## 6. Spring Break ③ ~Wanting to Protect~

"Hah! Ju-just a dream...  
Nn...? Nuwah!"  

The newly awakened Yuu sensed something wet around his lower abdomen.  
It didn't feel like bedwetting though.  
A slippery, slimy sensation - an indescribable discomfort.  
*(Come to think of it, when I ejaculated in the dream, it felt incredibly good...)*  
It felt so real that Yuu almost believed he'd synchronized with his dream self during the climax.  

"N-no way..."  
He threw off the duvet.  
A large stain was already visible on his pajama pants.  
"Th-this is definitely..."  
Pulling up both his pajama pants and underwear confirmed it.  
"A wet dream?! At this age?!  
...Wait, shouldn't this be normal? This body is still a teenager's after all."  

Yuu's original self had never experienced nocturnal emissions.  
In his youth, he'd masturbated too frequently to have them.  
He'd heard that abstaining for about a month could cause wet dreams - and that they felt amazing.  
The current Yuu had no memories of masturbation.  
So perhaps this wasn't surprising.  
But his current situation was extremely problematic.  

"W-wait. No time to panic yet."  
The clock showed 6:45 AM.  
Since Yuu was recovering well, Martina - his mother in this world - had returned to work and wouldn't visit until evening at earliest.  
Temperature checks and breakfast usually came after 7 AM.  

"Need to handle this before then."  
Trying to dispose of the evidence before the nurse arrived, Yuu pushed aside the duvet and sat up.  
As he turned right to get out of bed, someone knocked on the hospital room door.  

"Good morning! Yuu-sama, are you awake?"  
"Gah!"  
"Oh, you're already up?"  

After several days of consciousness, Yuu had learned four nurses rotated shifts in the male VIP suite on the hospital's top floor.  
Few male patients were hospitalized here to begin with.  
There were slightly lower-grade private rooms for men where some elderly patients stayed.  
Currently, Yuu was the only VIP suite occupant.  
Hence four nurses could easily cover 24-hour shifts.  
All were women - in fact, aside from one elderly doctor and a part-time physician, all medical staff were female.  

The smiling nurse who saw Yuu trying to rise was Kajio Shiho - the first person he'd met upon waking in this world.  
In her mid-twenties, she was the youngest and prettiest of the VIP nurses.  
Yuu panicked.  

"Are you feeling better already?"  
Shiho approached with a gentle smile.  
Though any patient would be pleased by such attention from a beautiful nurse, the timing was terrible.  

"Ah... no, just need the toilet."  
Though his sprained right ankle only allowed slow walking, nurses always accompanied him to the bathroom.  
Embarrassing as it was, they seemed to consider this duty important, making refusal difficult.  

"Hmm? Something smells floral...?"  
Shiho sniffed as she drew near.  
"...Ah!"  
Yuu tried stepping past her to handle his sticky situation before she noticed.  

"Ouch!"  
Leading with his injured right foot was a mistake.  
He stumbled instantly.  
"Yuu-sama!"  
Shiho moved reflexively - a nurse's trained response.  
She caught Yuu frontally as he fell.  

""Ah!""  
They ended up embracing.  
"S-sorry!"  
"Wah! N-no... it's fine..."  

Their similar heights brought their faces close, lips nearly touching as they stared at each other.  
Shiho flushed crimson enough to emit steam.  
Though a decade older than Yuu, her virginal reaction seemed odd - but Yuu was more concerned about his damp crotch touching her.  

Their embrace lasted mere seconds.  
Regaining composure, Shiho forced a bright tone.  
"N-now, that was dangerous. Let me support you."  
"Ah, okay..."  
Taking Yuu's arm over her shoulder, she helped him shuffle to the ensuite bathroom.  
Though wanting to pull away, Yuu yielded.  
Shiho's grip felt unusually firm, her face still flushed as she looked down.  

"Um, I'll be fine now. It'll take a while..."  
The unit bath included a shower he intended to use.  

"Ah... I'll wait outside then.  
Call me when you're done."  
Shiho seemed to understand, stepping away as Yuu closed the door.  
She'd come early hoping to chat during the temperature check - maybe even glimpse his sleeping face.  
But this unexpected bonus left her giddy.  

*(Ufu, ufufu... I embraced Yuu-sama! So slender yet firm... and that wonderful scent... young boys' bodies really are the best~  
Ahh~ I wish time had stopped there...  
...Oh no, just that much has already got me...)*  
Walking back to the bed, Shiho hugged herself with a slack smile.  

***

After lunch, Yuu watched TV from the sofa.  
The large CRT television was something his middle-aged self rarely saw in his original world.  
A daytime talk show filled the screen.  
Channel-surfing revealed a consistent pattern: announcers, commentators, hosts, reporters, celebrities, and interviewed politicians/critics/athletes were all women across networks - including public broadcasting.  
Men appeared occasionally but rarely more than one or two per program - essentially the "token male" equivalent of variety show idols in Yuu's world.  
When the lone male panelist spoke, women reacted exaggeratedly, fawning over him.  

"Men really are scarce and precious here..."  
The terms "Countermeasures for Low Birthrate Law" and "New Male Protection Law" caught his attention.  
Hearing only that they'd been enacted ten years ago, he resolved to research them later.  

According to Yuu's inherited memories, his middle school had over 200 girls to just 7 boys - roughly a 1:30 ratio.  
Essentially one boy per class.  
Japan's population statistics were unknown, but the imbalance was severe.  
Normally, 29 women per class would go partnerless.  
Even with polyandry, only a few men could support multiple wives.  
Harems with dozens of women existed only in eroge games, not reality.  
Thus, competition among women for men must be fierce.  
Yuu worried whether societies could function properly like this.  

An afternoon news segment led with rising sexual crimes against underage males.  
The announcer reported gravely that while adult cases remained steady, juvenile assaults were increasing.  
The gender gap had widened among 13-20 year olds, driving hopeless girls to commit violent sex crimes.  
Some elementary school girls - encouraged by mothers seeking "preemptive claims" - were even assaulting male classmates.  
Girls from multi-generation all-female households were particularly prone to rape, trapped in negative cycles.  
The government was considering harsher penalties and lowering the age of criminal responsibility.  
Recalling his own attack and last night's dream, Yuu realized this wasn't abstract news.  

***

"Yuu-chan! Yoohoo!"  
"Eh? Mom, what about work?"  
Martina arrived unexpectedly after 4 PM, still hyperactive.  
Since waking, Yuu's lack of rejection seemed to delight her.  
His middle-aged self simply treated her normally after accepting her as his mother.  
So far, she misinterpreted his personality shift positively.  

"Aahn! For Yuu-chan, work can wait... just kidding! My schedule's flexible today. I brought someone for you to meet!"  
"Meet someone?"  
"Yes, your new Male Protection Officers!"  

Two women followed Martina inside.  
Both wore black pantsuits but contrasted sharply.  
The taller one stepped forward and bowed.  

"Kitamura from MALSOK.  
I've been assigned team leader for your security during outings."  
Her business card read:  
『S-Class Male Protection Qualification・Kitamura Kanako』  

Clearly over 180cm, she stood taller than Yuu.  
Her broad shoulders suggested a toned physique beneath the suit.  
Chestnut hair fell straight to her shoulders.  
Sharp eyes, a high nose, and resolute mouth gave her a dignified, reliable aura - like an esteemed elder sister.  
She appeared mid-twenties.  

"Ah, pleased to meet you."  
Yuu stood to accept the card, then offered his hand - a bold move for his middle-aged self facing young women.  
But Male Protection Officers were essential in this world.  
Since they'd spend much time together, getting along seemed wise.  

Kanako hesitated momentarily before shaking hands.  
A slight smile flickered across her lips, but Yuu missed it, distracted by her prominent bust.  
*(Whoa... huge. And beautiful too.)*  
Not quite Martina's size, but undoubtedly busty.  

The other woman glided closer.  
"Kujira."  
"Kujira?"  
"Ku・ji・ra."  
Her intonation differed from the mammal's name.  

Her card read:  
『A-Class Male Protection Qualification・Kujira Touko』  

Around average female height from Yuu's world - mid-150cm.  
A short bob with long bangs hid her face, but large, upturned eyes left an impression.  
Her petite frame showed no obvious muscle, yet she exuded alertness - necessary for the job.  
Though she looked high-school aged, she must've been around twenty.  

"Ah, so it's Kujira-san. Unusual surname."  
A small hand thrust toward him.  
Touko stared expectantly.  
"Ahaha. Pleased to meet you."  
"Nn. I'll protect you well. Won't let any scum touch you."  
Kanako shot her a stern look.  
*(Guess that's her character.)* Yuu didn't mind.  
If Kanako was the reliable big sister, Touko felt like a bratty little sister.  
"I'm counting on you."  
He enveloped her small hand in his.  
"...!"  
Despite initiating, Touko looked down, cheeks flushing crimson.  

With introductions done, Martina explained:  
"Kitamura-san and Kujira-san will be stationed 24/7 at our condo.  
Lately there've been intruders bypassing security - it's dangerous. This way I'll feel safe when working.  
Especially Kitamura-san! She holds the highest S-class qualification nationwide!  
I couldn't bear another attack like before, so I insisted they take the job."  
"R-really? Um... thanks, Mom."  
"All for you, Yuu-chan."  
Martina nodded matter-of-factly, making Yuu blush harder.  
The new officers smiled fondly at the mother-son scene.  

Male Protection Officers at Yuu's graduation had been burly and plain-faced.  
Comparatively, these two were beauties - always preferable for male companions.  
They'd accompany him during commutes via school security buses from condo to campus.  
Outings required teams of three or more.  
Men clearly couldn't walk alone here - a restriction Yuu disliked.  

Later he learned their fees exceeded the previous security company by 20%, but settlement money and government compensation covered it.  
Such concepts still felt alien to him.  

"Oh yes! You know about the April 1st checkup? You'll have your semen test this year. Here's the pamphlet."  
"Huh?"  
Martina produced a thin A4 booklet titled 『Nationwide Simultaneous Male Health Checkup Information』.  
Below cheerful illustrations of boys and men, it stated:  
『Since 1981, semen testing and biannual sperm donation are mandatory from age 15』  

***

After the introductions, Kanako and Touko left for their company car.  
Behind the wheel, Kanako couldn't suppress a smile recalling Yuu's beautiful face, shy smile, and handshake.  

Once driving, Touko murmured:  
"Jackpot."  
"Hm? Ah... perhaps."  
Having partnered before, Kanako recognized Touko's rare verbal bursts.  
"Yuu-sama♪"  
Glancing at the passenger seat, she saw Touko smirking.  
Slightly creepy.  

"Well... I get it. Most protected men avoid eye contact, refuse conversation, and hate being touched.  
Yuu-sama seems wonderful.  
I'd braced for a difficult client after hearing schoolgirls attacked him."  
"Want to protect him 24/7♪ From everything that hurts Yuu-sama."  
Touko sang, making a hugging gesture.  

Usually inscrutable, her petite frame and unassuming look belied her skills.  
Trained in multiple martial arts with excellent combat scores, she'd even landed hits on Kanako from behind.  
Her codename "Shinobu" (忍) came from her ninja-like movements.  
Kanako's was "Neki" (ネキ) - "big sis" - which she disliked despite being just two years older (24 vs 22).  
Their contrasting appearances exaggerated the age gap.  

"I know, but he's an important client."  
"Nn. I'll indulge my fantasies only in my head. I can separate reality."  
"Honestly, you're hopeless..."  
Touko was secretly lewd.  

"And Neki's been grinning dopily since earlier."  
"Hah!"  
"Come to think of it, you have a brother the same age-"  
"Don't say it!"  
"Watch the road!"  

Kanako's fluster nearly made her cross the centerline.  
Her only weakness was her brother - Yuu's age - whom she adored.  
His upcoming boarding school enrollment saddened her.  
Regardless, both officers found their new client professionally rewarding... and privately intriguing.  

---

### Author's Afterword

Popular chastity-reversal novels on "Narou" often feature unique Male Protection Officers.  
In a male-scarce world, such bodyguards feel essential.  
Yet they rarely appear in nocturne (adult) works - likely because they'd restrict the protagonist's... activities.  

Still, I deliberately included them here.  
Though they start with high favorability toward the protagonist, whether relationships deepen remains uncertain.  


### Chapter Translation Notes
- Translated "夢精" as "wet dream" to maintain explicit terminology while preserving natural flow
- Preserved Japanese honorifics (-sama for Yuu, -san for officers) per style rules
- Translated "精液検査" as "semen test" and "献精" as "sperm donation" using precise medical terminology
- Maintained Japanese name order (e.g., Kajio Shiho, Kitamura Kanako)
- Transliterated sound effects (e.g., "Nuwah!" for ぬわぁっ)
- Used explicit anatomical terms ("ejaculation", "crotch") without euphemisms
- Formatted simultaneous dialogue with double quotes ("「「...」」" → ""Ah!"") during embrace scene
- Italicized internal monologues per style guidelines
- Translated professional titles formally ("Male Protection Officer")