## 7. Spring Break ④ ~Super Chance~

### Author's Preface

This time it's a bit long.

---

April 1st.

Around 10 AM that day, he left the hospital for the first time since becoming Yuu in this world.

Though it was just the annex building three minutes' walk away.

Even so, he hid his face with a white hooded parka to avoid being recognized as male at a glance, surrounded by his protection officers Kanako and Touko along with attending nurses as they exited through the hospital's night entrance.

Since it was early morning, they reached the annex's back entrance without being noticed by anyone.

Today, a health checkup for males would be conducted there.

Judging by the pamphlet provided beforehand, it wasn't much different from those at schools or companies.

Measurements of height, weight, and chest circumference; vision, hearing, blood pressure, blood tests, chest X-rays, urine tests, and electrocardiograms.

The only difference was the mandatory semen test required from age 15.

Was it about five years ago?

A married colleague who couldn't conceive underwent a semen test as part of infertility treatment and secretly confided in me.

He was reluctant, but since both were in their mid-thirties with no time to spare, his wife persuaded him to go.

The result was a diagnosis of azoospermia.

"I was told I have no ability to father children," he muttered self-deprecatingly at a drinking party, I recall.

Ultimately, they chose to live as a childless couple.

*(Semen... I guess I have to masturbate into a test tube or something?)*

I believe my colleague mentioned something like that.

Apparently, erotic magazines and comics are prepared as "material" in small private rooms.

"We'll wait here. There shouldn't be any issues while you're inside this building, but if anything happens, press that transmitter button hard."

Kanako and Touko seemed to be waiting in the first-floor lobby.

Seeing groups of two or three similarly suited, well-built women sitting together on chairs, they were likely fellow male protection officers.

They only glanced when Yuu entered without particular reaction.

Conversely, the receptionists sitting at the counter in the back were subtly stealing glances while pretending nonchalance.

Security guards in uniform stood at key points like elevators and corridors, with the main entrance shuttered and dimly lit.

Today seemed completely closed to general patients.

"Well then, I'm off."

Yuu bid farewell to Kanako and others and headed to the reception counter.

Another young man was checking in at the counter, likely also here for the checkup. Apart from the elderly hospital doctor, the first male Yuu had seen in this world. Probably around 20, older than Yuu.

Surprisingly, he felt relieved seeing him - perhaps from being surrounded by women so long. He never imagined feeling that way about seeing another man.

The man finished checking in and walked toward the elevators.

Yuu handed over the medical questionnaire filled out in his hospital room, unable to hide his nervousness.

He didn't think he had any medical history but had confirmed with Martina while writing it just in case.

For Yuu, a regular checkup was familiar, but he couldn't hide his anxiety about his first semen test.

"Yes. Hirose Yuu-sama, correct? Please take this and go up to the third floor via elevator, then hand it to the staff there."

A young woman in navy-blue office uniform smiled broadly while explaining.

When handing over the clear file containing test forms, their hands touched - probably just his imagination that the gesture seemed deliberate.

Upon reaching the third floor, he gave the clear file to a nurse in white waiting there and was told to sit in the lined chairs.

A large rectangular room that could hold about 100 people. Yuu thought it might normally be used as a conference room.

Present were nurses in white conducting examinations behind long desks or walking around with documents.

And about 20 men undergoing examinations.

Ages ranged from teens to forties. Those below elementary school and over 60 were in separate locations.

At first glance, it resembled company health checks Yuu had experienced.

However, perhaps because it was early, there were fewer people than expected.

No - fundamentally, there were fewer men in this world.

Though the checkup was scheduled only for today, it might not be crowded with long waits like Yuu had experienced.

As expected, within three minutes of sitting, a nurse around 30 called his name.

"Now, Hirose-sama. First we'll measure height and weight."

"Yes."

Entering the partition at the room's right end, there were familiar height measurement equipment and a large scale.

"Height 170.5 cm, weight 57.2 kg. Is that correct?"

"Yes."

*(Taller and lighter than I was at this age. Also a bit skinny.)*

He'd thought so while bathing - not much muscle.

Hadn't he joined any sports clubs in middle school?

No, fundamentally there were no boys' sports clubs, he confirmed.

Since he'd been rejuvenated, he should build muscle through training, Yuu thought.

With little crowding, he proceeded through examinations quickly.

Vision was excellent at 1.5 in both eyes as expected.

Naturally, better to see far without glasses.

Hearing no problem.

The blood test nurse around 40 was skilled at inserting needles, causing little pain.

What bothered him slightly was how overly cheerful the nurses were and how much they touched.

Seeing other men similarly resigned, he understood.

*(So many men to see - how wonderful! So glad I got assigned this year!)*

*(Really! Such a treat for the eyes!)*

*(Especially the young ones. Glowing skin, such a nice smell...)*

*(You're touching awfully much!)*

Perhaps thinking they couldn't be heard, whispers came from behind the partition as Yuu waited seated for the next test.

Conversations like those of sexual harassers.

Come to think of it, most nurses here were 30s to 40s.

Yuu keenly felt how gender perceptions were reversed.

Unsurprisingly, internal examination and ECG requiring upper body nudity were handled by male doctors.

During the internal exam, he reunited with the elderly doctor he knew, who inquired about his progress and made small talk.

"I'm unnecessary now, but you have your first semen test ahead. Well, I pray you have vigorous sperm."

"Haa."

He opened the door to a separate room for the final semen test.

Three chairs were prepared at the reception desk, but the right one was vacant as the staff member was away, and the left had a man receiving explanations.

So Yuu sat in the middle.

The nurse opposite appeared the youngest there, around 20.

For some reason she looked down, her face unclear.

"Excuse me."

"Y-yes!? S-sorry! ...Ah!"

When the woman saw Yuu's face, her eyes widened in surprise.

Slightly wavy brown short bob hair, with thick bangs and outward-curled sides reminiscent of 80s idols.

Though somewhat droopy-eyed, plump tear bags made her eyes look gentle.

Small nose and mouth features. Most striking was the mole under her right eye.

More modestly cute than beautiful.

Her nameplate read Takano Mio.

Most eye-catching was the prominent swell of her breasts beneath the white coat.

"S-s-s-sorry. U-um, Hirose Yuu-sama, semen test, correct?"

Coming to her senses, Mio checked the test form.

"Ah, yes. My first time."

"Th-then, I'll explain."

Mio set up an illustrated board and began speaking.

As part of anti-low-birthrate measures, the previously optional semen test became mandatory 10 years ago, with sperm condition rated in four tiers.

Those rated "Pass" or above (excluding "Fail" for azoospermia) must provide sperm donations at least twice yearly.

No specific dates - just visit designated medical institutions anytime.

Men rated "Good" or "Excellent" above "Pass" receive thank-you payments per donation.

"We especially encourage 'Excellent' rated individuals to donate monthly if possible! It helps the nation and brings generous payments! All benefits!"

There was even a pamphlet on diets and habits to improve sperm quantity and quality.

Yuu was surprised such things existed.

"Now then... we'll proceed to the... semen test... Um, the procedure is..."

Her previously fluent speech became halting.

She showed the final board.

Yuu watched suspiciously.

『Please ejaculate semen into the dedicated container yourself.  
※ Handle the container after hearing explanations from the attendant.

The attendant may provide support for ejaculation.  
Please consult thoroughly with the attendant about preferred methods.

※ If unable to ejaculate at the designated venue today, the test must be scheduled within one week.  
Thank you for your cooperation.』

Cartoonish illustrations showed men holding test tube-like containers with white liquid inside - semen.

Hiding most of her face behind the board, Mio spoke falteringly.

"As you see, there are two methods... Ah, um, private rooms are prepared over there... umm..."

She placed a box on the desk, opening it to reveal an empty test tube in a transparent bag.

The opening had a specially designed rubber stopper.

"P-please... put your... s-s-semen... into this container..."

Yuu mostly understood, but one point concerned him.

He hesitated to ask a young woman, but decided to inquire since it was his first time.

"Um, excuse me."

"Y-yes!"

Yuu pointed at the second sentence with trembling fingers.

"'The attendant may provide support for ejaculation'? Does that mean... you'll help me ejaculate?"

"Huh?"

He wondered why she looked dumbfounded.

*(Wait. This isn't some shady place where cute young girls promise handjobs but middle-aged women show up, right?)*

Having experienced such tricks, Yuu pressed carefully.

"To confirm - will you... Takano-san, do it? If so, I'd appreciate it."

"Wh... whaaaaat? Eh? Wha-? Me!? Why!? Wh-wh-what should I do!?"

Her rapidly changing expressions amused Yuu, making him stare.

He didn't dislike this flustered clumsiness.

But sensing no progress, Yuu took panicking Mio's hand and stood her up.

Fortunately, both adjacent seats were empty, but he didn't want attention.

"Hey, let's go. Or... do you dislike helping me?"

"N-n-no! Not at all... Rather... p-p-please..."

Only now noticing her held hand, Mio flushed from face to ears.

Mio seemed a bit clumsy but amiably cute.

At his former company, a new girl like Mio was popular as men felt protective.

That she agreed so readily after brief talk...

His young, handsome appearance must be helping, Yuu thought.

"Wow, so this is the inside."

"Ah, my first time too..."

"Eh? But you're assigned?"

"Ah... I'm a new nurse, substituting for a senior who was suddenly hospitalized. Plus, all men I've received so far did it alone. I never imagined assisting..."

"I see."

That explained her freshness, Yuu realized.

Opening the door revealed a small three-tatami room.

A hospital-style pipe bed occupied half the space.

With little extra room, the two stood nearly touching.

Perhaps unsettled by Yuu's proximity, Mio fidgeted while looking around.

A magazine rack in back likely held magazines or comics - "material."

Yuu wondered if male-oriented adult products existed here but feigned disinterest with Mio beside him.

Between bed and rack was a lidded wastebasket hiding contents.

Besides a pillow, a thin blanket was folded small at the bed's foot.

Two stacked tissue boxes sat conspicuously near the pillow.

Truly a room for ejaculation.

"Um, shall we sit first?"

"Ah, yes."

Yuu sat near the bed's center, Mio leaving a person's space beside him.

"Hey."

"Y-yes! Wh-what is it?"

"If you sit so far, you can't assist."

"Eh... but it feels presumptuous..."

Even as the assigned attendant, no men requested handjobs.

She and others hadn't anticipated this.

In Yuu's world this would be a reward, but men here likely avoided such "landmines" fearing women.

Moreover, Mio's inexperience with men left her bewildered in this confined space, forgetting what to do.

Yuu moved sideways until their bodies touched.

"Haoh!"

"Shh! Don't be loud. Walls seem thin."

"Ah-ah, but being with a man... howaaaaah..."

*(She's excessively naive.)*

Mio's flustered state eased Yuu's nerves.

Turning fully toward steam-almost-coming-from-her-head Mio, he embraced and stroked her hair.

"There, good girl. Calm down, okay?"

"Howawawawa... ahfunnn"

Mio stiffened momentarily at being hugged but seemed to relax into Yuu's stroking, closing her eyes.

As a married middle-aged man inside (though outwardly reversed), Yuu intended to show elder composure.

But upon embracing Mio's soft body, his heartbeat raced intensely.

Likely no perfume as a nurse, but floral shampoo scent from hair touching his cheek tickled his nose.

Mio panted "haa, haa" at his chest.

Sliding his left hand from her back along her side to waist revealed surprising firmness.

Feeling Mio through five senses reminded Yuu of his first relationship and embrace twenty years prior, his chest aching. Simultaneously aroused, he felt his male desire ignite.

*(I could push her down on this bed...)*

Tempted momentarily, he regained composure - perhaps from age.

After five minutes holding and stroking her hair, he slightly separated.

"Better? Calmer?"

"Ah... my heart's still pounding."

Mio clutched Yuu's parka hem regretfully.

"Same here."

"Huh? R-really?"

"Yeah."

When Yuu nodded, Mio looked up with a modest smile.

*(So cute!)*

Yuu almost embraced her again.

But he remembered their purpose.

"Um, we need to collect semen? I'll undress."

"Ehh! W-w-wait! I'm not mentally read—"

Ignoring flustered Mio, Yuu unbuttoned his jeans, lowered the zipper, and placed hands on hips.

He pulled down his underwear too.

His half-erect member appeared.

Mio covered her face but watched through finger gaps.

"Hyah! Ah... this is... Mr. Penis?"

Yuu wondered what that meant but took Mio's hand.

"Not fully erect yet. Could you use your hand? Also, better prepare the container now."

"Y-y-yes!"

"Come closer."

"Howohh..."

Seeing Mio fumblingly produce the test tube - resembling a round-bottom flask for semen collection - Yuu positioned her hugging him from behind diagonally.

He placed her left hand holding the container around his back/waist on standby.

Mio's right hand merely rested on his crotch, unmoving.

But her ample breasts pressed softly against Yuu's side through the coat, their softness making his member swell as he enjoyed it.

"Ahh! Mr. Penis is getting big! Eh? Eh? Eeeeeeeeeeeh!!!"

An exaggerated reaction.

In this world, average Japanese penis size was nearly 4cm smaller than Yuu's world - about 10cm.

Reasons included reversed social roles making women larger while men grew less, plus decreased male libido.

Thus Yuu's size was exceptionally large.

Though strictly instructed never to comment on size after seeing male genitals during training, Mio didn't explicitly say so.

"Mr. Penis...? Well, whatever. Keep touching gently."

"Yes! Um, like this?"

"Y-yeah."

Mio stroked the shaft's surface up-down with unskilled hands.

Just that felt pleasant.

"Wow... First time seeing, first time touching... somehow amazing. Ah, I'm moved."

"Haha. Exaggerated."

Now fully erect and pointing skyward, Mio gazed raptly.

*(Too blessed - handsome AND huge penis.)*

Yuu marveled inwardly.

He'd seen morning erections in the hospital, but seeing it now was astonishing. Eyeballing about 18cm long.

The impressive glans created deep coronal sulcus.

His middle-aged self had been average, so he couldn't imagine women's reactions to this.

In his elementary school dream, it was under 10cm - a child's penis with full foreskin, but it seemed to grow with his height.

Being hugged and stroked by Mio felt good, but reaching ejaculation for collection would take time.

Yuu turned his head toward Mio.

"Hey, could you grip lightly with your right hand?"

"L-like this?"

She gripped the shaft area.

"Move your hand up-down from base to tip while gripping. That feels good for men."

"O-okay. Then I'll do my best to make Yuu-sama feel good!"

As motivated Mio began stroking while gripping, Yuu felt enveloped in pleasure.

Youth made him sensitive to stimulation.  
"Mm... ahh, good. Playing with the tip with fingers would be nice."

"Y-yes! L-like this?"

Mio's right hand reached the sulcus, rubbing the slightly reddish glans with two fingertips.

She alternated between stroking and glans stimulation every few pumps.

"Kuh... nngh..."

"Ah, um..."

"It's fine. Well done. Keep going."

Yuu involuntarily moaned but winked playfully to show composure.

Mio visibly relaxed.

Likely her first time, but her serious expression while hand-jobbing was endearing.

"R-really? Glad... haaah... Mr. Penis is so hard and hot. So wonderful... ah! Something came from the tip!"

"Nngh... feeling really good now. Better prepare for collection."

"Y-yes!"

Worried if it would fit, Mio flipped open the container's lid and brought the opening near the penis.

The opening had black rubber with a central slit.

She pressed it against the tip, inserting until the glans barely entered.

She managed smoothly, likely having practiced, sighing in relief.

But concentrating on the container stopped the handjob.

"Keep hand-jobbing. A bit faster."

"Ahh! Sorry!"

The resumed handjob.

Precum dripped, making soft nuchu nuchu sounds.

Held tightly from behind, Yuu felt Mio's soft breasts as his ejaculation built.

"Good, keep going..."

"Yes!"

Glancing sideways, Mio's face was close over his shoulder.

His eyes drew to her modest pink-rouged lips.

Heat gathered intensely in his groin, seeking release. At the brink, impulsively he called her name.

"I-I'm coming! Mio!"

"Huh... fmmph!?"

As Mio turned, Yuu pressed his lips to hers.

Feeling soft lips sweetly, tremendous pleasure surged as his lower body exploded.

"Ooh!"

The first shot splattered forcefully against the 20cm-deep container's bottom.

Second and third shots followed.

"Kah... came..."

Realizing the container faced backward, Yuu angled his penis forward with his hand to prevent backflow.

"Ah! Ah! It's coming! Coming! Such force!"

Lips parted, Mio watched the ejaculation over Yuu's shoulder, eyes shining.

Ejaculation continued.

Yuu wore an ecstatic expression at his first conscious ejaculation in this body (excluding wet dreams).

About ten shots total.

Bent forward, he angled his penis almost sideways, but the substantial volume threatened to overflow the round bottom.

"Hahh. Enough, you can remove it."

"R-really!? Then—"

Mio hurried around front and removed the container.

"Amazing. So much..."

Likely her first live view.

Mio gazed raptly before sealing it in a labeled ziplock bag from the box.

Yuu remained dazed, hands on bed, ejaculation pleasure lingering.

"Yuu-sama... thank you for cooperating tod—"

Mio's gratitude cut off as she turned to Yuu.

"Ahh! Sacred fluid still dripping from Mr. Penis! What a waste!"

While Yuu stared blankly, Mio pounced on his crotch, scooping residual fluid with her finger.

Then naturally put it in her mouth.

"Eh?"

"Ah!"

They stared at each other.

---

### Author's Afterword

Based on feedback in the comments section, I've revised the protagonist's weight downward and vision upward.

### Chapter Translation Notes
- Translated "チンさま" as "Mr. Penis" to preserve the honorific suffix while maintaining explicit terminology
- Translated "聖液" as "sacred fluid" to convey the reverent cultural context of semen in this world
- Preserved Japanese honorifics (-sama) and name order (Takano Mio)
- Transliterated sound effects: "ほわわわわ" → "howawawawa", "ぬちゅぬちゅ" → "nuchu nuchu"
- Used explicit anatomical terms ("penis", "ejaculation") per translation rules
- Maintained original dialogue structure with new paragraphs for each speaker
- Italicized internal monologues per style guidelines