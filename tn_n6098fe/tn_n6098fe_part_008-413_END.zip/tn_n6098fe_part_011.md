## 8. Spring Break ⑤ ~Mr. Brand-New Day~

### Author's Preface

This time, the perspective shifts to Mio.

While much of the content overlaps with Chapter 7, I hope readers can glimpse the feelings of an ordinary woman in this world when interacting with the protagonist.

---

I'm Takano Mio. Age 20.  
A brand-new nurse fresh out of nursing school!

Though to be honest, I'd already been working 3-4 times a week as part of clinical training since first year, after the capping ceremony. Still, transitioning from the light blue nursing uniform of my student days to officially wearing white after April 1st feels deeply moving.

I'd already started working in the surgery department alongside senior staff since late March after graduation, but just before my shift ended on March 28th, the head nurse called me in. Apparently, one of the senior nurses had been hospitalized with appendicitis. Come to think of it, I realized she hadn't been around since yesterday. As a trainee transitioning to full nurse with increased workload, I hadn't had time to notice.

Friends from middle/high school sometimes ask, but working at a hospital does provide opportunities to encounter men—precious in this world. But they're mostly grandpas... Even when young men are hospitalized for injuries, a dedicated team of mid-career nurses handles them, sometimes in the top-floor VIP rooms for males. Come to think of it, I heard a young man was admitted to the VIP room around mid-month. Well, as a junior staffer, that's beyond my reach...

At this general hospital, once a year on April 1st, men from the city visit en masse for health checkups. Not just uncles, but young boys too! Seeing, talking to, even touching so many men! Nurses are selected from each department for this duty without disrupting regular operations, but I've heard this sparks fierce competition. To avoid bloodshed—literally—some departments use strict lotteries or five-year rotation systems. Surgery prioritizes veterans at milestone years like 10th/15th anniversaries. That meant I wouldn't get a turn for another 9 years. I'd resigned myself to it.

But as mentioned, the 10th-year senior scheduled for duty was hospitalized with appendicitis. She was reportedly crying from both pain and frustration over missing April 1st duty. Hence, I was sent as substitute. Why me, a rookie?

"Pulling more nurses would disrupt regular operations. Only rookies who don't count as full staff are available! Understand, Takano? This is incredible luck! Give me all the details later!" The head nurse's explanation made sense.

Since assignments were decided a week prior, I was drilled with training until the night before, leaving me exhausted. My assignment? Semen testing. The materials mentioned nurses might assist with semen production...? Could I really... touch a man's thing directly? Me, who's only seen pixelated images in R16+ media or erotic manga!?

"Relax. That won't happen 99.99% of the time." The instructor's words confirmed my suspicion. "When semen testing was first introduced, occasionally boys who'd never masturbated needed nurse assistance. Ahh, those were the days. Now junior high health education covers it, so even inexperienced boys manage alone or prepare samples at home. Your duties are explaining procedures and handing out containers. Officially, assistance is possible—maybe a 0.01% chance—so we'll teach the method." "Ah, yes."

I fantasized about boys shyly handing over semen-filled containers or saying "Nurse, could you help?" feeling strangely aroused. *Heheh. This might be nice.*

"Still, it's a rare chance to talk face-to-face with many men. Be extra friendly. Young girls like you might get special treatment." "Ooh! I'll make this once-in-a-lifetime stage count!" "Hahaha." I didn't realize then that the instructor was teasing me.

---

"Haa~"  
"Hey, no time to mope. Next person's coming soon."  
"I knowww."

Within an hour of the checkup starting, my glass heart was already shattered.

The first at my station was a dignified man around mid-twenties—perfect marriage material. Excited, I energetically began explaining...  
"Enough. I know. Just give me the container." Despite memorizing the script late into the night, he cut me off mid-explanation as I started without checking the notes.  

"Eh, but—"  
"I've been doing this ten years! Don't need explanations now!"  
"Y-yes! Sorry!"  

Scolded, I could only hand the box containing the semen container to the stern-faced man. This repeated 7-8 times. Teenage boys mostly listened, but visibly recoiled at "The assigned staff may assist with semen production." I got clicked tongues, cold stares, and insults like "Pervert! Sexual harassment!" It's not like I wanted this! I almost cried.  

"Men are sensitive about such things. Even with medical necessity, only sex workers stay calm hearing this from women. Elsewhere, 'Give me semen' would be instant harassment charges." "Sigh. I guess so."  

Veteran nurse Bitou-san (40), who sat to my right, had life experience—even a daughter via artificial insemination. Meanwhile, Eitou-san on my left kept excusing herself for breaks after being yelled at by the first man. With only two of us handling what should be three stations, it was hectic.  

"Good work! How's the checkup? Nervous? Eh? Just grandmas so no? Oh stop! Ahahaha!" Bitou-san eased men's tension with auntie-talk. She summarized explanations for teens and skipped them entirely for older men with just chit-chat. Men accepted containers smoothly with wry smiles—a skill born of experience.  

I had no such composure. The more earnestly I recited memorized lines, the more men disliked it, creating a vicious cycle. The last 30-something man stayed silent, avoiding eye contact, reaching for the container without listening. I could only hand it over.  

During a lull, I looked down with a heavy sigh. The door clacked open—next person. Eitou-san absent as usual, Bitou-san chatting with a friendly uncle. Meaning they'd come to me. Footsteps approached.  

"Excuse me."  
"Y-yes!? S-sorry! ...Huh!?"  

Forced to look up, I saw an angel before me.  

An impossibly handsome face like a foreign statue from my middle school art room—sharp, well-defined features. Black hair slightly long, tips brushing ears and nape, yet clean and silky-looking. Taller than my 157cm—maybe 170cm? Long legs like male models in magazines. *Ahh, so handsome!* I stared dazedly, almost drooling.  

The boy smiled gently, watching me. Being stared at like that made me feel strange. Flustered, I checked his form.  

"Su-su-sorry! Um—Hirose Yuu-sama, semen test, correct?" I instantly regretted stating the obvious, but Yuu-sama didn't scowl like others.  

"Ah, yes. My first time."  
*Ahh, I get to assist his first time!* Such an honor! Bitou-san beside me also gaped at Yuu-sama. *Could such beauty exist? Too dazzling for public view—I worry women like me might assault him.*  

Taking a deep breath to refocus, I began: "Then, I'll explain."  

Yuu-sama sat properly on the pipe chair, listening attentively—even nodding along. So touched, tears welled up. I quickly wiped my eyes while switching boards.  

The explanation progressed smoothly to collection methods. Now the critical part.  
"As shown, there are two methods... Ah, um, private rooms are prepared over there..." Afraid of his reaction, I hid behind the board, stammering. "Pl-please produce... semen... into this container..."  

Peeking, I saw Yuu-sama looking at the plastic-bagged container.  

"Um, excuse me."  
"Y-yes!"  
He spoke suddenly, making me jump.  

"'The assigned staff may assist with semen production'? Does that mean... help me ejaculate?"  
"Hweh?"  

*What is this beautiful boy saying?* No man had asked this. How should I answer?  

"Just to confirm—you... Takano-san will jerk me off? Then please, by all means."  

I froze, mentally replaying his words. *Takano-san—me... jerk off? What? Please? What does he mean?*  
"Ha.........hiiii? Eh? Wha—me!? Why!? Wh-wh-what do I do!?"  

Bitou-san was away guiding that uncle; Eitou-san predictably absent. *Help!*  

Then Yuu-sama suddenly took my hand, standing me up...  
"Hey, let's go. Or... do you dislike helping me?"  
"N-n-n-no! Not at all... Rather... pl-please..." My face burned crimson. So embarrassing. But glancing up, Yuu-sama still smiled, warming my heart. Carrying the container box, hand-in-hand, we moved to the private room.  

---

"See? Good girl, calm down, okay?"  
"Howawawawa... Afuun~"  

*Is this an angel's embrace? Will I ascend to heaven?* Sitting on the bed, hugged and head-patted by Yuu-sama, I inhaled his neck scent. *My brain's boiling from my first whiff of male skin.*  

According to his form, Yuu-sama was 15. Friends say teen boys are targeted by women, making them timid. Yet here he was, calmer than panicky me despite being five years younger. Almost like an adult man inside... Meaning... utterly wonderful! My heart threatened to burst, but his head-pats made me warm and comfortable. *I want this forever...*  

"Better? Calmer now?"  
His body pulled away slightly.  
"Ah... still heart-pounding."  
I unconsciously gripped his parka hem, missing his warmth.  

"Me too."  
"Huh? R-really?"  
"Mm."  
His radiant smile shone before me. I smiled back—*did it look proper?*  

Yuu-sama seemed to remember something, releasing me. *So disappointing...*  
"Um, semen collection, right? I'll undress."  
"Ehh!? Wa-wait! Not mentally ready—!"  

*I suddenly remembered our purpose. That means... seeing his thing? I've never seen one directly before!*  

While I panicked, Yuu-sama casually stripped off jeans and underwear. *No! A teen boy shouldn't be so bold—Ooh!*  

The super-popular manga *Ohhh, Lord Dick!*—originally R16+, now a late-night anime. I own all volumes and record every episode. The protagonist is Seichin Ayumu, 16, secretly contracted with a shrine god enshrining penises, tasked as a justice warrior (not sexual play). Evil secret society "Virginity" turns virginity-obsessed women into lewd dominatrix demonesses who attack innocent boys. Opposing them is Ayumu-kun, masked with underwear, his crotch glowing with righteous Lord Dick!  

What slipped out when Yuu-sama stripped reminded me of Lord Dick mid-transformation.  
"Hyah! Ah... this is Lord Dick!"  
*Shouldn't confuse fiction with reality—* but I blurted it out. Unfazed, Yuu-sama took my hand:  

"Not fully erect yet. Could you make it hard with your hands? Ah, and take out the container now."  
"Y-y-yes!"  

*Why is Yuu-sama so composed despite being younger?* His clear instructions helped.  

"Here, get closer."  
"Hohoh... this is..."  
Flustered, I retrieved the container while hugging him diagonally from behind at his direction. *Unbearable!* Breathing in his scent, my breaths grew ragged. My hand rested on Lord Dick—I felt it swelling.  

"Ahh! Lord Dick's getting big!"  
"Lord Dick...? Whatever. Keep touching gently."  
"Yes! Um... like this?"  
"O-oh."  

*First time seeing/touching one... amazing. I'm moved.*  
"Wow... never seen or touched before but... incredible. Ahh, I'm so moved."  
"Haha. Exaggerating."  

Now fully erect, Lord Dick pointed skyward, majestic. Yuu-sama's version seemed divine—unlike anything in R16+ media. Wonderful texture, hard and hot... *My lower abdomen tingled.*  

Following Yuu-sama's guidance, I stroked with my hands—right hand moving up/down the shaft. Occasionally teasing the tip with fingers. Yuu-sama sometimes moaned—*am I doing it right?* But when he smiled, "Good. Keep going," I thrilled. *My heart was already captured.*  

*Not just my heart—seeing Yuu-sama's pained expression, I felt wetness down there. Not my period, but I wore a pad just in case...*  

At Yuu-sama's calm direction, I removed the container lid and inverted it over Lord Dick. Ready for collection. Transparent fluid leaked from the tip as Yuu-sama's breaths grew ragged—*the moment approaches.* My limited knowledge: white stuff shoots from the tip when men...  

"I-I'm coming! Mio!"  
Hearing my name, I looked up—something pressed against my mouth...  
"He... fmmph!?"  
"Oough!"  

Stunned, I kept moving my hand. Pulsations throbbed through my right hand—vibrations through the left-held container.  

*Kissing... me?* Not my first kiss—a memory I want to erase. High school (all-girls public school, not competitive co-ed), lost in the building, cornered by delinquent seniors. They forcibly kissed me like venting lust, groping my chest. Yuu-sama's kiss overwrote that—sweet, dreamlike. *Sploosh—lewd fluid gushed out down there. Ah, leaked onto my thigh. Whatever.* I couldn't think.  

"Kah... came..."  
Yuu-sama's voice snapped me back. Our lips parted. Following his gaze downward:  

"Wa-wa-wah! It's coming! So much!"  
Semen gushed powerfully from Lord Dick, rapidly filling the container. *Does it always come this much? Or is Yuu-sama special?* Leaning against his back, I stared transfixed at the whitening liquid.  

"Haa~. Enough? Can remove it?"  
"Y-yes! Then—"  
Remembering my duty, I hurried around front to remove the container.  
"Amazing. This much."  
Past the measurement line—thick fluid. *Precious Yuu-sama semen—handle carefully.* Sealing the lid, I wrapped it in the labeled plastic bag as taught and boxed it.  

Mission accomplished. Turning back, Yuu-sama remained slumped on the bed, hands down. *Exhausted?*  
"Yuu-sama! Thank you for your coopera—"  
I began heartfelt thanks...  

"Ahh! Holy fluid still dripping from Lord Dick! What a waste!"  

In *Lord Dick!*, enduring demonesses' torture converts Ayumu-kun's semen into holy fluid. Splashed on skin or entering via mouth/vagina purifies women instantly. Had I channeled those demonesses while stroking him? Suddenly craving holy fluid, I instinctively knelt between his legs, scooped dripping residue from the still-erect tip, and swallowed. *Bitter—adult flavor.*  

"Eh?"  
"Ah!"  

After a mutual stare, I realized what I'd done.  

"Aaaaaaahhhhhh—!! S-sorry!"  
*What have I done? Licking a man's semen without permission!* Cold sweat drenched me—I prepared to kowtow for forgiveness when Yuu-sama's hand patted my head.  

"Surprised me, but don't worry. Rather... could you clean my dick with your tongue?"  
"Huh? Really?"  
"Mm. Please."  
"Afu."  

*What woman could refuse an angelic beauty patting her head?* Rather, a reward. Plus, he'd started calling me "Mio"—my heart soared.  

"Th-then, excuse me."  
Holding Lord Dick lightly, I licked the tip. *Mm, delicious.* Delightfully, more holy fluid seeped out. With permission, I couldn't waste this chance. Opening wide, I took the tip into my mouth.  
"Kwoh!"  
"Mmphu?"  
"Ah, ahh, good. Keep going."  

*Good—not disliked.* Recalling the fellatio-specialist demoness from *Lord Dick!*, I moved my tongue inside my mouth. *Schlicking sounds—saliva and holy fluid?* Noticing no more fluid, I saw Lord Dick glistening with precum and sweat. I licked from the ridge down the shaft, sucking orally.  

"Haa~, feels amazing. You're skilled, Mio. Thanks to you, I'm staying hard."  
Yuu-sama spoke as if overwhelmed. *Am I... skilled? Or just following desires... no—this is for Yuu-sama.*  

"Hey Mio, I have a request."  
"Fwah?"  
Releasing Lord Dick, I looked up. *For Yuu-sama, anything.*  

"Next... could you give me a titty fuck?"  

---

### Author's Afterword

(Note) In this world, marriageable age is 16+ for both genders, so adult media restrictions are lowered to R16 equivalent.

2019/2/24 Correction:  
婦長 → 看護師長 (to match "nurse" terminology)

### Chapter Translation Notes
- Translated "チンさま" as "Lord Dick" to preserve the honorific and manga reference context
- Rendered "聖液" as "holy fluid" during Mio's erotic fantasy sequences to maintain the manga allusion
- Preserved Japanese honorifics (-san, -sama) per translation rules
- Translated explicit anatomical/sexual terms directly (e.g., "精液"→"semen", "射精"→"ejaculation")
- Transliterated sound effects (e.g., "ほわわわわ"→"Howawawawa", "びっくりした"→"surprised me")
- Maintained original name order for Japanese characters (Hirose Yuu, Takano Mio)
- Italicized internal monologues reflecting Mio's thoughts and emotional state