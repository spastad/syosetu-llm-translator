## 9. Spring Break ⑥ ~Aphrodisiac from the Lips~

### Author's Preface

Thank you for the amazing high ratings, numerous accesses and bookmarks!

To show my appreciation, I'll continue daily posts until the 24th (Monday).

---

Mio didn't seem to understand when Yuu said "paizuri."

After explaining it meant caressing the penis between breasts, she exclaimed, "Ah! You mean *paizeme*!" as if it clicked.

Apparently, it's a niche practice in this world.

When Yuu tried to ask for details, she dodged the question.

  

Whether called paizuri or paizeme, the woman must undress to perform it.

When Yuu mentioned this, Mio hesitated briefly before finally nodding.

"P-please don't laugh at me..."

What would he laugh at?

Yuu tilted his head, wondering if aesthetic standards for women differed in this world too.

"Since I was little... I've been teased for having big breasts..."

"Huh?"

Unlike Yuu's original world where adult media for men was scarce and sexual preferences weren't openly displayed, large breasts didn't seem to be a status symbol among women here.

"Laugh? I'm dying to see how you look undressed. Please show me."

When Yuu said this to dispel her anxiety, Mio looked surprised before nodding hesitantly.

  

In Yuu's world, nurses wore not only white uniforms but also pink and light blue, with pants being more common than skirts.

But Mio before him wore the classic white one-piece style.

The neckline had rounded collars with front buttons.

The pockets on her chest and sides were likely for work tools like writing utensils. Indeed, a three-color ballpoint pen was tucked in Mio's chest pocket.

  

The advantage of one-piece uniforms: undressing reveals underwear in one go.

Though Mio wore a thin camisole as an inner layer, her pink bra was visible through it.

The underwire full-cup bra supporting her large breasts had floral lace, looking adorable.

When Yuu complimented this, Mio showed a happy expression.

That aspect seemed universally pleasing to girls, regardless of worlds.

  

"Huh? What's wrong?"

Mio showed no shame about being in her bra above the waist, but her one-piece uniform remained lowered to her hips.

Perhaps exposing her panties was too embarrassing.

"C-can I just... take off the bra?"

  

Yuu hesitated.

Since entering this room, Mio had been obedient.

He could probably force her to strip completely or even escalate to sex.

But this was originally a semen collection room.

Requesting paizuri was pure selfishness because Yuu's erection wouldn't subside.

Maybe he shouldn't push her too hard.

  

"Sure. Then, could you remove your bra?"

Relief washed over Mio's face at Yuu's words as she reached behind to unhook her bra.

For her, showing Yuu her panties wouldn't normally be an issue.

No—she'd even want him to see, under normal circumstances.

But right now, her love juices were overflowing from her crotch and running down her thighs like she'd wet herself—that was too embarrassing to show.

It was the typical virginal shame of not wanting to be seen as a slut who gets aroused easily by men.

  

The moment the hook came undone before Yuu's eyes, the shoulder straps loosened, and the restrained breasts surged forward.

Simultaneously, the underwire supporting her breasts from below released, causing a dramatic bounce. Yuu almost heard a "tayun" sound from the breast movement.

The forward-thrusting breasts didn't sag but pointed straight ahead, with side spillage visible under her arms.

Beautiful bell-shaped breasts.

Yuu wasn't well-versed in women's bust sizes.

The largest he'd seen in this world was probably Martina.

Even if not that extreme, Mio's breasts were impressive. Since her shoulders weren't broad and she seemed petite, he guessed her bust size was late 80s to early 90s, with an F or even G cup.

  

He examined them closely enough to see veins beneath the white skin.

Compared to their size, small pink nipples sat at the center, seeming to shyly contract.

Without thinking, Yuu leaned forward. As he gazed closely at her breasts, an inner impulse drove him to touch them with both hands.

"Ahhn!"

"Ohh!"

  

Fifteen-year-old Yuu was a virgin with no female experience.

But inside, he was a divorced middle-aged man.

His ex-wife had been a virgin until marriage, timid and passive about sex, remaining completely unresponsive like a dead fish from their first night.

She was also extremely shy, rarely getting wet or aroused.

He'd only dated one woman before marriage, but they broke up before becoming physical.

So he'd lost his virginity to a prostitute.

  

Meaning he lacked experience.

Thus after marrying, he'd begun efforts to sexually please his beloved wife.

First with how-to books. Then gathering knowledge about female bodies through the newly available internet.

Well, it combined hobby and practical benefit.

During nighttime activities, he treated her body like fragile porcelain.

Regrettably, they divorced before those efforts bore fruit in their marital life.

  

Mio's alluring body was the first he'd touched in this new form.

Though wanting to squeeze and knead freely, he gently cupped them with his palms.

The first sensation upon touching her breasts was simply soft.

With slight pressure, his fingers sank into the flesh but met resilient bounce.

She didn't seem pained.

While watching Mio's reactions, he slowly, gently massaged her breasts.

Then lightly brushed a nipple with his fingertip.

"Hyauu!"

Her nipples seemed sensitive too.

He teased them with small circular motions like massaging delicate areas.

  

"Haaah! Ah! Ah! Yu-Yuu-sama... Annn!"

Finally, he supported both breasts with his hands and buried his face between them.

A pleasant pressure against his cheeks.

Strangely, being smothered by breasts gave a faint milky scent.

Yuu raised his head, brought his face close to Mio's, and whispered.

"Amazing breasts. Please do paizuri—or paizeme—with these."

"Ah... amazing... Afuun..."

Mio, looking intoxicated from feeling Yuu's breath on her ear, barely managed to nod.

  

"This might help."

Yuu picked up a plastic container beside the tissues, confirming it contained lotion.

Likely provided to aid masturbation.

Unnecessary for solo use, but useful for reducing friction during paizuri, so he gratefully used it.

  

"Hyah! C-cold!"

"Haha, you'll get used to it."

He spread the lotion dripping from his hand over her cleavage.

Mio fidgeted restlessly, cheeks flushed.

Her twin mounds glistened wetly, looking obscenely lewd.

Soon Yuu urged Mio in a husky voice.

"Okay, please."

  

Yuu sat on the bed as Mio knelt between his spread legs, obediently sandwiching his erect penis between her breasts.

When she pressed her upper arms against her chest, her ample breasts emphasized, transmitting flesh pressure to the buried penis.

"Th-that's it. Now... stroke me with your breasts."

"Yes."

  

Yuu had only received paizuri once before from a prostitute.

He'd gotten a plump woman with huge breasts—though with extra waist fat—who provided the service.

Frankly, he hadn't expected much, but professionals delivered.

He remembered the slippery caress from those ample breasts feeling better than anticipated.

  

Mio's technique was rougher, but her breasts' softness combined with firmness and bounce surpassed the prostitute's.

The lotion helped too.

Unlike handjobs, the sensation of being enveloped in flesh while the entire shaft was stroked felt incredible.

Despite having just ejaculated, transparent fluid leaked from his engorged penis as tingling pleasure spread.

  

"Oooh... this is good. Ahh, amazing..."

Yuu gently stroked Mio's head with his right hand.

Mio narrowed her eyes happily.

"Fuaa... I-I'm glad. That Yuu-sama is pleased.

Um... may I try sucking the tip?"

"Sure. Please do."

"Yes! Nn... *chu*! Lero... *chu*! Npaa, lerolerooo... amu! Chin-sama... *chu*, please feel good... nn... lerochu... release your se... men... hamu, nn, nn, jupa... kurahai ne~"

  

Making lewd wet sounds, Mio enthusiastically performed paizuri-fellatio.

First kissing the glans peeking from her cleavage.

Then sucking it, swirling her tongue, swallowing, and releasing with a *chupon*.

With a dazed expression, she kissed the urethral opening repeatedly.

Trying to lick the transparent fluid with her tongue, but precum kept overflowing, mixing with drool and dripping down, combining with lotion for extra slickness.

Mio kept licking obsessively until the glans was drenched in drool, shining wetly.

  

For Mio, like the earlier handjob, this was her first time giving fellatio or paizuri.

Naturally, she had no technique.

But she continued diligently—first for Yuu, second because she wanted to.

Their desires coinciding meant things progressed smoothly despite both being first-timers.

  

"T-this feels too good... Guh, I won't last long..."

The combined effect of fellatio and paizuri sent tingling pleasure up Yuu's spine from his lower body.

As if aphrodisiac flowed from Mio's lips, rapidly heightening his sensitivity.

He lost the leisure to stroke her head, tilting his chin up and supporting his arched back with both hands.

  

"Nn, hamu... lerolerochupa! Afuun... Chin-sama is wonderful... Aamu, nn, nn, chupo... faa, nmu, delicious!"

Mio kept sucking obsessively, unaware that love juices dripping from her soaked panties were staining the floor.

Sucking a male symbol itself brought her unparalleled sexual excitement.

  

"Kuh! M-Mio! I'm close... Ahh!"

"Nfu! Yuu-sama's face as you feel it... is wonderful too! Aa—mu, jupujupojuruuuuu!"

Mio smiled with crescent eyes and intensified her breast stroking while sucking the glans.

  

"O, ofu! Th-that's good! Oooh! Kaha! C-c-cumming!"

Yuu's jaw jerked up as he stared at the ceiling. Electricity shot through his lower body as stronger pleasure hit.

A sensation like hot magma gushing from his loins.

"Nn, muguuu!?"

Mio's eyes rolled when semen hit her throat, but she didn't remove her mouth.

Instead, she sealed her lips tightly to prevent spillage, gulping down the overflowing semen.

*(Ahh... this is the taste of Yuu-sama's holy fluid... I feel purified from within...)*

Shivering as the hot liquid flowed down her throat, Mio wore a dazed expression.

  

"Haaah~. That was incredible. Wait, huh!?"

Yuu felt like his hips had turned to jelly. Looking at Mio, he saw she still had his penis in her mouth, swallowing with gurgling sounds.

*(No way)*

His wife never gave blowjobs—wouldn't even touch him. His only experience was with pros.

Even then, they'd spit into tissues after oral climax.

Meaning this was his first semen-drinking experience.

  

Though for Mio, this was self-driven desire for Yuu's "holy fluid."

Even after multiple ejaculations, she kept sucking, slurping up the last drops.

"Mio."

Yuu smiled gently and stroked her head.

Mio looked up with glazed eyes.

"Thank you."

Mio nodded happily with clear delight.

After finishing every drop, she released with a *chupon* and beamed.

  

"Yuu-sama's holy fluid was delicious!"

"Hahaha. R-really?"

Watching Mio nod vigorously, Yuu felt overwhelming affection for her.

"Mio!"

"Fweh? Yu-Yuu-sama?"

He slid his arms under her armpits and lifted her, pulling her close.

"Ah!"

He hugged her tightly.

Her glistening breasts squished against Yuu's chest, changing shape.

  

"Yu-Yuu-sama, your clothes will get wet!"

"Doesn't matter. Meeting you today was truly wonderful."

Stroking her head, he whispered by her ear.

Mio shivered at his breath but shed a tear upon hearing his words.

"Th-that's... I'm the lucky one to meet someone like Yuu-sama... I... hic... such an amazing experience... like a dream..."

"Haha, don't exaggerate... Wait, are you crying!?"

Yuu noticed tears trailing down Mio's cheeks.

"Ah, aha... because... in 20 years... this is my first time feeling... so happy..."

Mio smiled through tears.

  

To Yuu, Mio was undoubtedly cute, but the 1:30 gender ratio barrier remained formidable.

Hence, a man initiating was miraculous.

Only a handful of women blessed with looks, talent, and luck got chosen by men.

Conversely, men could pick freely—rejection was nearly unheard of.

  

They hadn't had full intercourse—he hadn't planned to go that far here—but Yuu felt glad Mio was his first sexual partner in this world.

He gazed directly at her.

"Don't cry. Come on, smile. You'll ruin your cute face."

"C-cute? Me?"

"Hyaaa......"

Mio froze with a strange sound as Yuu wiped her tears with his finger.

Then pressed his lips to hers.

She'd just swallowed semen, but a light kiss seemed fine.

"Mufuu..."

"Nn...?"

  

Mio's eyes softened at their second kiss today.

But Yuu looked puzzled.

His waist—or rather knees—felt unusually wet.

Casually, he slid his left hand down Mio's back to her waist.

Eyes closed, Mio dreamily savored Yuu's lips.

His left hand lifted her uniform hem and stroked her buttocks.

Mio's legs were slightly spread on his lap—perfect positioning.

While continuing the kiss and changing angles, Yuu peeked through half-open eyes. Mio's flushed cheeks showed dreamy bliss.

He slipped his hand inside her panties through the waistband gap.

  

"Hweh? Nya, what are you!?"

"Don't mind it. Come on, *chu*."

"Ah... *chu*..."

Since he was only stroking her buttocks, Mio couldn't resist the kiss temptation.

*Chu*, *chu*—he peppered kisses while his left hand gradually descended.

His fingertips moved from her anus straight to her vagina.

  

"Mu?"

"Nnn!?"

"Hoh?"

"Yah!"

  

*(This isn't just "wet"—it's a flood!)*

First, his fingers touched drenched, slimy labia.

Her spread legs allowed easy entry into her pussy.

It felt like a waterlogged mollusk—soaked and soft.

The sanitary pad Mio had worn was swollen with moisture, making her panty crotch sag like a wet diaper.

Only now did Yuu notice.

*(Shit)*

Touching a girl down there during her period was unacceptable.

He immediately withdrew his hand to examine his fingers.

  

*(Phew. Not blood. Then this is...)*

Transparent but sticky, stringy fluid—not watery.

"Yu-Yuu-sama! N-nooo!"

Mio squirmed frantically.

Yuu held her back with his right hand while his left swiftly re-entered her vagina.

Teasing her vaginal opening with his fingertips, he whispered in her ear.

"So wet... Mio's such a naughty girl."

"Hauu! Nnaa...... hah... nfuu"

"Don't shout. It might leak outside."

"B-but..."

Yuu pulled Mio's head against his chest.

  

He hadn't noticed she'd already climaxed slightly.

In this world, it was a cliché line women heard in adult media.

Being told this herself, plus the shock of someone else touching her sensitive spot for the first time, overwhelmed her.

  

"That paizuri felt amazing. Now it's my turn to make you feel good."

Using two fingers, Yuu began fingering her with squelching sounds.

"Feh? Mufu! Moo-moo! Nmuu! Oo, uu, uuun! Ii, nfuuun!"

Mio pressed her mouth against Yuu's parka to muffle moans.

She drooled profusely onto it from pleasure but didn't notice.

  

"Amazing. So wet. When did you get this aroused?"

"Fu-, fu-, fii! Nn, nn, naau! Nfuu!? Hya, hyame! Aa... fiiiiii...... uwaan!"

  

Based on his experience, Yuu assumed pleasuring women required effort, so he thought he was being gentle.

First tracing her labia with his fingertips, spreading them, then teasing her vaginal entrance.

Since she suppressed her voice, he didn't realize she was already near climax.

Likely a virgin, he avoided Mio's vaginal interior, focusing on the entrance before targeting her clitoris.

Her pussy was wide open in welcome, letting his index finger easily locate it.

When he brushed her sensitive clit with feather-light touches, Mio climaxed properly, gushing love juices.

  

"Your clitty's all puffed up. Feels good, Mio?"

Rubbing intensified the clitoral reaction. Blood pooled, making it swell—perfect for pinching and teasing with his fingertips.

"Oo, oo, ofu! Nn, naa! Hyii, iin! Yu-Yuu-sama... nyi, ii, iin!"

  

Yuu's skin scent filled her nostrils, his sweet whispers filled her ears, her nipples rubbed against fabric with every movement. Most of all—his fingers worked her clit and vagina more skillfully than her own.

*(Th-this... every part of my body feels like an erogenous zone... t-too good... ah, cumming again, cumming! Can't stop cumming! I... can't think anymore... oh... Yuu-sama, I feel like I'll ascend to heaven...)*

Repeated waves of intense pleasure blurred dream and reality.

She nearly lost consciousness multiple times, but Yuu's warmth barely anchored her. Clinging tightly, she refused to let go of this tangible thrill.

  

Compared to men, women's sexual pleasure relies more on psychological factors.

They struggle to feel pleasure from unwanted men's touches but soak instantly from beloved partners.

Some enjoy non-consensual arousal or masochism, but they're minorities.

This remained true in this world, though heightened female libido amplified the effect.

  

For Mio, Yuu was love at first sight—his mere presence acted like aphrodisiac, intoxicating her with proximity or touch.

Her rationality already neared danger when he led her inside. Touching his male symbol while hugging made her overflow.

The kiss broke the last restraint.

Mio had been tossed in pleasure's waves for under ten minutes since Yuu touched her privates—a timeless climax hell, or heaven.

  

Meanwhile, Yuu found Mio desperately clinging and muffling moans unbearably endearing.

Her continuous sounds confirmed she felt pleasure, delighting him.

Thus he redoubled efforts to bring her to climax.

  

"Close, Mio?

.........Huh? Mio?"

Noticing Mio had gone silent, Yuu panicked.

Her arms still clung stiffly, but when shaken, her head lolled back.

She'd fainted with rolled-back eyes.

  

  

  

  

  

  

"S-sorry to keep you waiting!"

"Takano? You're late. What were... you...?"

  

Mio regained consciousness after ten minutes of continuous climaxes but couldn't walk with limp legs.

Thus Yuu supported her as they exited after cleanup.

Mio repeatedly apologized but couldn't hide her joy.

  

At the semen test reception, two nurses sat at both counters.

One had just accepted a container from a man.

Yuu addressed the stunned nurse in front—"Bitou" on her nametag.

  

"She helped with the test but collapsed when leaving. Vertigo, maybe?"

"I-I see. Apologies for the trouble."

Bitou bowed to Yuu.

Beyond her, the surly-looking nurse—Eitou, retrieved from the smoking area—stared intently at Yuu.

  

"Well, morning sessions are ending soon with few arrivals. Takano, you may leave."

"S-sorry."

  

It was past 11:30.

Meaning they'd been in the room over forty minutes.

Yuu removed his hand from Mio's shoulder.

Mio gazed at Yuu longingly, clutching the box containing Yuu's semen sample.

  

"Well, thank you for everything."  
"No, thank you for absolutely everything!"

  

Mio bowed nearly 90 degrees before looking up. Yuu waved with a refreshing smile.

"See you."  
"Y-yes."

Mio watched Yuu's retreating back, cheeks pink.

  

"What was that!? Takano, 'helping with the test'...?"  
"Unfair! If I knew such a beauty was coming...!"

With no more men expected, they interrogated her, but Mio remained unshaken.

"Gufu. Gufufufu. Yuu-sama was... A-MA-ZING~. Ehe, ehehehe... I'm so happy..."

She floated in bliss, ignoring them.

  

Morning checkups ended at noon, with afternoon nurses taking over.

Mio remained dreamy through lunch in the staff cafeteria until realizing she hadn't recorded Yuu's contact info.

But even in this era of lax privacy, male information was strictly protected.

If caught secretly copying it, she'd face severe punishment—perhaps a blessing in disguise.  


### Chapter Translation Notes
- Translated "聖液" as "holy fluid" (literal rendering of euphemism for semen) with context reinforcing meaning
- Preserved Japanese honorifics: "祐様" → "Yuu-sama", "チンさま" → "Chin-sama"
- Transliterated sound effects: "たゆん" → "tayun", "ちゅぽん" → "chupon", "ぐちょぐちょ" → "gucho-gucho"
- Used explicit anatomical terms: "ワレメ" → "labia", "クリトリス" → "clitoris", "膣" → "vagina"
- Rendered sexual acts without euphemisms: "パイズリ" → "paizuri", "精飲" → "semen-drinking"
- Maintained Japanese name order: "高野未緒" → "Takano Mio" (no given-name-only instances)
- Italicized internal monologues per style guide
- Translated "媚薬" in chapter title as "Aphrodisiac" for cultural accessibility