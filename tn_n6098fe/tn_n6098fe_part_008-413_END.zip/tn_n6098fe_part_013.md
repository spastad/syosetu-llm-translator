## 10. Spring Break ⑦ ~Swaying Feelings~

April 8 (Sunday). The day of discharge.

Given that the injury was to the head, the initial diagnosis had been over a month for full recovery. However, due to the smooth postoperative progress and Yuu's own wish to make it in time for the high school entrance ceremony, he was discharged today.

Yuu's presence in the top-floor VIP room was known only to limited staff, not even to other patients. Therefore, he couldn't exit through the main entrance. Just like during the health checkup, he had to slip out discreetly through the back entrance under guard vigilance. After finishing lunch around 1 PM, Yuu followed Martina—who had specially taken time off work—through the back door.

A welcoming car was already parked, with Kanako and Touko having opened the rear door. Another person seemed to be in the driver's seat. The black-painted, sturdy-looking body featured a distinctive emblem on the front grille—a thin silver triangle within a circle. It was, surprisingly, a Mercedes-Benz. Not only the male protection officers but even the vehicle had been upgraded.

Martina's red compact car was also parked nearby. Its angular design differed from the rounded styles common in the 21st century, reminding Yuu of 1980s models like the March or Starlet from his memories, evoking a strange nostalgia.

Instead of heading straight to the car, Yuu turned back. Four nurses from the VIP room had come to see him off: the leader in her forties, two in their thirties, and the youngest, Shiho.

"If you feel any abnormality, please contact us immediately. Your body is precious."  
"Even without issues, come visit anytime."  
"We'd welcome Yuu-sama anytime!"  
Not only the head nurse who'd cared for him like a son, but all expressed regret at parting. Shiho was even tearfully speechless.

"Um, I'll be coming for follow-up visits, so I'll be in your care again. Please look after me then."  
Due to the early discharge, Yuu had to undergo weekly checkups. He first took the head nurse's right hand.

"Heh!?"  
The usually composed veteran nurse was flustered by the sudden gesture. Their hands—frequently exposed to alcohol disinfectants and chemicals—were prone to roughness, especially in middle age when skin moisture diminished. Despite the chapped fingertips and joints that remained dry even with hand cream, Yuu didn't mind, clasping them gently.

"My full recovery is thanks to all of you. I'm grateful for your care these past month."

He meant it. Even discounting his status as a rare male in this world, he appreciated their heartfelt nursing. Though some attentiveness bordered on meddlesome—and might have offended local men—Yuu, being a middle-aged man with little female attention in his past life, found it tolerable.

He made eye contact with each nurse while shaking hands slowly.  
"Ah, ahahaha"  
"Well, this is embarrassing..."  
Despite being twice Yuu's age, the nurses blushed like schoolgirls, flustered and bashful.

Finally came Shiho's turn.  
"Shiho-san, thank you for everything."  
"Yu-Yuu-sama. Um, that..."  
With almost no height difference, their faces were close when standing face-to-face. Shiho noticed her heart pounding harder than ever. Having lived earnestly focused on studies and work, Yuu was the first man she'd grown close to, however briefly. Though aware of her beauty, she knew this world wasn't lenient enough for looks alone to secure a partner. By 25, she'd half-resigned herself to being alone. This resignation helped during work, but now facing Yuu's departure, she was overwhelmed by surging emotions and sudden sadness, rendered speechless despite standing before him.

"We'll meet again, right? I want to see you, Shiho-san. I'll be happy if you're there during my checkup."  
"I-I want to see Yuu-sama too! I'll definitely be there on your appointment days!"  
"Great. Promise?"  
"Yes!"

Yuu deliberately opened the car window to wave, prompting the nurses to wave back vigorously. After watching the car drive off, the head nurse murmured:  
"What a good boy."  
"I'd heard young boys were especially difficult..."  
"I thought he was an angel."  
The two thirty-something nurses nodded emphatically. Shiho remained too emotionally overwhelmed to speak.

"Hey, remember that male VIP patient from before?"  
"Ahh! I remember! Some executive's husband, right? Around 50?"  
"He fell down stairs and broke his leg because he was too fat to see his feet."  
"He stayed about two months from last winter, right?"  
"Well, about him—"  
""""He was the worst!""""  
Excluding Shiho, the three had previously handled surgical VIPs.

"Selfish!"  
"Shouted constantly!"  
"Made unreasonable demands!"  
"And so heavy he was hard to move!"  
"Finally demanded 'Send different nursing students daily for bath assistance'! We were appalled! Know what he said? 'I'm giving young women valuable lessons about masculinity—you should be grateful!'"  
"Being male doesn't excuse that!"  
""Exactly!""

In this world, men are treasured like jewels from birth. Unlike girls, few mothers discipline boys properly during upbringing. Most become spoiled "caged sons" to avoid hardship in a female-dominated society. Consequently, most grow up either extremely selfish or terrified of women. Nurses share the common experience that hospitalized men either reject care or make excessive demands beyond what they'd ask at home. With 100% female nurses (despite male doctors existing), it's unavoidable.

"Compared to Yuu-sama, it was like moon and sun."  
""Exactly!""  
"Though much younger, he lacked youthful arrogance—felt like a man with presence."

Simply listening to nurses without complaint already made him exceptional. Some men refused touch or made disgusted faces during necessary procedures, but Yuu never minded. He even chatted cheerfully during care. Admittedly, this made them overdo physical contact.

Shiho recalled accidentally seeing Yuu shirtless post-shower and nearly prostrating in apology—only for him to stop her in surprise. Young men typically would've screamed for guards just for being seen changing. She also remembered impulsively hugging him right after he woke. Remembering these made her lower abdomen throb, having comforted herself in bed multiple times.

"Kajio, you've been quiet—thinking about Yuu-sama?"  
"Huh!? N-no, not at all!?"  
"Fine, fine. I understand completely."  
The head nurse patted her shoulder.  
"A boy that handsome with such good character is rare. Can't blame you for falling. But professionally, we can't develop feelings for patients."  
"Right, really regrettable."  
"I... understand..."

Shiho could only nod. Though selected for the VIP room due to competence, they were strictly forbidden from making advances or using private information personally.

◇ ◆ ◇ ◆ ◇ ◆

"Library!?"  
"Yeah. I want to stop by the library before going home."

Rewind about an hour before Yuu's send-off. While preparing for discharge after lunch, Yuu told his mother Martina this. Hearing it, Martina frowned and shook her head.

"No. It's dangerous. What if women attack you again?"

Yuu wanted to groan—how could a daytime library be dangerous? "But we have reliable male protection officers," he said, glancing at Kanako and Touko. They nodded firmly.

"If visiting the library, we'll request reinforcements from HQ. They'll arrive within 30 minutes."

"But... what if something like the graduation happens..." Martina couldn't hide her anxiety. Understandable—her beloved son had been severely injured by women when out of her sight. Naturally, she never wanted a repeat. Had Yuu been his former self, this trauma might've made him a shut-in. But current Yuu was different. He had compelling reasons for the library visit.

During his three-week recovery, he'd devoured TV, newspapers, and magazines (noting many women's weeklies but no men's) during free time. He'd grasped the current 1:30 gender ratio and how it transformed laws and customs—education, marriage, even mandatory polygamy for men.

He'd also learned about societal shifts: women dominated labor while nearly half of men were "househusbands" supported by multiple women. The rest entered male-focused fields like education, healthcare, welfare, or special industries like arts, entertainment, and sex work.

Though his original world promoted gender equality in the 21st century, Japan was considered male-dominated. Here, it was completely reversed—a female society. One effect was different era names due to successive empresses. The Showa era was Kobun here, affecting everything from Antarctic bases to familiar companies and universities.

However, 1990 technology seemed similar. Meaning the internet and cell phones that revolutionized information access weren't widespread. Hospital computers were likely restricted to work use.

Thus, he wanted to understand how this world came to be. Had it been a sword-and-magic fantasy world, survival would've taken priority. But its similarity to his original world made him curious. Today—before high school—was the perfect chance.

Having lived 40 years including marriage, Yuu knew appealing to emotion often worked better than logic with women—though he'd never had the chance to apply it.

Yuu approached Martina. Taking her right hand, he clasped it between both of his.  
"Huh?"  
"Mom. Thank you for worrying. That makes me really happy."  
"Yu-Yuu-chan..."

Stared at directly, Martina's large light-brown eyes wavered. Such straightforward eye contact and emotional expression hadn't happened in years. Brief confusion quickly turned to bashfulness and undeniable joy.

Yuu drew close like a lover, cheeks nearly touching. Kanako and Touko showed envious surprise behind him, unnoticed.

"I know I'm protected by you and the officers. But for my future, I want to actively learn about this world."

Feeling Yuu's breath on her ear, Martina shuddered—a sensation absent since her husband's death. Not unpleasant; rather, she felt joy at her son's closeness. But reason prevailed.

"I understand using the library. Then have the books delivered."  
"Okay. I'll do that next time. But first I need to see it."  
"Yuu-chan!"  
"Sorry for being selfish. But I really want to go. Please?"

At point-blank range under Yuu's earnest gaze, Martina couldn't refuse. "Fine... just today, really."  
"Thanks, Mom! Love you! *Mwah*"  
Hearing this and receiving a cheek kiss shattered Martina's restraint. "Yuu-chan!!"  
"Oof!"  
She hugged him tightly, covering his cheeks with multiple kisses until love marks multiplied.  
"Ahaha. Embarrassing, Mom."  
With her large breasts pressed against him, Yuu counted prime numbers to prevent a lower-body reaction.

"Hmph..."  
"Staring..."  
Witnessing this unusually affectionate mother-son display, Kanako and Touko could only stare.

---

### Author's Afterword

Minor note: After checking the 1990 calendar, I changed the date from April 7 (Sat) to April 8 (Sun).

Next time, the protagonist finally leaves the hospital and touches upon the origins of this reversed world.

### Chapter Translation Notes
- Translated "アラフォー" as "in her forties" to convey age approximation
- Preserved Japanese honorifics (-sama for Yuu, -san for nurses)
- Translated "がさがさ" as "rough/chapped" for tactile description
- Used "househusbands" for "主夫" to reflect gender-role reversal
- Transliterated sound effects (e.g., "Heh!?" for へっ！？)
- Translated "箱入り息子" as "caged sons" to convey overprotection
- Maintained original name order (Hirose Yuu, Kajio Shiho)