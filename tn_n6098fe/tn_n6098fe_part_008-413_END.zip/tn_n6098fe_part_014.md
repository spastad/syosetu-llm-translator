## 11. Spring Break ⑧ ~Lady Navigation~

### Author's Preface

Christmas Eve? 

It's a holiday so I have the day off, but no plans to go out. Spent half the day cleaning.

The rest of the time I read updated novels and worked on my writing.

  

  

From the latter half to the first part of the next chapter, there will be explanations of history and worldbuilding.

---

The Hirose family lives in Saito City (埼央市), Saitama Prefecture in this world.

No such city name existed in the world where Yuu was a middle-aged man.

Apparently it's a recently established city born from large-scale municipal mergers equivalent to the "Heisei Great Mergers," formed by combining former Higashimatsusaka City with three surrounding towns.

Located almost in the center of Saitama Prefecture, it boasts the second-largest area among the prefecture's municipalities. In this Heisei period, there's no Saitama City of comparable size yet.

Most of the city consists of hilly terrain abundant with nature.

  

In addition to the existing private railway station in former Higashimatsusaka City, Saito Station was newly established immediately after the merger.

With plans announced for another private railway company to extend its line from southern Saitama to connect at Saito Station, the station area is experiencing a construction boom and remarkable development.

The Hirose family's apartment is in the new urban area, just a 5-minute walk from Saito Station.

Incidentally, Saito General Hospital where Yuu was hospitalized was located on a hill away from the new urban area.

That information came secondhand from Martina.

The view from the hospital gave the impression of more abundant nature and closer mountains compared to the apartment in southern Saitama where Yuu previously lived.

  

Even after becoming a new city, public funds aren't lavishly spent, and many of the city's representative public institutions remain in former Higashimatsusaka City.

The municipal library is one of them.

  

Twenty minutes by car after leaving the hospital.

A beige box-shaped building with horizontal lines came into view.

Formerly Higashimatsusaka Municipal Library, now Saito Municipal Library.

The Mercedes-Benz carrying Yuu, Kanako, Touko, and the middle-aged female driver approached the parking lot.

A security guard stood at the entrance, and the gate displayed a "Full" sign.

  

"Tch, it's crowded because it's Sunday," muttered the driver. Yuu in the back seat also noticed the lot was full.

"Eh... We came all this way. What should we do?" Not being a regular library visitor, he hadn't realized that events held on Sundays draw many citizens, filling the parking lot by afternoon.

  

"It's alright, Yuu-sama. Please wait a moment," Kanako said reassuringly from the passenger seat.

Then, opening the window, she beckoned the security guard and spoke just loud enough to be heard: "A male is visiting. There should be priority parking, correct?"

"Yes ma'am! I'll confirm immediately!" The guard hurriedly checked the priority spaces right inside the lot.

Apparently one was available.

Fortunately, there seemed to be enough space even for the large Mercedes, and the driver skillfully backed into the spot.

*(So this is when being male is advantageous.)* Yuu immediately experienced male privilege.

  

After getting out, the tall Kanako took the lead while Touko guarded from behind.

They'd mentioned calling for backup, but they seemed to be keeping watch from a discreet distance - Yuu couldn't tell who they were.

Yuu wore the same white hoodie and jeans from his checkup, with a cap pulled down low.

His hair was long enough to reach his neck, so from a distance he might look like a boyish girl.

However, though hidden behind Kanako from the front, anyone viewing from an angle could tell he was a young male.

Or rather, having two male protection officers in suits made it obvious he was a young male anyway.

  

Upon entering the lobby, women who glanced his way immediately began buzzing.

"Eh? A m-m-male? Seriously!?"  
"No way! And so young and beautiful..."  
"Hey, maybe an incognito idol? Do we know anyone like that?"  
"Haaah~. It's been years since I last saw a young boy in person."

  

Being inside a library, they didn't raise their voices, but their hushed whispers while keeping their distance made it obvious they were gossiping about Yuu.

Many women sent sticky, lingering gazes that seemed to visually violate Yuu from head to toe as he walked straight through the long, wide lobby toward the automatic doors ahead.

  

*(It really is all women!)*

Women, women, women looking at Yuu without restraint.

In the lobby: mothers and daughters looking at bulletin boards, elderly groups in kimonos chatting in circles, students eating and drinking while seated.

Even after entering the main library building, everyone who noticed Yuu simultaneously sent him surprised, heated stares.

Every single one was female. Not a single male in sight.

  

It felt like a teacher transferred to an all-girls school... or rather, more like a top idol suddenly appearing among ordinary people.

Yuu couldn't help feeling like an exhibit. He began regretting coming directly to the library, but having come this far, he tried to maintain a poker face.

Kanako walking ahead with straightened back and dignified demeanor seemed incredibly reliable.

Unnoticed by Yuu, women had been closing in step by step like butterflies drawn to flower nectar or moths to night lights, but Touko's sharp glare kept them in check.

  

Kanako briskly headed straight to the checkout counter without hesitation.

"A male wishes to browse materials. Please arrange this promptly."

"Huh?... Y-yes ma'am!" A woman who seemed to be writing something shot up upon seeing Yuu.

She hurried around the counter and came before Yuu.

  

The woman in her late twenties with gold-rimmed glasses and braided black hair was likely the librarian.

A white blouse, check-patterned vest, and a tight navy skirt reaching her knees gave a pure impression fitting for strict professions like teacher or doctor, contradicted by her prominently protruding twin peaks.

  

*(S-she's the pure type with glasses and huge breasts. I-I can't stand it!)*

In Yuu's original world, she'd undoubtedly be an adult media model.

Seeing Yuu up close, her eyes widened and she froze.

But when Kanako cleared her throat, she seemed to reboot instantly.

  

"U-um, do you have a library card?"  
"Library card? No, I don't think so..."  
He had no memory of making one.  
"Should I make one first?"  
"Y-yes... It's required by policy. Anyone living in the city or commuting here for school/work can get one. It won't take long, shall I make one now?"  
"Yes, please."

His simple smile and slight bow made her mutter "Foh... so precious" strangely.

She likely intended it as a whisper, but Yuu's ears caught it clearly.

Finding her unexpectedly airheaded increased his favorable impression.

  

  

  

  

"Th-then, this way please."

After receiving the newly made library card, Yuu followed the librarian upstairs to the second floor.

While climbing, he discreetly observed her large buttocks ahead.

The second floor appeared to be a spacious reading room with closed stacks.

Study tables seating four were lined up, mostly occupied by students concentrating on their work.

The moment Yuu appeared, they turned in unison, eyes widening as they whispered "Male!" repeatedly - same as downstairs.

Yuu pretended not to notice as he passed through.  
Being this noticed was genuinely embarrassing.  
The librarian opened a door to a room in the corner.

  

"This is the male reading room. Protection personnel may also enter."

Inside was a conference room-sized space with a long table seating about eight people.

Piped chairs along the wall seemed meant for male protection officers.

But no one was there.

  

"Um, private room?"  
"Yes. It's prepared but rarely used.  
Elderly gentlemen occasionally use it, but they usually come on weekday mornings when it's empty." The librarian smiled gently.

Yuu found her kind smile appealing.  
She looked over 10 years older, but mentally he was much older.  
If not for all the attention, he'd want to visit just to see her.

  

"Um, what materials would you like to view today?"  
"Well, I'd like to learn about world and Japanese history. Time is limited, so I don't need detailed knowledge. Something digestible, like a general history book would be best."  
What Yuu wanted to know was whether this world differed from his from the beginning, or if some specific event caused the divergence.  
"Understood. I'll bring them shortly, please wait a moment."

  

The librarian left, returning in just about 5 minutes.

Through the open door, Yuu saw several student-like girls trying to peek inside, stopped by staff.

The librarian seemed slightly out of breath - she must have hurried.

She'd brought four thick books. They must have been heavy.  
Yuu stood to help carry them.

  

"Ah, let me help."  
"No, you shouldn't... Ah!"  
As she'd been holding them pressed against her chest, when taking the inner books, his hand brushed against something soft.

He'd actually aimed for it. Wondering how she'd react.  
But she reacted more sensitively when Yuu's left hand touched her right hand supporting the books from below.

  

"Hyah!"  
"Careful!"

Flustered, the librarian lost balance with the stacked books. Without hesitation, Yuu moved closer.

His right hand held the book corner while the back of his hand pressed into her ample breast, gripping her overlapping hand.

Their chests and stomachs sandwiched the four books, bringing their faces close enough to feel each other's breath.

Unaccustomed to male proximity, her vivid pink-rouged lips trembled.

  

"S-sorry!"  
"No, my fault. I tried to take them forcibly."  
"Hah... that's..."

In his original world, this would be clear sexual harassment, but the librarian apologized as if she'd done wrong.

Yuu lightly shook his head, saying he shared blame to soothe her.  
That alone seemed to captivate her, her gaze growing passionate.  
A calm part of Yuu thought *How easy*.

  

"Let's take two each to the table?"  
"Y-yes."

Her face still bright red, the librarian wore an expression regretting their separation but followed Yuu in placing books on the table.  
"I-if y-you n-need anything else... p-please call me."  
She seemed to stumble over her rushed words.

Yuu felt strangely tender and smiled gently.  
"Yes. If I want to read more, I'll ask."

The librarian bowed repeatedly before leaving.

  

"Lucky pervert. Jealous," Touko murmured softly behind him, but Yuu was already opening books and didn't hear.

  

She'd brought two books each on Japanese and world history.  
One type was large-format guides with abundant color photos and illustrations.  
The other was detailed historical reference books like high school textbooks, including chronological tables at the end.  
Yuu felt renewed gratitude that she'd prepared both types for his vague request.

  

"Not sure how long this will take, but I'll read for a while.  
Sorry, but could you wait?"  
"Don't worry. This is our job.  
We'll eliminate any troublemakers disturbing Yuu-sama, so please read without concern." Kanako puffed out her impressive chest.

Briefly, Yuu almost developed impure thoughts about comparing her size with the librarian's firsthand, but refocused on the books.

  

  

  

  

◇ ◆ ◇ ◆ ◇ ◆

  

  

  

  

Both world and Japanese history matched Yuu's original world until the medieval period.

Historical figures - royalty, nobility, cultural icons - matched the names he remembered.

The divergence point came during the 15th century Age of Exploration.

A Portuguese expedition returning from exploring Africa's interior brought back an unknown infectious disease.

With a long incubation period and airborne transmission, it rapidly swept through Europe, North Africa's coast, and the Middle East.

A terrifying disease causing high fever and red spots covering the face and body, killing victims in about a week.

  

Strangely, only males contracted it, not females.

Once infected, half of all male victims died, with particularly high mortality among teens to thirties.

Deaths didn't reach one million in the decade after Europe's outbreak, but young males dropping like flies caused panic from royalty to commoners.

For nobility, losing heirs threatened family lines. For commoners, losing primary workers was devastating.

Survivors who fathered children produced only daughters.  
Later research revealed the pathogen targeted testicles, affecting genes.

  

Named Red Death Disease (or Male Death Disease) after the Black Death (plague) that ravaged 14th century Europe, intermittent outbreaks continued until late 19th century treatments drastically reduced mortality, though complete eradication remained elusive by the 20th century.

Beyond direct deaths, the disease's aftermath forced global transformation post-16th century.

By late 16th century, queens and empresses leading nations and noblewomen becoming heirs became standard.

  

Historically, this era saw endemic diseases like syphilis spread across continents, dragging Japan into colonial expansion currents.

Until Tokugawa Ieyasu destroyed the Toyotomi clan after the Azuchi-Momoyama period, history remained largely unchanged. But foreigner influx (especially missionaries) caused massive Red Death outbreaks in Japan.

With males collapsing en masse, the newly established Tokugawa shogunate leadership struggled.

Learning the same disease plagued Portuguese/Malay bases like Goa and Malacca, the shogunate implemented sakoku (isolation policy) - about 10 years earlier than Yuu's history.

But too late. Outbreaks continued in Japan, and from the fourth shogun Tokugawa Ietsuna onward, women ruled the shogunate using male names.

  

Examining early modern/modern world history, a key difference from actual history was males being included among colonial resources.

With reduced male populations causing severe population decline, European nations forcibly captured males from unaffected regions for domestic distribution.

  

The mid-18th century Industrial Revolution also stemmed partly from women replacing male laborers. Pregnancy/childcare periods and physical limitations drove technological advances for efficiency.

Fierce competition among powers for males culminated in early 20th century world war.

Photos showed women as military mainstays by then, with males assigned only to safe rear duties.

But technological advances birthed machine guns, aircraft, landmines, tanks - weapons enabling mass slaughter. Horrified by mounting deaths, leaders made peace after three years.

The League of Nations formed centered on victorious powers.

Five years post-war, a feud between two princesses over one nobleman escalated from royal conflict to national confrontation.

Attempted mediation nearly triggered another war involving multiple nations, but the man fleeing to America left it unresolved.

  

Thus, unlike Yuu's history, only one World War occurred, though conflicts over clashing interests persisted worldwide.

For example, Southeast Asian wars for independence from resource-plundering powers (including males) spread across Asia-Pacific, lasting from 1940s-1960s.

After the Rissei Restoration (equivalent to Meiji Restoration) and Chinese campaigns, Japan joined the powers. Rather than fighting directly, it maintained neutrality while supporting Asian nations through machinery/weapons exports and volunteer corps dispatch.

Though joining the powers, resource-poor Japan (late to colonization) maneuvered more skillfully than its history's doomed "hundred million as one" path. While earning European nicknames like "Wicked Jap," it maintained Asian alliances and prospered.

  

Meanwhile, China remained divided into four nations after prolonged civil wars.

Diplomatically, Japan maintained strong alliance with the Republic of China (Nanjing Nationalist Government) ruling southeast mainland and Taiwan, having supported it since founding.

Relations with the other three nations alternated between conflict and dialogue without formal ties.

On the Korean peninsula, prolonged civil war over opening borders left relations icy with the government (Great Korean Republic) due to Japan's support for anti-government (pro-opening) forces. No diplomatic relations exist.

Minor skirmishes occur over Japan Sea fishing/mining rights.

Regardless, Japan's diplomacy maintains delicate balance without escalating to conflict.

  

  

  

  

---

### Author's Afterword

Compared to our world, the population ratio is about 70-80%.

Though only one large-scale war occurred, conflicts (mainly over males) happened frequently.

Note: The Red Death Disease is modeled after the "red-faced smallpox" from the gender-reversed historical manga *Ōoku*.

  

2019/6/16

Revised the final East Asia situation.

### Chapter Translation Notes
- Translated "LADY NAVIGATION" as "Lady Navigation" maintaining thematic consistency
- Preserved Japanese honorifics (-sama for Yuu, -san implied)
- Maintained Japanese name order (Hirose Yuu, Kitamura Kanako)
- Transliterated sound effects (e.g., "Tch" for ちっ, "Hyah!" for ひゃっ)
- Translated explicit anatomical terms directly ("testicles", "breasts")
- Rendered sexual descriptions without euphemisms ("visually violate")
- Used fixed terms: "Red Death Disease" for 赤死病, "Rissei Restoration" for 立成維新
- Italicized internal monologues consistently
- Applied dialogue formatting rules (new paragraphs for speakers)