## 12. Spring Break ⑨ ~Glass Boy~

For men who relinquished society's leading role to women and became an extreme minority, the early modern period was a history of hardship.

In European upper classes, young men were reportedly managed collectively as stud horses to maintain pure bloodlines.

Furthermore, in Christian (especially Catholic) countries, churches centrally managed boys in facilities called Male Protection Facilities from infancy to protect them from Red Death Disease. At age 15, they'd be dispatched in small groups to all-female villages for semen provision. 

However, this practice declined due to public backlash against nuns monopolizing men and tragedies where entire facilities were wiped out by Red Death infections. Eventually, men were brought from colonies and exploited until their bodies broke down.

Ironically, this accelerated racial mixing, making racial discrimination less severe than in Yuu's original world.

Regardless, by the 20th century, male protection ideology spread alongside human rights concepts, transforming society. 

World population here is 70-80% of Yuu's original world. In relatively stable regions, males comprise about 10% of the population. Western Europe—repeatedly ravaged by Red Death—has particularly low rates of 2.0-2.5%.

Japan's population grew during its high-growth period (1950s-late 1960s) fueled by war demand, briefly exceeding 80 million. After the bubble economy burst, it entered gradual decline. 

Japan's male ratio is 3.3%—slightly better than other developed nations, but still a 1:30 gender ratio. The 1978 population was 79 million. Though declining slowly, projections indicated it would drop below 70 million by the 21st century due to falling birth rates.

Alarmed, the ruling party followed European nations implementing drastic reforms and pushed through bold legislation addressing low birthrates, overriding opposition. This included the New Male Protection Law to improve male environments and promote marriage, enacted in April 1980—ten years before Yuu's rebirth.

Since then, young men have enjoyed economic security and near-overprotective protection—provided they marry multiple women and impregnate them. However, their movements are restricted, and the risk of assault by women remains if they let their guard down.

Amid rising male protection ideology, the Male Protection Agency was established as a national institution in 1946 (later integrated into the Ministry of Health, Labour and Welfare). Previously, wealthy families hired private guards, but the state now officially protected males. 

The initial system covered all males aged 7-59 (later expanded to birth-69), with protection officers dispatched by the agency. Early officers were mostly ex-police/military—skilled in combat but prone to fighting attackers rather than protecting. Systemic kidnappings and cases where officers sexually assaulted the males they guarded were exposed by media, revealing institutional negligence.

Consequently, the New Male Protection Law established a new Male Protection Officer system and advanced privatization. The government developed training schools and qualification systems while subsidizing security costs for families with males. Private security companies now handle most protection services.

At least Yuu was reborn after the medieval/early modern "dark age" for males. As a middle-aged man in his past life, he'd occasionally fantasized about reincarnating in his youth—though he'd never believed time travel possible, enjoying it only in fiction.

Though initially shocked when it happened to him, he soon considered leveraging this situation—like time-travel protagonists profiting from future knowledge. Unfortunately, Yuu had no horse/boat racing experience and couldn't recall specific winners. He vaguely remembered baseball teams reaching the Japan Series, but gambling was illegal. Soccer lottery wouldn't start for over a decade. Investing in mobile/IT stocks was possible but required capital he lacked as a high schooler. Moreover, with males drastically reduced and political/economic landscapes altered, his knowledge seemed largely unusable.

Instead, as a rare male—an exceptionally handsome 15-year-old—Yuu realized he could easily manipulate women. This world might be paradise. Joy slowly spread through him. But his 40-year-old self had only dated two women—married once but divorced after being cheated on. His communication skills and initiative were average, mismatching his new appearance. 

*(Well, I'm definitely popular—it'll work out.)* He deliberately chose optimism.

Before he knew it, over an hour had passed in the male reading room. The four volumes the librarian brought were substantial, helping him understand the transformed world since the early modern period. The library visit proved worthwhile.

Yuu called the librarian, thanked her, and expressed his accomplishment—thoughtfully doing so inside the room to avoid other women's eyes while clasping her right hand with both of his. Her flustered, crimson face was endearing.

Finished, they exited through the staff entrance to the parking lot—Kanako had warned against using the main entrance. Kanako led while Touko guarded the rear as they headed to the car.

"Huh? What's that?"

About ten people had gathered around the Mercedes. Recognizing Yuu, they shrieked and surged forward. Initially walking normally, they began competing—one breaking ahead, then another, until finally sprinting recklessly.

"Ugh!"

Teenage girls would've been manageable. Unlike before, Yuu now welcomed female attention. Even if they got carried away, Kanako and Touko would protect him—unlike graduation day. But these were middle-aged women, roughly 40-60 years old. Why must he be surrounded by hags older than his mental age? 

Even from afar, their garish outfits and beer-barrel figures stood out, faces grotesquely caked with thick makeup. Yuu could almost see heat waves rising from them as they closed in on their target. As this monstrous group approached, terror shot up his spine.

These women were actually a notorious stalker group targeting young male idols/actors. Using their "aunty network," they'd track targets, chase obsessively, shout obscenities, and breach security to touch them. Multiple police reports hadn't deterred them. Today, they'd staked out the library adjacent to a cultural center where an actor's sister was performing, hoping he'd appear. Having struck out, they'd apparently heard about Yuu.

*Thud, thud, thud—* their stomping footsteps echoed closer. Their eyes gleamed as they fixed on Yuu.

Kanako stepped forward, extending her baton as her clear voice rang out: "Halt! Advance further and we'll exercise self-defense rights under the New Male Protection Law!"

A few stopped upon hearing her. The decade-old law permitted preemptive action when males faced assault threats—including armed force depending on opponents. But most seemed too excited to hear, eyes only on Yuu.

When the group closed within 20 meters and Kanako raised her baton—

*Pop, pop, pop!* Light popcorn-like cracks sounded from both sides.

"Gyah!"  
"Eek!"  
"Oww!"

For a moment, Yuu thought it was gunfire—but the reports were lighter. The women crouched, clutching faces and limbs. Two broke through, apparently unscathed by the rubber bullets—their excitement peaking as they neared Yuu.

"Eeeeeek! Such a cute booooy! Let me hold yooou!!"  
"Boy! Let me touch your diiiick!!"

The leader was crane-like—tall and gaunt, with disheveled gray-streaked hair. Her fingers sported neon manicure, but the long nails looked like weapons. The second resembled a judoka or wrestler—stout with frizzy perm like a Buddha statue, but bloodshot eyes and a gaping red mouth made her ominous. Both resembled predatory beasts.

*(What are they saying in public?! And what are these monsters?!)* Yuu cursed internally, realizing his legs trembled. Even without their age, being charged by desperate women was a first. His heart pounded uncontrollably—like cracked marbles.

Just then, a black shadow leaped before Yuu. Kanako swung her baton sideways, striking the crane woman mid-stride and sending her flying bent double. 

Spinning instantly, Kanako swept the beer-barrel woman's legs. Grabbing her collar and sleeve as she fell, Kanako executed a hip throw—slamming her hard onto the pavement. She then delivered sharp baton strikes to both women's backs.

"Yowch!"  
"Argh!"

Confirming the two crawled frog-like and immobilized, Kanako turned to Yuu—her sharp expression strikingly handsome. "Go, now's our chance."  
"Ah... yeah."  
"Don't worry—rubber bullets aren't lethal. But they hurt." 

Touko answered Yuu's unspoken question about the other fallen women behind them. Hurrying to the car, Yuu glimpsed swollen red marks on hands and cheeks. Following Kanako's nod, he spotted a gray-suited woman aiming a pistol—signaling *"Leave this to us."* She resembled the staffer guarding the reading room door—clearly backup. Another plainclothes officer stood opposite—a plump woman indistinguishable from civilians. Both had watched discreetly from a distance.

The driver held the rear door open. Yuu slid in, finally breathing easy. Though spectators crowded the entrance, they dispersed as the Mercedes honked. Only when the car accelerated did Yuu relax, noticing his clammy sweat.

"I panicked a bit back there. But thank you for protecting me. Could you thank those two later?"  
"Yes. We'll convey your words—it boosts our motivation."  
"No problem for us. All good."

Suddenly, Yuu felt a gaze from his left. In the backseat, Kanako sat to his right, Touko to his left. "Um—" He noticed Touko fidgeting, opening and closing her hand. "Ah," Yuu understood, taking both women's hands. *So that's it.*  
"...!"  
"Mhm." 

He glimpsed their shy smiles. "I'll keep counting on you both."  
"Y-yes, of course!"  
"Rest easy."  
"Haha."

This world allowed legal harems—ideal for a man with original-world values. But thinking deeper, it wasn't so simple. With a 1:30 gender ratio, not all thirty would be beauties. Young and old alike—including those aunties—competed for one man. Alone, Yuu would've been mobbed and brutalized.

*(Turns out it's not easy mode after all.)*  
Enjoying their hand warmth, Yuu pondered this—still unable to imagine women's true terror since today's incident was thwarted.  


### Chapter Translation Notes
- Translated "硝子の少年" as "Glass Boy" to convey fragility symbolism while maintaining poetic tone
- Preserved sound effect transliterations (e.g., "ポン" → "Pop", "ゴン" → "Gon")
- Rendered internal monologues in italics per style guidelines (e.g., *"Turns out it's not easy mode after all."*)
- Translated explicit anatomical/sexual terms directly ("おチンポ" → "dick")
- Maintained Japanese name order and omitted honorifics where absent in source
- Handled simultaneous dialogue with double quotes per rules when multiple characters speak/react identically
- Translated "男護院" as "Male Protection Facility" matching Fixed Reference terms
- Used gender-neutral "they" for unspecified groups (e.g., backup officers)