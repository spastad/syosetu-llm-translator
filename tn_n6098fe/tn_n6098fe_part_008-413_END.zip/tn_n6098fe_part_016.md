## 13. Spring Break ⑩ ~Frustrating Lips~

*Chin* - the elevator doors opened with a sound.

The 11th floor of a 12-story apartment building. Unit 1102 was Yuu's home.

Though this was his first homecoming since his consciousness transfer, the moment he opened the front door, he felt the sensation of "returning home."

The entrance hall was horizontally wide.

The right-side door was left open, and from the desk and chair arrangement inside, it gave more of an office impression than a living room.

"Well then, please call via intercom if anything comes up."  
"Yeah. Understood. Good work."

After a light bow, Kanako and Touko entered through the right door.

Except during nighttime and heating/cooling seasons, this door remained open, with them handling visitors first.

Yuu retrieved the corresponding key from memory and opened the left door.

This led to the Hirose family's residential area.

Floors 10-12 of this apartment were designed for families with males, featuring dedicated living space for 24/7 male protection officers.

Consequently, the family living area had 3LDK on floors 10-11 (6 rooms) and 4LDK on floor 12 (4 rooms) - relatively few units.

"I'm home."

As Yuu spoke while opening the door, he was startled by the immediate "Welcome home" response.

There stood a woman with her hair pulled back in an apron, bowing.  
"Ah, yes. Um..."

Recalling his memories, her name was Kawamata Akiko.

She'd worked as their housekeeper since last July, handling all household chores for the Hirose family.

According to the personal history Martina showed him, she was 32 with one daughter.

"Um, it's been about a month, huh?"  
"I'm glad to see you've recovered well."  
"Yeah, thanks to you."  
"..."

Akiko remained expressionless even while looking at Yuu.

"Madam informed me she's ordered sushi tonight to celebrate your recovery.  
With no dinner preparations needed, I was cleaning during this free time."

Since Martina worked full-time, they employed a professional housekeeper who handled cleaning daily besides meals and laundry.

Nearly three years had passed since moving here for Yuu's middle school enrollment, yet everything remained spotless.

Akiko was exceptionally skilled and perfect at her job, but contrary to her polite words, she never showed any emotion.

Yuu followed Akiko as she turned toward the living room.

From behind, her height seemed nearly equal to Yuu's - likely around 170cm.

Tall women were common in this world.

Perhaps due to long-established female dominance, gender height differences had nearly vanished or reversed.

To current Yuu, Akiko's features weren't bad despite minimal makeup. But impressions rely heavily on expression.

Always Noh-mask-faced Akiko appeared like a plain middle-aged woman despite being just over 30.

It reminded him of Matsushima ○○ko from that TV show "Housekeeper ○ta."

After entering the living room together, Yuu sat on the sofa while Akiko continued wiping in the kitchen.

Silence persisted except for *kachakacha*, *kyu kyu* sounds from Akiko.

Unable to bear it, Yuu spoke.

"Um, where's my sister?"  
"Elena-sama remains shut in her room as usual, but seems to be eating properly."  
"I-I see..."

When conversation stalled, he glanced at the clock.

Almost 4 PM.

Akiko worked 9 AM to 5 PM, leaving in just over an hour.

Martina had vowed to return by 7 PM today, so Yuu would soon be alone... no, alone with his sister.

His sister had experienced something shocking around Christmas during her third high school year, becoming truant.

Initially Martina tried everything, but Elena stubbornly refused school attendance.

Though permitted to graduate, she'd remained shut-in for three months without pursuing further education or work.

Yuu wanted to talk to her but decided to consult Martina first.

Yuu watched Akiko work diligently.

Suddenly, a memory surfaced.

*(Oh, that thing)*

That sixth-grade night when his mother and sister barged in during his first ejaculation.

The resulting guilt bound Yuu, preventing self-stimulation.

Unlike his original world, boys here seemed to have low libido, rarely obsessing over masturbation.

Young Yuu had wet dreams every three weeks instead.

These created miserable mornings for pubescent Yuu.

Feeling drained, he'd secretly wash underwear while hiding from family and housekeeper.

During second-year middle school autumn perhaps.

On a busy morning, he'd merely wiped his lower abdomen and left soiled underwear in a plastic bag.

Returning home to find them gone, he endured the awkwardness silently.

After several such incidents, the previous housekeeper suddenly said:

"Yuu-sama, have you never masturbated?"  
"Huh? Wh-what are you..."  
"Because your underwear gets so soaked..."  
"Wahhhhh!"

Embarrassed, Yuu tried fleeing but she took his hand.

That pre-Akiko housekeeper was just over 30 - gently maternal in a different way from his mother, someone Yuu found unusually likable.

Thus when she held his hand and stared, he couldn't resist.

"No need for shame. It's common for pubescent boys."  
"R-really?"  
"Yes. Holding it in too long makes semen accumulate until the body expels it naturally."  
"Eh..."  
"So... shall I assist you periodically?"

Having won a male teacher's heart in co-ed high school and becoming his third wife post-graduation, she was unusually knowledgeable about male physiology among women.

Perhaps secure with husband and child, she showed no blatant desire, merely stating facts.

"As-assist how?"  
"But it's not intercourse, so rest assured. Merely managing a physiological process. For Yuu-sama, I'll lend a hand.  
Ah, not literally undress - just an expression. Ufufufu."

Housekeepers dispatched to male households followed something like the Housekeeper Three Principles:

1. Obey male requests in principle (excluding mutually harmful acts)
2. Do not harbor lust toward males or engage in sexual acts
3. Never disclose male presence in assigned household

Since Principle 1 overruled Principle 2, consensual sex was possible.

However, dispatched housekeepers were skilled, childbearing women over 30 who passed rigorous psychological exams, making errors rare.

Still, undisclosed consensual relationships might occur.

Ultimately, Yuu accepted biweekly "processing" (blowjobs).

Each time, she swallowed the abundant semen in her mouth.

She claimed it benefited beauty and health.

For Yuu, it eliminated morning discomfort and underwear disposal issues.

Though guilt lingered, the ejaculation felt tremendously pleasurable.

Male-household housekeepers typically had non-renewable annual contracts.

Likely handed over during transition, Akiko also provided "processing" (blowjobs) if Yuu requested.

Her expressionlessness during felt eerie. Initially clumsy and time-consuming, she'd since mastered efficient ejaculation techniques.

Now, Yuu rose from the sofa, unable to hide his nerves, and awkwardly stepped around the counter into the kitchen.

"Akiko-san."

Akiko seemed to be cleaning the microwave stand, turning silently toward him.

Her emotionless eyes fixed on Yuu as she spoke.  
"How may I assist?"  
"Ah, um..."

Facing her directly weakened his resolve.

With Mio, it was a private room. The semen test required exposing his cock, creating a sexually charged atmosphere despite no intercourse.

Women like nurse Shiho or the librarian, whose attraction was obvious, felt like lower hurdles.

But Akiko maintained infuriatingly blank expressions even when Yuu spoke.

Beneath her apron: a checkered gray sweater and brown slacks - purely functional, unfashionable attire.

Yet Yuu's looks - his current weapon - didn't affect Akiko.

What a formidable opponent.

*(It's fine. She gave me blowjobs pre-hospitalization too. She won't refuse if I ask!)*

He stepped closer.

Stopping about 1 meter away.

"Right after returning but... I'd like... that processing..."

Yuu lowered his gaze to his crotch.

A momentary pause.  
"Understood.  
I'll wash my hands - please wait briefly."

Yuu felt oddly deflated by her easy agreement.

Recalling the routine, Yuu swapped places with hand-washed Akiko, standing back-to-sink with hands on the edge.

Previously done in his room, but since his sister's seclusion, they moved to the kitchen to avoid noise.

Here, distance from Elena's room minimized visibility risks.

"Then, I'll undress you."  
"Yeah."

Kneeling Akiko carefully removed his pants.

A habit from the previous housekeeper, reflecting this world's norm of women undressing men.

She neatly folded the removed pants and underwear.

Then Akiko examined Yuu's still-quiet cock up close.

Pre-hospitalization Yuu rarely watched, but current Yuu had to as the blowjob began.

Her expression seemed to soften momentarily beneath his gaze.

But after a small cough, it reset to blank.  
"I'll touch you now."

Unnecessarily stating actions seemed her custom.

Akiko began handling the exposed cock with both palms like fragile goods.

Her right hand enveloped the shaft, stroking it lengthwise.

Her left hand gently massaged the scrotum.

Warm breath from her open mouth nearby hit him.

The sensitive teenage cock gathered blood instantly.

Gradually hardening, the glans swelled upward.

Her right hand accelerated accordingly, stroking from shaft to tip.

Akiko's freshly washed hands felt cool, but the heating cock experienced indescribable pleasure.

Dead-serious Akiko maintained focus while continuing the handjob.

Her unchanging expression suggested either experience or pure duty.

Within minutes, Yuu's cock stood proudly erect.

Previously covered during wet dreams, Yuu's cock now bore fully exposed pink glans - retracted patiently by the former housekeeper - pointing at Akiko's face.

"Then, I'll lick."  
"Mh... ah."

After a *chu* kiss, her tongue-tip lightly licked the glans' flat surface.

Her unmoving right hand made the minimal stimulation frustrating.

He felt teased slowly. Her wet, parted lips looked sensual.

Just as Yuu craved more stimulation, she suddenly engulfed the entire shaft from corona to base, licking inside.

After releasing, she thoroughly licked every inch downward before kissing the glans with a *chuu* suck.  
"Ugh, kuh!"

Sudden intense pleasure forced a moan.

With glans between lips, Akiko glanced up briefly before resuming silently.

Her left arm wrapped Yuu's waist, pulling them close while her right hand stroked the shaft base.

Now her tongue thickly licked the frenulum.

Facing down, her expression stayed hidden, but Akiko's slightly narrowed cheeks had flushed.

*Chupon* - her lips detached with trailing saliva strands.

Seeing the glans glistening with spit and pre-cum, she reopened wide and sucked it in, tongue writhing.  
"Ah, nkuh! Good! Fe-feels good!"

He couldn't help vocalizing.

Hips gripped, her right hand moved briskly while the wet tongue caressed his sensitive glans through mucosal warmth.

Still silent, her movements targeted weak spots unerringly.

After half a year, her technique was thoroughly polished.

Yuu felt ejaculation building powerfully.

Suddenly, Yuu studied Akiko below.

Her neatly tied black hair shone lustrously; her skin looked unexpectedly fair and smooth.

Minor wrinkles were barely visible; no spots or sagging.

On closer look, she seemed youthfully charming for her 30s.

Unconsciously, Yuu spoke.  
"Hey, Akiko-san, may I touch you?"

Akiko's movements froze with a *pikuri*.

No response.

Assuming non-refusal, Yuu gently stroked her black hair below.

Her tightly bound hair showed no stray strands.

Excessive touching might dishevel it.

After several head-strokes, Yuu's hand moved to her nape.

"...Ngh!"  
"Ah, sorry - dislike it?"

Cock still in mouth, Akiko shook her head slightly.

Then she began bobbing her head while sucking.

Simultaneously, her right hand stroked rapidly with *shaka shaka* sounds.  
"Kuh! Th-that..."

With cock-suction sensations and hand motions, semen surged upward.

Yuu's hand roughened, stroking Akiko's neck before invading her sweater collar.

Fingertips traced shoulder to collarbone, then - just before reaching breasts - electricity shot up Yuu's spine.

"Ooh! Ooooh!"

No time to resist - sensation erupted from his core.  
"I-I'm cumming!"

Back arching reflexively, Yuu's cock ejaculated straight into Akiko's throat.  
"Nguh!"

Akiko choked momentarily but sealed her lips, containing it.

She swallowed the overflowing semen with a *gukyu*.

Repeated *pyuru pyuru* spurts brought hip-dominating pleasure so intense he nearly collapsed.  
"Ah, ah, ah... Came."

Akiko didn't respond but swallowed while savoring, slender throat moving.

Even post-ejaculation, she kept sucking for last drops.

Finishing with *pero pero* glans-cleaning licks, she meticulously wiped moisture away.

Ejaculation-hazed Yuu passively let Akiko redress him.

"Then, excuse me."

As Akiko bowed to leave, Yuu called out.  
"Ah, Akiko-san. Thank you."

Akiko glanced sideways, her prim expression unchanged.  
"No, you're welcome."

*(Haa~. Felt amazing. Could request this weekly - no, more often than biweekly.)*

Her perpetual blankness maintained a "processing" impression.

Regardless, Akiko's technique rivaled professional sex workers.

Approaching his room, he suddenly recalled.  
*(Come to think, Akiko-san always secluded herself in the bathroom afterward.  
Since she swallowed properly, surely not vomiting?)*

Whatever. He lightly shook his head and opened the door.

After scanning his tidy room, he flopped onto the bed.

Shortly after Yuu's door slammed shut, faint sounds leaked from the bathroom.  
"Nn... haa, Yu-Yuu-sama! After so long, Yuu-sama's so kind... nn, fuu... Still... his cock's hard and magnificent! Nna! I... just seeing/smelling it up close already... ah, ann!"

Splashing *kuchu kuchu* accompanied the voice.  
"Touched by Yuu-sama... ah, feeling more than usual... Can't... this is bad... shouldn't... haa, haa, Yuu-sama... nn, nn, nfuuuu..."

---

### Author's Afterword

Uncertain about real 15-year-old boys, but with a 40-year-old man inside, a housekeeper (32) resembling Matsushima ○○ko is well within strike range.

The Spring Break arc ends here - next time we finally enter the high school enrollment arc.

One more update planned this year.

### Chapter Translation Notes
- Translated "はがゆい唇" as "Frustrating Lips" to convey the teasing/impatient sensation during the sexual act
- Preserved Japanese honorifics (-san, -sama) and name order (Hirose Yuu, Kawamata Akiko)
- Transliterated sound effects (e.g., "chin" for チン, "kachakacha" for カチャカチャ)
- Translated explicit terms directly: "cock" for チンポ, "blowjob" for フェラ, "semen" for 精液
- Maintained euphemism "processing" (処理) for blowjob where used contextually
- Rendered internal monologues in italics (e.g., *(This is concerning)*)
- Applied dialogue formatting rules: new paragraphs for unattributed dialogue