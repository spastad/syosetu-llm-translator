## 14. High School Enrollment ① ~And I Am at a Loss~

"Haaah. How did it come to this..."

Yuu slumped over his desk with a sigh.

For the inner Yuu, this was his first high school life in 22 years.

He'd been reborn as an extraordinarily handsome teenager in a world with an extreme male shortage.

He'd imagined a rose-colored campus life where female classmates and seniors would squeal and swarm around him without him lifting a finger. Forming a harem with zero effort seemed guaranteed.

How could he not entertain such thoughts?

That said, his experiences during spring break had taught him reality wasn't as sweet as an eroge protagonist's. In this world, men were protected beings. Even in middle school, classes, classrooms, and extracurriculars strictly segregated genders, leaving virtually no opportunities for interaction. With a 1:30 gender ratio, this was likely necessary to protect the minority males from the overwhelming female majority.

However, the private Sairei Academy High School Yuu enrolled in was Saito City's only co-ed institution. But it wasn't ordinary co-ed - from what Yuu heard, such schools were called "matchmaking schools" here. Gender barriers lowered compared to middle school, actively encouraging male-female relationships during studies. Under the Related Laws for Countering Low Birthrate, men were encouraged to marry by 18. Those remaining single by 25 despite having reproductive capability would have three single women randomly assigned by the state. Thus, most co-ed school males dated multiple girls during school, choosing a partner to marry upon graduation. This included not just one-on-one relationships but potentially one male with multiple females.

In Yuu's Sairei Academy first-year class: 36 males versus 240 females. A 1:7 ratio compared to middle school's 1:30. Compared to all-girls schools, co-ed institutions offered exponentially more male interaction opportunities and marriage prospects. Consequently, reasonably confident girls fiercely competed for admission. With interviews openly evaluating both character and looks, Sairei's female students excelled in appearance and intellect (except for one physical education track class). For males needing to select marriage partners, co-ed schools offered clear advantages too.

So why was Yuu sighing in this privileged environment? Because looking around, every seat - front, back, left, right - and even the teacher at the podium were all male, male, male.

*(This is just like an all-boys school from my original world. You've got to be kidding...)*

True, during the entrance ceremony, he'd drawn attention from the sevenfold female students in the gymnasium without partitions. Yuu had also thoroughly observed his female peers. Additionally, 90% of teachers were women, including young beauties he'd noted. During subsequent student council events and club introductions, he'd seen female seniors too. Sairei Academy's girls were selected for looks, and their uniforms - sailor outfits with lavender bases, white sleeves/collars, and pink ribbons - made them all appear attractive. Yuu wanted to get close immediately, but...

Realistically, suddenly mixing genders after strict segregation since middle school inevitably caused problems. Females were starved for males; males were often fearful of females. Hence separate classrooms/classes, with only monthly gender-mixing events during first year to gradually acclimate them. Free interaction during breaks/after school would be permitted from second year, with some shared classes in third year. Same-year interactions were encouraged, though cross-year relationships apparently occurred through clubs.

Yuu certainly felt grateful for his past self choosing co-ed over Saitama's mere four all-boys schools. But the cost of only skimming Martina's school brochure without proper reading was now apparent.

"Poke poke."

Yuu's left elbow was poked as he slumped despondently over his desk.

"Hm?"

The boy to his left jerked his chin forward as if saying "Look ahead."

"Hirose-kun, please listen properly to sensei."

"Ah, yes. Sorry."

It was morning homeroom. At the podium stood homeroom teacher Kanbayashi-sensei. 25 years old, married. Since second/third-year homeroom teachers and male-class PE teachers were all over 30, he was the sole young male teacher. In a word: the refreshingly handsome type seen in youth dramas. Mild-mannered, he'd explained during self-introductions that a male mentor from his high school days inspired him to teach and guide boys in disadvantaged positions. His personality made him seem more like a kind older brother than a teacher, and he'd quickly gained the male class's favor within days. While Yuu appreciated not having a problematic teacher from day one, he secretly wished for a young, beautiful female teacher. Hiding this thought, Yuu faced forward to listen.

"Today marks the fifth day of high school. Getting used to classes yet? Being co-ed might bring concerns. If anything feels stressful, tell me immediately. I'll be in the next room during breaks."

Kanbayashi-sensei scanned the students as he spoke. They all nodded obediently.

This was the Second Building, somewhat separated from the First Building housing female classes. Though called a building, it was narrow with only three rooms per floor including the male classroom, nicknamed the Isolation Building. A second-floor corridor connected to the First Building, but first-years like Yuu on the third floor used a direct elevator to access the first floor. While teachers could usually be found in the first-floor staff room in the administration building, considering the difficulty of first-year boys going to that female-dominated space, they'd arranged consultations in the adjacent preparation room. Moreover, school buses parked right outside their apartment building for commutes, with parents or Male Protection Officers seeing them off. After school, buses departed from the Second Building. Such overprotectiveness was undeniable. Unsurprisingly, subject teachers were mostly women over 30 - married or with children. Presumably chosen specifically for teaching male classes.

Kanbayashi-sensei continued. "Club visitations start after school today. That said, clubs accepting boys are limited, so I trust none of you will visit athletic clubs."

Students nodded as if saying "Obviously."

In this world, sports were female-dominated. Professional baseball existed, though less popular than in Yuu's world, with audiences and players shifting to softball. No male team sports survived - only amateur individual events persisted. Professional sports required female dominance, another gender reversal Yuu learned from library materials.

Past males attempting professional careers by joining female-dominated sports faced repeated sexual harassment and ended up as sexual playthings for strong female athletes, never succeeding. Gradually, male sports became hobbies, while culture/arts fields allowed talent expression without female competition.

"Hirose-kun, what about clubs?"  
"Hm? Clubs..."

Lunch break. Though the school had a bakery and cafeteria, first-year boys lacking courage to enter those female-dominated spaces ate boxed lunches in class. In this gender-reversed world, women worked while about half the men stayed home. However, post-New Law implementation, households with males received increased allowances, enabling most to hire housekeepers. With housekeepers handling chores and children grown, men gradually entered society, forming new connections with women and spreading their seed. This system - touted as allowing more women access to men beyond minimal wives - gained public approval despite heavier taxes for childless women.

Regardless, all boys in class brought lunches prepared by fathers or housekeepers. Since school started, Akiko had specially delivered Yuu's lunch at 7:30 AM. Though requiring extra overtime pay, her delicious lunches made it worthwhile.

The boy addressing Yuu now was Higashino Rei from the front seat. With shoulder-length black hair, fair skin, androgynous features, and around 160cm height, he could easily pass as a girl. His personality was quiet and reserved. Unintentionally, his occasional sidelong glances carried a seductiveness unsettling for a male. Yuu initially thought *(He'd suit crossdressing)*, but was shocked to learn Rei actually wore girls' clothes until elementary school without resistance.

Most boys here seemed effeminate, lacking Yuu's concept of masculinity - an inevitable result. Male child abduction was a severe problem, with individual and organized crimes making headlines. Pre-adolescent boys were trafficked across borders at exorbitant prices - essentially abducted young to be molded into preferred males. Owning multiple boys to command at will was a shared dream among this world's wealthy women.

Thus, parents of boys couldn't afford reservations. Beyond 24/7 Male Protection Officers, they gave gender-ambiguous names and dressed boys in outright girlish attire to deter targeting. Boys raised this way naturally lacked Yuu's original-world masculinity.

"What about Yamada?"  
"Mm...?"

Stumped for an answer, Yuu redirected the question to Yamada Masaya on his left. In his original world, Yuu came from a single-mother household and worked part-time instead of joining clubs to earn spending money. Thus, no clubs immediately came to mind.

Masaya had neatly parted hair (70:30) and silver-framed glasses, appearing neurotic at first glance. Indeed, Yuu faced constant nagging - but only because he stared at girls during classroom changes and even waved back when they called, recklessly unguarded for this world's males. Essentially, Masaya seemed to nag out of concern, suggesting a decent nature underneath.

After chewing and swallowing his rice, Masaya wiped his mouth and turned to Yuu - another meticulous habit.

"I took piano until middle school. No confidence in becoming a pianist, but I like music, so I'm considering concert band."

"Huh."

Masaya stood about Yuu's height with a slender build. His hands revealed long fingers.

"I hadn't thought about it, but might consider if something looks fun. What about you, Higashino?"

Rei made a troubled face when asked. "U-umm. Well... I'm torn. I've done tea ceremony and flower arrangement since childhood, so continuing in high school might be nice... But it'd be scary with many girls."

"Haaah."  
"With your personality, if senior girls pressure you during club visits, you won't refuse, right?"

Masaya's prediction seemed accurate. Rei did seem easily pressured. As Yuu ate the fried chicken in his lunch - another delicious dish from Akiko - he pondered.

"Then I'll go with you? If it doesn't suit you, I'll politely decline. Maybe we'll find interesting clubs while looking around."

This was his first high school year after 22 years. Rather than being surrounded by boys, club activities offered female interaction opportunities. Helping Rei - who'd become friendly since sitting nearby - killed two birds with one stone.

"Really? Yay! Thank you, Hirose-kun!"

Rei made a modest fist pump toward Yuu, flashing a smile more adorable than any girl's. Yuu inwardly noted how even his gestures seemed girlish.

After school, as Rei headed out, Yuu said he'd use the restroom first and asked him to wait at a bench in the back garden. While exiting the restroom, classmates stopped him for a brief club discussion. Combined with Masaya's earlier inquiry, about half planned to be clubless; the other half intended to visit culture clubs.

"Kept Rei waiting."

His watch showed 15 minutes since leaving the restroom. Exiting the Second Building, Yuu walked through the tree-lined back garden. Having toured campus on day three with his homeroom teacher, he knew the layout. Founded as a girls' school nearly half a century ago, Sairei Academy became co-ed 15 years prior. Expanded grounds housed scattered facilities. Unlike middle school's strict gender zones, co-ed meant seeing both genders everywhere - pink/lavender sailor uniforms for girls, casual wear for boys. Co-ed implementation initially introduced purple-blazer uniforms for boys, but thefts and targeting during commutes led to discontinuation after just two years. Thus, the unusual sight of sailor-clad girls and casually dressed boys.

Unlike the main gate side with its athletic field, the back garden lay enveloped in after-school stillness, faintly carrying concert band practice from the building. Few people were around. Past the back gate stood bicycle parking, a lodging facility, and an archery range. The prefab culture club building should be at the far end. Benches dotted both sides of the garden path, about half occupied by boys and girls - some with a boy sandwiched between two girls. Real-life "flowers in both hands," likely second or third-years.

*(I want that soon too.)*

Hiding his envy, Yuu pressed on.

"Huh?"

He spotted two girls in gym uniforms energetically talking to Rei on a bench. Green-striped sleeveless tops over dark green bloomers. One had short hair; the other a simple ponytail. Both were slender and tall. Gym clothes at this hour suggested athletic club members. Most of all, Yuu's eyes went to their legs - bloomers offered near-underwear levels of exposure, clearly outlining buttock shapes.

*(B-b-bloomers! Amazing! First time seeing them real in 22 years!)*

In middle-aged Yuu's original 21st century, bloomers had been eradicated nationwide, replaced by half-pants. They only survived in adult games and erotica. Seeing them firsthand made his rebirth worthwhile.

"Hey, please! Just five minutes!"  
"Ehh... but I planned to visit culture clubs..."  
"Just a little! It'll be quick! Just sitting there is enough!"  
"E-even if you say that..."

Casually observing the girls' lower bodies, Yuu approached as their conversation reached him. Gym uniforms had grade-based colors: first-years used crimson. Theirs was green, meaning second-years.

"Higashino!"  
"Ah! Hirose-kun!"

Rei's troubled face instantly brightened as if rescued from a predicament.

"Whoa! H-he's hot..."  
"What's with this year's first-years? Insane quality!"

Yuu heard their whispers. Deliberately smiling, he addressed them - both were attractive sporty girls after all.

"Excuse me, senpai. We were about to visit clubs together. May I ask what this is about?"

Facing them, both stood slightly taller than Yuu's 170cm. Their builds suggested athletics. Simultaneously, a question arose: boys didn't join athletic clubs. So why were they requesting this?

"U-um, we're basketball club, practicing in the gym after school. We asked him too, but could you just watch for a bit?"  
"Huh? Why? Athletics are all girls. Boys can't join."  
"Actually," the ponytailed girl continued, "having boys watch during visitation week drastically increases applicants. Ideally, attending games - practice is impossible - would hugely boost morale. So we're running around recruiting, hoping people visit just once."

Yuu understood. Like baseball or soccer clubs in his world getting pumped when girls cheered. Glancing at Rei, he saw anxious uncertainty about how Yuu would handle this.

"Higashino, mind if we spare a moment?"  
"Eh? You're not..."  
"Just curious. I don't play sports but enjoy watching." He couldn't admit wanting to openly watch girls exercise.  
"U-umm... Well, if you choose it, I'll go along." Rei resignedly nodded. After days together with Masaya, he seemed to recognize Yuu as unconventional.

The senpai wore expressions begging not to be rejected. Yuu turned back to them.

"Sure, senpai. We'll visit."  
"Right? Probably not possib- Huh? What'd you say!?"  
"We'll go. But we have plans later, so only 10 minutes."  
"O-ohh... Yes! Yes!"  
"Senior's scolding will- I mean, nothing! Hah! The club will welcome you!"

Their overjoyed reaction was extreme. Hands clasped together, they hopped gleefully as Yuu watched fondly.

---

### Author's Afterword

Protagonists carelessly changing clothes in class drawing female attention, or encountering molesters on trains - staples of chastity reversal stories.

However, this work deliberately restricts such opportunities (though similar situations may occur later).

Consequently, the protagonist must act proactively - a chance conveniently presenting itself this time.

This concludes this year's updates.

Next update scheduled for January 2nd.

Everyone, have a happy new year!

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to preserve cultural specificity of Japanese gym attire
- Maintained Japanese name order (e.g., Higashino Rei) and honorifics (-kun, -sensei) per style rules
- Translated "お見合い校" as "matchmaking school" to convey the institution's relationship-focused purpose
- Rendered internal monologues in italics (e.g., *This is just like an all-boys school...*)
- Preserved sound effect transliterations (e.g., "つんつん" → "poke poke")
- Used explicit anatomical terms ("buttock shapes") where contextually appropriate
- Translated sexual references literally ("sexual playthings") without euphemism