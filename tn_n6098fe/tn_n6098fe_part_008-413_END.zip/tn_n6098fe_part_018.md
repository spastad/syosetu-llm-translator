## 15. High School Enrollment ② ~Intense Gazes~

### Author's Preface

Happy New Year.

I appreciate your continued support for "Reborn in a Chastity Reversal World" this year.

Since I'll likely be drunk tonight, I'll update during daytime.

---

The gymnasium was divided in half, with the basketball club using one side and the volleyball club the other. Naturally, Yuu and Rei were brought to the basketball side by the two second-year girls. Even before entering, the sounds of balls bouncing on the floor and lively girls' voices echoed outside.

"Everyone's gonna be shocked."  
"Right? I wanna see the seniors' surprised faces~"

As they approached the open entrance at the gym's side, the two seniors giggled gleefully.

"Sports clubs seem kinda scary..."  
Rei grabbed the hem of Yuu's jacket from behind him. The gesture seemed girlish to Yuu, making him smile wryly.

"It'll be fine. We're in a co-ed school now, so we should experience everything."  
"Y-you think so?"

Contrary to Rei's unconcealed anxiety, Yuu was filled with anticipation. After all, he'd been specially invited to watch high school girls practicing club activities. Though he'd told Rei they'd stay only 10 minutes, he planned to savor every moment of this rare opportunity. Stepping inside, he entered a space occupied entirely by females. The faintly sweet-and-sour scent of sweat filled the air as Yuu took a deep breath.

*Damu damu damu* went the basketballs bouncing on the floor. Girls in athletic wear ran nimbly around. "Go! Go!" "Pass it!" "She's open!" "Don't dawdle!" Voices crisscrossed energetically in response to the court action. Players passed quickly, and when one caught the ball near the free-throw line and shot, the ball traced a parabola into the high net.

On the court, players wore purple uniforms - the school color - divided into teams by red and yellow bibs for practice matches. Referees and sideline observers wore gym clothes. At a glance, there were over 30 people. Since some members like their guides were out recruiting, the actual number might be higher. Several exceptionally tall white and black girls stood out among them.

*(Quite impressive)*

The effect was heightened by the uniformly tall girls. Though Yuu had rarely watched basketball before, seeing tall girls running fiercely for the ball felt unexpectedly intense.

"Visitors here!"  
"And it's first-year boys!!"

The moment the two seniors announced this, not only the players focused on the game but also the sideline members in gym clothes - and even some sailor-uniformed first-year girls who'd come for club visits - all turned simultaneously toward Yuu and Rei. One player mid-shot froze wide-eyed, mouth agape. The ball she held aloft dropped and rolled off the court.

"No way? Boys? Seriously?"  
"Wha-wha-what?!"  
"And... one's super handsome while the other's super cute!"

A buzzing murmur filled the gym. Unnoticed until now, even volleyball players on the opposite side pressed against the dividing net to stare.

*Clap! Clap!*  
"Hey! Continue the game!"

The first to reboot was a uniformed girl wearing red bib number 4. After clapping to urge her teammates from the sideline, she dashed toward Yuu and Rei. Though she'd sprinted from the opposite end of the court, she wasn't winded at all. Impressive.

"Boys visiting? How unusual. Welcome! I'm Shiina, the third-year captain."  
"I'm first-year Hirose."  
"Um... likewise, H-Higashino."

Captain Shiina stood noticeably taller than Yuu, her hair in a ponytail revealing her forehead. She was clearly over 180cm. With dignified features, broad shoulders, and a sturdy build, she looked every bit the captain. Moreover, without moving his gaze much, Yuu naturally saw her prominent breasts in his field of vision. The basketball uniform consisted of tank tops and shorts. In Yuu's original world, baggy pants reaching below the knees were popular for basketball, but this school seemed to use form-fitting uniforms. Yuu appreciated how clearly they revealed body lines - the captain's excellent figure was obvious. He imagined Kanako, the male protection officer, might have looked like this in high school.

Shiina-senpai explained the basketball club while they observed practice. The two second-years who brought them clearly wanted to stay but yielded to Shiina-senpai's silent pressure and left. Yuu was reminded of sports clubs' strict hierarchies.

According to the explanation, Sairei Academy's basketball team had reached prefectural quarterfinals or semifinals in last year's spring, summer, and fall tournaments. They always got far but couldn't break through to finals. This year, they aimed for their long-cherished goal: qualifying for nationals. The content resembled what Yuu vaguely remembered from the club orientation in the gym earlier, but he listened without comment.

Before he knew it, the practice match had intensified - rapid dribbling, fierce ball contests, and impressive three-point shots. An exceptionally tall black girl executed a magnificent dunk.

"Seriously... They're going all out like it's a real match just because boys are watching."  
The captain looked slightly exasperated.  
"Amazing."  
"Yeah, quite a show."

Though basketball had seemed like a smart sport among ball games, Yuu now saw it could be intense with physical collisions over the ball. When another shot scored and the player jumped for high-fives with teammates, they'd initially seemed overly eager due to Yuu's presence but now played with natural intensity. According to Shiina-senpai, they were holding red-white matches between starters and reserves for the spring tournament. Even reserves could earn starting positions by performing well in these practices, hence their enthusiasm. Yuu found himself engrossed in the dynamic plays unfolding before him.

"Nice. Must feel great when shots go in like that."  
Shiina-senpai caught Yuu's murmur despite the noise, having stayed close while enduring other members' envious stares.

"Want me to teach you? Basketball's fun. Not that boys could join, but I'd love you to experience it. Then... maybe you'd cheer at our games... *ahem* Anyway, since you're here!"  
Seizing the moment, Shiina-senpai pressed eagerly forward. Whether motivated by club interests or personal desire to interact with boys - even first-years - Yuu didn't mind. Watching uniformed high school girls play energetically was enjoyable enough, but joining them was a rare chance. Smiling at the captain who peered at him intently, he replied:

"Alright, just briefly. I'm a complete beginner, so please teach me, Se~n~pa~i!"  
"Oooohhh! I-I've never been called senpai by a boy before... I feel like my life's complete now!"

As the captain jumped for joy exaggeratedly, other members watched dumbfounded. Yuu couldn't take his eyes off her bouncing chest.

"Is this okay? Have you ever played basketball?"  
Rei tugged Yuu's hem worriedly. The practice match would end in three minutes.  
"Hmm? I'll manage somehow."  
He hadn't played since PE classes in his past life and had no intention of competing with active players. "Just felt like moving my body. Sorry - I meant to accompany you for club visits."  
"No, it's fine. We have all next week for visits anyway."  
"I'll go with you tomorrow. Hold this for me?" Yuu handed Rei his black jacket, and Rei reluctantly nodded.

After the practice match ended, they switched to basic drills for first-year visitors including Yuu. Eight female visitors were present, five seeming experienced from middle school. The court split: experienced girls would play light games with seniors in gym clothes. Though that group looked reluctant, the beginner first-years paired with Yuu seemed thrilled, saying "Today's our lucky day!"

"Now, starting with basic dribbling!"  
The seniors teaching Yuu's beginner group wore uniforms, meaning they were first-string players - showing the club's meritocracy. After a senior demonstrated, first-years took turns. Though beginners, the girls had PE experience and seemed athletic. Yuu recalled distant PE memories, dribbling while moving slowly and keeping his eyes forward.

"Wow, pretty good!"  
"Nice rhythm!"  
"Not bad!"  
"Talented and handsome!"  
"Haha, you think?"

While other girls had two instructors, Yuu inexplicably had four including Shiina-senpai, who competed to give feedback while eyeing each other warily. Being praised felt undeniably good.

After dribbling came passing, then free-throw shots. After seniors demonstrated perfect shots, first-years tried. About half the beginner girls scored. When Yuu's turn came, he held the ball firmly with both hands, using his body's spring to push it from his fingertips. His first shot hit the corner of the backboard and missed.

"Aah!"  
"Close!"

Not just seniors but first-year girls - even volleyball players beyond the net - watched Yuu intently.

*(Crap. This is nerve-wracking)*

Since rebirth, he'd faced increasing female attention at the library and entrance ceremony, but intense scrutiny of his every move remained unsettling.

Determined to succeed, he shot again. The ball traced a clean arc, hit the black rim, and shook the net. Cheers instantly filled the gym.

"He did it!"  
"Nice shoooot!"  
"His shooting form is mesmerizing!"

"Nice! Hirose!"  
""Yeeeah!""

Shiina-senpai approached smiling for a high-five. Then seniors and first-years alike rushed over for high-fives, noisily surrounding Yuu. Players on the opposite court watched enviously without hiding their expressions.

"Since you're getting the hang of it, how about splitting for a mini-game?"  
"Sure!"  
"Yah! Let's play the game!"

After alternating passes and shots, a senior proposed. The tall black senior joined enthusiastically with a bright smile.  
"But senpai, we're not at your level."  
"No problem. There are four first-years, right? We'll split them and add three of us. Using half-court, only first-years can shoot."  
"I see."

They divided into two teams of five via rock-paper-scissors.  
"I'm Hiyama Yoko from class 5. Nice to meet you!"  
"Hey. Hirose Yuu. Likewise."  
"*giggle* I know."

The first-year girl on his team greeted him. With short bob hair slightly taller than Yuu, her shy smile was cute. Whether prepared for this or not, first-years had already changed into gym clothes. Her bare legs extending from maroon bloomers were dazzling. Making a same-year acquaintance pleased Yuu.

Yuu's team included Shiina-senpai and the cheerful black senior - clearly strong. The leftover senior referee blew a whistle to start. Since it was half-court, they began from center line. First to 10 points or most points in 10 minutes wins.

Initially, seniors passed while first-years contested near the basket. When Yuu got the ball, opponents eagerly rushed him. He couldn't compete with seniors like he might with fellow first-years. Especially against a blonde, blue-eyed player around 190cm who screened him like a wall.

"Hehe, Come on boy?"  
"Grr."

He tried passing to teammates but they were marked. He'd have to break through himself. Continuing his dribble, Yuu noted the white senior held back - perhaps because he was a first-year boy - but she wasn't easy to pass. A feint almost worked, but she reacted well with long limbs.

"Over here! Pass!"  
"Don't push yourself!"

Teammates called, but Yuu focused on his opponent. A thought struck him: as a beginner in a non-match, he didn't need orthodox methods.

Yuu pressed close from the front.  
"Huh?"  
Stunned more than defending, the white senior froze.  
"Senpai, you're incredibly beautiful! I admire you!"  
"Ah..."

Seizing her pause, Yuu slipped right and passed to Yoko under the basket for an easy score. Returning to position, the senior lightly tapped his shoulder.  
"Don't even joke like that. I might take it seriously."  
Yuu looked back at her intently.  
"It's no joke. I meant every word."  
Too embarrassed to linger, he quickly distanced himself.  
"Oh..."  
The white senior stopped, blue eyes wide, hand over mouth. A faint blush colored her cheeks.

The mini-game became unexpectedly close, tied 8-8. With time running out, the next basket would likely decide it. After his first real exercise since rebirth, Yuu realized: while reflexes and explosiveness seemed good in this body, stamina was problematic. Having barely exercised through middle school, he was panting after just minutes of running. He recalled losing speed quickly even during the short chase after graduation.

*(Gotta train more)*

He wanted to build muscle too - to maximize his new body's specs.

*(One more)*

Receiving a pass near the sideline, Yuu dribbled toward the basket to score himself. But two defenders blocked him near the key. Instinctively, he tried circling right around a gym-clad first-year instead of left. But his tired legs couldn't keep up.

"Whoa!"  
"Eek!"

His foot caught, making him fall onto her. Protecting her head instinctively, Yuu wrapped his left arm around her as they fell.

*Thud!*  
"Are you okay?!"

Everyone rushed over as they collided. Yuu lay atop the girl who'd fallen backward. Since he shielded her head, they looked embraced.

"Sorry. Tripped. You okay?"  
"Wahwahwah... m-my butt hurts... b-but I'm okay!"

As Yuu rose, he naturally offered his right hand.  
"Huh?"  
The girl - twin braids giving a timid impression - stared at his hand, face crimson.  
"Give me your hand. I'll help you up."  
"Ah... okay"

Taking her hesitant hand, Yuu pulled her up. Whether from unsteadiness or momentum, she stumbled toward him, faces drawing close.

"Hyah! Ahh, s-sorry! I mean... thanks!"  
"No, my fault."

Yuu acted from his original world's instinct to avoid injuring girls, but she felt guilty for involving a boy despite her innocence.

"Hmph, jealous."  
"I wanna collide with him too."  
"Hey, play with us next!"  
"The game's not over! Don't say this is the end!"  
Voices came from afar too.  
"Basketball club's cheating! Come here next! We'll teach you hands-on!"  
"Yeah, join volleyball!"

Facing the girl he'd knocked down, Yuu noticed the commotion. More intense stares made him regret his actions. Then a sharp *peeeeeeep!* echoed.

"Hey, what's this gathering?! I heard a boy's visiting."

A woman around 30 in track suit blew a whistle from her chest before calling out sharply. With very short hair, tall stature, and sturdy build, she looked unmistakably like a PE teacher. Behind her, two sailor-uniformed girls entered, eyeing Yuu with keen interest.

---

### Author's Afterword

The author rarely watches basketball and didn't even know that what was thought to be a "shoot" is correctly called a "shot" in the rules. Being an amateur, there might be odd descriptions - please overlook anything besides obvious typos.

※The following are correction notices - skip if preferred.

2019/1/4  
Regarding "shot":  
Wikipedia and online dictionaries state "shoot is the common term, but all are called shots in official rules (Japan Basketball Competition Rules)." I initially followed this but reconsidered after reader feedback. Since "shoot" is more familiar than obscure "shot," I've revised all instances.

Another correction at the end:  
"Yuu lay atop the girl who'd fallen facedown" → "Yuu lay atop the girl who'd fallen backward."

2019/2/16  
Corrected mini-game scores based on reader feedback.

2019/9/7  
Changed Shiina-senpai's bib number from 2 to 4 after learning numbers 1-3 are typically unused.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to preserve cultural specificity of Japanese gym attire
- Preserved Japanese honorifics (-senpai) per style guidelines
- Transliterated sound effects (e.g., "Damu damu damu" for ダムダムダム)
- Maintained original name order (e.g., Hiyama Yoko)
- Translated "ショット" as "shot" initially but revised to "shoot" following author's note about common usage
- Used explicit anatomical terms ("breasts") per translation rules