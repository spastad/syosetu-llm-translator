## 16. High School Enrollment ③ ~Boy Meets Girls~

### Author's Preface

Going out tonight, so updating during the day.

---

Saturday holidays had become well-established in the 21st century, but during Yuu's student days, half-day classes were still held.

Apparently, it's the same in this world. After finishing four classes, while everyone else would normally board the shuttle bus home, Yuu was heading somewhere else.

  

"Hey, are you really okay with this?"

"Going alone seems..."

Yamada Masaya and Higashino Rei, who had become friends with Yuu early on due to sitting nearby, expressed their concern.

"Nah, since it's the student council, I shouldn't need to worry about that."

  

Yesterday after school, while accompanying Rei on club visits, they were invited by second-year seniors to watch the basketball club practice at the gym.

During that, Yuu got carried away and participated in basketball drills, which led to a commotion. The advisor intervened and forcibly ended the session.

Amidst the chaos, Yuu hadn't noticed, but apparently a student council senior had entered right after the advisor. During second period break, through their homeroom teacher, Yuu received an invitation and was now heading there.

  

"Yahoo, Hirose-kun!"

As Yuu stepped out to the entrance with classmates including Masaya and Rei, a female senior called out to him.

Her petite frame, average for girls in his original world, was wrapped in a sailor uniform with pale purple as the base, white sleeves and collar, and a pink ribbon. Her straight flaxen hair was in twin tails, which swung vigorously as she energetically waved at Yuu.

  

"See you next week then."

"Yeah, see you next week."

"Bye-bye, Hirose-kun!"

  

After saying goodbye to the two at the entrance, Yuu approached the senior waiting in the courtyard. "Sorry to keep you waiting."

"Let's go then!"

"Okay."

  

In Yuu's original memories, bleaching or dyeing hair had been the exclusive domain of delinquents or "yankees" until the 1980s. Fashionable hair coloring only became common from the 1990s onward. Since this senior was in the student council, she probably wasn't a delinquent. Her flaxen hair seemed natural, not dyed.

  

"Hmm? Curious about my hair color?"

"Ah, no, not really..."

As they walked through the courtyard, the senior played with her twin tails. "My grandma was British, you know. She said staying on that island full of women in Scotland was pointless, so after high school she ran away from home and went to Southeast Asia right in the middle of their independence war. She met my grandpa, the son of a diplomat in Singapore. They fell madly in love despite parental opposition and got married! I've heard that story so many times. It's like a movie, I totally admire it!"

"Ah, I see. Wow."

  

Her starry-eyed, over-the-top storytelling made Yuu chuckle. In this world, aggressive women fighting to win over men seemed to be the norm. National borders also seemed lower than in Yuu's world, with immigration and international marriages being common—likely due to the drastic reduction in male population. Just yesterday at basketball practice, and throughout his first week, Yuu had seen many female students with distinctly foreign features.

  

The student council room was on the second floor of the dormitory building. As they climbed the stairs, Yuu was troubled by how the senior's skirt hem rose about 10cm above her knees, nearly revealing her underwear. She probably didn't care if boys saw. So Yuu decided to look up boldly. While he could admire her well-proportioned thighs—not too thick, just right—he was disappointed that her panties remained frustratingly out of sight.

  

"We're baaack!"

When the door opened, the first things Yuu saw were a small mobile blackboard and long tables with pipe chairs arranged in a U-shape. Following the senior inside with a "Pardon the intrusion," his eyes landed on someone. She had been looking out the window when they entered. Her stunning, raven-black hair cascaded down to her waist. As she turned, her hair swayed gracefully. Then, in a calm voice, she spoke.

"Welcome back."

Then she turned to Yuu.

"Welcome to the student council. We're glad to have you."

"Ah..."

  

Her straight-cut bangs perfectly aligned above her eyebrows, almond-shaped eyes, straight nose bridge, and lips faintly crimson as if touched by rouge. And her flawless, porcelain skin. She resembled a Japanese-style bisque doll. With the sunlight from the window behind her, she almost seemed to glow with a halo.

  

Yuu had seen her from afar during the school orientation in the gym on his second day. Back then, he'd only thought, "The student council president is pretty." But seeing her up close now, her extraordinary beauty overwhelmed him.

  

A two-year age gap during adolescence felt significant. Even with a 40-year-old mind, Yuu found himself unable to resist the charm radiating from her entire being, staring speechlessly. Perhaps mistaking his tension for shyness, she offered a gentle smile. If this were a manga, flowers would surely be blooming in the background. White flowers would suit her—lilies, dogwoods, or perhaps carnations, Yuu thought vaguely. At the same time, a selfish male thought crossed his mind: a classic black sailor uniform would suit her better than this pale purple one.

  

"I'm Komatsu Sayaka, third-year student council president. Nice to meet you."  
"Ah... yes, nice to meet you... pleased to make your acquaintance."  
"Huh? Has Riko-senpai not returned yet?"  
"Ah, she should be back any moment now."

  

Just as they spoke, rapid footsteps approached from behind—*tatatat*.  
"Oh? Perfect timing?"  
Turning around, Yuu saw a bespectacled girl enter, slightly out of breath. She carried a plastic bag, as if she'd bought something. The president seemed about Yuu's height, while this new senior was slightly taller—perhaps around 170cm. She had a slender build, and silver-framed glasses suited her serious-looking, narrow face. Her slightly wavy hair was tied at the nape and draped over her shoulder.

  

"Standing around talking seems awkward. Why don't we sit and talk while eating?"  
"Yesss! I'm starving!"  
Following the president's suggestion, they took seats. Come to think of it, Yuu felt hungry too. The senior who arrived later pulled sandwiches, pastries, and carton drinks from the bag and arranged them on the table. Since there was a portion for Yuu, he gratefully accepted. The three seniors sat across from Yuu on the other side of the long table. It felt strangely like being interviewed.

  

"I've already introduced myself, so let's start with the vice president."  
Sayaka gestured to the bespectacled senior on her right while neatly holding her sandwich with both hands. The vice president, who had been about to bite into a cream bun, flinched and put it down, looking slightly reluctant as she spoke. Yuu found her expression unexpectedly cute, despite her initially sharp impression.

  

"I'm Hanmura Riko, student council vice president. Third year, same as the president. Pleased to meet you."  
"Yes. Pleased to meet you too."  
This time, Yuu managed to respond calmly.  
"I'm Ishikawa Emi, secretary and treasurer! Second year! Call me Amy!"  
She flashed a peace sign, making her twin tails sway. On closer look, her round eyes gave her a squirrel-like, adorable impression.

  

"Um, I'm Hirose Yuu, first year. Ishikawa-senpai invited me, so I'm visiting today."  
"Good. Thank you for coming. We appreciate it."  
"Fufu, just like the rumors, not only handsome but seems like a good person too."  
"Th-that's... Um, rumors?"

  

Sayaka and Riko let out stifled laughs.  
"Yeah, word's spread that an incredibly handsome first-year enrolled."  
"Everyone says when you meet him up close, he smiles and waves back without ignoring them!"  
"Plus, yesterday at the gym, he came to watch basketball practice and even joined the mini-game—it's the talk of the sports clubs."  
"Ah... that was... I got a bit carried away yesterday."  
Feeling itchy with embarrassment, Yuu attributed it to his teenage body overriding his adult mind.

  

After finishing their snacks amidst the friendly chatter, they faced each other again.  
"So, um, why was I invited today?"  
"Hmm. Right."  
The three exchanged glances, hesitating to speak immediately. Finally, Sayaka, seated in the middle, leaned forward and looked directly at Yuu.  
"Let me be blunt. Hirose-kun. Would you like to join the student council?"  
"Huh?"  
*(C-close!)*

Her eyes, nearly black like her hair, locked onto his. Yuu felt like he might be sucked into those perfectly round, pitch-black pupils.

  

"President, that's too sudden. You've frozen him."  
"Amy-senpai, since he's a boy, maybe he doesn't understand..."  
"Hmm. Perhaps."  
Yuu had no experience with student councils in middle or high school, holding only generic impressions. Moreover, boys in this world rarely participated in extracurriculars, so the concept didn't resonate. 

"Right! My apologies. First, I'd like to explain the student council's overview. Is that alright?"  
"Yes, please."

  

The student council is an organization established to promote student-led activities. For example, submitting student requests to the school administration through general assemblies for adjustments, or coordinating with clubs and groups. For major school events—like the cultural festival or welcoming/graduation periods—organizing committees are formed, but the student council provides full support. Incidentally, the school life orientation on Yuu's second day was a student council-led event.

  

Sayaka's explanation flowed smoothly, as if well-rehearsed and easy to understand. It aligned closely enough with Yuu's image of student councils to aid comprehension.

  

"Does that give you a general idea?"  
"Yeah, I think so."  
"So, um, has it sparked your interest in joining?"

  

Sayaka continued to gaze at Yuu with sparkling, expectant eyes. Being looked at like that by her made Yuu feel a complex mix of embarrassment and happiness—a first since his rebirth into this body. He'd seen plenty of cute and beautiful girls over the past month, all without exception looking at him favorably. While partly due to men being rare in this world, his exceptional looks certainly played a role. But Sayaka treated him normally. Just looking at her made his heart race.

  

"After only a week since enrollment, isn't it too sudden to expect an answer?"  
"Hmm. True. You might be right. My apologies."  
Riko's words made Sayaka nod reluctantly. Sayaka bowed her head slightly, seemingly embarrassed. Riko appeared to be the steady vice president who reined in the occasionally overenthusiastic president—a good team.

  

Yuu took a deep breath, trying to calm himself.  
"I have a few questions."  
"Sure. Ask anything."  
"Okay. First, is the student council just the three of you?"  
"Ah..."

Riko and Emi exchanged awkward glances. Only Sayaka remained composed.  
"The council has five official positions. When we were elected last September, besides me as president, there was Riko and another vice president. Emi has been handling both secretary and treasurer since April, but we had a separate treasurer too.  
...But circumstances led to vacancies."  
"I see."  
Something must have happened. Since he hadn't decided to join, Yuu chose not to pry.

  

"Then, another question. Why invite me, who just enrolled?  
I get the feeling you need male cooperation, but wouldn't second or third-years be more helpful?"  
"Ah, that."  
Sayaka nodded understandingly.  
"Let me explain step by step. The two vacancies are part of it."  
Sayaka took a sip of her café au lait. Seeing this, Yuu, Riko, and Emi finished their drinks.

  

"Since it's co-ed, ideally we'd have boys in the student council.  
Until December, I personally recruited a male classmate to be vice president.  
He was sociable for a boy, academically excellent, and kind to everyone—many girls admired him."  
"And he was handsome too!"  
"Yep, yep."  
Seeing the three smile fondly at the memory of the absent boy, Yuu was surprised to feel a twinge of jealousy. The story continued.

  

"Among those who genuinely fell for him while working closely together was the girl who served as treasurer.  
Things went well until she confessed her feelings at the school-sponsored Christmas party in December.  
But he had many rivals vying for him.  
Some girls might have already been involved with him. That anxiety probably played a role.  
The treasurer came from a fairly prominent family. During winter break, she invited him to her home, created a *fait accompli*, and essentially imprisoned him."  
"Huh?"  
"But such predatory romance rarely ends well. Naturally, the boy's parents protested. It nearly escalated to a lawsuit before her parents, concerned about scandal, backed down. His luxurious confinement lasted only about a week."  
"Whoa."  
"Ultimately, the male vice president transferred to a boys' high school in the third term. The treasurer girl got suspended until the end of the term. Her grades were good, so she wasn't held back, but she quit the council."

  

The tale of a wealthy, possessive—or rather, restraining—girlfriend was terrifying. The fallout hit Sayaka and the current council members hard.

  

"Losing two members suddenly left us in a bind.  
Article 9, Clause 2 of the Student Council Bylaws states: 'In the event of unavoidable vacancies, remaining officers may appoint replacements by consensus.'  
With only half a year left—well, including summer break, effectively under five months—we looked for second or third-year boys willing to join. But getting a positive response was tough. The treasurer's scandal had spread.  
Just as we were struggling, yesterday's incident happened."  
"That was a shock!"

  

Yuu's participation in the mini-game hadn't just drawn the basketball club's attention; neighboring volleyball players and girls from other clubs who heard rumors had flocked to watch, making it far more conspicuous than expected. Hearing this only deepened Yuu's embarrassment.  
"Until middle school, boys and girls are strictly separated.  
Given their age entering puberty, it's a necessary measure to prevent problems. But first-years here are still unaccustomed to interacting with the opposite sex.  
You probably heard we ease them into it gradually through events.  
Considering that, Hirose-kun, your ability to mingle comfortably with girls at this stage is extremely rare."  
"R-really? Hmm, I guess I didn't really think about it."  
Unable to reveal his mind had been swapped, Yuu laughed it off.

  

"As explained earlier, the student council negotiates with various parties—the school administration, clubs, etc. Most are women.  
Therefore, we need boys who can speak normally without intimidation, even to multiple women.  
On that point, Hirose-kun, you've already cleared the first hurdle."

  

Being rare and protected, boys were often intimidated by the overwhelming number of girls. This was obvious even among classmates. While they'd likely adapt over time in co-ed schools, few boys proactively engaged. Though not particularly skilled with women in his past life, Yuu's exceptional looks and the courteous treatment he received now gave him some confidence. Plus, he hadn't lived 40 years and gotten married for nothing—even if it only lasted three years. His ordinary mind was more than compensated for by his extraordinary appearance and environment.

  

Sayaka continued.  
"Changing the subject, I want to discuss our school's sports clubs.  
Partly because we have a physical education track, clubs like baseball, softball, and soccer are strong contenders at the prefectural level."  
Yuu recalled hearing the basketball club reached the best four or eight nationally.

  

"This is common among co-ed schools in the prefecture, but qualifying for nationals is rare. They always fall just short.  
Any idea why?"  
"Huh?"  
Yuu tilted his head. Based on his original world's knowledge, private schools with more funding tended to dominate high school sports. He assumed it was similar here.

  

"Girls' schools target co-ed schools like ours! They come at us full force without thinking of consequences!"  
"They always target our ace players, plus borderline fouls and dangerous plays! It's infuriating to watch!"  
Riko and Emi spoke with palpable frustration.

  

"Girls' schools?"  
"Jealousy over boys being involved.  
Realistically, girls deeply involved in club activities have little interaction with boys.  
Yet they work hard.  
Meanwhile, girls' schools resent co-ed schools simply for having boys.  
And proportionally, girls' schools vastly outnumber co-ed ones. So even if co-ed schools like ours have superior strength, the toll of advancing through rounds puts them at a disadvantage."

  

The resentment over boys ran that deep. In Yuu's world, boys' school students envied co-ed schools, but he'd never heard of that translating to aggression in club matches. This was uniquely this world's issue.

  

"To overcome that, effective coaching and rigorous practice... no, that's not enough.  
Maximizing players' motivation requires cheering, especially from boys.  
Three years ago, a co-ed school in southern prefecture finally mobilized a boys' cheering squad—apparently only a dozen or so—for the softball prefectural finals. They upset the top-seeded girls' school and won the championship.  
Since then, co-ed schools realized the crucial importance of boys cheering at sports club matches—unlike cultural clubs where boys sometimes participate. But achieving it is difficult."  
"For early rounds, maybe. But as you advance, audiences swell to hundreds or thousands of girls. Few boys willingly go there."

  

Flipping the scenario: imagine dozens of girls surrounded by thousands of roaring male spectators at a Koshien qualifier. Staying calm in that heated atmosphere would be impossible. While unheard of among students, professional cheering sections often brawled outside stadiums—understandably, no one wanted to get caught in that.

  

"So, how do we get boys to attend as cheerleaders?"  
"Given yesterday, we thought you might be perfect, Hirose-kun."  
*Well, I'm the exception—regular boys wouldn't go that far,* Yuu almost said. But after only a week, he needed to understand how much distance ordinary boys wanted from girls. Most importantly, seeing Sayaka's sincere expression, Yuu's desire not to disappoint her outweighed everything else.

  

Suddenly, the tension left Sayaka's face, and her lips relaxed into a smile.  
"I might have rushed things. You don't need to answer yet.  
Just talking with you today makes me happy."  
"Me too!"  
"Same here."  
"For me too, hearing about the school was really helpful."

  

It was completely genuine. Just seeing Sayaka's smile made Yuu's heart race—he realized he was attracted to her.

  

Encounters are like treasure hunts in life.  
If so, meeting Sayaka and the others felt like discovering a treasure for Yuu's high school life ahead.

  

---

### Author's Afterword

2020/05/21～7/1

Revised the outcome of the treasurer girl's predatory romance incident.

### Chapter Translation Notes
- Translated "ツインテール" as "twin tails" for hairstyle accuracy
- Preserved Japanese honorifics (-kun, -senpai, -san) per style rules
- Used "flaxen" for "亜麻色" to convey natural hair color nuance
- Translated "濡れ羽色" as "raven-black" for poetic description of hair
- Rendered internal monologue *(ち、近い！)* as *(C-close!)* in italics
- Maintained original name order (e.g., "Komatsu Sayaka" not "Sayaka Komatsu")
- Transliterated sound effect "たたたっと" as "tatatat"
- Translated "ビスクドール" as "bisque doll" for cultural accuracy