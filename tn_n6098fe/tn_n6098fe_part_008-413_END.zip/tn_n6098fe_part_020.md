## 17. High School Enrollment ④ ~Wanting to Know You More~

Monday of the second week after entering high school.

Today marks the start of the first male-female interaction event for first-year students.

It's nothing complicated.

During fourth period, the 36 boys are divided into six groups of six, who then visit the girls' classes to spend about an hour making introductions and conversing.

It's a meet-and-greet style event where each group visits one class per day.

※Since there are seven girls' classes (including PE course), only Group 7 won't meet boys on the first day.

  

Though it's a simple affair, the male classmates couldn't hide their nervousness since morning, gradually losing focus as classes progressed.

Hirose Yuu was probably the only one swelling with anticipation.

  

"H-Hirose-kun, how can you stay so calm?"

"Hirose's just different."

"Hey, that makes it sound like he's some weirdo."

  

During second period break.

As usual, Yuu was talking with Higashino Rei—whose face had turned pale from extreme tension, making him twitch more than usual—and Yamada Masaya, who'd lost his composure and kept wiping his glasses and smoothing shirt wrinkles since earlier.

  

"But seriously, I envy how composed you are."

"You calmly withstand those intense stares from girls. That's impressive."

"Nah, it's nothing special."

""It's definitely not normal!""

  

After such exchanges, when third period ended, they were escorted by teachers toward Building 1.

Even while walking through the hallway, murmurs could already be heard from the girls' classes.

They seemed restless too.

Group 5, which included Yuu and Rei, would visit Class 5 today.

  

The moment the door opened and they entered the classroom, the commotion reached its peak.

""""Wooahh!!""""

""""Aahh!""""

""""S-so handsome!""""

"Everyone, take your seats!"

  

"Who is that guy? He's super hot!"

"I know him! Last week near Building 2, I waved and he waved back!"

"Haaah haaah. The petite one next to him is cute too. Oooh, I wanna pin him down!"

"Lucky us. We hit the jackpot with the first group."

While the homeroom teacher and escort teacher instructed everyone to sit, voices appraising the boys continued to leak out.

  

Unlike the other boys who stiffened like pitiful small animals brought to a predator's den, trembling fearfully, only Yuu wore a relaxed smile as he scanned each face.

*(Hmm. Nice. All cute girls.)*

For once, Yuu felt grateful that appearance was part of the girls' admission criteria.

  

"Ah! Hirose-kun! Do you remember me?"

A slender girl with a short bob raised her hand toward Yuu.

"Hmm... Hiyama-san, right? Oh, and that girl over there?"

He also recognized the girl next to her with braided pigtails and a timid demeanor—the one he'd knocked over during the mini-game at basketball club observation last Friday.

  

"Aaah, I'm Aki! Th-that time..."

"Are you okay? Not hurt?"

"Yeees! I-I'm fine!"

"Haha, glad to hear it."

  

"Heyyy! How come you two already know that gorgeous guy, Yoko and Kazumi?"

"Sneaking ahead is cheating!"

"Same middle school or something?"

  

While other girls pressed them, Aki Kazumi remained flustered and speechless, but Hiyama Yoko puffed out her chest proudly.

"Fufun. What's wrong with that? We just got lucky. Right, Kazumi? Especially you."

"Waah waah waah! Y-yeah, we were lucky! Ahaha...ha......"

Blushing as she recalled being knocked over by Yuu, Kazumi trailed off.

  

They proceeded with formal introductions.

Unlike the male classmates who froze under the collective female gaze, Yuu alone could speak normally.

With so many girls, time would run out if each gave self-introductions, so they kept it to names.

Honestly, with over 30 people, memorizing everyone was impossible.

Yuu made mental notes of only the cutest girls.

  

Next came Q&A time with the boys lined up at the podium.

Common questions included birthday, blood type, ideal type, and future dreams. Each boy's answer was met with girls taking notes as seriously as during exams.

  

The final 15 minutes were free time.

The boys lined up with some distance in front of the blackboard.

Girls then formed lines in front of their targets to exchange brief words.

Nearly half the girls swarmed around Yuu and Rei, but their eagerness created a circle rather than lines.

Yuu didn't mind, but seeing Rei tearful while surrounded by tall girls seemed pitiful, so he grabbed Rei's shoulder and pulled him close.

  

"H-Hirose-kun... Thanks."

"Don't mention it. You'll get used to it once you start talking."

"R-really?"

  

"Ooh! This pairing works! They look perfect together!"

"Guh. Precious."

"Just watching makes me drool... *slurp*"

Unbearable voices leaked from girls watching their whispered exchange.

Could there really be fujoshi in this world too?

  

"Hey hey. Hirose-kun, will you come cheer for basketball club?"

While Yuu stood dumbfounded, Yoko and Kazumi sidled up to him.

"Are you both joining basketball club?"

"That's the plan. Right, Kazumi?"

"U-uh huh. Well... I'd be happy... if Hirose-kun came to cheer..."

  

True to her name, Yoko shone brightly like the sun, contrasting with the shy Kazumi.

Though different types, both ranked among the cutest in class.

Regardless of how it started, Yuu wanted to cherish this connection.

He moved to stand between them.

Several quick-witted girls immediately seized the chance to approach Rei.

*(Sorry!)* Yuu apologized mentally.

  

Addressing not just Yoko and Kazumi but the surrounding girls too:

"Actually, I've been invited to join student council."

"Eh?! Already? Right after starting school?"

"Yeah. The male vice president can't come to school anymore, so they want a replacement. I'm thinking of accepting."

"Amazing!"

"They're considering having male supporters at official matches for sports clubs—especially important games like finals or semifinals. So I'll probably go cheer proactively too, not just suggest ideas."

""""Ooh!""""

Several surrounding girls visibly perked up—likely planning to join sports clubs.

  

"Then! I'll try hard to become a starter even as a beginner!"

"M-me too."

Yoko struck a determined pose while Kazumi clenched her small fist.

"Fufu. Do your best."

Casually extending his right hand, Yuu touched Kazumi's butt.

"......!"

  

With everyone standing and staring at Yuu, he figured it wouldn't be noticed.

For Yuu, this was a gamble.

Definitely sexual harassment, but he predicted his status as a beautiful boy in this world would make it acceptable—even welcome.

He also counted on Kazumi's shyness preventing her from speaking up.

  

Facing forward, he whispered to Kazumi:

"Does it still hurt where you got hit?"

"Hyaa... I-I'm f-fine...nn!"

Lifting her skirt, he rubbed over her panties to confirm the shape before slowly kneading her buttocks.

Given her basketball club plans, she'd probably done sports since middle school. Her firm, taut butt felt pleasantly springy.

Though Kazumi looked down in shy confusion, she soon gazed up at Yuu with heated eyes. Seeing expectation mixed in, Yuu's fingers boldly ventured deeper.

  

"Fwaah!"

"Hm? Kazumi, what's wrong? Your face is redder than before. Fever?"

"N-n-nothing! U-um, I'm just nervous with Hirose-kun so close!"

"Ah, that's understandable."

"Hey hey, don't just talk to them! Talk with me too!"

"Me too!"

As the two girls in front pressed closer, others swarmed near Yuu at point-blank range.

"Hahaha. Sure."

Waaah! Yellow cheers erupted.

  

*(Hmm. Not scary at all. Being surrounded by cute high school girls feels great. This is harem bliss.)*

Smiling amiably, Yuu conversed while scanning each face.

Yoko, persistently keeping her spot at his left, pressed close enough for her breasts to brush his arm.

His right fingertips rubbed Kazumi's panty crotch, already feeling dampness.

Kazumi gasped wordlessly with ragged breaths, desperately clutching Yuu's jacket hem.

  

The chime soon signaled the event's end.

Girls pretended not to hear and kept talking to boys until teachers sternly ordered them back to seats.

Yuu patted each girl's arm or shoulder while saying goodbye.

All wore surprised yet delighted expressions as they reluctantly withdrew.

In his past world, girls who touched freely were often cute, leaving unpopular boys wondering "Does she like me?". Now Yuu felt like one of those girls.

  

  

  

  

  

The next day at Class 6 was another Yuu showcase.

Other boys welcomed Yuu drawing female attention, reducing pressure on them.

Only Rei worried about Yuu—a good guy.

Repeating yesterday's pattern, Yuu targeted several cute girls with bold touching until their eyes turned predatorily lustful. Fortunately, the chime rang before things escalated.

  

After school, Yuu headed to the student council room.

He'd heard council meetings were typically on Tuesdays and Fridays.

Emergency meetings like last Saturday occurred occasionally, but not all members came daily—Emi had part-time work while Riko served as library committee member.

Only Sayaka came almost daily except Saturdays.

  

Knocking and opening the door, he found all council members present.

Their relaxed atmosphere suggested casual chatting rather than a meeting, so Yuu felt relieved.

  

"Oh! Hirose-kun. Glad you came."

Sayaka noticed Yuu first, rising with a welcoming smile that made her long black hair sway.

Seeing her and hearing her voice instantly made Yuu's heart race.

  

"Yay! Hirose-kun!"

"Fufu, seems you enjoyed the interaction event."

Emi cheered innocently while Riko smiled meaningfully.

Rumors about Yuu in girls' classes must have spread already.

"Um, is now a bad time?"

"Nothing important today. We were just chatting, so no problem at all. Did you have questions?"

"Well, sort of."

Yuu looked at each of the three.

  

The endlessly bright, universally likable Emi.

The cool, intellectual beauty Riko.

And above all, Sayaka with her mysterious beauty and dignified radiance.

Council elections were in October—less than five months away excluding summer break—but Yuu thought spending time with these three might be nice.

He'd already started charming classmates during the interaction event.

Pragmatically, the council offered broader interaction opportunities than joining a club.

But the biggest reason was Yuu's attraction to Sayaka.

  

"About your invitation the other day..."

"Eh?!"

Not just Sayaka but Riko and Emi showed surprise and faint anxiety.

They'd likely expected rejection.

  

"Y-you don't need to decide so soon."

"I'm still new and clueless, but I want to help all students—not just boys."

"No, take more time to think caref—huh?"  
"I've decided. President, I accept."

Approaching Sayaka directly, Yuu bowed.

  

Sayaka looked momentarily dazed before Yuu's words registered, blooming into a radiant smile.

"S-so you will?! Hirose-kun! You'll join student council?"

"Yes."

"Yay!"

"Fufu, wonderful."

  

Emi and Riko also smiled brightly.

Yuu suddenly noticed Sayaka holding his hand.

Her silk-smooth hands enveloped his right hand.

"Nothing could make me happier! I know we'll work well together!"

"I look forward to spending time with you and everyone."

Meeting Sayaka's moved gaze, Yuu covered their clasped hands with his left.

  

"President"

"Sayaka seeenpaaai~?"

"Hm?"

"Ah."

Both Yuu and Sayaka flushed crimson and pulled apart.

  

"S-sorry!"

"No, my fault for suddenly grabbing a boy's hand."

"Ah... No, it's fine from you, President."  
"R-really?"

Seeing the usually composed Sayaka flustered struck Yuu as charming.

They took seats at the U-shaped table—Sayaka at the center, Riko as vice president to her left, an empty seat to her right, Emi as secretary at the left corner, and Yuu opposite Emi.

  

"First, what's the nearest upcoming event?"

"Hmm. The April co-ed introduction event is school-led, so next would be the Newcomer Welcome Orienteering after Golden Week."

A mixed-gender event (groups formed by lottery, sometimes all-girl) touring the city by bus and foot.

"Third-years including council members are planning it. It's annual, so not too troublesome."

"Just watch for lottery cheating in group assignments. The event day itself is hectic."  
"At some locations, truant students from other schools target boys, leading to brawls with our security girls—practically tradition."

Yuu found this terrifying despite their casual tone.

  

"Next is June's Sports Festival."

"Sports Festival...?"

Yuu tilted his head, vaguely recalling it from school orientation.

  

"Ah, right. All girls participate, but boys are optional. Realistically, only some third-years join as players or supporters—first and second-years rarely do."

"I see. What a waste."

"A waste?"

"Yes. After April and May interaction events, we shouldn't miss June's bonding opportunity."

"Hmm. That perspective has merit..."

  

Sayaka rested her chin thoughtfully.

Yuu spoke from memories of his high school class competitions decades prior—even non-athletic students got excited for their class.

  

"Full participation might be impossible, but we could assign six boys to each girls' class like this week's event. They could play or support during practice to build familiarity."

"Girls would try harder with boys around."  
"Yeah! It'll hype things up!"

  

Riko and Emi agreed enthusiastically.

"Hmm. Good idea. I was trapped in the assumption boys wouldn't be motivated, but talking with Hirose-kun brings new insights. Thank you."

"Don't mention it."

Yuu felt happy being thanked by Sayaka.

  

Sayaka formally requested Yuu's candid opinions on council-led events as a male member.

Yuu gladly agreed—he wanted active involvement.

And of course, he wanted more time with Sayaka.

  

An hour passed unnoticed, and Emi offered to walk Yuu to Building 2.

Though fine alone, Yuu didn't mind walking with the cheerful girl.

Humming a tune, Emi descended the stairs first, her twin tails swaying.

Pausing on the landing, she turned and flashed a grin.

  

"Hey, Hirose-kun..."

"Yes?"

"Did you fall for Sayaka-senpai?"

"Huh?!"

Stunned, Yuu gaped wordlessly.

  

"Just a girl's intuition~. You talk normally to girls, but with Sayaka-senpai it's different."

He couldn't deny it.

Even as a rare boy unafraid of girls in this world, Sayaka was exceptional.

His experience wasn't enough to hide his feelings.

  

"W-well, that..."

"But bad news! Sayaka-senpai is engaged."

"Eh?!"

"Sayaka-senpai is the heiress of the Komatsu Group. Her parents arranged her engagement in middle school."

"Th-that's..."

Yuu knew a "Komatsu" company famous for forklifts in his old world, but this world's economy differed.

Still, Sayaka's graceful demeanor fit a corporate heiress.

Despite overwhelming female attention since starting school, his first true crush being engaged felt cruelly ironic.

  

Shocked stiff, Yuu faced Emi as she closed in until barely a handspan away.

"U-um, Riko-senpai is the serious type who ignores boys, but I... well, since we finally have co-ed school, I want to get close to boys. But no one in my grade yet... Then you joined the council! I'll say it now... I-I had... love at first sight!"

"Eh?!"

"At least I'm not saying I want to be first! Tenth or twentieth—no, order doesn't matter. So... I want to be one of your girlfriends! Ehehe, I said it!"

  

Sticking out her tongue cutely, Emi blushed.

From their first meeting, Yuu found her petite frame, flaxen twin tails, large round eyes, and frequent laughter charming.

Now she looked even more adorable.

Casually, Yuu wrapped his right arm around her back, resting it lightly on her waist as he pulled her close.

  

"Fweh?!"

"Ishikawa-senpai."

"Call me Emi!"

"Then, Emi-senpai!"

"Ah, yes..."

  

Tentatively placing hands on Yuu's shoulders, Emi gazed up, cheeks flushed.

Yuu brought his face close enough for cheeks to touch.

Their bodies pressed together conveyed her soft breasts' shape, heartbeat, and warmth.

  

Bringing his lips near her adorably bite-sized ear, a citrusy fragrance tickled his nose.

"Emi-senpai is really cute."

"Hauu! H-Hirose-kun! Calling your senpai cute..."

"But cute is cute."

"Auuuuu..."

Her ears reddened too.

As if kissing it, he pressed his mouth to her ear.

"I'd be happy if you became my girlfriend too. Let's be close friends from now on."

"F-fuaaaah..."

Yuu's breath in her ear made Emi's legs weaken. Supporting her collapsing body, Yuu noted how light she felt—his untrained muscles could manage her petite frame.

  

"S-sorry..."

"Don't worry. And Emi-senpai, call me by name too."

"Really?"

"Yes."

"Then... Yu-kun?"

"Yes, Emi-senpai!"

"Ah. Yu-kun... I love you!"

Emi threw her arms around Yuu's back in a tight hug.

  

His first confession since rebirth.

Though Sayaka remained his true interest, Emi's open affection warmed Yuu's chest. Hugging her small frame tightly, he felt a pang of emotion.

  

  

  

  

  

---

### Author's Afterword

We've been away from explicit content for a while, but please wait a little longer as this is the preparation phase leading up to the main event...

### Chapter Translation Notes
- Translated "貴腐人" as "fujoshi" (rotten girls) to convey the Japanese subculture context
- Translated "ギラついた視線" as "intense stares" to maintain explicit tone
- Preserved Japanese honorifics (-kun, -san, -senpai) throughout
- Translated "ボディタッチ" as "touching" and "セクハラ" as "sexual harassment" per explicit terminology rule
- Used "Sports Festival" for "球技大会" as standard school event term
- Transliterated sound effects (e.g., "Fweh?!" for ふぇっ！)
- Maintained Japanese name order (e.g., "Hiyama Yoko")
- Italicized internal monologues per style rules