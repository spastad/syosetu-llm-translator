## 18. High School Enrollment ⑤ ~Just a Little More, Almost There~

### Author's Preface

Before I knew it, Chapter 17 reached 10,000 points!  
My goodness, what a surprise. Thank you! Thank you!  
I was planning to post on Wednesday night, but I'm posting a day early instead.  
Sorry for any typos or errors.

---

"Hirose-kun, are you going to the student council again today?"

After the last class ended on Wednesday, Yuu, who was preparing to leave, was addressed by Rei in the front seat.

"Yeah, that's right."

When Yuu replied, Masaya to his left also spoke up.

"Does the student council meet every day?"

"Not exactly. But since I joined mid-term, it's a good chance to learn about the school. I'm getting taught various things by the seniors."

"Huh, you're really enthusiastic."

"Aren't you scared being surrounded by seniors?"

"Not at all. Precisely because they're kind seniors, I decided to join the student council."

Masaya had apparently decided to join the wind instrument club, while Rei seemed undecided.

"I thought we could go home together..."

"Ugh... sorry about that."

Rei, who lived in the same apartment building, was supposed to take the same shuttle bus. Having just moved in before high school started, Rei seemed happy to know they attended the same school and had been clinging to Yuu since day one. But Yuu hadn't been able to accompany him much even for the club visits he'd promised. Seeing Rei's feminine face make a puppy-dog abandoned expression filled Yuu with guilt despite himself.

"Tuesdays and Fridays have regular meetings, but I think I can go home with you tomorrow?"

"Really? Okay then! See you tomorrow."

"I'm heading to club too. Later."

"See ya, Yamada! Tomorrow!"

After leaving the classroom and saying goodbye at the entrance, Yuu headed straight for the dormitory building. This area had few people even after school. Most were female students heading to the bicycle parking. On scattered benches, he could see couples from second or third year, or groups of two women surrounding a boy, but Yuu strangely found himself not feeling envious at all.

As he climbed the dormitory stairs, he felt his tension rising. He'd heard the president came to the student council room almost every day except Tuesdays and Fridays, but would she really be there? If she wasn't, he'd surely be disappointed. Is she there or not? His heart pounded as he knocked on the door with trembling hands. After a moment, Sayaka's calm voice replied, "It's open," and a natural smile spread across his face.

"Oh? I didn't expect you to come again so soon after yesterday."

"Haha. I thought I'd like to talk if you were here. Is this okay?"

"Absolutely no problem. I'm glad you came."

Even if it was just polite small talk, hearing Sayaka say that with a smile made Yuu happy.

"What were you doing?"

Sayaka had been sitting in her usual seat, looking through a thick file. Taking advantage of the other members' absence, Yuu casually sat down beside her.

"Ah, this. I was rereading the student council activity records since our school became co-ed. I'd looked through it before, but after hearing what you said yesterday, Hirose-kun, I thought I'd review it again from a male perspective."

"Hee~. You're really dedicated."

Most girls entering co-ed schools aimed to meet and bond with boys. Exceptions were those focused on athletics or academics - Riko seemed to fall into the latter category. Seeing Sayaka excel not only academically but also genuinely commit to student council work made Yuu respect her as a senior.

"May I look with you?"

"Ah, sure."

Yuu moved his chair to the closest possible position without touching her. On the page held down by her white-fish-like beautiful fingertips was written: "Seika 3rd Year - Sairei Academy Student Council Activity Report." He still hadn't gotten used to this era name that wasn't Showa or Heisei. If this year was Seika 13, then this was from ten years ago - 1980.

"I believe this was the fifth year since becoming co-ed?"

"Mm. You can see they were still trial-and-erroring various approaches around this time. Seems they faced many problems and hardships."

With the extreme gender imbalance, male-female sensibilities were reversed from Yuu's original world. When few boys shared space with many girls, usually the girls caused problems. Hence, trains, buses, and taxis apparently had male-only cars - though men rarely used public transport anyway. In co-ed schools, they designed a system where boys and girls who'd lived completely separate lives until middle school would gradually get used to each other through interaction events, lowering barriers each year until relationships developed.

While nodding along to Sayaka's explanation interwoven with co-ed history, Yuu subtly observed her. Her silk-smooth black hair hung straight down her back without a single wave. When a slight movement made a strand fall forward over her shoulder, and she naturally brushed it back, he couldn't help but stare. Her skin was porcelain-white, and her vermilion lips were indescribably alluring. Just looking wasn't enough - he felt the urge to touch them.

Suddenly, Sayaka turned toward Yuu.

"What's wrong? Being stared at like that is embarrassing."

"Hah! S-sorry!"

He'd been so captivated by Sayaka that he'd been caught.

Sayaka didn't seem to realize he'd been admiring her, lightly shaking her head before saying "Hmm!" and stretching her clasped hands upward. Yuu averted his gaze but caught a glimpse of her prominently swelling chest and hurriedly looked away. Whether she noticed or not, Sayaka smiled and said:

"Phew. Let's take a break and make some tea."

"Ah, I'll help."

They stood up simultaneously. When the breeze made Sayaka's hair sway, a floral scent tickled Yuu's nostrils. He was momentarily driven by the impulse to hug her right then, but when Sayaka turned her back and stepped forward, he came to his senses and followed her to the water-heating room.

***

After that, they spent time chatting over tea, but not wanting to overstay and disturb her research, Yuu left after about forty minutes. Learning that her parents lived in southern prefecture while she lived alone in a nearby apartment was today's personal gain - though she'd wryly admitted having a live-in maid handled most chores. Buying an apartment outright for his daughter showed how the wealthy operated differently.

Yuu realized he was falling for her more with every word exchanged in her presence. Given Yuu's inner self was a 40-year-old man, she should be 23 years his junior. Yet now, he felt like a regular high school boy with a crush on a beautiful senior. Just recently he'd been flirting with first-year girls, and yesterday Emi had confessed to him. But that was that, and this was this.

Had he been the original Yuu, Komatsu Sayaka would've been an unattainable prize - especially with a fiancé. He'd have given up immediately. Having experienced marriage collapse due to his wife's affair, Yuu used to believe cheaters - male or female - were unforgivable.

Men popular with women often boasted, "Cheating proves manliness" or "Women come to me - I can't reject them." Meanwhile, those who claimed "I'd never cheat" usually struggled to keep even one woman. Since being reborn here, Yuu's ethics had shifted considerably over the past month.

Men were obligated to bond with multiple women. It didn't matter if it happened before adulthood (18) - in fact, it was welcomed. Men became dependents while multiple wives worked - that was the norm. A man's most important duty was spreading his seed to as many women as possible to boost population growth. So what was wrong with dating multiple girls?

Komatsu Sayaka was the first woman Yuu had genuinely been attracted to since coming to this world. He desperately didn't want to give up on these feelings.

***

Friday was student council gathering day.

"Yay! Yuu-kun! Looking cool as ever today!"

"Haha. Emi-senpai is energetic as always. President, vice president, good afternoon."

The moment Yuu entered the student council room, Emi waved energetically and cheerfully called his name, surprising Sayaka and Riko.

"Hee~"

"You two have gotten quite close."

"Ehehe. He gave me permission to use his name before! Yuu-kun is really kind and wonderful!"

Yuu hadn't given Emi a clear answer after her confession. But hugging her on the stair landing had apparently made her extremely happy, putting her in high spirits immediately.

"Ah, I want us to get along well, so I hope you two don't mind?"

"Well, calling a boy by his first name is rather..."

"I'll stick to how I usually address him."

The third-years apparently didn't have the courage to go that far.

The immediate agenda was the Newcomer Welcome Orienteering event coming up in about two weeks, after Golden Week. Since it happened annually, planning was complete. Next Tuesday they'd hold an explanatory meeting for executive committee members from second and third years. Yuu reviewed the plan document, offered some male-perspective suggestions resulting in minor revisions, and that concluded the day.

***

The next day, Saturday after school.

Yuu headed to the student council room without much expectation but thinking she might be there. Though his first invitation had been an exception, he'd heard Sayaka usually didn't come on Saturdays. So without knocking, he tried turning the doorknob just to check if it was locked. Contrary to expectations, the stainless steel knob turned with a mechanical clack, and the door opened.

There sat Sayaka in her usual chair, but sideways, gazing out the window. Her profile seemed somewhat troubled.

"President."

"Hm? Hirose-kun?"

Even after recognizing Yuu, she lacked her usual liveliness. Though her mouth relaxed slightly, her eyes held no energy.

"President, you seem... unwell?"

"Hm... dear me, does it show even to you, Hirose-kun?"

"Did something happen?"

"Hm, well..."

Sayaka didn't answer directly, standing to look outside. Yuu stepped toward her but hesitated at her unapproachable aura, simply watching her worried profile.

After a while, Sayaka murmured softly as if exhaling.

"Boys are difficult."

"Huh?"

"Ah! I mean, not that..."

She seemed flustered, having not meant to say it aloud. It was rare for Sayaka, who never discussed relationships, to say such things. Judging from what Emi had said earlier...

"Could it be about your fiancé?"

"Mm... how did you know?"

"Emi-senpai told me."

"Honestly, she can't keep secrets." Sayaka shook her head as if exasperated. "If you don't mind, I'd like your advice. I may have less life experience than you, but I might be able to help with male relationships."

"I-is that so... yes! Maybe you can. It's a boring story, but I'd like you to hear it."

According to Sayaka, their engagement had been arranged by their mothers when she was thirteen. The boy was from a major corporation partnered with her parents' company. However, he was extremely quiet and seemed unenthusiastic about the engagement since their first meeting. Marriage was set after Sayaka's college graduation, and they only met about once a month. After four years, the distance remained, confusing her. Sayaka took a photo from her wallet to show Yuu.

Likely at some party venue. There stood Sayaka in makeup and a mature purple dress, smiling naturally. Beside her at a slight distance stood a slightly short boy in a tuxedo - handsome enough but with an androgynous face resembling Yuu's friend Rei. They made a well-matched beautiful pair, stirring jealousy in Yuu's heart.

"Last night was my first dinner with him in a month."

"I see..."

"Though I did most of the talking."

"Are you close?"

"Haha. I wish I could say yes... unfortunately, it's hard to say things are going well."

Yuu felt guilty yet relieved seeing Sayaka's weak smile.

"I held his hand when escorting him to the table. He seemed a little surprised but didn't pull away. But when I tried linking arms while leaving... he rejected me."

"Huh? What a waste!"

"Eh?"

"Ah, sorry."

"Fufu. You say amusing things, Hirose-kun."

Yuu thought to himself, *I wasn't trying to be funny; it's just how I honestly feel.*

Sayaka smiled at Yuu but soon looked down. "I know. I'm just an unwanted woman who gets to date a boy thanks to my parents. But he must dislike it. Having to spend time with an arranged fiancé regardless of his feelings."

"Does he have someone else he likes?"

Sayaka seemed taken aback by Yuu's sudden question. "Huh? No, I don't think so. He's probably just uncomfortable with women."

"So you want a more intimate relationship?"

"W-well, I am a healthy 17-year-old girl, so it's not like I'm uninterested in such things."

Yuu pondered. Even in modern times, engagements arranged by families for social connections existed. The heirs probably accepted it pragmatically, but the gender difference seemed more pronounced here than in his world. A passive boy versus an active girl. In his original world, a beauty like Sayaka would have unlimited options, but not here. With a 1:30 ratio, girls had more to gain from finding marriage partners. Conversely, boys might feel forced against their will.

"Realistically... what does your fiancé think of you?"

"Eh... uhm..."

"Please speak frankly."

Sayaka's eyes darted around. She seemed reluctant, but Yuu needed to press.

With a heavy sigh, Sayaka made a bitter expression. "I... don't think he views me favorably. If anything... he might be scared of me."

Sayaka appeared dignified with masculine speech and constant composure - the reliable older-sister type. Yet her occasional flustered moments created an adorable gap. Yuu wanted to see more sides of her. That this world's men only saw her surface and found her frightening made him indignant. Such a captivating woman!

They'd met too late. Moreover, family arrangements seemed stricter than imagined for someone in Sayaka's position - stealing her fiancé's place would be difficult. Being mentally older, he could imagine that much. But even temporarily, he wanted Sayaka all to himself. Without revealing these hidden feelings, could he touch her? Yuu wondered.

"H-Hirose-kun?"

Sayaka looked at the silent Yuu worriedly.

"President."

"Hm?"

Having decided, Yuu stepped forward until he was close enough to touch her. Sayaka watched him with a puzzled expression.

"I think you should learn more about interacting with men. So... why not use me as practice?"  


### Chapter Translation Notes
- Translated "おっさん" as "old man" to convey the self-deprecating tone of Yuu's inner monologue
- Preserved Japanese honorifics (-kun, -senpai, -kaichou) per style rules
- Rendered "フローラルの香り" as "floral scent" for natural English flow
- Translated "子種をばらまき" literally as "spreading his seed" to maintain explicit terminology requirement
- Kept "Golden Week" as culturally recognized term without explanation
- Maintained original name order for Japanese characters (e.g., Komatsu Sayaka)
- Used "Newcomer Welcome Orienteering" for "新入生歓迎ハイキング" as established in Fixed Terms
- Translated "高嶺の花" idiom as "unattainable prize" for cultural accessibility
- Rendered internal monologue "*I wasn't trying to be funny...*" in italics per style rules