## 19. High School Enrollment ⑥ ~Let's Kiss Rather Than Talk About Love~

### Author's Preface

I actually planned to post this yesterday, but there were several parts I wanted to revise and expand, so it ended up delayed by a day.

---

The room was an 8-tatami Japanese-style room. 

A cheap folding table stood in the center, with only a round tray holding tea utensils like a teapot and cups. The walls had a closet and storage space likely containing futons. An old-fashioned stainless steel pot (non-electric) sat in the alcove.

Too simple for an inn, it looked like a barebones lodging room - clearly one of the rooms reserved for training camps.

During cultural festivals and enrollment/graduation seasons, executive committees are formed to prepare alongside the student council. Sayaka had explained that when events increase the number of people, the student council room becomes cramped, and since overnight stays sometimes occur, the council reserves extra rooms. No wonder there was an inner door connecting directly from the student council's pantry.

That Sayaka deliberately came here meant she wanted to avoid being seen - which conveniently aligned with Yuu's own intentions.

The door didn't lock, but he closed it properly. After removing his indoor shoes and stepping onto the tatami, Sayaka turned around to face him. She approached the frozen Yuu and placed both hands on his shoulders.

*(Starting off aggressive!?)*

Hiding his inner excitement, Yuu met her gaze as she smiled directly at him.

"Don't you think you're being a bit too careless, Hirose-kun?"  
"Um... what do you mean?"  
"No matter how you look at it, if a boy follows an upperclasswoman alone so readily, he can't complain if he gets assaulted."

Ah, so that's what she meant. Applying this world's common sense to his original world, it would be like a male upperclassman (wolf) and a careless female underclassman (sheep). As Yuu, that was exactly what he hoped for.

"I wouldn't mind if it's the president."  
"Wha-!?"

Sayaka, who'd been trying to half-jokingly warn him out of concern, was completely caught off guard by Yuu's grinning declaration and reflexively pulled her hands away.

"D-don't tease your upperclasswoman!"  
"Ah, sorry. I didn't mean it that way. Anyway... I was the one who suggested this."  
"Ah, r-right. My apologies too - my joke went too far."

After mutually apologizing, they sat down for tea. As they drank the tea Sayaka prepared, Yuu spoke.

"So... what do you and your fiancé talk about during meetings?"  
"Well... mostly I talk about school life centered on student council activities, family matters, and recent political/economic or international affairs... while he mostly gives brief responses."

*High school boys and girls discussing politics and economics?* Yuu thought but kept silent. "Your fiancé doesn't like talking?"  
"Yeah... I'm usually the one doing all the talking..."

Sayaka's face gradually lowered. Yuu suddenly wondered: As a capable student council president, she wasn't particularly bad with boys. Last year they'd had a male vice president with no issues, and she conversed normally with Yuu too. Was she getting so nervous in front of her fiancé that she ended up talking nonstop, completely unlike her usual lively self at school?

Yuu could imagine it - he'd experienced similar things in middle and high school. With female classmates in platonic relationships, it was fine. But when facing a girl he liked, he'd become overly conscious and unable to have a proper back-and-forth conversation. Unable to bear the silence, he'd start rambling about himself. Guys like that rarely crossed the line into actual relationships - only extremely handsome guys could get girlfriends despite poor communication skills. In his original world, many men would pursue a beauty like Sayaka. But here, women had lower status regardless of looks, while men were scarce and in high demand despite flaws. He realized she was trying too hard to attract male attention and failing.

Yuu pondered. Though mentally 40, he wasn't experienced enough to give love advice. He knew what he'd done wrong in approaching women before, but wasn't skilled enough to advise on solutions. Plus, he wanted to deepen his relationship with Sayaka now. Maybe he could make physical contact while pretending to help?

Seeing Sayaka looking down dejectedly as she recalled her failed meetings with her fiancé, Yuu couldn't stand it anymore. Without making a sound, he slid over beside her while still seated.

"Hmm? Hirose-kun?"  
"President!"

He stopped just short of touching her. "I don't think a junior like me can give great advice. But I feel like once you get used to it, interacting with the opposite sex becomes manageable."  
"Get used to it... but how would I get used to boys..."  
"Who's right in front of you?"  
"Ah!" Sayaka's eyes widened.  
"Fufu. You're right. How could I forget such a handsome boy was right here?"

Yuu felt slightly down that she saw him as just a junior - at best a brother figure - but pressed his advantage. "That's it! I just remembered - most people don't mind being complimented. Praising your partner might make it easier to touch them. For example..."

Yuu slid even closer. Sayaka remained motionless, her heartbeat slightly faster as she stared at her underclassman. "I've thought this for a while - your hair is beautiful."  
"Ah..."

Yuu's hand reached out and stroked Sayaka's head and the long black hair extending down her back. It shone like silk yet felt smooth to the touch, flowing through his fingers without snagging.

"Wow... it's lovely. I could touch it forever."  
"Fu... ah..."

He stroked the black hair slowly, as if touching something precious. For Sayaka, having her head stroked was something only done in early childhood by parents, relatives, or housekeepers - never by a teenage boy.

*(S-so nice...)*

Her eyes naturally narrowed as she let Yuu's hand stroke freely. If she were a cat, she might have purred.

When Yuu's hand eventually withdrew, Sayaka felt disappointed - just as she wished he'd keep stroking, he caressed her cheek instead. "Your skin is so smooth too."  
"Huh?"

With Yuu's face so close, Sayaka's heart raced. But it didn't feel unpleasant.

"You're truly beautiful, president. I feel like thanking God for letting me meet you at this school."  
"...!"

Instantly, Sayaka's face flushed crimson. She'd been called beautiful since childhood until it became normal. But Yuu's whispered words at close range pierced her heart.

"A-ah... H-Hirose-kun"  
"How was that? President?"  
"Uu..."

Sayaka suddenly grabbed Yuu's shoulders with both hands. "Fufu... I thought my heart would stop."  
"Huh? Um..."

Yuu panicked at the unexpected reaction. "Well, it's rare for me to be complimented by an unrelated man."  
"Ah, I see... Then it's your turn now, president."  
"M-me...?"  
"Yes."  
"Hmm..."

Frowning seriously, Sayaka began thinking hard. "Is it difficult? Just imitate me then."  
"R-right! Good idea!"  
"Ah! I know - how about this scenario?"

Seizing the idea, Yuu flopped down and laid his head on Sayaka's lap as she sat formally.

"Hah! H-Hirose-kun!?"  
Startled by the sudden move, Sayaka froze in flustered confusion rather than pushing him away. From Yuu's perspective, he saw the raised chest of her sailor uniform and beyond it, Sayaka's bewildered face.

"I'll play all kinds of roles today! Go ahead!"

A woman giving a man a lap pillow. A common scene for couples in his original world, but here where men were scarce and avoided contact out of fear of women, it only existed in fiction. Even proper Sayaka, being a girl her age, read romance novels. She never imagined experiencing such a dream scenario firsthand. With Yuu's head on her lap looking up at her, she felt her heartbeat quicken. Sweat seeped from her palms, which she wiped on her skirt near her waist, forgetting her handkerchief.

Finally resolved, Sayaka spoke. "H-H-Hirose-kun's..."  
"Why don't we use first names at times like this?"  
"O-okay. Then... Yuu-kun?"  
"Yes, Sayaka-senpai."

They smiled at each other, slightly awkwardly.

"Yuu-kun's hair is smooth too. Nice to touch."  
"R-really?"

He'd trimmed it before enrollment, so it was neither too long nor short - just right black straight hair. If anything, Yuu was enjoying Sayaka stroking his head more. As she stroked his hair, she caressed his cheek with her other hand.

"And your face has just the right mix of ruggedness and sweetness. When those hazel eyes stare at me, my heart races for some reason. I totally get why even third-year girls fall for you at first sight. Truly, you're a sinful man."  
"No... not really... Ah! You're saying that perfectly now, Sayaka-senpai."

At Yuu's comment, Sayaka put a hand to her chin in thought. "I wonder why. Is it because I see you as a fellow student council member? But I definitely do see you as a man..."

"You see me as a man?"  
"Yeah. Definitely. Um, here..."

Supporting Yuu's head, Sayaka stretched out her legs. Then she bent forward, pressing Yuu's face against her chest.

It happened in an instant. Though separated by her uniform, he was enveloped in a soft, pillowy sensation.

"See? Can you feel my heart pounding?"  
"Whoa!?"

Yuu couldn't respond. That women could casually touch men's chests - another effect of the chastity reversal. The feel of his admired Sayaka's breasts. Pressed from above, they felt more voluminous than they looked. Forgetting his breathlessness in his joy, he rubbed his whole face against the softness.

"Hahah. That tickles, Yuu-kun. Did you hear my heartbeat?"  
In his enjoyment, he'd forgotten. Now he heard the *thump-thump* clearly. His own chest was pounding too. The breast sensation felt wonderful - he wanted to bury his face forever. But curious how Sayaka would react if reversed, Yuu wrapped both arms around her back and hugged her tightly.

"Fwah! Yuu-kun! Wh-what!?"  
"My heart's pounding so hard it might burst! Listen!"

He sat up together with her. Now kneeling, Yuu lifted his striped shirt and pressed Sayaka's head against his left chest. Up close, his nipples were faintly visible through the T-shirt.

"See?"  
"But why... aren't you wearing underwear!?"  
"Underwear? Ah, that's too much trouble."

Yuu had learned after starting high school: boys here wore tank-top-like undergarments beneath T-shirts. Unlike women's bras that protect breasts and maintain shape, male chest underwear purely shields them from female gazes. During P.E. changes, Masaya and Rei had scolded him multiple times for not wearing any, but Yuu laughed it off since he wasn't used to it.

Though less soft, in this world male chests held the same value as female breasts in Yuu's original world. Women couldn't casually touch them over clothes, let alone see them without underwear. Yuu's T-shirt without underwear was as erotic here as a braless T-shirt on a woman in his old world. Hesitant at first, Sayaka gently pressed her cheek against it when Yuu guided the back of her head.

"Ahh... I can feel Yuu-kun's heartbeat. From this hard, rugged manly chest. Haaaah~~~"  
Seeing Sayaka moan uncontrollably, Yuu smiled wryly and stroked her head. Looking down, he noticed her hands resting on his sides and clasped one free hand. Sayaka seemed too engrossed rubbing her nose and cheek against his chest to notice. Intertwining his fingers with her smooth, long ones in a "lover's hold," Yuu savored her hand's touch.

*(I want more of this woman...)*

Her soft chest pressed near his lower abdomen, making blood rush to his crotch.

Smoothly, Yuu lowered himself to eye level with Sayaka. His left hand held hers, his right around her waist. Her near-black eyes seemed to capture him in an intense gaze but quickly looked away. Her ragged breathing was unmistakable though. Having tasted a boy's chest through thin fabric, Sayaka felt strong desire. But she suppressed it with reason - she had a fiancé, and Yuu was a precious junior.

Breath close enough to feel, Yuu spoke. "Sayaka-senpai, shall we practice deepening romantic stages?"  
"Pr-practice? How?"  
"First, A."  
"Huh?"

A light lip-to-lip kiss. The kind new couples share when the mood is right. Yet even that made hot excitement bubble inside Yuu.

Before Sayaka could react, he pressed his lips again, slightly firmer. "Mm... fu"  
Finally catching up, Sayaka blinked rapidly before closing her eyes. For over a minute, they kissed motionlessly, savoring each other's lips.

Pulling back to check Sayaka's reaction, he saw her cheeks pink, eyes dazed as she looked back. That expression was adorable too - *how cute*, Yuu thought.

"Let's practice more."  
"Ahfu, pr-practice... mmph... mmfuu"

As Yuu's right arm around her waist tightened, Sayaka's left arm moved from his back to his shoulder, gripping tightly. *Chu, chu* - they exchanged pecking kisses repeatedly.

"Ahh, Sayaka-senpai..."  
"Mmfu... Yu-Yuu-kun..."

Between kisses, they called each other's names, pressing lips together repeatedly. With each kiss, their affection grew stronger, chests burning. Unconsciously, Yuu parted her lips and teeth with his tongue.  
"Mmph!?"  
Eyes flying open momentarily, Sayaka felt her lower abdomen heat up at the slimy sensation of Yuu's tongue invading her mouth, her thighs clamping together. "Ahfuu"  
Her breath leaked from the slight gap. Yuu's tongue circled her mouth before pressing firmly against Sayaka's retreating tongue. He pushed it deeper, scooped it up, and toyed with it.  
"Nnhhoo..."  
Sayaka's eyes grew hazy, then she wriggled her tongue back defiantly. They tangled - one on top, then the other, twisting together.

When Yuu realized it, Sayaka had pinned him down. Opening his eyes slightly, he could see her face lost in deep kissing, but his vision was dark. Sayaka's long black hair cascaded over the sides of his face.

"Mm, chu, chu! Hah, hah, Yu, Yuu-kun! Ahh! Yuu-kun! Amm... mm! Mm! Lero, leroh... oh, ohiiih... Kissing... feels so... ahfuu, more! Mmph leroh jupuu"  
Not only did Sayaka's tongue roam Yuu's mouth, she showered his cheeks and jaw with *chu, chu* kisses like rain. Drool from both already coated around Yuu's mouth. Sayaka's tongue licked it away as if it were precious.

"Hyaah... aeh... hyaah ka, fenpa... mmn!"  
When Yuu tried to speak, Sayaka's lips sealed his. The fragrance from her hair, the fresh softness of her lips and tongue - Yuu's head grew fuzzy, unable to think straight.

*(Guess the fire in her suppressed heart got lit?)*  
*Oh well. This is fine sometimes.* Yuu abandoned thought and surrendered to Sayaka's physical onslaught.

---

### Author's Afterword

Ended at just kissing (´・ω・`)  


### Chapter Translation Notes
- Translated "貞操逆転" as "chastity reversal" to maintain series terminology consistency
- Preserved Japanese honorifics (-kun, -senpai) per style rules
- Translated "膝枕" as "lap pillow" as culturally specific term
- Rendered sexual terms explicitly ("breasts", "crotch", "French kissing")
- Transliterated sound effects ("chu" for ちゅっ, "lero" for れろ)
- Maintained Japanese name order (Komatsu Sayaka, Hirose Yuu)
- Italicized internal monologues per style guide
- Translated "ディープキス" as "deep French kissing" for clarity
- Used "T-shirt" for ティーシャツ as standard term
- Translated "ノーブラティーシャツ" as "braless T-shirt" for cultural accuracy