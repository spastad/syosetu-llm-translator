## 20. High School Enrollment ⑦ ~I'd Rather Caress Than Be Caressed~

Sayaka's hands impatiently unbuttoned the shirt buttons while her mouth busily sucked and licked from Yuu's neck down to his open collar.

*(Maybe this kind of thing isn't so bad once in a while)*

Watching Sayaka's head as she panted with rough breaths in full arousal mode, Yuu thought.

Ultimately, this was a reversal of the typical scenario where a suggestive junior girl tempts a senior boy into losing control.

Moreover, since she was a virgin who'd been coldly rejected by her fiancé, it was only natural she'd get excited.

After roughly exposing Yuu's chest, Sayaka buried her face in it to fully inhale his scent—but suddenly froze.

  

Wondering what was wrong, Yuu lifted his head.

Her long disheveled hair covered her face, making her expression unreadable.

But gradually, sobs began to leak out.

  

"Uu... I-I... what have I...! L-Letting lust take over... committing an... irreparable act..."

"Sayaka-senpai?"

"Guh...u... I'm sorry. Yuu... Hirose-kun. Y-you were scared, weren't you? Hah!"

"Huh?"

  

Sayaka suddenly leapt off Yuu with tremendous force, scrambling backward before assuming a dogeza position.

"I-I deeply apologize! Having committed such an unforgivable crime, I shall accept any punishment with my body—"

"Wait, please!"

  

Yuu's silence while letting Sayaka have her way had backfired.

She'd mistakenly thought Yuu couldn't speak from terror—the normal male reaction in this world.

Though Yuu had actually been enjoying it, he'd been flustered about how to react since he wasn't used to being caressed by women. Had it been novice nurse Mio or housekeeper Akiko stroking his cock, he'd have vocalized.

  

With the sweet atmosphere shattered, Yuu hurriedly approached Sayaka. "Sayaka-senpai didn't do anything wrong! There's no problem at all. Ah, please lift your head."

"That can't be..."

When Sayaka looked up, her refined face was crumpled with intense remorse and self-loathing, eyes bloodshot as if tears might spill any moment. She was probably holding back tears, thinking Yuu should be the one crying.

  

This unexpectedly vulnerable side of Sayaka.

No—her strong sense of responsibility as student council president. As the eldest daughter expected to inherit the family, she strictly disciplined herself, so succumbing easily to lust must have felt shameful.

As a 40-year-old at heart, Yuu found the earnest Sayaka even more endearing.

  

Without thinking, he spread his arms and embraced Sayaka tightly.

"Hauu! Wh-what are you doing!?"

Holding her tight and feeling her warmth, Yuu made a resolution.

He wanted to keep her close.

  

"I think... I've fallen for you, Sayaka-senpai."

"H-heh? Th-that's—"

This time, seeing the usually cool Sayaka breaking down was amusing, and a smile formed on Yuu's lips.

  

"I know. You have a fiancé, so we can't date."

"U-uu..."

Yuu gently brushed the hair from Sayaka's face and gazed into her wavering eyes after his sudden confession.

He caught the teardrops gathering at the corners of her eyes with his fingers.

  

"Earlier, when I saw Sayaka-senpai looking down, I wanted to do something for you.

So kissing and hugging—I'm the one who wanted this. See?"

With that, he lightly kissed her forehead.

"Ah!"

Then kissed her cheek.

  

"Do you dislike kissing me?"

"N-no, not at all... Rather, I want more... Hah! But, but I..."

"Fufu. Good. Then let's continue practicing. Senpai should learn more about men.

And I want to know more about you."

"Fumoh!"

  

This time Yuu pressed firmly against Sayaka's lips while hugging her tightly and stroking her hair.

"Nfuhh!"

The embers smoldering deep within Sayaka's body, which had seemed cooled, reignited.

Her hands naturally crept around Yuu's back, stroking as if confirming his texture.

  

After breaking the kiss, Yuu stroked Sayaka's head like praising a good child while whispering near her ear with his breath.

"And you know? Men have sexual desires too."

"Fehh!?"

  

Without warning, Yuu groped Sayaka's breasts over her uniform.

They were more than a handful.

She was likely wearing a full-cup bra covering the entire breast—he felt underwires.

But the soft, yielding sensation in his palm wrapped Yuu's heart in happiness.

  

"Ahh, Sayaka-senpai's breasts are wonderful! Perfect size!"

"R-really?"

"Yes!"

  

Sayaka, living in this world, couldn't understand Yuu's breast obsession.

But being praised so excitedly couldn't not make her happy.

"Fufufu. Then I'll have you show me your naked body next. Don't be shy."

"Ah, sure."

  

Yuu's eyes remained glued to her breasts as he quickly removed his dress shirt.

He even started casually removing his half-tucked T-shirt.

"Ah, wait! That's wasteful!"

Sayaka spoke up, wanting the pleasure of undressing him herself.

In novels with slightly erotic scenes she'd read, it should have been:

"Se-senpai, I'm embarrassed~"

With blushing cheeks.

Whether it was reality vs. fiction, Yuu being unusual, or him acting cheerful because she was inexperienced, her mind raced before concluding it was a mix of the second and third options. In truth, it was simply a difference in chastity values.

  

"Hoh... u, too beautiful!"

This time Sayaka's eyes were glued to Yuu's upper body, licking it with her gaze.

Though he'd started self-training during the latter half of his hospitalization to combat his lack of stamina, barely ten days showed no results—he remained slender with little muscle.

Unbeknownst to Yuu, this world favored slimness as attractive for both women and men.

Thus, Yuu's visible slenderness through clothes had drawn intense female gazes since before middle school.

  

Seeing this ideal body firsthand was irresistible for Sayaka.

A gulping sound was audible.

Her eyes glistened intensely, looking ready to enter full arousal again.

  

"Ca... can I touch?"

"Let's touch each other."

"R-really?"

"Of course!"

Sayaka had been trying to be considerate while suppressing her overflowing lust, but Yuu's immediate response made a smile spill out.

"Fufu... really, you keep surprising me today. But somehow, it makes me happy."

"I'm the one who's happy seeing Sayaka-senpai's various expressions and voice, and such a beautiful body... I can't contain my joy."

"Yuu-kun..."

"Sayaka-senpai."

  

After their foreheads lightly touched, their lips met as if drawn together, overlapping as they savored the sensation.

Meanwhile, both hands reached forward.

While Yuu gently touched her breasts straight on with outstretched hands, Sayaka's hands snaked around from the sides to touch Yuu's armpits.

  

*(Soft! But not just soft—they have firmness too... ah, these are Sayaka-senpai's breasts!)*

First, Yuu spread his index finger and thumb to scoop from below the breast, confirming the texture.

Simultaneously, he felt Sayaka's hands creeping up his sides toward his chest from his armpits.

*(Somehow... ticklish)*

For Yuu, kissing while groping breasts was commonplace, but having his own body touched so boldly was a first—confusion dominated.

By his original world's standards, he preferred touching over being touched (cock aside).

But Sayaka, endlessly fascinated by the male body, wanted to stroke freely.

This collaborative effort between two people with such different sensations.

Kissing while touching and being touched.

Unexpectedly, this created a synergistic effect, exciting them both.

  

"Haa, haa... Sayaka...senpai! Nn, fuu... breasts, so soft... amazing..."

"Nn, auu... st-stop... Yuu-kun's hands are lewd... nfuhh... ahh, Yuu-kun!"

  

Sayaka licked Yuu's saliva-glistening lips.

Provoked by the red tongue moving at the edge of his vision, Yuu also extended his tongue to catch it, their tips licking each other.

Then, with a *buchu* as their lips met, their tongues intertwined.

Yuu's hands gently grasped the breasts without force, moving to confirm the plump, jiggly feel.

Sayaka's hands, after checking Yuu's shoulders and chest with her fingers, pressed her palms against his armpits and squeezed tightly.

  

"Nnnn!"

Yuu pressed his palms against her breasts and pinched her nipples between his fingers.

"Senpai, your nipples hardened."

He teased the swollen, hardened nipples triumphantly.

"Nnaah! Ann! Wh-why is it... when Yuu-kun plays with them... I-I feel strange... ryuhh!"

"Well, nipples are sensitive, right?"

Yuu whispered while blowing into her ear.

"Nkuuuu... y-you're calm, Yuu-kun!"

"Uwah!?"

  

While feeling pleasure, Sayaka retaliated by kneading Yuu's nipples with her fingertips.

For Yuu, this was a first.

A strange, tingling sensation ran through him.

"O...ohh..."

"Hah, hah... d-does it feel good?"

This time Sayaka nibbled his earlobe as she spoke.

"I-it might feel good..."

"Th-that's good... haaann! H-hey... ahh, fuun"

Not to be outdone, Yuu inserted his tongue into Sayaka's ear, licking with wet *picha picha* sounds while continuing to fondle her nipples.

  

The breast-fondling contest was effectively won by the experienced Yuu.

Or rather, Sayaka—whose arousal continued, dampening her inner thighs—never stood a chance.

Sayaka succumbed to the circular nipple stimulation and ear-licking.

Gripping Yuu's shoulders, Sayaka arched her back sharply before trembling violently.

"Hah! Why... nnnnnn—! Kuh, aahh, Yuu...kuun! Enough... I-I... aauunn!"

  

Wearing an ecstatic expression from her first climax, Sayaka lost herself.

Women in this world had heightened sensitivity due to increased libido and physiological adaptation to rare male encounters.

Though surprised she came just from breast play, Yuu realized such reactions were normal here.

Regardless, he was thrilled she climaxed from his touch—even without much confidence—and found her adorable. Embracing the dazed Sayaka, he gave her a passionate kiss.

  

  

  

  

Sailor uniforms broadly fall into two types: side-opening and front-opening.

Sairei Academy's designated girls' uniform was the front-opening button type.

Checking at Sayaka's suggestion, he saw light purple buttons matching the sailor color on the overlapping fabric's inner side.

He undid the buttons one by one from the top.

The pink scarf was intentionally left on.

With all buttons undone, pure white bra-covered breasts protruded assertively through the parted fabric.

As expected, it was a wired full-cup type firmly supporting the voluminous flesh, with lace edging adding elegance.

The breasts swelling beyond the cups drew his eyes to their valley—naturally, as a man.

  

Meanwhile, Sayaka showed no embarrassment under Yuu's intense gaze.

At that moment, she was facing one of life's most critical junctures—too preoccupied for that.

Namely, she was slowly lifting the hem of Yuu's inner T-shirt.

  

"Haa, haa... nn! Fuu, calm down, me..."

She didn't even notice her ragged breathing or muttered words just from seeing his navel and stomach.

  

Both were engrossed in seeing each other's bare skin.

Wanting to savor the gradually exposed skin, they moved their hands while exchanging heated gazes.

  

"Unhooking it."

"Ah, yeah."

Yuu checked from the front but saw it wasn't a front-hook bra like in eroge—the hook was on the back. He reached behind.

When removing the T-shirt, her hands brushed Yuu's armpits, further exciting Sayaka. But she realized she was experiencing the rare event of having her clothes removed by a boy.

Each touch of Yuu's hands sent pleasant tension through her.

As Yuu fumbled with the stubborn hook, his face beside hers emitted a refreshing scent that tickled her nostrils.

Sayaka's chest made a faint creaking sound inside.

She found Yuu—who cared for her—adorable and precious.

This warm feeling, stronger than what she felt for her fiancé (whom she assumed would naturally be hers), filled her heart.

  

"Don't rush. Stay calm."

"Y-yes"

At Sayaka's voice near his cheek, Yuu regained composure.

Despite being married with female experience in his past life, he'd apparently been nervous before this beautiful girl.

  

Yuu calmly unhooked the bra.

As the cups fell away, the restrained breasts swayed and were exposed.

"O...oooh!"

"Why so surprised?"

Sayaka tilted her head at Yuu's reaction.

  

Below Yuu's gaze were perfectly curved, plump hemispherical breasts.

Even without the wire bra's support, they protruded horizontally without sagging.

He estimated they were around E-cup.

Moreover, the small nipples and areolas were pale pink.

In his original world, he'd only seen such perfect breasts in magazines or adult media—never directly.

Now, the sailor scarf tied in a bow hung perfectly in the center, adding flair.

Yuu was a partial-undressing enthusiast.

  

"Am...amazing! Sayaka-senpai's breasts!"

"R-really?"

"Yes!"

  

Sayaka, living in this world, couldn't comprehend Yuu's breast obsession.

But being praised so excitedly couldn't not make her happy.

"Fufufu. Then I'll have you show me your naked body now. Don't be shy."

"Ah, sure."

  

Yuu's eyes remained fixed on her breasts as he swiftly removed his dress shirt.

He even started casually removing his half-tucked T-shirt.

"Ah, wait! That's wasteful!"

Sayaka spoke up, wanting the undressing pleasure herself.

In novels with slightly erotic scenes she'd read, it should have been:

"Se-senpai, I'm embarrassed~"

With blushing cheeks.

Whether it was reality vs. fiction, Yuu being unusual, or him acting cheerful because she was inexperienced, her mind raced before concluding it was a mix of the second and third options. In truth, it was simply a difference in chastity values.

  

"Hoh... u, too beautiful!"

This time Sayaka's eyes were glued to Yuu's upper body, licking it with her gaze.

Though he'd started self-training during the latter half of his hospitalization to combat his lack of stamina, barely ten days showed no results—he remained slender with little muscle.

Unbeknownst to Yuu, this world favored slimness as attractive for both women and men.

Thus, Yuu's visible slenderness through clothes had drawn intense female gazes since before middle school.

  

Seeing this ideal body firsthand was irresistible for Sayaka.

A gulping sound was audible.

Her eyes glistened intensely, looking ready to enter full arousal again.

  

"Ca... can I touch?"

"Let's touch each other."

"R-really?"

"Of course!"

Sayaka had been trying to be considerate while suppressing her overflowing lust, but Yuu's immediate response made a smile spill out.

"Fufu... really, you keep surprising me today. But somehow, it makes me happy."

"I'm the one who's happy seeing Sayaka-senpai's various expressions and voice, and such a beautiful body... I can't contain my joy."

"Yuu-kun..."

"Sayaka-senpai."

  

After their foreheads lightly touched, their lips met as if drawn together, overlapping as they savored the sensation.

Meanwhile, both hands reached forward.

While Yuu gently touched her breasts straight on with outstretched hands, Sayaka's hands snaked around from the sides to touch Yuu's armpits.

  

*(Soft! But not just soft—they have firmness too... ah, these are Sayaka-senpai's breasts!)*

First, Yuu spread his index finger and thumb to scoop from below the breast, confirming the texture.

Simultaneously, he felt Sayaka's hands creeping up his sides toward his chest from his armpits.

*(Somehow... ticklish)*

For Yuu, kissing while groping breasts was commonplace, but having his own body touched so boldly was a first—confusion dominated.

By his original world's standards, he preferred touching over being touched (cock aside).

But Sayaka, endlessly fascinated by the male body, wanted to stroke freely.

This collaborative effort between two people with such different sensations.

Kissing while touching and being touched.

Unexpectedly, this created a synergistic effect, exciting them both.

  

"Haa, haa... Sayaka...senpai! Nn, fuu... breasts, so soft... amazing..."

"Nn, auu... st-stop... Yuu-kun's hands are lewd... nfuhh... ahh, Yuu-kun!"

  

Sayaka licked Yuu's saliva-glistening lips.

Provoked by the red tongue moving at the edge of his vision, Yuu also extended his tongue to catch it, their tips licking each other.

Then, with a *buchu* as their lips met, their tongues intertwined.

Yuu's hands gently grasped the breasts without force, moving to confirm the plump, jiggly feel.

Sayaka's hands, after checking Yuu's shoulders and chest with her fingers, pressed her palms against his armpits and squeezed tightly.

  

"Nnnn!"

Yuu pressed his palms against her breasts and pinched her nipples between his fingers.

"Senpai, your nipples hardened."

He teased the swollen, hardened nipples triumphantly.

"Nnaah! Ann! Wh-why is it... when Yuu-kun plays with them... I-I feel strange... ryuhh!"

"Well, nipples are sensitive, right?"

Yuu whispered while blowing into her ear.

"Nkuuuu... y-you're calm, Yuu-kun!"

"Uwah!?"

  

While feeling pleasure, Sayaka retaliated by kneading Yuu's nipples with her fingertips.

For Yuu, this was a first.

A strange, tingling sensation ran through him.

"O...ohh..."

"Hah, hah... d-does it feel good?"

This time Sayaka nibbled his earlobe as she spoke.

"I-it might feel good..."

"Th-that's good... haaann! H-hey... ahh, fuun"

Not to be outdone, Yuu inserted his tongue into Sayaka's ear, licking with wet *picha picha* sounds while continuing to fondle her nipples.

  

The breast-fondling contest was effectively won by the experienced Yuu.

Or rather, Sayaka—whose arousal continued, dampening her inner thighs—never stood a chance.

Sayaka succumbed to the circular nipple stimulation and ear-licking.

Gripping Yuu's shoulders, Sayaka arched her back sharply before trembling violently.

"Hah! Why... nnnnnn—! Kuh, aahh, Yuu...kuun! Enough... I-I... aauunn!"

  

Wearing an ecstatic expression from her first climax, Sayaka lost herself.

Women in this world had heightened sensitivity due to increased libido and physiological adaptation to rare male encounters.

Though surprised she came just from breast play, Yuu realized such reactions were normal here.

Regardless, he was thrilled she climaxed from his touch—even without much confidence—and found her adorable. Embracing the dazed Sayaka, he gave her a passionate kiss.

  

  

  

  

---

### Author's Afterword

( ゜∀゜)o彡゜ Oppai Oppai  


### Chapter Translation Notes
- Translated "おっぱい" as "breasts" consistently per explicit terminology rule
- Preserved Japanese honorifics (-senpai, -kun) throughout
- Maintained original name order (Komatsu Sayaka)
- Transliterated sound effects (e.g., "Haa haa", "Nfuhh", "Buchu")
- Italicized internal monologues per formatting rules
- Translated anatomical terms directly ("nipples", "breasts", "cock")
- Rendered sexual acts without euphemisms ("groped", "fondled", "climaxed")
- Used gender-neutral "they" for ambiguous singular references
- Translated "童貞" as "virgin" for accuracy
- Handled simultaneous dialogue with double quotes when characters spoke/reacted together
- Translated author's afterword phrase "( ゜∀゜)o彡゜ オッパイ" with transliteration + context