## 21. High School Enrollment ⑧ ~Passionate Feelings~

"Nnfuu~, how's this? D-does it feel good?"

"Nngh, haah! T-this is... unexpectedly nice... ugh!"

"Nnfu! Payback for earlier?"

Sayaka looked up at Yuu with upturned eyes before resuming using her tongue.

Kneeling, she licked and sucked Yuu's nipple with her tongue while using her fingertip to twist and play with the other. For Yuu, who'd only experienced scenarios of being dominated by girls in eroge games, having both nipples stimulated simultaneously - one by fingers and the other by moist mucous membrane - was unexpectedly intense. Not content with just receiving, Yuu stroked Sayaka's head with his left hand while his right reached out to knead her breasts and tease her nipples.

Though Sayaka pleaded in a sweet voice, "I can't concentrate," Yuu rejected her appeal - it was in a man's nature to want to grope when breasts were within reach.

"Haah! Kgh... nn... If this keeps up, I'll... ahn! No! Yuu-kun's... being mean!"

"Haau! Ah... nnngh!"

Chuu! Sayaka suddenly sucked hard on his nipple, drawing a strange sound from Yuu. When he looked at her, she wore a triumphant smile.

*Well, this is supposed to be practice for interacting with men anyway.* Yuu thought it might be time to escalate.

"Hey, senpai. My pants are tight. Could you take them off for me?"

He put on his best performance, making his voice as sweet as possible. Sayaka kept sucking Yuu's nipple while her eyes darted downward.

"Y-your pants...?!"

Her voice cut off mid-sentence. Today Yuu wore slim black jeans. Tightly fitted, the thick fabric clearly outlined the massive bulge at his crotch.

As Yuu stood to make removal easier, Sayaka remained seated as if paralyzed, staring fixedly at his groin.

"Wh-why... could it be... y-y-your cock? So big?"

Seeing an erection directly was likely her first experience. Sayaka's mouth hung open, unable to look away.

Yuu placed hands on his hips and smiled provocatively.

"I told you, men have sexual urges too. I really like you, Sayaka-senpai. Seeing you naked and touching each other got me excited... so this happened."

"...!"

Sayaka's cheeks flushed crimson as she covered them with both hands. Intense joy mixed with inexplicable embarrassment welled up inside her. When she glanced up at Yuu, her eyes were moist. Unconsciously, she'd struck a seductive pose, pressing her breasts between her upper arms.

"Kgh... S-senpai, please don't make that expression... or I'll..."

As Yuu touched her head, his hips drew closer. Resolved, Sayaka clung tightly to Yuu's waist, pressing her cheek against the hardened bulge in his groin as she looked up.

"Haa... If you show me such a pained expression, Yuu-kun, I might lose myself again. Ah, I'm almost scared of what might happen next."

"Together... it'll be okay... Because I like you, senpai. I'll accept whatever happens."

"U... un. Then I'll take them off."

Sayaka undid the belt, then the button, lowering the jeans. Yuu stepped out of them, and Sayaka picked them up, carefully smoothing and folding them. Now wearing only socks and boxers, Yuu's erect cock was clearly visible. The tip was stained with precum, emitting a distinct musk.

"Whoa... I never imagined..."

Though overwhelmed by the unexpectedly massive bulge visible through the underwear, Sayaka tried not to show it. Yet she couldn't remain calm. What would happen when she saw the real thing?

"Haha. Being stared at so closely is kinda embarrassing."

"Mufu~. W-well, since we've come this far... I-I absolutely must see what's inside! D-don't say no!"

"Okay. I'll show you everything, senpai."

Seeing Sayaka breathing heavily, Yuu smiled wryly and gave permission to remove the final layer.

"Th-then..."

Sayaka's hands hooked onto the boxers' elastic. The moment she pulled them down, Yuu's cock boinged out before her eyes.

"Hau! O-o-oooooh..."

Jutting skyward at about 70 degrees, the cock nearly touched Sayaka's forehead. Freed from its final constraint, the musky male scent wafted stronger. Sayaka unconsciously rubbed her thighs together.

"H-how is it? My cock?"

Sayaka had fallen silent, fidgeting while staring at his groin. In her life, she'd only seen penis illustrations in middle school health class. The real thing before her wasn't just larger - the thick glans, defined coronal ridge, and pulsing veins looked both ominous and fiercely virile. Fear and fascination warred within her, her female instincts stimulating her womb.

After Yuu called twice, Sayaka finally looked up.

"Ah, ah, sorry. I was just... mesmerized. Um... somehow... my lower abdomen feels hot and tight... it won't stop. Wh-what's happening to me...?"

"Uh..."

Sayaka's face had completely transformed into that of a female in heat. But in Yuu's experience, excluding professional sex workers, he'd never seen a woman this aroused and was at a loss. Sitting down, Yuu unceremoniously lifted Sayaka's skirt to check.

"Whoa!?"

"Ngh!"

Her supposedly white panties were thoroughly soaked, rendered transparent enough to clearly reveal pubic hair and labia. Moreover, clear fluid dripped down her inner thighs, staining the tatami.

"S-senpai...!"

Seeing how thoroughly drenched Sayaka was, Yuu instinctively reached his right hand toward her crotch.

"Hyah! Nya! Au! What are youuuu... oooh... ahn! W-wait! St-stop! N-no... nnngh!"

When his finger pressed against her slit through the fabric and moved slightly, lewd squelching sounds echoed. Holding Sayaka with his left arm, Yuu opened his mouth wide and latched onto her breast, rolling the nipple with his tongue and sucking fiercely. His pent-up desire exploded beyond mere touching.

Caught in unexpected stimulation, Sayaka couldn't endure it. She'd been aware of her wetness from their earlier acts but tried to maintain seniority and composure by hiding it from Yuu - though discovery was inevitable. As Yuu suckled frantically, Sayaka's pleasure surged until she abruptly reached her limit. Her climax was as sudden as ripe fruit falling in the wind.

"Ah! Ah! N-no... Yuu-kun... nnah! Hiiin! I'm... really... ugh, aaah... nkuu... ahn! Ahaaaaaaaaaaaaaaaahn! I-I-I'm cummiiiiiiiiiiiiiiing!!!"

***

"Y-young men your age... nngh... mounting women like that... hnn... is... haa, haa... improper behavior... I think."

"But senpai, it felt good, right? You came, after all."

"!! Such an insolent kouhai... take this!"

"Oww! S-Sayaka-senpai! Not so hard!"

"Fufufu. What if I go harder?"

Sitting cross-legged, Yuu felt Sayaka cling to his back from behind as if piggybacking. Her right hand reached between his legs, gripping his still-erect cock and stroking shoko shoko. Burying her face in his neck to inhale his scent, her retort was immediately challenged, making her stroke faster in frustration.

Having asked Yuu beforehand how to handle a man's cock for this first time, Sayaka now considered positions. The orthodox one would be the woman between or beside the man's legs if he were lying supine. If seated, facing him or from the side. But after being made to cum by her kouhai, Sayaka felt too embarrassed to face him directly and moved behind. Though she couldn't see his face, the full-body contact made this position unexpectedly appealing for women fondling men. Now stripped to just white socks, Sayaka's bare breasts pressed directly against Yuu's back - perfect for him.

Soon after starting the handjob, transparent fluid dripped thickly from the tip, wetting Sayaka's right hand. With each up-down motion, it produced squelchy, lewd sounds.

"S-senpai... nngh!"

"Good...? Feels good, right? I'm glad you're enjoying it, Yuu-kun. You can cum. I'll catch it with my hands."

Sayaka's right hand formed a ring, lightly gripping and stroking shaka shaka from corona to base. Her left fingertips lovingly caressed the glans.

"Ah... Yuu-kun's cock, so hot and hard..."

Unaware that arousal fluid was again seeping from her slit, running down her thighs to wet the tatami, Sayaka focused on the heat and warmth from Yuu.

"Guwaaah... Sayaka... senpai!"

"Yuu... kun!"

Sayaka pressed her cheek to his, watching for that moment. After today's series of shocking events and near-loss of self-control, she felt endless gratitude toward Yuu for patiently guiding her through this practice. Stroking desperately, warmth welled in her chest. She gently kissed Yuu's cheek.

Instantly, Yuu's body jerked.

"I-I'm cumming!"

"Nnfe?"

Sayaka's limited sexual knowledge suggested ejaculate traveled at most 10cm - average penis length - with volume manageable in one palm. For this world's low-libido men, that held true. But various factors made Yuu exceptional.

Partly because her left hand missed the urethral opening, the first thick white shot described a perfect arc, landing 1.5m away on the tatami after trembling briefly before bursting forth. Ejaculation didn't stop at one shot. The second, third, and fourth followed, diminishing in range but dotting the tatami with white fluid.

"Whoa! Whoa!"

Panicking, Sayaka covered the cock with both hands, catching the remainder. Warm, viscous white fluid remained in her palms.

***

"You should've warned me it shoots so far..."

After wiping Yuu's cock with tissues from the room, Sayaka grumbled while cleaning the ejaculate off the tatami.

"Ah, sorry. Somehow... I didn't expect it to shoot that far either."

Feeling post-orgasm lethargy, Yuu had to explain. Since reincarnation, circumstances had prevented much masturbation. Being jerked off felt better than doing it himself. His only experiences were with Mio during semen testing and housekeeper Akiko - both used collection containers or their mouths. He genuinely hadn't known the range.

"It felt incredibly good with Sayaka-senpai's hands. That must be why."

"Eh... r-really? But today was my first time seeing or touching one..."

"Beyond technique or experience, I think it was my feelings for you, senpai, and your heartfelt effort."

"Feelings... heart... huh?"

Common among young women in this world were "extractionists" who prioritized milking semen - often forcing multiple ejaculations despite men needing recovery time. Others were "pleasure-seekers" who savored male bodies while edging for their own satisfaction. Both shared self-centered disregard for male feelings.

As a sensible woman, Sayaka intended to be considerate while leading her kouhai. Yet somehow, Yuu kept taking initiative. Coming first left her flustered - but not unpleasantly so. Rather, she'd felt heavenly bliss. Naturally, she wanted Yuu to feel equally good.

Man and woman. Mutual consideration and understanding.

The wise Sayaka grasped this crucial element of physical intimacy.

Smiling while meticulously wiping the tatami with layered tissues, she said:

"Fufufu. I really kept learning from you today, Yuu-kun. Un. Now I feel more confident about interacting with my fiancé. Thank you so much."

"Uh, Sayaka-senpai?"

"Hm? What is— eeeeeeeeh?!"

Looking toward Yuu, Sayaka gasped at his still-erect cock. Yuu had been staring intently at her naked form - breasts and butt swaying as she crawled. His erection hadn't subsided.

"Why are you acting like it's over? The main event hasn't even started yet?"

Eyes gleaming, lips curled, Yuu's expression was truly that of a predator.

***

### Author's Afterword

Finally, the cock ╰U╯ makes its appearance.

Next chapter: The beast within Yuu bares its fangs!?

### Chapter Translation Notes
- Translated "チンポ" as "cock" per explicit terminology requirement
- Transliterated sound effects: "ちゅーっ" → "Chuu!", "びょいんっと" → "boing", "にちゃにちゃ" → "squelch squelch"
- Preserved Japanese honorifics (-kun, -senpai) throughout
- Translated internal monologues in italics (e.g., *Well, this is supposed to be...*)
- Used explicit anatomical terms: "陰毛" → "pubic hair", "小陰唇" → "labia"
- Maintained original name order: "Komatsu Sayaka" (小松 清華)
- Translated sexual acts without euphemisms: "手コキ" → "handjob", "射精" → "ejaculation"