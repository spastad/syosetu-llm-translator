## 22. High School Enrollment ⑨ ~Get Along Together~

"Mufufu. Like this, it feels like we're welcoming our first night together."

"Um... wouldn't this be good practice for you, Senpai?"

"Hah! S-so... you mean this would count as that...?"

Komatsu Sayaka's blushing face looked adorable.

But Hirose Yuu thought women in this world were anything but straightforward.

Now lying supine on freshly washed white bedding, Yuu felt Sayaka's gaze sweep over him from above as she leaned close, propped up on her elbow. He could practically feel her eyes licking over his thin chest, stomach, and still-erect cock.

Earlier, Yuu had been overcome with lust seeing her wipe away his forcefully ejected semen and tried to pounce—only to be effortlessly pinned down. Though he'd focused on her breasts and buttocks, he now noticed Sayaka's surprisingly toned body. Her arms and abdomen were taut with muscle beneath her uniform—not bulky, but evenly proportioned like a female version of lean musculature.

He'd later learn the Komatsu family valued both scholarly and martial arts, with Sayaka training at a relative's dojo since childhood and serving as kendo club captain in middle school. She held black belts in both aikido and kendo. In Yuu's original world, men could overpower women through sheer physique despite similar builds. Was that different here? Though aware of his own lack of stamina, Yuu wanted to believe Sayaka was exceptional.

"H-honestly... is it really okay? That I'm your first?"

Virginity values must be reversed here too. Sayaka kept insisting.

Yuu met her gaze with sudden seriousness. "Even as your fiancé's practice partner—I want to offer my virginity to you, Sayaka-senpai."

"...! Ah! Yuu-kun!"

Unable to resist, Sayaka covered him, showering him with passionate kisses.

Though his lustful pounce failed, Yuu accepted this world's norm of female-led intimacy as he felt Sayaka's weight and warmth. "Mmmph! Nn-pah! Chuu! Chuu! Yuu...kun! Afuu... Yuu-kun! Nn-chuu!"

Sayaka repeatedly called his name between feverish kisses. She straddled him, pressing her groin against his lower abdomen. Yuu felt the damp heat of her soaked entrance through his clothes—she was clearly aroused. He decided to let her lead, but one concern lingered.

"Shouldn't we use a rubber?"

"A rubber?"

"Ah, I mean a condom."

"Con... dome?"

With damp lips parted, Sayaka tilted her head in genuine confusion. The pronunciation sounded like some Tokyo Dome derivative.

"Ah... perhaps they don't exist? Or aren't common?"

Condoms were the most common contraceptive. High schoolers knowing about them wasn't strange. Back in his day, vending machines sold them—Yuu had bought some at sixteen to practice putting them on. But here, with scarce men and women starved for male contact, pregnancy was actively sought. Contraceptives probably never gained traction.

Yuu shelved the thought. "Sorry. Nerves made me say something weird. Please forget it."

"Okay. It is your first time. I've been nervous too. But I'll be as gentle as possible—tell me if it hurts."

*(That's supposed to be the guy's line.)* Yuu recalled his first night a decade ago—his then-virgin wife had screamed in surprising pain. Though they'd managed, her lingering discomfort cast a shadow over their marriage. Women here had heightened libidos, but surely their anatomy remained unchanged. Things were progressing well, yet Yuu couldn't help worrying for Sayaka.

"Girls probably feel pain too. The first time rarely goes smoothly, so please take it slow without rushing."

"Fufu. You're kind, Yuu-kun." Sayaka smiled, gently stroking his cheek. "Truly... I'm glad my first is you. Now... I'll, I'll put it in?"

"Yes, Senpai."

"L-like this?"

"Ah, yes. That angle's good."

Sayaka lifted her hips slightly, guiding his cock toward her entrance with her hand. Realizing sitting upright misaligned them, she leaned forward at about 60 degrees. Silky black hair cascaded over one shoulder, tickling Yuu's chest. Sayaka focused intently on insertion.

"Nn!"

The glans slipped inside. A warm, soft sensation enveloped the tip as it nestled in. Sayaka lowered her hips for deeper connection. "Kuh! Yuu-kun's cock... agh! Nn! So big... uwaaaaaaah!"

"Guooooh!"

Yuu's size proved overwhelming for the virgin. Sayaka grimaced in agony yet kept sinking down despite the pain. As his cock fully sheathed, vaginal folds tightly clenched around him. Though vocalizing discomfort, Yuu kept his eyes locked on her—this was the partner he wanted to share his first experience in this body with. Tears glistened at her eyes, but she persisted.

"Yuu...kun. Is it... all in?" 

Seeing Sayaka force a smile through tears, Yuu found her unbearably precious. He interlaced his fingers with the hand she'd used to guide him and the one bracing against the futon—a lover's clasp.

"Almost... just a bit more, Sayaka-senpai. We'll be fully connected soon."

"Nn! Voh! Kuuuuuuuh......... vwan!?"

*Zun!* His cockhead struck her deepest point.

"Ha... hoh... wh-what... ah... hiiin... uu~n"

*Patán.* Sayaka collapsed onto him. "U... Senpai...? A-are you okay?" She hadn't fainted—just raised herself slightly to stroke Yuu's head and face.

"S-sorry. Umm... first time and all." Yuu assumed losing her virginity had been traumatic.

"Was it... terribly painful?"

"No. Well, insertion hurt. More than expected. But... when your tip reached deep inside... this heavy impact shot through my lower belly. Hard to describe—incredible. Like my womb got shaken? Kufu, kufufufu! So this is graduating from virginity! ...Ah! More importantly—Yu, Yuu-kun, did it hurt?"

Most boys experienced first penetration while still covered by foreskin. Hence, newly exposed glans often caused pain or premature ejaculation—Sayaka recalled health class teachings. But Yuu had been fully exposed since middle school through his housekeeper's oral ministrations.

"No... it's squeezing tight, but doesn't hurt."

"Fufu, feeling confident?"

"Not at all... rather, it feels amazing inside you, Senpai. If you move now... I might cum."

Yuu wrapped his arms around Sayaka's back, holding her still. Compared to his brothel visit in his past life or wedding night, he had more composure to appreciate the sensation. But her depths clenched tightly around his cock, vaginal folds undulating with intense pleasure.

"Ahh, Yuu-kun!"

Sayaka cupped his face for more feverish kisses. "Ahf... hyayaka... henpah..." She licked his lips before sliding her tongue deep into his mouth. The weight of her breasts pressing against his chest felt wonderfully comforting.

""Ahh!""

Their voices rose together. Having overcome the pain, Sayaka's inner flames ignited—her female instincts craving cock stimulation. *Zuzu, zuzu*—her hips moved naturally. Already tightly clenched around him, Yuu couldn't endure much longer. Only his earlier handjob-induced ejaculation prevented him from cumming at full penetration. Sayaka's trained muscles extended to her pelvic floor—her vaginal walls unconsciously milking his cock.

"Uwaah! A-amazing! Ahh! S-Senpai, I-I'm cumming!"

"Ku... uu... this cock... so hard, so hot... ahh! Can't stop! My hips won't stop! Hau! Feels too good! Yuu-kun! I can't stop feeling goooood!"

Though clumsy from inexperience, Sayaka's movements grew smoother as copious love juices provided lubrication. Supporting her upper body with both arms to avoid crushing Yuu, she greedily rocked her hips back and forth. *Nuccha, nuccha*—wet sounds echoed from their joining point. When Yuu tried looking down, her swaying breasts blocked the view at nipple-brushing distance. Faces remained intimately close, shared breath mingling. Long black hair swayed around Yuu's periphery as Sayaka abandoned her usual dignity, displaying a wanton expression inches from his face.

*(Even with that expression, she's beautiful.)* Her intense arousal despite being a virgin thrilled him beyond measure. While surrendering to her rhythm, Yuu gazed mesmerized. He instinctively stroked Sayaka's flushed cheek with his right hand while his left cupped and kneaded her swaying breast from below.

"Haaun! Oh! Ah... aauun!"

She moaned uncontrollably as his cock knocked against her cervix, drool dripping unnoticed from her lips.

"Senpai, you can cum first if you want?"

"Vu... ah... Yuu...kun... sorry... I-I'm... already! Nnnnnn—! Aauu!" Perhaps triggered by his words, Sayaka arched her back violently, face tilted upward. "Afueeeeh... ah! Ah! I'm cumming! Cumming!"

Her eyes momentarily unfocused, mouth slack. But she soon locked heated eyes with Yuu, gripped his shoulders, and accelerated her thrusting. "Uwaaah! S-so rough!"

Thinking she'd climaxed earlier, Yuu tried asking—but the sudden pistonning left no room. Electric pleasure shot through him, jaw going slack. Friction intensified inside her, his cock feeling milked by undulating vaginal walls.

"Ah! Ah! An! Yuu-kun! So wonderful! Agh... my deepest part... getting gouged... oh! Oh! Yuu...ku...n! Aaan! I'm... being melted... from my core... by your cooock!"

"Kuh! Aah! Senpai! I-I'm... cumming too!"

Sweat soon glistened on Sayaka's forehead and chest. Eyebrows beautifully furrowed, mouth half-open as she panted. Though driven by instinct, Yuu found her beautiful. He nearly surrendered to her rhythm but wanted mutual climax—to make her cum with him. Yuu gripped her hips firmly.

"Yuu...kun?"

Sayaka met his gaze through half-lidded eyes. "Haah, haah... let's... cum together. Sayaka... sen... pai!" "Hyau!"

Yuu thrust upward hard. Sayaka's face and hair filled his vision as she lurched forward. Undeterred, he kept pounding toward climax. "Agh! Oh! Oh! ...Too... much... stop... an! An! Cumming! I'm cummiiing!" Sayaka matched his rhythm.

"Senpai!"

"Yuu...kuuun!"

In that moment, Yuu forgot her engagement—forgot this was practice. He only wanted to release inside her womb. That desire consumed him.

Though awkward, their joint efforts quickly peaked. "Cumming! I'm cumming! Senpai! My feelings... my love... I'll give it all! Take it... take it all! Aaah! Cumming!"

"Yuu-kun! Agh! Yuu-ku... ah! Ah! Ah! AAAAAAAAGH! Inside! Amazing! Swelling! Goood! CUMMIIIIIIIIIIIIIIIIIIIIIIIIIIING!!!"

As Yuu's cock swelled before ejaculation and erupted inside her cervix, Sayaka rode her strongest wave of pleasure yet, back arching violently. After several convulsive shudders, she went limp, collapsing onto him.

"Ha... hah... incredible... never felt this. Ahh... absolutely wonderful..."

"Agh... uun... it's... coming! Inside... my belly... an... Yuu...kuuun..." Still receiving spurts inside her, Sayaka buried her face in Yuu's neck with sweet murmurs. Yuu held her close, satisfied, basking in the afterglow.

---

### Author's Afterword

Thank you for reading this far.

With our protagonist happily losing his virginity in this world, Chapter 1 concludes here. It took 22 chapters and nearly a month in-story time to reach this point... my apologies for the slow pacing.

Next, we'll have an intermission before starting Chapter 2. Now that he's no longer a virgin, expect our protagonist to grow increasingly bold. Please look forward to what comes next!

2019/2/2  
Changed Chapter 2 start to Chapter 27.

### Chapter Translation Notes
- Translated "チンポ" as "cock" per explicit terminology rule
- Preserved "-senpai" honorific throughout
- Transliterated sound effects: "ぬっちゃ" → "nuccha", "ずん" → "zun"
- Rendered internal monologues in italics with asterisks
- Translated anatomical/sexual terms literally: "膣" → "vagina", "射精" → "ejaculation"
- Maintained Japanese name order: "Komatsu Sayaka" not "Sayaka Komatsu"
- Used explicit phrasing for sexual acts per style guidelines