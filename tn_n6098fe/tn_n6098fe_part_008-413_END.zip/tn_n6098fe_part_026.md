## Interlude 1: Martina ~Part 1~

### Author's Preface

This is a flashback from the perspective of the protagonist's mother, Martina.

Split into two parts due to length. 2021/09/04

---

In modern times, after the great epidemic of the Red Death Disease drastically reduced the male population in Europe...

Despite the plundering from colonies during the imperialist era, Europe had one of the lowest male-to-female ratios in the world, averaging 1:40 across countries.

After the World Wars, with the development of various technologies, deaths among the young decreased and lifespans extended.

Additionally, the groundbreaking invention of artificial insemination gradually helped the total population recover.

However, that recovery eventually plateaued, and to solve the anticipated population decline problem, drastic reforms were implemented from the 1970s.

As part of this, Men's Preferential Treatment Zones were established on several Mediterranean islands, inviting men from around the world for vacations.

Men visiting the preferential treatment zones had all expenses covered—accommodation, meals, entertainment, etc.—free of charge, except for travel costs.

To ensure the men's safety, security around and within the islands was as tight as military bases, which was only natural.

Conversely, women—whether staff or tourists—had to pay more than double the standard rates and meet strict criteria regarding age, appearance, and background, with only a select few passing the high competition.

The male-to-female ratio on the islands was maintained at around 1:5 to 8, and public safety was so well-kept that men could even walk alone in designated areas.

Thanks to this, many couples not only found fleeting romance in the Men's Preferential Treatment Zones but also ended up marrying.

According to a survey by a Western European country, men who had spent time in these zones were reportedly twice as likely to father children compared to those who hadn't.

Lampedusa Island, the southernmost island of Italy floating in the Mediterranean, was one such place.

  

  

  

  

◇ ◆ ◇ ◆ ◇ ◆

  

  

  

  

My mother, fresh out of high school in Barcelona, applied for a restaurant staff position on Lampedusa Island and was successfully selected.

There, she met my father, a Japanese tourist, and fell in love.

Even more fortunately, my father didn't see it as just a fling for the duration of his stay... No, within a month, he decided to take her as one of his wives.

I later heard from my mother that, despite being ten years older and already having four wives (making her the fifth), she didn't mind at all.

After all, having a relationship with a man and being taken as a wife was an immense stroke of luck in itself.

  

Mother accompanied Father to Japan and formally married him.

A year later, I, Martina, was born.

By the way, I had five half-sisters but no brothers.

Although better than Europe, Japan's gender ratio hovered around 1:30, making opportunities to meet men scarce. Still, as the youngest daughter, I was doted on by Father and was very happy.

  

In this world where men are extremely scarce...

There was apparently a time when young men were swarmed by women who would squeeze them dry just to bear children and maintain the population.

But by the late 20th century, artificial insemination technology advanced, making it possible to have children without women fighting over men.

Thus, there were families that were entirely female for two, or even three, generations.

When daughters from such families came of age and wanted to date or marry, they had no immunity to men and didn't know how to interact with them.

Sometimes they resorted to forceful measures, becoming molesters or rapists and facing criminal charges.

Some women remained without male experience past twenty. Those who could have children via artificial insemination were the lucky ones.

Others grew old without bearing children due to economic or physical reasons.

This was the negative spiral of female-only families that had become a recent problem.

  

Conversely, daughters with fathers or brothers had close male relatives from a young age, allowing them to interact with men more naturally and easily form bonds.

While I was certainly blessed in many ways, perhaps I was in such a situation too.

Being able to attend a co-ed high school was, of course, partly due to my own efforts.

However, I was troubled by my breasts, which grew rapidly as I got taller, ripening like fruit.

They were particularly noticeable among girls my age, causing shoulder stiffness and pain when they bounced during exercise.

Another worry was that I couldn't find bras in my size for designs I liked.

Even when I tried to get close to boys in high school, most would back off upon seeing my breasts.

At the time, a slender figure with little flesh was popular among both genders.

At worst, I was called a "breast monster" or "disgusting," which was shocking.

  

Becoming an executive committee member for the cultural festival in my third year was partly because I had just gone through a breakup and wanted to distract myself with something else.

On the day of the festival, I had a fateful encounter.

I managed to invite a man who had been featured in the media for years—hailed as the savior of the declining birthrate era and a sexual hero—to give a lecture, and he took a liking to me.

The irony was that the main reason he fell for me was my rare large breasts... No, thinking back, perhaps my breasts grew so much just so I could meet him.

We started dating and married right after graduation.

By then, I was already pregnant with my first daughter, Elena.

  

He, Sakuya-san, was a rare individual.

His full name was Toyoda Sakuya, and he was 27 when we met.

At the time, I was in the mid-170cm range, and he was slightly taller, so he must have been around 180cm.

His caramel-colored light brown hair was slightly long, reaching his nape.

He had fair skin, rare for a Japanese person, long legs, and a slender, outstanding figure.

Even from a distance, one could tell he was a stunningly handsome man, and any woman who saw him couldn't help but gaze at him passionately.

Male celebrities on TV paled in comparison.

His alias was the "Fair-skinned Prince."

His appearance perfectly matched the prince from fairy tales of old, secretly popular among young girls.

In a world where men were often timid for fear of being assaulted, he alone never refused any woman, smiling warmly and looking at them with gentle eyes.

At first glance, he seemed delicate—the type that made women want to protect him from lust-driven attackers.

  

In this world, polygamy is mandatory, but the minimum number of wives a man takes is three, and at most, like my father, five or six.

Since women tend to have stronger sexual desires than men, constantly satisfying their demands would be physically exhausting.

  

Amidst this, Sakuya-san became a legend: he lost his virginity to his elementary school teacher at ten and, by fifteen, had slept with over 200 women and fathered children with more than 20.

Even if that's an exaggeration, such a man was unheard of.

In Spain, my mother's homeland, there's a legend of Don Juan, a man who had relations with hundreds of women, but it's said to be a creation by an author lamenting the world's sudden male decline.

  

Sakuya-san didn't attend high school; instead, the state guaranteed his livelihood for life, and he effectively married four classmates he got pregnant.

Truly, an exceptional man.

After media coverage, his fame spread beyond Japan overseas, and women from across the sea flocked in droves to have him. The state eventually took charge of his security.

Still, he was picky, selecting only women in their late teens to early twenties with outstanding looks.

Before marrying me, at 27, he had 17 wives. He had over 30 children with his wives alone?

Beyond that, the number of limited-time mistresses and one-night stands was countless.

Including acknowledged extramarital children, rumors said he had 100 to 150 children.

In any case, he was truly a beacon of hope for women.

  

Being chosen by him filled me with pride and joy.

When he first invited me to bed, I was uncharacteristically nervous, my heart pounding uncontrollably.

And when he took me, I realized:

Sakuya-san's true nature was that of a sexual beast—a man of insatiable lust and immense stamina.

  

Simply being undressed, held, and kissed melted my heart and body into a puddle.

"Ah, Martina, how captivating you are. And such magnificent breasts—I've never seen anything like them! How wonderful!" he whispered during prolonged foreplay, leading to my first climax.

Thanks to over an hour of his foreplay, which left my body utterly pliant, the pain of losing my virginity was momentary.

After that, I was tossed about by waves of pleasure, losing count of how many times I came.

  

Until then, knowledge from health classes and elsewhere taught that men's hearts and bodies were delicate compared to women's, so we had to handle them gently and considerately.

Erections from a naked woman approaching or having sex two or three times only happened in unrealistic erotic manga and novels.

In reality, after ejaculating even once, an interval was necessary. Whether the woman was satisfied or not, only once per night was recommended.

  

Sakuya-san overturned that common sense.

His penis was different from what I'd imagined—virile and impressive.

A large, protruding glans with a defined coronal ridge. Veins bulged, making it bumpy to the touch.

I'd heard the average erect penis size was about 10cm, but his was easily twice that?

His balls were heavy and full, hinting at his inexhaustible stamina.

While a man's penis is an important organ for pleasuring and impregnating women, Sakuya-san's was a weapon that reduced women to mere bitches and drove them mad.

  

That night, at his request, I made him ejaculate twice with titfucking and three times inside my vagina.

I came over ten times—I lost count. I even passed out several times in between.

  

My trysts with Sakuya-san weren't a one-time thing; they continued.

Sometimes in luxury hotel suites, sometimes invited to beachside villas.

We spent many passionate nights together.

Perhaps because of that, by the start of the new year, I learned I was pregnant.

When I confessed, having steeled myself, he was overjoyed and promised to take me as his 18th wife upon graduation!

At that moment, I was in a dreamlike state. After all, both were the highest happiness a woman could achieve.

Of course, my parents were delighted. My mother hugged me, crying tears of joy.

  

After graduating high school, I happily entered married life.

With 18 wives including me, we lived separately in groups of about three in Tokyo, with Sakuya-san periodically visiting each group.

The reason, apparently, was that gathering everyone in one place like a harem from ancient times would inevitably lead to unfair treatment and factional strife among the wives.

It seemed they grouped wives with similar backgrounds, including mixed-race, so I ended up living with the tall, cheerful Italian Emmanuela and the Finnish Suzanna.

Emmanuela was 20, two years older than me, with wavy black hair and large breasts like mine, which made me feel close to her.

Suzanna was 17, a year younger, petite and fairy-like with long, straight platinum blonde hair that shimmered beautifully.

  

When Sakuya-san visited, the wives shared the bed, so if co-wives didn't get along, he wouldn't engage with them.

Perhaps that was intentional to force us to get along.

Luckily, we became close quickly, being close in age.

Plus, with my first childbirth approaching, having Emmanuela, who had experience, was reassuring.

Elena, born then, was a girl with chestnut hair and snow-white skin.

I was sure she'd grow into a stunning beauty, having inherited Sakuya-san's traits strongly.

Suzanna, pregnant half a year after me, joined us, and we spent happy days as three mother-child pairs.

  

Around that time, Sakuya-san led a busy life.

Japan, following Europe's lead, was advancing reforms for population decline, male human rights, and improving male-female interaction opportunities. Sakuya-san, composed in front of large crowds and sharp-minded, was in high demand. He served as an advisor to national special committees and public corporations, attending meetings.

But even amid his busy schedule, he occasionally hooked up with new girls, making me laugh in disbelief.

Still, Sakuya-san made sure to stay at his wives' homes every night.

He visited each house in turn to avoid unfairness.

  

Even so, as the number grew, it was inevitable that wives would compete.

As they say, "Three people create factions"—humans can't escape conflict.

The largest Japanese group had personal likes and dislikes but managed to split well, while we, the new European minority, kept a low profile.

However, the American and Chinese wives were evenly matched and had been competing for years.

That was about two and a half years after my marriage.

When he took a Chinese-American girl as his 20th wife, a huge dispute erupted over which group she would belong to.

Ultimately, the 17-year-old girl, admiring American culture, chose to join the American group, wanting to live in a Western-style mansion.

That became the trigger.

  

I learned later from people there and reports.

On the day the girl was moving, Chinese wives stormed in, hurling abuse and obstructing the move.

Worse, they entered the mansion wielding brooms and sticks, so the initially calm American wives hardened their stance.

A mere quarrel escalated into a brawl with weapons.

When Sakuya-san arrived after a phone call, one Chinese wife, at a disadvantage due to physique, slashed one opponent with a hidden kitchen knife and then went for the girl.

Sakuya-san instinctively shielded the girl.

  

If he were an ordinary man, it would've been fine. Men wouldn't dare approach a women's fight.

But for some reason, he had a tendency to protect women.

Because of that, the knife thrust in a frenzy pierced Sakuya-san's abdomen.

Faced with the wife who had turned pale at her own deed, Sakuya-san didn't get angry.

He just smiled and said:

"Silly. If you wanted to fight, I could've taken you all on at once..."

Those became Sakuya-san's last words.

  

Sakuya-san's death caused an uproar, not just in Japan but overseas.

The Chinese wife who had accidentally stabbed him, upon learning he had passed away despite desperate care at the hospital, shook off police, ran up the stairs, climbed the rooftop fence, and jumped.

Countless other women attempted suicide, some succeeding, shocked by his death.

Over 100,000, perhaps 200,000, people gathered for his funeral.

  

We 19 wives—one had taken her own life—who attended the funeral couldn't return home to avoid media and lived separately in hotels.

But then, I realized: I was pregnant.

The only place to turn was my parents' home.

However, even there, the media came, so I took refuge at a hot spring inn in Izu run by my father's aunt.

I had inherited assets divided among the wives, so money wasn't an issue.

  

There, I gave birth to a boy.

I'd heard Sakuya-san was especially happy when a boy was born, as most of his children were girls.

To have a boy now...

It broke my heart that I couldn't tell his father, Sakuya-san.

  

  

  

---

### Author's Afterword

Was Sakuya reincarnated from the same world as the protagonist?

Or did he possess ancestral traits?

I leave that to your imagination.

In any case, the protagonist inherited his physical characteristics.

  

2020/3/1

In Martina's understanding, there were no boys among the children of his formal wives.

However, while writing Chapter 5, a contradiction in the setting emerged.

Therefore, it was changed to: since there were many girls, Sakuya-san would be especially happy when a boy was born.

  

2020/5/3

Originally, it wasn't about a specific nationality but the concept of Chinese as an ethnicity.

And in this world, the Chinese mainland had split into four nations (if abbreviated, one might call itself "China").

However, it inevitably evoked real-world China, so to separate it, references to "Chinese" or "Chinese people" in the work were changed to "中華" (Chūka). I considered "China" but hesitated...

The Chinese women appearing in this story refer to those from the Republic of China (Nanjing Nationalist Government), the only Chinese nation friendly with Japan, or those of mixed Asian heritage, including Taiwanese, Manchus, and overseas Chinese in Southeast Asia.

  

2021/9/4

"We 20 wives who attended the funeral"

At that point, one had already committed suicide, so it should be 19. Corrected.

### Chapter Translation Notes
- Translated "乳お化け" as "breast monster" to convey the derogatory term for large breasts
- Translated "白皙の王子" as "Fair-skinned Prince" to preserve the nickname's elegance
- Translated "おチンチン" as "penis" to maintain explicit terminology as per style guide
- Preserved Japanese honorifics (e.g., Sakuya-san) and name order (Toyoda Sakuya)
- Translated "童貞を卒業する" as "losing one's virginity" for natural flow
- Used explicit terms for sexual acts and anatomy as required
- Handled the author's afterword notes with care, including the correction about the number of wives