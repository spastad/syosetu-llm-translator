## Interlude 1: Martina ~Part 2~

It was wonderful to have a baby boy, to hold his small body in my arms and savor the happiness, but at the same time, I had a concern.

Back when Sakuya-san was a teenager, he had fathered two boys with women and acknowledged them outside of marriage. I had heard that because the mothers were students, the state took over their upbringing to provide an environment worthy of precious boys. Moreover, the turmoil surrounding Sakuya-san's death still lingered, and I feared what might happen if this became known. I absolutely wanted to avoid having my newborn son—whom I named Yuu—taken away.

So I lied to everyone that a girl had been born.

The inn in Izu let us stay until Yuu's neck could fully support his head.

After returning to my parents' house, I explained the situation. As a result, we reverted to my maiden surname Hirose. When filing the birth certificate, since the father was deceased, I had the sudden idea to leave it blank—fortunately, this meant even if third parties saw it, they wouldn't realize he was Sakuya-san's child. To be safe, I stopped meeting with his wives like Emmanuela and Suzanna, among others I had interacted with. It was lonely, but necessary for Yuu's sake.

Yuu was raised with utmost care. Boys were precious to begin with, and to me, he felt like Sakuya-san's reincarnation. While my parents helped care for him initially, as Yuu grew older, people became increasingly bothersome... After all, Yuu inherited only the best traits from Sakuya-san and me, growing into an exceptionally handsome child. By age two or three, people were already saying, "He must become our son-in-law someday!" Especially when it came from paternal relatives or half-sisters, I couldn't refuse strongly. Eventually, when Elena entered elementary school, we moved to Saito City in Saitama Prefecture, which had recently formed through municipal mergers. There, I started part-time work at Saitama Chuo Shinbun, a local newspaper.

Though Sakuya-san's inheritance remained largely untouched and I didn't need to work immediately, I wanted to get accustomed to working while I could. For household matters, I decided to hire a housekeeper from a trustworthy agency.

Perhaps the new environment—peaceful and full of nature despite being in the metropolitan area—was good for us. Both Elena and Yuu grew up healthy. Of course, since Yuu was a boy, he couldn't go out much, but at home they got along very well. Yuu was so adorable back then.

"Mom! Big sis! I love you!"

When he said that with a smile, Elena and I couldn't help but hug him tightly and give him kisses. I naturally doted on Elena, my first child with Sakuya-san. But for a mother, a son is special. I truly understood what "so precious you wouldn't feel pain even if he were in your eye" meant.

However, it pained me to teach Yuu to "be careful around women" when he entered elementary school. After all, I had to make him learn to protect himself from women—the same gender as his beloved mother and sister. I heard that once he started school, Yuu became very popular with girls. Since elementary classrooms were co-ed, he was constantly surrounded by girls who competed over him. Even at that young age, they were already women. Though mistakes wouldn't happen yet, my worries never ceased.

Around two years into my job, the newspaper offered me a full-time position, but I asked to postpone it until Yuu graduated since I wanted to take him to and from school. Well, it was good that Yuu himself learned through school that women were frightening and became more cautious.

Watching my children grow daily brought me joy as a parent. On the other hand, I also felt loneliness. The most poignant moment was when Yuu started bathing alone, ending our longtime routine of bathing together. He also began avoiding hugs and kisses. People often say adolescent boys are difficult to handle—how true.

Around when Yuu turned eleven, as he transitioned from child to adolescent, he grew taller and his features became more dignified, blending cuteness with handsomeness. By then, I had started assisting with interviews and editing, taking on more responsibilities. With quasi-employee status and increased pay came longer hours and later returns home. While fulfilling, exhaustion overwhelmed me after work—I was already in my thirties.

One evening, returning home, I found Elena and Yuu had prepared Mother's Day gifts. Elena chose a beautiful floral-patterned handkerchief and scarf. Yuu gave me a bouquet of carnations and a message card reading, "Mom, thank you for everything!" He handed them to me with a smile that belied his usual aloof tone, then hugged me tightly while blushing. Instantly, my tear ducts gave way. Yuu even grew flustered at how much I cried—that's how happy I was.

Because of that, I suppose. After drinking just one glass of wine, I got overly excited and barged into the bath after Yuu, who had gone in earlier with Elena. Seeing Yuu accept it despite his shyness made him unbearably precious. Calling him "Yuu-chan" like when he was little while washing his body, I lost control. Elena seemed the same. In hindsight, I definitely went too far. I'd heard some mothers did such things, but I should have been more careful with a boy's delicate parts. As a mother, I was happy to know he had experienced his first ejaculation—a sign of his growth—and Elena surely accepted everything about her adorable younger brother. But Yuu himself seemed to feel differently.

After that, Yuu became even colder toward me.

Though resentment remained, I avoided mentioning that night and maintained surface-level peace. When Yuu entered middle school, we bought a new condominium and moved. The New Male Protection Law had increased allowances for households with boys, and Sakuya-san's inheritance provided financial leeway. The upper floors of this condominium accommodated two households per section with provisions for resident male protection officers. Boys from middle to high school age faced the greatest danger. To protect Yuu, who was becoming increasingly handsome, this was necessary. Aside from the entrance ceremony, commuting involved chauffeuring by male protection officers. I'd heard middle schools strictly separated genders and had security guards stationed to protect male students, making incidents unlikely.

I became a full-time employee at the newspaper. Though saddened by reduced time with my children after entrusting housework to the housekeeper, I worked diligently for their futures. Just as our new life began, problems arose with the children.

When a family has a male member, girls often pseudo-romanticize him. First loves might be fathers or brothers. If they meet men outside through luck, it could lead to romance and marriage. But in this male-scarce world, outside encounters and romance don't always succeed. Some girls become so fixated on fathers or brothers that they genuinely fall in love, even wanting to have children with them—or so I'd heard from mom friends, TV, and magazines.

In Elena's case, though clingy with Yuu since childhood, it worsened as she grew, fitting that exact pattern. Even when pulling away from parents during rebellious phases, siblings rarely become so estranged. But around middle school, Elena's feelings for Yuu twisted into excessive brotherly love. Understandably, Yuu withdrew and avoided her at home.

Though saddened by Yuu avoiding me, I endured it as proof of his emotional growth. I'd heard boys become calmer and more communicative at a certain age. But Elena was different—the more he avoided her, the more she pursued him. The housekeeper told me this happened while I was at work. Even when I directly told Elena to maintain sisterly boundaries, she only grew more stubborn.

Then last winter, on the night of Elena's final high school Christmas party... I didn't know she had returned home early. Though aware of her intense feelings for Yuu, I never imagined Elena would do such a thing...

Since then, an irreparable rift formed between them. Yuu came to despise Elena, hurling scornful words or ignoring her when they met, while Elena stopped attending school and shut herself in her room. Whenever I tried asking what happened, she withdrew into her shell, refusing to open up.

Just a few years ago, our family of three lived happily together—why had it come to this? At times like this, I wished Sakuya-san were here. Perhaps noticing me crying alone at night from despair, Yuu's attitude softened slightly—he began conversing with me morning and evening, a small mercy amid misfortune. Then, on graduation day, that happened!

Receiving the police call at work, I nearly fainted from shock. When I rushed to the hospital, Yuu was unconscious in critical condition. I was told he had fallen from a pedestrian bridge and hit his head hard. Several nurses restrained me as I panicked, screaming I couldn't live if Yuu died. After a night, hearing he was out of mortal danger brought relief—but overwhelming rage toward the female middle school perpetrators surged immediately.

Just as I prepared to confront them, police arrived at the perfect time and explained details. Allowing such vile crimes would make life harder for men. They promised thorough investigations and severe punishment for both the masterminds and participating students. Hearing this, I had to lower my raised fist. In this world, crimes against males carried strict penalties even for minors.

After entrusting matters to the police, all I could do was pray for Yuu's recovery. During his coma, I took leave from work, abandoning ongoing assignments. Yuu came first. Though my boss smiled wryly at my uncompromising stance, he approved extended leave—I was fortunate to have an understanding superior.

When notified of his regained consciousness during a brief home visit, I rushed back to the hospital immediately. Seeing Yuu safe in his room, I couldn't stop crying. I hugged him so tightly that nurses had to intervene. Though dazed from just waking, his complexion looked fine—a relief. But shockingly, he didn't remember me...

"You're not my mother! My mom isn't this young and beautiful!" What could this mean? My feelings were complicated. His speech had also changed from "boku" to "ore"...

The doctor suggested head trauma from losing consciousness might have caused memory confusion—amnesia, perhaps. At least he only sprained his ankle besides the head injury, with no major damage. We could only wait and observe as he recovered.

The investigation into Yuu's horrific assault progressed faster than expected. Since it occurred outdoors with few witnesses, Yuu's testimony was taken just once in his hospital room—a relief. Cases involving male victims minimized burdens on them.

Personally, I wanted the perpetrators executed. According to confessions, the assault was premeditated and extremely malicious. Despite causing severe injury, rape and abduction charges remained attempted, preventing heavy sentences. Even the three ringleaders would get under ten years imprisonment! Could such trash truly reform? Who would take responsibility if they targeted Yuu again after release?

Fuming with helpless anger, I hired a lawyer through work connections to seek civil damages. My supervisor—a mother of boys herself—fully supported me, saying this wasn't others' business. The security company we contracted sent their president immediately to apologize for failing their duty. Prostrating himself, he promised maximum compensation—they apparently couldn't afford disputes with male families given their reputation. I gave up on holding the middle school responsible after hearing it was impossible. Instead, I demanded no mercy toward the perpetrators' parents, though delays were inevitable.

With condolence money from the government, we contracted a more reliable security company. When introducing the dispatched protection officers to Yuu, I noted the upgrade: previously one A-rank and several B-rank officers, now two S-rank and A-rank officers at the core. The cost was high, but Yuu's safety was priceless.

After thorough examinations showed no issues and Yuu's mental state stabilized, I felt relieved hearing he might discharge before high school entrance ceremonies. I'd worried male assault victims might withdraw completely, even rejecting family women, so this outcome was truly fortunate. Most joyfully, Yuu regained his calm and spoke affectionately like in childhood. But somehow... he had changed. His rebellious phase seemed forgotten. Had overcoming adversity matured him spiritually? I sometimes felt like speaking with an adult rather than a teenage boy. Moreover... his gaze when looking at me and his speech differed from before. This wasn't how one looks at their mother. How should I put it? I couldn't grasp it at first.

But relaxing at home after discharge, I suddenly realized: he resembled my late husband Sakuya-san.

I'd heard of people changing drastically after near-fatal head injuries. Could Yuu be like that? ...Even so, Yuu was Yuu. Above all, my precious son. As his mother, I could accept personality changes—especially since they weren't for the worse. Current Yuu was wonderful: polite, considerate of me returning from work, even mastering simple cooking somehow.

When Yuu was born, I'd jokingly wondered if he was Sakuya-san's reincarnation. Talking to post-recovery Yuu made it feel true, confusing me. One night, returning home tipsy, I staggered in the hallway when Yuu caught me instantly. For some reason, Sakuya-san's face flashed in my mind—flustered, tears wouldn't stop. Yuu held me, gently stroking my head. He seemed more like Sakuya-san than ever... If this continued, I'd want to depend on Yuu as a woman, not his mother. So I deliberately call him "Yuu-chan" like in childhood—to remember I'm his mother.

---

### Author's Afterword

This concludes Interlude 1.  
I plan to start Chapter 2 on Wednesday night.  

2019/5/2: Due to inconsistencies with (Interlude 2) Elena's story, I have revised part of the recollection.

### Chapter Translation Notes
- Translated "精通" as "first ejaculation" to maintain explicit terminology for sexual development
- Preserved Japanese honorific "-san" for Toyoda Sakuya throughout
- Translated "ギューってハグ" as "hug him tightly" to transliterate the sound effect naturally
- Rendered "女の子のデリケートな部分" as "delicate parts" to balance anatomical accuracy with contextual flow
- Maintained original name order (Hirose Yuu) and Japanese terms like "Yuu-chan"
- Translated "新法" as "New Male Protection Law" based on Fixed Special Terms reference
- Used explicit terminology for the bath incident without euphemisms