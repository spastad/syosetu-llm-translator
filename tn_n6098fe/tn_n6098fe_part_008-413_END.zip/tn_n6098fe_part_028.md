## 23. Student Council ① ~Just By Your Side~

### Author's Preface

The first half is from Sayaka's perspective.

The latter half shifts to a third-person (Emi) perspective.

---

Komatsu, the two- and four-wheel vehicle manufacturer that forms the core of the Komatsu Group, began as Komatsu Loom Works, founded by my great-grandmother in the early 20th century.

The company continued to develop under my grandmother and mother, who succeeded my great-grandmother, and now boasts one of the world's highest sales volumes for both two- and four-wheel vehicles, with the name "KOMATSU" known worldwide.

I, Komatsu Sayaka, as the heiress of the Komatsu family, am in a position to carry the group on my shoulders in the future.

My younger sister Kiyoka, three years my junior, had a superior intellect to mine, but her health was not very robust, and she spent much of her childhood recuperating at home.

Perhaps because of that, she became deeply immersed in a wide range of literature, from classical works to light novels and manga for girls.

Not only did my sister voraciously read with passion, but she eventually began writing novels herself, and by the time she was in middle school, she was submitting her work to literary magazines.

I've had the chance to read a few of them, and I remember being surprised by their quality—so impressive that it was hard to believe they were written by a middle schooler. Though the protagonist was set as a middle school student, modeled after herself, the content brilliantly elevated her knowledge, accumulated since childhood, and innovative ideas—so novel I wondered how she came up with them—into the form of a novel.

It would have been fine if it remained a hobby, but after winning a newcomer award in a girls' magazine as the youngest recipient, she began pursuing the path of a writer, leading to a strained relationship with our mother—a headache for me as her sister.

In any case, as the successor to a major corporation, I strive to excel not only academically but also in both literary and martial arts, diligently training at the dojo run by our family.

In high school, I didn't quite achieve the top rank, but I attained a position within the top five in terms of grades, and as student council president, I lead student autonomy.

Since I became engaged to a boy my age, born to an executive of a major company with which we have long-standing business ties, when I was thirteen, I consider myself fortunate in this world where women vastly outnumber men.

I've had monthly rendezvous with him, but I've struggled to close the distance between us.

During our meetings, I'm usually the one doing most of the talking, and he avoids facing me directly or touching me.

It took about two years from our first meeting until I could finally hold his hand.

Due to security reasons, we mostly met indoors, but that time, we were strolling through the garden of a detached palace owned by the imperial family—a rare occasion—when he almost tripped on a step in the stone pavement.

Even then, he immediately pulled his hand away, and I remember feeling a twinge of sadness.

I've heard that unlike women, men have low interest and sexual desire for the opposite sex, so perhaps it can't be helped.

Occasionally, when I attend parties with my mother, I hear girls my age boast about how intimately they're dating boys.

I listen with a smile while suppressing my frustration.

What's the difference between them and me?

...No, I know.

It's that he's scared of my attitude and tone of voice.

I, too, am a girl of marriageable age. My interest in boys and sexual desire are just as normal as anyone else's.

I sometimes find myself staring rudely at his androgynous face and slender, delicate body.

But as the future bearer of the Komatsu Group, I must lead, not fawn over men.

He is my spouse, necessary for producing children as the next head of the Komatsu family.

Emotions are unnecessary there.

Even as I told myself that, the loneliness that arose in my heart didn't disappear.

Since our families arranged the engagement, it won't be broken.

My destiny is to endure the present, marry him after graduating from university, bear children, and succeed my mother.

I never doubted that.

Until I learned about the new student Hirose Yuu, invited him to the student council, and grew close to him...

"Nn... Ufuh... Chu, chup... Nnn..."

Sitting on the tatami and embracing each other, I had been savoring Yuu-kun's lips for a long time before pulling away to look at his face.

When our eyes met, his half-open eyes meeting mine, a smile naturally spilled out.

We reached out to stroke each other's cheeks and hair.

I never imagined the day would come when I could stroke a boy without reservation.

Even more, I never knew having my hair stroked by a boy could feel so pleasant.

There are still so many things I don't know about the world.

"Sayaka-senpai, your kissing has improved quite a bit."

"R-really? Do you think it feels good...?"

"Yes. Kissing you feels good, senpai. So, more..."

What a delightful thing to say.

I want to kiss more too.

While embracing and kissing Yuu-kun, I feel a throbbing deep inside my body and notice my private parts getting wet.

I want to push him down and take Yuu-kun's chinko right away.

Such desires are arising.

But I learned the other day not to rush.

Yuu-kun suggested it himself and is teaching me the practice of romantic interactions through his own body.

A woman shouldn't greedily seek pleasure from a man unilaterally.

It's important to build up the mood together, confirming each other's feelings.

Yuu-kun makes me realize what's important.

As I pressed my lips against his again, kissing with light pecks like a bird pecking, I unbuttoned Yuu-kun's shirt from the top down.

Suppressing the urge to rip it open all at once, I undid each button carefully.

My excitement rose as more of his skin was exposed.

At the same time, one of Yuu-kun's hands slipped under my sailor uniform, lifting it up.

His other hand had been playing with my hair and stroking my neck, cheeks, and behind my ears since earlier.

"Nn... Ah... Ah... An..."

As Yuu-kun's hands moved faster, the heat inside me intensified.

My breasts, which suddenly grew when I was 13 or 14.

I thought they were just useless fat until I had children, but strangely, Yuu-kun likes them.

Ah, I never knew being touched by a boy could feel this good.

After finishing unbuttoning, I lifted his T-shirt inside and savored Yuu-kun's skin.

I love Yuu-kun's upper body, where I can feel the sensation of his bones through his lean flesh.

I ran my fingertips and palms over his smooth skin, from his sides to his back and then to his chest.

"Fe... Nn, ah... Sa- Sayaka-senpai..."

I covered his mouth as he let out a cute moan.

Then I slipped my tongue inside, fully tasting the inside of Yuu-kun's mouth.

Yuu-kun also stuck out his tongue, and our mucous membranes touched and stuck together, wriggling against each other.

"Nn... Nn! Afuu... Nn, nn, amu, leroo... Ah... Nmu... Fuwa... Ahn..."

As our tongues intertwined, my head grew hot and fuzzy.

But my tongue, as if it were a separate creature, moved incessantly, making wet sounds as we sought each other.

I could tell my crotch was already soaking wet.

I never knew just kissing could make me feel this way.

Sex isn't just about inserting an erect penis into the vagina and having him ejaculate.

It's only been about ten minutes since we entered this waiting room. Foreplay has just begun.

Last Saturday, I had to wear my panties while they were still wet, and I changed them as soon as I got home.

But today I brought a change, so it's okay. Yeah.

How long had we been deep kissing?

When we parted our lips, a string of saliva stretched between our mouths.

Yuu-kun was looking at me with feverish eyes.

Being stared at like that, I...

Yuu-kun is just a cute underclassman, that's all he should be...

Not only does my core feel incredibly aroused, my excitement only growing, but my desire for Yuu-kun overflows.

I tried to kiss him again...

"Hyan! Yu, Yuu-kun?"

"Fufu. Sayaka-senpai's oppai."

"Hey... Haa... Nn!"

Before I knew it, my bra had been undone, and Yuu-kun was pinching my nipple with his fingers.

Not only that, but Yuu-kun lowered his head and sucked on my breast.

"N-no... Ahi!"

"Eh, no? Nmuu. Like this?"

"Ah, ah, Yuu-kun! That, my nipple... Ann!"

While teasing my left nipple with one hand, he took my right nipple into his mouth, rolling it with his tongue and sucking on it with chu-chu sounds.

At first, I thought it was like a baby.

But why does it feel so good?

I'm making unexpected noises, and the throbbing deep inside won't stop.

Even though Yuu-kun said it was his first time the other day, it's strange how knowledgeable he is about a woman's body, but I had no room to think about that.

My body reacted sensitively to Yuu-kun's caresses, and I let out indecent sounds.

◇ ◆ ◇ ◆ ◇ ◆

Today is Monday.

Normally, there are no student council activities on this day.

But Ishikawa Emi, suppressing the pounding in her chest, hurried toward the dormitory building where the student council room was located.

She was now in love.

The object of her affection was Hirose Yuu, a first-year student who had just joined the student council.

At Sairei Academy High School, in principle, dating between boys and girls is permitted starting from the second year (though in practice, some deepen their relationships from the first year through club activities, which is tacitly permitted).

By requesting a meeting in advance and being accepted by the boy, girls can talk to them during breaks or after school.

For that, they need to have the boy remember their face and name during first-year exchange events and leave a somewhat favorable impression.

However, not everyone could smoothly interact with boys.

At the start of the second year, not all boys were immediately receptive.

Though the competition rate is more favorable compared to the outside world, at that point, only a few—about one or two girls per class—had started dating boys.

The day after the entrance ceremony, in April when first-years became second-years, Emi, who had failed to form a friendship with a boy, decided to go scouting near the boys' classroom with friends in the same situation.

They checked the boys getting off the dedicated boys' shuttle bus and entering the entrance of the second school building.

They didn't particularly intend to do anything.

It was just the curiosity typical of girls their age—wondering what kind of boys were in this year's first-year class.

Especially in April, just after new students arrive, the number of girls like Emi who come to scout increases.

As long as they don't barge into the boys' classroom or lay hands on the boys, the school tacitly permits just looking.

A rope was stretched about 10 meters from the entrance in advance, and the gathered girls waited impatiently for the bus to arrive.

8:20 AM. The first bus arrived. By then, nearly 100 girls had gathered.

The first one seemed to be a minibus on the route that goes around Saito City.

Probably about a dozen boys were on board.

It parked about 5 meters from the entrance, and the door on the side of the vehicle for boarding and alighting opened.

Thanks to securing a spot an hour earlier, Emi was at the front row and smiled as the long-awaited moment arrived.

Boys got off the bus one after another.

"Here we go again," some third-years seemed to think as they glanced and remained calm.

Since more than half of the third-year boys were already taken, targeting them was risky.

Still, some girls called out names and screamed, perhaps because there were promising boys.

The boys who looked startled by the crowd of girls and averted their eyes in a fluster were surely first-years. So innocent.

Amidst this, one boy who got off looked over the girls casting passionate gazes with a dignified attitude.

A black jacket that suited his slim build well.

He seemed relatively tall for a boy.

His straight, unassuming black hair swayed smoothly in the spring breeze.

His well-defined, handsome face was dignified, and his wide-open eyes were gentle.

Second and third years have only about thirty students per class. Emi remembered the faces and names of the boys.

The beautiful boy before her wasn't in her memory.

Meaning, a first-year?

A stir spread even around Emi.

"Wow, isn't he super handsome?"

"Could a male idol have enrolled?"

"No, no, no, he's way beyond any ordinary idol!"

"Hwa~. Just looking at him makes me horny."

He smiled faintly and looked in her direction.

At least, Emi felt their eyes met.

In that instant, Emi experienced a shock for the first time in her life.

In other words, she fell in love.

"Ufufu. I wonder if Yuu-kun is here today?"

As she approached the dormitory building, Emi's steps lightened, and her flaxen hair, tied in twintails today, swayed.

Though unofficial, since joining the student council and starting activities together, she quickly realized he was drawn to the student council president—whom Emi called Sayaka-senpai.

In truth, the beautiful and academically excellent student council president was popular regardless of gender.

Though boys are in a position where girls come to them without them having to do anything, apparently several boys wanted to date Sayaka-senpai.

However, being the daughter of a major corporation and having revealed that her parents had arranged her engagement, the boys, already lacking in initiative, gave up early.

Probably, Yuu-kun would also end up just admiring her from afar.

So, if she became close to him by then, he might turn to her.

She had such calculations, but when she was alone with him, she ended up pouring out her feelings.

She felt a moment of regret when she confessed, but it didn't matter.

The women of the Ishikawa family believe in brightly and cheerfully making the first move.

That's how her grandmother and mother were able to date men and have children.

Even if rejected, she'd just keep attacking!

She thought quickly in that short time.

She was prepared to be rejected after a sudden confession.

But his reaction went beyond her expectations.

He suddenly hugged her and whispered in her ear:

"Emi-senpai is very cute."

Realizing her ears were bright red after being told that by the boy she liked.

"I'd be happy if Emi-senpai became my girlfriend.

Let's be close friends from now on, okay?"

After that, she was so overjoyed her head stopped working, and she felt like her legs might give way—unbelievably, she was being held in his arms!

She probably blurted out "I love you!" while feeling his warmth.

Now, both her body and heart were captivated by him.

"Since the Newcomer Welcome Orienteering explanation meeting is soon, Sayaka-senpai must be here today too. So, Yuu-kun might be here as well. Yuu-kun, please wait for me!

...Huh?"

At the entrance of the dormitory building, she saw a familiar third-year student about to enter.

"Riko-senpai!"

"Huh?"

With an intelligent impression, an oblong face and silver-rimmed glasses. Her slightly unruly black hair was tied in a single bundle and flowed over her shoulder.

"Riko-senpai, are you going to the student council room too?"

"Y-yes. I have business with Sayaka."

Unusually for a student at this school, Hanmura Riko—Riko-senpai—had no interest in boys.

Sairei Academy High School is certainly among the advanced schools, but with her academic excellence, ranking first or second in the grade except for physical education, she could have gone to a top prefectural school.

So why did she choose Sairei Academy?

Emi heard after entering high school that she was close friends with Sayaka since middle school, having attended the same middle school.

Even now, she was trusted enough to be called Sayaka's right-hand woman in assisting her.

The fact that the student council, normally with a capacity of five members, could manage with just three was largely due to the president and vice president being a well-matched pair.

But after half a year of activities together, Emi had noticed.

Riko-senpai held feelings for Sayaka-senpai beyond friendship.

That's why she deliberately chose the same high school.

On nights when student council activities ran late, she often stayed over at Sayaka-senpai's apartment, which was very close, and now she even had a set of overnight gear.

However, Sayaka-senpai seemed unaware, treating her merely as a close friend.

"I'm sure Sayaka is already here. Shall we go?"

"Yes!"

Responding cheerfully, Emi followed behind Riko, who led the way.

She knocked on the student council room door, but there was no answer.

Tilting her head slightly, she confirmed the doorknob turned and opened the door.

"Huh?"

"Hmm? No one's here."

The student council room was empty.

"But their belongings are here..."

Around the seats where Sayaka and Yuu usually sat, their belongings were placed, but nothing was spread out on the desks.

It gave the impression they had come to the student council room, left their things, and immediately gone out.

"Huh? That's strange."

"Hmm... Maybe they went to buy something?"

Riko approached Sayaka's seat, and Emi approached Yuu's.

After a moment of contemplation, Riko lifted her head.

"Hey, can you hear something?"

"Huh? ...Now that you mention it..."

Listening carefully, Emi heard a feminine voice.

The windows weren't open, so it wasn't outside. It seemed very close.

"This way!"

Riko approached the partitioned-off tea preparation room to the left rear after entering the student council room.

Emi followed.

Entering the tea preparation room, the voice became clearer.

"It's from the waiting room. Sayaka and them? Hmm... But what are they doing?"

(Eh... is this...?)

Riko didn't seem to have a clue, but Emi had an idea.

It sounded like the moans from an AV (adult video) a friend had shown her before.

But unlike that AV, now she only heard a woman's voice, with almost no man's voice.

"Riko-senpai, why don't we open that door quietly?"

"Y-yes."

Feeling it would be bad to open the door suddenly, Emi whispered to Riko in a small voice.

Probably having sensed something by now, Riko nodded stiffly.

The two opened the waiting room door without a sound.

What entered their vision was Sayaka, on top of Yuu who was lying on his back, swinging her hips desperately, her long hair disheveled.

---

### Author's Afterword

I always look forward to the continuation of a certain Chastity Reversal work, and when I read the latest chapter last week, it was interesting but at the same time shocking.

Why? Because, coincidentally, the content from the latter half of this chapter to the first half of the next overlapped with it.

I had planned this flow from the beginning to involve the two student council members, and it was almost written.

However, that work was updated first.

Even if it looks like I copied, I have no choice but to explain. I'll say in advance that the flow from there onward is different...

2019/7/24

Before introducing the younger sister Kiyoka in the main story, I revised the part about the sister in the flashback scene.

### Chapter Translation Notes
- Translated "おチンポ" as "chinko" (slang for penis) to maintain explicit terminology as per style guide
- Translated "喘ぎ声" as "moans" in context of adult content
- Preserved Japanese honorifics (e.g., -senpai, -kun) throughout
- Transliterated sound effects: e.g., "んっ" → "Nn", "ちゅっ" → "Chu", "ぱっ" → "Pa", etc.
- Used explicit terms for sexual acts and body parts (e.g., "nipple", "breast", "crotch", "penis") as required
- Maintained original name order for Japanese names (e.g., Komatsu Sayaka, Hirose Yuu)
- Italicized internal thoughts (e.g., "*What's the difference between them and me?*")
- For the term "ＡＶ(アダルトビデオ)", translated as "AV (adult video)" with the abbreviation explained
- Translated "控え室" as "waiting room" (context: student council annex room)
- Handled dialogue formatting: new line for each speaker, with attributions kept with the dialogue when present