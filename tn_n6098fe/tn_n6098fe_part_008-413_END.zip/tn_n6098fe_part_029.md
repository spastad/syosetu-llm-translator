## 24. Student Council ② ~Unstoppable Lust~

### Author's Preface

I've inserted the character introductions at the beginning of Chapter 1.

I plan to update the content around the end of each chapter.

---

"Ah, ah, ahhh! I-It's amazing... so good! Yuu-kun's cock... reaching deep inside me... aahn! I'm... I'm gonna cum!"

"Ahh... Sayaka-senpai, it feels so good for me too... ngh! D-don't squeeze so tight!"

"B-but my hips... they're moving on their own... uuuh"

  

"Eh? No way... S-Sayaka, why?"

"Fueeeee... Yu-Yu-kun? That's..."

Through the door crack Emi and Riko were peeking through, they could see the two coupling from a diagonal rear angle.

Both Emi and Riko were shocked by the sight before their eyes, but couldn't speak, only staring dumbfounded.

The disheveled state of the pair was unlike anything they'd seen before.

  

Yuu had one hand on Sayaka's hip while the other kneaded her jiggling breasts.

How long had they been joined?

A glimpse of Sayaka's face showed it flushed pink, mouth hanging open lewdly as she moaned.

  

*Schlick, schlick, schlick!*

The sounds they'd been hearing were coming from where the two were connected.

Neither Emi nor Riko had ever seen real sex before.

Moreover, they were fellow student council members.

Seeing familiar people coupling right before their eyes. They felt confused by how strangely arousing it was.

  

"Whoa..."

Since both were only naked from the waist down, they could see Sayaka's pussy spread wide, not just swallowing Yuu's thick cock but glistening wetly and twitching.

In the AVs Emi had seen, mosaics obscured how male and female genitals connected.

The concave and convex parts of their bodies were joined as if flesh intertwined.

The reality was far more obscene than she'd imagined.

  

Emi stood while Riko crouched to watch.

Naturally positioning themselves - Emi wanting to see Yuu, Riko wanting to see Sayaka's ass and their joined parts.

  

"Nghh... Yuu-kun..."

A throb ran through Emi's lower abdomen.

*(Yuu-kun's cock is going deep inside Sayaka-senpai's pussy)*

Unconsciously, she pressed her thighs together, covering her crotch.

She realized she was wet.

  

"Haaa... S-Sayaka's pretty pussy... sucking Hirose-kun's cock, spread so wide... she looks so pleasured... akuu"

Glancing at Riko, she saw her sucking her finger while fidgeting.

  

"Aaah! Ooh...n...aaah! Yuu-kun! Yuu-kun! I'm...!"

Sayaka, having discarded her usual composure, moaned like a beast in heat.

Her hips pistoned faster in response.

*Slap, slap* - flesh-smacking sounds echoed.

  

"Senpai, you look so pleasured, so beautiful. It's fine. You can cum first."  
"Ahh... Yu...kun"

Yuu extended both hands for a "lover's link" hold.

As if shifting gears, Sayaka rocked her hips while raising her voice higher.

"An! An! An! Good! Cumming from Yuu-kun's cock, cumming! Aaaahhhh!! Aahn! I-I'm cumming!!"

That instant, Sayaka arched her back looking skyward before collapsing onto Yuu.

  

As Emi and Riko watched, their coupling continued.

The hip movements slowed but Sayaka kept wriggling her white butt while seemingly kissing Yuu, hugging his face.

  

*(Uu, I'm jealous... I want to kiss Yuu-kun like that too!)*

Emi, who'd gotten wet just from being hugged and whispered to days earlier, wondered what would happen if Yuu kissed her.

Just imagining the passionately kissing pair made her lower abdomen throb and grow wetter.  
"Ahhaa... Yuu-kun..."

She lifted her skirt and touched her panty crotch.  
Already soaked.

Riko below was similarly lifting her skirt and fingering herself.  
Though her gaze remained fixed on Sayaka's white ass and their joined parts.

The door crack had widened unnoticed as the pair grew more excited and leaned forward.

  

While they watched intently, Yuu sat up while holding Sayaka.

Crossing his legs, they faced each other embracing.

After adjusting positions, they kissed. Kissed. Kissed.

Between kisses they seemed to exchange whispers, but the watchers couldn't hear.

Watching this, Emi felt nothing but envy. The unfamiliar sight of the pair and the *smooching* sounds excited her as she pleasured herself.

  

Meanwhile, Yuu's right hand stroked Sayaka's head while his left slid under her sailor uniform to grope her back.

Her bra seemed already removed, so unimpeded, his hand traveled from her slim waist to her sides, up her spine to her shoulder blades.

Sayaka fully opened her unbuttoned striped shirt and pushed up her T-shirt to touch Yuu's skin directly.

Seeing Yuu's flank excited Emi so much she leaned forward.

  

With clothes pushed up to their chests, skin pressed together, Yuu began thrusting upward.

"Uwaaan! Ah! Ah! Ah! Aah!"

Sayaka clung tightly to Yuu.

*Thump, thump, thump* - rhythmic flesh-smacking sounds echoed.

  

"Hyauu... this... Yuu-kun's hot hard cock... f-feels like it's piercing deep inside... haa! Ah! An! So good!"

"Ahh... I feel deeply connected to senpai too... with every thrust it feels like my whole length is being milked... kuh, incredible"

  

With each upward thrust, Sayaka's long black hair and breasts swayed as the cock struck deep inside.

Her descending cervix being knocked stimulated her feminine instincts, making her unconsciously wrap both legs around Yuu's waist.

Rubbing cheeks, they embraced tightly. Their unified up-down movements didn't take long to bring both toward climax.

  

"Ngh... S-Sayaka-senpai... I'm close too..."  
"A, ahi...nnn! Ngaau! M-me too... aahn! I-I'm cumming again. Being made to cum by Yuu-kun"  
"Then... let's cum together? Okay?"

When Yuu whispered in Sayaka's ear, his gaze flickered toward the door, showing momentary surprise.

But they couldn't stop now.

He thrust harder.

  

As Yuu began his final sprint, Emi and Riko were also aroused, masturbating intensely.  
Fingers working their crotches, making *squelching* sounds.

"Haa... amazing..."

To Emi, sex only meant cowgirl position where women rode men lying like fish.

In AVs she'd seen men moan too, but a know-it-all friend said it was mostly acting.

In real sex, men only vocalized during ejaculation.  
Truly pleasuring men during penetration required expert technique.

  

But what about this pair before her?  
They embraced tightly, mutually seeking, heightening, feeling each other's pleasure.  
Watching made her body hot, arousal uncontrollable, jealousy overwhelming.  
She just stared at their union, breathing heavily while frantically moving her fingers.

  

As Emi and Riko watched, Yuu and Sayaka's coupling approached its end.  
Deeply joined, they moved with undulating hips. Inside, the tip gouged her cervix.

  

"Uggh! I'm... cumming! Cumming! Sayaka-senpai!"  
"Ha, ha... m-me too... cumming cumming... aaahn! Amazing! It's swelling inside"  
"Ugh!"  
"Aaaaaaahhhhhhh!!! C-c-cumming uuuuuuuuuuuu!!!"

  

The instant Sayaka hugged Yuu's head, looked skyward and cried out as she came, thick pulses of Yuu's semen flooded her womb.  
Feeling the long pulses, Sayaka moaned "Ah... hau... fuun" as if overcome.

After the long ejaculation, when Sayaka's chin dropped, Yuu covered her lips.  
Sayaka still felt heat inside, dazedly savoring the kiss.

  

"Senpai. Um... we've been seen by those two."

Hearing Yuu's words after their lips parted, Sayaka's eyes flew wide open.  
She turned her head robotically *creak creak* to look diagonally back.  
"Riko, and even Emi..."  
""Ah!""

After meeting eyes, all three averted their gazes awkwardly.

  

Yuu thought it was better that it was these two student council members rather than unrelated students or teachers.  
Today wasn't a student council day, but discovery was inevitable.  
This might be a good chance to bring them into the fold.

  

"You two, instead of watching there, why not come here?"  
"Eh?"  
"For real?"

  

Emi immediately reacted and rushed out.  
But stopped short.  
"I-is it okay?"  
"It's fine, right? Sayaka-senpai?"  
"U, uhn..."

  

Asked by Yuu, Sayaka was at a loss for words.  
Her mind couldn't keep up with the situation.  
Yuu gently stroked Sayaka's cheek.  
While tensing his lower body, he said:  
"Since we're this far, let's all be together."  
"Ah...nn!"

Semen spurted *pyurutt* from the still-inserted cock.  
"Seriously..."

Sayaka glanced at Riko.  
"Sayaka... sorry for peeping..."  
"No, I got carried away too..."

  

"Yuu-kun..."  
Blushing, Emi approached Yuu.  
"Emi-senpai"  
"Me... me..."

Sitting down beside him, Emi gazed passionately at Yuu but averted her eyes upon seeing him still joined with Sayaka.  
Then Yuu extended his left hand.

  

"Eh?"  
He took Emi's unconsciously offered hand and pulled her close.  
"Ah"  
Pulled into an embrace.  
"Yu... Yuu-kun! Me too...!"  
Emi hugged Yuu tightly, burying her face in his neck, rubbing against him.  
Her twin tails *fusaah* swayed against Yuu.  
Yuu patted her head soothingly before sliding his hand down her back to her butt.  
Then lifting her skirt hem, he slipped his hand inside.

  

"Hyan!"  
"Emi-senpai, your panties are soaked.  
You were masturbating while Sayaka-senpai and I had sex, weren't you?"  
"Fah! St-stop! Ann!"  
"Then..."

Meanwhile, Riko had drawn close enough to touch Sayaka, so Yuu reached to lift her skirt.  
"Hyaa! Eeh!?"  
His finger touched the polka-dot panty crotch - soaked like Emi's.  
"W-what are you doing!?"

Riko immediately escaped Yuu's hand but clung to Sayaka from behind.  
Meanwhile, Emi writhed as Yuu played with her private parts.  
"Ah, aahn... d-don't play... there..."

Despite saying "don't," Emi pressed closer to Yuu with sweet moans.

  

After looking at all three, Yuu grinned and declared:  
"Since we're here... why don't we all do it together?"  
"Um..."  
"Huh?"  
"An..."

  

Emi reacted first to Yuu's words.  
"I want too... to hold Yuu-kun like Sayaka-senpai!  
Watching you two having sex... I got so jealous, and my lower belly started aching... ah, Yuu-kun, I love you!"

Emi, who'd been sniffing Yuu's sweaty scent at his neck, looked up with heated eyes.  
Yuu turned and gave her a light *chu* kiss.  
At the sudden act, Emi went "Feh?" and flushed crimson.

  

*(Yuu-kun...)*  
Seeing them kiss, Sayaka was confused by sudden jealousy.  
She had a fiancé.  
They'd only met less than a month ago, just senior-junior in student council.  
They weren't dating.  
Yuu just advised her when her engagement was troubled, teaching her about boys. That's all.  
Yet after skin contact, she'd developed this desire to make him hers?  
Of course, these days, boys dating multiple girls was normal but...

  

As complex emotions warred within Sayaka, Riko suddenly spoke:  
"I... I've liked... S-Sayaka for a long time!"  
"Eeeh!?"  
Riko hugged Sayaka tightly from behind.  
The motion made the cock slip out *nyururi*.

  

""Ah!""  
Semen oozed from the freshly vacated vagina.  
"Bad. Ti-tissue!"  
Yuu reached behind for the tissue box by the pillow.  
Then handed it to Riko.  
"Riko-senpai, could you wipe Sayaka-senpai down there?"  
Dumbfounded at first, Riko smiled knowingly upon understanding.  
"Leave it to me. I'll wipe Sayaka's precious place."  
"Eh? Um... Riko? Ah"  
"Whoa trouble! So much dripping down!"

  

Meanwhile, Emi was fixated on Yuu's cock.  
Though softened slightly after ejaculation, it remained hard and upright.  
Having just been inside Sayaka, it glistened wetly, looking even lewder.  
"Th-this is Yuu-kun's cock... bigger than I imagined"  
"Want to touch?"  
Asked at lip-touching distance, Emi's eyes darted between Yuu's face and crotch, but her heart was decided.  
"Yeah. Let me touch Yuu-kun's cock. I want to touch"  
Emi's hand reached for the cock.  
"Ahh... hard and... hot. Yuu-kun's cock is amazing..."

Though tentative with her first male genital touch, Yuu's cock swelled and curved back as she stroked.  
While kissing Emi longer this time, Yuu glanced at Riko with one eye.

  

"See? More's coming out. Gotta wipe properly so the futon doesn't get dirty. Right?"  
"W-wait! R-Riko! N-not like that... ah...nnn!"  
Riko's lips silenced Sayaka's protest.  
After wiping with tissue, Riko inserted fingers *squelch squelch*.  
The fluid seeping out was clearer but still slightly cloudy.

  

*(They're having fun over there. Then I'll enjoy Emi-senpai. Senpai, but she's so cute)*  
By his original world's standards, Emi would rank among the cutest girls in class.  
Being told "I love you" by such a girl couldn't not make him happy.

  

When Yuu slipped his tongue in, Emi flinched but accepted.  
After licking her mouth *lero leron*, their tongues entwined.  
"Fah... anmmu... chupa... nn, nfu... ann... Yuu-kun... love you"  
Emi, dreamy from Yuu's tongue ravaging her mouth, tried moving her tongue to match.  
Her first kiss with beloved Yuu. Her first adult kiss beyond textbook knowledge.  
Emi's mind was dyed pink.  
One hand clumsily but earnestly stroked the erect cock while the other clung to Yuu's neck, lovingly stroking his head.  
Naturally, her privates dripped far more nectar than during her peeping.

  

Yuu's left hand left her pussy to knead her butt, enjoying the elastic flesh, then slipped under her panty elastic.  
"Hyan! Yu, Yuu-kun? Ah, ann!"  
When his finger traced Emi's slit, he immediately felt slippery wetness.  
Just slight movement coated not just his fingertip but his whole finger in her juices.  
The pussy play made Emi break the kiss.  
Saliva strands *dangled* between their mouths.  
Yuu smiled his usual refreshing smile at Emi.

  

"Emi-senpai, want my cock inside here?"

Emi had no reason to refuse.  


### Chapter Translation Notes
- Translated "おチンポ" as "cock" following explicit terminology rules
- Preserved Japanese honorifics (-kun, -senpai) throughout dialogue
- Transliterated sound effects (e.g., "schlick" for ずっちゅ, "slap" for ぱしん)
- Maintained original name order (Hirose Yuu, Komatsu Sayaka)
- Rendered internal monologues in italics (e.g., *Uu, I'm jealous...*)
- Translated anatomical terms directly ("pussy" for おマンコ, "semen" for 精液)
- Used explicit descriptions for sexual acts per translation style guidelines
- Applied simultaneous dialogue formatting for collective reactions (""Ah!"" for 「「あっ」」)