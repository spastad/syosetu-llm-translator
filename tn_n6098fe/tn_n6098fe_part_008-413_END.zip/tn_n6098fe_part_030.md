## 25. Student Council ③ ~If I Held You Tighter~

"Sayaka's breasts are surprisingly large, aren't they?

No, it's fine. I'm not being sarcastic - I like them.

Because, look. They're so soft and pleasant to touch.

Oh my, what's wrong?

That's right. Girls can feel their nipples too. I realized while touching myself while thinking about you, Sayaka. 

Fufu. Maybe you've become sensitive because Hirose-kun touched you?

Look how stiff they are!"

"Ah, nnn! R-Riko, between girls... doing this kind of thing..."

"In this world with so few men, it's fine for girls to fall in love with each other.

Whether it's an all-girls school or co-ed, you know there are quite a few girl couples, right?"

"Th-that may be true but... ahn! Even so... kuh! S-stop that!

W-wait! My body's become sensitive after coming so many times with Yuu-kun... aah!"

"Not just Hirose-kun, I want to love you too, Sayaka. Please?

I've kept these feelings hidden because I thought you'd hate me if I confessed, but I can't hold back anymore."

"I could never hate you, Riko... mmph!"

"Mmmchu! Fufu, I'm so happy. Sayaka, let me kiss you more."

"Ri...Riko... nn, fuu... ah...nn..."

***

From Yuu's perspective, it was surprising that the always serious and calm Riko had been hiding such intense feelings.

Though likely her first time, Riko's caresses seemed practiced - perhaps from years of masturbating while imagining this moment. Unlike typical virgin boys, factors like their same gender and Sayaka having just had sex with Yuu probably played a role. Sayaka appeared to be melting under Riko's techniques without a chance to resist.

Moreover, watching two beautiful senpai-level girls being lesbian right before his eyes was incredibly arousing.

As Yuu stared intently, a hand touched his cheek.

"Yu-kun, look at me."

"Ah, sorry."

Fresh, soft lips sealed Yuu's mouth. A sticky tongue invaded his mouth, immediately met and entwined with his own.

"Nnn... Emi-senpai's kiss... feels so good."

"Mmmph~. Fah... am... chup, nn, slurp... nnaah, Yu...kun. Chuu, chuu, ahhaa... Because kissing Yu-kun feels so good... Even your saliva tastes delicious..."

With flushed pink cheeks and a thoroughly melted expression, Emi continued devouring Yuu. After experiencing her first kiss with Yuu, Emi had transformed into a kissing demon. She covered every inch of his face - forehead, nose, cheeks, chin - with kisses and licks, ignoring when Yuu said it tickled. It resembled an animal marking its territory.

Emi's lower half was already naked, having discarded her skirt and panties without shame before Yuu could even see the pattern. "I want it like Sayaka-senpai just now," she'd said, and they'd been kissing while embracing frontally. Yuu's hardened cock pressed against Emi's lower abdomen, and the endless flow of her love juices had soaked even the area beneath Yuu's buttocks.

Opening his mouth while intertwining tongues, Yuu reached behind her to unhook her bra clasp. He lifted her sailor uniform's hem. Removing the white floral half-cup bra made her breasts spill out. Yuu reached to confirm them.

"Nnn? You want to touch a girl's chest?"

"Yeah. I want to."

Judging from Sayaka and Emi's reactions, men in this world might not have much breast obsession. During Yuu's student days, he'd excitedly discussed topics like whose breasts were amazing, wanting to touch them just once, or how erotic it was seeing bras through blouses with friends. But since being reborn, such conversations never occurred in class. *What a waste*, Yuu thought.

Ending the kiss temporarily, Yuu faced Emi's chest. They weren't particularly large, but her slender upper body had bowl-like swellings that protruded forward rather than sideways. Probably C-cup - beautiful breasts with moderate size. Her areolae and nipples were small and pale pink.

"Ah, Emi-senpai's breasts are so beautiful."

He instinctively sucked on one nipple while cupping the other with his hand.

"Ah... Yu, Yu-kun? Nnn... hah, fuu... nnaah! I-it feels... ah, like a baby... but... w-weird... ah, ahn! Yu-kuuun!"

"Chupa, chupa, nn... lero, leroo... hafuu, Emi-senpai's breasts taste delicious."

"T-tasty? Nothing comes out? Haaah! D-don't suck like... that!"

Yuu took Emi's breast into his mouth, rolling it with his tongue and sucking the nipple. His right hand gently kneaded while palm-massaging the nipple. The winter-bud-like tiny tip swelled puffily and hardened under stimulation.

Though it was her first breast caress, the impact made Emi tremble while intoxicated by intense pleasure. As she lovingly hugged Yuu's head and stroked his hair, transparent fluid dripped down her thigh.

"I can't wait anymore! I want Yu-kun's cock inside me now!"

Clutching him as if to push him down, Emi raised her hips for insertion. Indeed, women's libido seemed strong in this world. Based on Yuu's limited knowledge, women might enjoy foreplay more, but Emi eagerly pressed forward wanting union.

"Needless to ask, but is this Emi-senpai's first time?"

"O-of course! First kiss and first sex. And... you're the first I've truly fallen for!"

Panting with rough breaths, Emi looked thoroughly aroused. Intense joy surged within Yuu. Though Sayaka was currently his favorite, that was separate - this was different. Men were allowed to love multiple women in this world. With such a cute senpai making passionate appeals, he had no reason to refuse.

"Receiving Emi-senpai's virginity makes me happier than anything."

Tears overflowed from Emi's eyes, startling Yuu. But it was understandable - while many boys lost their virginity before graduation, far fewer girls managed to lose theirs despite their wishes.

"Ehehe. You're so sweet, Yu-kun. I'm so glad I fell for you! Now, I'll put it in..."

As Emi slowly lowered her hips, Yuu supported her slender waist.

"L-like this... ah!"

"Nn... yes."

The cockhead touched her vaginal entrance. With a squishy sound, warm, soft mucous membrane greeted him. Once the tip entered, gravity should do the rest. But being a virgin, her vaginal flesh immediately resisted penetration.

"Gah! Yu-kun's cock... ghi! S-so big... nhii! Sorry, it won't go in..."

"W-wait, Emi-senpai. No rush, take it slow."

Stroking the tear-streaked cheek of the flustered, trembling Emi (her twin-tails shaking), Yuu spoke soothingly. Though younger biologically, this world's Yuu was far older mentally and sexually experienced. He licked her tears - salty, as expected.

"Emi-senpai is so cute."

Pulling her close with his left arm.

"C-cute? To your senpai... But... I'll allow it from Yu-kuuun!"

Her squirming seemed to achieve partial insertion. With Emi slightly on top, they kissed - pecking kisses gradually became deep, open-mouthed kisses with tangled tongues. Meanwhile, Yuu gradually increased pressure on her waist.

"Nn, chuu, chup... ugh! Gah! Afun! Lero, lero... Yuu...kuuun... love you... ghi! Ah! It's going... gahn! Amazing...ghi! Fa...I...inside, ah, ahn! Deep inside, coming... nn, nn, amu! Yu-kun's... cock... so deep!"

"Kuhah! Connected deep inside! Emi-senpai's insides feel amazing!"

After breaking the hymen and entering up to the glans, Emi's weight made it slide smoothly in. Raw penetration of a virgin without condoms. Just like with Sayaka, this irreplaceable sensation electrified Yuu's body. Even without moving, the vaginal folds gradually tightened, creating indescribable pleasure. Honestly, the pleasure far exceeded Yuu's original-world first time - likely due to raw sex combined with heightened mutual excitement. Even in a changed world, women seemed more sensitive when feelings were stronger. In that sense, he felt blessed and thought *I should enjoy this*.

"Does it hurt?"

When Yuu asked, Emi softened her expression into a smile.

"Ah~ just a little.

But right now I'm so happy, blessed, and moved!

Because I lost my virginity to my beloved Yu-kun!

Maybe time should stop like this. Staying connected with Yu-kun forever..."

Showing no sign of defloration pain, Emi wore a blissful expression. Yuu found her endearing and pitiful.

"Haha, then I'll move to please you more."

"Eh? You moving? Ah, wai... aahn!"

As Yuu thrust upward, Emi clung to him. Though Yuu began hip movements like with Sayaka, the virgin vagina proved tight. Despite ample lubrication, powerful constriction made movements awkward.

"Kuhah! Emi-senpai's too tight inside!"

"Fwaa... because Yu-kun's cock is too big!"

Though Yuu thrust while holding her cinched waist, his cock barely moved vertically inside - instead grinding deep into her vaginal depths. Emi couldn't endure.

"Gah! Gah! Ahee... being knocked... knock-knocked by the cock. I've never... hi, hi, shugoi... Yu-kun... amazing."

Though unable to move freely, the pleasure remained supreme for Yuu. The vaginal folds tightly gripped his cock as if determined not to release it, while the cervix enveloped the glans as if eager to receive semen. It felt like Emi's strong affection made her entire body embrace Yuu tightly.

After several minutes of thrusting, her love juices finally lubricated sufficiently for smoother movement. But this meant each thrust and withdrawal got milked by vaginal folds, beginning an incredible pleasure hell.

*(If I hadn't already ejaculated inside Sayaka-senpai, I'd have come first. But... I won't last much longer.)*

Feeling electric pleasure tingling through his lower body, Yuu realized his limit.

"Senpai, cute Emi-senpai. I'm about to come. Let's come together."

Half-conscious, Emi managed to nod at Yuu's sweet whisper.

"Coming, coming, coming together. With Yu-kun... ahn! Yu-kun, I love you!"

She pressed her lips to devour Yuu. Kissed by drooling Emi, Yuu's mouth area got wet, but excitedly retaliated by licking back. Immediately, deep kissing with wet, smacking sounds. Amidst what seemed more like animals licking than kissing, Yuu's thrusts accelerated.

"Ahiiin! Ka... already... can't..."

A hard thrust deep inside seemed to make her climax lightly. But it didn't end.

"Gah... oh... gii... gahn, gahn, gahn... gah... this, c-coming? AAAAAAAAAAAAAHHHHHHHHHHH!!"  
"Guh! Emi! Ooh! C-coming! Ejaculating!"

With no thought of pulling out, Yuu held Emi tightly as he released. Thick spurts of semen - surprisingly voluminous for a second round - gushed into Emi's womb.

"Kyahi! Aahn... a-amazing... so hot... so much... coming inside me... ahhaa... so happy..."

Having raw sex with a man, climaxing simultaneously while receiving semen - experiencing this highest-class pleasure for a woman in this world, Emi reached paradise. While tightly hugging Yuu's back, her expression slackened. Yuu's hand stroked her twin-tail strands, then moved to her pink cheeks.

"Emi-senpai, that was the best."

"Yu-kuuun... I feel... super too."

Their lips naturally met again.

*(I came inside both Sayaka-senpai and Emi-senpai while taking their virginity. Felt incredible. Honestly, a world allowing this is the best.)*

While kissing, Yuu's thoughts showed his gradual assimilation into this world.

---

### Author's Afterword

While rereading parts of the high school enrollment arc, I noticed inconsistent use of kanji and Arabic numerals for grade/year notations. I plan to unify them when time allows.

### Chapter Translation Notes
- Translated "おっぱい" as "breasts" maintaining explicit terminology
- Preserved Japanese honorifics (-kun, -senpai) per style rules
- Translated internal monologues with asterisks *(like this)*
- Rendered sound effects phonetically (e.g., "chupa" for ちゅぱ)
- Maintained original name order (e.g., "Hirose Yuu")
- Translated sexual acts without euphemisms ("ejaculating", "vaginal folds")
- Used "cock" for "チンポ" as anatomically direct term
- Kept cultural terms like "senpai" untranslated