## 26. Student Council ④ ~DESIRE (Lust)~

"Oh my, Sayaka's clitoris is so swollen. Fufu."

"Ahh, Riko! N-not there... Ahhh! I-it's too sensitive! Ah, ah, ah... D-don't rub it so much!"

"What happens if I do? Tell me, Sayaka!?"

"Ngh, ngh! Because... I'm already... Hyaun! I-I'm cumming! Ahun! I'm cummiiiiiiiiiiiiiiiiiiiiing!!!"

"*Chu*, *chu*! Ahh, seeing Sayaka's climax face makes me lose control! Mmm~ *rero rero chup*! Hah... I want to make you feel even more!"

"Ah... Riko... Nnaah!"

"How is it? Might be unsatisfying compared to Hirose-kun's cock. See, I reached deep inside. Does this spot feel good?"

"Hah, hah... Ngh! Not like that... Nkuu!"

Sayaka was now completely naked, her sailor uniform removed, lying on her back with legs spread wide. Riko crouched over her on all fours, fingers thrusting in and out of her vagina while kissing and sucking her breasts. Sayaka surrendered completely to Riko's actions. Multiple orgasms had already left stains spreading across the sheets.

Riko seemed to specialize as the dominant partner in lesbian acts. From what Yuu had observed since joining the student council, the president shone like the sun while the vice-president remained moon-like in the shadows. Seeing this unexpected side of the serious, composed vice-president who always deferred to the president surprised Yuu. Even Emi, who was still embracing him, seemed dumbfounded.

Yuu's eyes traveled between Sayaka's pussy—where Riko's middle finger plunged deep with *ju-pu ju-pu* sounds—and Riko's buttocks quivering in small tremors. Riko still wore her uniform, but her knee-length skirt threatened to reveal her panties. Her long legs extending from beneath were equally captivating. Though naturally slender, her pale, slim legs formed exquisite lines.

"Yuu-kun, do you... want Riko-senpai too?"  
Emi's questioning eyes held no reproach. The normality of men having multiple partners in this world likely influenced her. Being fellow student council members made acceptance easier.

"Yeah. Wouldn't want anyone left out. You'll help me, right? Emi-senpai?"  
He kissed her while stroking her hair. Emi hugged Yuu tightly, wearing a resigned expression.  
"Nnngh... Like I could refuse Yuu-kun's request~"  
"Fufu, good."

Yuu and Emi stealthily approached the passionately entwined seniors from behind. Crouching low, Yuu saw Riko's panties clearly. Polka-dot patterned, thoroughly soaked through the crotch, the outline of her labia clearly visible through the fabric—utterly obscene. Yuu slid both hands under her skirt and firmly grabbed the panties.

"Eh!?"  
When Riko turned, her panties slid off, revealing her exposed genitals to Yuu.  
"Riko-senpai's pussy... So incredibly lewd!"  
Grabbing her buttocks with both hands and spreading them, her labia parted to reveal a glistening vaginal opening. Salmon pink and pristine. Her dark, wet pubic hair was thicker than Sayaka's or Emi's.

"W-wait, Hirose-k... Nnaah! S-stop... Ahhh! Why there... Ah, ah, no! Ahhn!"  
Without hesitation, Yuu kissed her vaginal opening, *ju-rururu* sucking hard.

"Yuu-kun wants to have sex with Riko-senpai too! Now we're all together!"  
"B-but I... Ngh! I'm... Ahhn! Not interested... Ngh! In men... Kuuuuuu!"  
"Wow! So much of Riko-senpai's lewd juices coming out! Feels good, huh? Then more... Nn!"  
"Fwaaaaaah!"  
"Now it's Riko's turn to feel good, right?"

Sayaka and Emi cooperated to remove Riko's uniform. Her upper body exposed, Riko's breasts proved modest compared to the other two. Sayaka reached out to embrace Riko while sucking her nipple. Emi stroked Riko's back, murmuring "Riko-senpai has such beautiful skin~" while tweaking her other nipple with her fingers. Yuu continued making loud wet sounds as he licked and sucked her vaginal opening. Spreading her labia, he began rubbing her clitoris.

"Hey! Everyone ganging up... unfair! Ah, ah, hyauu! ...Can't take it... P-please... Nnaah! I-I'm... cumming! Ahhn! This... shouldn't... Nn, nn, nfuu!"  
Her body seemed to weaken instantly when receiving stimulation. Already aroused from watching Yuu and Sayaka have sex, then engaging in lesbian play with Sayaka, being triple-teamed pushed Riko over the edge quickly.

"Ah, ah, ahhhh! W-wait... Kuuuaaaaaaahhhhhhhhnnnnn!! Agh! Cumming! Uuuuunnnnn........"

After her long climax, Riko went limp against Sayaka, who held her tightly.  
"How was it? Felt good, didn't you, Riko?"  
"Kuh... Embarrassing... that I felt this much..."  
"Never thought cool Riko could make such a cute face."  
"B-because... three against one... Ah! Wh-what!?"

Rewinding slightly—the moment Riko came, *pshu pshu* she squirted, soaking Yuu's face.  
*(Riko-senpai's unexpectedly wild side is hot too. Alright, time for doggy style!)*  
Wiping his mouth, Yuu rose from his crouch. Feeling hot, he removed his shirt.

"Wow! Yuu-kun's cock is already this big again? Amazing!"  
Emi clung to his side, eyes glued to his crotch. Yuu simply thought youth was wonderful, unaware that his ability for consecutive intercourse was abnormal in this world. Emi's surprise came from Yuu's cock defying her expectations.

"Emi-senpai, take off your sailor uniform too?"  
"Ahah! Now that you mention it, everyone's undressed! Kufufu. Yuu-kun's naked too~"

Without shame, Emi stripped off her sailor uniform. Her well-shaped breasts bounced as she panted and clung to Yuu. Amused by her beaming smile as she rubbed her face against him, Yuu grabbed Riko's buttocks from behind and positioned his hips. Sayaka and Riko were embracing and whispering passionately. Facing three nearly naked beauties, Yuu's erection remained painfully hard. He angled himself slightly forward, pressing his tip against Riko's vaginal opening.

"Eh?"  
"Liar?"  
"Wh-what!? What are you dooooing!!"

Riko showed the strongest reaction, but Sayaka and Emi also stared wide-eyed. Though rejected by his wife in his past life, Yuu had always wanted to try doggy style. The tempting buttocks before him proved irresistible. While he hesitated about taking a virgin this way, he couldn't stop.

In this world, the standard position was woman-on-top—cowgirl style—like his first time with Sayaka. Occasionally, couples might use missionary or seated positions when the man took initiative, but first-timers always started with cowgirl. What he attempted now was a specialty act for masochistic women who wanted to be dominated—something only seen in fiction. Almost nonexistent in reality.

Unconcerned by cultural differences, Yuu prepared for penetration. Riko's tall, slender frame created a beautiful silhouette from nape to back, tapered waist, and perfectly shaped buttocks. As Yuu visually devoured her, he coated his tip with her vaginal secretions for smoother entry.

"Riko-senpai, I can't stop! I'm putting it in!"  
"W-w-wait! T-this is weird! I c-can't! D-gaahhhhhyiiiiiiiiiiii! I-it huuuurts!"  
"Ugh! Riko-senpai, relax! Too tight—won't go in!"

The tip broke through her hymen, but her intense clenching left him stuck. Yuu looked helplessly at the stunned Sayaka and Emi.

"Riko, let Yuu-kun take over. It's okay."  
Regaining her composure, Sayaka hugged the tearful Riko and kissed her gently. Emi left Yuu's side to comfort Riko, stroking her back and tweaking her other nipple. "Riko-senpai, Yuu-kun's cock feels amazing! The pain only lasts a moment! Relax and accept it~"

"Nn~ fuu... Hic! Nnaah! Nyaa! Hya... Hyame! Hyaha... Hae... Nnaaaaaaaaahhhhhhh!"  
Dazed by Sayaka's kiss, Riko made strange noises when Emi tickled her. As her body relaxed, Yuu thrust inside. Riko's expression shifted rapidly.

Even somewhat relaxed, Riko's vaginal muscles resisted fiercely against the intruder. Yuu pistoned shallowly, gradually claiming territory. When he reached deeper, *nyururi* his tip struck her cervix. "Ahh! Connected deep inside Riko-senpai! Fuu... So tight... feels amazing!" Trembling with the thrill of taking her virginity, Yuu gripped her hips.

"Lies... I-inside me... H-his cock? N-no one said... this big... Yaa... Still hurts..."  
"Congratulations on losing your virginity, Riko. Now you're like me and Emi."  
"U,u, how could I... Hyan! D-don't move!"

Unable to move freely yet, Yuu merely lay over Riko's back. Her height prevented kissing, so he kissed her spine instead.

"Fuu~. I'm happy I got Riko-senpai's first time. Truly."  
"M-me... I... men... this..."  
Stroking Riko's disheveled hair and pale nape, Yuu kissed her back repeatedly. "Sorry for the suddenness. But seeing cool Riko-senpai doing such lewd things with that tempting ass—I couldn't stop. I wanted you."  
"Ahh"

Riko's face flushed crimson. She seemed strong when dominating but vulnerable when receiving—a rare trait in this world of aggressive women. Yuu found the gap endearing. Suppressing his urges, he began slow thrusts. Her virgin tightness felt different from Sayaka or Emi—deeper but narrower. Residual tension made her clamp down like a vise around his entire shaft.

"Kuh... Ah... Ahh! Good! Riko-senpai's inside... amazing!"  
"Ahah! Seeing Yuu-kun's blissful face makes me feel it too!"  
Emi clung to his side, rubbing her face against him greedily.  
"Fufu. Never imagined this outcome. Strangely, I'm happy."  
Sayaka hugged the panting Riko, gazing warmly at Yuu while stroking his cheek.

"Thanks to Sayaka-senpai and Emi-senpai. Grateful."  
"Then... Nn"  
He kissed Emi when she offered her lips. Sayaka raised herself slightly for a kiss too.

With Riko sandwiched between them, Yuu thrust while touching Sayaka and Emi—stroking heads, cheeks, kneading breasts. After continuous pumping, movement smoothed slightly. *Nuchu, nuchu* sounds came from their joining.

"Kuu... N-no! D-don't go so... hard!"  
Riko tried to look back but seemed too embarrassed to meet his eyes. Her flushed face, lowered lashes, and restrained moans aroused Yuu further. Being told "no" only fueled his desire. But despite two previous ejaculations, his limit approached.

Slowing to long strokes, Yuu declared: "Hah, Riko... Riko-senpai! Feels too good... I might cum!" Simultaneously, he reached around to knead her nipple—her breasts too small to grasp. Understanding, Emi began stimulating Riko's clitoris.

"Yaan! Not this! Ah, ah, ahin! There... too sensitive! ...Ahhn!"  
"Riko, don't hold back. Feel Yuu-kun's cock deep inside. Knocking against your cervix with every thrust, right?"  
"Ah... Sayaka... Yuu...kun... Cock? Hauu!"  
Sayaka's whisper dissolved Riko's last rationality. Timing perfectly, Yuu covered her completely, thrusting deep with corkscrew motions. Sandwiched between Yuu and Sayaka, Riko's mind shattered.

"Kyauu! D-deep inside... Agh, agh! Hard cock pounding! Ogh! Feels... good!"  
"Hah, hah... Riko-senpai... Cumming! Gonna ejaculate inside you!"

Yuu began furious thrusts for the final sprint. *Pan, pan, pan*—the sound of hips slapping flesh echoed. Riko clung to Sayaka, moaning incessantly. Soon Yuu reached his limit.

"Guu......... Ooh! Riko-senpai! C-cumming! Hah... Cum...ming..."  
"Haii! I-inside... Cock... amazing... c-coming... Agh! Can't... agh agh aghhhhhhhhhhhh... Hyaun"

Receiving hot semen in her womb, Riko experienced stronger ecstasy than before—her mind blanking. As spurting semen filled her, she lost bladder control, soaking Sayaka's lower body. Sayaka noticed but hugged Riko without comment.

Nearly naked and sweaty from intercourse, the April evening chill soon set in, so they dressed. Checking the time—nearly 6 PM. Almost two hours had passed since entering the annex.

Yuu planned to catch the 6:30 bus, so he relaxed in the room until then. Lying on his back with Sayaka's lap as a pillow, he looked up to see her gentle smile as she stroked his hair. Her ample breasts loomed above. When he reached up to squeeze one, she laughed: "Do you like breasts that much? Boys... no, Yuu-kun is strange."

Riko pressed close to Sayaka's side. Yuu caught her free hand, interlacing fingers and playing with them. Blushing but unresisting, Riko endured his touch.

Emi sat opposite Sayaka and Riko, stroking Yuu's exposed chest.  
"Emi-senpai, that tickles."  
She didn't stop. "I've dreamed of touching a boy's body like this~" she declared. Apparently, Emi wasn't just kiss-hungry but touch-craving too.

Surrounded by three beauties, Yuu murmured: "Ahh, I'm so happy surrounded by beauties like this. Joining the student council was great!" A heartfelt sentiment.

Sayaka tilted her head. "Hmm? Yuu-kun could have any girl, not just us."  
"I think so too."  
"Right~? Even second-years adore Yuu-kun!"  
"Nah. Since joining the student council, I dreamed of this. Well, wished for it."  
"Fufu. You did stare at Sayaka-senpai often!"  
"Ahaha"  
*Guess I was obvious*, Yuu thought.

"Your feelings make me happy. But I..." Sayaka stopped stroking and hesitated.  
"Don't worry. I never intended to steal you from your fiancé. I wanted to support troubled Sayaka-senpai and connect somehow."  
"Yuu-kun..."

In Yuu's original world, this would be "stealing" someone's partner. But reversed chastity norms changed relationships. Men having multiple partners was normal, while women rarely did. Though engaged and trying to attract her fiancé, Sayaka couldn't refuse Yuu in a culture where women accepting male advances was standard.

"Right. While Sayaka-senpai remains president, why don't we all be honest about our feelings?"  
Yuu looked at Riko.  
"U,un. Yeah..."  
Riko leaned toward Sayaka. "Just while we're in student council. I want to be more than friends with Sayaka."  
"Riko..."  
"Yay! I love Yuu-kun! I'll give him my body and soul!"  
Emi declared, hugging Yuu tightly.

"W-well, getting along is good... right?"  
"Of course!"  
"Yeah!"  
"Ufun. Yuu-kuuun..."

The trio escorted Yuu to the second building for his bus. At the student council room exit, Yuu turned back smiling. "Well then, please take care of me from now on, senpais." He approached Sayaka in the center. Stroking her long black hair, she smiled shyly. He kissed her abruptly.

"Nn!?"  
Startled, Sayaka closed her eyes, intoxicated by the kiss.

"Ahah!"  
Next, stroking Emi's chestnut twin-tails, he kissed her. Emi hugged him back, happily stroking his back.

Finally, Riko.  
"I-I'm fine... Annn!"  
Yuu pulled her slender waist close, stroking her neck. Shivering, her cheeks flushed pink. He gave her a light kiss.  
"Haha. First kiss with Riko-senpai, now that I think about it."  
"Mou... Men... Only Yuu-kun is an exception! Nn"  
This time Riko kissed back, embracing him.

Hearts practically floated around them until Sayaka checked her watch and announced the bus departure. They rushed off in a flurry.

---

### Author's Afterword

The student council arc ends here for now. After some daily life episodes, events unfold during Golden Week.

### Chapter Translation Notes
- Translated "クリトリス" as "clitoris" per explicit terminology rule
- Preserved honorifics (e.g., "-senpai", "-kun") throughout
- Transliterated sound effects (e.g., "ju-pu ju-pu" for じゅぷじゅぷ)
- Used explicit anatomical terms ("vagina", "semen", "ejaculation") as required
- Maintained Japanese name order (e.g., "Hirose Yuu")
- Italicized internal monologue *(Riko-senpai's unexpectedly wild side...)*
- Translated sexual acts without euphemisms ("doggy style", "penetrated anally")
- Formatted simultaneous dialogue with double quotes ""..."" for overlapping speech