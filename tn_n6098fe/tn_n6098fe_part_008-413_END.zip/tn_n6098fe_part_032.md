## 27. On the Way Home from School ① ~Scenes of the Town~

### Author's Preface

I thought it would be better to end at Chapter 26, so I've changed the start of Part 2 to Chapter 27.

I've only modified some prefaces/afterwords in previous chapters; there are no content changes.

---

"Can we go home together today?! Yuu-kun!"

As sixth period ended and Yuu began preparing to leave, Higashino Rei in the front seat turned around and spoke to him with an expectant face full of hope.

"Yeah. We can go home together for the first time in a while today."

When Yuu answered, Rei's face lit up with a genuinely delighted smile.

About a week after enrollment began...

When Yuu said, "Calling you 'Higashino' is awkward. Can I use your given name instead?" they started calling each other by their given names rather than family names.

This week, Yuu had formed relationships not only with student council president Sayaka but also with Riko and Emi. However, his schedule was packed with preparations for the Newcomer Welcome Orienteering event scheduled after Golden Week.

A dedicated executive committee had been formed for the welcome/farewell event for graduates and new students, which had been working with the student council since around New Year's. Since it might be awkward for Yuu to join midway, he was only being briefed for reference and giving opinions, not actually participating in activities.

Because of this, all three student council members were absent today (Wednesday) due to school business. Yuu himself had no after-school plans.

"Masaya-kun has wind ensemble club again today, right?"  
"Yeah. Playing instruments is fun, though the girls constantly trying to talk to me is annoying."

Yamada Masaya, pushing up his silver-framed glasses with a flick of his finger, kept his distance from girls like a typical boy in this world. Still, having learned piano through middle school, he enjoyed playing instruments and joined the wind ensemble club. About one-third of the 30 club members were boys, with activities three times a week (Monday, Wednesday, Friday).

Though his actual attitude toward girls was unclear, he seemed generally aloof in daily interactions. Yet he appeared to enjoy club activities even surrounded by girls. Yuu thought even someone like him would eventually get a girlfriend - whether one, two, or maybe even three. *That's youth for you*, Yuu mused.

Meanwhile, Rei had checked out several cultural clubs but ultimately hadn't joined any. He seemed to want to join whatever Yuu joined, but Yuu had already joined the student council. "I didn't really have a club I wanted to join anyway," Rei said, but seeing him clearly lonely about going home separately despite living in the same apartment complex made Yuu feel slightly guilty.

---

Nearly a month had passed since starting high school. Among the all-boys class, Yuu's only real friends seemed to be Masaya and Rei. It wasn't that others disliked him - he could talk with them normally. But for daily activities like moving between classrooms, break-time conversations, and lunch, he mostly spent time with those two.

According to Masaya: "Yuu's unusual. Plus, he seems more composed than he looks, which might create a barrier."  
Rei added: "Talking with Yuu-kun does feel like talking with someone older. Ah, I think that reliability is good! But being too unguarded around girls is questionable..."

In other words, Yuu's middle-aged mindset and values were so different from boys in this world that others kept their distance. Compared to Yuu's memories, the boys at this school were generally docile overall:

- Serious, nervous types like Masaya  
- Effeminate, androgynous types like Rei  
- Outgoing but only social with other boys  
- Introverted otaku-like types  

There were no delinquents or aggressive types. Though they sometimes voiced harsh opinions about middle school girls or current female students, these feelings never turned toward their male peers. They were complete herbivore boys lacking the typical overflowing energy or mischief of 15-16 year olds. From Yuu's perspective, the girls seemed far more energetic, proactive, and active. *This must also be due to the reversed chastity dynamic between genders*, he thought.

---

After parting with Masaya who headed to the music room with clubmates, Yuu and Rei exited through the entrance toward the bus stop. The shuttle bus was already parked with its doors open. Ropes were strung along the first building side of the space between the entrance and bus stop. While not impossible to cross, the unspoken rule of staying behind them to just look was being observed.

From Yuu's perspective, Sairei Academy girls seemed more ladylike and considerate toward boys compared to middle school girls - perhaps because they had the security of knowing higher grades offered school-approved dating opportunities, or maybe they didn't want to seem desperate and get disliked.

When Yuu and Rei exited the entrance, about fifty girls - mostly first-years - had gathered, fewer than at enrollment but still a crowd. The moment they spotted Yuu and Rei, shrill cheers erupted:

"Ah! It's Hirose-kun!"  
"Lucky today! Hirose-kun really is handsome!"  
"And! He's with Higashino-kun today. What a picturesque pair!"  
"Aww, Higashino-kun is so cute~!"  
"Look over here!"

It felt like being an idol. Yuu still wasn't used to girls squealing over him, but it wasn't unpleasant. When he smiled and waved lightly, the cheers grew louder.

"See? They're calling your name too, Rei."  
"I-it's embarrassing..."

Rei kept his face down, too shy to respond to the calls. This was probably why people found him cute. With a wry smile, Yuu boarded the microbus labeled "Bus 1". Their bus route went via Saito Station and through the new downtown area.

Fifteen boys from all grades boarded before departure. Besides the driver, uniformed security guards hired by the school rode at the front and rear. The school name wasn't displayed on the bus body, and smoked window film prevented outside viewing - likely for crime prevention. Unlike in unstable countries, Japan apparently had no bus attackers, but since boys boarding daily would draw attention, guards ensured boys were safely handed over to guardians (or male protection officers) after disembarking.

Yuu and Rei sat side-by-side in a two-seat row near the middle, Yuu by the window. Sairei Academy High School was somewhat removed from downtown, surrounded by fields and forests creating a rustic landscape. Security guards patrolled because suspicious individuals targeting boys occasionally appeared, Yuu heard.

As the bus departed, newly built residential areas came into view near the school gate-facing road. Sayaka lived in one of these apartment complexes. While responding to Rei chatting beside him, Yuu thought he'd like to visit Sayaka's home someday.

"Speaking of which, doesn't math teacher Dei-sensei have a creepy stare? Like she peers at each person weirdly while walking around desks..."  
"Ah, now that you mention it..."

Math teacher Dei was an unmarried female teacher in her early 30s (though Yuu heard she had children). Unaccustomed to teaching boys (her first time this year), she'd acted strangely since day one - nervous and oddly servile. Recently she seemed more comfortable, but now her gaze at boys had become suspicious. From Yuu's perspective, her face was ordinary but her large breasts and butt made for good eye candy. Lately she'd started removing her jacket, wearing blouses that showed her bra and tight skirts - irresistible. Frankly, she had an erotic figure.

However, Yuu seemed to be the only one looking at her sexually; other boys disliked her odd behavior. In his original world, it might resemble a muscular male teacher visually violating female students during class.

"Maybe she's sexually frustrated?"  
"Th-that's awful! If she acts any weirder, I'll have to tell Kanbayashi-sensei."

Kanbayashi-sensei was the young male homeroom teacher for the boys' class. The gentle-mannered Kanbayashi-sensei had suffered sexual harassment since his student days, so he sincerely addressed the boys' concerns.

"Well, let's endure it as long as it's just looking. Touching or saying something would be out of line though."  
"U-uh... If Yuu-kun says so, I guess it can't be helped..."

Yuu wanted to keep watching Dei-sensei as temperatures rose and clothing got thinner. Most teachers were middle-aged women anyway. He hoped this rare eye-candy teacher wouldn't be driven away by rash actions and would exercise restraint.

---

Their conversation about school life - classes, teachers - seemed endless. Rei appeared truly happy to talk with Yuu after so long. Though partly because they lived in the same apartment complex, Rei clearly admired Yuu like an older brother, following him everywhere at school like a goldfish trailing its owner. Yuu also saw him like a younger brother and didn't mind.

Before they knew it, the bus had entered downtown. Among rows of buildings, they glimpsed movie ads, loan services, new beer/cigarette promotions, and magazine covers featuring male models before the view swept past. Tobacco shops at corners, alcohol vending machines, and phone booths in prominent locations gave a sense of the era.

The bus stopped more frequently as traffic increased. Naturally, some students disembarked downtown too. Guards accompanied them, ringing doorbells and handing them over to male protection officers who emerged.

Looking from the bus window, Yuu noticed few minivans (which became popular when he was an adult in his previous life). Sedans, kei cars, and compact cars dominated the roads. Drivers and passengers were all women. Cars carrying men probably had smoked windows - Yuu spotted several such vehicles.

Pedestrians and cyclists - from children to elderly - were all female. Students and families chatting at street corners or window-shopping. Staff shouting while working at restaurants or gas stations. Store clerks seeing off customers leaving clothing stores. Construction workers and traffic controllers. A driver getting a ticket from a motorcycle officer after parking illegally roadside. Without exception, all were women.

Occasionally spotting men, Yuu saw elderly walkers flanked by family members, or uncles entering restaurants surrounded by burly male protection officers. Men apparently never walked alone at any age. *I guess you can't stroll freely alone in this world*, Yuu thought regretfully.

"Yuu-kun? Hey, Yuu-kun!"  
"Huh? Ah, sorry. What was that?"

Though seeing this scenery daily, Yuu still found it novel and had apparently missed Rei's question.

"I was asking about which course you'll take starting second semester?"  
"Ah. Right. You're taking the general course, right?"  
"Yeah. I don't have a specific career in mind that'd require the college prep course, plus I'm not confident in my grades..."

Yuu didn't know about girls, but boys' classes focused on junior high review during first semester until summer break. Having forgotten most high school knowledge from his previous life, Yuu felt uneasy about potential tests or being called on in class. Though painful to restudy math/science as a humanities graduate, he was grateful for this chance to relearn properly as he desperately absorbed formulas that standard junior high students should know.

Starting second semester after summer break, Sairei Academy boys chose between:  
- College prep course (aiming for university to pursue specific careers like doctor/teacher)
- General course (only needing high school graduation credentials)

Classes remained the same, with some subjects splitting. More subjects would separate as grades advanced.

Though formerly a college graduate, Yuu might struggle to enter a university at his previous level now. Three years might restore his former grades, but career options for men were limited here anyway, so he also lacked specific career aspirations.

"I'll probably take the general course too. No particular job I want enough for the prep course."  
"Really? I'd be happy to stay with Yuu-kun!"  
"Hahaha. You're such a sweet kid!"  
"Wah!"

Touched by the frank sentiment, Yuu roughly ruffled Rei's hair. However cute and androgynous Rei was, Yuu felt no strange attraction toward boys. Though delighted by his popularity with girls in this bizarre reborn world, he still felt anxiety and loneliness. Having a friend like Rei genuinely pleased him.

Soon the bus reached the apartment complex where Yuu and Rei lived. By then, only half the students remained. Guards disembarked first and rang the intercom. Already waiting, Yuu's protection officers Kanako and Touko, plus Rei's two officers, came out.

Surrounded by their officers, Yuu and Rei entered the apartment elevator. Inside the ascending box, Rei pressed close beside Yuu. Watching the floor numbers rise above the door, he hesitated slightly before speaking.

"U-um, Yuu-kun?"  
"Yeah, what is it?"  
"Er, well, if you'd like... maybe next time..."

Just then, *ching* - they'd reached Rei's 10th floor.  
"You were mid-sentence, right? I'm curious so I'll get off with you to hear it."  
"Eh? Is that okay?"  
"Sure. It's no trouble. Sorry about this, Kitamura-san, Kujira-san."  
"Not a problem at all." "We don't mind. Let's get off together."

Yuu and Rei disembarked at the 10th floor with their officers.  
"Yuu-kun, thanks for coming with me!"  
Rei looked truly delighted.  
"Don't worry about it. I haven't been able to go home with you lately with student council being busy."  
"N-no, you don't need to feel bad about that... Um, what I wanted to say was, Golden Week's coming soon, right? Would you... come over to my place?"

It struck Yuu they hadn't visited each other despite living in the same building. School friends in his previous life often visited each other's homes. Rei was a precious same-sex friend - Yuu felt he should accept.

"Sure. I'll come. I have a hospital visit on the 28th, so anytime after the 29th works."  
"Th-then... let's make it the 29th!"  
"Alright. Looking forward to it."  
"Yes!"

As things progressed smoothly, Rei clenched both fists in a victory pose. Though a victory pose, Rei's small, delicate movements made it look girlish.

After concluding arrangements, they saw Rei to his apartment door and said goodbye.  
"See ya. Tomorrow then."  
"Un. Bye-bye. See you at school tomorrow!"  
Rei waved with a beaming smile. Not only his officers but even Kanako watched Yuu and Rei with a tender smile as if observing something precious. Only Touko momentarily made a sloppy "dehehe" face before quickly regaining composure.

---

### Author's Afterword

No matter how cute Rei is, he's not a heroine but a precious same-sex friend slot. There shouldn't be any BL relationship.

### Chapter Translation Notes
- Translated "草食男子" as "herbivore boys" to convey passive male archetype
- Preserved Japanese honorifics (-kun, -san) per style rules
- Transliterated sound effects (e.g., "paa~tto" for ぱぁっと)
- Translated "ゴールデンウイーク" as "Golden Week" (standard term)
- Maintained Japanese name order (Higashino Rei, Yamada Masaya)