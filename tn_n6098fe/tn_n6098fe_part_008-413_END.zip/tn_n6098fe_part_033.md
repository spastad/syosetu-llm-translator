## 28. On the Way Home from School ② ~I Don't Want to Let Go~

After parting with Kanako and Touko at the entrance, Yuu opened the door leading to the Hirose family's living area.

"I'm home."

"Welcome home, Yuu-sama."

Had she heard the sound of Yuu opening the door and been waiting? 

Standing right there as usual was the housekeeper Akiko, her hair tied back in an apron, standing straight with perfect posture as she bowed to greet him.

Since Yuu joined the student council and started visiting the council room daily to see Sayaka, his opportunities to meet Akiko—who left at 5 PM—had decreased except when receiving his lunchbox in the morning. So meeting in the evening felt like a long time.

Mornings only involved brief lunchbox exchanges without proper conversation, but today he came straight home around 4 PM. Depending on her housework schedule, they might have time to talk. Though her expression remained as impassive as ever, making her thoughts unreadable.

"Now then, I'm still in the middle of dinner preparations."  
"Mm. Thanks for coming to greet me."

Akiko bowed once before returning to the kitchen. Unbeknownst to Yuu, as she turned away, the corners of her mouth relaxed into a happy expression. Yuu remained unaware as he entered his room.

After placing his belongings in their usual spot, he sat on his bed and pondered—about Akiko. When was the last time she'd serviced him (given him a blowjob)? With fewer evening meetings, over ten days must have passed. Though the 16-year age gap was significant for his outward appearance, her blowjob skills were the best he'd experienced, including his previous life. Maybe he'd request it after dinner preparations. It wouldn't seem unnatural after this long.

But now that he'd lost his virginity in this world, Yuu thought: *I want to see Akiko's usually mask-like face show a feminine expression.* Of course, as a housekeeper dispatched to a household with a male, she must be mentally resilient. Maintaining that expressionless face even during fellatio was impressive—she'd never attack him. Still, Yuu wanted to see some sign of her arousal.

"Got it!"  
Inspired by imagining gender-reversed scenarios, he got an idea and decided to act. First, he hung his thin linen jacket on a hanger. While unbuttoning his striped shirt, he noticed: *(Hmm... I feel someone watching.)*

The clean, natural-floored Western-style room was eight tatami mats—larger and more luxurious than his childhood home. Furniture included a study desk and wooden chair matching the floor color, a small round table, a solid wood single bed, a dresser, and color boxes. The white walls with subtle cosmic patterns lacked the female idol and rock band posters he'd had in his previous life. A round wall clock hung centrally, alongside a painting of a European countryside scene. A calendar with kitten and puppy photos hung near the foot of the bed. A corkboard beside the desk displayed childhood photos with family and same-sex friends, plus memos pinned with thumbtacks.

Though he'd finally grown comfortable relaxing here recently, he'd started feeling watched during solitary evenings. Lace curtains covered the window, and the door was properly closed. The sensation didn't come from the living room wall but from his sister's room next door. When Yuu stared at that wall, the feeling vanished, but it returned when lying on his bed or changing clothes.

This had made masturbation difficult when he first returned home. Well, Akiko's blowjobs solved that, and recently his physical relationships with student council members prevented frustration. But the suspicion remained. Once, considering checking the wall, he instead knocked on his sister's door—no answer, and it was locked. Martina only said, "Please leave her be for now." Since initiating conversation was impossible, she must believe time would solve it. His sister seemed to live almost nocturnally but apparently ate the meals Akiko prepared. He'd sometimes heard rustling sounds at night. It was disappointing he couldn't interact with the stunning beauty seen in photos and memories.

Yuu stepped into the hallway with his shirt half-unbuttoned and headed to the living room. When he opened the door, delicious aromas immediately wafted over.

"Dinner will be ready in about 30 minutes. Tonight it's beef stew, so please reheat it before eating. I also made cheesecake for dessert—please enjoy that too."  
"Oh!"

Akiko must have heard him enter. Her voice came from the kitchen, though he couldn't see her. Her exceptional housekeeping skills covered Japanese, Western, and Chinese cuisine, and her homemade desserts were a delight for his growing teenage body. Though Yuu hadn't particularly liked desserts in his previous life, Akiko's were perfectly sweet without being cloying. He'd become addicted—now she had him wrapped around her finger.

"But I plan to do some light training first, so I'll have it afterward."  
"Understood. I'll put it in the refrigera...tor..."

Akiko stepped away from the stove and froze mid-sentence as she looked over the counter at Yuu. Seeing her shocked expression, Yuu grinned mischievously. He'd left his shirt on the living room sofa and now wore only a white T-shirt.

It was a short tank top he'd found in the dresser—something he'd learned was male underwear after starting high school. Though Masaya and Rei often called it "indecent," Yuu didn't wear chest-concealing undergarments, finding the custom bothersome. Sayaka and Emi had been surprised too, but their eyes glued to his chest was amusing. So now he wore just the T-shirt—equivalent to a high school girl wearing a braless T-shirt in his original world.

He wanted to observe her reaction longer, but unfortunately Akiko immediately turned away. So he headed to the treadmill in the corner.

"I want to try running to build stamina."  
This started when Yuu told Martina after his early-month hospital discharge. Not joining any sports clubs in middle school made him acutely aware of his poor stamina and lean, under-muscled physique. Reborn, he wanted to build his body—not to become an athlete, but to gain confidence through early training. Maybe he clung to his original world's masculine values.

But Martina vehemently opposed him running outside. He suggested running with Kanako and Touko, but they disapproved too.

"Even once or twice might be manageable, but as a routine, people would definitely lie in wait or stalk him. We're confident we could handle any number, but there's no need for Yuu-sama to take such risks."  
"Agreed. While I'm happy Yuu-sama wants to run together, I unfortunately can't approve because he might experience fear."

Even Touko objected, so Yuu abandoned the idea. Instead, Martina bought him a treadmill. Yuu's joy at her casually buying this machine costing tens—maybe hundreds—of thousands of yen was undeniable. He immediately hugged her tightly.

The treadmill—or more accurately, running machine for indoor jogging—delivered by Martina's arrangement. Though he'd only seen them in commercials, it had a 1.2m rubber running belt like those in fitness clubs, with a monochrome monitor and buttons adjustable while running.

Starting cautiously, he set the slowest speed and 1.5km distance. Strangely, Martina wanted to watch him run, so he used it almost daily, morning and night. After three weeks, he felt some stamina improvement—noticeable during consecutive student council sex sessions. His original self might have exhausted himself after one round. He suspected this world's men weren't sexually active partly because they couldn't physically match stronger women.

Yuu stepped onto the running platform and started the machine. Today he set speed to level 3 (of 10) and distance to 3km.

"Haah, haah... Fuu, done."  
He noticed light sweat after finishing. Compared to his 40-year-old self, it wasn't particularly smelly—teenage bodies were impressive. Next, he did three sets of 10 push-ups, sit-ups, and squats with short breaks. Initially, he couldn't manage many reps and felt pathetic. This light training took about 30 minutes. If he'd joined a sports club, he could've pushed harder, but there was no need to overdo it. He'd build up steadily.

The clock showed 4:40 PM. Not much time left. When Yuu circled to the kitchen, Akiko stood idly, having finished her chores. Today she wore a red-and-navy checkered shirt with beige cotton pants and an apron featuring chicks and hens. Though subtle, she wore light makeup, showing more feminine charm than before. She glanced at Yuu but immediately averted her eyes from his T-shirt-clad form. To middle-aged Yuu inside, a lightly sweaty, scantily clad girl was arousing. What would the reverse be in this world?

"Akiko-san."  
"Ye... yes?"  
"It's been a while, so... um... I'd like to request it. The usual service."  
He approached as he spoke.

Akiko remained silent and expressionless. Nodding slightly, she removed her apron, folded it small, and set it aside. Then, as before, she moved toward the sink, head bowed, avoiding Yuu's gaze. Grinning mischievously, Yuu slowly approached and embraced her.  
"Kya!"  
She smelled sweet, perhaps from cooking.  
"Thank you for always making delicious meals. Ah, and the house is always spotless, laundry neatly folded and put away. I appreciate it."  
Holding her tight, he whispered in her ear.

"Ah... no, i-it's my job..."  
Akiko stood rigid, barely responding.  
"Mm. I know. But I can tell you're skilled and put heart into it."  
Housework might seem trivial, but it wasn't. Akiko made their comfortable home life possible. Having lived as a divorced man doing daily chores, Yuu understood the effort.

"Yu... Yuu-sama... hearing that... I-I'm grateful..."  
"Ah, sorry! I just exercised and sweated. If I shower now, you won't make it home in time... Do I smell?"  
Pulling back slightly from their cheek-to-cheek position, he looked at her face. With minimal height difference, their breath mingled.  
"Th-that's not..."  
Akiko's eyes darted nervously. Seeing her usually mask-like face flush crimson delighted Yuu, who hugged her tightly again. *She's surprisingly busty,* he thought privately.

Bringing his mouth near her ear, he whispered: "Your contract's one year, right? So you can only stay until June... I don't want that. I want you here after July too."  
Finally, he blew softly into her ear.

"Hah... nn! Yu... Yuu-samaaa..."  
Akiko's previously limp hands rose, stopping just before touching him. When Yuu whispered, "You don't have to hold back, Akiko-san," she hesitantly wrapped her arms around his back and hugged back. Feeling her emotions, Yuu's mood soared as he stroked from her back to buttocks. Her reasonably large butt had good shape without sagging, unexpected for a mother over 30. After hugging awhile, Akiko spoke in a faint, husky voice.

"Yu... Yuu-sama... um, I'll begin."  
"Mm. Please."

Keeping their bodies pressed together, Akiko slowly lowered herself. Kneeling on the kitchen floor, she undid Yuu's belt and pulled down his jeans. His half-erect penis sprang before her eyes.  
"Fahh..."  
Eyes wide, Akiko immediately took the penis into her mouth over his underwear. Surprised by the different approach, Yuu found the warmth pleasant and let her continue.  
"Nnfuu..."  
"Ahh, good, Akiko-san"  
Yuu gently stroked her head to avoid messing her hairstyle. Stimulated, his penis gradually hardened. As it fully erected and became too big for her mouth, Akiko tilted her head and took the shaft from the side. Even through fabric, her soft lips felt wonderful.

Looking down, Yuu saw her white nape to shoulder. A few stray hairs looked strangely erotic. His hand moved from her head to cheek, then nape. Her skin felt smooth and moist, surprisingly good for someone nearing 30.

"Nmmu... yu... yuuma... nn, fuu... hah! M-my apologies! How could I..."  
Akiko pulled away in panic, bowing repeatedly.  
"Huh? Why apologize?"  
"Because... I lost control..."  
"Ah. Did you... want to suck me yourself?"  
"......"

Yuu gently lifted her chin. She raised her face slightly but avoided eye contact.

"You know... I've been worried you might dislike this and only do it because you're employed."  
"Th-that's not... true..."  
"Really? You're not forcing yourself?"  
"N-no force... Rather... for Yuu-sama... I'm happy to serve..."  
Looking up, Akiko's eyes glistened.  
"Akiko-san!"  
"!"  
Impulsively, Yuu crouched and kissed her—just a light lip touch. Yet when their lips parted, her face was bright red.

"Ah... ahh. My first kiss. Yuu-sama is my first. I... can't believe it."  
Meaning she'd had no male relationships before conceiving via artificial insemination.  
"Are you okay with me being your first?"  
Akiko nodded firmly.  
"I consider it the greatest possible fortune."

Looking up, Akiko smiled modestly. It was her first smile—beautiful and charming, unbelievable compared to her usual expressionlessness.

"Akiko-san!"  
"Hyaa... nmm!"  
Yuu kissed her again, savoring her lips as he changed angles greedily. Breaking away, he whispered:  
"Hey, touch me."  
"Fai."

Akiko's hands removed his underwear and went straight to his penis, now fully erect. One hand stroked the glans while the other lightly jerked the shaft.

"Ahh, Akiko-san, feels good"  
Their eyes met as their lips naturally met again. Aroused, Yuu held her head and pushed his tongue past her lips and teeth.  
"...Ngeh!?"  
Eyes wide with shock, Akiko matched her tongue to his as it explored her mouth.

Their tongues touched, parted, then pressed together, tangling like living creatures. Soon, lewd *picha picha* sounds emerged as Akiko's eyes glazed. But her hands moved faster, not stopping—using both to caress every part of his penis, sometimes gently, sometimes firmly.

"Nn... aah... yu... yuhyama... amu... lelo, lelo, jup! Feels... good, yes?"  
"Nn... puhah"  
A string of drool stretched as their lips parted.  
"Mm... because you're amazing, Akiko-san. But now I want you to suck me."  
"Y-yes. Gladly."

With Yuu sitting cross-legged on the floor, Akiko hugged his waist from her side-sitting position and buried her face in his crotch. She kissed the beloved thing several times—*chuu, chuu*—then swallowed it deep into her throat. And suddenly, serious fellatio began.

"Kuhaa... ahh... Akiko-san..."  
While kissing the glans, she must have pooled saliva—mixed with pre-cum, it made *jupo jupo* sounds as her head bobbed. Her left arm wrapped around his waist while her right hand stroked from the base. Her whole mouth pleasured him, sucking *jurururu* while her tongue licked the glans. Though the tip surely hit her throat, she didn't cough—this was Akiko's full-effort blowjob. Yuu felt as if his penis was being sucked into her mouth.

*Jup, jup, jup.*  
The pleasure left him weak, his chin lifting involuntarily. Yuu's right hand had been stroking her head, but nearing climax, he grabbed her shoulder.  
"Kuooh! Hah, hah... ah... I-I'm close..."  
Akiko maintained her usual silence, but feeling her devotion—the best service he'd ever received across both lives—Yuu knew his limit approached.

"Ah, ah, I'm cumming! Akiko-san. Gaah... I'm cumming! Aaah!"  
"Nn!"  
Sensing his penis swell just before, Akiko stopped moving and tightly pursed her lips.

*Dopuuu*—a white torrent overflowed into her mouth. Akiko caught it all, swallowing with *gokyu gokyu* throat sounds. Slowly moving her right hand to encourage continuous ejaculation, she drank every last drop. After her usual cleaning licks, she wiped with tissue.

Frozen by overwhelming pleasure, Yuu watched Akiko bow respectfully.  
"Finished."  
Not her usual expressionless face—slightly flushed, she seemed to wear a faint smile. She picked up the folded underwear and pants. Feeling inexplicably shy, Yuu remained silent like a child as she dressed him.

Standing, they briefly locked eyes before Akiko quickly looked away to leave. As she stepped from behind the counter, Yuu hugged her from behind.  
"...!"  
"Akiko-san. That felt incredible. Thank you always."  
"N-no... it's nothing special..."  
Unusually flustered, Akiko stammered. Yuu's hands moved to her breasts, kneading the swell. He confirmed their substantial size.

"I wish I could make you feel good too sometimes..."  
"N-no, Yuu-sama... ah..."  
Gently massaging her breasts through the shirt, he kissed her white nape. But the living room wall clock caught his eye—long past 5 PM.

Post-ejaculation rationality overcame desire.  
"Sorry. You're past leaving time. Your daughter must be waiting."  
"M-my apologies. Just your feelings alone make me very happy."  
"Mm. Now, face me."  
"Yes."

Turning her shoulders to face him, he kissed and hugged her. Akiko hesitantly returned the embrace.

So neither noticed.  
Not just his sister Elena's door, but even the living room door was slightly ajar—someone had been watching.

---

### Author's Afterword

From a heated moment with the housekeeper to a horror-like ending. However, the consequences of this and how it will change things won't confront the protagonist until later.

### Chapter Translation Notes
- Translated "処理" as "service" in dialogue but "fellatio" in narration to balance natural speech with explicit terminology requirements
- Preserved Japanese honorifics (-san) and name order (Kawamata Akiko)
- Transliterated sound effects (e.g., "chuu" for ちゅっ, "jup" for じゅっぷ)
- Translated explicit anatomical/sexual terms directly ("penis", "ejaculation", "fellatio")
- Maintained internal monologue formatting in *italics*
- Used gender-neutral "they" for unknown observer until identity confirmed