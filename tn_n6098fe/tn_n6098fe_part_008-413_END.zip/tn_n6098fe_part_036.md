## 31. Golden Week ③ ~Thrusting, Riding~

After finishing ejaculation through titty fucking and double fellatio, the three faced each other on the bed.

The double bed size proved convenient at times like this, with ample space even when all three sat together.

Earlier, Mio and Shiho's faces had been spectacularly splattered with semen, but now they'd wiped it clean with tissues.

"My makeup has completely come off."  
"Indeed."

When receiving the facial, both Mio and Shiho had been enthusiastically licking up the semen, but as they calmed down, they seemed embarrassed to show their nearly bare faces to Yuu, avoiding eye contact.

"Eh? Both Mio and Shiho-san are naturally beautiful, so it's fine. Don't be shy, look this way."  
""But...""

Yuu embraced both Mio and Shiho who were still averting their eyes, kissing each in turn.  
"Ah...ahh, Yuu-sama! Yuu-samaaa!"  
"I'm happy...so happy!"

As they clung to him from both sides as if overcome with emotion, Yuu's excitement rose again.  
The passion once ignited couldn't be contained by a single ejaculation.

"Hey. Mio, Shiho-san. Sorry for taking your time during work hours because of me."  
"Ah...that's not..."  
"Yuu-sama isn't at fault! I wanted to be with you!"  
"W-what about me!"

Mio had been cleaning toilets after being ordered by her senior who often bossed her around. Shiho was on break but noticed an hour had passed when checking the clock earlier. Even knowing this, she couldn't bring herself to mention it - she simply didn't want to leave Yuu's side. As for Mio, she was prepared to be scolded upon returning. She might even be told not to come to the hospital anymore. But if she missed this chance, she didn't know if she'd ever meet Yuu again. Even if seen as an annoying woman, she wanted to cling to him until hearing farewell words.

After looking at them slowly, Yuu spoke.  
"Thank you. I still want to be with both of you too.  
Actually, I want to have sex."  
""Se-se-sex!?""  
Their voices harmonized.

"Ahwahwah... Yuu-sama and me... se-sex... wh-wh-what should I...?"  
Shiho, who had completely forgotten her usual composure, was flustered, while Mio remained relatively calm.  
"Ahaha. So Yuu-sama will be my first. How honorable."

Having had no proper relationships with men in her 25 years, Shiho's mind couldn't catch up to reality, having only fantasized about sexual matters. In contrast, Mio had experienced handjobs and titty-fucking fellatio with Yuu during semen tests, so having Yuu take her virginity was more than she could wish for.

"Though I'm like this, I sincerely ask for your favor."  
Mio clasped her hands before her chest and bowed. Unconsciously, her exposed breasts were emphasized, wobbling as they changed shape.

"Thank you, Mio.  
What about Shiho-san? Do you dislike me as your partner?"  
Patting Mio's head, Yuu looked toward Shiho.  
"D-dislike? Never..."  
Shiho clung to Yuu.  
"I-I've... admired Yuu-sama ever since his hospitalization!  
To cling to Yuu-sama like this, exchange words, kiss... ahh, how many times I've dreamed of this. Someone like me rejecting Yuu-sama is unthinkable! Rather... that is... p-please, take me!"

"Whoa, being admired by a beautiful older sister like Shiho-san makes me happy as a man."  
"Ahh... I too... am supremely happy..."

Yuu kissed Shiho's approaching chin - *chu*, *chu*. Then Mio also brought her face closer. Embracing Mio and Shiho from both sides, Yuu kissed them alternately. Starting with light lip touches, then pecking bird kisses, and as excitement grew, he extended his tongue, developing into deep kisses with Mio and Shiho.

"Haah...mmph, mm, mmm...puhhaa... Kissing Yuu-sama feels so good every time...my head feels like it's melting...ahhn! You like my breasts, don't you? Touch them more, please!"

While kissing Mio, Yuu's left hand touched her breasts. When lifted and released, her breasts swayed *tayun*. Trying to envelop them with his whole palm from soft touches to gradually increasing pressure, but the excessive flesh made his fingers sink in completely. As he pinched her nipples with his fingers while kneading, Mio intermittently leaked sweet sighs.

"Nnah, ah, vun! Mmph, chupaa... Yuu-samaaa, more...haahn! Ho, I want it! Hya, ahn! Yuu-sama's teasing..."

As if unleashing long-suppressed desires, Shiho became suddenly proactive, greedily taking Yuu's mouth. Yuu's right hand traced Shiho's inner thigh before invading inside her panties. He continued gently caressing her incredibly *guchu guchu* wet area. With every movement of Yuu's fingers, *kuchu kuchu* watery sounds could be heard.

Facing two such alluring nurses, Yuu's excitement skyrocketed. His cock, having ejaculated once, stood erect without any weakening, now being played with from tip to ballsack by both their hands.

"Kuhah! Soon, I want to put it in."  
At Yuu's words, the two looked at each other. With two women present but only one man, order needed to be decided. After a moment of silent staring, they turned to Yuu, avoiding conflict between women by yielding initiative.

Sensing this, Yuu thought briefly before speaking.  
"First with Mio."  
While Mio beamed with a radiant smile, Shiho looked slightly disappointed. Grinning, Yuu whispered in Shiho's ear.  
"But I won't leave Shiho-san out either."  
"Huh?"

"Th-then... I'll insert it."  
"Un, just like that. Mind the angle."  
"Y-yes!"

Yuu stopped them from removing their white coats as initially intended, requesting they keep them on with fronts open for the main act. A clothed sex scenario any uniform-loving man would dream of. Though they'd wrinkle and get wet, he'd overlook that. It would be perfect with nurse caps, but they'd been removed as nuisances.

Mio straddled Yuu's hips as he lay supine. His erect cock angled shallowly near his lower abdomen. Thus Mio leaned over until her nipples touched Yuu's chest, reaching one hand to guide his cock to her entrance. Aligning the tip with her vaginal opening, she tried lowering her hips. Without Yuu doing anything, her soaking wet entrance tried swallowing his cock.

"Ah...vuh! Chin-sama is...f-finally, inside me.  
Kuu! T-tight...but I want it, Chin-samaaaa...ah, ah, taking my virginity...aahn!"  
"Kuoh!"

A definite sensation of breaking through something. Simultaneously, the vaginal folds tightly squeezed *gyuuuuu* the invading glans, while pressure built as if trying to expel the intruder.  
"Nnn! More...deeper...ah...I want Chin-sama but...too big!"

A big-breasted virgin nurse straddling him to insert him - how could he not be excited? Mio, tearfully struggling to insert him deeper, seemed adorable. Yuu grabbed Mio's hips with both hands.  
"I'll help. Mio, let's become one."  
"Y-yesss!"

Matching Mio's hip descent, Yuu thrust upward slightly. His cock advanced *meri meri* through unexplored secret folds. Truly virginal - the glans hurt.

*Zun* - the glans struck deep inside.  
"Guah! It's...in!"  
"Hah, hah, I...connected deeply with Yuu-sama...*zubutte* deep inside me...this is sex..."

Unaware of drool trailing from her mouth, Mio wore a rapturous expression. The emotional impact of full insertion seemed stronger than hymen pain. With pink-flushed cheeks, Mio savored the cock penetrating her womb until her gaze caught Yuu's face.

"Kufufuu. Yuu-samaan!"  
Her mouth curved crescent-like, red tongue flicking out *chirori* before she abruptly leaned over.  
"Ooh, mphu!"  
"Amu, juru, rep...nn, nn, nn, Yuu...hyama...n, chupuu...haahn! I love it...mphuu...I (shu) love (shu) love it!"

Transformed into a lustful female, Mio greedily ravaged Yuu's mouth with her tongue. With two people's saliva pooling inside, Yuu had no choice but to swallow. On Yuu's chest, pressed breasts changed shape *muni muni* with Mio's movements.  
*(Mio, who had no male immunity as a virgin, became like this?)*  
Perhaps Mio's strong sexual desire as a woman of this world manifested. Soon Mio began rocking her hips in small motions.  
*(Damn, squeezing so tight...feels amazing!)*

Though tempted to let go until orgasm, Yuu suppressed the urge and tapped Mio's shoulder.  
"Feh...? Yuu...hyama?"  
Mio pulled back with tongue still out, multiple drool strands *taran* stretching between them. The way she licked away the strands connecting their mouths was alluring.  
"Sorry, Mio. Move as you like, but could you give me a little space?"  
"Fai"

Watching Mio reluctantly rise slowly, Yuu looked at Shiho waiting at his right side. Her expression resembled a female dog kept waiting. Frowning, breathing *haa haa* roughly, she stared at Yuu's exposed upper body as if licking it. Sitting flat on her butt, her right hand reached toward her freshly removed underwear, fidgeting *moji moji*.

"Shiho-san. Sorry to keep you waiting."  
Extending his right hand into her hem, Yuu grasped Shiho's hand.  
"Hah!"  
Coming to her senses, Shiho blushed and averted her eyes. Unconcerned, Yuu smiled.  
"For Shiho-san...I want you to straddle me like before...but precisely, straddle my face."  
"Eh...haah!?"

No wonder Shiho was shocked. In this world, facesitting let women indulge in dominating men, making it a common desire. But just as women in Yuu's world disliked fellatio, most men here hated facesitting. Hence its popularity in male gang rape fiction. Despite her composed facade, Shiho had excitedly used such scenarios countless times through novels and manga. A man requesting it himself was unimaginable.

"Such...placing my bottom on Yuu-sama's face..."  
Staring intently at Yuu's face, Shiho felt temptation rise - wondering how it would feel to put her buttocks on that beautiful face - battling her last shreds of reason. Her dripping wet pussy touching Yuu's mouth. Imagining this made her lower abdomen throb *kyun kyun*.

"I want to lick Shiho-san's pussy."  
"Th-that's..."  
Though thinking such words improper for a young boy, Shiho lifted her hips against her will.

"Come on. Please."  
"Haa, haa... Yuu-sama, excuse me."  
Yuu's words seemed decisive as Shiho fully lifted her hips into a kneeling position, circling around to his head.

"Ah, ah, ahn! Amazing...Chin-sama is gouging *gori gori* deep inside me. Ahhn! Feels too good...I can't stop my hips~"  
When Yuu glanced forward, Mio gripped his sides firmly, rocking her hips frantically, her ample breasts swaying *tapun tapun*. Turning his gaze upward, Shiho's crotch came into view beneath her straddling legs.

Earlier when Shiho opened her front, he'd seen her modest chest. Not much different from his sister Elena in dreams - perhaps A to B cup. But if Mio had breasts, Shiho had beautiful legs from buttocks to thighs. Having Shiho straddle his face and press her buttocks against him felt like a reward to Yuu.

Impatient with her hesitation, Yuu grabbed her thighs and pulled down. The shadowed crotch gradually approached. At close range, he saw it glistening wet, love juice dripping down her thighs. As her buttocks closed in, they completely blocked Yuu's vision. Along with a steamy feminine smell, viscous liquid wet Yuu's face.

Grabbing her buttocks from both sides to spread them, he pressed his lips *buchu* against her labia.  
"Hyan!"  
Shiho's cute reaction didn't register.  
*(Shiho-san's pussy is flooding!)*

The sight of a cool, competent woman suddenly unraveling aroused his male instincts. He wanted to unravel Shiho further.  
*Jupu jupo jurururu!*  
Making loud sounds as he sucked up her love juice, he extended his tongue and began licking *beron beron* around her vaginal opening.

"Ahhyin!"  
Unprecedented pleasure pierced her body, making Shiho jerk. Simultaneously trying to lift her hips, but Yuu firmly gripped her buttocks, not letting go. Spreading her open *kupaa* with his fingers, he licked her labia up and down with his tongue before *juru juru* sucking the love juice overflowing from her entrance. Then narrowing his tongue, he invaded inside her vagina.

"Ahh! Yu-Yuu-samaaa, aah aahn! Don't suck so much, I...this is...hyan! Sto-stop, ah, ah, something's coming! Aaaaaaaaaaahhhhhhhhhh!!!"

Within minutes of starting facesitting cunnilingus, Shiho climaxed. Receiving the *pushaa* splashing fluid on his face, Yuu kept sucking obsessively. Unable to bear it, Shiho reached out and embraced Mio before her. Mio too, her hip movements smoothing out, made loud *juppu juppu* watery sounds from their joining area as she approached climax.

"Ahn, ahn! Amazing! Chin-sama is amazing...I'm going crazy! Ah, oh, oh, already!"  
Mio also clung to Shiho, burying her face in her flat chest while moaning, her hips never stopping.

"Gumu! Ooh...nn, chupa! Haa, haa...nn!"  
Though unable to see the two beautiful nurses embracing and moaning above him, Yuu heard their overlapping sweet voices.  
*(Kuh, I'm...almost there too)*  
Still, he intended to continue cunnilingus to the limit. He wanted Shiho to feel more. Spreading her hood with his fingers, he extended his tongue and touched her clitoris.

"Hyauu!"  
Shiho's body jerked again, but Yuu firmly held her buttocks. Teasing her clitoris *chiro chiro* with his tongue tip, he felt it swell *pukkuri*. Meanwhile, matching Mio's hip movements, Yuu thrust upward. *Pashin, pashin* - flesh-slapping sounds echoed.

"Ya, ah, ah aahhhh! Yuu...sa...ma...ah, there...too sensitive...fuaaaaahhhh! Already, already! I-I'm...cumming! Me too, ah, ah, yes! Again...something amazing, coming!"  
"Haun! Hya, ahn, ahn! Chin-samaaa, getting bigger again...grinding deep inside...amazing, amazing, ah...no more...aun! Cumming!"  
*(Kuhah, now, cumming!)*

Realizing his limit, Yuu sucked hard on Shiho's clitoris, clamping it with his lips while thrusting *gan gan* upward.  
"Hau! Tha-that's...no...cumming uuuuunnn"  
"Ah, ah, ah, ahhinnn! Cumming uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuhhhhhhhhhh!!!"

At Yuu's ejaculation timing, Shiho and Mio embracing each other climaxed simultaneously.

Shiho stared blankly into space, immersed in the afterglow.  
*(Haaaaaa... Having a man perform cunnilingus feels this amazing. Completely different from doing it myself. Oh no... I want to feel even better things)*

Meanwhile, Mio leaned against Shiho, trembling *biku, biku* as she received the prolonged ejaculation.  
"Ahhaa... Chin-sama's holy fluid...inside me...*pyuku pyuku* so much coming out.  
Aahn, feels so good... Feeling this good... I'm being purified from the inside out..."

Identifying with enemy female characters from her favorite works, Mio drifted in dreamlike bliss.

---

### Author's Afterword

I wonder how many people immediately recognized the reference when seeing this and the previous chapter's subtitles.

### Chapter Translation Notes
- Translated "突いてるね 乗ってるね" as "Thrusting, Riding" to preserve rhythmic wordplay and sexual connotations
- Rendered explicit anatomical terms literally ("クリトリス" → "clitoris", "ワレメ" → "labia")
- Preserved Japanese honorifics (-san for Shiho, -sama for Yuu) per style guide
- Transliterated sound effects (e.g., "guchu guchu" for ぐちゅぐちゅ, "tayun" for たゆん)
- Translated sexual acts without euphemisms ("顔面騎乗" → "facesitting", "クンニ" → "cunnilingus")
- Maintained original name order ("Takano Mio", "Kajio Shiho") as per fixed references
- Formatted internal monologues in italics per style rules