## 32. Golden Week ④ ~Longing, Heartache, and Tenderness~

"Ahh! Yuu-sama, I must be heavy. I'll move right away."

"No, it's fine, Shiho-san. Stay as you are. First, I need to pull out my penis."

"Hweh!? Chinsama, you're pulling out...?"

"Haha, seems she really took a liking to it."

"Well, you gave me so much sacred fluid... Ann, it's still big."

"Takano, my turn now!"

"Ah, yes!"

Seizing the moment to assert seniority, Shiho's words prompted Mio to lift her hips, slowly pulling out the penis. Shiho hovered to avoid putting weight on Yuu, staring intently at their joined area. The glistening member remained erect and majestic, just looking at it made Shiho's lower abdomen throb.

"Ahh! The sacred fluid is leaking out!"

After it slipped out with a splurch, Mio panicked upon seeing semen flowing back out, pressing tissues against her vaginal opening.

"Alright then!"

Yuu shifted his body backward, moving behind Shiho and embracing her from behind.

"Hyah!?"

"Both of you, stay embraced like that and lie down facing that side."

"Um, like this?"

Mio discarded the tissue bundle she'd been holding against her crotch, then pulled Shiho along as she fell backward while holding her under the arms. "Eh? Yuu-sama?" Ignoring her confusion, Yuu forcefully pushed Shiho down and covered her, sandwiching her between them.

Yuu intended to take Shiho from behind. His experience with student council member Riko had taught him that doggy-style worked well for tall, slender women. Spreading those proud legs to admire the well-shaped buttocks while thrusting from behind - a preference rare among this world's men. Despite having ejaculated twice already, Yuu's member remained erect against Shiho's buttocks. As he embraced the now all-fours Shiho from behind - smelling her hair, kneading her modest swell, rubbing his penis against her buttocks - his excitement grew.

"Yuu-sama? Wh-what are you...?"

"Going to insert it like this."

"Eh!? N-no way!?"

This position was unexpected for Shiho. Startled, she twisted her neck to look at Yuu. Her natural sidelong glance and half-open lips, glossy despite her faded rouge, sent shivers through Yuu.

Yuu firmly rolled up Shiho's white coat to her waist. Kneeling, he pressed his hips forward into insertion position. When his penis touched Shiho's vaginal entrance - already soaked from two climaxes - it made a wet schlick sound, welcoming him with soft envelopment. Despite Shiho's confusion, her body clearly wanted it.

"Shiho-san!"

"Yuu-sama... w-wait... ah... ahh!"

Perhaps because she was thoroughly wet, the membrane seemed to break smoothly. But her virgin passage still resisted penetration. Yuu felt pain as he forced through the tight vaginal walls, but even this transformed into pleasure for him. Using deliberate hip movements, he pushed past the resistance of her flesh walls, thrusting deep inside in one motion.

"Guhhheeeeen! Ah... kah...!"

"Kuh! I-it's in...! Oh... ohh... Shiho-san's inside is hot and squeezing tight... s-so good!"

"Yu-Yuu-sama's penis... inside? Finally... my... deep inside... ahhaa... Yu...u...sa...maa... annh!"

Shiho must have felt the pain of defloration, but didn't seem overly distressed. However, the moment Shiho's consciousness shifted, Yuu felt vaginal folds wriggle deep inside, gripping his glans tightly - no, capturing it.

The Related Laws for Countering Low Birthrate cause major changes when both sexes reach age 25. Unmarried men with reproductive capabilities get three random unmarried women assigned by the state. Meanwhile, women face increasingly heavy tax burdens from April after turning 25 if unmarried and childless. Thus, men and women over 20 without romantic prospects actively seek partners. With a 1:30 gender ratio, it's completely a seller's market for men. Matchmaking services exist, but competition can reach 100:1 for popular men. Since one man typically chooses three women, actual ratios are slightly lower. Many men attended all-boys schools with minimal female interaction, making partner searches difficult, but still preferable to random assignment. Such men typically seek younger, non-aggressive partners.

This world celebrates Christmas with families, but women's ages are compared to Christmas cakes - hope remains through the 24th (years), but after the 25th, they risk being "leftover." Romantic connections depend heavily on luck beyond looks and personality. Women without marriage/pregnancy prospects by 24-25 often abandon romance for careers.

Shiho was serious by nature, never actively seeking men since high school, accepting her lack of romantic prospects. Meeting Yuu changed everything. Now penetrated by the man she adored, her body moved according to female instinct, craving male essence. Once penetrated, her vagina tightly gripped Yuu's penis deep inside, refusing to release it until milked dry.

"Wow, never seen Kajio-senpai make that face before. Completely melted. Hehe. Can't help it when Chinsama enters you~"

Though Mio teased from below, Shiho couldn't retort. Feeling Yuu inside for the first time, her body was becoming enslaved by pleasure. For her ripening 25-year-old body, the pain of defloration was momentary. With Yuu's penis deep inside before even moving, it intensely stimulated her feminine instincts. She hovered precariously near climax.

"Shiho-san's back view is beautiful too."

Yuu admired her exposed slender back from the waist up where he'd rolled her coat, running his hands over her soft skin. Just this nearly made Shiho overflow.

"Ah... no... fuu..."

"Shiho-san's pleasured voice is sexy. Let me hear more?"

Yuu brought his mouth to her back, licking upward with his tongue. Simultaneously, he thrust shallow but firm strokes, gouging her cervix. A tingling sensation spread through Shiho as intense pleasure surged from her depths.

"Kyahi! Gah... no, nooo... GAAAAAAAHN! AHN! Coming! I'm coming! COMING! IIIII'M COOOOMIIIIIIIIIIIIIIIIING!!!"

Less than five minutes after penetration, Shiho arched her back sharply, reaching climax.

"Senpai, came already? That expression... looked like you ascended to heaven. Hehe." Mio teased while stroking Shiho's sides toward her breasts. "Haun! No... now my body's sensitive... aun!" Mio's hands enveloped Shiho's pert breasts, pinching her nipples. "Hey... Taka... no... stop... nkuu" "But Yuu-sama's amazing part is just starting~"

Of course, Yuu was just beginning. Gripping Shiho's hips firmly, he responded to Mio's words by thrusting with deeper strokes. "Ah! Ah! Aah! Like that... Yuu-sama! N-no... I'll... come again... gahn! Feels... too good... going crazy!" "Shiho-san, feel even better, come lots more. I'm getting really into it."

Yuu raised his upper body to watch their joining. Shiho's formerly virgin pussy now gripped Yuu's thick penis tightly, contracting with each thrust, dripping with pleasure. Shiho gripped the sheets, trying to endure Yuu's onslaught. Wanting to make Shiho climax again before ejaculating, Yuu varied his thrusts - sometimes shallow, sometimes deep - acclimating his penis inside her. When their joining began making loud squelching sounds, he suddenly shifted to rapid thrusts. Pah! Pah! Pah! The rhythmic sound of flesh meeting flesh echoed. With each impact, Shiho shook her head and moaned intensely.

"Haa~ amazing. Who'd imagine Kajio-senpai like this? Yuu-sama really is special." Mio watched Shiho's torment with heated eyes, her own rekindled passion moistening her crotch.

Different from missionary or cowgirl, doggy-style provided unexpected stimulation, building Yuu's ejaculation pressure. Shiho's virgin passage tightly constricted his penis, sending electric shocks particularly when hitting deep. Yet Yuu didn't stop.

"Gah! Haa... Shiho-san! Shiho-san! Ahh, Shiho-san's inside feels so good!" "Ah! Ah! Yu...u-sama... I can't... take more... GAAAAAAAH! Coming... again, coming! HAAAAAAAH... n-no... CUMMING!!"

At climax, Shiho's arms gave out, collapsing elbows-first onto Mio. Yuu followed, sandwiching them. "Yuu-sama." When Mio peeked out from the side, Yuu kissed her while thrusting. He wanted to kiss Shiho too, but their height difference made it impossible.

"Nn... kuh... I'm... close." Instead of kissing, Yuu firmly rolled up Shiho's coat. Pressed against her back, he sensed his limit approaching. Though his stamina had improved recently, thrusting vigorously left him breathless. Still atop both women, he began his final sprint - long strokes shifting to deep, cervix-gouging thrusts while fully sheathed.

"Kah... this... good! Shiho-san's inside... incredible! Ah, gonna... cum!" "Ah! Gah! Oh... deep... gouging me! Ahi, ahi... Yuu-shaaama... ahh! Give it! Seeeemen! Inside meee!" "Guh! Gah! C-cumming!"

With one final powerful thrust, Yuu climaxed. Pressing his urethral opening flush against her cervix, his ejaculation lasted long. Though his third release, thick semen pulsed copiously into Shiho's womb.

"Ah! Ah! Ahn! Good! Haaun, amazing... Yuu-sama's penis... hot semen coming... lots... aahn, I'm... happy..."

Perhaps coming again from the ejaculation, Shiho murmured deliriously before going limp. Yuu hugged her as they collapsed, but concerned about crushing Mio, he simply stroked Shiho's short hair.

***

"Quite some time passed, huh."  
"Uun... don't want to think about it."  
"Same here, Yuu-sama."  
"Yeah. *mwah*"  
"Ah, me too!"  
"Huhu. Knew it. *mwah*"

Now lying on his back in bed, Yuu had Shiho and Mio pressed against both sides. Mio on his right held his arm between her breasts, nuzzling his shoulder, begging for kisses. Shiho on his left stroked his chest to stomach while pressing her face to his neck, also begging for kisses.

Their leisurely time together felt wonderful. But remembering Kanako and Touko were waiting, Yuu grew anxious. After a final kiss, he sat up.

"Decided. I'll go with you when you return to work and apologize."  
"Eeeh?!"

They harmonized in shock - men never took such actions for women.

"Because I'm the one who wanted sex with Mio and Shiho-san, making us late. Apologizing is only natural."  
"Aah..."

Touched, their hearts warmed. They were drawn to Yuu not just for his looks, but this kindness too.

"Yuu-sama!"  
"Yuu-sama!"  
"Whoa..."

As both hugged him, Yuu smiled at them alternately. "Should tidy up and go now."  
"Yes!"

***

When Yuu took them to apologize directly to the surgical nursing director, she readily forgave them. Of course, they didn't honestly state the reason. Their cover story: After his checkup, Yuu felt ill while entering the restroom just as Mio finished cleaning it. Mio helped him out, where they encountered Shiho on break. They let him rest in an empty male patient room. Yuu stopped them from calling a doctor, saying he'd recover with rest if they stayed. Thus, they "accompanied" him for 90 minutes.

"Hmph. Well then. Good work, both of you. Can't have anything happen to male visitors. But really, you just didn't want to leave him, right?" The director eyed them suspiciously briefly before bowing to Yuu. "Thank you for explaining personally."

"Not at all. I just wanted to help these two who cared for me."  
"My! Such considerate young men are rare. But some nurses lose rationality around men like you, so be careful."  
"Ah, yes. I'll be mindful."

The motherly director seemed genuinely concerned, making Yuu feel slightly guilty. Kanako and Touko waiting in the lobby were summoned.

"We worried with how long it took."  
"We searched the examination rooms but couldn't find you."  
"Uu... sorry."

Yuu apologized to the two who'd searched for him anxiously. They flustered at his bowing - protected men treated guards like air, never apologizing for making them wait. That Yuu treated them as people delighted them, their faces breaking into smiles.

Business concluded, Yuu headed for the rear exit with Kanako and Touko front and back, plus Mio and Shiho who got permission to see him off. Following slightly behind, the nurses silently stole glances at Yuu's back. "Want to see you again" - their shared unspoken wish. Professional ethics kept them from voicing it. Meeting Yuu again and sharing that passionate time felt miraculous, something to treasure forever.

Meanwhile, Yuu wanted to meet them again for sex but lacked pretexts beyond medical needs. Asking to meet privately was simple, but men faced restrictions. Dating with guards felt awkward.

Approaching the exit, Yuu remembered something. Turning back, he approached Mio.

"Yuu-sama?"  
"Remembered what you said during the semen test. The mandatory sperm donation every six months. You said they accept voluntary donations too."  
"Y-yes! I did explain that."  
"Can I do that at this hospital?"

Mio looked at Shiho. As a temporary assignee, she didn't know routine operations. "I believe so, with prior arrangement."  
"Really!"  
Yuu smiled at Shiho's answer.

"Then could I see Mio and Shiho-san then?"  
"W-well... Probably handled by internal medicine or urology, not surgery. We wouldn't be involved."  
"Muu."

Not so easy. But recalling the director's attitude, Yuu considered exercising male privilege.

"Ah!"  
"Hm?"

Mio's sudden exclamation drew attention. "About the semen test - the results should have reached you."  
"Ah, right."

Yuu recalled the health report arriving weeks later included semen results. "Takano! Can't say such important things here!" "Hah!" "It said 'Superior (Special)'."  
"Hah?"

Despite Shiho's attempt to stop her, Yuu blurted it out. Not just Mio and Shiho, but Kanako and Touko heard, all showing shock.

"Superior... with 'Special'?! Amazing, as expected of Yuu-sama!"  
"Eh, really?"

Mio looked moved, but Yuu didn't grasp the significance. He'd vaguely thought "Superior" was good like university grades, missing the "(Special)" meaning. He hadn't read the fine print.

Mio had intensely studied male sexuality. Shiho, Kanako, and Touko knew the common knowledge: Semen tests evaluate volume, concentration (sperm count), and motility. "Superior (Special)" denotes exceptionally high quality semen - occurring in perhaps 1 in 100,000 men. Meaning sex with Yuu carries high pregnancy likelihood, especially during "lucky days."

Shiho softly touched her lower abdomen. Her ovulation was two days prior. Typically, the three days surrounding ovulation are "lucky days." Thus, she likely conceived Yuu's child today. Uncontainable heat surged from her core. Seeing Mio smiling while touching her stomach, perhaps her timing was favorable too. Both gazed at Yuu with their own thoughts, but he simply nodded and spoke.

"Can I request specific staff when donating? I want Mio and Shiho-san."  
"Eh!?"  
"Yuu-sama would...?!"

Touched he'd go this far for them, their hearts warmed. "I... recall years ago, a man who started dating a nurse during hospitalization requested her for his semen tests. I heard it was exceptionally approved. Senior nurses called it legendary..."  
"Oh? Precedent exists. Then I'll request it next time."  
"Aah... Yuu-sama."  
"Yuu-sama, thank you."

Moved to tears, Shiho showed her emotions openly. Mio crossed her arms, emphasizing her chest as she gazed adoringly - drawing Yuu's eyes there.

After promising to meet again, Yuu shook both their hands simultaneously. Watching this, Kanako and Touko felt complex emotions, especially Touko who glared half-lidded at the nurses upon hearing "semen." But the nurses, engrossed in Yuu, didn't notice.

---

### Author's Afterword

[Supplement] (Simple naming though)

This world - Chastity Reversal World:

・Danger days → Lucky days (当たり日)

・Safe days → Off days (外れ日)

Revised 2019/2/24  
Head nurse → Nursing director (to match "nurse")

### Chapter Translation Notes
- Translated "当たり日" as "lucky days" to convey fertility concept while maintaining world-specific terminology
- Translated "外れ日" as "off days" as cultural counterpart to fertile/infertile periods
- Preserved "sacred fluid" for "聖液" as established euphemism for semen
- Maintained explicit anatomical terms ("penis", "vagina", "cervix") per style rules
- Transliterated sound effects: "ぬぽっと" → "splurch", "ぬちゃり" → "schlick"
- Kept honorifics (-sama, -san) and Japanese name order throughout
- Formatted simultaneous dialogue with double quotes per Fixed Reference rules
- Translated "看護師長" as "nursing director" for professional title accuracy