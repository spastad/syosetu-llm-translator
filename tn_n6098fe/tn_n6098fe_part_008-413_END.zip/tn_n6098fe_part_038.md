## 33. Golden Week ⑤ ~MUGO・Hmm... Alluring?~

April 29th, Sunday.

The day had come to visit Rei, my high school friend, as previously arranged.

That said, it was merely descending from the 11th floor where I live to the 10th floor.

Despite such proximity, Kanako and Touko accompanied Yuu.

I tried saying it should be fine alone since it's within a secured apartment building, but apparently there was an incident where a high school boy walking alone in the hallway got assaulted.

The perpetrator was a woman in her thirties living downstairs who'd seen him leaving at the same time every morning and became convinced he was timing it for her, developing a delusion of mutual affection. There are also occasional cases of suspicious individuals bypassing security to lurk on male-occupied floors.

Thus, flanked by Kanako and Touko as usual, Yuu descended to the 10th floor via stairs and stood before Room 1005 where Rei lived, ringing the intercom.

"Who might this be?"  
"It's Hirose. I have an appointment with Rei-kun today."  
"Yes. Hirose-sama, correct? Please wait a moment."

The door was opened by a male protection officer in a black suit whom Yuu recognized from when he'd walked Rei home. His distinctive features included shoulder-length shaggy hair and flashy makeup, giving a sensual impression. Behind him stood a contrasting figure with long black hair and a docile appearance. "Welcome," they both said, breaking into gentle smiles upon seeing Yuu.

Rei's protection officers weren't particularly tall or intimidating like ordinary people. But their alert movements and tense demeanor during guard duty revealed their professional expertise despite appearances.

When the officer further inside signaled, the left door opened and Rei immediately emerged saying, "Yuu-kun!"  
"Hey."  
"I've been waiting! Come on in."  
"Now, now, Rei dear. Ohohoho."

Standing near the doorway were a woman who appeared around late twenties and a girl who looked early teens. Yuu guessed they were family since he'd heard Rei had a sister.

"We shall take our leave for now. Please contact us when returning."  
"Okay. Got it. Thank you, Kitamura-san, Kujira-san."  
"You're welcome!"  
"Excuse us."

They bowed their heads and left. Yuu found it inconvenient that without a cellphone, he could only contact them via landline, but since that was normal in his youth, he resigned himself to it.

Entering the living area, Yuu formally greeted the Higashino family. "Pleased to meet you. I'm Hirose Yuu from Rei-kun's class. This is nothing special, but..." He'd bought boxed sweets yesterday with Kanako and Touko - a safe choice of assorted cookies since he didn't know their preferences.

"My, thank you for going to the trouble. I'm Rei's mother. Rei always talks about you - it's Yuu-kun this, Yuu-kun that at home."  
"O- mom!"  
"R-really... Wait, you're his mom? I thought you were his older sister since you look so young."

It was a line Yuu had always wanted to say, though only seen in manga. Truthfully, Rei's mother was indeed youthful and beautiful enough to warrant it. She was about Rei's height with light brown semi-long hair curled softly inward. A loose navy blue top suited her fair skin, paired with an elegant floral long skirt. Her gentle gaze and slim figure made her seem nothing like a mother of two - a feminine, charming adult woman who looked barely thirty, completely opposite to Yuu's mother Martina in type.

"My! Such a young boy yet so smooth-talking!" Rei's mother widened her eyes, covering her mouth in surprise at Yuu's words, a faint blush coloring her cheeks. The effect seemed tremendous.

"Fufu. Even coming from Rei's friend, it makes me happy to hear that from a boy. Now... Satomi, say hello properly too." She urged the girl clinging closely behind Rei.  
"I-I'm Satomi... Rei's sister."  
Though nearly the same height as Rei, she was slightly shorter. Her long black hair reaching her back was tied in twintails with pink ribbons. The siblings resembled twins, though Yuu recalled the sister was still in middle school. With Rei's androgynous, sweet features, his sister was undoubtedly a beauty too. A pale orange dress with frills suited her slender frame well, covered by a thin black cardigan that hid her barely noticeable chest.

"Hello, Satomi-chan." Yuu smiled in greeting, but she hid further behind Rei as if wary. Perhaps shy? Yuu found this reaction refreshingly different from schoolgirls.

"Really, Satomi... Rei never brought friends home in middle school. I'd been excited like a silly schoolgirl to meet Yuu-kun after hearing how handsome, reliable and unflappable he is. But this child's shy - sorry about that."  
"Not at all, I don't mind."  
If anything, Yuu wondered how Rei had described him at home.

"This way, Yuu-kun."  
"Ah."  
"I'll bring tea and sweets later."  
"Ah, don't trouble yourself."

As his mother headed to the living room, Yuu followed Rei into his room. The layout seemed identical to his own apartment.

"U-um, I tidied up in a hurry so it might look messy in places... Don't mind it."  
"Nah... Looks plenty clean to me."

Like Yuu's pre-reincarnation room, Rei's was neatly organized. But whereas Yuu's room had standard boyish blues and greens, Rei's pastel pinks, creams and lavenders gave it a girlish atmosphere - something hard to comment on to his face. Boys' rooms typically didn't have teddy bears on beds or lace curtains on shelves.

Most notably, Satomi - who Yuu assumed would either return to her room or join their mother in the living room - naturally followed Rei in and sat right beside him. It was so natural Yuu was speechless. Rei wore a wry smile but didn't send her away, apparently resigned to it.

Yuu sat across the apple-shaped table. The siblings sat on purple and pink cushions, Yuu on light blue.

"Quite a nice room."  
"R-really? I felt embarrassed to show it like this, but suddenly redecorating seemed weird too."

He seemed somewhat aware. Yuu kindly refrained from pointing out how unmanly it was. He vaguely sensed Rei's tastes stemmed from family influence. Previously, Rei mentioned living in an obscure western Saitama town before moving here, surrounded by grandmother, aunts, cousins, mother and sister - all women except his father who visited twice weekly.

They chatted about room items until Rei's mother brought tea and sweets. Yuu and Rei got iced café au lait, Satomi orange juice. Seeing Satomi comfortably settled in as usual, Rei's mother looked troubled, but Yuu smiled and shook his head to indicate it was fine. Not wanting to exclude her, Yuu ventured conversation.

"I think Rei mentioned you're in middle school, Satomi-chan? What grade now?"  
"Second year." She made eye contact but gave minimal answers.

"Entrance exams in two years? Thinking of Sairei Academy?"  
"Of course! I'll definitely get in!"  
"Oh? Confident? I hear competition's tough for girls." Yuu's question made Satomi's eyes light up despite her earlier shyness.  
"Entering Sairei in two years is an absolute future for me! Until then, I have to watch closely so no wicked women snatch my brother before third year!"  
"Ooh... I see."

Satomi straightened up facing Yuu directly. "Um, Yuu-san?"  
"Yeah?"  
"I heard you're my brother's closest high school friend. Until I enroll, could you watch over him so wicked women don't catch him? Please, I beg you." Still kneeling formally, Satomi bowed, her long black hair cascading down.

Yuu flustered at the sudden request. "Ah... hey, lift your head, Satomi-chan. I'll do my best to protect Rei from scary experiences anyway. Well, within my sight range at least."  
"Yes. Please take care. There've always been many women who like cute boys like my brother."

*(There are already quite a few girls who admire Rei though...)* Yuu thought but didn't voice it. Instead he smiled. "Satomi-chan really loves her brother, huh?"  
"Yeah! I love him!"  
"W-wait, Satomi!"

Satomi hugged Rei's arm with a radiant smile, having said her piece without reservation now. *(Severe brocon...)* Yuu felt slightly overwhelmed. Had his own sisterly relationship not soured, he and Elena might have been like this.

"Speaking of which, don't you have an older sister, Yuu-kun?" Rei asked while patting Satomi's head. Apparently he doted on her too, as Satomi looked delighted.  
"Yeah, but we're not close like your family. Some things happened before..."  
"I-is that so..."

Likely last winter, but those events seemed traumatic enough for Yuu to block them out - he couldn't recall no matter how hard he tried. Hence the vague response.

Satomi broke the slightly heavy atmosphere. "Hey, big bro! Since it's a good chance, let's show Yuu-san that!"  
"That? Now?"  
Satomi whispered something in Rei's ear.

"Eh!? R-right now?"  
"Yeah! Yuu-san will be surprised for sure!"  
"But..."  
"Come on!"

Seeing them whisper made Yuu curious. "Something that'd surprise me? I'm intrigued."  
"See? It's fine!"  
"Hmm..."

Rei gave Yuu a pleading look, but before Yuu could react, Satomi forcefully dragged him away. "Wait about 30 minutes! Read manga or something meanwhile!"  
"Sorry, Yuu-kun!"

Left alone, Yuu browsed the comic collection on the color-crate shelves - all shoujo manga. Did this world even have shounen manga Yuu would enjoy? His own room had manga with boy protagonists, but with delicate, soft art clearly drawn by women. None had the rough, dynamic art style of male-drawn shounen manga.

Not inclined to pick up manga, Yuu noticed photo frames by the pillow: one showed Rei and Satomi in matching dark gray uniforms before a school gate (likely Satomi's middle school entrance), another a family of four. *(Rei takes after his father, not mother.)* The youthful, androgynous man who emitted little masculine energy must be the father - resembling an adult version of current Rei. Alongside the mother, they looked nothing like parents of middle/high schoolers.

While examining photos and fiddling with the teddy bear, Yuu heard soft *kon kon* knocks. Probably Rei returning, though why be polite in your own room? "Come in."

The door opened to reveal Satomi. Same outfit and hairstyle, but now lightly made up. For some reason, her walk seemed awkward and she avoided Yuu's eyes. Had her shyness returned? Or was she nervous being temporarily alone with Yuu?

*(Makeup... Huh? Could it be?)* Yuu recalled Rei mentioning crossdressing since childhood, sometimes dressing as a girl on family outings. Behind two photo frames was a smaller one showing two elementary school girls. They resembled twins, but the one with bobbed hair slightly taller was likely Rei. *(I see - he's coming in drag. Satomi-chan came first after finishing makeup.)* It made sense he'd be embarrassed before friends. What reaction was appropriate? Having no crossdressing friends, Yuu decided complimenting how well it suited him would do.

Trying conversation first: "Is your brother coming after this?" The "girl" flinched, glancing up at Yuu from under her lashes. Though two years younger, she exuded strange allure, making his heart skip. With makeup, she seemed older than her age, putting Yuu in an odd mood. *(Hooking up with a friend's sister during a visit? Fine in eroge but...!)* Since Rei would return any moment, Yuu suppressed such thoughts.

As they locked eyes in a strange atmosphere, the door suddenly swung open, nearly stopping Yuu's heart. "Ta-da! How was it, big bro!?"  
"Huh?"

Identically dressed Satomis stood beside him and in the doorway. Yuu froze.

"Seriously! I couldn't tell at all!"  
"Sorry. I thought you'd notice up close."  
"Totally fooled - I panicked!"

The lookalike pair stood side by side, likely wearing wigs. Though Rei's voice was deeper post-puberty, speaking might have revealed him.

Yuu slumped forward, shocked less by failing to recognize crossdressed Rei than by feeling attracted to "her." Though aware of "otokonoko" from 21st century internet, he had no such interests. No matter how girlish, he shouldn't feel drawn to a boy. Inside, he screamed *"How dare you trick me?!"* but suppressed it.

"Hey hey, Yuu-san's handsome too though different from big bro, right? No thick beard - wanna try makeup?"  
"Hmm. Yeah. Yuu-kun would look like a mature big sister crossdressed."  
"Eh, wait!"  
"Wanna try since we're at it?"  
"It's okay for first-timers! We'll make you pretty!"

Cornered by the twins' sparkling eyes, Yuu faltered.

"Is this... me?"  
Staring at his reflection in the hand mirror, Yuu was stunned.  
"Could pass without suspicion outside."  
"Amazing, Yuu-kun! So beautiful!"

Heavy eyeshadow, faint blush on cheeks, crimson lipstick. From multiple wigs, they chose long black hair with waves. The exotic beauty resembled a younger version of his mother Martina. Forced into a bright red opera-style "Carmen" dress, he felt uncomfortably breezy around the crotch.

The wig alone left some drag queen vibe, but makeup perfected the transformation. As the siblings said, appearance-wise he might pass as female.

"Mommy!"  
"Yes, dear?"  
"W-wait!"

Satomi's call summoned her mother. Finding an unknown woman in her son's room would cause panic, especially in this world.

"Wha-!? Who are you!? How did you-? Must call the police - no, protection officers!"  
"M-mom! Wait!"  
"It's Yuu-kun!"

The gentle mother nearly transformed into a demon before Rei and Satomi frantically stopped her.

"My my my, oh dear. Is that so? That so? Yuu-kun is handsome after all. Mommy completely panicked... How embarrassing."  
"Don't worry, I totally understand."

Fellow deceived souls understood each other.

"I know! Got a great idea! Next time, why not go out together with Yuu-kun dressed like that?" She clapped, beaming.  
"Great idea!"  
"Yeah! Want to hang out with Yuu-kun!"

*You're all on that side!?* Yuu slumped. While uninterested in crossdressing outings, an idea struck him: Boys never walked alone here except commuting, always guarded. But crossdressed, he might roam freely outside.

---

### Author's Afterword

Skipping the latter half of Golden Week, next time moves to school events.

### Chapter Translation Notes
- Translated "MUGO" as transliterated sound effect without interpretation
- Rendered "色っぽい" as "alluring" to convey sensual nuance
- Preserved Japanese honorifics (-kun, -chan, -san) throughout
- Transliterated sound effects (e.g., "kon kon" for knocking)
- Translated internal monologues in italics with asterisks
- Maintained original Japanese name order (Higashino Rei, Hirose Yuu)
- Translated explicit terms directly ("crossdressed", "breezy around the crotch")