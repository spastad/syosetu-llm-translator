## 36. Newcomer Welcome Orienteering ③ ~Let Me Off the Hook!~

After finishing at the restroom, Yuu and Rei began returning to the clearing where everyone waited, surrounded by the six girls of Group 5.

The first to react to the malice directed at them and the multiple footsteps were Risa and Miyoko.

Both had been volleyball club members since middle school, excelling as spikers and blockers.

However, in the physical education course where admission is primarily through recommendation, performance in official tournaments during the second and third years of middle school greatly influences acceptance. Making it to prefectural representatives or advancing to finals in prefectural tournaments multiple times is ideal. At minimum, reaching the quarterfinals is the baseline.

In this regard, their junior high school had few club members, and aside from reaching the quarterfinals in their third-year summer, they only made it to the second or third rounds.

Nevertheless, after passing Sairei Academy's general academic exam and joining the volleyball club, they demonstrated physical abilities comparable to physical education students. Consequently, they were seen as potential regular members after the third-years retired.

Excellent athletes excel not only in physical and sensory abilities but also in animalistic intuition - what you'd call good instincts.

Without exchanging words, they signaled each other with just their eyes.

""Dangerous!""

The group had just started walking along the forest path from the restroom toward the clearing. To their left was a mountain slope, while beyond the guardrail on their right was a cliff.

Positioned diagonally behind on the left, Risa pulled Rei's petite body close as she retreated sharply. Miyoko, on the right, forcefully pushed not only Yuu but also Kazumi beside her forward.

These girls weren't so slow-witted as to freeze upon hearing their teammates' warnings. Sensing an emergency from their urgent demeanor, they quickly moved to Yuu or Rei's side.

Pebbles rained down on the suddenly vacated space, but fortunately, no one was hit.

Dada da! About five or six girls in purple jogging suits rushed down the mountain slope, surrounding Yuu's group from front and back. More descended from the slope side to strike from the flank.

"Tch, they dodged it. Well, whatever. You two boys over there, come with us. Don't worry, we won't hurt you if you behave."

"About ten loads per person, I'd say."

"These are top-grade goods! I wanna devour both!"

"Me too!"

""""Gyahahaha!""""

The purple jogging suits were likely for camouflage. Up close, it was clear they weren't from the same school. Their vulgar speech and delinquent appearance suggested they might be students from the notoriously troublesome Ichimatsu High.

At that moment, near the restroom, the security squad's vanguard was talking with Group 3's security team about 100 meters ahead at a crossroads. The rearguard was with Group 5 resting in the clearing, roughly 50-60 meters away. The gently curving path offered poor visibility.

The security team had been vigilant about threats approaching from the path's front and rear but never anticipated an attack from the slope, leaving them completely off guard.

The group leader, Yoko, immediately gave orders.

"Risa, Miyo - protect Higashino-kun! Kazumi, Mashiro - protect Hirose-kun! Yuema - that thing!"

""Okay!""

""Got it!""

"Nn!"

Despite being caught off guard, their actions showed no hesitation. Perhaps they had anticipated such a situation.

Yuema, who had somehow removed her backpack, took out round objects about ping-pong ball sized and lit fuses protruding from them with a lighter. She threw them consecutively toward the front and back.

The round objects shattered upon impact, spewing thick smoke that enveloped the area.

"What the? Whoa!"

"The smoke!"

"Shit! Can't see!"

"Now, while we can!"

"""Roger!""

Yuu was sandwiched between Kazumi and Mashiro as they dashed toward the clearing. Right behind them, Risa and Miyoko followed, protecting Rei. The group slipped through the right side of the purple-jacketed girls blocking their way.

"Oh, the boy!"

"Take this!"

One girl lunged at Yuu, but Mashiro threw something she was holding.

"Gyaa! My eyes, my eyes~!"

It hit squarely in the face, the powder robbing her of vision. Yoko body-slammed another nearby assailant while Yuema, moving with unexpected speed, tripped a third with her foot. They broke through the opening.

"Stop right there!"

"Stop, I say!"

No one would stop just because they were told. Seeing Yuu's group escaping, the jogging suit girls immediately gave chase. Reaching the clearing would reverse the situation. Some members of Group 5 nearby seemed to have noticed the disturbance and were shouting something.

Just when it seemed they'd narrowly escaped the suspicious group's ambush thanks to their quick-thinking classmates, something happened as Yuu thought they just needed to run and regroup with their classmates and security seniors.

"Kyaa!"

The cry came from Kazumi, running immediately to Yuu's right. The smoke, blown by the wind, helped obscure them from their pursuers but also made footing unclear. Unfortunately, at a spot without guardrails, Kazumi stepped off the road's edge and nearly fell down the cliff.

"Aki-san!"

Yuu instinctively stepped sharply right, reaching out to grab Kazumi's arm as she fell. This caused Yuu to lose his balance too.

"Hirose-kun! ...Tch, everyone else go ahead!"

"Yoko!? Eh, wait!"

Seeing Yuu and Kazumi falling down the slope, Yoko didn't hesitate. After just calling out to the others, she jumped after them.

The lead pursuers hesitated upon seeing them fall. Continuing along the path risked a brawl with Sairei Academy's reinforcements who were rushing over. Since the enemy outnumbered them, they were at increasing disadvantage after the failed ambush. So they decided to chase the boy down the slope and secure him. If they could take him somewhere unseen, he'd be theirs. Better to catch one likely prey (a man) than chase two rabbits.

Several made this decision on the spot and descended the slope, totaling over ten including followers. Though only a minute or two passed, this bought Yuu precious time. The remaining third, blinded by smoke, continued along the path but Rei was welcomed by Group 5's girls, and the security team repelled them, forcing a hasty retreat.

"Guah! Ouch! Ugh... Whoa, can't stop!"

Yuu had grabbed Kazumi's arm as they fell, but the steeper-than-expected slope made stopping impossible, and they tumbled down together. They were lucky the slope was mostly soil with few rocks, and layers of fallen winter leaves cushioned their fall. They tried stopping when hitting trees but poor footing made them slide uncontrollably. Initially sliding down on their backsides, they soon ended up embracing each other while rolling down. Yuu suddenly recalled tumbling like this before his rebirth in this world. But unlike then, Kazumi was with him now. He shielded her head during the fall to prevent injury.

Then, his body floated briefly before thudding hard against the ground, rolling slightly, and crashing against a large tree's roots.

"Kyaa!"

"Gah! Tsuu..."

The fall ended, and Yuu caught his breath. Wincing at pains throughout his body, he looked at Kazumi in his arms. Her eyes were closed.

"Aki-san... Aki-san! Are you okay?"

"Ah, uh... Oh! Hehe, Hirose-kun!"

Startled to find Yuu's face so close, Kazumi's eyes flew open, mouth agape. But they both realized they were covered in leaves and dirt.

After briefly separating, Yuu checked himself. Relieved he could move his limbs and wasn't bleeding, though numerous bruises and scrapes hurt.

"They might chase us. Can you stand?"

"Ah, yeah. I-I'm okay!"

As they stood up: "Whoa, whoa, whoaaaaaaah!"

A sliding sound - zusasaaaah! - preceded someone suddenly emerging from a 2-meter drop right before them, landing on their backside and sliding toward them.

"Huh!?"

Recognizing who it was, Yuu crouched and braced himself, firmly catching her body.

"Kyann!"

"Whoa! Hiyama-san, did you chase after us?"

"Eh, ehehe."

"Reckless."

"B-but I said today I wouldn't leave Hirose-kun's side no matter what!"

"Is that so... Yeah, thanks for coming."

"Uh-huh. You're welcome!"

"I don't think this is the time for that."

Kazumi admonished Yoko, who was clinging to Yuu and grinning, despite doing the same herself moments ago.

"That's right! They're chasing us from behind, we have to escape!"

"Wait a sec."

When standing earlier, Yuu glimpsed that continuing downward would lead to a ravine. Crossing it seemed to reach a road, but the footing looked treacherous, risking encirclement. Instead, something caught his eye when catching Yoko.

"How about hiding there?"

It looked like a hole in the slope. Mountain slopes sometimes have thin drainage pipes, but this one was thicker, over 1 meter in diameter - wide enough to enter while crouching. Similar to pipes protruding in empty lots from that cat-shaped robot anime.

Voices and noises came from above, so they hurried. Fallen leaves and broken branches littered the area. A conveniently sized "Beware of Forest Fires!" sign lay toppled.

After propping the sign against the entrance gap, Yuu entered first. The two girls camouflaged it with broken branches from outside. When they entered, they blocked gaps with branches and leaves that seemed to have washed in. Just then, voices came from right above.

"Where'd they go? They're not here!"

"That girl fell down just now, right?"

"Shit! Find them! Find them no matter what!"

They seemed to have descended near the large tree Yuu hit. The timing was razor-thin. "Let's go further in."

Inside was concrete, but stagnant air and a damp smell lingered, likely from accumulated soil and leaves. Fortunately, no water flowed or pooled due to continued fair weather. Not high enough to stand, they advanced hunched over. Near the entrance, light seeped through gaps, but darkness soon enveloped them. So dark you couldn't see your nose if pinched. The tunnel sloped slightly upward. Holding the hem of the person ahead, they advanced in order: Yoko, Yuu, Kazumi.

"Seems we can't go further."

They stopped before 10 meters. Feeling ahead, Yoko reported it split into three narrower paths too small to enter.

"Then let's sit and wait it out here."

"Yeah. At this point, we can only pray we're not found."

"......"

The ground felt cold to sit on. Before Yuu could take his packed jersey from his backpack, Yoko and Kazumi quickly spread their own jerseys on the ground.

"Sorry about that."

"It's fine, really. Don't worry. Let's sit."

Yuu sat sandwiched between Yoko on his left and Kazumi on his right. "It's quite cold inside."

"Yeah, it is..."

All three wore short sleeves. The unlit culvert felt as cold as an over-air-conditioned room.

The two girls kept a slight distance, seemingly hesitant to touch Yuu. "Get closer."

"Eh, but..."

"Just do it!"

"Ann!"

"Whoa!"

Yuu spread his arms and pulled Yoko and Kazumi close. Sandwiched between their athletic yet soft bodies - toned yet yielding from sports. Their warmth and sweet-sour sweat scent made Yuu flush.

"Ah...fua...H-Hirose-kunn..."

In the darkness, Yoko wrapped her arms around Yuu's back and clung tightly.

"U...gus..."

"Hm?"

Leaning against him from both sides, Yuu noticed Kazumi's cheek felt wet. "Aki-san, are you crying?"

"Wueh, ehh...guu...sorry...I'm sorry. If I hadn't messed up and dragged Hirose-kun into this, we might've escaped safely...so-sorryyyy!"

Her earlier silence stemmed from guilt. Yuu patted Kazumi's head. A rustling sound came from leaves stuck in her hair. Brushing them off with his fingers, he gently stroked her head.

"Aki-san... Don't cry. Reaching out to grab you when you fell was my choice. You'll stay by my side today, right?"

"But, but..."

"It's okay. Actually, I wanted to be close to you like this."

"R-really...?"

"Ahh. Kinda jealous. Kazumi, you've been oddly lucky since club observation day."

"That's not..."

"I've liked Hirose-kun too! Loved him so much it hurts since we first met!"

"Eh!?"

Yoko's sudden confession. But Kazumi wouldn't be outdone. "Me too! I like Hirose-kun! Not just handsome, but kind, with a wonderful smile, like an ideal prince."

"Ahaha. Embarrassing."

The near-total darkness perhaps made them bold. Though opposite types, both ranked among Class 5's cutest girls. Hearing such direct affection, no man could help feeling pleased.

"Thank you both. That makes me happy. I've been interested in Hiyama-san and Aki-san since club observation too."

Saying this, Yuu hugged them tighter.

"Fua...Hirose...kun..."

"Ahaa..."

Had it not been dark, both girls' equally flushed faces would've been visible. Relieved their confessions weren't rejected, Yoko and Kazumi clung tightly to Yuu.

### Chapter Translation Notes
- Translated "見逃してくれよ" as "Let Me Off the Hook!" to convey the pleading tone in the context of evading pursuers
- Preserved Japanese honorifics (-san, -kun) per style rules
- Transliterated sound effects (e.g., "dada da" for ダダダ, "gya" for ぎゃっ)
- Maintained original name order (Hiyama Yoko, Aki Kazumi)
- Translated explicit anatomical terms directly ("backside" for お尻)
- Used gender-neutral "delinquents" when original Japanese didn't specify gender (though context implies female)
- Rendered sexual frustration references explicitly ("ten loads per person")
- Kept culturally specific items untranslated (bloomers referenced indirectly via sports context)
- Italicized internal monologue markers preserved but none present in this chapter