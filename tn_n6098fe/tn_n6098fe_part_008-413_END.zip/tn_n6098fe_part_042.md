## 37. Newcomer Welcome Orienteering ④ ~Kiss in the Darkness~

"U-um, it's about the future, but..."

Yoko abruptly started the conversation.

"In our second year, dating becomes allowed, right?

S-so, at that time, I was thinking... maybe I could reserve a spot as Hirose-kun's potential girlfriend...?"

Perhaps because she knew it was a preemptive move, her voice trailed off.

Yuu recalled that, officially, that was the case.

At school, he had physical relationships with three student council members, but he was technically free.

Kazumi hastily interjected.

"Me too! I'd do anything for Hirose-kun! So... if you could meet with me sometimes at school and talk... Sorry, I don't know much about boys, but being with Hirose-kun makes me feel really happy... Aaah, what am I saying...?"

Yoko and Kazumi.

Yuu also thought favorably of these two, whom he had connected with during the basketball club visit.

That's why he had secretly manipulated things so they would be in the same group today.

In that case, what harm was there in marking them as his own now?

Yuu raised both hands and began stroking the girls' napes and hair.

After stroking Yoko's slender, long nape, he played with the ends of her shoulder-length bob. He could tell the ends were fine and smooth.

Kazumi had her hair neatly braided, so the area around her face was clear and her skin was exposed, giving off a surprisingly alluring charm despite her plain hairstyle.

In the darkness, as Yuu ran his fingers over their ears, napes, and down to the napes of their necks, feeling the smooth texture of their skin, both girls let out sweet sighs. "Haaahn~"

"Yoko."

"Eh!?"

"Kazumi."

"Y-yes!"

"While the three of us are together, let's call each other by our first names."

"Eeeeeeeeh!? Really!?"

Their voices harmonized.

"Because Yoko and Kazumi are becoming special to me among the first-year girls. I want to get closer. So, let's drop the formalities."

He drew both their faces close to his, bringing them so near that their cheeks touched.

"A-ah... Yuu-kun?"

"Yeah, Yoko."

"Yu... Yuu-kun. I'm happy... ufufu... Yuu-kun!"

"Yeah, Kazumi."

Yoko and Kazumi's voices were filled with emotion.

For Yuu, not only had his relationship with the two grown much closer, but the warmth of the girls clinging to his hands was also arousing him.

Taking advantage of their cheeks being pressed against his, he shifted his face and captured Yoko's lips.

"Mmm? ...Fah!? Wh-what was that just now!?"

Then Kazumi's lips.

"Mmmmeeeeeeh!"

"Ki-ki-ki, a kiss!"

"It's a greeting to commemorate today, when you both confessed your feelings to me. Want to do more?"

There was no immediate reply, but he could feel them nodding repeatedly.

Without any further hesitation, Yoko on the left and Kazumi on the right pressed their bodies tightly against him.

Yuu could feel the swell of their breasts pressing against his sides from under his arms.

Yuu kissed them alternately, one by one, feeling their sweet pleading voices and hot breaths, and realized that as time passed, both girls were becoming more aroused.

"Mmm, chuu, chuu! Ah... nn... Kissing Yuu-kun, mmph! Feels super good!"

"Chuu! Mmm... ahfuu... Me too, it's like a dream... Yuu-kun!"

"Fufu. Yoko and Kazumi are both really cute. Now, stick out your tongues and say 'ahh'."

"Aaaaaaahn~"

Yoko and Kazumi brought their cheeks close to Yuu's front from left and right, sticking out their tongues as instructed.

Yuu stuck out his own tongue and began licking theirs alternately.

He overlapped his tongue with Yoko's, up and down, then with a string of saliva still connecting them, he pressed his tongue against Kazumi's.

While making wet, squelching sounds inside Kazumi's mouth, Yoko began to plead, and with a "buchi" sound, their lips met again, half-open.

Yuu's hands, which had been holding them close from behind, moved to the front and began groping their breasts, but the two were so engrossed in kissing that they didn't mind at all.

Yoko's breasts were somewhat small. Kazumi's seemed larger than average.

The repeated exchange of kisses heightened the trio's excitement.

"Lero, lero, fahn! Ufuu... Yuu... kun... more!"

"Fufu. Yoko, here."

"Chuu, chuu, chupaa... aahn~"

"Ahhn, Yuu-kun, me too!"

"Ahh, Kazumi. Stick your tongue out more."

"Aahh... chupa, julu... lerooo... ahfuun... feels so gooood... my head feels like it's melting."

"Haa, haa... Hey, Yoko, Kazumi. I have a request."

"What is it? Yuu-kun."

"If it's Yuu-kun's request... I'll do anything."

Yuu took their hands and guided them to his crotch.

It was rock hard.

If it had been light, it would have been visibly bulging.

"Wawaah!"

"Feh, is this maybe...?"

"Haha. After all that kissing with you two. I got excited and ended up like this.

Will you both touch it for me?"

"Fwoah!"

Yuu lowered his sweatpants along with his underwear to his knees.

His cock sprang back, asserting its presence in the darkness.

Yoko and Kazumi tentatively touched it.

"It's hot! And... hard... and, wow, amazing."

"O-oh... A boy's cock is this big?"

"It might be bigger than the average guy's. So, will you take good care of it?"

The two responded with actions rather than words.

Though timidly, they slowly began stroking Yuu's cock.

Their awkward yet gentle touch felt pleasant for now.

"It's a shame it's dark and I can't see, but just by touch I can tell. Yuu-kun's cock is bigger and more impressive than the ones in dirty books."  
"Haa, haa, just touching it... eeeh, I'm getting so horny! Ahn!"

Yuu's hands had started stroking their butts.

"I want to touch Yoko and Kazumi's pussies too."

"Fah!? Yuu-kun, touch me, touch me!"

"Aahn... I can't believe Yuu-kun is touching me..."

Yuu helped each girl lower her bloomers and panties to her knees.

The two knelt facing each other on either side of Yuu, slightly spreading their legs and raising their hips.

Yuu slid his hands over their smooth buttocks, savoring the feel of their firm flesh, then slowly reached for their private parts.

*Squelch, squelch.*

Both were already drenched.

"Ah... nn~"

"Haaun!"

"Amazing. You're both so wet."

"Uu... it's because of Yuu-kun..."

"Aaun... I love Yuu-kun so much... kissing and doing this... I'm sorry. I'm so lewd."

"It's fine. Yoko and Kazumi can be as lewd as you want in front of me."

"Ahn!"

"Yuu... kun."

Neither girl knew a boy as handsome, gentle, and tolerant as Yuu.

Though they had been looking down at his cock in the darkness, they both raised their faces at the same time, seeking him.

After kissing them alternately and tangling tongues, Yuu whispered to them.

"Next, can you both lightly grip my cock, stroke it, and suck the tip?"

"Su-suck it..."

"Ufu, gladly!"

The two brought their mouths close to Yuu's crotch as instructed.

In doing so, they ended up presenting their buttocks to him.

Overlapping their hands, they stroked from the base to the head while extending their tongues to lick the tip.

"Ahh... good. I'm happy to have you both sucking my cock."

"Uun... I'm the happy one..."

"Me too. It's Yuu-kun's cock, which I love so much."

"Fufu. Then, here goes."

"Aaaahn!"

For both Yoko and Kazumi, not only was this their first sexual act, but Yuu was also their first kiss.

They had aimed for Sairei Academy, a co-ed school, and after passing the highly competitive entrance exam, they dreamed of finding a wonderful boyfriend and getting together during their time there.

The gender ratio changed from 1:30 in middle school to 1:7, so they thought their chances had increased.

However, Kazumi had been intimidated by the fact that the girls selected were so many and so attractive.

On the first day of the entrance ceremony, they immediately spotted an exceptionally handsome boy.

They were delighted to learn he was in their year, named Hirose Yuu, and hoped to make contact someday.

Then, during the club visit in April, they were blessed with the luck of playing a mini-game together and were able to chat amiably at the greeting event.

Furthermore, today they received the unexpected fortune of him joining their group.

Most girls believed that even if a boy treated them coldly, they shouldn't get discouraged but try to please him, and that they should comply with any request. If they asserted themselves, they would be easily discarded and beaten by rivals.

Even so, as humans, they naturally preferred kindness.

Being ignored or treated coldly was worse than being smiled at.

Yuu was not only beautiful in appearance but also had a good personality, and his mature, composed demeanor was also attractive.

Just being by Yuu's side and talking to him made their adoration grow even more.

By now, both girls' affection for Yuu was at maximum.

Just having their bodies pressed together made them unbearably aroused.

Originally, both Yoko and Kazumi had comforted themselves countless times in their rooms using Yuu as material.

Now that their dream had become reality, and because it was dark and they couldn't see, they were more sensitive than ever.

Of course, for Yuu too, a double blowjob from two cute same-year girls he had grown close to was exciting.

Regardless of technique, their innocent, wholehearted stroking and sucking with hands and mouths sent his excitement soaring.

*Chupu, chupu. Jurup, jupo! Chapu, juppu, juppu!*

The sounds of the two sucking his cock, slick with pre-cum and saliva.

The wet sounds of their love juices playing each time two fingers stroked them.

In the culvert, lewd sounds from Yuu, Yoko, and Kazumi's genitals echoed without end.

"Mmmnn! Puhah... ah, ah, what's... happening... ahn, ahn, Yuu-kun! Aah... I'm...!"

Both were moaning as they were fingered while desperately sucking his cock, but the first to approach her limit was Kazumi, whom Yuu was fingering with his right hand.

"Mmm, mf... me too, nn... aah! I-it feels so good, Yuu-kun! When you touch me, it feels amazing!"

Yoko also rubbed her cheek against his cock and raised her chin.

"Ah, ah, ah, I'm cumming, cumming! Yuu... kun! I'm cumming!"  
"Me tooooooo, I can't hold it... aaaah, ah, ah, I'm cummiiiiiiiiiiing!!"

Yoko dripped love juices continuously, while Kazumi sprayed her fluids with a splashing sound as she came.

"Ooh, you came already? You're both sensitive, aren't you?"

"W-well..."  
"It's because Yuu-kun touched us..."

"Is that so? I'm glad. I'm about to come too. Both of you... make me cum."

"Fai!"  
"Ahn, your cock..."

With ecstatic expressions, Yoko and Kazumi sucked Yuu's cock with all their might.

Since it was their first time touching and sucking a cock, they had no technique.

But emboldened by the darkness, they stroked Yuu's cock with all their hearts.

They kissed every part of the glans with "chuu, chuu" sounds, licked up the dripping pre-cum as if competing for it.

Sometimes competing, sometimes cooperating, their caresses naturally brought Yuu to the brink.

"Hah, haa, ahh... good! Feels so good!"

"Chu, chupa! Aha, Yuu-kun's desperate voice is so arousing. Let me hear more. Here, here... mm~ lero chu~"  
"Aaahm lero lero jupu! Yuu-kun's cock is delicious~"

Yoko and Kazumi weren't just doing this because Yuu asked; they were also following their own desires and enjoying sucking his cock.

This gave Yuu more pleasure than he expected, and he soon reached his limit.

"Guh... haa... Yoko, Kazumi... I-I'm cumming! Cumming! Ahh!"  
"Nn... nnuu?"  
"Afu!?"

Since both were competing to suck the glans at that moment, the first spurt went almost equally into their mouths.

But in their surprise, they pulled their lips away, so the second and third spurts splattered messily onto their cheeks.

"Aah... it's hot... so much hot stuff..."  
"Waa... it's coming out of Yuu's cock..."

Still stroking with their hands, they tried to catch the overflowing semen and lick it up.  
"Haha. Thank you, Yoko, Kazumi. That felt really good."

Even after finishing, Yuu gently stroked the heads of the two girls who continued to lick him clean.

---

Using the tissues they had on hand, the three wiped each other off and adjusted their clothes.

Subjectively, it felt like 30 minutes to nearly an hour had passed since they hid in the culvert.

Thinking that the purple-jerseyed women who had chased them might have given up by now, they went to the entrance to check.

First, leaving Yuu behind, Yoko and Kazumi went out.

"Hmm, seems like they're gone now."  
"Just to be safe, should we go out and look?"  
"Then, Yoko, you go first."  
"Eh? Kazumi, you go."  
"You first, you first."

In the end, Yoko, who lost at rock-paper-scissors, pushed aside the branches and leaves used for camouflage and stepped out. Immediately, two, then three tall women emerged from the shadow of a nearby tree and called out when they spotted Yoko.

"Ooh!"  
"Geh! ...Huh?"  
"You... what, a Sairei Academy student?"  
"Se-senpai!"

They had encountered the security team seniors.

At Yoko's call, Kazumi and Yuu also came out, and they were able to safely meet the gathering security team seniors.

"You were hiding there? I'm really glad you're safe!"  
"Sorry for worrying you. Yes, we managed thanks to you."  
"Aah! It's my fault for being clumsy!"  
"Never mind that. The fact that you were able to hold out safely is also thanks to these two being with you."

Yuu, who had been the first to bow his head, lightly patted Kazumi and Yoko's shoulders.

The two looked at Yuu with unconcealed affection and clung to him.

According to the seniors, after protecting Rei, they had repelled the 5 or 6 purple-jerseyed women who had chased them.

Because Mashiro and Yuuma had reported that Yuu and the others had fallen down the slope, they immediately descended to search.

There, they naturally got into a brawl with the purple-jerseyed women.

One-on-one, the opponents were more experienced fighters, but since they were scattered in small groups, the security team overwhelmed them with numbers and succeeded in defeating them one by one. After that, the group apparently fled along the stream.

Since it didn't seem like Yuu had been kidnapped, they had been searching the area for over 30 minutes.

Feeling that they had caused everyone worry while they were fooling around, Yuu and the other two apologized to the security team and classmates when they returned to the clearing.

However, the security team seniors also felt intense guilt and regret for letting their guard down and allowing the attack on a boy, so they ended up apologizing to each other.

### Chapter Translation Notes
- Translated "抜け駆け行為" as "preemptive move" to convey the idea of trying to secure a relationship before others.
- Translated "唾をつけて" idiomatically as "mark them as his own" to preserve the meaning of claiming territory.
- Translated "他人行儀" as "formalities" to convey the sense of being overly formal or distant.
- Translated "オカズ" as "material" in the context of masturbation, as it is slang for material used for sexual gratification.
- Preserved the sound effects (e.g., "chuu", "julu", "buchi") by transliteration.
- Used explicit terms for sexual anatomy and acts as per the Fixed Translation Style (e.g., "cock", "pussy", "blowjob").
- Kept honorifics like "-kun" and used first names as per the original text and Fixed Character Names.
- Italicized internal monologue: `*(thought)*` was not present in this chapter, so not used.
- Maintained the original Japanese name order for Japanese names, but since the text uses given names only, we used "Yoko" and "Kazumi" without family names.
- For the dialogue quotes: Used standard double quotes for regular dialogue. There were no simultaneous quotes in this chapter.
- Translated "ブルマー" as "bloomers" as it is the standard term for the gym shorts worn by Japanese schoolgirls.
- Translated "ジャージ" as "jersey" for the track suits.
- Translated "警備班" as "security team" to match the context of the school event.