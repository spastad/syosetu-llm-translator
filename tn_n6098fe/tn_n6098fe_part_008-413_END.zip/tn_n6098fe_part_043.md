## 38. The Student Council Again ① ~Hands Full of Johnny~

### Author's Preface

Beyond general terms like penis, male genitalia, and reproductive organs, there are also names like (o-)chimpo, (o-)chinchin, and chinko. Furthermore, it seems they're sometimes expressed as son, junior, my-san, meat rod, or Excalibur.

Among these, I thought "Johnny" as used in a certain famous non-18+ reversal novel was an innovative and excellent way to refer to it.

---

Though Yuu's group arrived about an hour later than scheduled, there were no incidents of boys being abducted or injured—though the security team had several minor skirmishes and brawls at various locations, which happens every year—and the Newcomer Welcome Orienteering ended safely.

However, the surprise attack by assailants wearing similarly colored jerseys on the mountain slope remained a significant point of reflection and would be a challenge for future security measures.

At any rate, after the Newcomer Welcome Orienteering concluded, peaceful daily life would continue until the athletic meet in early June.

Today was Thursday the week after the orienteering.

The student council had also returned to normal operations, with Riko at the weekly library committee meeting and Emi having gone to her part-time job right after school.

Thus, Yuu and Sayaka were enjoying a tryst alone in the student council waiting room for the first time in a while.

"Hmm. The more I look at it, the more fascinating a boy's penis is."  
"Umm... is that so..."

Sitting sideways between Yuu's legs as he leaned against the wall, Sayaka bent down and brought her face close to his crotch.  
Her eyes were fixed on his erect penis.  
Her supple, white-fish-like fingers traced along the shaft.  
Every time Sayaka tilted her head, the tips of her smooth black hair brushed against his legs, tickling him.  
Sayaka's fingertips circled the smooth glans and the indented coronal ridge, then moved along the veiny shaft as if checking its texture.

As usual today, after hugging and kissing for a long time, they fondled each other's breasts.  
Currently, Yuu was naked from the waist down with only a T-shirt on top.  
Sayaka, at Yuu's request, had kept her sailor uniform on but opened the front and removed her bra, so her ample breasts swayed freely.  
Below, she had removed both skirt and panties, wearing only white socks—a tantalizing appearance.

Sayaka blew puffs of air and poked lightly with her finger.  
It was as if she was playing with a toy.  
Then she began lightly stroking the penis with one hand.

"Ah... aah... Sayaka... senpai."  
"It just twitched. Does this feel good?"  
"Ye... yes, it feels good..."  
"Fufu. Even so, I can't believe something this big was inside me.  
Look, it's so long I can't even grasp it fully with one hand. And it's thick too.  
Why does something so fierce and manly also feel strangely cute?"

Sayaka stroked the shaft from the base with her right hand while gently massaging the scrotum with her left.  
The sensation was still frustratingly light since she wasn't applying much pressure, but that was fine too.  
Moreover, having his scrotum massaged made him feel like he was entrusting something precious to her.  
As Sayaka's hand slowly moved up and down from tip to base, Yuu's pleasure gradually intensified.

"Oh? Some transparent liquid is dripping out. It seems a bit sticky."  
"I-It comes out when I get excited... from senpai's touch... It's Cowper's gland fluid, commonly called pre-cum or precum."  
"I see, I've learned something. Well then, how does it taste?"

Sayaka scooped it up with her finger and licked it without hesitation.  
"Hmm. It has almost no taste. Maybe slightly salty."  
Then she kissed the glans with a *chu*.  
Today's lesson was on male genitalia and caressing techniques—specifically fellatio.

"Where do boys feel good?"  
Sayaka kissed from the tip and ran her tongue along it while asking.  
Her right hand continued teasing the shaft from the base with tickling fingers.  
Seeing Sayaka's mischievous smile as she looked up at him, Yuu's excitement soared beyond measure.  
While stroking her head, he managed to answer.

"Ugh... ng... the tip... the glans feels best. Ahh, right there!"  
"Okay, okay. *Lero, lero, chu!*  
*Kufu*, seeing Yuu-kun's reactions gets me excited too. Here, I'll pamper you more."

After licking the entire glans thoroughly with her tongue, she opened her lips and took it into her mouth with a *kup*.  
Hearing Yuu's pained moan, Sayaka took it as encouragement and began sucking while moving her tongue.

In Yuu's original world, apart from sex workers, he'd heard few women—even lovers or spouses—enthusiastically performed fellatio. Just as some men resisted cunnilingus, they might not want genitalia in their mouth even with loved ones. Yuu himself had no such resistance—he'd gladly do it if it pleased his partner. But his ex-wife had disliked even touching it, making them sexually incompatible.

In this world, perhaps due to fewer men, women had strong libidos, loved seeing men scantily clad or naked, and felt no aversion to touching, licking, or even swallowing semen. As a man, Yuu would never want his own semen in his mouth. But just as he'd lick a woman's arousal fluids without hesitation, women here seemed to find joy in swallowing ejaculate as an expression of pleasure.

*Picha, picha*—lewd wet sounds continued as Sayaka's fellatio progressed. Now slick with pre-cum and saliva, the penis glistened while Sayaka caressed it lovingly with hands and tongue.

"Se-senpai, that... the underside, the frenulum feels good too."  
"Mmm."

Accepting Yuu's words, Sayaka extended her tongue and licked the frenulum with *pero pero*.  
"Kuh! Yes! Sayaka... senpai, it feels amazing!"  
Yuu had only experienced this with skilled sex workers before—the frenulum lick sent electric jolts of pleasure. Though inexperienced, Sayaka's enthusiasm matched theirs. He reached out to squeeze her breast, and a desire surfaced.

"Sayaka senpai, I have a request."  
"F...nn?"

While stroking Yuu's chest to abdomen with her left hand, jerking his penis with her right, and licking eagerly, Sayaka responded.  
"Paizuri... or titfuck, I think? I want you to sandwich my penis between your breasts."  
"Pai... mu, with my breasts?"  
Sayaka glanced at her breasts being squeezed by Yuu's hand.  
"Yes. Senpai's breasts are big. Regular fellatio feels great, but being sandwiched would feel amazing too."  
"Hmm. Never heard of that. If these 'useless' breasts can help, I'll try."  
"Please!"

How many men in this world would request paizuri? For Yuu, it was a dream. Sayaka pressed her breasts together as instructed. Leaning forward, over half his penis vanished into her ample flesh.

"Ooh... sandwiched by breasts... so soft... amazing!"  
"Fufu. Boys are funny. If this makes you happy, it's easy."  
"Co-could you stroke me with them?"  
"Ah, sure."

Sayaka began stroking his penis with her breasts, arms clamped tight. Slick with fluids, it slid easily. *Nuchi nuchi* sounds accompanied each motion.

The stimulation might be milder than handjobs or sucking, but it was titfuck by beloved Sayaka. Her breast pressure exceeded expectations, fueling Yuu's excitement.

"Haa, haa, uk... Senpai's paizuri... like a dream. Ahh! I want to cum... Oh, could you... suck it too?"  
Instead of answering, Sayaka lowered her chin and began licking the glans peeking from her cleavage.

"Mmm, *lero... chu, chu, amu... mfuh*... Yuu-kun's penis... I'll make you feel... even better... *mm~mm!*"

Though Yuu's monstrous penis drove women wild, stroking and sucking it made it seem oddly cute. The dripping pre-cum proved his arousal. Sayaka stroked with her breasts while eagerly licking the tip. Sandwiched and glans-attacked, Yuu couldn't endure.

"Kwa! If you... do that... I'll..."  
"*Puh*. It's fine, Yuu-kun. Cum freely. Here."  
Sayaka teased the urethra with her tongue tip.  
"Ah!"  
Yuu grabbed her shoulders. Sensing his limit, Sayaka deep-throated him, stroked with breasts, and teased with her tongue.

"Sen... pai... ah... I'm... cumming! Ugh... ahh!"  
"*Mmm... fuh...*"

Sayaka closed her eyes, pursed her lips, and waited.  
"I'm cumming!"  
"*Mmm?!*"

Release surged through Yuu's hips as intense pleasure overwhelmed him. Semen gushed into Sayaka's mouth.  
"*Gwaah! Ah, gah!*"  
Swallowing for the first time, Sayaka choked as semen clogged her throat. More spurts splattered her face—forehead, nose, cheeks—staining her doll-like features. Even her bangs were streaked white.

"*Gah*, ugh... s-sorry. I couldn't catch all your semen.  
Ah... it's still coming. I'll take responsibility."  
Ignoring the mess, Sayaka swallowed the semen in her mouth, then resumed sucking.

Seeing her earnestness, Yuu stroked her head gently.  
"Don't apologize. I should thank you.  
It felt amazing. Doing this much for me... I'm overjoyed."  
"Fufu. You're so kind, Yuu-kun. I thought boys were more delicate and selfish. Hearing that makes me happy... and hornier."  
Sayaka smiled while licking him clean. Post-ejaculation fellatio kept Yuu erect.

"Let's do more. We're alone today—let's practice plenty."  
He lifted her by the armpits.

Holding her close, he whispered in her ear:  
"Shall we do the main event?"  
"Ar-are you ready already?"  
"Yes, thanks to senpai. See?"

His penis pressed against Sayaka's lower abdomen.  
The hard, hot sensation made her core ache.  
"Ah... Yuu-kun!"  
Already aroused from foreplay and wet from sucking, she was ready.

"What position today?"  
Their first time was this world's standard cowgirl position. Later, they tried seated face-to-face.

After hesitation, Sayaka shyly said:  
"I-I-I want... to be held..."  
"Holding while doing it? Fufu, senpai's surprisingly clingy."  
Sayaka flushed crimson instantly. At home or school, she never acted clingy. Strict upbringing left few memories of being spoiled. Yet with Yuu, she inexplicably wanted to indulge. Being called out overwhelmed her with shame.

"N-no! I-It's... deeper connection that way..."  
"I love holding face-to-face too. Same here."  
"Un... *ahn!*"

While cheek-rubbing and hugging, Yuu's hand groped her drenched slit.  
*Kuchyu kuchyu* sounds followed.  
"*Mmm...* ah... Yuu-kun's mean...  
But yes—I'm soaked and need your penis now!  
I can't wait! I'm putting it in!"  
"Yes. Please."

As practice, Sayaka lifted her hips for insertion.  
This brought her breasts to Yuu's face—he buried himself in their softness.  
Experience made entry smooth.  
"Ah!"  
Their voices overlapped as the glans entered her vagina. Though almost a month since losing her virginity, Sayaka remained tight. Wetness helped, but depth came gradually until it slid fully in with a *nyuru*.

"*Gyaahn!*"  
"Ooh! I-It's in..."  
"Ah... *kuh~* Yuu-kun's penis... always so big... I... ah, ah, *haun!*"

Even connected deeply, they stayed embraced. Sayaka had orgasmed instantly from the deep thrust. Yuu savored her half-naked warmth, scent, and vaginal sensations—folds gripping and squeezing his shaft.

"Haa, haa... se-senpai inside... feels amazing...  
We're physically compatible, aren't we?"  
"Physically... I only know you... but yes.  
It feels this good... my head's melting... *mm*."  
They kissed repeatedly with *chu, chu*.

"Fufu. I never knew I could be this lewd. I want more of you.  
Shall we move?"  
At Sayaka's shy whisper, lips nearly touching, Yuu agreed.  
"Of course. However senpai wants..."

Yuu buried his face in her neck, inhaling her scent.  
"Hah... *mm*... then, no holding back..."  
Answering the throbbing in her abdomen, Sayaka slowly began rocking her hips.

### Chapter Translation Notes
- Translated "ジョニー" as "Johnny" per author's preface explanation of this term for male genitalia
- Translated sexual terms explicitly: "パイズリ" as "titfuck", "フェラチオ" as "fellatio", "精飲" as "swallowing semen"
- Preserved Japanese honorifics (-senpai) and name order (Hirose Yuu, Komatsu Sayaka)
- Transliterated sound effects: "ぴちゃ" → "picha", "ちゅっ" → "chu", "ぴゅるぴゅる" → "spurt"
- Italicized internal monologues per style guide
- Translated anatomical terms directly: "亀頭" → "glans", "玉袋" → "scrotum"
- Maintained explicit descriptions of sexual acts without euphemisms
- New dialogue lines start new paragraphs except when attribution precedes speech