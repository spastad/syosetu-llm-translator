## 39. The Student Council Again ② ~Putting Jealousy to Sleep~

"Ah, ah, ahh! It's good, m-my hips, won't stop! I-I'm... ah, I'm cumming, I'm cumming! Aahn! Gooood, I'm cuuumiiiiiiiiiiing!!!"

Clutching tightly onto Yuu while violently shaking her hips, Sayaka looked up at the ceiling as she reached climax.  
Her rough breaths hit Yuu's skin.

"Fufu, Senpai came again, didn't you?"  
"Ugh... b-because... Yuu-kun's penis... feels too good! That's the problem!"  
"It's fine. No matter how many times you cum. I really love seeing such an erotic Komatsu-senpai like now."  
"Yu... Yuu-kun... nn."

Sayaka lovingly cradled Yuu's head and showered him with passionate kisses.  
Though she'd intended to gently lead as an older woman since their first time having sex, she couldn't shake the feeling that Yuu had taken the reins.  
Only when giving blowjobs or handjobs could she feel like she was pampering him.  
But reflecting now, she realized Yuu had expertly guided her toward pleasure throughout.  
Despite appearances, his attitude felt mature beyond his years, making her unconsciously surrender to him.  
And once penetration happened, she always came first.  
Yet her body rejoiced in this, craving more from the depths of her heart.  
She felt terrified by how indispensable sex with Yuu had become, yet simultaneously wanted to surrender completely - these conflicting emotions warred within her.  
Though a corner of her mind wondered what had become of her spiritual discipline, she recognized her overwhelming feelings for Yuu.

After exchanging deep, sloppy kisses with wet sounds, they separated their lips with a string of saliva still connecting them.  
With a final smacking kiss to Sayaka's dazed expression, Yuu whispered:

"Senpai, despite how it looks, I'm nearing my limit too.  
This time I'll take the lead."

"Ah... Yu... kun... Fine... Cum inside... me... Aah! Aaah! S-suddenly... so rough!"

Each time Yuu lifted Sayaka's firm buttocks and thrust upward, wet slapping sounds echoed - tan, tan, tan.  
Sayaka wrapped her arms around Yuu's shoulders and her long legs around his waist, clinging like a koala to a tree.

"Ngh, ah! Komatsu-senpai! Aah, amazing... so good! Just like this..."  
"Anh, anh, anh... me too... ahhn! Deep inside... aahn! Being thrust... I can't think anymore... ah, augh! This is... ruining meeeee!"

Sayaka's ample breasts pressed flat against Yuu's chest as their joining point produced loud squelching sounds.  
Yuu's groin area was visibly soaked, but neither cared anymore.  
Though they'd placed folded towels beforehand, the futon might already be damp.

"Yuu...kun! So good! I-inside feels... amazing! Cumming again! Ah, ah, aaaaahhh!"  
"Kuhah, Senpai! If you squeeze that tight...!"

Perhaps because Yuu's thrusts stimulated her more than her own movements, Sayaka unconsciously matched his rhythm while her vaginal walls rippled as if trying to milk his penis.  
Her descended cervix made contact, giving it a fervent welcome.  
The small, rapid movements soon reached their limit.

"Ah, kah... Komatsu... sen...pai! I'm... ejaculating! Inside your vagina... I'm cumming!"  
"Aaahn! Yuu-kunn! Cum lots! Inside my vagina! Ooh, ooh, again... so intense... coming! Aaaaaaahhhh! M-me too, cummiiiiiiiiiiing!!!"

Holding each other tightly with cheeks pressed together, they climaxed simultaneously.  
With each spurt of semen into her womb, Sayaka's body convulsed slightly.  
"Ah...n...... ahh, so much... coming out... Yuu-kun's seeeemen... haaaaah..."

Yuu gazed at Sayaka's dazed expression while smoothing her disheveled hair.  
"Today was amazing too, Komatsu-senpai. Even as a practice partner, having sex with you makes me happier than anything."

Hearing such direct feelings left Sayaka speechless.  
She could only gasp each time Yuu's thrusts pumped more semen into her womb.  
But Yuu sealed her lips with a kiss as if saying no reply was needed.  
In response, Sayaka tightly hugged his back.

***

"This past Sunday... I met my fiancé."  
"Eh... and?"

Still undressed, they were wiping themselves with tissues when Sayaka's sudden remark made Yuu react.

"Un... Maybe because I observed him carefully while suppressing my own feelings? The conversation went smoother than before.  
I didn't just talk about myself - I asked about him too."  
"Is that so? That's good."

Contrary to his words, Yuu's heart felt complicated.  
Though many classmates and nurses had confessed to him and they'd had sexual relationships, his feelings for Sayaka were strongest.  
Objectively speaking, her doll-like perfect features, near-black large eyes, porcelain-flawless fair skin, silky glossy black hair, and well-toned balanced body all exemplified perfected beauty.  
As a company president's daughter raised with refinement, she excelled academically and served as student council president.  
Her serious, responsible nature gave her dignified nobility, like a grand white rose.  
Yet her tendency to overwork for student council affairs or make clumsy mistakes was endearing.

For Yuu reborn in an unfamiliar world, Komatsu Sayaka was the ideal woman.  
But while she could practice male communication with him, dating or marriage was impossible - her parents had already decided her future husband.  
He couldn't steal that position.

*If only I were truly this age. I might've demanded she break the engagement to date me. But as a 40-year-old man with life experience, I know some realities can't be changed by individual effort. Rather, forcing Sayaka to break the engagement would only trouble her.*

Despite being born handsome in this male-scarce world, he couldn't make the woman he loved his partner.  
Just hearing about her smooth conversation with her fiancé stirred jealousy.  
That he could suppress this jealousy without showing it might be due to his mature mentality.

*Ironically, in my original world, Sayaka would be cheating on her fiancé. But she shows no such awareness - probably because this world's chastity norms differ completely from what I knew. That's why I can have sex with her. For now, I'm grateful for that.*

"That's all thanks to you teaching me things and being my practice partner, Yuu-kun. I'm truly grateful."  
"No, it's because of your mindset, Senpai. Knowing and doing are different."  
"R-really?"

Sayaka smiled shyly.  
Dressed only in her sailor uniform and socks, her straight-backed sitting posture looked like a gravure model come to life.

"By the way, I got a birthday present.  
It's still two weeks early - how dutiful."  
"What did you get?"  
"Let's see... The latest electronic dictionary.  
Fufu, this year's choice seems useful for studying."

Unlike Yuu's 21st century, electronic dictionaries in this era probably weren't affordable for high schoolers.  
Her fiancé's family was clearly wealthy.  

"Before, I got word processors or radios. They were nice gifts but I didn't use them much."  
"Ehh..."

As birthday gifts for a girl, weren't accessories more appropriate?  
Reportedly, her fiancé's parents were executives from a major electronics manufacturer's founding family.  
Essentially, they were probably handing over new products from their company.  
Though expensive, did they contain any personal feelings?  
Still, delivering it early in person showed some consideration.  
But another detail caught Yuu's attention.

"Two weeks early? So Komatsu-senpai's birthday is early June?"  
"Ah, un. June 1st."  
"Hey, what a coincidence. Same birth month. Mine's the 30th."  
"R-really?"

Though trivial, this coincidence delighted Yuu.  
"I know! Let's have a birthday party next month! With everyone from student council!"  
Sayaka smiled wryly at Yuu's eager suggestion.  

"Haha. A birthday party? Like elementary kids."  
"Come on! Let's exchange presents!"  
After pondering while watching Yuu's expectant face, Sayaka nodded.

"Alright. Since June has the sports festival in its second week, after that should work.  
I'll ask the other two about their schedules later. As for location..."  
Yuu hesitated to invite them to his home because of his reclusive sister.  
He wanted to visit Sayaka's apartment but wasn't bold enough to say so.

"Tentatively... my place is fine."  
"Yay! I'm so excited to see Komatsu-senpai's home!"  
Unable to contain his joy, Yuu hugged Sayaka.

"Haha, you're like a child, Yuu-kun."  
Sayaka gently stroked his head like an older sister doting on a younger brother.  
Though she had a younger sister, she'd once wished for a brother - an impossible dream.  
But after Yuu joined student council, she'd initially thought of him like a brother.  
Of course, his actions had since exceeded sibling affection.

With his face buried in Sayaka's neck, Yuu began sucking her collarbone and licking her neck.  
His right hand lifted her sailor uniform to directly grope her breasts.

"Hyan! Hey, sto... ah...n!"  
"You sweated earlier. A bit salty."  
"Then it's dirty, don't lick... nn... fah!"  
"Komatsu-senpai's sweat isn't dirty at all. Lick. Mmm, delicious."  
"Anh! Don't... ah, my nipple!"

Her already stiffening nipple was pinched and twisted by his fingers.  
His left hand moved behind her back, gradually pushing her down.  
Sayaka's long black hair spread across the tatami like silk fabric.

"Yuu-kun?"  
The expression Sayaka saw when looking up was that of a lust-drunk beast - gleaming eyes and upturned lips staring at her.

"I want to do it again. Let's, okay?"  
"Haeh? Nn... nnfunn"  
With a smacking kiss, Yuu pushed his tongue in.  
His hardened penis pressed against Sayaka's lower abdomen.  
Feeling this, her core throbbed and instead of resisting, she spread her legs in acceptance.  
She hugged Yuu's head and actively tangled her tongue with his.

"Puh... Can't be helped, Yuu-kun.  
But... this position?"  
Unfamiliar with such knowledge, Sayaka couldn't comprehend the man being on top - missionary position was outside her understanding.  
But for Yuu, it was perfectly normal.  
"Once in a while is fine.  
Here I go."  
"Nn... ah, haaaaaaah... vun! Your penis, i-it's entering!"

Though some time had passed since their last union, her vagina was thoroughly wet, allowing smooth penetration.  
After thrusting deep in one go, Yuu looked at Sayaka.  
Using Yuu's arm as a pillow, Sayaka met his gaze with flushed cheeks unlike before.

"How is it? Senpai?"  
"Ah... ah... f-feels good. With Yuu-kun on top... holding me... anh!  
Your penis... feels like it's stirring me inside! Haan! Good! Yuu-kun, more!"  
"Of course! I'll go deeper."  
"Ah... aaaaahhhh!"

Still connected, Yuu slowly lifted Sayaka's hips upward while mounting her - the so-called "breeding press."  
"Fah!? Wh-what... this... aaahn! D-deep inside, gouging me!"  
Instead of pistoning, Yuu's circular motions scraped her deepest parts, stripping away Sayaka's usual dignity and leaving only the face of a female craving seed.

"I'll cum inside you again, Senpai. Receive it all."  
"Nn, nfu, Yuu-kun! Aah! Yuu-kunn! Anh, so good!"  
Without needing to be told, Sayaka wrapped her arms around his back and legs around his waist, clinging tightly with her body.

Suddenly Yuu thought:  
*If we keep having unprotected sex like this, she'll surely get pregnant.  
What then? Normally, impregnating an engaged woman would cause huge problems.  
But we're having consensual creampie sex.  
No need to think about consequences.*  
Yuu kept thrusting, determined to pour his essence into Sayaka.

---

### Author's Afterword

Regarding Sayaka's fiancé,  
there were two conflicting descriptions:  
・Son of a major corporation's president  
・Executive from an electronics manufacturer's founding family  
So I removed one.

### Chapter Translation Notes
- Translated "チンポ" as "penis" consistently per explicit terminology requirement
- Rendered sexual sounds literally (e.g., "tan, tan, tan" for たんっ、たんっ、たんっ)
- Preserved Japanese honorifics (-kun, -senpai) throughout
- Translated "種付けプレス" as "breeding press" to convey the sexual position's literal meaning
- Maintained original name order (Komatsu Sayaka) per style guidelines
- Translated internal monologues in italics without parentheses
- Used explicit anatomical terms ("vagina," "semen," "ejaculate") as required