## 40. The Student Council Again ③ ~Piece of My Wish~

After finishing student council duties, Hirose Yuu needed to go to the front of the second school building to catch the school shuttle bus.

Though it was only about a 5-minute walk, someone from the student council always insisted on accompanying him there. 

While Yuu had no problem going alone, he wasn't so rude as to refuse their kindness. Besides, walking through the less-frequented back garden while secretly holding hands with an upperclassman wasn't unpleasant.

Today, Ishikawa Emi was walking beside him.

As they walked together, Emi seemed in high spirits. Since leaving the dormitory, she'd been stealing glances at Yuu. Then came an unnatural brush of hands.

"Ah!"

When Yuu looked at Emi, she averted her eyes awkwardly. Her intentions were completely transparent.

Yuu smiled and took her hand.

"Ufufu~"

Emi's cheeks flushed crimson as her lips relaxed into a smile. Her utterly transparent reaction seemed fresh and adorable to him.

Suddenly, Yuu's gaze drifted toward a grove of trees. He often saw couples—sometimes one boy with two girls—being affectionate on benches during his walk to the student council room. Just the other day, he'd spotted a couple kissing in the shade. Since there was no hurry to return, maybe they could kill some time there.

"Emi-senpai, is this okay?"  
"Hmm? What is it, Yuu-kun?"  
"Let's take a detour."

Pulling the puzzled yet expectant-looking Emi by the hand, he led her toward the grove.

There, at the base of a large tree, was a small space surrounded by haphazardly growing trees about 2 meters tall, creating a natural screen. Unless someone deliberately entered, it was a perfect hidden spot.

"I didn't know this place existed... Annn~"

Upon reaching the large tree, Yuu gently pulled Emi into an embrace. As they hugged face-to-face, the pleasant scent from Emi's flaxen twin tails tickled Yuu's nostrils.

"Aha... Yuu-kun~"

Emi happily leaned in, wrapping her arms around Yuu's back.

They remained embraced for a while, savoring each other's scent and warmth. Yuu not only stroked Emi's petite back but boldly moved his hands upward and downward—his right hand touching her nape while his left felt her buttocks through her skirt. Emi writhed at his touch, burying her face in his chest as hot breaths escaped her lips.

Yuu lowered his chin and whispered near Emi's small ear.

"Emi-senpai, look at me."  
"Fua... Yu, Yuu-kunnn..."

Emi looked up at Yuu, her cheeks already flushed pink, gazing at him with dewy eyes. They stared at each other from breath-touching distance.  
"Nnn~"

Emi closed her eyes and lips, slightly tilting her chin upward.

*(Haah... I can't stand this)*

A beauty like Emi was asking him for a kiss. Taking those closed lips would be easy. But the Yuu of before could only admire such beauty through a screen—her long eyelashes when eyes were closed, her smooth fair skin, her small crimson lips like flower buds. He found himself captivated.

"Nn~?"

The moment Emi opened her eyes slightly in confusion at his hesitation, Yuu captured her lips.

"Nn!... Ufuun... Fa! Annn..."

They continued exchanging passionate kisses while holding each other tightly. The soft, moist sensation of her lips made Yuu's excitement uncontrollable. Though not large, he could distinctly feel her breasts against him.

"Emi... senpai~"  
"Yuu... kuunn... amu, nn, kissu~ feels so good~"

Without either initiating, their tongues met and entwined passionately. Moving in and out of each other's mouths, they became engrossed in deep kissing with wet *picha picha* sounds.

"Amu... chu, chu, chupa... afu, re-ro, re-ro, nmu! Nfuun... fa... Yuu-kun... Yuu-kun! Ah, ann!"

Driven by lust, Yuu's left hand had slipped under Emi's sailor uniform to fondle her breast through her bra, while his right hand boldly lifted her skirt and crept upward along her inner thigh.

"Hyan! Th-there... ah, ah, yan! I'm getting sensitive~... haa, haa, sorry, I can't stand..."  
"Here, hold on tight."

Securing Emi against his body with his left arm around her waist, Yuu used his right fingers to tease her dripping vaginal opening with *kuchu kuchu* sounds. Deeming the timing right, he inserted his middle finger inside.

"Nnnnn~~~~~~!"

Emi muffled her moans against his chest.

"Does this feel good?"  
"Nhyiin!"

When he rubbed the abdominal side of her vaginal wall with his fingertip, Emi's petite body jerked and her twin tails swayed. Continuous stimulation soon had her muffled moans flowing nonstop until she easily reached climax.

"Nn, aah, aah, aaii, ii... iiinn... Yuu... kun! Sho... ko... ann! Shugoi~... feels so good~.  
Fa, aah, nn, nn, I'm cumming, ifuu... i! Ifu ifu! Nnaah!"

After one particularly strong jerk, Emi went limp and nearly slid down, so Yuu sat down while holding her.

Yuu hadn't had much sexual experience before his rebirth and didn't consider himself particularly skilled. His nighttime activities with his ex-wife had been quite poor. If physical compatibility existed, theirs probably wasn't good.

Yet in this reborn world, girls came easily under his touch. He suspected it wasn't his technique but rather this world's women having strong libidos and sensitivity. Another factor might be their affection for him—the difference between men feeling physically and women emotionally. Considering how wet Emi became just from hugging and kissing, the effect was likely amplified for her.

"Re-ro, re-ro, aa mu... nn, nn, nfuu... n-chupaa!  
Roou, Yuu-kun, does it feel good?"  
"Ah, feels great. I'm happy you're sucking so enthusiastically."  
"Nfu! Because I love Yuu-kun, so I love Yuu-kun's penis too!  
I'll give it lots of love!"

Beaming, Emi buried her face in his crotch and resumed sucking. She stroked the shaft from root to tip with both hands, caressed his scrotum, and licked around the glans and coronal ridge. While she'd given handjobs before, this was her first blowjob. More than technique, Yuu was pleased and comforted by her heartfelt effort.

Yuu's right hand played with her twin tail strands while his left slipped under her sailor collar to touch her breast through her bra.  
"A, aah... i-it feels good!"

Emi looked up at Yuu with his penis in her mouth. Her round eyes and puffed cheeks made her resemble a squirrel holding food. Seeing Yuu's pained expression looking down, Emi's eyes curved happily like crescent moons. Not only did she tease the glans with both sides of her tongue, she also *chuu* sucked it.

"Kuaa! Ah, that..."  
"Nfu♪ Nn... amu, juruchupu! Afu... ree-ro, ree-roo, nmu... nn, nn"

Sensing Yuu's trembling expression and body, Emi intensified her attack. Her right hand rapidly stroked the shaft from root to tip in small movements. Though her first blowjob, she served earnestly, focused solely on pleasing Yuu.

Yuu's ejaculation urge grew steadily. Suddenly, an erotic manga scene flashed through his mind—face-fucking while gripping twin tails. Emi might accept it, but Yuu resisted rough treatment due to past experiences with his wife. Maybe something similar would work.

"Emi."  
Yuu spoke while touching her chin as she kept his penis in her mouth.  
"I'm about to cum. Can I move for the finish?"

She nodded slightly.

Yuu rose to his knees from sitting. Emi, now on all fours, unhesitatingly took his penis deep into her throat without releasing it. Her mouth wasn't large, yet she took his above-average size deep without showing any jaw fatigue.

Placing hands on both her cheeks, Yuu slowly moved his hips. Each thrust brought pleasure from the moist inner membrane.  
"Ah, Emi's mouth feels amazing."  
"Nfu~"

Treated like an oral onahole, Emi remained delighted, gripping Yuu's waist firmly with both hands.

As excitement built, his hip movements accelerated. Occasional gagging sounds came when he hit her throat, but Yuu didn't stop.  
"Nn, ah! E-Emi... ku!"  
Emi endured the violation of her mouth. Electric-like pleasure shot through Yuu's hips and lower body, nearing eruption.  
"Ugh, oh... I-I'm cumming! I'll ejaculate everything, swallow it all!"

Tearfully, Emi pursed her lips and looked up at Yuu, waiting.

At that moment, Yuu pulled his penis slightly back from her throat and prepared to ejaculate.  
"Nn... nguu!?"  
"Kaha... c-cumming..."

*Dopu dopu* semen shot forcefully into Emi's throat.  
"Ngo... ugh, ngu, ngu..."  
Unable to spit with the thick penis in her mouth, Emi swallowed the overflowing semen while occasionally coughing, her slender throat bobbing.

After filling Emi's mouth and making her swallow, Yuu had her clean him with her mouth. She sucked the still-hard penis clean and licked it thoroughly before swaying forward dizzily. Yuu caught her.

"Aha... I swallowed semen for the first time!  
It kinda stuck in my throat—sticky and thick.  
And... an adult taste? Bitter and hard to swallow, but it's Yuu-kun's so... ehehe."  
"Yeah. Thank you, Emi. That was amazing."

Feeling post-ejaculation lethargy, Yuu patted Emi's back while holding her. Feeling affection for her devotion was natural as a man. He decided to indulge her affection for a while.

But Emi seemed concerned about Yuu's departure time. After a moment, they stood up. While leaving the grove, Yuu put his arm around Emi's shoulder.  
"Ah...!"  
Though startled, Emi smiled happily and leaned her head gently against him. For ordinary girls, this was a dream scenario only seen in fiction. Though brief, the walk to the second building was a dreamlike moment for Emi.

Meanwhile, a third-year couple who'd heard Emi's moans had been watching. After Yuu and Emi left, the excited couple—who'd only recently kissed after starting to date—advanced to petting and fellatio that day, deepening their relationship. The female student felt deep gratitude toward the vaguely familiar Yuu and Emi for inspiring this.  


### Chapter Translation Notes
- Translated "PIECE OF MY WISH" as "Piece of My Wish" maintaining the song reference while preserving capitalization style
- Translated "お掃除フェラ" as "clean him with her mouth" to convey the act without using loanword "fellatio" twice
- Rendered sound effects literally: "くちゅくちゅ" → "*kuchu kuchu*", "ぴちゃぴちゃ" → "*picha picha*"
- Preserved Japanese honorifics (-kun, -senpai) per style guide
- Translated anatomical terms directly: "チンポ" → "penis", "膣" → "vagina"
- Maintained original name order: "Ishikawa Emi" not "Emi Ishikawa"
- Used italics for internal monologue: "*(Haah... I can't stand this)*"
- Translated sexual acts without euphemisms: "フェラチオ" → "blowjob", "射精" → "ejaculate"