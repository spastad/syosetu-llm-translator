## 41. The Student Council Again ④ ~This Feeling I Can't Hold Back~

### Author's Preface

I initially planned to only feature Sayaka, but decided to add chapters for the other two student council members (Emi and Riko) as well.

While the story order is Sayaka → Emi → Riko, the timeline isn't strictly chronological.

Just noting these setting details for clarity.

---

Since it was a good stopping point, sixth period ended slightly early.  
Thanks to this, Hirose Yuu could head to the student council room about 10 minutes earlier than usual.  

*Am I the first one here? Maybe I should hide nearby and surprise her...* he thought childishly as he tried the doorknob. It opened without resistance, startling him.  

Upon opening the door and stepping inside, he found vice president Hanmura Riko seated and reading.  

"Oh? You're early."  
"Um, class ended early. What about you, Riko-senpai?"  
"Mine was self-study. I finished the worksheet early, so I came here to read."  

The book in her hand appeared to be a business paperback.  

"Huh?"  
The author's name glimpsed was Komatsu Hanako.  
"Komatsu... could the author be...?"  
"Sayaka's great-grandmother. The founder of the Komatsu Group."  
"Wow."  

Though Yuu saw her dignified, reliable, and quintessential student council president demeanor daily, Sayaka didn't quite match his image of an ojousama. But reconsidering, she was indeed the young lady of a world-renowned corporate group family. Given Sayaka's personality, she'd likely deny this, insisting the credit belonged to her great-grandmother and predecessors.  

"Sayaka will be a bit late today."  
"Is that so?"  
"Yes. Something about being consulted by classmates. You know how everyone relies on her."  
"Ah~ I get that."  

Girls are divided into humanities and sciences tracks from second year. Though humanities-track Sayaka and sciences-track Riko were in different classes, Riko must have received advance notice.  
"But Emi should arrive soon. Shall we prepare tea?"  
After quickly clearing her belongings from the long table besides her book, Riko stood up. She crossed in front of Yuu toward the kitchenette.  

Since joining the student council, Yuu had spoken frequently with Sayaka and Emi, but rarely had one-on-one conversations with Riko. Seizing this chance, he followed her.  
"Mind if I chat with you here?"  
"Oh? Not at all."  
Glancing back with a smile, Riko stood before the sink and began preparing tea utensils.  

For a moment, Yuu found himself captivated by the view of Riko's tall, slender back. Flustered, he searched for conversation topics.  

"Um... Riko-senpai, you're going to university after graduation, right?"  
"Hm? Well, yes."  

As the top-ranked student in her grade, Yuu wondered if Riko aimed for equivalents of Tokyo University or Waseda/Keio from his original world, but asking directly felt too intrusive. Though some university names differed here anyway.  

"I'm aiming for a national university engineering department. Of course, Tokyo University and Tokyo Institute of Technology are within consideration."  
"Whoa, amazing."  
Another extraordinary senior.  
"Will you attend the same university as Sayaka-senpai...?"  
"Hmm, not sure. Sayaka has her own aspirations. But..."  
"But?"  

Riko hesitated without looking at Yuu.  
"Ah, sorry. You don't have to answer if uncomfortable."  
"No, it's not that..."  

She seemed embarrassed. Riko's profile with its sharp contours was breathtakingly beautiful. Her glasses and reserved demeanor initially gave a cold impression, but her intelligent, unapproachable aura fascinated Yuu.  

Instead of facing Yuu, Riko turned her back and spoke.  
"I... I want to join the Komatsu Technical Research Institute after graduating university."  
"Komatsu? So that's Sayaka-senpai's company's research institute?"  
"Yes. My dream is to support Sayaka—who'll eventually lead the Komatsu Group—from the technical side. But first, I must study hard, get into university, and improve myself, or it'll remain just a dream."  

"Riko-senpai!"  
"Y-yes?"  
"That's amazing! With your dedication, you'll definitely achieve it!"  
"Eh... r-really?"  
"Yes! I'm moved!"  

Yuu himself had drifted through high school, studied for exams like everyone else, barely entered a mediocre university, and job-hunted conventionally. Having lived aimlessly with many regrets, he wondered how things might have differed with Riko's clear purpose. Though success wasn't guaranteed, he might have had fewer regrets.  

Though partly because he liked Sayaka, Riko's clear path shone brightly. Even with his middle-aged mental age, seeing youth speak of dreams was inspiring. He was also happy that Riko—who'd seemed distant—had shared her true feelings.  

"Ah... you're close."  
Unconsciously, Yuu had stepped directly behind Riko. Trapped against the sink, she couldn't retreat.  
"Wow, 'talented and beautiful' must describe someone like you, Riko-senpai!"  
"Wh-what are you..."  
"Sayaka-senpai is wonderful, and Emi-senpai is cute, but I feel truly blessed to work alongside a beauty like you in the student council!"  

He lightly embraced her from behind.  
"H-hey now!"  
Riko's face flushed red, but she didn't resist Yuu's hands—instead covering them with her own. Though claiming disinterest in boys, their previous physical intimacy meant Yuu occupied a special category.  

"Seeing your beauty, I just couldn't..."  
Yuu kissed her pale nape and trailed his tongue downward.  
"Ngh... fha... N-no! Someone might come!"  
When Yuu's right hand reached for Riko's chest, her resistance was weak. Over her sailor uniform, he gently caressed her barely visible breasts. His mouth moved from her nape to her neck, licking and sucking.  
"Riko-senpai, you smell wonderful."  
Though it was just clean soap scent, their closeness made it arousing.  

"Sto...p... ngh... Hirose-kun, you're naughty..."  
"Could you call me Yuu?"  

She'd used his given name when they had sex, but reverted to his surname otherwise. Apparently embarrassed, Yuu whispered in his sweetest voice before blowing on her shapely ear.  
"Hyan!"  
An unexpectedly cute sound escaped her.  
"W-wait! Yu..."  
"I'll eat your ear."  

Holding Riko's head as she tried to pull away, he nibbled her earlobe before licking behind her ears and along the helix.  
"Ah, stop...nhi!"  
Riko shivered slightly.  

Ears can be unexpectedly sensitive. While hair-down people require parting, Riko's neat updo left hers exposed. Yuu's tongue entered her ear canal while his right hand slipped under her sailor uniform, poking her nipple through her bra.  

"Ah...ngh... ah! Ank... noo...!"  
Blushing cheeks and sweetened tones delighted Yuu. Though usually sharp and proactive with Sayaka, he'd learned Riko became vulnerable when teased.  

Yuu's tongue pushed deeper into her ear while his fingertip circled her nipple.  
"Ngh... ah, ah, ah! Nnnn~~~~~~!"  
Riko muffled her rising moan with her hand. But Yuu persistently tormented her with fingers and tongue.  

After several minutes, he turned her limp body to face him, lifting her chin.  
"Riko-senpai."  
Her narrow eyes behind glasses wandered to avoid his gaze before reluctantly meeting it.  

"Really... such a bad kouhai."  
"Hehe. You're just too captivating, Riko-senpai."  
As he leaned in, Riko closed her eyes without resisting.  

"Mmph."  
Their lips met as he pulled her slender body close. Riko timidly raised her hands to Yuu's back. With deepening kisses, her arms tightened around him with a deep sigh. Yuu's hand moved from her neck to her head, gently stroking.  

Riko never dreamed she'd embrace and kiss a boy like this. But the ear and nipple stimulation ignited a boiling heat deep inside that wouldn't stop. She wanted more kisses, more touching—these desires spilling out bewildered her.  

After passionate kissing with repeated angle changes, Yuu whispered with their lips slightly parted.  
"Riko-senpai."  
"Fweh?"  
"Open your mouth a little."  
"Nna... eh?"  

As Riko obediently parted her damp lips, Yuu's tongue invaded. Filling her cheeks, he ravaged her mouth—scraping upper and lower gums, inner cheeks, then pinning her tongue down before forcibly bending it upward for underside attacks. Initially wide-eyed in surprise, Riko's brain grew numb from the stimulation until her eyelids drooped languidly, surrendering completely. With mouths slightly open, their tongues touched tentatively before pressing together and intertwining. Despite the lewd *picha picha* sounds, Riko was engrossed in her first deep kiss.  

"Riko-senpai... how ish it?"  
"Ah... Yuu-kun... ngh... ah... feelsh good."  
"Hehe. Good. Your expression is beautiful too, Riko-senpai."  
"Ah...ngh... chu! Nmu... puhah... Yuu-kun, you're bad... ank!"  

Unnoticed, Yuu's hands had reached Riko's chest and butt. After pulling back with saliva glistening around their mouths, he smiled.  

"I want to make you feel more, Riko-senpai."  
"Eh...? Ehh! Wait!"  

Suddenly crouching, Yuu lifted Riko's skirt.  
"Haa~. Your legs really are beautiful, Riko-senpai."  
"Stop... don't stare..."  

While women's legs are often compared to "gazelle legs," actual gazelles have sturdy, athletic builds. Riko's slender legs resembled antelope legs—straight and smooth. Though her thighs were lean, they weren't sickly thin but model-slim.  

Forcing himself between Riko's legs, Yuu ran his hands up her inner thighs. With both hands occupied, her skirt fell over his head—objectively, he was now under her skirt.  

"Really... Yuu-kun, is this fun?"  
"Yeah. Fun and happy."  
Riko looked exasperated at his instant reply but squirmed at the sensations from his fingers and breath.  

"Ah...ngh... kuh... heh!? Wait... Yuu-kun! Ah, ank!"  
After savoring her smooth inner thighs with tongue and hands, he suddenly buried his face in her panty-covered crotch.  

"Mphu~. Riko-senpai, you're already wet."  
"Stop... Yu...u...ku...n! Ah, not there... noo!"  

Through her blue-and-aqua striped cotton panties, Yuu attacked her moist pussy with lips and tongue. He felt warm love juice seeping through. Riko tried closing her thighs but only trapped Yuu's head.  

"Ank! Ngh, nnn~~~~~~!"  
Covering her mouth to suppress moans, Riko was helpless as Yuu persistently tormented her.  

After several minutes, he slid off her panties, exposing her vulva. Though her dark pubic hair was thick, its wet flattening looked obscene. With faint light filtering through the skirt, her slightly parted salmon-pink vaginal opening glistened with secretions.  

Without hesitation, Yuu extended his tongue and licked upward.  
"Kyau! Yu, Yuu-kun! N-not here... ah, ah, ank! Don't lick!"  
"Lero, lero, juru jupu chupaah... fuu. Riko-senpai's lewd juice is delicious."  
"Please... stop... ank! Hah! Ah, ah, ah, don't lick so much!"  
"Mphu~, what'll happen? Nn~ lero lero"  

When Riko tried pressing Yuu's head under her skirt, it only encouraged him. Easily peeling back her hood, he attacked her exposed clitoris directly while inserting a finger into her vaginal opening.  

"Ah...ank! Noo... Yuu-kun... ah, uun... hah, hah, haan!"  
Riko's head tilted back as she trembled with pleasure, now completely surrendering to Yuu's ministrations. She lovingly stroked his head through the skirt.  

Yuu boldly licked her clitoris with both sides of his tongue while slowly thrusting his middle finger into her tight vagina. Amid *picha picha* and *juku juku* sounds, Riko's moans intensified.  

"Ah, ah, no! Ank! Ank! Yuu-kun... Yuu-ku... feels good! Enough... ahhhhhh! No! Not that! Ah, aun! I'm... changing! I'm... coming! Ah, ah, I'm cumming, I'm cummiiiiing!!!"  
"Ooh!"  

Splashed with a gush of female ejaculation, Yuu smiled contentedly, pleased at having pleasured her. Leaning against the sink while catching her breath post-orgasm, Riko heard footsteps.  

"Ah! Yuu-kun, someone's coming!"  
"Ah, yes!"  

They hurried back to the student council room.  

"Sorry I'm late! Oh, Yuu-kun and Riko-senpai... Is Sayaka-senpai not here yet?"  
Emi opened the door. At the long table arranged in a U-shape, Riko sat opposite the entrance with Yuu in Sayaka's usual left-side seat.  

"I-it's fine. Sayaka said she'd be late today. Sh-she should arrive soon."  
Seeing Riko's flushed face and ragged breathing, Emi looked suspicious. Freshly opened documents lay before them, pretending they'd been reviewing materials.  

"Hmm. Is that so?"  
Sitting casually beside Yuu, Emi formed a line: Emi - Yuu - Riko.  

"That's upside down."  
The previous year's documents in Yuu's left hand were inverted.  
"Ah? Really? No wonder it looked odd. Haha."  
"Y-yeah. Didn't notice."  
"Jii~"  
Emi stared pointedly at Yuu and Riko, who rarely spoke alone.  

"How is it, Riko-senpai?"  
"Uu..."  
When Yuu glanced at Riko, her still-flushed face looked down as she mumbled.  
"V-very big... I think. I... don't know about this."  
"But you should know. Um, a few days ago?"  
"Ah, r-right, yeah."  

Curious, Emi leaned into Yuu. Their bodies touched, her twintails brushing his chest as she peered down. Riko averted her eyes while Yuu smiled wryly—*caught*. Their hands were under the table, Riko's left hand on Yuu's erect cock.  

"Fufu. Me too."  
With a mischievous smile, Emi reached out. The bulge was visible even through his black jeans.  
"Ahh, these pants are tight."  
"Then let's make you comfortable."  
In sync, Emi unbuttoned his pants and pulled down his underwear, making his cock spring out.  

Emi and Riko exchanged glances. Smirking, Emi firmly grasped Yuu's cock with her right hand. Seeing this, Riko sighed and followed suit with her left hand.  

Yuu wrapped his arms around their waists.  
"Please make me cum, senpais."  
"Fufu. Leave it to me."  
"Really... fine then."  

The double handjob began with two flowers: Emi gripped the base while Riko held the glans. Emi stroked faster and firmer, while Riko moved more hesitantly. The mismatched rhythms felt unexpectedly good.  

"Ah...ahh, good. Feels good."  
"Fufu, glad to hear."  
"Amazing. It's so hard and hot. Wow, clear liquid came from the tip."  
"Uhn... that's precum. Ah!"  

Riko's fingertip traced his urethra, collecting fluid.  
"I thought it'd be watery, but it's quite sticky."  
Her investigative spirit emerging, Riko leaned closer for a better look.  

"Fufufu. I love your pleasured face, Yuu-kun."  
As Emi brought her face close, they kissed messily, tongues tangling.  
"Hah, hah, Riko-senpai too."  
Blushing but closing her eyes when called, Riko received Yuu's kiss.  

As they took turns kissing, Yuu's climax approached. Emi's hand moved rapidly to induce ejaculation while Riko's slower strokes at the coronal ridge produced *nicha nicha* sounds with precum. Unconsciously grazing his glans occasionally made him moan.  

"Uu... I'm close, gonna cum..."  
"Fufufu. Payback."  
"Eh~? Payback for what, Riko-senpai?"  
"A se~cret."  
"Yuu-kuuun? What did you do with Riko-senpai?"  

Emi stopped moving. Stopping at the edge was torture. Instead, Riko circled his glans with her finger.  
"Then I'll make Yuu-kun cum. Does this feel good?"  
"Ank! Cheater!"  

Their hands brought Yuu to the brink.  
"Ahh! I'm... cumming!"  
At that moment, the door burst open.  
"Sorry! The talk ran long—"  
Sayaka appeared, breathless.  
"Ooh!"  
"Ah!"  

A thick glob of semen arced over the table, landing with a *splat* before Sayaka's feet as she entered. *Dopyu, dopyu*—more shots followed, dotting the floor white. Panicked, Emi and Riko covered the tip, coating their hands in milky fluid.  

"What exactly were you doing in the student council room?"  
"Sa-Sayaka, this is..."  
"Um, well..."  
Emi and Riko evaded awkwardly. Feeling the heavy atmosphere, Yuu boldly confessed.  

"I got excited and asked them for a handjob.  
It's my fault for pressuring them. Don't blame them."  
"Yuu-kun..."  
"Yuu-kun..."  

Without responding, Sayaka clicked her heels around the table behind Yuu. Bracing for scolding, Yuu instead felt her embrace him from behind, accompanied by her sweet scent.  

"Sayaka-senpai?"  
"Excluding me is unacceptable. Let me join too!"  
Hearing this, Yuu, Riko, and Emi smiled.  
"Of course!"  

Afterward, Yuu had wild sex with all three.  

### Author's Afterword

I've seen erotic scenes where semen splatters when a girl opens a door during ejaculation. But given the student council room's size, having it fly to the door seemed unrealistic, so I had it land on the floor.  

2019/12/1  
Changed the business paperback author to Sayaka's great-grandmother Hanako.  

### Chapter Translation Notes
- Translated "曾祖母様" as "great-grandmother" with formal honorific "あらせられる" rendered as implied reverence
- Preserved Japanese honorifics (-senpai) per style rules
- Explicitly translated sexual terms: "チンポ" → "cock", "潮吹き" → "female ejaculation", "ディープキス" → "deep kiss"
- Transliterated sound effects: "ぴちゃぴちゃ" → "picha picha", "じゅくじゅく" → "juku juku", "びよん" → "spring out"
- Maintained original name order: "Hanmura Riko" (半村 莉子) not "Riko Hanmura"
- Italicized internal monologues: "Am I the first one here?" etc.
- Used gender-neutral "they" when plural subjects had mixed genders
- Translated "小松技術研究所" as "Komatsu Technical Research Institute" per fixed terms