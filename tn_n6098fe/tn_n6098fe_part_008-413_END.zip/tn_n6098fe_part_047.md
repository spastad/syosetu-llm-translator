## 42. Going Out to the City ① ~Teenage Walk~

Going out to the city.

The reason Yuu thought of this was partly because he was intrigued by the woman-filled cityscape he saw daily through the bus window, but mainly because he wanted to personally visit stores to buy a birthday present for Sayaka.

In this era where the internet isn't widely available, going directly to stores is the norm for shopping. Though even in his previous life when the internet was common, for important gifts to women, he still preferred selecting them in person at stores. He remembered giving his wife famous brand accessories before marriage and buying her a practical spring coat together after marriage.

As a high schooler now, gifts costing tens of thousands of yen might be inappropriate. But the recipient is a company president's daughter. Something too cheap would be embarrassing, making it a delicate balance. For women's gifts, sisters would be reliable in such situations, but unfortunately his sister is currently withdrawn. Protection officers Kanako and Touko would be easy to ask, but he worries about the age gap and whether their tastes match. More importantly, Yuu himself wants to browse freely without reservations.

Though it's common sense in this world that men can't move freely, having lived in a different world, Yuu occasionally wants to walk outside alone. However, Yuu going out alone without protection officers would certainly cause an uproar. While being surrounded by cute girls is welcome, he wants to avoid being chased by middle-aged women or delinquents. Thus, his crossdressing experience at Rei's house the other day served as reference.

Makeup is impossible, but hairstyle alone can significantly change one's impression. When he asked Rei about wigs, she offered to give him many types, but thinking they were probably expensive, he declined and had her order the same one he wore before.

The plan would be executed on Saturday afternoon. Since returning buses check male student rosters, he arranged for Rei to pick him up from home after student council work.

Yuu finished his disguise in a management building toilet stall after school when fewer people were around. His outfit featured loose cargo pants and an oversized parka to conceal his crotch. He wore a long black wavy wig with volume covering his cheeks, making his face hard to recognize from the side. With a mask, he wouldn't be identifiable as Yuu. Even if forced to speak in stores, he could claim a hoarse voice from a cold. With minimal height difference between genders in this world, his build shouldn't be an issue.

"Okay. Looks good."

He checked his appearance before the mirror. Though flat-chested, his slender frame would likely pass as a slim build. Instead of his usual backpack, he carried a small unisex shoulder bag.

His wallet usually contained nearly 10,000 yen in bills and coins, but today he added another 10,000. School commutes were always by bus, and unlike his previous student life, he never stopped to hang out with friends, so spending opportunities were rare. Though he'd visited bookstores and game shops with protection officers, they catered to women so he never felt like buying anything, leaving his savings untouched.

Incidentally, all current banknote portraits featured women: Empress Jingū on the 10,000-yen note, Murasaki Shikibu on the 5,000-yen note, and a politician from the Rissei era (equivalent to Meiji) on the 1,000-yen note. He'd heard male figures like Prince Shōtoku and Sugawara no Michizane were used before the Heian period, but the prevalence of female portraits reflected this female-dominated society.

Yuu left the management building while checking his surroundings, hurrying toward the back entrance to avoid attention. Though he passed several female students who glanced at him, none seemed suspicious. His heart pounded nonstop, but they likely thought him an ordinary visitor.

First, finding a bus stop. Sairei Academy was distant from the station, so most female students used bicycles or buses to Saito Station or Higashimatsusaka Station. He'd learned Saito Station had a station building but few surrounding shops, while Higashimatsusaka Station had older commercial districts. He felt more drawn to exploring Higashimatsusaka Station, which he rarely visited.

He quickly found the Higashimatsusaka Station bus stop along the school road. Past the evening rush, about ten sailor-uniformed students and two mother-daughter pairs waited there, so he lined up behind them. A kindergarten-aged girl immediately turned to stare at him but faced forward without reaction, so he seemed undiscovered.

After five minutes, the bus arrived. Two passengers got off, but most seats were filled, forcing new passengers to stand in the center aisle. Yuu stood toward the back away from the doors to avoid notice. With his head slightly lowered and hair covering his face, everyone seemed to assume he was female. Except for Yuu, all passengers were female. Dominated by high school girls, the bus filled with that sweet-and-sour feminine scent. Seated passengers looked outside or read magazines and paperbacks—a pre-cellphone era scene. Sairei students clustered around the center aisle near Yuu, chattering noisily.

Three first-years behind him discussed school lessons, TV dramas, and celebrity gossip.

"Speaking of which, yesterday after school when I passed the second building, I happened to see Hirose-kun."

Hearing his name unexpectedly, Yuu's heart jumped.

"What are you talking about? You were lying in wait, weren't you?"  
"Hahaha. Caught me. But you know, unlike other first-year boys, he always turns around and smiles when we wave?"  
"True. For us girls, Hirose-kun is a healing presence."  
"Yeah. And that level of beauty! How many times have I wanted to take photos to save?"  
"But we can't secretly photograph at school."  
"True."  
"Well, I gathered my courage and spoke to him."  
""Hey!""

Yuu recalled that yesterday after school, when heading to the student council room, a girl had called out to him. He remembered her as short with a youthful impression, but quite cute. Tempted to confirm if she was talking behind him, he restrained himself.

Officially, cross-gender interaction began in second year, but nothing prohibited first-years from becoming close. Yuu himself waved greetings or chatted briefly with Hiyama Yoko, Aki Kazumi, and other Class 1-5 girls when passing them on campus. Perhaps witnessing this, girls from other classes had recently become more proactive in approaching him.

However, excessive behavior led to warnings. Secret photography or molestation could result in suspension. Fortunately, Sairei students rarely went that far.

"Hehe. Hirose-kun talked to me with that wonderful smile! Only five minutes, but he even shook my hand!"  
"Ehhh, unfair!"  
"Too enviable! I'll try next time."  
"But if too many go, security might scold us."

First-years seemed focused on getting him to remember their faces and names through brief interactions, building connections for the future. Yuu welcomed this since the girls approaching him were relatively cute, though he struggled to remember everyone—a luxurious problem.

"Aww, I want to see Hirose-kun and chat again!"  
"Seriously, he's so wonderful and kind—an angel!"  
"I want to date him once we're second-years!"  
"Competition will be fierce though."  
""Yeah yeah.""

What expressions would they make knowing the subject of their gossip stood nearby? Though tempted to reveal himself, he couldn't. Yuu gazed outside while eavesdropping on the girls' conversation.

The bus arrived at Higashimatsusaka Station East Exit bus terminal. As the final stop, Yuu followed other passengers off. His first view of Higashimatsusaka Station revealed a single-story building smaller than expected. Still, Saturday afternoon crowds bustled with prominent high school uniforms and business suits. Of course, only women filled his vision.

He briefly considered riding a train—what if discovered as male in a women-only car?—but today's priority was finding Sayaka's birthday gift, so train exploration would wait.

First, checking the station map for nearby shopping streets, he realized he hadn't eaten lunch. Spotting a hamburger shop facing the terminal with a familiar large yellow M logo, he entered. Though resembling McDonald's, the sign read "Mercy's"—perhaps founded by a woman named Mercy in this world.

Inside resembled his world's burger joints, easing his nerves. Notable differences were more dessert and drink options. He ordered a double cheeseburger set with small fries and Coke, pointing at the counter menu with minimal words: "This, please."

*(This reminds me of my student days.)*

Carrying his tray upstairs, Yuu reminisced. As a salaryman, he'd frequented set-meal restaurants, beef bowls, ramen, or standing udon/soba shops—his first burger joint visit in years. Back then, he'd kill time with friends after school. Though restarting life at 15, he felt lonely unable to casually hang out with male friends.

Upstairs buzzed with young women. Scanning for seats, he noticed an empty area by the window. The reason became clear: six delinquent-looking girls occupied three connected tables. Everyone avoided sitting near them.

Reluctantly, Yuu chose the farthest available table. Drinking Coke, he unwrapped the lukewarm burger. The cheap texture felt nostalgically familiar.

His hanging hair constantly bothered him—an unfamiliar annoyance. Though tempted to tie it back, that would expose his face, risking recognition by schoolmates. Briefly understanding women who frequently tuck their hair, he focused on not eating it.

""GYAHAHAHA!""

Crude laughter reached him. Sitting against the wall with a full view, he saw the delinquents guffawing by the right window.

*(Ah, Ichimatsu High students)*

He recognized their plain navy jackets and skirts—the notorious delinquent school mentioned by classmates during Newcomer Welcome Orienteering. Security seniors later confirmed they'd disguised themselves in purple jerseys during the mountain ambush.

These girls sported red, brown, and blonde dyed hair with oddly styled bangs or frizzy perms. Their white blouses hung open enough to show bras, with untucked hems. They sat with legs wide open or knees up, blatantly smoking in uniform.

"Seriously, getting caught like that—you're such an idiot!"  
"Kukuku, so dumb~"  
"The hell you say?!"  
"GAHAHA! She said it, hilarious!"

Their stupid conversations carried unapologetically. Compared to Sairei girls' loveliness, these delinquents' stupidity stood out starkly.

"Hey Yukko, heard you bought a Penis Uncle recently?"  
*(Penis Uncle?)*

The unfamiliar term made Yuu listen intently. The conversation centered on "Yukko," a long-brown-haired girl, revealed that uncles dressed as women lurked in alleys at night, performing fellatio for money. Though crossdressed, they were obviously male in daylight. Prices varied by act/partner, with full service possible at high rates—the reverse of his world's compensated dating (enko). Yuu envied men getting paid by schoolgirls.

"But that fatass couldn't get hard even after 20 minutes. Tried to run saying 'time's up,' so I kicked his crotch. He made this crushed-frog sound and went 'pyuru' with white stuff. What, you wanted that play from the start? Kicked him repeatedly!"  
"Why so mad? Maybe you just suck at sucking?"  
"N-no I don't!"  
"Well, they say Penis Uncles are hit-or-miss. Some have raging cocks good for two shots, or eat pussy well."  
"Hah? Urban legend?"  
"But if such uncles exist, I'd pay anything!"  
"More like, any young guys lying around instead of 40-50-year-olds?"  
""Hell no!""  
"Ah shit. That Sairei boy I saw recently would be perfect."  
"More than that, those girls piss me off."

Their envy toward Sairei boys and jealousy toward Sairei girls spilled out. Yuu worried if their students faced regular harassment. The grudge Ichimatsu students held during the orienteering might stem from daily resentment.

Venturing out alone let him learn unexpected truths. Though not exceptionally cute, they weren't ugly—delinquent hairstyles and makeup made them look mature. Big and small breasts, slightly plump and thin bodies. Visible underwear favored black, red, purple—no plain white. From his middle-aged male perspective, they were vibrant schoolgirls he couldn't help watching.

"Hey! The fuck you lookin' at?!"

Staring too long, one nearby girl glared. Flustered, Yuu turned away. Though fries and Coke remained, he quickly grabbed his tray and stood.

"What's with her?"  
"Who knows. Lame."

Getting entangled would be troublesome. After swiftly disposing of trash and returning the tray, Yuu left without looking back.

---

### Author's Afterword

Skipped developments like crowded train groping leading to group molestation, or delinquents shaking him down leading to exposure.  


### Chapter Translation Notes
- Translated "チンコウおじさん" as "Penis Uncle" per Fixed Reference term
- Preserved Japanese honorifics (-kun) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "pyuru" for ぴゅる)
- Translated explicit terms literally ("crotch," "cocks," "eat pussy")
- Maintained original Japanese school names (Ichimatsu High)
- Italicized internal monologues per formatting rules
- Used "Rei" for Higashino Rei since only first name appears in text
- Translated "エンコー" as "compensated dating" with original term in parentheses
- Preserved cultural references (Empress Jingū, Murasaki Shikibu) with explanations in translation notes