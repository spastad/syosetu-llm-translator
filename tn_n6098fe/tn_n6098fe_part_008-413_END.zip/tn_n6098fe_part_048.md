## 43. Going Out to the City ② ~Lonely Runaway~

After leaving the hamburger shop, Yuu passed under an arch reading "Higashimatsusaka Station Shopping Street" and began strolling along the arcade-covered shopping district.

Given its proximity to the station, there were many pedestrians and vibrant energy.

In Yuu's memories from before his rebirth, many shopping streets had become shuttered, but this place showed no signs of that.

Here, he occasionally spotted a few men.  

However, the only men walking alone were elderly gentlemen with canes. Men were always accompanied by women—those in casual clothes were likely family or lovers, while those in black suits were probably protection officers. Particularly for young men, the security was so tight it seemed designed to block surrounding gazes.

Yuu himself rarely saw men outside school, so he stopped to observe. But since he now appeared female, a black-suited protection officer gave him a stern look. Several women approached to get a closer look at what seemed to be a man in his twenties, but were immediately blocked.

*Even during daytime, young men walking alone is unthinkable in this world's common sense,* Yuu reflected anew.  

Thus, Yuu walked along the edge of the road bisecting the shopping street, careful not to attract attention. He saw not only familiar Sairei Academy's purple sailor uniforms but also groups of two or three girls from other schools chatting. Near a mixed-use building housing a bookstore and cram school, he spotted monochrome uniforms of white blazers and black skirts—likely Matsusaka High School (Matsukou). The high glasses-wearing rate and modest hairstyles gave a studious, earnest impression typical of academic-focused schools.

Conversely, the girls making noise at cafes and game centers were from Ichimatsu High School (Ichimatsu), whom he'd seen earlier. He deliberately avoided them. He also recalled that the dark gray sailor uniforms with red accents belonged to Saito Comprehensive High School (Sougou). Their students ranged from serious types to ordinary girls and even slightly delinquent-looking ones. Unfamiliar uniforms likely belonged to schools from other cities.  

Perhaps because it was a weekend afternoon, their carefree smiles resembled high school girls from Yuu's original world. However, in this world's reality, only about 1/10 of them would ever bond with a man. Behind the surface lay fierce competition, and the girls at Sairei Academy were the winners of that struggle. Yuu realized how fortunate he and other boys were to choose partners from these selected girls.  

Searching for Sayaka's birthday present, Yuu walked while examining shops on both sides. Though he had several gift ideas in mind, seeing the actual stores made him hesitate.  

"Clothes... might not suit her taste.  
Stuffed toys... probably too childish now...  
Stationery feels a bit..."  

Unintentionally, he'd started muttering to himself. Thanks to his mask, no one noticed the unusually low voice for a woman. Though they might have thought him suspicious for talking to himself while walking.  

*(Oh! That's...)*  
Halfway through the shopping street, Yuu spotted a jewelry shop across the street. Its dark-toned facade with gold lettering exuded elegance, giving an adult-oriented impression. Several accessories displayed in the street-facing window glittered under the lights.  

*(Necklaces or pendants could work well)*  
Accessories and jewelry were classic gifts for women. Seeing young students entering, he guessed it wasn't prohibitively expensive. Though entering alone as a man required courage, his current appearance wouldn't seem unnatural. The real problem was his own intimidation upon glimpsing the interior—crowded with young women when two college-aged girls entered.  

*(Hmm, what to do?)*  
While hesitating, he noticed a man around thirty entering, flanked by women. The tall women in black suits at front and back contrasted with the office lady-types in tight skirts on his sides—likely wives or lovers. Their group of five seemed to further crowd the store.  

Losing motivation, Yuu's gaze shifted to other shops. Three stores down from the jewelry shop, he spotted a traditional Japanese-style store that likely sold wagashi or tea. Though he couldn't read the cursive script, the camellia-petal-adorned sign seemed to read "Somehonpo" (Main Shop). Somehow intrigued, Yuu approached it.  

  

  

  

  

"Phew. Glad I found something good."  
While examining items at the shop, something caught his eye and he impulsively bought it. Though Sayaka's birthday party date wasn't set yet, he felt relieved to have secured a gift. It was small enough to fit in his shoulder bag.  

Reaching the shopping street's end, Yuu bought cold canned coffee from a vending machine outside a liquor store. It cost 100 yen.  

In his original world, a 3% consumption tax had been introduced around 1990. Though not yet implemented here, heated debates on TV and newspapers suggested it was imminent. Ten years after the New Male Protection Law, population issues remained unresolved, making tax implementation likely within a few years for future social security and low birthrate countermeasures.  

Thus, vending machine purchases would soon cost more than a single coin. Holding a can of OCC coffee featuring a woman's illustration, Yuu pulled the tab open. In his memory, canned drinks once had detachable pull-tabs he'd hook on his finger while drinking, but they'd apparently switched to non-detachable types.  

Perhaps because his mission was complete, his guard dropped. Without checking his surroundings, Yuu removed his mask, pocketed it, and tilted his head back for a deep drink. He failed to notice a woman watching intently from a nearby bar where she'd just stepped out for opening preparations.  

"Hey."  
"Huh?"  
Startled by the suddenly close female voice, Yuu jumped.  

The woman appeared early-thirties, with long, brown shag-cut hair and a red dress giving a sexy, decadent impression.  

Yuu panicked. Though wearing a wig, his face was exposed. As he fumbled for his mask, the shag-haired woman suddenly reached out and grabbed his crotch.  

"Agh!"  
"Hehe. Knew it. You're a boy."  
Strong perfume assaulted his nostrils.  

*(H-how did she know?)*  
Too shocked to speak, Yuu froze as she smirked, revealing crimson-rouged lips.  
"Since I've no customers yet... Come inside? Wanna do something nice with big sis?"  
Her expression resembled a predator eyeing prey.  

He'd assumed only schoolmates familiar with his face might recognize him—girls he could ask to keep quiet in exchange for favors. Being exposed by a complete stranger was unexpected. Though he could've handled it calmly, Yuu panicked and chose to flee.  

"Hey, wait!"  
Tossing his nearly empty can, Yuu sprinted away as the woman gave chase. Though faster in bursts, she desperately pursued, unwilling to lose this chance with a young boy.  

His powerful dash faltered at a road unevenness. As he stumbled, the woman grabbed his back—catching only his long flowing hair. A sharp yank followed.  
"Gah!"  
His chin jerked up, and the wig slipped off as she pulled. The woman fell on her rear, giving Yuu time to recover and widen the gap.  

"Ahh! Wait, you!"  
Her shout drew passersby's attention, but Yuu focused solely on escape.  

Emerging onto a busy roadside sidewalk, Yuu finally noticed the abnormality—everyone was staring at him. He'd unknowingly entered a crowded area.  

"Huh?"  
While running, he hadn't noticed his head felt lighter—the bothersome hair brushing his face was gone. Touching his head, Yuu paled as he realized the murmurs of "boy" and "young man" were about him.  

"Why's a boy alone?"  
"Wow, he's handsome."  
"So cute!"  
"Young man! And gorgeous with great build! So hot... *slurp*"  
"Can I approach? Is it okay?"  

Women gathered around Yuu standing frozen on the wide sidewalk, their numbers swelling rapidly—from ten to twenty to forty. Passersby joined those emerging from shops and even drivers stopping their cars. Ages ranged from elementary kids to students, office ladies, mothers, and grandmothers—all united by their heated gazes.  

In broad daylight, no one immediately attacked the beautiful boy. For now, they kept distance, some wondering why he was alone, others looking around for cameras or protection officers.  

The crowd slowly tightened around Yuu.  
*(Ah, this might be bad)*  
He'd endured intense stares during the April basketball club visit, but that felt safer—schoolmates unlikely to cross lines, with Shiina Chizuru maintaining order. This disorganized mob was unpredictable.  

Yuu urgently scanned his surroundings. Staying put wasn't an option. Decisively, he turned toward a nearby building entrance—the lobby of a large roadside structure. Several aunties blocked the path but were immobilized by shopping bags, letting Yuu slip through their gap.  

""""Ahhh! He's getting away!""""  
The encircling women gave chase—curiosity transforming into desire upon seeing escape. They wanted to talk, touch, embrace, kiss... and if possible, more. Their pursuit resembled predators chasing prey more than idol-chasing fans.  

Yuu had entered Omatsu Department Store, Saitama's only department store. Like most, its first floor featured cosmetics, jewelry, accessories, and women's bags—men's and children's sections were on higher floors. The bustling Saturday afternoon first floor became Yuu's worst possible refuge.  

"Ugh..."  
""Huh?""  
""Whoa!""  

Most present were women over thirty. Some were married, and a few guarded male family members stood near the edges. But the vast majority were women with no male connections, who reacted directly.  

""Squee! A young boy!""  
"Gah!"  

Yuu panicked as aunties twice his age swarmed him. He headed toward less crowded areas, but every direction held nothing but women. Even women emerging from inner shops changed expressions upon spotting him.  

Had this been a sale commotion, staff or security could've handled it. But no one anticipated a stunningly beautiful boy appearing alone, surrounded by female customers.  
"Everyone, please calm down!"  
Their shouts went unheeded. When Yuu considered exiting, he saw the mob approaching the entrance—trapped.  

"Why that face? Hey hey, your name? Age? Where from?"  
A heavily made-up aunty sidled up front. Older women were bolder in such situations. Gaudily dressed aunties closed in simultaneously.  
"Ah, um—"  
Yuu forced a polite smile while scanning for escape, spotting an escalator—but the path was blocked.  

"Nngh, move!"  
"Excuse you! You move!"  
Thud!  
Two aunties pushing past each other to reach Yuu collided and stumbled.  

"Huh? Where?"  
"Where'd he go?"  
Ducking behind a life-sized model cutout, Yuu momentarily disappeared from view.  
*(There!)*  
He stayed low, aiming for a gap.  

It led behind cosmetics counters. Staff were flustered by the chaos—only one quick-thinking employee called security. Security's arrival wouldn't quell this.  

Entering the counter area, Yuu stood before a navy-uniformed employee. The woman (40), who'd focused solely on work since vocational school with zero male contact, nearly fainted when Yuu appeared and placed hands on her shoulders.  

"Sorry, need to get through."  
"Y-yes!"  

Even now, Yuu couldn't bring himself to be rough with women—especially not store staff who were victims here. "Excuse me. Sorry," he said, touching her shoulder as he slipped past. Stunned employees blocked customers trying to follow into the counter area. This let Yuu shortcut to the escalator and ascend to the second floor.  

  

  

  

---

### Author's Afterword

What Yuu bought as Sayaka's birthday present will be revealed at the upcoming birthday party.

And do you understand why the shag-haired woman was certain he was male when she approached?  

  

Also, unrelated to the main story, I wrote about the manga *Chastity Reversal World*.  

Please check it out if interested.  

https://xmypage.syosetu.com/mypageblog/view/xid/175790/blogkey/220608/  

2019/03/23  
Revised the description after the protagonist enters the department store.  

2019/5/5  
Changed the canned coffee opening scene from detachable pull-tab to stay-on-tab style.  


### Chapter Translation Notes
- Translated "ソバージュ" as "shag-cut" to describe the woman's hairstyle
- Translated "ルージュ" as "rouge" for lipstick, preserving cosmetic terminology
- Translated "大松百貨店" as "Omatsu Department Store" using conventional department store naming
- Preserved brand name "OCC" as fictional coffee manufacturer
- Translated "ステイオンタブ式" as "stay-on-tab" for modern can design
- Used "aunties" for "おばさん" to convey informal age-group designation
- Transliterated sound effects: "がっ！" → "Gah!", "どんっ！" → "Thud!"
- Maintained Japanese store name "Somehonpo" (本舗) with contextual explanation
- Translated "ぷらぷら" as "strolling" for wandering movement
- Preserved honorific-free dialogue for unnamed characters