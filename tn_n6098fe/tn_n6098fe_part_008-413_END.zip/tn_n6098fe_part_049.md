## 44. Going Out to the City ③ ~Shuraba★Ra★Bamba~

### Author's Preface

The reason Yuu was exposed as male in the previous chapter was correctly guessed in the comments section that same day.  
It was because when he was gulping down canned coffee, his Adam's apple was seen moving.

---

Yuu ascended the escalator to the second floor.  
The female customers who spotted him stood dumbfounded, so he first considered finding another exit—perhaps an emergency staircase—to leave the department store.  

However, the second floor was a women's clothing section, and just like the first floor, it was crowded with female customers, so he was immediately surrounded.  
Furthermore, the group from the first floor joined the pursuit, swelling the crowd even larger.  
While no one was violently attacking him yet, the situation was explosive—any trigger could set off an outburst.  

With no choice, Yuu apologized to the stunned shop clerks with "Excuse me, excuse me!" as he cut through the register counter area, bending low to slip between displays.  

"Eh!?"  
"Ahh!"  
"Wait!"  

The women who tried to follow Yuu behind the counter got tangled up with clerks who'd regained their composure, inadvertently aiding his escape.  
The larger crowd grew confused by Yuu's quick movements and temporary disappearance.  
After all, only some had actually seen him clearly—many had just drifted over upon hearing the word "male."  

"Was it a daydream?" one woman wondered, tilting her head, while others wandered around searching for the glimpse they'd caught of Yuu. The chaos remained.  

As Yuu neared the wall from the center of the floor, he spotted a row of changing rooms.  
Fortunately, no women were chasing him yet. He decided to hide inside one to wait things out.  
But as he opened the curtain of the nearest changing room and jumped in...  

"Ugh!"  
"Huh?"  

*Boing!* His face plunged into two large, elastic mounds.  
There was already someone inside—a dark-skinned woman standing over 190cm tall.  
Not just tall but broad too. And her bust wasn't just 100cm—more like 120cm or beyond.  
To Yuu, she appeared massive, a Polynesian woman (likely Hawaiian, Fijian, or Samoan) in her underwear.  

"S-sorry!"  
"Eh? Ah! Hey, wait!"  

She seemed around 30 years old—a South Seas beauty with large eyes and lips—but Yuu had no time to enjoy the sensation of her ample breasts before quickly putting distance between them.  
Though momentarily stunned, she immediately called out upon recognizing him and charged forward still in her underwear.  
But Yuu suddenly turned a corner, dodging her, causing her to collide with another woman who happened to be passing by.  

*Phew. This is rough.*  

While spotted and called out to by several people along the way, Yuu managed to evade them, crawling along the floor until he successfully reached the edge of the floor.  
The clothing displays scattered everywhere helped conceal him.  
He could still hear women searching: "Where'd that boy go?" "Was there really a boy?" but he hid by a screen near the wall.  
However, he'd eventually be found if he stayed.  
*If only I had my phone, I could call for help,* he couldn't help thinking. But he had to escape alone to safety.  

Yuu spotted stairs about 50 meters ahead.  
He decided to make a run for it after checking his surroundings.  
*(Now!)*  

Yuu dashed in a crouched position to stay hidden.  
Luckily, he reached the stairs unseen.  
He briefly considered going down to the first floor but abandoned the idea upon hearing the ongoing commotion below.  
Instead, he switched direction and raced upward.  

Upon reaching the third floor, he didn't immediately step out but peered around the corner.  
It seemed most people had flowed toward the second floor—few were visible here.  
Just then, a voice suddenly called from behind:  

"Hey hey, whatcha doing?" "Whatcha doing?"  
"Whoa!"  

Yuu was so startled his heart nearly stopped.  
But when he turned, he felt slightly relieved—it was just two little girls.  

One wore a shocking pink T-shirt with white shorts, her long hair in side braids—probably elementary school age.  
The younger one in a floral dress with a bun hairstyle suited her well—likely her sister since they looked alike.  
Both had big, bright eyes that promised future beauty.  
Yuu crouched to meet their eye level.  

"Well, sort of like hide-and-seek. What about you two?"  
"Um, Mama had important business and ran off, so we're waiting by the restroom!" "Waiting!"  
"I see. Good girls."  
*"Ehehehe"*  

When Yuu patted their heads, the girls smiled happily.  
*Maybe their mother is searching for me too.* Yuu felt guilty for causing trouble even for children.  
Still, amidst this battlefield, interacting with the cute sisters brought him peace.  

The older sister stared intently at Yuu before grabbing his right arm.  
The younger sister imitated her, clinging to his left arm.  

"Mister, you're super handsome!"  
"Yeah, handsome!"  
"Ahaha. Really? I'm glad."  
"So be our Papa and come to our house!" "Come!"  
"Huh?"  

Yuu froze at the sudden request.  
"Hey hey, come on! Play with us! Please!"  
"Be our Papa and hold us!"  
"Hmm..."  

In other words, these sisters were born through artificial insemination and only had a mother.  
While Yuu sympathized, this was commonplace in this world.  
He couldn't possibly devote himself to just these girls—especially as a student.  
Yet he couldn't be harsh with them as they clung tightly, looking utterly adorable.  

"You two... Ah!"  
A woman's voice echoed from a nearby corridor, snapping Yuu back to reality.  
It was likely their mother—a woman in her early 30s.  
Though similar in features, she was noticeably plump—and she was dashing toward them with several women of similar age trailing behind.  

"Araaan, so a super handsome boy really was here!"  
"Mama! Let's have this cool mister be our Papa!"  
"Yeah!"  
"Ufufu. Mama wants a young Papa too. Say, do you have time later? Maybe we could go somewhere together..."  
"Wait, me too!"  
"Me too, me too!"  
"Ehh..."  

The mothers licked their lips (*juruuri*) as they approached.  
Age-wise it was acceptable, but in this situation, it was too much.  
He couldn't escape with both girls clinging to him. The only other direction led deeper toward the restrooms.  
Yuu realized he was cornered again.  

Later, he'd wonder why he thought of it, but in that moment—perhaps resigning himself to being assaulted by women his mother's age—Yuu acted.  
First, he slowly kissed the older sister clinging to his right arm.  
"Nnfeh?"  
Then immediately kissed the younger one.  
"Nn—"  

Taking advantage of their stunned freeze, he freed his arms and stood.  
Both sisters blushed, dazed.  
The approaching mothers also stopped, seemingly thrown by the unexpected move.  
Yuu placed hands on their heads and spoke rapidly:  

"Being Papa is impossible, but in about ten years, let's do naughty stuff!"  

Whether they understood or not, they nodded (*kokuri*), but Yuu had already spun around and dashed deeper inside.  

"Ahh! He's getting away!"  
"But there's only restrooms that way!"  

Yuu wasn't aiming for the restroom but a door en route labeled "No Entry Except Authorized Personnel."  
Whether it'd open was a gamble, but the doorknob turned when he gripped it.  
"Yes!"  

The mothers gave chase immediately, but Yuu managed to shut the door and lock it just in time.  

*Phew*  

Catching his breath while ignoring the *banban* pounding on the door, Yuu walked on.  
Inside was a dim concrete corridor—a stark contrast to the glittering store, as expected for employee-only areas.  
*If only I could borrow a phone somewhere.* He decided to look for an office.  

"Ah, you are...?"  
"Eh!?"  

Startled again by a sudden voice, Yuu jumped (*bikutto*).  
Turning, he saw a uniformed security guard.  

"Honestly. A young man walking alone in crowds—that's beyond careless."  
"Yes... you're absolutely right."  

Accompanied by the guard, Yuu walked through the employee corridor toward the office.  
With her tall, stocky build and scarred cheek, he'd initially thought she was male, but she was unmistakably female.  
He could only guess she was middle-aged.  

Yuu explained how he'd disguised himself to go shopping, been fine until suddenly exposed as male.  
"I suspected he might've gotten separated from his protection officer.  
If so, I thought that'd be inexcusable for a protection officer."  

Apparently, she'd originally been a male protection officer herself.  
Her intimidating appearance contrasted with her protective gaze toward Yuu—likely due to her background.  
Finally finding someone reliable, Yuu felt relieved.  

"But why are you a department store guard now?"  

He recalled Kanako and Touko proudly mentioning that male protection officers were elite among female professions.  
But he instantly regretted asking—what if it touched on painful history?  
Yet she calmly stroked her scar with a detached expression.  

"My last protection subject was a boy younger than you.  
He'd stayed late at a friend's house and nearly got kidnapped on his way home at night.  
Unfortunately, it was an organized crime group—they were armed, so it got extremely dangerous."  
"Was he alright? That boy."  
"Yes, well. We called backup and barely fought them off, but we suffered multiple broken bones—this scar is from then too. When the perpetrators injured the boy while forcibly trying to take him, it became an issue, and ultimately our contract was terminated."  

Her slight limp while walking was likely a lasting effect.  
Yuu himself wondered what happened to the officers who'd protected him when he was attacked after his middle school graduation ceremony.  
Regardless of Martina's feelings, present-day Yuu felt only gratitude, not anger, toward them.  

"Anyway, there are other guards at the first-floor security office. You should wait there until your escort arrives."  
"Sorry for the trouble."  

Just as they were about to descend the stairs—  
*Bang!* The door behind them burst open, revealing the earlier mother.  
"Found you! Kyaha!"  
"Jackpot!"  
"Let me kiss you too!"  

"Crap!"  
And there were more now—easily over ten.  

"Tch! I'll hold them here! Hurry to the first-floor office!"  
"Y-yes!"  

Seeing the guard spread her arms like a guardian deity at the stair landing, Yuu leaped down two steps at a time.  

Just as he was about to reach the first floor, he heard "Wait!" from behind—she hadn't held them all back.  

"Dammit! The office is... there!"  
A glass window midway down the first-floor employee corridor marked what seemed to be a reception desk.  
Yuu peered inside but found it empty—likely staff had left to handle the store commotion.  

*Bata bata*—footsteps descended behind him.  
A phone sat before him, but the women would arrive before any call for help could connect.  
The cramped office offered no escape.  

After a split-second hesitation, Yuu dashed toward the nearby exit.  
"Aaahn! Wait!"  
Annoyed by their persistence, Yuu emerged through the department store's back exit.  
Several work trucks were parked there, but no people. Unlike the main entrance, the back seemed less frequented.  
He had to find a police box or at least an inconspicuous pay phone.  
Hiding in the shadow of a truck by the street, Yuu waited for the women to pass before darting out, scanning his surroundings as he ran.  

---

### Author's Afterword

2019/03/23  
Major revisions made.  
Cut almost all of the scene where he's assaulted by the Polynesian beauty in the changing room.  
Softened the commotion scenes slightly.

### Chapter Translation Notes
- Translated "シュラバ★ラ★バンバ" as "Shuraba★Ra★Bamba" preserving the stylized katakana and star symbols
- Transliterated sound effects: "ボヨン" → "Boing", "バンバン" → "banban", "じゅるり" → "juruuri" (lip-licking), "コクリ" → "kokuri" (nod)
- Rendered internal monologues in italics without parentheses per style rules
- Translated anatomical terms directly ("Adam's apple", "ample breasts")
- Preserved Japanese honorifics and name order throughout
- Translated "警護官" as "protection officer" per Fixed Special Terms