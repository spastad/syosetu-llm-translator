## 45. Going Out to the City ④ ~Cheap Hippies~

Wandering aimlessly through unfamiliar territory while running and walking around is mentally exhausting.

To make matters worse, police boxes and public phones are nowhere to be found when you need them. 

I considered heading out to the main road but gave up, thinking it would just repeat what happened earlier.

So Yuu walked through back alleys for a while, avoiding attention.  
He passed several women, but they merely looked surprised and didn't attack, quickly turning corners to disappear.  
Once he found a convenience store and tried to borrow their phone, but unfortunately a group of delinquent girls was loitering there.  
The moment Yuu appeared, they surrounded him and chased him relentlessly.

He finally shook them off, but now wandered the alleys with no idea where he was going.  
All he saw were rundown mixed-use buildings covered in vines and grime, or suspicious shops with faded signs that might not even be open.  
Telephone poles and walls were covered in spray-painted graffiti like "○○ here!" or "DICK" and "SEX".  
Alongside Japanese, there was English, Cyrillic, and what looked like Arabic graffiti too - it felt like getting lost in some foreign city's backstreets.

*Ah, if a girl wandered into a place like this, she'd get kidnapped by bad guys, gang-raped, and sold to underground organizations.*  
*No, in this world it'd be a boy.*  
*Which means... I might be in exactly that situation right now?*

Even Yuu regretted his reckless actions.  
Going out in public crossdressed for the first time was beyond foolhardy.  
Not getting caught on the bus, during lunch, or while shopping was pure luck.  
Anyone observant could tell he was male, and his panicked escape caused a huge commotion that inconvenienced many people.  
Plus, if his mother or protection officers found out, they'd be furious... or worse, if they cried, he'd feel terrible.

"Haaah..."

A heavy sigh escaped him.  
Exhausted and unable to think straight, he staggered forward without knowing his location or direction.  
As he approached a building, he collided head-on with some girls just coming out.

"Ah, sorry!"  
"The hell you—huh?"  
"Eh? A guy? Wha-why's he here?"

Both were tall and looked like stereotypical delinquents.  
Their uniforms looked familiar - Ichimatsu High's navy uniforms with old-fashioned long skirts dragging on the ground.

*(Oh crap...)*

Yuu thought he'd encountered more trouble, but couldn't muster the energy to run.  
"Hey, I kinda got lost," Yuu shrugged with a tired face.  
"Hah? What're you talking about?"  
"Huh?"

The girls looked at each other dumbfounded.

"Ah, bad news," one muttered, looking across the street.  
Her eyes caught another delinquent group approaching, spread across the entire road width.  
She grabbed Yuu's shoulder.  
"Come with us."  
"Ah, okay."

Sandwiched between them, Yuu didn't even resist as they led him into the mixed-use building they'd just exited.

They walked down a dimly lit corridor with flickering fluorescent lights, turned right, and found a wooden door covered in grime and graffiti - the original color indistinguishable.  
Alongside the now-cliché "○○ here!" and "YOROSHIKU" (Nice to meet you) graffiti, there was English writing too, smudged and illegible.

"This way."

Urged by the tall girl, Yuu entered.  
Though lit, the interior looked shabby and dirty - apparently a defunct café.  
Three delinquent girls lounged inside in various poses.  
The smell of cigarettes and dust hung thick in the air.

"Huh? Back already... Whoa! What's with him!?"  
"Wha!"  
"Oooh, a guy!?"

All three looked shocked.

"Found him when we were leaving," said one of the girls who brought Yuu.  
"Saw Shouryuumon's crew coming from across the street.  
Could've beaten them down, but this guy would've complicated things.  
Says he's lost."

Yuu didn't know what "Shouryuumon" meant but guessed it was a rival group.  
He noticed something like a bōsōzoku flag decorating the back wall.

The girl from the sofa approached.  
"Phew! Damn, a rare hottie!"  
Though shorter, she reached out and lifted Yuu's chin.  
Yuu sighed, patted her head once, then walked past her.  
He plopped down on the sofa she'd vacated.  
The girl sitting opposite froze in shock.

The others stared dumbfounded at Yuu's actions.  
"Been chased around everywhere running nonstop. I'm exhausted.  
Not running or hiding anymore. Let me rest here a bit?"  
He noticed a large plate with mint chocolates and Pocky-like snacks, ashtrays, and several bottles/cans on the table.  
"Ah, can I have this?"  
Yuu picked up a half-finished cola bottle.  
"Uh, yeah."  
Taking the dazed girl's nod as permission, Yuu chugged the cola.  
"Pffuuh. Tasty!"  
A belch followed naturally.

The girls stared mesmerized at his drinking.  
"Hey... guys drink like that? Th-that was indirect kissing!"  
"How should I know? I'm still a virgin at this age with zero guy experience."  
"But damn he's hot! I wanna fuck him so bad!"  
"Thought 'players' were urban legends. Whatever, he came here himself. Like a moth to flame. We can have our way, right Leader?"  
"Ah, uh, yeah."

"Hey, you relaxing over there."  
"Yeah?"  
The tall girl addressed Yuu as he quenched his thirst.  
"First, know this place is the hideout of Saiou Red Scorpions - we make crying babies shut up."  
"Saiou Red Scorpions... Wow, cool name."  
Yuu imagined a red-themed soccer team from his world that had Saitama as home base, unsure if this was a biker gang or team.  
"Fufun, right?"  
The girl puffed her chest proudly.  
Yuu noticed her enormous breasts and stared intently.

"Mari."  
"Ah, yeah. So listen up, pretty boy—"  
"Yuu."  
"Yu-Yuu? I'm Mari."  
"Hey, cute name. Nice to meet you, Mari."  
"R-really? Hehe. Likewise."

Mari's delighted reaction drew a jab from the girl beside her.  
"Mari!"  
"O-okay, okay Ginko.  
Shit, this is throwing me off.  
S-so! When a hottie like you waltzes into a place like this, getting gang-raped and fucked dry till you wither is just how it goes, got it?"

Yuu scanned the assembled girls.  
Mari looked about 180cm tall with a sturdy build and huge breasts.  
Her black perm hair gave an intimidating first impression, but her rounded face with freckles showed youthfulness.  
Yet her plump lips and mole by her mouth held strange allure.

The equally tall girl beside her had a slender build and reddish-brown straight hair reaching her back.  
Her spiked bangs felt 80s-style.  
She wore a mask with a red X, her narrow eyes distinctive.  
From their talk, he learned her name was Ginko.  
Both wore Ichimatsu High uniforms and seemed about Yuu's age or a year older.

The girl who'd been sitting opposite stood up like a spring when Yuu made eye contact and joined the others.  
Heavy eyeshadow and makeup gave her a full-fledged ladies gang vibe.  
Her dark brown ponytail and short skirt made her the sexiest and oldest-looking here.  
But she avoided direct eye contact, only stealing glances.  
Shy personality despite appearances?

The fluffy permed-hair girl in the sailor uniform had been on the sofa earlier and gave him the cola.  
Both wore dark gray sailor uniforms with red ribbons - likely from Saitama Prefectural Saiou Comprehensive High.  
Not particularly tall, but her extremely short skirt drew attention to her slender white legs.  
Her big round eyes staring intently at Yuu seemed adorably animal-like.

Finally, one girl stood alone behind the counter, glancing at Yuu once before turning away.  
The so-called Leader had blonde hair and blue eyes - a genuine Yankee girl inexplicably wearing a red tracksuit.  
Distance and her averted gaze made details hard, but her Anglo-Saxon features were clear - sharply defined, beautiful features like a movie star.  
Her long blonde hair shone naturally, and her casual brushing-it-back gesture was stylish.  
Her unchanging aloof expression after that first glance was maddeningly attractive.

Yuu considered.  
Facing over ten opponents would've been tough.  
No inhumanly ugly girls who'd kill his erection either.  
To his middle-aged-man soul, these were all fresh high school girls - he wanted to beg them himself.  
His 40-year-old body couldn't handle it, but at 15? Maybe five rounds.

"Okay."  
"Look, behave and we won't rough you up. Just count the ceiling stains and—wait, what!?"  
Mari dropped the cigarette she'd been putting in her mouth.  
"I said okay. All five of you here. I'll take you in order."  
"WHAAT!?"

All five wore shocked expressions.  
In this world, such a reaction made sense.  
Aside from men working in the sex industry or older men selling themselves for money/young women, no teenage boy would willingly offer himself to delinquent girls - it only happened in fiction.  
They'd expected tearful pleas of "I'll pay any amount, please let me go!"  
Not that they planned to let him go - they wanted to taste his precious male body more than money.

"Y-you sane? Ready to lose your virginity to us in a place like this?"  
Ginko asked instead of the stunned Mari.  
Yuu answered nonchalantly.  
"Not a virgin anymore.  
C'mon, let's get started. Who's first?"

"Wh-wh-what do we do?"  
"Seriously? Is he really a player?"

Instead of immediately attacking, they huddled to discuss.  
*Fake-delinquent virgin girls flustered by a suddenly appearing slut*, Yuu mused.  
The lack of forced gang rape gave him some breathing room.

"Only right for Leader to go first!"  
"Agreed."  
"Let Leader's skills make that cocky bastard beg and turn him into an obedient male slave! Then us inexperienced ones can—"  
All members turned to their authentic Yankee leader.

"Eh..."  
Suddenly under their expectant gazes, the Leader responded irritably.  
"N-no thanks. Not my type."  
"Eeeh! How picky!"

Mari cut off the surprised voices.  
"Actually, always thought Leader had someone special. Never joined guy talks."  
"Ooh! Leader's the best!"  
"Ah, well... yeah."  
The Leader nodded vaguely, then changed the subject.  
"Speaking of, Misa's the only experienced one here, right?"  
"Eeh! Me!? W-well, yeah..."  
Misa was the fluffy-permed sailor girl Yuu found cute.  
"And Ryoko."  
"Fwah!?"

Ryoko was the heavily made-up girl who looked like a proper ladies gang member.  
True, she had delinquent gravitas, but she was extremely shy around men.  
The Leader patted both shoulders.  
"You two team up and fuck him."  
"Right! Leave it to them!"  
"Sh-show us how it's done!"  
"Hahaha... got it! Leave it to me!"  
"Nnngh..."

Misa put on a brave front while Ryoko looked extremely nervous at being chosen.  
They psyched themselves up for this once-in-a-lifetime chance and turned around.  
Yuu was removing his hoodie.

"Ah, finally decided?"  
"Wh-what're you...?"  
"It's hot in here. Gotta take it off anyway."  
"O-oh."

Under the hoodie was just a white T-shirt - no male underwear.  
Not just Misa and Ryoko approaching, but even waiting Mari and Ginko stared openly. Only the Leader remained unfazed with a brief glance.

"Haa, haa. So erotic..."  
Ryoko muttered, breathing heavily.  
Seeing this, Misa thought Ryoko was getting motivated and stepped before Yuu.

"F-first, two of Saiou Red Scorpions' Four Heavenly Kings - Misa and Ryoko - will take care of you.  
S-so cry real pretty for us, got it?"  
"Hoh."

*The first of the Four Kings is always the weakest*, Yuu thought, but his excitement for the coming encounter kept building.  


### Chapter Translation Notes
- Translated "マブい男" as "hottie" to convey delinquent slang while preserving attractiveness emphasis
- Translated "童貞散らす" literally as "lose your virginity" to maintain explicit terminology
- Preserved gang name "Saiou Red Scorpions" per Fixed Reference
- Translated "輪姦" as "gang-raped" following explicit terminology rule
- Transliterated sound effects (e.g., "Pffuuh" for ぷふぅ)
- Maintained Japanese name order for gang members (e.g., Mari, Ginko) as only given names provided
- Translated "オス奴隷" as "male slave" to preserve dehumanizing context
- Used "Yuu" consistently for protagonist per Fixed Character Names