## 46. Going Out to the City ⑤ ~I Want You to Kiss Me~

### Author's Preface

Starts with Misa's recollection, with viewpoint switching midway.

Slightly longer than usual.

---

My name is Misa. I'm a second-year commerce student at Saito Comprehensive High School.

Even though I've been starved of male attention for years, I did have something like a boyfriend—well, a close male friend. Until I was twelve, anyway.

That guy was Hiro, who lived in my neighborhood. What you'd call a childhood friend.

Hiro's face was average or maybe a bit old-looking, but I liked how unusually gentle and kind he was for a boy. We went to school together from kindergarten through elementary.

When we were little, we didn't really think about gender differences. We'd fool around like idiots walking to school and after classes, laughing together—those were fun times. Back then I could even visit Hiro's house to play games or read manga. We fought sometimes but always made up quickly.

But around 11 or 12, I started feeling self-conscious. I hated getting teased by girls when we walked home together, so I deliberately kept my distance. Looking back, those girls were probably jealous I had a close male friend.

Realizing I saw him as a boy meant my feelings for Hiro were changing. Yeah—first love. Since middle school would separate us into different classrooms, and I wouldn't be able to talk to him casually anymore.

On graduation day, I made a big decision: I called Hiro behind the school building to confess.

But I couldn't bring myself to say it properly. Hiro gently stroked my head while I fidgeted. Back then I had long black hair. Having Hiro stroke my head calmed me down, but facing him directly made my heart race and put me in a weird mood.

Looking up at Hiro's face—he'd gotten taller than me—I kissed him. Just a light touch of lips—my first kiss.

"I like you, Hiro! I'll be your wife someday! Keep the first wife spot open for me!"  
"Huh...?"  
"Answer me!"  
"O-okay. Got it."

Maybe he was just swept up in the moment, or maybe gentle Hiro was humoring me, but when I got home alone, I was over the moon. Well, a grade-schooler's promise isn't exactly reliable.

Middle school completely separated boys and girls. Since I biked to school while Hiro had protection officers driving him, we barely talked. At first Hiro would wave when he saw me, and we could chat over the fence—that was okay.

Middle school girls start getting interested in sex and horny. Some stupid girls took a liking to Hiro and started stalking him, so Hiro and his mom got really wary of women. I couldn't visit his house like before—couldn't even talk to him.

I only learned Hiro was going to a boys' dormitory school in Kasugai City in eastern Saitama just before middle school graduation. We never got to talk properly before he left.

They say first loves never work out, but I at least wanted to say goodbye properly before he moved.

That's why I went wild in high school. A so-called "high school debut." Dyed my hair brown, got a perm, started going out at night with delinquent friends, learned to smoke and drink. Not that cigarettes tasted good—I couldn't handle alcohol either. I didn't have the guts to do paint thinner like Ichimatsu High delinquents or buy (hunt) men.

Then a second-year senior invited me to join the Saiou Red Scorpions. They were getting pushed around by the upstart Shouryuumon, but they had a long tradition dating back before the merger of Kurenai Chou and Joou Sasori. When I joined, there were still over ten members.

I wasn't confident I'd fit in, but the Red Scorpions valued camaraderie—they had this vibe of girls having fun freely together without strict seniority rules, which I liked.

I had fun, but clashes with our archrivals Shouryuumon were tough. I'm not strong—more the brainy type—but I got dragged into fights several times.

Then in January this year, the core members including our leader got arrested on suspicion of male assault. It was shocking—they were too straight-laced for that. The police (MALSOK) just swallowed the male victim's testimony and didn't listen to our leader at all.

We ran around gathering info. The "victims" were two guys around 40. Rumor had it they'd been connected to Shouryuumon members through prostitution. That time, they'd persistently solicited our leader in a red-light district. When one hugged a member, they forcefully pushed him off, and he suddenly collapsed. Then he tore his clothes, ran off screaming about being attacked by delinquent girls. Total frame job. They'd even filmed the takedown from the shadows. Hearing that got us furious.

But they must've been waiting for this—our leader's arrest. When only one or two members were left, Shouryuumon ambushed us in the dark or forcibly recruited members until only three of us remained—including me.

Then Ryoko—the Red Scorpions' top fighter who'd just repelled an ambush—stepped up. One snowy February night. She stormed Shouryuumon's hideout alone with a wooden sword.

Later I heard she took on about ten people in a huge fight and hospitalized over half—incredible. But Ryoko got badly hurt too—cracks in her left arm and ribs. When she tore down their team flag from their hideout and came back to us covered in blood, she collapsed immediately—we panicked.

Ryoko was hospitalized over a month and had to repeat second year. After her raid, we cheered, but when our other senior graduated, only Ryoko and I were left. I thought we'd have to disband, but three fresh middle school graduates joined in March. They said they were from the same elementary as our jailed leader and owed her from childhood. That was Mari, Ginko, and Keiko—blond with blue eyes, looked like a real Yankee but insisted she was pure Japanese.

So from April, the five of us became the new Saiou Red Scorpions. Normally Ryoko, as the oldest (though repeating), should've been leader. But she refused, saying a fighter like her wasn't fit. And someone half-assed like me wouldn't work either. While we went leaderless, I noticed Keiko was surprisingly dependable for her age. Mari and Ginko agreed, so we pushed it onto Keiko.

Then we decided: Among us five, no hierarchy. We'd call each other by first names and use casual speech.

The Red Scorpions always had loose seniority. Not that juniors disrespected seniors—we cared for every teammate as important. That's why we were tight. Until that damn incident. Honestly, without Keiko, Mari, and Ginko joining, we'd have disbanded. Ryoko and I had no intention of bossing around newcomers.

Ryoko had trained in martial arts at some dojo and was unbeatable in fights. But the three newbies—Mari (judo background), Ginko (karate), Keiko (kickboxing)—were amazing too. When Shouryuumon tried picking a fight with twice their numbers, the three easily repelled them—I was stunned. We'd gotten some real fighters.

I was the only half-assed one in fighting and delinquency, but I had one advantage over the other four: My experience with men—well, my puppy love with Hiro. Ryoko was unbeatable against women but froze stiff around men. Mari and Ginko had zero male experience. Keiko just clammed up when the topic came up—seemed totally uninterested in men. Mari thought she might have someone special in mind; I secretly suspected she was a lesbian.

Not that I had much to boast about, but my bad habit of getting carried away kicked in. Bragging away, I ended up claiming Hiro and I lost our virginity in middle school. The mood made it impossible to admit we'd only kissed lightly or that we drifted apart without progress after starting middle school. Peer pressure is scary.

So with new members, things seemed fun, but my male drought continued. Despite what I told them, I was still a virgin. I could pay big money to a Penis Uncle in the nightlife district to lose it. But if possible, I wanted to lose it to a boy my age. I'm not picky about looks—just someone kind. Yeah, someone like Hiro would be perfect.

◇ ◆ ◇ ◆ ◇ ◆

"Mmchuu, chuu... lero, lero, anmmu... mm, mmfuu... chupaa... haun"

The tongue that had been freely moving around in my mouth pulled away with a *tsuu* sound, trailing a string of drool. After a kiss far more intense than my sixth-grade first kiss, the beautiful boy Yuu stuck his tongue into my mouth.

When that wet mucous membrane violated me, my head went fuzzy—I couldn't think at all. I stuck out my tongue too, and as they tangled, this aching feeling deep in my stomach made me realize—confused as I was—that I wanted more of Yuu.

"Yuu, more!"  
I begged in a voice so sweet I couldn't believe it was mine.

Then Yuu whispered to me with a face so beautiful it mesmerized me:  
"You're cute, Misa."  
"Auu!"

Oh no. I'm wet down there.

I closed my eyes, slightly parted my lips, and waited for Yuu's wet lips to approach.  
*Buchu, picha, picha.*  
Every time Yuu's and my tongues tangled, lewd sounds echoed, fogging my brain. This was an adult kiss. Dangerously good.

As Yuu pulled me close, my sailor uniform got pushed up high, and Yuu's hand roamed inside. Before I knew it, even my bra came off. Every time my chest or sides were touched, my body trembled. Not to be outdone, I reached for Yuu's chest and back, touching freely.

A boy's body is this hard and rugged? Somehow it's really arousing.

After a long, deep kiss with me, Yuu turned right.  
"Ryoko, let's kiss."  
"Nn..."

My eyes got drawn to Yuu's neck. So sexy. And being this close, I could smell Yuu's sweaty, masculine scent. Like a moth to flame, I pressed closer to the skin. After sniffing deeply with my nose pressed in, I realized I'd licked it.

Yuu, who'd been kissing Ryoko, turned to me.  
"Haha, that tickles."  
"D-did you hate it?"  
Yuu's left hand—which had been stroking my body—patted my head and stroked it.  
"Funyaan"  
I let out a cat-like sound without thinking—it felt so good.  
"It's fine, do what you want."  
Yuu said with a gentle smile.

Cheater. Already so handsome, then saying that—  
My heart skipped a beat. I felt my face burning crimson—embarrassed yet happy. Lost in confused feelings, I buried my face in the base of Yuu's neck.

"Nn... fu..."  
"Don't tense up so much. Relax."  
While stroking Ryoko's hair with his right hand as they kissed, I started greedily licking and sucking Yuu's skin.

◇ ◆ ◇ ◆ ◇ ◆

The two who sat on either side of Yuu—Misa and Ryoko, as he'd heard.

Since it was originally a two-seater sofa, they pressed tightly against him. But that was all they managed. Misa kept glancing at Yuu, moving her hand out then pulling back. Ryoko was completely stiff, not even trying to look at Yuu's face.

Losing patience, Yuu wrapped both arms around their waists and pulled them close.

"Fwaa!"  
"...!"  
"Let's get started. Misa first, then."  
"Ehh? Nmmu!?"

Yuu alternated kissing Misa and Ryoko. Simultaneously, his hands pushed up their sailor uniforms and began freely touching their upper bodies. By touch, he learned Misa was slender with modest breasts, while Ryoko had toned muscles and surprisingly large breasts. When his fingers touched the scars on Ryoko's armpits and shoulders, she let out a strange "Nhi!" sound.

"Did it hurt?" he asked, but she just shook her head.

Misa was the first to moan sensually from the deep kisses and hand caresses. In contrast, no matter how many times Yuu kissed Ryoko, she remained stiff as a board, eyes and mouth tightly shut. Yuu thought so-called ladies (delinquent girls) would have immunity to men, but Ryoko seemed completely different. Her extreme innocence and lack of male exposure felt refreshing.

Staring closely at her face, Ryoko glanced at Yuu with her dark brown eyes but immediately looked away. Her downcast eyes had unexpectedly long lashes—a thrilling allure. Though wearing heavy makeup, her natural features weren't bad—rather well-proportioned. Yuu stroked her cheek, played with her ponytail, then brought his mouth to her ear.

"Ryoko, you're pretty—the beautiful type."  
"He...? L-lies."  
"Not lies. *Fuu*"  
"Hii!"

When he blew into her ear, Ryoko jolted. "I want you, Ryoko. I want to know all your sounds and expressions."  
"Nuaa!"

Yuu tickled her from armpit to flank with the fingertips of his right hand—still pushing up her sailor uniform from inside.  
"Hyaa! St... ahi, hyaa, hyau! St-stop... aha, hahi, haun!"  
"Hahaha. There there."  
He mercilessly tickled her toned upper body without an ounce of excess fat. Ryoko twisted to escape but had nowhere to go—she was against the wall.

In Yuu's memory, ticklish girls were supposedly sensitive. He hadn't verified if that was true. But at least she probably wasn't frigid. Women in this world were generally highly sexual and sensitive anyway, so it wasn't reliable.

But Ryoko seemed extremely ticklish. Especially under her armpits.  
"Ahyii! Hii, hii... hya, ahyahyaa fuwaa! St... stop, uhi! Hooooooooo!"  
She let out sounds girls shouldn't make, clearly feeling it intensely.

When he noticed, she was teary-eyed and breathing heavily. Yuu placed a hand under her chin and pressed his lips to hers. Savoring Ryoko's vividly rouged lips while observing her, she seemed to have lost her tension. Good timing.

Gently stroking her neck, Yuu slipped his tongue in.  
"Nfu!"

He briefly worried she might bite in shock, but needlessly—Ryoko yielded completely to Yuu.

While distractedly feeling Misa greedily licking his exposed skin, Yuu caught Ryoko's retreating tongue and tangled with it.  
"Mufu... nn, aau... n... fu! Nkuu... chupa... ah, nnn!"

Recently practiced, he successfully unhooked her bra clasp with just his right hand behind her back. Pushing up the front of her sailor uniform revealed breasts that were mesmerizingly round and perky—beautiful mounds. From Yuu's memory, larger than Sairei Academy student council member Emi's—probably D-cup.

"Ah, Ryoko's breasts are beautiful too."  
"Eh? ...Nnaa!"

Pulling away with a string of drool between their lips, Yuu observed her breasts before deliberately touching the right one with his hand. It slightly overflowed his palm—soft yet firm flesh with perfect elasticity. The cute pink nipple still shyly puckered.

While kneading with his right hand, he latched onto the other breast.  
"Hii! Ah, yaa... a... nn!"  
Yuu hungrily sucked, rolling the nipple with his tongue inside his mouth.  
"Th-there... st... stop... ann!"  
Ryoko's husky, nasal moans fueled Yuu's excitement. He tormented the nipple with his fingers while focusing oral attention there too. After thoroughly kneading it up and down with his tongue, he sucked like a baby. Ryoko moaned while trembling, clutching Yuu's head.

After ample breast play, he pulled away with a *chupon* sound. Looking up, he saw Ryoko with flushed pink cheeks and dazed expression. As they kissed deeply again with open mouths, Misa pleaded.

"Aahn, Yuu... me too."  
"Haha. Sorry sorry. Your turn, Misa."  
"Nn... nfuun. Kissing feels so good."

Yuu alternated deep kisses while kneading both girls' breasts and playing with their nipples. With Misa's high, sweet moans and Ryoko's husky, restrained ones coming in stereo, Yuu's excitement skyrocketed.

"Hey, hey... Yuu?"  
"What is it?"  
"Wh-what's... this?"

When Ryoko's face fell against his chest as he stroked her head, Misa stared at Yuu's prominently bulging crotch and asked.

"Huh? Didn't you say you had experience, Misa? You know what this is, right?"  
Having clearly heard their earlier conversation, Yuu whispered mischievously near Misa's ear. She stiffened, eyes darting. "I-it's too big..." she murmured softly, then frantically shook her head, putting on a brave front.

"O-o-okay. I know! Th-this is... b-bo-bo, boner, right? Haha... g-got this hard, how lewd. Yuu is..."  
"Well, yeah. I've been getting horny playing with you and Ryoko."  
"Seriously? Even though you're a boy?"  
"Seriously. Because I'm a boy. Want to touch it and see for yourself?"

Misa gulped, then nodded her head up and down like a puppet on strings.

### Chapter Translation Notes
- Translated "チンコウおじさん" as "Penis Uncle" per Fixed Special Terms
- Preserved Japanese honorific-free naming (e.g., "Hiro" not "Hiro-san")
- Rendered sound effects literally (e.g., "chupaa" for ちゅぱぁ)
- Translated explicit anatomical/sexual terms directly ("erection", "breasts", "tongue")
- Maintained original Japanese name order (e.g., "Hirose Yuu")
- Italicized internal thoughts (e.g., *Cheater*)
- Used gender-neutral "protection officers" for 警護官
- Formatted simultaneous actions with em-dashes for fluidity