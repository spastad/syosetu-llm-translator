## 47. Going Out to the City ⑥ ~Get Wild~

"Ah, ah, Yu...u... Not there... it's... good! Why... it feels so good! Aahn!"

"Nn... hah, hah, haaah! Ah!... Hahi, hahi, nguuuuuuuuuuuuuuuuuuuuuuuuu!!"

"Fufufu. Both Misa and Ryoko are so wet. Look look, your clits are all swollen. Feels good when I do this, right?"

"Y-y-yes... It feels good... Yuu. And your cock is so hard and hot... A, a, ahhaa... Me..."

"Nn, nn, nna! Ann!"

"Ryoko's feeling it too. Your pussy's soaked like a flood."

"D-don't say... that... Embarrassing..."

"Nothing to be embarrassed about. Here, touch my cock more. It's okay to get even dirtier."

"Uu..."

Yuu had lowered his pants and underwear to his ankles, letting Misa and Ryoko touch his erect cock. Both his hands were caressing their private parts with several fingers. Following Yuu's instructions, Misa and Ryoko had taken off their skirts, leaving their panties hanging on one leg while spreading their legs hooked over Yuu's legs.

Mari and Ginko were watching the sexual act unfolding between the three from the adjacent booth, gradually leaning forward while gripping the sofa backrest tightly as they stared.

"Hey, Ginko..."  
"W-what... Mari?"  
"I-it's my first time seeing a real man's cock... it's grosser than I imagined."  
"Y-yeah gross. Gross but... somehow I'm feeling weird."  
"Can something that big really go inside a pussy?"  
"No idea. But anyway, Ryoko making that face is something I've never seen before."  
"Me neither. Somehow I'm jealous... nn"

When Mari looked at Ginko, she noticed her breathing heavily through her nose, her mask puffing in and out. Ginko was also fidgeting with her thighs pressed together. Mari understood that feeling well and slid her hand under her own skirt to her crotch.

"Ginko..."  
"W-what is it... Mari?"  
"Watching them... I'm getting wet."  
"Relax. Me too."  
"I see... Hn... fuu"

Mari and Ginko both began fingering themselves under their skirts, silently agreeing not to comment on each other's actions.

Right now before their eyes, Misa was trying to climb onto Yuu who remained seated. Yuu's hands supported Misa's buttocks from below, guiding them to join. As if they couldn't afford to miss a single moment, Mari and Ginko stared intently while frantically moving their right hands. So intently that they didn't notice leader Keiko, who had been behind the counter earlier, had disappeared.

"A...ga... Oww... mggg"

When inserting in the facing position, Yuu definitely felt the sensation of breaking through the hymen. Misa seemed to be grimacing from the pain of losing her virginity, biting down hard to avoid crying out. Having deflowered several virgins since being reborn in this world, Yuu couldn't help but wryly smile at Misa's poor acting trying to appear unaffected.

"What... are you laughing at...?"  
"Misa, you were really a virgin, weren't you?"

Blushing, Misa averted her eyes. The insertion wasn't complete yet. Yuu changed his hand position from her buttocks to her waist and pushed in further.

"Ngyii!"  
"Strange. If you weren't a virgin, you wouldn't be in so much pain."  
"T-that's because Yuu's cock is too big!"  
"I see. That makes sense. Then once it's all the way in, I'll go hard. I'll pound you so hard you'll forget your first time ever happened."

Seeing Yuu's grin with upturned lips, Misa looked at him fearfully. "W-wait Yuu"  
"Nn?"  
"I..."

Misa lowered her eyes and spoke in a voice so small it almost disappeared. Fortunately, Yuu's right hand had been playing with Ryoko's private parts this whole time, and she was moaning in suppressed voices with no room to pay attention to Misa.

"I... I've only ever kissed someone before. This... doing this... Yuu is my first."  
Without letting her say more, Yuu sealed Misa's mouth with a kiss. "Thanks for telling me. I'm happy to be Misa's first. Let's feel good together!"  
"Ann! Yuu...n...faa! I-it's in... deep... all the way... o, oh... ahi... Yuu's cock is filling me up!"  
"Ku... As expected of a virgin pussy. Misa's insides are tight... feels great!"  
"My... my pussy is making Yuu feel good...?"  
"Yeah, it feels so good I could stay like this without moving."

Actually, even while connected deep inside, Yuu was only supporting her waist with his left hand. Perhaps due to her petite build, Misa's vaginal canal was narrow, tightly squeezing his cock all around.

"An... I'm happy. I'm glad Yuu was my first."  
"Misa"  
"Nn"

After sharing a passionate kiss, Yuu and Misa were watched not only by Mari and Ginko leaning from the adjacent booth, but even Ryoko was looking at them with envious eyes. As Yuu began slowly moving his hips while their tongues intertwined lewdly, Ryoko rested her face on Yuu's shoulder with a soft thump.

"Nn... Ryoko?"  
"A, um, Yuu?"  
"What is it? Tell me."  
"Um, um..."  
"Nn"

Ryoko, who had been looking down, glanced at Misa before looking up at Yuu. "Next... I want it."  
"Ryoko"  
"Au"

Yuu took Ryoko's chin, red to her ears, with his still-wet right hand. "Of course, next is Ryoko's turn. I'll make it unforgettable sex."  
"Nnn!?"

While sealing Ryoko's lips, Yuu didn't stop his hips. That said, Misa's virgin interior was extremely tight, so he was thrusting slowly while deeply connected.

Misa wrapped both arms around Yuu's shoulders and clung tightly, starting to let out sweet moans. "Ahhaa... ah, ah, nn! Nna! Somehow... it's starting to feel... good."

The pain of losing her virginity didn't last long, being quickly overtaken by the pleasure of union - apparently a characteristic of women in this world. While women were naturally more pain-tolerant, perhaps their heightened sexual desire and pleasure easily overwhelmed pain perception. Though a mystery to Yuu, having experienced traumatic first nights in his original world, he couldn't help but feel happy as a man that she was feeling pleasure.

The endless flow of love juices provided lubrication, making movement easier, Yuu noticed. Temporarily breaking his kiss with Ryoko, he spoke to Misa.

"Misa, want to try moving yourself?"  
"Eh, eh? Can I do it well...?"  
"Just move however feels good to you."  
"A... yeah. I'll try moving."

Misa placed her hands on Yuu's shoulders and began moving her hips up and down. Though clumsy at first, she gradually got used to it and started swinging smoothly.

"Nn, nn, gyaaah! This... somehow... amazing! My deep spot... deep inside... Yuu's cock is hitting it! An, ann! Feels so good... a, a, aaah! Can't stop!"  
"Ooh... good, Misa. Kufu, that's the way."

Misa's fluffy hair swayed with each up-down motion. Unfortunately, her breasts weren't voluminous enough to bounce, but with her hip movements, wet squelching sounds - nucchu, nucchu - began from their joining point.

"Nnn-! This is bad... I'm getting addicted! A, ann! Aahn! So good... Yuu's cock feels so good... hahi, hahi... gyaauu! Wait... Yuu!?"

This time Yuu himself started thrusting upward. Misa's petite body shook violently up and down. "Sorry. I can't hold back much longer. I'm gonna cum inside you, Misa!"  
"Kyauu! Yuu, so rough!"

Tan, tan, tan - rhythmic slapping sounds of buttocks meeting played with each of Yuu's thrusts. "Hah, hah, hah, shugoiieee... I, I didn't know... something like this. My belly... grri, grri, deep inside... being gouged... ann! Ah, ah, ah, Me... pierced by Yuu's cock... going crazy... un! I'm going crazyyyy"  
Misa threw her head back, completely at the mercy of Yuu's assault.

But Yuu had no room to spare either. Though somewhat accustomed, the post-defloration vaginal walls tightly squeezed his cock, bringing incredible pleasure, and he was nearing his limit. "Gu, sorry Misa. I, I'm cumming... kaha!"  
"I-it's okay... Cum inside me... guaaah! I-inside, it's getting super intense!"  
"Aah! I, I'm cumming!"  
"Ahhiin!"

Thrusting deep inside at the moment of climax, massive amounts of semen poured into Misa's womb. "Wha, wha, nya? Gyaa... it's coming! Hot stuff... fuwaaaaaahhhh... a, a, inside my belly... full... pulsing, coming out..."  
Receiving repeated ejaculations, Misa collapsed face-first onto Yuu's shoulder.

Since Misa was relatively light, Yuu stood up still connected in the "station lunchbox" position and carried her to the sofa opposite. Mari and Ginko, who had been leaning forward watching intently from the adjacent booth, hid themselves shyly the moment they made eye contact with Yuu. But at that moment, their blouses were completely unbuttoned, fronts gaping open, and their breasts seemed visible.

When laid on the sofa, Misa opened her eyes slightly and looked at Yuu. "Yu...u...?"  
"Misa, that felt amazing. Rest a bit."  
"A... yeah. Me too... best ever. Thanks."  
"You're welcome."

Patting her fluffy hair and giving a light peck, Yuu pulled his cock from her vaginal opening, and a thick, cloudy fluid leaked out. The pink tint was likely hymen blood. Yuu's freshly pulled-out cock still maintained its hardness, pointing skyward.

""Aah...""

Mari and Ginko stared intently from behind the sofa backrest, busily moving their right hands, but Yuu didn't notice as he turned toward the sofa where he'd been sitting. There, Ryoko was looking at Yuu with heated eyes.

"Sorry to keep you waiting, Ryoko. Shall we?"  
As Yuu approached, Ryoko nodded her head up and down like a broken doll. "Nn... ha... a..."  
She let out a longing sigh looking at Yuu's cock. The earlier coupling with Misa had clearly affected her.

First impression: a tough-looking delinquent girl.  
When embraced and kissed: a bashful maiden.  
And now: the expression of a lustful female.  
Though hard to tell under heavy makeup, her features were unexpectedly well-formed, and undressed, she had an outstanding figure. Though he'd just ejaculated and seemed to be calming down, the flames of desire burned fiercely within Yuu.

Now Ryoko was glued to Yuu's cock standing before her. Yuu extended both hands and placed his palms behind Ryoko's knees. "Spread your legs and show me your pussy well."  
"U... un"  
Lifting her legs to spread them wide, he placed her feet on the sofa edge, forming a perfect M-shaped spread. Right in the center, Yuu stared at the gaping vulva. The clean salmon-pink flesh glistened wetly, showing its insides obscenely. "Fuu... Ryoko's pussy is pretty too. Well then, I'll have it now."  
"Fue... a... kun!"

The tip of the ferocious-looking meat rod pressed against the center of the untainted virgin's private parts.

Ryoko, a delinquent feared not only by rival gang Shouryuumon but known throughout the city. Yuu, popular at the co-ed school everyone admires. Hearing these two would have sex, most would imagine Ryoko forcing herself on Yuu. But the reality was playboy Yuu about to thrust his cock into inexperienced Ryoko.

Once again, Ryoko tightly closed her eyes showing tension, so Yuu brought his face close and spoke gently. Still not inserting, he rubbed the glans against her vulva center. "It's okay. Relax and leave it to me."  
"Ah..."  
Ryoko gasped, her eyes moist as she met Yuu's gaze. Drawn in, they kissed. Kiss. Kiss.  
"Afu... yu... u..."  
Ryoko wrapped both arms around Yuu's shoulders, letting out a hot breath.

Seeing Ryoko's expression, Yuu smiled and pushed his hips in while keeping her legs spread with both hands.  
"...nguu!"  
"Are you okay?"  
At close enough range to feel each other's breath, Yuu watched Ryoko's furrowed brows. "O-okay... come..."  
"Nn"

The strong resistance of virgin vaginal flesh against the glans immediately after breaking the hymen. Yuu pushed his hips in forcefully, thrusting deeper.  
"Gu! Haa... Ryo... ko!"  
"Ga... haa... Yu... u!"

Though she spoke little, she was clearly in pain. Ryoko clung tightly to Yuu with both hands. Looking down, Yuu saw a trickle of blood from the deflowering. But deliberately, Yuu didn't stop, instead thrusting vigorously.

Gori gori - parting the vaginal flesh, the cock tip finally reached deep inside and thrust in completely. "O... oh... Ryoko, it's all the way in."  
"Nn... A... haa... Yuu, so big"  
Yuu moved his arms from behind her knees to embrace her back, then slowly began moving.

""Amazing""  
"Yeah. Amazing..."

Ryoko sat spread-legged on the sofa while Yuu thrust into her in a half-squatting position. Sex like wild animals. Pan pan pan - sounds of flesh meeting, along with gucchu gucchu - the wet sounds of genitalia playing. Though the table blocked their view from there, mixed fluids dripped to the floor, spreading stains.

Ryoko, clinging to Yuu, who had been suppressing her voice while unable to hide her tension earlier, now opened her mouth wide letting out loud moans as if it were a lie. While Ryoko's state was unbelievable, for Mari and Ginko, Yuu violently thrusting his hips was equally unbelievable. Since earlier, they'd lost their vocabulary and could only say "amazing."

"A, I want to do it with Yuu soon, can't stand it."  
"Me too."  
Both Mari and Ginko had their hands inside their panties comforting themselves. When their eyes met, a sudden question arose: Who would go first with Yuu?  
"Ha, haha"  
"Hahaha"  
Hiding their absolute refusal to yield, both laughed it off.

"Ah, aaah! Nn, nn, Yuu... Yuu!"  
"Ryoko! Aah, Ryoko's insides feel amazing!"

Though he'd ejaculated once, the virgin vaginal walls still tightly squeezed his cock. While Misa felt tight due to her petite build, Ryoko's developed muscles made her clamp down hard deep inside. It felt incredibly good. Though the half-squatting position was somewhat strenuous for Yuu, with each long stroke thrusting from near the vaginal opening to deep inside, a tingling pleasure pierced his entire body.

Meanwhile, Ryoko was initially unable to hide her confusion at Yuu covering her with his weight. But feeling his breath, smell, and warmth, she experienced an unprecedented physical and mental excitement. The pain of deflowering itself wasn't as bad as expected. The foreign sensation of her first penetrating cock gradually became unnoticeable, and with each deep thrust to her vaginal depths, she was tossed by wave-like pleasure. Ryoko moaned in higher pitches than ever, repeatedly calling Yuu's name. When Yuu called her name in return, her excitement soared beyond measure.

"Aah, Yuu. I... I... aku! A, a, aaaah! Scared... I'm scared, Yuu! From deep inside my body... bubbling, something hot is coming... it's weird! H-he, I'm going crazy!"  
"It's okay, Ryoko. You're about to cum, aren't you? Just let yourself go."  
"Yuu... aahn! This... this is... can't... a, a, aaah! D-don't do that anymore... aaaaaaahhhhhhn! Yuu! Yuu! Something amazing is coming!"  
"Guu! Don't squeeze so tight! Aau! I-I'm cumming too! Kuuuuu... cum... ming..."

While repeatedly thrusting deep with his cock fully inserted, Yuu finally reached his limit. He ejaculated with the glans pressed against her cervix. An impressive amount of semen for a second round was released into Ryoko's womb.

---

### Author's Afterword

Regarding this weekend's updates, though I normally post Friday nights and Sunday afternoons, due to circumstances I'll only be posting once on Saturday night.

### Chapter Translation Notes
- Translated "処女膜" as "hymen" for anatomical accuracy per explicit terminology rule
- Rendered sexual sounds literally: "ぬっちゅ" → "squelching sounds - nucchu", "ぐっちゅ" → "gucchu"
- Preserved Japanese honorifics (-kun for Amir) though none appeared in this chapter
- Translated "慶子" as "Keiko" following Fixed Character Names list
- Maintained explicit anatomical terms: "チンポ" → "cock", "おマンコ" → "pussy"
- Formatted internal monologues in italics: "（この世界に生まれ変わって...）" → "*Though a mystery to Yuu...*"
- Used direct translations for sexual acts without euphemisms: "射精" → "ejaculated", "セックス" → "sex"