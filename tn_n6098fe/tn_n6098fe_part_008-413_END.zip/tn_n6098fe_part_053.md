## 48. Going Out to the City ⑦ ~I'm Popular~

"Phew... Let's take a short break."

Since his underwear and pants were getting in the way of walking, Yuu headed toward the counter completely naked except for his shoes and socks. Spotting an unopened bottle of oolong tea on the counter, he thought *(I'll pay for the tea later)* and without asking, used a nearby bottle opener to open it, gulping it down. Though lukewarm rather than cold, it felt delicious after sweating.

Just as he wondered where the blonde, blue-eyed leader had gone and tried to look around the store—

"Ugh, I can't take it anymore!"  
"W-wait, Mari! Damn it, I can't either!"  
"Huh?"

Yuu was startled as the nearly naked Mari charged at him, unable to stop or dodge. "Whoa!" Mari threw off her skirt onto the seat where she'd been sitting, forcibly removed her blouse and bra mid-charge, and clung to Yuu while her magnificent breasts bounced, pushing him down onto the floor. Held by her arms, Yuu didn't hit his head, but he couldn't move under Mari's well-built frame.

This was a judo pinning technique—tate shiho gatame. Mounting the supine opponent and pressing down on their face using breasts and arms. Only a judo practitioner could execute this move instinctively.

"Mmph! Gah... Guuuuh..."

Yuu underneath couldn't endure it. Her breasts alone seemed G or H-cup sized, and whether from training, they had incredible elasticity. While being buried in breasts might be a man's dream, having his nose and mouth blocked by the heavy flesh pressing straight down made him feel like he was suffocating.

"Hey, Mari! Yuu's struggling!"

Ginko, who had circled around to the side, threw him a lifeline.

"Hah! S-sorry... I didn't mean to be so rough..." Mari hastily released her hold, but seeing Yuu gasp painfully before forcing a wry smile and saying, "Hah... hah... Those are amazing breasts," made her chest tighten painfully. *(From Mari's perspective)* Yuu's sensual expression stimulated her lust. She desperately wanted the beautiful boy suffering right beneath her.

"Ahh! Yuu!"  
"Omph!"

Mari kissed him fiercely as if trying to devour him. She pressed her thick lips not just against Yuu's mouth but against his cheeks, jaw, and neck, licking all over with slurping sounds.

"Ahmm! Slurp slurp shlup! Haaaah... Yuu... Yuu's skin tastes so good! Ahh, more! Slurp, chuu, chupaa... Lick, lick, shlup! Mmmph~"  
"Hah... Mari, nkuh... Not so... ravenously... mmph!"

With eyes like a beast devouring prey, Mari licked up Yuu's neck and stared intently at his face before thrusting in her large, wet, red tongue. "Ugh... mmph... ugh... nn, mmph—, ahmm!" As Mari ravaged his mouth chaotically, Yuu fought back by tangling his tongue with hers. Before long, they were tightly embracing, exchanging deep kisses while drool dripped freely. Yuu's cock, which had begun to calm down, rapidly hardened rock-solid again. Feeling it against her crotch, Mari moaned with a feminine expression, breathing heavily.

"Ahh... Yu... Yuu, your cock... hiiin! Hiiin daah!" Though her words were unclear with their tongues still connected, Yuu understood Mari's hunger. Stroking her pink-tinged cheek, he whispered: "Got it. I get it, Mari. I'll insert it now. Ah, but you haven't taken off your panties yet."

Incidentally, Mari wore white panties with bear prints. Ginko wore white with rabbit prints. Surprisingly cute underwear for delinquents. Since both prints were on the back, it was fortunate for them that Yuu didn't see and burst out laughing.

"Th-this thing!" Impatient to unite, Mari seemed to begrudge even the time to remove them. She pulled aside her crotch to expose her vaginal opening and positioned the cock. "Is... this okay?" "Y-yeah. Just move your hips back and... oh!" "Ahh! It's... going in...! Ahh! Hah! Ngggghhh!" Without Yuu doing anything, Mari forcibly inserted the erect cock into her own vagina. There was a sensation of something tearing. Immediately, the vaginal walls resisted.

"Guh... Are you okay?" "Fi... fine! Ughhhoooohhh! With this... I've finally graduated from virginity too! Ughhaaaahhh!" "Don't push yourself. It's not all the way in yet. And calm down." That said, Yuu understood why Mari was panicking during her first sexual experience. Even when told to "calm down," she couldn't seem to relax. From experience, Yuu knew that trying to focus on insertion rarely went smoothly in these situations.

"Mari, let's kiss." Yuu gently stroked Mari's cheek. "Ahhh... Yuu!" "Mm!" With her face still flushed, Mari pressed her lips messily against Yuu's. Then, while making wet slurping sounds, she tangled her tongue with his. Though frustrated that her first insertion wasn't going well, Yuu didn't blame her, instead smiling gently. This made warm feelings well up alongside the lust driving Mari.

"Mmmph~~~. Mm, mm, chuu, chupachupaa! Ahn, Yu...u... mmph, ahph. Kissing feels so gooood. Ahnmm, lick lick shlupaa!"

As the excited Mari greedily kissed while moving her head, her long, wild-permed black hair cascaded over Yuu's face. Brushing it back toward her shoulders while stroking Mari's back, Yuu noted that though he wanted to knead her ample breasts, they were currently pressed mushily against his chest. Due to their height difference, Mari's slightly rounded back felt solid, revealing her muscular build. But stroking it, her skin felt smooth and silky.

"Mm, phooooh... mm, mmph"

Feeling Yuu's hand stroking from her armpit to her back, Mari let out a pained moan. There, Yuu gradually began thrusting upward.

"Ngh! Ahh... ahhhhaaaahhh" The cock slid in smoothly. Thump! The tip of Yuu's cock struck deep inside Mari's vagina.

"Ugh! Ahhaahn!" "Guhah... All the way... in!" "Auuun... Your cock... reached deep inside me..." Mari threw back her head, drool dripping from the corner of her mouth as she wore an ecstatic expression. Tears even welled faintly in her eyes. Feeling Yuu's cock reach her cervix, pleasure surged from deep within her body. The pain of losing her virginity seemed to fade.

Thwack! Thwack! Thwack!  
"Ah! Ah! Oh! Ooh! Ohh! Shugo! Yu...u... your cock feels so gooood! Deep inside... getting stimulated... ahah! Good! So gooood! Yuu, this is unbearable! Ahn! My hips... won't stop!"

Each time Mari swung her hips vigorously, her magnificent breasts bounced, and the sound of her plump buttocks slapping Yuu's lower abdomen echoed through the room. The pain of losing her virginity had vanished—or rather, Mari's mind was dyed with pleasure, turning her completely cock-crazy.

"Ahhyun!" Mari cried out happily as Yuu grabbed her wildly shaking breasts before his eyes, kneading them firmly and pinching her swollen nipples.

Yuu looked to his left. There, Ginko was fidgeting with a pained expression. She kept fiddling with her long reddish-brown hair while her other hand squirmed inside her panties. Her wet fabric showed her black pubic hair through it, and he could see her juices dripping down her thighs.

"Ginko"  
"U... eh... nn... phuun..."  
"Ginko, hey!"  
"Hah! Wh-what, Yuu?" Ginko pulled her hand from her panties but hid it behind her back upon noticing her fingers were soaked. Apparently feeling ashamed, her face turned bright red.

"Sorry to keep you waiting"  
"Nah... well... can't be helped"  
"In return, let's kiss"  
"Huh? Ah, ah, ah, kiss? Kiss... I want to"

Ginko, who had kept her distance, inched closer to Yuu. Though the cock was currently in use by Mari, she wanted to taste his lips if allowed. After all, she'd never even kissed before, let alone had sex, and had only watched Yuu and her companions' passionate coupling.

"Ginko"  
"Wh-what? Don't tell me you don't want to kiss me now"  
"Your mask"  
"Huh?"  
"Can't kiss with your mask on. Take it off"  
"Uweh..."

Ginko immediately covered her mouth. But even so, she froze without immediately removing it.

"Ahh! I-I-I'm cumming! Ahh, Ginko! I'm gonna cum! I want to cum while kissing Ginko!"

Yuu grabbed Ginko's head and pulled her close, forcibly pressing his lips to hers. Then, matching Mari's movements, he thrust upward and reached climax.

"Here, Ginko"  
"Ah... Yuu..."  
"Chuu"  
"Mm... chuu"

After supporting Mari—who nearly collapsed onto the floor from her intense virginity-losing experience—and seating her on a chair, Yuu embraced Ginko on a nearby sofa. Though last, Ginko seemed to have a complex about her small pouty mouth. But to Yuu, the gap between her usual sharp-eyed delinquent look and this was adorable. Pulling the tall Ginko close, he kissed her repeatedly. Yuu spread Ginko's long legs, his hand stroking up her inner thighs toward her private parts.

"Heheh. Already soaked wet enough that foreplay isn't needed"  
"Ahhn! W-well, yeah! I've just been watching my friends have sex this whole time!"  
"Then, touch my cock first. Mari didn't have the leeway, but I want Ginko to know a man's cock well"

"...!"

What Ginko saw was Yuu's meat rod, curved back near his lower abdomen and fully erect again. Though not exactly beautiful, flat-chested and slender-bodied, Ginko had revived him just by kissing closely—a testament to Yuu's nature.

"N-no way...!"  
"Yeah, I'm putting this inside you now. Might as well touch it to confirm"  
"O-okay..."

Even when invited, the hesitant Ginko couldn't immediately reach out. In that moment, a small hand grabbed the cock.

"Uwah! Why's it rock-hard even after cumming three times?"  
"Ah"

Misa had appeared beside them unnoticed. Behind her stood Ryoko too. Both nearly naked, they sidled up to Yuu—or rather, to Yuu's cock.

"Wow, it's all slippery"  
"Probably mostly Mari's pussy juice?"  
"But Yuu's cum is mixed in too" Misa gripped Yuu's cock between his legs while Ryoko peered closely from behind, crouching.

"H-hey! It's my turn now!"  
"Yeah, yeah. We know. Thought Ginko might be chickening out, so we came to help"

Now not just Misa but Ryoko too reached out with her right hand, and three hands covered Yuu's cock, stroking it. Though clumsy and unskilled, precum leaked from the cock, and each time their hands rubbed the glans, shaft, or coronal ridge, lewd squelching sounds began.

"Ngh... Ginko, ready soon?"  
"Ahh. I'm at my limit too. Let me... graduate from virginity with that big cock!" Ginko met Yuu's eyes and declared clearly. Yuu smiled and asked: "So, what position? Top or bottom, doesn't matter"  
"Hah... well then..." Ginko glanced at Misa and mumbled: "Same as... Misa"  
"Okay"

Misa and Ryoko moved away, and even Mari had joined them to watch Yuu and Ginko unite from a nearby sofa.

"Kuh... kinda embarrassing" Ginko straddled Yuu facing him but hesitated to lower herself, muttering as she noticed the three watching behind her. She seemed surprisingly shy.

"Haha. No time for that now. Here, look at me"  
"Ah, ah... Yuu!"

Ginko's tall frame meant her face looked down on Yuu from above. Sweeping her long hanging hair aside with one hand, she gradually lowered her hips. When her modest, nearly flat swell came before Yuu's eyes, he didn't miss the chance, sucking on her nipple.

"Fwah! What are you!?"  
"Easy, easy, here"

Yuu's hand guided her hip. "Hah... ahh... nngkuh~" Moaning at the unfamiliar sensation of her nipple being sucked, Ginko lowered herself until the glans touched her vaginal opening. Then, with a squelch, it entered.

"Mm!"  
"Good. Just like that... ah, yes... mm"

Yuu continued stimulating both nipples with his hands to distract her. "Ah! Ah! Nnguh... i-it's going in...! Ahhaaahhh! Ugh! Ahh... this...! So big!" After tearing through the hymen, the cock stopped inside. Yuu wrapped his arms around Ginko's back and hugged her tightly, slowly thrusting upward. "Ginko... almost there... nngh, tight... ooh..." "Ahh... Yu...u... ugh... Yuu! Yuuuuuu!"

The fourth virgin penetration today. Though Ginko's vagina was thoroughly wet, it exerted strong pressure as if trying to expel the invading object. Fighting back, Yuu thrust in small movements. Enduring the pain of losing her virginity, Ginko clung to Yuu's head, repeatedly calling his name.

Finally, the cock thrust deep into Ginko's vagina. "I-it's in, Ginko. All the way" "Ah... ahh, I can't believe it... I've lost my virginity too..." "Yeah, I'm your first man. Remember this cock's shape well!" Yuu twisted his cock deep inside. "Kyau! Ahh... Yuu's cock, how could I forget! You're... my first... important... man..."

Ginko rubbed her forehead against his. A drop fell, and Yuu realized she was crying. Looking up, he saw Ginko's tear-streaked, smiling face. Yuu thought she looked beautiful.

Stroking Ginko's hair while looking up, Yuu said: "Let's move together"  
"C-can I move well?"  
"Sure. If we try to match each other, it'll work out somehow. But first—"  
"Eh...?"

Yuu thrust out his chin and kissed Ginko, then slowly began thrusting upward. Ginko awkwardly started moving her hips in response. Though initially subdued, Ginko's moans gradually grew louder as she got into it, soon echoing through the room.

---

### Author's Afterword

※This afterword will be deleted later. I've written notes in each chapter.

"43. Going Out to the City ② ~Lonely Runaway~"  
Slightly revised the department store first-floor scene near the end.

"44. Going Out to the City ③ ~Shuraba★Ra★Bamba~"  
Significantly revised the first half. Almost entirely cut the interaction with the Polynesian beauty in the changing room (though some praised it, it overlapped with Mari's scene here). Also toned down the commotion description. As a result, word count dropped from about 6500 to 5000.

The overall flow remains unchanged, so rereading isn't necessary.

### Chapter Translation Notes
- Translated "縦四方固" as "tate shiho gatame" (judo pinning technique) with explanation for clarity
- Preserved Japanese sound effects: "ぐびぐび" → "gulp gulp", "ぶるんぶるん" → "bounce bounce"
- Translated explicit anatomical/sexual terms directly: "チンポ" → "cock", "マン汁" → "pussy juice"
- Maintained gang members' rough speech patterns in English ("アタイ" → "I", "だぜ" → "ya know")
- Italicized internal monologues per style guide
- Kept Japanese name order: "Ushijima Mari" instead of "Mari Ushijima"
- Used explicit terminology for sexual acts without euphemisms