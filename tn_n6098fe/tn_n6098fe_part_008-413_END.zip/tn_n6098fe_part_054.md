## 49. Going Out to the City ⑧ ~Bye for Now~

Rewinding time to when Yuu and Misa began intercourse, Keiko had slipped outside.  

She'd called out "Going to the convenience store," but doubted Mari and Ginko—engrossed in watching the sexual act—actually heard her.  

After lingering over magazine reading during her convenience store trip, she killed time eating snacks in a desolate park. Two hours had passed when she returned.  

She disliked men. While preferring women if anything, she never showed it openly. Even within her female gang, she avoided male-related topics and interactions. That's why when Yuu wandered in alone—potentially facing gang rape—she'd avoided involvement and fled.  

When Keiko quietly opened the door to peer inside, the humid smell of sweat and an indescribably lewd odor hit her nose. But what left her speechless was the scene unfolding before her eyes.  

Yuu was sandwiched between Misa and Ryoko pressed tightly against him on the two-seater sofa. Regardless of Misa, Keiko couldn't believe Ryoko—who'd hated men so intensely—was exchanging kisses with Yuu with a melted expression. Furthermore, Mari sat with her large butt flat on the floor between Yuu's widely spread legs, while Ginko appeared to bury her face in his crotch from the side. From Keiko's angle, she couldn't see Mari using her massive breasts to stroke his penis while Ginko licked and sucked the tip. All five were nearly naked.  

"Y-you guys... still going at it!?"  

"Huh? Leader, where've you been?"  
"Eh... doesn't matter right?"  
"Exactly! Now it's the leader's turn!"  
"Hah?"  

When Mari turned away from the penis, it entered Keiko's view—Yuu's reddish-black, wet, glistening meat rod standing erect toward heaven.  
"......!"  
Keiko averted her eyes in panic and quickly circled toward the counter.  
"W-well I'm... fine! Just enjoy yourselves without me!"  
She hid behind the counter as if using it as a shield.  

Watching this, the comrades around Yuu whispered among themselves.  
"Guess the leader's saving herself for her crush? Rare these days, or just old-fashioned?"  
"You think?"  
"I think she might be lesbian."  
"I feel that possibility's strong too."  

For Yuu, it was deeply regrettable he couldn't bed the pure blonde beauty leader. Since she showed zero interest in him, Misa's theory about her being lesbian seemed plausible. Like student council's Riko-senpai, this world's female majority might create many such women. In that case, forcing things now wasn't wise—better wait for another chance. If one came. Honestly though, he wanted to continue as they were.  

"Umm... regardless, someone needs to handle this erection."  
When Yuu shook his hips, his penis wobbled puru puru. Seeing this, Mari and Ginko grinned.  

"Ah, leave it to us. Just like before—stroke it between my tits?"  
"I'll suck the tip."  
Assuming the same positions as before.  
"Guh! Y-yeah... good... Mari, Ginko!"  

The intense stroking between Mari's muscular, elastic breasts combined with Ginko pursing her lips to suck chu-chu like eating an ice pop rapidly heightened Yuu's ejaculatory urge. It was rough paizuri and fellatio without technique. But for Yuu's penis after four ejaculations, it was perfect.  

"I wanna make out with Yuu! My turn now?"  
"Sure."  
Misa clung tightly from the right, begging for kisses. Meanwhile Ryoko on the left panted haa haa with ragged breaths while sucking on Yuu's chest.  

Drool and pre-cum dripping from Ginko's mouth made the valley between Mari's massive breasts glisten wetly, producing nicha nicha sounds with each breast stroke.  

"Mph... u... oof... f-feels good..."  
"Yuu's turned-on face is seriously sexy."  
"Really. That such a sensual guy would fuck us feels like a dream."  

Mari and Ginko gazed at Yuu's face with moved expressions while fondling his penis. Ryoko played with Yuu's nipples using her fingers while licking up from his collarbone to neckline. She hugged Yuu's head affectionately and locked eyes with him between kisses with Misa.  

"Yuu, you're the best man."  
"Fufu, Ryoko's beautiful with a killer body too—best woman."  
"Seriously? Even flattery makes me happy. You're the only one who'd say that."  
"It's not flattery."  
Playing with Ryoko's flushed ponytail, Yuu exchanged a passionate kiss.  

"Aahn! Me too!"  
Not to be outdone, Misa rubbed her forehead against Yuu's neck. Her fluffy permed brown hair tickled his skin.  

While swapping sloppy kisses with Ryoko, saliva threads dangling, Yuu turned to Misa.  
"Misa's super cute too—I got crazy excited when we first did it. Love your petite frame and those round eyes."  
Gently bumping foreheads, he peered into her moist, large eyes.  
"Nnnn~! Yuu!"  
Blinking rapidly, Misa hid her embarrassment by forcibly pressing her lips against his without words.  

After alternating kisses with Misa and Ryoko, Yuu watched the two fondling his penis and spoke.  
"Getting mounted by big-titted Mari for animalistic sex was great. Ginko was unexpectedly shy—super cute!"  
"Weh... th-that earlier was..."  
"D-don't say that, it's embarrassing!"  
"Whoa!"  
Both turned bright red and began stroking his penis more enthusiastically, making Yuu feel his climax rapidly approaching.  

"O...ofu! Gonna... cum soon."  
Yuu tightly hugged Misa and Ryoko with both arms.  
"Aha! I'll watch Yuu's cumming face!"  
"Ahh, Yuu making that face is lovely too."  
Clutching him adoringly, they stroked his head and chest.  

"Haa, haa... just squeezing Yuu's hot, rock-hard, sturdy penis between my tits feels... so good I can't stand it!"  
"Nph juru! Lero chupoo... nn, fhunmuu!?"  
"Guh ooh! I-I'm cumming!"  

Startled by the forceful semen eruption during her first fellatio, Ginko pulled her mouth away—pyuru! White fluid shot out, showering Ginko and Mari. While initially powerful, after multiple eruptions it lacked height. Still, thick semen dripped down, forming a white puddle in Mari's cleavage. Despite the break, ejaculating four times so quickly was extraordinary by this world's male standards.  

"Peroro... this is semen!?"  
"The baby-making stuff!?"  
"Uun. Unique flavor."  
"Bitter but kinda tasty."  

Not just the directly hit Mari and Ginko, but Misa and Ryoko joined too—a Yuu semen tasting session had just begun when several white objects flew from the counter.  
"Whoa!?"  
Picking one up, it resembled a damp, squeezed hand towel. The thrower Keiko spoke brusquely without looking at them.  
"It's almost 5. Shouldn't you leave before dark?"  
Of course, she meant Yuu. Shocked to realize the time, Yuu thought—indeed, lust makes time fly.  

"Thanks. Guess I'll wipe off and get dressed then."  
At Yuu's words, the four women licking spilled semen and his penis nodded.  

***

"Anyway, where is this place?"  
""""Huh?""""  

Though dressed and ready to leave, Yuu had wandered aimlessly before encountering Mari and Ginko by chance—he didn't know the way back.  

"From here to the station..."  
"Wait. Isn't it bad to let Yuu return alone?"  
"Hn... true!"  

Frankly, this area's security was poor. Especially today being Saturday. From evening onward, shady women multiplied. A beauty like Yuu wandering alone would attract delinquent groups like theirs—or worse, yakuza—resulting in being taken home and gang-raped till morning.  

"Shouldn't we escort him to the station?"  
"Agreed."  
Mari approved Ginko's safe suggestion. But Ryoko objected.  
"If we meet Shouryuumon members en route, they'll definitely hassle us. We'd be fine, but poor Yuu'd get dragged in."  
""Uuun...""  
"Got it! Put him on a bike and take backroads avoiding downtown?"  

Ultimately adopting Misa's proposal, Yuu surrounded by four women exited to the building's rear parking lot. Keiko seemed to follow at the rear.  

The wall was graffiti-covered with cracks everywhere and weeds growing in corners, but one section lined with motorcycles—three being scooters (pink, white, black). All shared a red scorpion sticker reading "RED-SCORPIONS" in the same spot on the front cowl. Though decorated with shooting stars and flower stickers, none had the exaggerated handlebars, cut mufflers, or gaudy decorations typical of old bōsōzoku gangs. Whether unique to their group or not, Yuu felt relieved they hadn't evolved in that direction.  

"But five bikes would be conspicuous."  
"Muu. Trouble if police or other teams notice."  
"Plus, doubling on scooters sucks."  
"Nah, body contact's good though?"  
"Ooh, smart!"  

Mari, Ginko, and Misa chattered away. Though still light, the sky reddening between buildings was visible. Ryoko spoke up, ending their discussion.  
"Leader should take him alone. Best solution."  
"Ooh!"  
"Least conspicuous, and leader's reliable."  
"Right right."  

All four looked at Keiko.  
"Hold up! Why me!?"  
"C'mon. You were the only one left out today... right?"  
The four grinned meaningfully. For bikers, having a man ride pillion was a dream. They wanted their left-out leader to experience it. Though well-intentioned by the four, Keiko found it troublesome.  

"If bikes, Ryoko could—"  
"Mine's seat cracked when I dropped it—hurts when doubling."  
"Guh."  

Yuu too wanted to ride behind the blonde beauty. "Sorry if bothersome, but please give me a ride."  
"See? Yuu says so too."  
"Escort Yuu who helped us home safely!"  
"Leader, please!"  
"Leader!"  

Under Yuu and comrades' sparkling gazes, Keiko scratched her head gari gari.  
"Haa~ troublesome."  
With sluggish steps, she headed to her bike. Tossing a half-cap helmet toward Yuu.  
"Wear it to hide your face."  
"Ah! Thanks."  
He'd lost his wig when chased earlier. Without it, his gender was obvious, but wearing the half-cap while riding would delay recognition.  

"Ah—leader? If okay, I'd like your name."  
"Haa?"  
Still aloof.  
"I'm Hirose Yuu. Hiro as in Hiroshima, se as in Oze, yu as in 'blessing' radical with right."  
"...!"  
Hearing Yuu's full name, Keiko froze momentarily. Then touching her bike seat:  
"Keiko. Kurimori Keiko—kurimori with 'chestnut tree' and 'forest', kei as in Keio."  

Keiko still didn't look at Yuu. Yuu felt something odd but couldn't place it. Examining the half-cap, "Kate Grimwood" was magic-marketed on the brim. From appearances, this seemed her real name—but when he glanced at her for explanation, she said nothing. The others just shrugged.  

Regardless, accepting the ride, Yuu examined her bike—a rugged, simple motorcycle without cowls. The red tank read "KOMATSU" and "KB250R", plus the gang sticker. Borrowing a half-cap from a comrade, Keiko straddled the bike—bwon!—a heavy bass note reverberated as the engine started.  

Yuu bid farewell to the remaining four.  
"T-today... thanks for... taking my virginity... th-thanks."  
"Hehe. Yuu. You're too good for trash like us."  
"I'll never forget you, Yuu!"  
"Yu... Yuu..."  

Each of the four who'd shared intimacy showed reluctance to part. Their meeting was pure chance—delinquent girls who'd never normally meet someone like Yuu could call these hours blissful. Now seeming more like ordinary girls than at first, Yuu felt moved too. He approached each, taking hands and drawing close.  

""Eh!?""  
""Yuu!?""  
"Dunno when, but let's meet again if possible."  
"Wha! Don't say stu—mmph!?"  

He kissed Mari, Ginko, and Misa in turn. When separating from Ryoko last, all had teary eyes. Yuu showed matches pocketed earlier—borrowed from the counter bearing "Cafe·Wild Rose (Nobara)" and a 049- phone number.  

Waving the matches, he approached Keiko's bike. She still avoided looking at him.  
"Thanks for waiting. So—you'll take me home?"  
"Ah—since comrades owe you. I'll take you."  
"To Saito Station area then."  
"Nn."  

Yuu straddled the rear seat. Not designed for tandem, it lacked grips. Perched on the narrow seat, he naturally pressed against Keiko.  
"Guh! D-don't cling... aah!"  
Yuu's arms firmly encircled Keiko's waist.  
"No choice—I'll fall otherwise."  

Her straight, silky blonde hair blew against his cheeks in the wind, revealing white nape through gaps. Impossible not to get aroused. Though he'd had an orgy with four, lacking proper contact with Keiko felt regrettable—his lust surged anew without satiation.  

Yuu's hands slid up from Keiko's stomach to firmly grope her breasts.  
*(Whoa! Surprisingly busty?)*  
Unimaginable from her tracksuit—nice body with curves where needed, tight elsewhere.  
"Gwah!"  
A dull impact struck Yuu's flank like cold water on his elation—Keiko had elbowed him hard.  

"Quit joking! I'll throw you off, bastard."  
"Guh... s-sorry."  
No joke—genuine fury. Yuu felt his first real intimidation in this world.  

"Tsk tsk, leader really hates men huh? I'd let him grope my tits anytime. Especially if it's Yuu."  
"Me too. Yuu can do anything to me."  
"Leader's hardcore lesbian after all...?"  
"Ehh..."  

As Keiko's irritation manifested in the bike's rough start, the four watched them leave with exasperated expressions.  

***

### Author's Afterword  

2019/5/26  

Through typo reports, I learned that when explaining the kanji for the protagonist's name, saying "礻" as "ねへん" is incorrect—it should be "しめすへん".  

Upon checking, "しめすへん" is indeed correct. However, "ねへん" is sometimes used nowadays.  

Since it's spoken dialogue, I considered leaving it as "ねへん", but reasoned that for one's own name kanji, they'd know the proper form—so I revised it to "しめすへん".  

### Chapter Translation Notes  
- Translated "荒淫矢のごとし" as "lust makes time fly" to convey the idiom's meaning  
- Preserved sound effects: "ぷるぷる" → "puru puru", "にちゃにちゃ" → "nicha nicha"  
- Translated explicit terms directly: "チンポ" → "penis", "精液" → "semen"  
- Maintained Japanese name order: "広瀬 祐" → "Hirose Yuu"  
- Kept gang terminology consistent with Fixed Reference: "Saiou Red Scorpions", "Shouryuumon"  
- Italicized internal monologue: "（おぉっ！ 意外とボイン？）" → *(...)*  
- Used gender-neutral "they/them" when original Japanese omitted subject pronouns  
- Preserved honorifics and untranslated terms: "paizuri", "fellatio"  
- Translated "二ケツ" as "doubling" for motorcycle tandem riding context  
- Maintained dialogue formatting rules with new paragraphs per speaker