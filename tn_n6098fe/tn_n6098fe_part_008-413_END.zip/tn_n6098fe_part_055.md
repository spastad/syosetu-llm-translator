## 50. Going Out to the City ⑨ ~Suddenly~

After stopping the bike, Keiko went out of her way to escort me to the apartment entrance, but she hurried away after ringing the intercom and before Kanako and Touko came out.

She hardly responded to conversation during the trip either, seeming to really dislike being pressed against by Yuu.

While waiting alone, Yuu wondered if she might be lesbian after all. *I'd like to sleep with her someday*, he thought.

Though Kanako and the others found it suspicious that he was alone and returned home later than planned, Yuu lied that a senior's parent from high school had given him a ride but left early because they were busy.

However, in the elevator, he heard Touko mutter softly from behind him, "I smell women."

He had wiped his genitals and body with wet wipes, but perhaps because he had been intimate with four women, or because he had been pressed against Keiko on the bike ride, the lingering scent still clung to him.

Yuu turned to look at Touko.

Her eyes, partially hidden by her bangs, seemed to glance at Yuu for a moment before hurriedly looking away.

Raising his left index finger to his own lips, he extended his right hand and patted Touko's head at just the right height.

"Kkh!"

Her black hair didn't seem particularly well-maintained, but its texture was good, reflecting the ceiling light to create a halo, and it felt smooth to the touch.

As Yuu stroked her, Touko's earlier displeasure vanished, her cheeks flushing as she narrowed her eyes contentedly.

*Chin*, the elevator seemed to arrive at the 11th floor.

When Yuu removed his hand, Touko looked up at him regretfully with upturned eyes.

"Next time, okay?" he said softly, and Touko nodded repeatedly.

"We've arrived... is something wrong?"

"Ah, no, nothing. I was trying to make a funny face to make Kujira-san laugh, but it didn't work well."

"Ah, Shi... she's quite mentally strong like that."

"Really? Would it work on you, Kitamura-san?"

"W-well... I am the leader after all, I don't laugh that easily!"

"Then maybe I'll try it in the car next time. If I can make both Kitamura-san and Kujira-san laugh, what will you do for me?"

"Umm..."

"Huh...?"

Walking down the hallway, he tapped Kitamura's arm as she started thinking seriously. It wasn't the soft, squishy feel characteristic of women but the resilient elasticity of well-developed muscles.

"Fufu. You can think about it later."

"Y-yes."

Though Yuu often chatted casually with Kanako and Touko while they guarded him, he thought it might be nice to have more physical contact with these two attractive women.

After parting from Kanako and Touko, Yuu quietly opened the door leading to the Hirose family's living area without making a sound.

In this era, both schools and companies finish at noon on Saturdays. It's what they called "half-holiday" in Yuu's student days.

Though recently, as part of countermeasures against low birthrates, there's been discussion about introducing a two-day weekend system to increase time for men and women to spend together and boost the leisure industry's economy.

Eventually, Saturdays will likely become full holidays, just like in his original world.

Until now, when Yuu stayed late at the student council on weekdays or Saturdays and returned late, Martina would worry since she came home early.

Though her real purpose was simply to have physical contact with Yuu, her plans were foiled when Yuu wasn't there.

For that reason, Yuu was concerned whether Martina had returned home early. Her shoes didn't seem to be at the entrance, but he peeked in quietly to check.

The hallway was silent, and beyond the door to the living room was dark.

Martina apparently hadn't returned home yet, and Yuu breathed a sigh of relief.

*(Does it still smell?)*

He opened his collar and sniffed himself.

Today he had been running around since afternoon and had sex with four women.

Wiping with wet wipes apparently hadn't completely removed the sweaty odor.

He couldn't tell himself, but perhaps only Touko could detect the female scent.

No, Martina might notice too.

What expression would she make if she knew her beloved son was sleeping around with women?

Knowing her, she probably couldn't stay calm.

Not wanting to cause unnecessary worry, Yuu decided to take a shower before Martina returned.

Just as he stepped forward to put his shoulder bag in his room, he noticed something.

His room door was slightly open.

*(That's strange)*

He was sure he closed it properly when leaving this morning.

Since Yuu reached adolescence, Martina had stopped entering his room without permission when he was out.

On weekdays, Akiko would come to clean, but since it was Saturday, she shouldn't be here.

That meant only one person could have opened it.

Just in case, Yuu crept silently toward his room door.

For some reason, he felt tense.

When Yuu drew near the door, intermittent sounds of a woman's agonized, painful moans leaked from inside.

"Nngh... nngh... ahn... Yu... uu... there... feels good. More, touch me more... Ahfuu... When Yuu touches me, it feels sooo good. Ah, ah... nnnn~~~!

Soon, I want your peepee!

I'm gonna... eat Yuu's... big, hard peepee with my pussy, you know.

Aha, can't you hold back either, Yuu?

Ufufu, don't rush. Big sis will be gentle with you.

Ahn! Yuu's peepee is amazing... more, thrust deeper. Yes, feel good inside big sis's pussy... nngh, nngh, nnnn! Cum, give me lots... l-let's make a baby."

Though Yuu hadn't heard it since being reborn, it was unmistakably his sister's sweet voice from his memories.

Gradually, he could hear wet *guchu guchu* sounds.

He didn't know whether she was using her fingers or a vibrator, but it was clear that in his sister's mind, a fantasy world was unfolding as she masturbated using Yuu as material.

Two thoughts battled within Yuu.

One was to open the door and thoroughly observe his sister's lewd behavior.

Normally, this would be an incredible weakness to exploit.

But the women in this world were different from his original one.

Not only would she be ashamed, but she might turn the tables and attack Yuu right then.

Not that Yuu had any reason to refuse now.

Though it would be incest by blood relation, Yuu himself had almost no sense of Elena being his blood-related sister.

The concern was not knowing when Martina might return.

If she saw Yuu and Elena together, wouldn't she be shocked?

The other option was to leave without being noticed.

He could keep secret that Elena had been masturbating in his room and use it later.

Though he could only approach her at night since daytime was impossible.

Just as Yuu, feeling fatigued and wanting to wash off, was about to choose the latter option, Elena's moans intensified further. Just as he recalled being pinned down by Mari earlier that day, an event from about half a year ago flashed through his mind.

It was the night before last Christmas. Probably around midnight.

Yuu, lying on his back, sensed someone's presence and called out groggily.

Simultaneously, he realized cold air was hitting his bare skin and something felt strange on his genitals.

When he lifted his head to look at his body, not only was his pajama front completely open, but his pants and underwear had been pulled down to his thighs.

And someone was crouching between his legs.

Though he couldn't see the face clearly in the dark, the long hair, slender silhouette, and whispering voice were unmistakably Elena's.

In other words, while he slept, Yuu was being assaulted by Elena.

At that time, Yuu felt something close to fear toward Elena, who persistently tried to make contact, and avoided her thoroughly.

But the more Yuu ran, the more obsessed Elena became about making contact.

Though Martina would intervene and she'd temporarily back down, she'd always revive after a while.

Eventually, Yuu started locking his door when sleeping, ensuring only Martina could open it.

That night, he must have locked it too, but perhaps he forgot to lock it again after waking up to use the bathroom.

He'd heard through his mother that Elena would be at a school Christmas party that night, and since she apparently had a boyfriend, he'd carelessly assumed she'd return late.

She must have seized that opportunity to invade.

Elena seemed to have discarded her clothes and was in her underwear, touching herself between her legs while stroking Yuu's dick.

She had just removed her panties and seemed fully intent on joining with him.

At that moment, Yuu panicked and resisted, struggling with Elena as she tried to cover his mouth and hands.

Eventually, Martina, awakened by Yuu's voice, stopped Elena's actions.

Yuu trembled wrapped in his futon.

Martina couldn't hide her anger.

Seeing this, Elena retreated to her room with a lifeless expression and shut herself inside.

Recalling that memory, Yuu somehow lost his motivation and silently backed away.

If genders were reversed - if a middle school girl was assaulted by her older brother while sleeping - it could cause trauma. She'd probably hate living under the same roof.

Though the current Yuu wouldn't be troubled by it.

He had originally planned to approach his sister when the opportunity arose.

Realizing Elena liked him this much, he reconsidered that it might be okay to take forceful measures.

As Yuu entered the bathroom, Elena moaned even more intensely before only rough breathing could be heard.

Then she whispered softly.

"Fu... fu... That old hag housekeeper who seduced Yuu... once I get rid of her... th-this time I'll..."

After Yuu finished showering and came out, Martina seemed to have just returned home.

Wearing sweatpants as pajama substitutes and only a T-shirt, Yuu went to greet her.

"Mom, welcome home."

"Ahh! Yuu-chan! I'm ho— Really, you can't go around dressed so lightly!"

"Ahaha..."

Though she often told him to wear underwear, Yuu never showed signs of changing, and Martina looked exasperated.

Yet she kept staring at Yuu's chest area.

Martina, who had opened the door, smoothly approached Yuu head-on and spread her arms.

"Ahh, I'm exhausted! It was supposed to end after noon, but an emergency meeting came up. And it was so long~.

Hey, replenish me with some Yuu-chan energy after my tiring work!"

"Haha. Sure. Good work today too."

Her colorful open-collar shirt with pink and purple hydrangeas stretched over her prominently protruding chest.

When Martina hugged Yuu tightly, the overwhelming sensation of her plump, abundant breasts came through.

"You took a shower? You smell nice."

"Ah, I sweated a lot today since it was hot..."

Taking a sudden shower because he cared about body odor at his age was better than smelling like women.

Indeed, Martina only savored the scent of Yuu's skin with deep sniffs, showing no suspicion.

Meanwhile, Yuu buried his face in Martina's abundant black hair near her neck, inhaling her scent.

He fully enjoyed the slightly subdued citrus fragrance.

Combined with the sensation of her breasts, his lower body threatened to react, so he tried recalling today's lesson content in his head.

Suddenly, Yuu remembered he wanted to talk to Martina about the housekeeper Akiko.

Housekeepers were typically on one-year contracts, and Akiko's would end in June, but Yuu really wanted to extend it.

If so, it would be better to start the extension process now.

"Mom, I need to talk."

Yuu slightly pulled away.

Martina looked at Yuu suspiciously.

"Talk?"

"Yeah. About housekeeper Akiko-san."

"Ah... Th-that reminds me, I just remembered something I needed to tell Yuu-chan too!

Let's go to the living room.

Oh yes, for dinner, since I was late, I bought sashimi. You like it, right?"

"Ooh! Awesome!"

Martina's mother apparently had no custom of eating raw fish in her home country, but she grew to love it after living in Japan, and Martina was influenced by that.

Naturally, Yuu loved it too.

Martina herself wasn't very good at cooking.

Yuu, having lived alone, had a slightly wider repertoire and could cook safely.

So usually, weekend dinners were made by Yuu or both of them together.

On the way to the living room, Martina stopped at Elena's door.

She knocked but got no response.

She seemed to call out at least once daily, but getting no reaction was normal.

Only Yuu, who had heard the masturbation sounds earlier, wore a complicated expression.

The two happily prepared dinner together, served rice and miso soup, arranged side dishes, and sat around the table.

Normally, Elena would join them there.

When would they ever eat together as three?

Though holding a shadow in their hearts, Yuu and Martina smiled at each other.

About five minutes after starting to eat, Yuu spoke up.

"It's about Akiko-san. Actually, I—"

"Um, it's hard to say, but—"

They both started speaking simultaneously.

"Uh... Mom, you go first."

"Eh, but Yuu-chan..."

"It's fine."

Curious about what was hard to say, Yuu decided to let her speak first.

Martina hesitated slightly, then averted her eyes from Yuu and spoke in a rush.

"About the contract with Akiko-san... we've decided to terminate it early.

A new person will come starting next Monday."

"Huh?"

He couldn't comprehend what she meant.

Martina too must have appreciated Akiko's excellent work and delicious cooking.

Just as he was about to say it was ridiculous to say such a thing now, Martina continued.

"Actually, it's recent. Elena... came to me at night."

"Sis did!?"

"Yeah."

One day, when Yuu expressed gratitude to Akiko for her daily housework, she asked him to show it through actions.

When Yuu hesitated, Akiko suddenly hugged him and even stole a kiss.

While Yuu froze, Akiko greedily devoured his lips and groped all over his body.

The kind Yuu couldn't blame Akiko for her blatantly sexual behavior or tell anyone, and on another day, he let it happen again.

This was the eyewitness account Martina heard from Elena.

If this continued, Yuu would be violated by Akiko.

After seeing it multiple times and witnessing Akiko's escalating behavior, Elena made a firm decision to leave her room and pleaded with Martina to replace the housekeeper.

It was a terrible misunderstanding.

No, such facts existed, but Yuu was the willing one. The distortion was extreme.

*(So Sis was watching?)*

He hadn't forgotten about her, but since she stayed locked in her room, he might have stopped paying attention.

Yuu bit his lip at his carelessness.

But how distorted must her perspective have been?

Perhaps jealousy had warped Elena's heart.

Yet Akiko took care of Elena too.

Firing her and kicking her out was going too far.

*Gata!*

Still during dinner, Yuu set down his chopsticks and stood up.

"Yuu-chan!?"

"I'm going to talk with Sis."

"Eh?"

Yuu knocked firmly on Elena's door.

"Sis! I need to talk!"

No response; the room remained silent.

Growing impatient after repeated knocking yielded no reaction, Yuu grabbed the doorknob, rattling it as he tried to open it, but it was locked.

He banged *don don* hard on the door, but with its sturdy construction and possibly double-locked, he couldn't open it.

---

### Author's Afterword

Excluding character introductions and interludes, we've finally reached 50 chapters. We've come this far at last.

Originally, I planned to end Chapter 2 here, but since we're at it, I thought I'd continue until a good stopping point in the story.

Note: Quite some time passed between Elena witnessing the incident in Chapter 28 and her reporting it to Martina, but let's assume she couldn't speak up immediately due to being shut-in.

### Chapter Translation Notes
- Translated "おチンチン" as "peepee" to preserve childish/sexual nuance while matching English colloquial equivalents
- Rendered "ぐっちゅぐっちゅ" as "guchu guchu" for wet masturbation sounds
- Kept "半ドン" as "half-holiday" with explanation of historical Japanese work culture
- Translated "オカズ" as "material" in context of masturbation fantasy
- Preserved Japanese honorifics (-chan for Yuu, -san for others) per style guide
- Maintained original name order (Hirose Yuu, Kitamura Kanako, etc.)
- Italicized internal thoughts like *(Does it still smell?)*
- Translated explicit sexual terms directly ("pussy", "cum", "genitals") per explicit terminology rule