## Interlude 2: Elena - Part 2

### Author's Preface

This is somewhat lengthy.

I did review it before posting and toned down Elena's pervertedness a bit, but some readers might still find it off-putting.

---

  

"Elena, well... Yuu is at a difficult age. It might be better to keep some distance for now."

"No!"

"Elena! As his big sister, you should consider Yuu's feelings!"

"Ugh..."

  

Though not entirely enthusiastic, I took Sairei Academy's entrance exam at the urging of Mom and others around me and passed brilliantly. Yuu entered the local public middle school.

Our family started this new chapter, but a heavy atmosphere lingered at home.

This was because Yuu had started blatantly avoiding me.

  

My feelings of cherishing Yuu above all else hadn't changed.

Didn't Yuu say he loved his big sister too?

We're the only siblings in this world.

I know there are many half-sisters from different mothers, but since we don't live together, they're practically strangers.

Things like blood relations or not being able to marry don't matter at all.

I'm resolved to live for Yuu forever.

So why was I being avoided so much?

  

When I tried hugging Yuu after he returned from school, he'd escape.

When I sat next to him (pressed close) on the living room sofa to talk, he'd get up and leave.

When I visited his room to chat, he'd gradually become sullen and kick me out.

When I tried surprising him by getting into his futon at night, he got angry and started locking his door the next night.

  

Why had Yuu changed?

No. Actually, I knew.

He disliked me looking at him with sexual eyes.

  

Maybe it was bad that I stared at Yuu's alluring appearance after his bath.

Or maybe he heard me masturbating while calling his name in bed...

  

I seemed to have a stronger sex drive than my classmates.

I reflected that my actions had gone too far due to my overflowing lust for Yuu.

Considering Mom's words too, I thought maybe I should keep some distance.

If things calmed down, maybe Yuu and I could become close again like before.

  

  

  

  

As a second-year high schooler, since same-grade dating was now permitted, I decided to look at boys at school a little.

I was a bit curious if there was any boy who could replace Yuu.

I think I'd met some during exchange events in first year, but I had no memory of them since I wasn't interested.

So I went out with friends during breaks or after school several times.

But frankly, they were beyond disappointing.

Friends said the boys' awkward fidgeting was boyishly cute, but I couldn't agree. Yuu was way cuter!

Their looks seemed like rows of potatoes and carrots compared to Yuu.

  

A year passed, but things with Yuu didn't return to normal.

Still, I thought this was a time for patience and tried not to force contact.

Though I did occasionally borrow his freshly removed underwear for masturbation material.

I bought a drill and made a hole in the wall between our rooms to peek through.

I was careful to place it high near the ceiling and not pierce the wallpaper so it wouldn't be discovered.

Thanks to that, I could see his angelic sleeping face and changing scenes, which really helped my masturbation sessions.

  

In third year, opportunities to meet boys increased through shared classes.

For some reason, boys started talking to me more often.

After a while, I became close with one boy.

His name was Yuuki.

He had a decent face and was about Yuu's height.

He seemed to be one of the most popular boys, and I often heard his name mentioned among girls.

Most of all, I liked that his name resembled Yuu's.

He said things like, "Hirose-san isn't pushy like other girls, and your aloofness is actually appealing."

How strange.

  

Though my number one was my brother Yuu, I thought he'd be good for understanding boys' feelings at this age, and figured he'd do as Yuu's spare. So we started dating in the second term.

Some praised us as a well-matched handsome couple, but many girls who'd been targeting him were jealous.

  

That said, meeting boys outside was difficult, so it was strictly school-based dating.

Just healthy interactions like talking during breaks or eating lunch together.

That was enough for me.

Strangely, I never felt lust for any boy besides Yuu.

He seemed reassured by this too, and surprisingly, our relationship continued into winter.

  

Then came December, near Christmas.

As the annual Christmas party approached, both boys and girls became desperate to find partners.

Modeled after American high school proms, the academy's Christmas party was a major third-year event.

Though voluntary, only girls paired with boys could attend (no limit per boy, but usually 1-3 girls per boy).

Many couples who became physically intimate around this time, including the night itself, ended up marrying after graduation.

In that sense, for girls, it was an important event to showcase their achievements in interacting with boys at co-ed school.

  

As usual, I didn't really care, but thought I might go if Yuuki invited me.

However, I was perplexed by how touchy-feely Yuuki had become lately.

When we sat on a bench in the backyard, he'd say my hair was pretty or I had a nice figure while reaching out.

When I silently stared, he'd hurriedly withdraw his hand.

Then he'd stutter things like, "C-c-can I kiss you?"

I ignored him as rejection since my lips were only for Yuu.

But since he looked so dejected, I said, "My cheek is okay," and he kissed me while acting suspiciously nervous.

His heavy breathing was a bit gross.

People say boys have low sex drives, but maybe not?

If Yuu wanted me, I'd welcome it though...

  

So with some awkwardness, the night of the December 23rd dance arrived.

Third-year girls with partners dressed up and went to meet their boys in front of the second school building.

  

That day, I wore a navy blue dress Mom prepared for me.

She said it suited my fair skin.

I put my hair up with a gold necklace and hairpin.

I regretted not being able to show this directly to Yuu, but Mom took photos and said she'd show him later, so that was fine.

  

Though disappointed my dance partner wasn't Yuu, I was somewhat excited.

When I arrived at the second building, about half the boys had already been escorted to the gymnasium by their partners.

With so few boys, I quickly spotted Yuuki in his tuxedo.

I found him, but was puzzled to see an unfamiliar girl beside him.

  

About 5cm shorter than me, and 10cm shorter than Yuuki.

Wavy dark brown long hair, big eyes - fairly cute, I suppose.

Her frilly pink dress had a daringly open chest, and she pressed Yuuki's arm against her ample cleavage.

  

"Who's that?"

"Ah... Elena! Th-this is, well..."

"Kyaha! Starting today, Ai is Yuuki-kun's number one! You're demoted to second place, got it?"

  

Her baby-talk speech reminded me.

One of the girls from another class who'd been pursuing Yuuki. I didn't really remember her name.

  

Ignoring this "Ai" girl, I spoke to Yuuki.

"So that's how it is?"

"Ah, well..."

"A girl like you who doesn't understand Yuuki-kun's feelings at all is pitiful, isn't he?

If it were me, I'd listen to anything Yuuki-kun wants! I'd treasure him forever!

Right? Yuuki-kuuun!"

  

Ai brought her face close as if to kiss him, acting sweet.  
"Ah... haha"

Pressed against Ai, Yuuki didn't seem displeased, his nose twitching happily.

Watching this, I realized my feelings were rapidly cooling.

He was just a Yuu substitute - I had no interest competing with this idiot girl.

  

"Fine. Whatever. Be happy."  
"Huh!? W-wait! Elena, you could join us too?"  
"Hah? Save the nonsense for when you're asleep. Goodbye."

When I coldly dismissed them, Yuuki panicked.  
"W-wait! Elena!"  
"Who cares! Forget that cold girl, let's go to the venue already."  
"B-but..."  
"Besides, I booked a hotel for tonight. After the party, we'll spend a hot night alone?"  
"Ah..."

  

Turning on my heel, I briskly walked toward the main gate, pushing thoughts of the cuddling pair from my mind.

Taxis were already lined up there for couples sneaking away from the party.

I got into one.

  

"Huh? Where's your companion?"  
Apparently not expecting a solo passenger, the middle-aged driver looked surprised.  
"Saiou Station."  
"Huh?"  
"I said Saiou Station. Hurry up!"

  

Still, going straight home felt awkward, so I walked around the station in my dress under curious gazes, killing time watching late shows at the new cinema complex.

Somehow I didn't feel like watching romance films, so I chose an action movie to blow off steam.

After watching a monster movie and a delinquent girl flick, I felt hungry and entered a nearby burger shop.

Though I thought the movies had cheered me up, being alone made me feel hollow, and eating the burger felt like chewing sand.

  

Before I knew it, it was past midnight, so I decided to go home.

The heated interior was fine, but outside, the winter wind chilled my exposed shoulders, the cold biting deep.

I'd left my change of clothes at school, so I wrapped a thin stole around myself and ran shivering to the apartment, relieved when I arrived.

  

Though relieved to be home, my heart remained cold.

I thought about bathing, but found myself standing before Yuu's room.

Only Yuu could comfort me like this.

But I knew the door was locked since that night I invaded his bed and was rejected.

Just hearing his voice would satisfy me...  
But that seemed an impossible wish now.

Thinking this, I gripped the doorknob.  
Unbelievably, the door opened.

  

Had he forgiven his big sister?

Holding back my inner surprise, I entered my beloved Yuu's room.

In the orange dim light, Yuu lay sleeping peacefully in bed, breathing softly.

  

I couldn't contain my rising joy.

I discarded my dress in the corner and crawled toward him in just my underwear.

Lifting the covers, I slipped in and embraced Yuu.

"Haaah~, Yuu... so warm, smells nice..."

The futon was wonderfully warm with Yuu's body heat, melting my chilled body and heart.  
"Ahh... as expected, Yuu is the best. I only need Yuu."  
"Mmm..."

When I stroked his hair, Yuu turned toward me from his back.  
Staring at his beautifully sculpted, angelic sleeping face, I reached my limit.  
I gently kissed him.  
After pulling back to gaze at his face, I kissed him repeatedly.  
"Mmmph?"

As Yuu moaned, his mouth opened slightly and drool dripped from the corner. I licked it away.  
The long-awaited kiss with Yuu tasted exquisite.

  

"Haa, haa... Yu...u..."

Driven by burning passion, I began unbuttoning his pajamas.  
Throwing off the covers, I thoroughly examined his underwear-clad form.  
Though unusually excited, I remained partly calm, carefully lifting his innerwear without waking him.  
When his thin chest was exposed, I couldn't help drooling, but that couldn't be helped.

  

"Kufu, kufufufuu"

Unconcerned about the strange sounds escaping me, I kissed, licked, and sucked my way down Yuu's chest.  
When I sucked his nipple, he went "Nngha!" and squirmed slightly.  
"Ufufu, does it feel good even while asleep?"

  

He'd been sensitive here during that bath before too.  
I focused on sucking and licking his small nipples and armpits.  
His slightly sweaty skin scent and occasional moans stirred my heart, and I felt myself getting wet down there.  
Plus, what had been pressing against my stomach since earlier was Yuu's penis...!

  

Moving gradually from his chest to his cute navel and lean stomach, I hooked my fingers into his pajama waistband and slowly pulled them down.  
"Gulp..."

I unconsciously swallowed.  
Unlike elementary school days, the front of his trunks bulged.  
Even Yuu's small, cute penis from three years ago would've been fine.  
But it's a woman's nature to be drawn to bigger bulges.

  

Glancing at Yuu's face, he was muttering in his sleep. Adorable.  
"Okay"  
I psyched myself up.  
With trembling hands, I gripped his underwear's waistband and pulled it down. His penis sprang out energetically.  
"Wow..."

  

Judging by its softness, it was still in normal mode, but clearly an adult-sized penis, not a child's.  
I could see pubic hair had grown thickly around what had been smooth skin before.  
"Ufufu. Not just taller, but this has grown properly too. Big sister is happy."

  

I stroked it lovingly with my fingertips.  
Three years ago, the foreskin covered the tip, but now it was retracted, exposing the pee hole like lips.  
I brought my face closer and gave it a kiss.  
"Hau... Yuu's scent..."

The dense boyish scent made my head feel dizzy.  
Moreover, as I stroked it with my hand, it gradually grew larger and harder.  
Yuu's penis seemed to accept me, making me tremble with joy.

  

"Amazing...!"

Eventually, Yuu's fully erect penis along his lower abdomen had unimaginable length and thickness.  
Rubbing my cheek against it, feeling its heat and rugged hardness on my skin, I realized I was dripping wet.

  

I'd been foolish to compromise with a fake like Yuuki.  
Tonight, I would unite with Yuu.  
And receive abundant seed from this splendid penis into my womb to make a baby.  
That was fate.

While caressing the penis, I became engrossed in fingering myself with my other hand, but couldn't wait any longer and started removing my clothes.  
Then, too focused on Yuu's penis, I didn't notice he'd woken up and was looking at me.

  

"Huh? Wh-who? N-no! St-stop!"  
Oh no. Yuu seemed panicked with sleep-clouded eyes.  
I tried to restrain him first.

  

"Big sister loves you, Yuu! I'll treasure you forever, so let's make a baby? See, it's okay, not scary. Leave it to big sister."  
"Mmph, fuga... n-no! This is weird! Nmmph! Nn—! Nn—! Puhah... h-help!"

  

Yuu struggled desperately with his whole body.  
Being his first time, fear was understandable.  
Big sister needed to persuade him properly.  
Trying to make him understand my feelings, I restrained his hands and mouth, but Yuu kept resisting.  
Having no choice, I tried forcing insertion.  
I wasn't fully undressed, but shifting things should work.  
Surely once we both felt good, Yuu would understand?

  

Mounting him, I rubbed our genitals together with small hip movements.  
"Fu—, fu—, your penis is so hard? Ufufu. Your body's honest, isn't it!"  
"N-no! I said no! Aah... stop! That's no good!"

  

Tearful Yuu looked adorable.  
While pinning his hands, I leaned over him and reached to shift my panty crotch.  
Then the door burst open violently.  
"Yuu!"  
"Mom!"  
"Who? N-no way... Elena? What are you doing!"

  

Mom slapped my cheek hard, sending me tumbling off the bed.  
"Even if it's Elena, I won't forgive attacking Yuu!"  
Standing protectively before Yuu like a fierce deity, I could tell Mom was truly angry.  
"U... eh... b-but, I truly love Yuu..."  
"If you cherish him as a sister, that's fine, but don't you know right from wrong!? Besides, you were being too clingy and making him uncomfortable, so I repeatedly told you to consider Yuu's feelings and hold back..."

  

I tried looking at Yuu with clinging eyes.  
He was wrapped head-to-toe in the futon, trembling violently.  
Had I done something so hateful?  
Had I been completely rejected by Yuu?  
The blood drained from my face.  
Standing to call out to Yuu, my vision swayed unsteadily.  
When I tried crawling closer, Mom blocked me.  
"Cool your head! Right now you're just a rapist! Using your brother as an outlet for sexual desire!"  
"R...rape... that's not... I just... love Yuu..."

  

Reflecting on what I'd just done.  
Taking advantage of his sleep to kiss Yuu, strip his pajamas, devour his skin, and his penis...  
Then pinning down Yuu as he resisted upon waking, trying to force insertion...

  

"Gyaaaaaaahhhhhhhhhhhh!!!"  
"Elena!"

  

Covering my head, unbearably ashamed, I stood up, turned on my heel, and left the room.  
Though I bumped my arms and shoulders on the way, my heart hurt more than my body.  
Still in underwear, I returned to my room and threw myself onto the bed.

  

I'd wanted to be close with Yuu like childhood.  
I loved Yuu who said "I love big sister!"  
He'd said, "Men can marry multiple women, right? Then I'll marry Mom and big sister!"  
So I'd intended to make babies with Yuu someday.  
That might have been childish nonsense, but I couldn't forget it and eventually took it seriously.  
I never meant to hurt Yuu.  
Though avoided now, I thought he'd understand my feelings someday.  
This wasn't how it was supposed to be.  
This wasn't supposed to...

  

  

  

  

After that, I developed a fever and was bedridden for three days.  
Even after recovering, I lacked energy to go out.  
Mom worried and spoke to me, but too ashamed to face Yuu, I shut myself in my room.  
Now reluctant to even attend school, I lost motivation for everything.  
My reclusive life continued. I graduated high school but failed university entrance exams.

  

When Mom told me Yuu had been seriously injured by female classmates after his middle school graduation ceremony, I considered rushing to the hospital.  
I thought about it, but when I changed clothes to leave, my legs froze.  
I was too scared to see Yuu. My own fault.  
After that, I only heard updates from Mom.

  

Seeing Yuu return home earlier than expected brought tears to my eyes.  
Though only through the peephole I'd made.  
After just one month apart, Yuu seemed different somehow, looking much more mature.  
"After three days apart, view a man with fresh eyes" - I recalled the old proverb.  
Though rarely used now, Yuu radiated an adult aura from within that aroused stronger desire in me than ever before.  
Even though I no longer deserved involvement with Yuu, I couldn't help caring about him.  
Tormented by these feelings, unable to meet or speak to him, days passed with me only peeping at Yuu and masturbating.

  

As spring passed during these monotonous days, I witnessed something.  
Having noticed Yuu's return home, I was watching when strange sounds came from the living room.  
Not conversation but sensual moans.  
*(No way...)*

  

Unable to resist, I fearfully left my room and slightly opened the door to the living room to peek inside.  
An unbelievable scene unfolded, and I covered my mouth to stifle a gasp.

Yuu was not only being embraced by the housekeeper but also kissed by her.  


### Chapter Translation Notes
- Translated "ナイトショー" as "late shows" to convey cinema timing
- Preserved Japanese honorifics (-kun for Yuuki, -san for Elena)
- Translated explicit anatomical terms directly ("penis" for おチンチン)
- Rendered sexual acts without euphemisms ("attempted sexual assault")
- Transliterated sound effects ("Gulp..." for ごくり)
- Maintained original name order (Hirose Elena, Yuuki)
- Italicized internal monologues *(No way...)*
- Translated "プロム" as "prom" as culturally equivalent
- Used "big sister" for お姉ちゃん to reflect Elena's self-reference
- Translated "子種汁" as "seed" to preserve biological accuracy
- Preserved cultural terms like "futon" and "tatami" without explanation