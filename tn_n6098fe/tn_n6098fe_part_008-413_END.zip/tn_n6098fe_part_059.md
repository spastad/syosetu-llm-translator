## 52. Before Goodbye ② ~Now That It's Come to This~

I visited Akiko's apartment a little past 11 AM. It was still early, but I ended up being treated to lunch.

What she made with available ingredients was spaghetti napolitan.

"If I had known Yuu-sama was coming, I could have prepared a proper meal..."  
"No, I'm just happy to be able to eat your cooking like this, Akiko-san."  
"Oh my..."

Akiko looked flustered, but everything she cooked was delicious. Until elementary school, Yuu apparently disliked many vegetables and was picky, but after entering middle school and consistently hiring skilled housekeepers, his pickiness seemed to have disappeared. Also, since dinners usually consisted of well-balanced Japanese and Western dishes with multiple items for nutritional balance, eating noodle dishes like this was rare.

"Yay! I love Mama's napolitan!"  
Compared to Yuu and Akiko, Chihiro had a smaller portion on her plate. Smelling the fragrant ketchup sauce, Chihiro expressed pure joy.

"Chihiro-chan is so lucky. Having such a skilled cook for a mother."  
"Uh-huh! I love Mama's cooking!"  
Seeing Chihiro's beaming, childlike smile made Yuu feel happy too.

"Now then, please enjoy."  
""Itadakimasu!""

The ingredients were sausage, onions, and bell peppers. It had a mild yet distinct ketchup flavor. In his previous life before being reborn, Yuu had tried making it when he had leftover boiled spaghetti noodles while living alone, but he remembered burning it and failing.

"Mmm! Delicious!"  
"See? It's good, right?"  
"Truly. Oh? Chihiro-chan, you can eat bell peppers?"  
"When I was little they were bitter and I couldn't, but Mama started chopping them finely and mixing them in, and before I knew it I could eat them!"  
"Wow, impressive!"  
"Ehehe."

Yuu and Chihiro looked at each other and laughed. Delicious food creates smiles. Yuu glanced at Akiko beside Chihiro. She was watching Chihiro with a gentle smile.

"Ah, um... Is something wrong?"  
"No. I was just thinking, Akiko-san, you show your emotions quite openly normally."  
"Eh!?"  
"At our house, you were always expressionless, or rather, hard to read."  
"Ah... that was..."

Her flustered expression was so unusual that Yuu couldn't help but laugh.

"Haa... I can't compete with Yuu-sama."  
"Eh? What do you mean? Were you concerned about that?"  
Akiko looked down. Yuu wondered if he'd said something wrong.

"No. Since we're at this point, I'll say it—I might be someone with deep emotions by nature. But to make a living as a housekeeper, I needed to suppress that part of myself to obtain the Male Home Dispatch Qualification. So I deliberately pretended to be indifferent and expressionless, especially toward the men in the households I was dispatched to."  
"I see. So the real Akiko-san has a passionate side."  
"Eh?"  
"Mama smiles when she's in a good mood like now, but she's scary when she's angry!"  
"Oh, Chihiro..."

The rare experience of sharing a table with three people seemed enjoyable. Chihiro joined Yuu and Akiko's conversation, and Yuu was happy to see Akiko's unexpected true self. Especially now, with Chihiro present, she had a completely maternal expression. Though he'd been aroused by the female expression he saw when she gave him oral sex recently, he found this gentle expression equally charming.

After the meal, they relaxed while watching TV. A rerun of a variety show was playing, hosted by a woman with slicked-back hair and black sunglasses. The guests and assistants consisted solely of female comedians, singers, and actors. Occasionally, male talents appeared as special guests for a few minutes each day, and only during those segments did the audience show intense interest. The show resembled a long-running program that had ended before Yuu was reborn, and Chihiro laughed merrily.

While drinking tea Akiko had brewed after clearing the dishes, Yuu repeated what he'd said at Saihinsha that morning. He apologized to Akiko herself for the contract termination due to family reasons. Akiko seemed stunned by Yuu's words and remained silent.

"Why..."  
"Huh?"  
"Why would Yuu-sama go so far for someone like me?"  
"Well..."

When asked directly, even Yuu found it strange. Digging through his memories, even as the pre-reincarnation Yuu, his feelings toward housekeepers weren't negative. There was gratitude for their care in handling all household chores, including meals, in place of his parents, but it wasn't just that. During puberty, compared to the overwhelming affection and interference from his mother and sister, the distance maintained by housekeepers dispatched to male households felt just right. Sharing the secret of receiving oral sex for ejaculation management was also significant.

"There are various reasons, like being taken care of, but especially having my stomach captured. As a man."  
"Your stomach?"  
"Yeah. I always looked forward to your meals, Akiko-san. You even made delicious lunches for me every day after I entered high school."  
"Oh my."  
"So when I said I wanted you to keep working for us after July, I meant it."

Akiko covered her mouth with her hand, looking deeply moved.

"To think you felt that strongly... I'm truly overjoyed. I too... am grateful for being able to work at the Hirose household, especially for having met Yuu-sama..."  
"Is it true you're returning to the countryside?"  
"...Y-yes."  
After a slight hesitation, Akiko nodded slowly.

"I heard it's in Tohoku?"  
"Yes. Aomori."  
"Ah, Aomori... That's far."

While the Kanto region would be manageable, the northern tip of Honshu wasn't a casual distance. However, Yuu found it curious that despite being from Aomori, she had no accent at all. When he'd met people from Tohoku or Kyushu in university or work, even when they tried to speak standard Japanese, he remembered they couldn't completely shake their accents. When he pointed this out, Akiko began sharing her background in fragments.

Akiko was born into a family running a guesthouse in a port town in Aomori Prefecture. She helped with the family business from childhood alongside her grandmother, aunt, and mother. However, a major earthquake during her elementary school years damaged the building, leading them to close the guesthouse. She left her hometown with her mother, who began working at inns and traditional restaurants in Kanto while Akiko attended local schools. After graduating from a junior college home economics department in Saitama, she initially worked at a restaurant. At 25, before tax burdens increased, she boldly chose artificial insemination to have a child. After her daughter was born, she switched to being a housekeeper for flexible hours and weekends off, continuing until now. Her mother had returned to Aomori to live with her aunt but suffered a stroke last year due to high blood pressure.

"I was trained in housework by my mother. So what I am now is thanks to her. I must be filial in some way," Akiko said with a smile.  
"I see... So your decision to return is firm."  
"Yes, though I feel sorry to make Chihiro leave when she'd just made friends at school."  
"If that's the case, I'll be lonely parting with you too, Akiko-san."  
"Yuu-sama..."

Yuu took Akiko's hand on the table and held it. Though her eyes moistened, she quickly looked away. Seeing this, Yuu circled the table and sat right beside her, pressing their bodies together as he put an arm around her shoulder.

"Ah!"  
"You really took care of me, didn't you, Akiko-san? Not just with housework, but also down below. Even if I tried to forget, I couldn't."  
"I-if I could be of even a little help to Yuu-sama..."

Holding her other hand, they gazed at each other. But noticing Chihiro staring intently, Yuu cleared his throat and slightly distanced himself.

"Um, when are you leaving?"  
"Ah... This coming Saturday morning."  
"One more week, then."

He could probably only relax today. On weekdays, Yuu had school, and Akiko would be busy with moving preparations and procedures. Letting her go like this felt too regrettable. He wanted to express his gratitude for her care and his feelings. As a man in this world, wasn't there something he could do? The problem was Chihiro's presence. Would it be difficult to come when Chihiro was asleep at night?

Confirming Chihiro had turned back to the TV, Yuu pulled Akiko close and whispered in her ear.

"Akiko-san."  
"Hya... yes."  
Her cheeks flushed crimson as she felt Yuu's breath on her ear.  
"I have one last request before we part."  
"I-if it's something I can do..."  
"I want to have sex."  
"Se...!?"  
"Not just oral or kissing—I want to go all the way with you, Akiko-san. Especially now that it's come to this."  
"Fweh!?"

Akiko's eyes widened in disbelief as Yuu captured her lips.  
"Mmph!"  
"You don't want me as your partner?"  
Akiko shook her head vigorously.  
"Good."

When Yuu patted her head, Akiko leaned against him as if collapsing, burying her face in his neck. Over her shoulder, he made eye contact with Chihiro. For some reason, she was grinning, so Yuu smiled back.

For a while, they remained embracing. Unlike when she kept it plain as a housekeeper, her naturally flowing black hair had a luster unexpected for her age, feeling smooth to the touch with a faint, sweet shampoo fragrance. The swell of her chest pressed against him, and he could feel Akiko's pounding heartbeat. When Akiko lifted her face slightly, their eyes met.

"Um, tonight..."  
"If it's alright, I have one request too."  
Their words overlapped.  
"You go first."  
"No, you first, Yuu-sama."

Chihiro's voice cut through their conversation.  
"Hey hey, are you gonna do 'sex' with Mama, Yuu-sama?"  
"Huh?"  
"Eh... eh!? Chihiro, where did you learn that word!?"

Startled, Akiko turned to Chihiro and questioned her. But Chihiro remained completely innocent.  
"I heard sixth-grade girls talking. They said when grown-up men and women get along, they kiss! Like you two just did. And then they get naked and do 'sex,' and babies are born!"  
"Eh..."  
"Hey, what's 'sex'? Tell me!"

Her innocent smile left them no choice but to wryly smile. While girls develop faster than boys regardless, strong interest in sexual knowledge might be characteristic of this world.

"Um."  
Akiko, who had her back turned, looked back at Yuu.  
"Hmm?"  
"What I was about to say earlier... That... i-if Yuu-sama is okay with it... But this might be something ordinary men would dislike..."  
"Hmm, I probably wouldn't refuse unless it's something extreme. Especially if it's your request."

Yuu squeezed Akiko's hand. After hesitating, she spoke.  
"Actually..."

After showering first, Yuu sat on the futon laid out in the six-tatami room. He wore only underwear, with a towel blanket draped over him. Though it wasn't his first time having sex, waiting alone made him nervous. To distract himself, he looked around the room.

It seemed to be the bedroom, with a three-tiered dresser in the corner and clothes hanging on hangers—winter jackets and coats not currently in use. While Akiko's were plain colors like black and navy, little Chihiro's clothes were girlish reds and pinks. Observing the living traces of this single-mother household, the sliding door opened slightly, and Chihiro peeked in.

"I'm out!"  
"Whoa, that was quick... Wha!?"

After Yuu, the two had entered the bath, but only Chihiro came out first—completely naked. Her childlike figure had no curves, just a smooth, plump silhouette. Of course, her crotch only had a single vertical slit—truly flat. Though dried off, her hair tips were damp. Yuu sat on what was probably Akiko's usual futon, with a slightly smaller one beside it for Chihiro. Chihiro plopped down on her futon. Though Yuu was only in underwear since they were about to have sex, even with late May warmth, being naked risked catching a chill. Yuu called to Chihiro.

"Come here. I'll hold you."  
"Eh? Hold me?"  
"Yeah, sure."  
"Ehe!"

Blushing shyly, Chihiro nestled into Yuu's outstretched arms. Pressing close, he covered them both with the towel blanket. Perhaps because children have higher body temperatures, her skin warmth transferred to him, making Yuu feel warmer too.

"Cozy!"  
"Yeah, it is."  
Chihiro happily pressed her cheek against Yuu's chest.

"Hey hey, you don't have boobies?"  
She seemed fascinated by his flat chest.  
"Well, I'm a man. Different from Mama."  
"Ohhh."  
"But instead, I have something Mama doesn't between my legs."  
"Huh?"

Her little bottom touched Yuu's lower abdomen, but thankfully he wasn't hard—Yuu wasn't a lolicon or pedophile. If she were his biological daughter, he wouldn't have been conscious at all, but this was Akiko's daughter whom he'd just met. And a cute little girl who'd likely grow into a beauty like Akiko. Though he felt no arousal, holding her naked made his chest itch strangely.

As she relaxed in his arms, Chihiro's bottom brushed against his penis.  
"Ah! Something's touching my butt!"  
"O-oh. That's... something only men have—a penis."  
"Peeenis? Weird!"  
"Ah, stop..."

She wriggled her hips to feel it. Even if Yuu didn't desire a young girl, that movement was problematic.

"Hey!"  
"Yah!"

He lifted her in his arms. When their eyes met, Chihiro smiled happily, making Yuu smile too. If he'd had such a cute daughter in his previous life, he'd surely have been a doting father.

What Akiko had requested was for Chihiro to witness their sexual intercourse. In his original world, such acts were never shown to children, but this world differed. For women, intercourse with men was a rare experience, so they might use this precious opportunity for sex education. With Chihiro here, they couldn't keep it secret anyway. Though internally conflicted, Yuu agreed to Akiko's proposal. He hadn't expected her to come out naked, though.

Just then, Akiko peeked through the gap in the sliding door.  
"Ah!"  
Yuu didn't miss the envious expression on Akiko's face when she saw Chihiro in his arms.  
"Akiko-san, I've been waiting. Come here."  
"Y-yes."

Nodding, Akiko slipped into the room and closed the door. She too was completely naked but covered her crotch with her hand when turning toward Yuu, kneeling formally. Her standing figure glimpsed earlier had curves in all the right places—unbelievable for a mother in her thirties. Though usually plain-dressed, undressed she had a figure rivaling any teenage girl Yuu had been with.

"I-I'm... um... this is my first time... with a man... S-so I might inconvenience you... P-please... be gentle..."  
Her stiff nervousness was endearing. Yuu beckoned.  
"You'll catch cold. Come here."  
"Ah..."

Holding Chihiro with one arm, Yuu extended his other hand. Timidly taking it, Akiko was pulled close. Then all three embraced.

The soapy fragrance from their freshly showered bodies filled the air, and Akiko's unexpectedly voluminous breasts pressed softly against him, making Yuu feel aroused.  
"Ah... fuh... Yuu-sama..."  
Feeling Yuu's skin directly seemed to unsettle Akiko too.  
"Akiko-san."  
"Ah... Yuu-sama."  
Drawn together, they kissed. A light kiss, then another. This time a longer kiss. After several kisses, Akiko's face flushed pink.

"Ah... Kissing Yuu-sama... Feels like a dream every time..."  
Her shy, dreamy expression seemed girlishly adorable. Feeling a gaze, Yuu looked down to find Chihiro staring intently.  
"Does Chihiro-chan want one too?"  
"Mmmh!"

Instead of answering, Chihiro closed her eyes and pursed her lips like a suction cup. Seeing Yuu and Akiko kissing made her want to join. Seeing Akiko's wry smile, Yuu kissed Chihiro too. After three quick pecks—chu, chu, chu—she seemed satisfied.

"Ehehe! I kissed Yuu-sama!"  
"Chihiro is very lucky. Getting your first kiss from such a handsome big brother like Yuu-sama."  
"Yay! I did it!"

Watching Chihiro's innocent delight, Yuu smiled and turned to Akiko.  
"Shall we begin?"  
With cheeks still flushed, Akiko nodded.

---

### Author's Afterword

Chihiro is 7 years old, so naturally, there's no mother-daughter threesome (actual intercourse). Just kissing + full-body hugging + α. How far α goes will be revealed in upcoming chapters!

### Chapter Translation Notes
- Translated "ナポリタン" as "spaghetti napolitan" to preserve the Japanese-Italian dish name
- Rendered sound effects literally: "えへ" → "Ehehe", "ちゅっ" → "chu"
- Preserved Japanese honorifics (-sama, -chan) per style rules
- Translated sexual terms explicitly: "処理(フェラ)" → "oral sex (fellatio)", "下半身" → "down below"
- Maintained Japanese name order: "広瀬 祐" → "Hirose Yuu"
- Italicized internal thoughts: "（男としては）" → "*(As a man)*"
- Translated culturally specific term "胃袋を掴まれる" idiomatically as "having my stomach captured" (meaning winning someone over through food)