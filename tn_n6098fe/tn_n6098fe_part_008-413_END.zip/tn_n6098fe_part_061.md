## 54. Before Goodbye ④ ~TOGETHER~

Regarding the main act, meaning penetration, what position should we use?

In the world Yuu originally came from, the missionary position would be most common when the partner is a virgin.

Only in eroge or erotic manga would one start with doggy style.

In this world, since women take the lead, the cowgirl position seems to be standard.

When asked, Akiko said she'd leave it to Yuu.

So Yuu positioned himself over Akiko who was lying supine on the futon, pressing his hips against her as he looked down.

"I'm getting a little nervous. I'm finally going to be with Yuu-sama. I'm truly sorry that someone like me is your partner..."

"What are you saying? I'm happy to have sex with a beauty like you, Akiko-san. Look, my cock is rock hard, see?"

"Huh...?"

Yuu rubbed the shaft against the center of Akiko's vulva. His cock, which had dried slightly after the cleaning blowjob, immediately became coated and wet with her love juices.

"Ah, haaun!"

Akiko, exposing her entire naked white body, let out a sensual breath as she felt the heat and hardness of Yuu's member, looking at him with heated eyes.

"It's okay. Relax your body and accept me."

"Yes."

"Mommy."

"Mmm."

Akiko held hands with Chihiro lying beside her, waiting for the moment. Yuu covered Akiko, positioned the tip at her vaginal opening, and prepared for insertion.

Sploosh.

"Nnngh!"

"Ooh!"

Though only the glans had been swallowed, he immediately felt enveloped by warm, moist vaginal flesh. Due to childbirth, her hymen had already been broken beforehand. However, Akiko's vaginal interior, accepting a foreign object for the first time, was extremely tight. When Yuu tried to continue insertion, his progress was hindered by the vaginal walls.

"Kgh! T-tight!"

"Agh! I-it's... ahggh..."

"Mommy, are you okay?"

"I-I'm fine. Because... I'm becoming one with Yuu-sama whom I've always longed for. This much is nothing."

Akiko smiled with tears welling in her eyes. "Um..."

Yuu paused the insertion and looked at Akiko. Noticing this, Akiko panicked.

"Ah, I was just selfishly thinking that. I'm sorry. For an old woman like me to have feelings for a wonderful young man like Yuu-sama... how rude of me."

"Akiko-san!"

"Y-yes!"

Yuu brought his face close with a serious expression. He whispered at a distance where their breath mingled.

"Don't put yourself down. Age doesn't matter. I know I have stronger sexual desires than most, but it's not like I'll do it with just anyone. Because I've been taken care of for nearly a year by someone as wonderful as you, I didn't want to part without saying goodbye, to meet like this, and to have sex."

"Ahh... to hear such words from Yuu-sama... I couldn't be happier."

"If you feel that way, let's make today's sex unforgettable."

With only one week left before Akiko returned to her hometown, and Yuu having limited freedom of movement, this would likely be their first and last time having sex. That's why he had devoted himself fully to the foreplay. He was also fully motivated for the main act. Though he couldn't take too much time, he wanted to make their union intense.

Yuu embraced Akiko's head and kissed her. Akiko wrapped her free arm around Yuu's back and squeezed tightly. Then, without forcing it, he began moving his hips in small motions.

"Ngh... mmph... Yu... sama... aghn mmph!"

"See, I'm going deeper inside you, Akiko-san... ugh! Kuu~"

Though there was no pain from defloration, Akiko furrowed her brows enduring the pain of accepting a man's member for the first time. Yuu stroked her head affectionately, placing kisses not just on her lips but also on her cheeks, jaw, neck, and collarbone.

"Ahh! Ngh... ah, ah, aah! Yuu-sama is... coming... inside me!"

Thrust, thrust, thrust—Yuu worked his hips, achieving deeper penetration. Finally, his cock thrust deep into her vaginal depths.

"Hyaun!"

"Hah... it's all in."

"Y-yes. Ah... more than I imagined... I'm full of Yuu-sama's cock..."

"Phew... Inside you, Akiko-san, it's meltingly hot, and even without moving, it's squeezing me... feels good."

As if embodying Akiko's feelings, her vaginal interior was heated and tightly clenched Yuu's cock as if refusing to let go.

"Akiko-san!"

"Yu... Yuu-sama!"

As if driven by the joy welling up inside them, the two kissed repeatedly, tongues entwined. Simultaneously, as Yuu began thrusting his hips, Akiko's moans grew even louder. After a while, the oozing love juices made her vaginal interior slippery, and though still tight, movement became easier.

"Does it still hurt?"

"Y-yes... ngh ah! It doesn't hurt... anymore. Ngh... rather, it feels... good."

"Hmm? Say that again?"

Akiko blushed and averted her eyes.

"Nn~, come on... come on."

Yuu pulled back near the vaginal opening, made several shallow thrusts, then with a large stroke, thrust deep into her vaginal depths. In that instant, Akiko let out a high-pitched moan, her chin jerking upward.

"Fwah! Ah! Aah! That! Ahn!"

"How is it? Having my cock thrusting in and out like this? I won't understand unless you say it clearly."

"Yuu-sama... ahn! Y-you're mean. I... I... being thrust deep by Yuu-sama's cock... feels good, so good! Agh, aah!"

"Good. Then how about this?"

This time, while thrusting deep inside, he changed to a circular motion.

"Hauu! Th-that too... feels good! Ha, ha, haan! I'm being stirred by your cock!"

Seeing her mother's even more lewd state than before, Chihiro watched wide-eyed in surprise. To a child's eyes, it might look like Yuu was doing something bad to her mother. But both Yuu and Akiko were sweating, wearing earnest expressions. Chihiro vaguely understood that her mother repeatedly calling Yuu's name came from joy.

With each thrust of Yuu's hips, the sound of flesh slapping echoed: pashun, pashun.

"Ahh, Akiko-san! Feels so good!"

"Haaaaaah! M-me too! Amazing! Feels so good! Agh, there! Hoh, oh, ah! I'm... I'm cumming! Cumming! I'm cummiiiiiiiiiiiiiiiiiiiiing!!!"

Arching her back dramatically, Akiko reached climax. Yuu hadn't come yet but felt himself approaching.

"G-good. I'm glad I could make you come first, Akiko-san." Feeling satisfied yet unable to suppress his arousal, Yuu continued thrusting at the same pace. Meanwhile, Akiko remained tossed by waves of pleasure, her voice growing increasingly strained.

"W-wait, Yuu... sama! I-I just came... ah, ah, not so... intense... ngh aah! It's amazing! So amazing! I'm... again... aahn!"

With each movement of Yuu's hips, wet squelching sounds came from their joined parts: gutchu, gutchu. But the two, nearing climax, paid no heed.

"Fuh, hah, ah, Akiko-san! I'm... this time... let's come together!"

After pressing their lips together with a smack, they gazed at each other at close range.

"D-don't mind me... haun!"

Yuu buried his face in Akiko's neck and nape as she lifted her chin, feeling the sweat slowly seeping into her skin while thrusting relentlessly.

"Kah! I'm cumming, Akiko-san! I'll ejaculate inside your vagina!"

"Hah, yes! P-please, give me your semen, Yuu-samaaaaah!

Aaaaaaaah! M-me toooo... it's coming... cumming!"

"Ugh!"

Pressing their bodies tightly together, embracing each other firmly, Yuu climaxed. Throb, throb, throb—despite being his second time, a massive amount of semen gushed out.

"Ogh... aghn... it's coming... ah haaaaaaaahn! Yuu... sama's... so much... hot... agh! Feels so goood!"

Akiko, receiving Yuu's semen continuously inside her womb, was assaulted by intense ecstasy along with welling joy.

After finishing his long ejaculation, Yuu thought:

The semen test results showed his semen was exceptionally superior even in this world. Meaning it was optimal for conception. Having had sex with the three student council executives multiple times and over ten others so far, some might already have his sperm implanted.

Normally, as a high school student, he couldn't raise children, but in this world, natural pregnancy births received special privileges, so financial worries seemed minimal. Whether this creampie sex would impregnate her was a gamble, but he hoped Akiko would get pregnant too. Being in her early thirties, it shouldn't be a problem.

Not knowing if it meant anything, Yuu kissed Akiko, who had closed her eyes, without pulling out his cock, staying connected as if plugging her.

"How was it? Your first time having sex."

"U-um, well, that..."

Contrary to expectations, Akiko hesitated. Not that she didn't want to answer—she seemed embarrassed.

"I... didn't imagine it would be this much... Um, it felt like ascending to heaven... I was supposed to cleanly cut ties with Yuu-sama and return to the countryside. But I... find being held by Yuu-sama so incredibly pleasant that I want more... ah, I'm sorry. Please forget I said that."

"Fufu. Akiko-san, you're cute."

"Ahn!"

When Yuu put strength into his hips, the semen remaining in his urethra spurted out with a pyur. Then he forced open Akiko's lips with his tongue, ravaging her mouth. Akiko also entwined her tongue, continuing a fierce kiss with loud chu-pa chu-pa sounds. During this, Yuu whispered:

"This might be the first and last time we can have sex like this. So I want to engrave myself into your body so you'll never forget me. For now... one more time."

"Ah, ah... Yuu-sama!"

While Akiko clung tightly, pressing her cheek against his, Yuu noticed Chihiro's face had come very close.

"Hmm? What is it, Chihiro-chan?"

Chihiro, her face slightly flushed, was fidgeting while pressing her hand against her crotch area.

"Um, my body feels kind of hot."

"Eh!?"

At their surprised voices, Chihiro frantically shook her head.

"N-no, not like when I catch a cold... more like my chest feels hot and my heart's pounding, and here... around my crotch, it feels tight..."

Chihiro's eyes, desperately trying to convey this, were moist as she stared at Yuu. Then she uttered surprising words:

"Um... I want you to do to me too... like Mommy."

Yuu supported Akiko while still connected and raised his upper body. They temporarily shifted to a seated facing position. Yuu created a small gap by pulling back slightly.

"Okay, come here, Chihiro-chan."

"Un."

Shyly, Chihiro extended one leg and straddled over, positioning herself between them facing Yuu, then clung tightly using both hands and feet. Like a koala clinging to a eucalyptus tree.

Chihiro, who hadn't reached puberty yet, probably wasn't sexually desiring a man. But children tend to imitate adults. Moreover, Yuu and Akiko's union was too stimulating for Chihiro. She didn't seem to feel aversion to the sexual act itself—perhaps her feminine instincts were awakening early. But naturally, he couldn't perform the same act with Chihiro as with Akiko. So after discussing with Akiko, they decided to let Chihiro share skin contact to experience similar feelings, creating pseudo-sexual intimacy rather than just watching.

"Ufufu. I like Yu-sama."

Feeling Yuu's warmth, Chihiro smiled happily, rubbing her cheek against his neck.

"Haha, that makes me happy."

"Really, even Chihiro..."

"It's fine. No matter how old, being told 'I like you' by such a cute girl is an honor as a man."

"Yuu-sama! Nn—"

As Chihiro puckered her lips like an octopus and lifted her face, Yuu smiled wryly and sucked her plump, soft lips. This time, he slowly pressed their lips together. After separating, Yuu stroked Chihiro's head.

"Chihiro-chan, let's try an adult kiss like Mommy here?"

"Adult kiss? Un! Do it do it!"

"Then open your mouth and stick out your tongue."

"Aaahn—"

Chihiro opened her mouth wide, sticking out her small red tongue. Yuu also extended his tongue, touched it, then sealed their lips.

"Mph!?"

Chihiro's eyes widened, but perhaps feeling something from the mucous membranes touching, she didn't resist and left it to Yuu. Their tongues tangled with wet, slurping sounds. Yuu's tongue moved around so much that Chihiro's cheeks puffed out, ravaging her mouth. After a prolonged kiss, when their lips separated, several strands of saliva connected them. Chihiro's eyes were dazed, her cheeks dyed pink.

"Ahfunn."

Chihiro rested her head against Yuu's neck.

"Was the stimulation too strong?"

"Un, Yuu-sama, me too."

"Of course."

"Nn, nn, juru-puchu... ahf, lelo, leloo... ahfunn. Nmu! Chupa... hauuu... ahn! Yuu-sama? Y-your cock is..."

Yuu's cock remained hard without weakening. Though it seemed to have calmed down slightly after ejaculation, it might have actually grown harder. Yuu didn't want to think it was because of the deep kiss with Chihiro.

"Lie down like this, and this time Akiko-san, you move."

"M-me?"

"Un. Move however you like to feel good."

"Yes. I'll try my best."

And so, with Chihiro still clinging to him, Akiko on top of Yuu began slowly moving her hips.

---

### Author's Afterword

The finale of the Akiko arc is finally coming in the next chapter.

### Chapter Translation Notes
- Translated "本番" as "main act" to convey sexual context while maintaining nuance
- Preserved Japanese honorifics (-sama, -san, -chan) per style guide
- Translated explicit anatomical terms directly ("vagina", "penis", "ejaculation")
- Used "cowgirl position" for 騎乗位 as standard terminology
- Transliterated sound effects (e.g., "Sploosh" for ずぶっ)
- Maintained original name order and partial names as in Japanese text
- Translated sexual euphemisms literally ("becoming one" for 一つになる)
- Italicized internal monologue *(This might be the first and last time...)*