## 55. Before Goodbye ⑤ ~OH MY LITTLE GIRL~

"Haah, haah, haah...nnn! A, ann! Yu, Yuu-sama... Yuu-samaa! It's good... it's so good! Yuu-sama's cock feels so good! Too good... my hips are moving on their own......nnaa! A, a, a... aaaahn!"

Akiko now looked completely different from the expressionless housewife who used to do household chores. Her semi-long black hair was disheveled down to her back, occasionally covering her face until she unconsciously brushed it away - an incredibly alluring sight. Her breasts jiggled as she stared at Yuu with feverish eyes, mindlessly rocking her hips back and forth while panting with heated breaths.

When she worked as a housekeeper, Akiko's voice had been low-pitched, but now she let out high-pitched moans that belied her age, which delighted Yuu.

"Haah! I'm sorry... I'm the only one...  
A, umm, is Yuu-sama feeling good like this too?"  
"Yeah. It feels good, Akiko-san. You're amazing for your first time."  
"R-really? I'm glad."

When Yuu extended his left hand, Akiko grabbed it with her right, interlacing their fingers in a lovers' clasp. Meanwhile, Yuu's right hand had been stroking Chihiro's head and back. With flushed pink cheeks, Akiko leaned over Chihiro to kiss Yuu. After exchanging chuu, chuu, chupa, chupa kisses, she began rocking up and down with small movements while still connected deep inside. Perhaps due to the mixture of semen from his earlier ejaculation and her vaginal fluids, wet squelching sounds echoed from their joined area.

"Aah, ah, ah, haaauuuuun..."  
Akiko's furrowed expression shifted to a pained look as she stared at Yuu.  
"I, I'm... about to come again... nn, fuuaaaaaaaah"  
"It's okay. Come as much as you want. I'm still... nn! That's it... I'm close too!"  
"Ah, ah, ah, deep inside... your cock keeps thrusting deep... nnkuu! I can't stop anymore! Ann, aahn!"

Watching her mother and Yuu, Chihiro slightly raised her upper body and began mimicking the hip movements, rubbing her crotch against Yuu's chest and stomach area.  
"An, an, Yuu-shamaa... Chihiro feels good too."  
"Haha... So not just Akiko-san, but Chihiro-chan's getting horny too?"  
"Becausee, Yuu-shama is kind and handsooome!"

Perhaps because he was aroused, Yuu suddenly felt the urge to caress the completely naked little girl clinging to him. He reached out both hands to grip under Chihiro's armpits.

"Fweh?"  
He pulled her close until her crotch was near his face.  
"Let me pamper Chihiro-chan more. Can you spread your legs and say 'Please look at Chihiro's pussy'?"  
"...U...n. Chihiro's... p-pussy? P-please look!"  
"Nn! Well said. Good girl. Now, let me examine how it looks."

Before Yuu's eyes was Chihiro's smooth crotch. He gently spread her tiny slit, which seemed only half the size of an adult woman's.

"Weeeeh!? That's dirtyyy!"  
"Not dirty at all. Chihiro-chan's pussy is very beautiful."  
"Kyann!"

As Yuu began licking with the tip of his tongue, Akiko finally reached her limit, unable to pay attention to their conversation. Having gotten used to it, she rocked her hips violently, greedily seeking pleasure with loud bachun, bachun sounds.

"Kuaa, ah, ah... good, so good! Yu, Yuu-sama... Yuu-sama's... cock feels too good! Aa... aaaah! I'm coming! I'm coming... haaaaaaaahn! Nn! Aahn I'm cummiiiiing!"  
"Hyaa! Yuu-shamaa, don't... lick like that... ah, ahi... something feels weird... au, au... Yuu-shamaa... aunn!"

Akiko reached out to catch Chihiro who nearly fell backward. At that moment, Yuu thrust upward.

"Hyau!"  
Though he thought he shouldn't make Chihiro climax from cunnilingus, the aroused Yuu couldn't stop. Sensing ejaculation was near as his climax built, Yuu bent his knees and began thrusting upward from below.

"Aah! Yu...u...samaa, your cock, so deep! I-it's good!" Akiko, who had been at Yuu's mercy, gradually began matching his movements, rocking her hips to create pan, pan, pan sounds of flesh slapping.  
"Haah, haah, haah... Yuu-sama, Yuu-samaa! I'm... coming again! Oh, oh, ooh... I never knew... it could feel this good! My hips... won't stop!"

With each thrust, Yuu's cock knocked against her descending cervix, making Akiko stick out her tongue and moan wildly.

"Nmu! Uu... igiso..."  
Though Yuu's excitement peaked and his limit approached, he persistently continued sucking Chihiro's little girl pussy.  
"Nya! Yuu-shamaa, ahi, I'm... I'm... gonna pee... an, I can't hold it!"  
Chihiro covered her face with both hands, shaking her head as if resisting, but Yuu couldn't see with her crotch blocking his view.

With Chihiro sandwiched between them, Yuu and Akiko continued mating instinctively. As Yuu passionately licked the tiny vaginal opening while thrusting vigorously, he was overcome by such intense pleasure that he ejaculated as if his hips were moving on their own.

"Oouu... I'm cumming!"  
"Haun! Aa... aaaauu! Fuaa... sore... noooooo... I'm cummiiiiing!"  
Akiko arched her back dramatically, climaxing from the impact of hot semen filling her womb. Then Chihiro's body trembled before a stream of urine gushed out - choro... jobaaaaaaah!

"Nah! Bufaa!"  
"Yaaaaaaah... I can't stop!"

It made perfect sense when thought about. Continuously stimulating Chihiro's undeveloped area produced urine instead of vaginal fluids. Some fetishists might consider this a reward. Even while experiencing intense pleasure from ejaculation, Yuu wasn't into that extreme. Trapped under both of them, he kept receiving Chihiro's splashing urine on his face. The liquid that entered his mouth tasted salty.

***

"U, uwe... Yuu...sama... hic... I'm sorry."  
Before Yuu, who was wiping his face with a hand towel given by Akiko, Chihiro sobbed. Though a child, she was already elementary school age. Having wet herself in front of Yuu's face filled her with shame and guilt.

However, though a first for him, her accident was caused by Yuu. He patted her head.  
"Since I was the one who stimulated you, Chihiro-chan isn't at fault at all. Stop crying."  
"B-but..."  
"No really. I'm sorry for pushing you too hard."

After holding her close for a while, she finally stopped crying.  
"Um, Yuu-sama?"  
"Hmm?"  
Akiko had been diligently wiping semen endlessly dripping from her vagina, deliberately avoiding looking at it.

"Perhaps you should take a bath?"  
"Hmm. Maybe."  
Having sweated heavily and with his crotch area sticky, Yuu wanted to freshen up.  
"Then, shall we bathe together?"  
"Huh? Yeeees!?"

***

Unfortunately, the apartment's bath proved too small for two adults, so Akiko firmly declined. If they'd bathed together, another round might have started. Instead, Yuu bathed with Chihiro and washed each other. By the time Yuu washed her back, Chihiro had cheered up, laughing brightly. When he sat her on his lap in the tub, warmed up and tired, she leaned against him with a dazed expression.

Looking down at the completely unguarded Chihiro, Yuu thought: If he hadn't divorced and had children, he might have bathed with them like this.

He once had a divorced colleague with an elementary school child taken by his ex-wife. The colleague later said being alone was easier - he could freely use time and money without worrying about family obligations. But he admitted sometimes feeling lonely, as if a hole had opened in his heart.

Well, his situation involved separation from his child. Having separated before any children were born, Yuu couldn't immediately relate. But he thought maybe if he'd had children, his days off would have been busy but fun.

"Don't fall asleep in the bath."  
He cupped the face of Chihiro, who was nodding off. He wondered why children's cheeks were so squishy and pleasant to touch.  
"Fwe...? Uun..."  
With sleepy eyes, Chihiro turned around and hugged Yuu.

"Ahn... I wish Yuu-sama could be Papa and play with Mama every day and bathe together like this."  
Yuu smiled wryly, wondering if that "play" included sex. Knowing they'd soon return to Aomori, he knew this wish couldn't come true. Still, voicing it might be a child's nature.

"Chihiro-chan."  
"Nn... what?"  
Yuu faced her directly. Still sleepy, she squinted but looked back at him.

"When Chihiro-chan reaches my age... hmm, in about 8 years.  
Let's meet then. I'll be your first."  
"First?"  
"Yeah. I'll make you a woman."  
"Un, okay! Yuu-shama will make Chihiro a woman!"  
"Haha. Then that's all for today."

He took her chin and kissed her plump, reddened lips.  
"N~. Yuu-sama, more kisses!"  
"Ah. Until we don't get lightheaded."

Until Akiko called them since they'd been in too long, Yuu kept kissing Chihiro while holding her.

***

◇ ◆ ◇ ◆ ◇ ◆

***

Around 11 AM Saturday, Yuu arrived by car in front of Akiko's apartment. A 2-ton moving truck was parked outside. Through the open loading door, household goods were packed tightly inside. They must have started early and were nearly finished. With just mother and child, belongings wouldn't be excessive.

Getting out, Yuu headed toward the entrance stairs. A moving company worker carrying luggage lightly noticed Yuu, gasped wide-eyed, and nearly dropped her load. Being professional, she managed not to drop it.

"Good work. Ah, is Kawamata-san's move almost done?"  
"Hweh! Y-yes. Yes. Umm... it should... finish soon."  
"Good. I made it in time."  
"Y-yes. We plan to depart by 11:30. Hehe."

The tall, muscular woman around 30 sweated profusely and became flustered under Yuu's gaze. But visibly delighted to speak directly with a young man, her eyes raked over his body. However, noticing two protection officers behind Yuu, she hurriedly carried the load to the truck.

"Aah! Yuu-sama!"  
Hearing voices, Chihiro appeared through the open door.  
"Guess what! Chihiro helped too! I packed toys, clothes, and school things in boxes.  
And cleaned every corner of the room!"

She dashed over, stopped before Yuu, and started talking as if wanting him to listen.  
"Ooh, good job. Like mother like daughter - hard workers."  
"Ehehe."  
When Yuu exaggeratedly praised and patted her head, she smiled happily.

"You really came, Yuu-sama. Thank you."  
Akiko appeared with a bow. Today she wore a light pink polo shirt and slim cropped jeans. Having moved since morning, faint sweat glistened on her forehead. She looked refreshing yet sensually mature.

"Ah, um... is something wrong?"  
Asked by Akiko, who found Yuu staring strangely, he snapped back to reality.  
"Akiko-san really is beautiful. I'll truly miss not seeing you anymore."  
"Such..."

Blushing pink, Akiko fidgeted slightly but quickly composed herself under surrounding gazes.  
"I'm sorry I can't attend to you properly in this situation."  
"Well, I barged in during your move. Should I wait with Chihiro-chan until you finish?"

He considered offering help but knew amateurs shouldn't interfere with professionals. Yuu decided to wait with Chihiro. They played tag and jump rope in the parking lot, not just talking. Strangely, Touko competitively joined their play, which Kanako watched with exasperation. Yuu felt embarrassed as apartment residents emerged one by one to stare upon hearing his voice.

The move finished as scheduled at 11:30. Since Akiko owned a light car, she'd load remaining luggage and drive. Yuu didn't know how long Aomori would take - probably arriving at night via expressway. Maybe they'd stay overnight and unload tomorrow morning.

"Now, say goodbye to Yuu-sama."  
The truck engine was already running with the worker waiting inside. Only farewells remained, but Chihiro hung her head, all earlier energy gone. For a 7-year-old, Chihiro was remarkably composed - surely due to Akiko's good upbringing. Not so childish as to throw tantrums, but seemingly heartbroken about parting with Yuu.

Yuu approached Chihiro.  
"Chihiro-chan."  
"Yuu-sama..."  
Finally looking up, Chihiro seemed on the verge of tears.  
"Hya!"  
Yuu put his hands under her arms and lifted her.

"「「「Aah!」」」"  
"No way!?"  
"So... enviable!"

Voices came from the apartment, but Yuu ignored them.  
"Yuu...sa...ma. I love you!"  
"Nn. I love you too, Chihiro-chan."  
"Waa!"  
When Yuu whispered so only she could hear, Chihiro's cheeks turned apple-red as she smiled happily and hugged him tightly.

"Remember our promise. Become a fine woman. Until we meet."  
"A... Un! Chihiro will become a fine woman! Then Yuu-sama will make me a 'woman'!"  
After kissing Yuu's cheek with a chu, Chihiro hugged him tightly again.

Once set down, Chihiro no longer looked sad.  
"Now, Akiko-san."  
"Yes."  
Considering onlookers, they decided to part with a handshake.

"Though less than a year, I'm truly grateful for everything, Akiko-san."  
"Likewise, working at the Hirose household will remain a precious, unforgettable memory."  
Though no tears welled, Yuu sensed Akiko cherished their parting deeply. He squeezed her hand slightly.

"Don't say we'll never meet again. Let's meet someday. Definitely."  
"Fufu. Hearing that gives me hope."  
"Right. I'd like letters and photos. Send them once settled. I'll reply."  
"May I?"

Instead of answering, Yuu handed her a memo with his address. Though she knew it as housekeeper, he wrote it just in case.  
"I'll definitely send it."  
After a deep bow from Akiko and a waving "Bye-bye" from Chihiro, they got in the car. Alongside the truck, Akiko's light car drove off. Yuu watched until both vehicles turned the intersection corner from the apartment road.

Yuu turned back toward Kanako and Touko. Perhaps because he looked unusually downcast, they spoke up.  
"It's rare for a man to mourn a housekeeper's departure so deeply."  
"Because Yuu-sama is kind."  
"But still..."

Akiko had been part of daily life - busy with work and his sister secluded. She'd cared for him like a mother, practically family. Boys in this world might take such devotion for granted, but mentally adult Yuu felt genuine gratitude despite their employer-employee relationship. Though initially expressionless, just as they'd finally connected, the sudden separation shocked him deeply.

Without stopping, Yuu closed in on Kanako and Touko and suddenly took their hands.  
"Eh?"  
"...!"  
"Kanako-san, Touko-san."  
Called by their given names unusually, both looked flustered.  
"Don't suddenly disappear on me."

Exchanging glances, they looked straight at Yuu and replied.  
"Ye...yes. As long as Yuu-sama needs us."  
"Like a leech, sticking tightly without parting."  
"Haha. Then, I look forward to continuing together."  
"「Yes!」"

Yuu, Kanako, and Touko smiled at each other.

***

### Author's Afterword

Though regretfully, Akiko makes her exit here. I feel Chihiro stole the spotlight at the end.

And the one who will conclude Chapter 2 is (someone who barely appeared in the main story).

### Chapter Translation Notes
- Translated sexual terms explicitly: "おチンポ" → "cock", "おマンコ" → "pussy", "クンニ" → "cunnilingus"
- Preserved Japanese honorifics: "-sama", "-chan", "-san" maintained throughout
- Transliterated sound effects: "ぐっちゅ" → "guchu", "ばちゅん" → "bachun", "ぱんっ" → "pan"
- Italicized internal monologues per style guide
- Maintained Japanese name order: "Kawamata Akiko", "Kawamata Chihiro"
- Translated "お漏らし" literally as "wet herself" with contextual clarity
- Used explicit anatomical terms: "子宮口" → "cervix", "膣内" → "vagina"