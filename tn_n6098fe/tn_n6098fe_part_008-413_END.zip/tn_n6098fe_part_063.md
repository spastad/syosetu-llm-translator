## 56. Siblings ① ~Only Looking at You~

Time rewinds to the day after Yuu visited Akiko's apartment and enjoyed the quasi-"mother-daughter bowl" experience—Monday.

Having been told by Martina before school, Yuu returned home early to meet the new housekeeper. According to her profile, the housekeeper named Iida was 49 years old. Stout and unadorned, she perfectly matched Yuu's image of a motherly figure. She had actually married a man, been blessed with three daughters who were all already adults. Her second daughter had happily married a man three years ago and was now pregnant with a long-awaited child, she explained while laughing heartily—"When I turn 50, I'll finally be a grandma!"

On Monday night, he immediately got to taste her home cooking. It was tasty, but felt like ordinary family meals. For Yuu who knew Akiko's culinary excellence, it felt somewhat unsatisfying.

"I think I mentioned before, but I'm on a business trip starting tonight. It's a shame we can't have dinner together."  
"That's right. Umm, Kinugawa, wasn't it?"  
"Yeah... Honestly, it's a hassle."

Right after housekeeper Iida left, Martina was bustling about preparing to depart. He'd heard last Friday about her three-day business trip to Kinugawa. Apparently, there was some gathering for local newspapers in the Kanto region. Given the location, it seemed more like a friendship event combined with leisure than a meeting, held annually. She'd started at her current newspaper as part-time help but progressed to quasi-employee status and now had subordinates. Though she complained about being squeezed between upper and lower management as the lowest-ranking executive, she was a graduate of a competitive co-ed school despite only finishing high school, and was likely competent at her job. Though Martina had been selected as a participant for the first time this year, she seemed to prefer staying home with Yuu.

"Kinugawa means hot springs and river rafting, right? And Nikko's nearby so there's Toshogu Shrine and Edo Wonderland—lots to see. Have fun," Yuu said, immediately realizing his carelessness. He recalled learning at the library that history had changed since the drastic decrease of men from the Edo period. In this world, Toshogu and Edo Wonderland might not exist. But Martina didn't seem particularly bothered—Tokugawa Ieyasu had existed, and the Edo period wasn't much different from historical facts.

"Oh... Yuu-chan, this is for work!"  
"But you can soak in hot springs at night, and you said the last day is free time."  
"W-well, that..."

Martina's eyes darted around. She'd accidentally let that slip when explaining last Friday.

"Then hey, I'd like to go to a hot spring with you next time, Mom. Maybe we could use a family bath together?"  
"F-family bath!?"

When Yuu said this with a mischievous smile, Martina's eyes widened in shock. "Y-yes! Let's absolutely go! Okay? I'll look into it when I get back!" Martina suddenly became enthusiastic.

After this exchange, Martina finished her rushed preparations and was about to leave around 5:30 PM. Seeing Yuu off at the entrance, Martina put her luggage down and faced him.

"Are you really going to be alright?"

Martina was worried about Yuu and Elena being left alone at night. But Yuu had a plan. "Actually, Mom. I thought I'd try talking to Sis properly."  
"Huh!?"  
"It's weird for us to stay like this forever when we live in the same house. I know we can't just wash away the past, but I've matured a bit too. I want to have a proper talk."  
"But what if Elena has another breakdown...?"

Though casually conceived, Martina might cancel her trip out of worry. Yuu racked his brain.

"Umm... How about I ask protection officers Kitamura-san and Kujira-san in advance to wait in the next room?"  
"That might work. Having others around might help her stay calm. Okay, have them come right after I leave? Otherwise I won't feel at ease."

Though it was a spur-of-the-moment idea, Martina seemed satisfied with the protection officer arrangement. While Yuu only intended it to reassure his mother and had no real plans to call them, he nodded outwardly. Seeing this, Martina smiled and spread her arms wide.

"Okay. Then before I go, let me stock up on plenty of Yuu-chan essence."  
"Essence..."

Feeling embarrassed by such a bold statement, Yuu approached. He'd just finished his usual exercise and was sweaty, but she said that made it better.

Martina gently stroked Yuu's head and back while bringing her mouth to his neck, inhaling deeply—*suu haa suu haa*. Though it looked perverted to outsiders, he was used to it. Yuu wrapped his arms around his mother's back and buried his face in her wavy, abundant black hair near her neck. A subtle citrus perfume scent tickled his nostrils. They held each other tighter and longer than usual—a passionate embrace like lovers reluctant to part.

Moreover, her pink blouse was so thin that the lace pattern of her black bra showed through, making the sensation of her ample breasts unmistakable. "Mmm... Yuu...chan... haa... you smell so good..." Pressing her cheeks so tightly against him that her foundation might rub off, Martina savored Yuu's scent. With every shift, her breath hit him or her breasts pressed firmly against him, making it impossible not to notice.

*(Shit, this is dangerous. But she won't let go... Then again, I want to let her hug me as much as she wants today...)*

The old Yuu rarely let his mother hug him, but the reborn Yuu accepted her. Delighted, Martina gradually became less reserved—though within her self-defined bounds of a mother doting on her son. Meanwhile, the reborn Yuu couldn't help but see her both as his biological mother and as an extremely attractive younger woman physically. Holding each other like this stirred his male desires—his lower body began reacting. No matter how much he tried distracting himself by counting prime numbers, it was futile. He couldn't stop his crotch from swelling. Worse, today she wore a tight skirt. The flush on Martina's cheeks might be from Yuu's sweaty scent and body heat—or perhaps the hard object pressing against her lower abdomen.

"Fuu~. I'd love to stay like this forever, but it just makes me not want to go even more..." After finally giving a *chu* on his cheek, Martina pulled away but kept her hands on his shoulders, peering into his face with light brown eyes. "Yeah. Looking forward to your souvenir. Have a safe trip." "Thank you, Yuu-chan..." This time Yuu kissed Martina's cheek. He figured it was acceptable as foreigners exchanged such affectionate greetings.

Martina blushed like a girl, then clenched her fist and beamed. "Well then, I'm off! *Ufufu*. I'll bring back lots of souvenirs." "Okaaay. Have a safe trip." And so Yuu waved Martina off.

***

That night. With few entertainments for men, staying up late wasn't common, so Yuu lived an extremely healthy life. With hardly any homework, he spent about 30 minutes daily on review/preview and reading modern novels or nonfiction about contemporary customs for social education. After bathing, he did thorough stretches before going to bed before 11 PM.

***

Around past midnight. The doorknob of Yuu's room—where he'd stopped locking doors since rebirth—turned silently, and the door opened without a sound. A figure crept in and slowly closed the door.

The figure took a few steps forward and stopped upon seeing Yuu sleeping soundly under the orange nightlight, breathing softly. *Shuru shuru*—the sound of fabric rustling as she stripped off not just her pajamas but her underwear too, dropping them on the spot. Her slender, pale naked body emerged. Her long hair was tied back with a hairband, the ends reaching mid-back.

Though late May daytime could be sweaty on sunny days, mornings and evenings still felt cool. Yet she didn't shiver despite her bare skin touching the chilly air. Rather, imagining what came next, she breathed heavily with excitement.

The figure approached the bed slowly. "Aaah... Yuu..." Having stayed silent until now, she accidentally let out a voice upon seeing Yuu's sleeping face. Covering her mouth with a hand and gulping, she pulled back the blanket covering him up to his chest. After raking her eyes over Yuu's properly supine form from head to toe, she resolved herself and reached out to straddle him.

She knew Martina was away on her business trip. Originally, she planned to approach Yuu normally while he was awake. But wasting time hesitating in her room, she realized it was past Yuu's bedtime.

Ultimately, while thinking about Yuu, Elena's thoughts derailed, leading her to decide to fulfill her desires tonight without interference. If he resisted and rejected her? Then she'd give up forcing herself like before and confess her feelings with words. Her trembling hands might be because she couldn't completely shake her hesitation.

But just as her hands touched the bed, Yuu—who should've been asleep—grabbed her wrists, making her heart leap. "Eek!" "Planning to repeat the same mistake?"

Since rebirth, Yuu had wanted to talk directly with his sister. Yet no matter how many times he knocked and called, she never responded. Martina's overnight absence was a perfect opportunity. He'd wait for his sister to make a move.

Thinking this, he went to bed slightly earlier than usual and set his alarm for 1 AM. By intuition or luck, Elena entered just as Yuu was waking. He'd pretended to sleep while waiting—but never expected her to strip naked before him.

Elena clearly hadn't anticipated Yuu being awake. Flustered, she desperately tried shaking off his grip. Still holding his sister's wrists, Yuu tried pulling her closer. They struggled briefly. Though Elena was taller, they were similarly slim. Half a year ago it might've been an even match. But after nearly half a year secluded with reduced meals, Elena had weakened, while Yuu had focused on building his body through healthy living and self-training.

"Kyaah!" With the difference in strength, Elena lost balance and fell onto the bed. Yuu's first move was to lock the door—if she escaped and locked herself in her room again, it'd be back to square one. Then he turned on the light.

"Uu..." Sitting slumped on the bed, Elena narrowed her eyes against the sudden brightness before looking at Yuu. Seeing his stern expression, she hunched over.

"Now we can talk properly, Sis." Saying this, Yuu sat on the bed. His sister kept her face turned away. "Yuu... Um, you see, big sister..." Elena inched closer while watching Yuu, closing the distance. A beautiful girl naked within arm's reach—Yuu couldn't remain unmoved.

But it wasn't time for familiarity yet. As if to restrain his sister, Yuu spoke sternly. "Last year is water under the bridge." "Ah... Yeah. Sorry. Th-thank you." Thinking she'd be scolded again, Elena seemed relieved and sighed.

"Rather, what I want to ask about is housekeeper Akiko-san." "Huh?" Yuu turned toward Elena. *(Shit!)* He knew Elena had witnessed him embracing and kissing Akiko in the kitchen and had pressured Martina to terminate Akiko's contract by portraying her as a villain. Yuu wanted to set the record straight for Akiko's sake.

But seeing Elena up close weakened his resolve. Her clean oval face was impeccably sculpted—he'd rarely seen such beauty before or after rebirth. In Yuu's estimation, only Sayaka rivaled her, though with completely different features. Perhaps because he mentioned Akiko, her large almond-shaped eyes stared at him. Her beauty overwhelmed him more than in dream memories or photos.

Moreover, she was naked and approaching him. Her un-Japanese translucent pale skin stood out. Leaning toward Yuu with hands on the bed, her breasts weren't large enough for cleavage but she had long, slender limbs like a model. Her caramel-colored hair shone with natural luster, not dyed. Clearly, she'd inherited more features from their father, whom Yuu had only seen in photos.

Yuu felt overwhelmed by her beauty but shook his head, suppressing his rising arousal. "Why did you feed Mom all those lies? Sis benefited from Akiko-san's care too, right? Sure, it's her job as a housekeeper, but she was excellent. Her cooking was amazing too."

Hearing Yuu praise Akiko, Elena's willow-like eyebrows shot up. "B-because! That old lady! With Yuu—" "Don't call her old lady!" "She is an old lady! I thought she sweet-talked you into not refusing her advances! Why her, of all people? You rejected me!! If this continues, that old lady will take Yuu's first time. My precious little brother's chastity..."

Elena's face flushed with anger, tears welling in her eyes. Yuu understood—it was jealousy. Her anger helped him stay calm.

"There's a misunderstanding." "Wh-what?" "When we embraced and kissed, it was consensual—or rather, I initiated it." "Haaah!?" "Besides, Sis has no say over my chastity. Who was it that attacked me while I slept last New Year's? Isn't it strange for that sister to talk about her brother's chastity?" "Tch..."

Elena looked down bitterly. He knew she'd genuinely loved him for a long time. Even if the pre-rebirth Yuu was at a difficult age, Elena's actions were excessively abnormal. The mentally adult Yuu might've accepted her with some distance, but it would've been too much for a middle school boy in this world.

"Uu... But, but..." Clutching the sheets, Elena started muttering. "Since you were born... I've been your big sister... I wanted us to stay together forever! I decided as a child—I'd protect Yuu! I care about you more than anyone in the world... I just wanted to get along like when we were kids. Why couldn't we...? I was so lonely... so sad... When I thought about you in my room, my body ached... my mind went crazy... I couldn't stop myself... I never meant to hurt you... *sob*. Uu... why... why did I... become like this..."

*Plop, plop*—tears fell, staining the sheets.

Hearing Elena's sudden confession, Yuu gasped then exhaled softly. Brother complex to this degree was severe. Come to think of it, Rei's sister had quite the brother complex too. With too few samples, he wondered if sisters in this world tended toward severe brother complexes.

Elena looked up at Yuu with pleading eyes. Yuu glanced sideways but quickly averted his gaze—the sight of his naked, crying sister was stirring his male instincts. Faced with such beauty, he couldn't help feeling desire. He took deep breaths to calm his rising excitement before speaking without looking at her.

"You know what? Men have nocturnal emissions if they don't ejaculate for a long time." "E... emissions? I don't know. We didn't learn that in health class." "After starting middle school, I started having nocturnal emissions. I'd have dirty dreams while sleeping and wake up to find I'd ejaculated. My underwear would be soaked and sticky with semen—disgusting and unbearably embarrassing."

Yuu's sudden graphic confession made Elena blink rapidly, then freeze with her mouth agape. Naturally—in Yuu's original world, it'd be like a high school girl telling her brother about period difficulties.

"On emission mornings, I hid it and washed my underwear myself later because I didn't want anyone to know. But I got caught—by the housekeeper in my second year. It was awkward, but she said it was normal for boys. That's when I started having her relieve me." "Re... lieve?" "Having her suck my cock regularly to ejaculate." "That's... Lies... I didn't know." "I kept this secret from Mom and Sis. Of course, I asked Akiko-san too." "Th-then you should've told big sister!" "You can't normally tell family about such things." "Uu..."

Elena had been about to grab Yuu's shoulders but shrank back at his sharp words. Now came the crucial part. Turning to face Elena while looking at her body, Yuu spoke.

"So across two generations, I've had ejaculation management. But it's not like I'll accept anyone. Akiko-san and the previous one were both beautiful and skilled. But I can't bring myself to ask this new person." "Ah... yeah." "Which means Sis has to take responsibility." "Responsibility?"

Elena tilted her head, confused. Finding the gesture cute, Yuu reached out and placed a hand on her shoulder. Elena's cheeks relaxed at Yuu's touch after so long. Then Yuu raised the corner of his mouth and whispered softly.

"Sis, you're going to be my sexual handler."

---

### Author's Afterword

／人◕ ‿‿ ◕人＼ "Contract with me and become a sexual handler!"

This chapter was difficult—even after finishing, I kept revising and it took time.

### Chapter Translation Notes
- Translated "親子丼もどき" as "quasi-'mother-daughter bowl'" to preserve the cultural reference to *oyakodon* while indicating the sexual context
- Translated "性処理係" as "sexual handler" to maintain explicit terminology while conveying the role's nature
- Preserved Japanese honorifics (-san) for non-family characters while using natural English terms for family (Mom/Sis)
- Translated "チンポ" as "cock" per explicit anatomical terminology rules
- Transliterated sound effects (e.g., "しゅるしゅる" → "shuru shuru")
- Maintained original name order (Hirose Yuu) and Japanese terms for organizations (Kinugawa/Nikko)
- Translated the Kyubey-style afterword as a direct parody of *Madoka Magica*'s contract phrase