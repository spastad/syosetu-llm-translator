## 57. Siblings ② ~An 18-Year-Old's Secret Desires~

"Aha~, it's like a dream. Being able to openly see Yuu's pee-pee up close like this... Ufūn, it's rock hard. And so warm~"

Sitting between Yuu's spread legs as he sat on the bed, Elena rubbed her cheek against his penis with evident delight.

"Sis, I want you to be my sexual handler."

When Yuu proposed this as Akiko's replacement, Elena looked dumbfounded. But the moment she understood the meaning, her face lit up and she readily agreed.

Though Yuu had suggested it himself, he was inwardly astonished. *What world has a sister who shows joyful expression when asked by her brother to handle his sexual needs?* Yet here she actually was. When she pulled down Yuu's pants and saw his penis directly, her beautiful face became utterly slack-jawed, making Yuu slightly recoil.

Now Elena's fingertips thoroughly explored every part of his erect penis - from the tip and coronal ridge to the shaft, base, and even his scrotum - carefully tracing each area to confirm their texture.

"When you were in elementary school, it was still tiny and cute~ and the foreskin covered the tip~. It's gotten so big and manly without big sister knowing. Amazing, isn't it?"  
"Well, when puberty hits, your dick grows."  
"*sniff sniff*... Just smelling Yuu's pee-pee scent makes me wet..."

Elena squirmed with her thighs pressed together, still seated on the floor. Yuu smiled wryly at how just smelling her brother's penis could arouse her - a serious condition indeed. Though for Elena, Yuu was likely her only object of desire.

Most women Yuu had been sexually involved with called it "pee-pee" (おチンポ) - with one exception who used "Lord Cock" (チンさま) - but only Elena and Martina used "pee-pee" (おチンチン), probably because they'd seen it since childhood. *A cute nickname that doesn't suit this adult cock*, he thought.

"Okay, I get how much you like my cock. Now give me a proper handling (blowjob)."  
"Hah! O-okay! Leave it to me!"

Elena, who'd been pressing her nose against the penis to smell it, flustered but looked up at Yuu and nodded firmly. Yet with a serious expression, she asked:  
"So... how do I do it?"  
"Huh?"  
"Um... if I can do what I want, I'd play with it forever. But I have to make Yuu feel good and make him squirt semen, right? I was wondering... how did Akiko-san do it?"

Elena asked shyly. Yuu found her attitude commendable - she seemed genuinely committed to replacing Akiko. Considering she hadn't touched the real thing in years, despite using Yuu as masturbation material, asking directly was practical.

Yuu smiled and stroked Elena's head.  
"Ah..."  
Elena narrowed her eyes happily.

"First, lightly grip the shaft with your right hand. Not too tight. Then stroke it up and down."  
"Like this?"  
"Yes. Your other hand can stroke the tip or gently massage my balls - do what you like. Yeah, that's about right."

Elena began handjob with earnest concentration. Being her first time, her movements were cautious and clumsy - at least she wasn't hurting him. Expecting the skilled, responsive techniques Akiko used was unrealistic. Even Akiko took time to learn initially. Elena would improve with practice. Besides, a naked beauty giving a handjob was arousing enough.

"Should I use my mouth too?"  
"Ah, please. Lick from the tip down the shaft like an ice pop."  
"Okay. A~hn, *lick*"

Now blushing pink, Elena stuck out her wet tongue and began licking from the tip downward. Her right hand kept stroking. Though unskilled, her enthusiasm was undeniable - she sucked fervently as if it were truly delicious ice. The wet mucosal stimulation melted Yuu's reason.

"Ugh... ah..."  
As she licked thoroughly from the tip, he couldn't help moaning.  
"Yuu, does it feel gooood?"  
"Ah, feels... good."  
"Anh, I'm happy... so happy... Big sister always dreamed of taking care of Yuu's pee-pee like this."  
"Ha...ha... Seriously?"

*If I hadn't been reborn, Elena might've raped me someday.* Her sisterly love seemed abnormally intense. While Yuu welcomed having sex with Elena now, controlling her might prove challenging. Still, securing her as his handler was a success.

Elena's gaze dropped to his hanging scrotum. Her eyes suddenly glistened.  
"Ufuh. Yuu's sperm... semen is in here... Aha~n"  
With drool dripping, Elena suddenly popped one testicle into her mouth and began sucking. *Chu-chu*  
"Fwoh!"  
Yuu let out an involuntary noise at her boldness. Her right hand kept stroking the shaft while her left hand had moved to her crotch, fingering herself. Already thoroughly wet, *squelching* sounds soon followed.

After sucking one testicle at length, Elena took the other into her mouth, *chupa-chupa* sucking vigorously. Her puffed cheeks made her look like a child with a lollipop. The sensation of having his balls sucked was indescribable - pleasurable yet... it felt like his manhood was being toyed with.

"Mmhmm~n... *slurp*... Big sister will lick-lick Yuu's precious balls..."  
"Nn... Sis... Hey sis..."

Elena rolled the balls on her extended tongue, her expression utterly debauched. Though she'd looked prim in photos, she now wore the face of a female devouring her brother's testicles. Her right hand mechanically stroked, making *squelching* sounds from precum, but she remained fixated on ball-sucking. Yuu reached for her modest breasts and pinched the small nipples.

"Hyahn!"  
"Balls are good, but time for the next step."  
"Ahhhh! S-sorry!"

Flustered, tearful Elena apologized. This sister seemed unable to multitask when focused. Yuu lifted her chin, pressed the cockhead against it, and instructed:  
"Suck it. See the clear fluid dripping? Lick it off."  
"O...okay"  
After glancing up at Yuu, Elena gulped and stared at the penis.

Opening her mouth to show her tongue, she pressed her lips to the glans and *chu-puu* licked off the precum.  
"Use your tongue to lick the entire tip."  
"Nn"  
Following orders, Elena began sucking the penis in her mouth.  
"Ah... yes. Take it as deep as you can...  
Th-that's it, move it up and down in your mouth... Unh! Ahh! Fe-feels good..."  
"Nngh. Yuu... so cute"  
Seeing Yuu's pleasure, Elena happily continued the blowjob.

Though clumsy for a first attempt, the warm mucosal sensation intensified the pleasure. Elena moved her head up and down while stealing glances at Yuu. She couldn't deepthroat yet, but that was fine for now. Still, reaching orgasm felt frustratingly distant.

Yuu stroked Elena's cheek.  
"Sis, I want to cum like this. I'll move too."  
"Ah, wai—"  
"Huh?"  
Elena pulled her mouth off slightly, licked the mixture of precum and saliva with a *chu*, flashed her glistening tongue, and said:  
"Hah, hah... Yuu... I have a request."  
"A request?"

Aroused from the blowjob, Elena flushed and squirmed, still fingering herself.  
"When you ejaculate... I want you to... cover me."  
"Cover?"  
"Yes... Big sister's body..."  
Elena indicated her chest with her wet right hand.

Suddenly, Yuu recalled his first ejaculation. Back then, Elena had been right in front when he erupted. Though he hadn't noticed then, in his dream memory she'd worn an ecstatic expression.

"Hah, hah, like that time... I want you to cover me. With Yuu's seeeemen."  
Elena stared at Yuu with feverish eyes. *What a perverted sister.* But Yuu didn't mind.  
"Cleanup will be messy... but whatever, we're naked. I'll cover you."  
"Unh! Yay!"  
"Now open wide."  
"Aaahn"

Yuu leaned forward, cradled his kneeling sister's face, and thrust his cock into her open mouth.  
"Abgh! Nnn~~~guuuh!"  
He'd gone too deep, making Elena gag, so he pulled back slightly. He began slow thrusts into her mouth.

"Nngh, nmgh! Nfuu... Aahn! Ugh! Uuun... Nngh, nngh, Aahn! Aahn!"  
"Ooh... This... Sis's pussy mouth feels amazing... Ah, I'm close!"  
"Nnn~n... Uu... Nngh, nmgh... Aaih!"

Regaining composure, Elena resumed masturbating with a blissful expression, surrendering to Yuu. A puddle of her juices had formed on the floor beneath her thighs. Seeking more stimulation, Yuu quickened his thrusts, making Elena's tied hair sway.

"Kuoh! Almost there... Nngh, guh!"  
Thrusting deep into her throat without restraint intensified the glans stimulation, pushing Yuu toward climax. Though Elena occasionally coughed, Yuu didn't stop. He nearly came in her mouth but remembered her request. At the last second, he pulled out, grabbed her right hand, and made her stroke the slippery cock.

"Nuooh! I'm... ejaculating!"  
"Nngh!"

First, semen shot onto Elena's dazed, open-mouthed face with a *splat*.  
"Fwah!"  
Leaning forward, Yuu continued ejaculating onto her upper body. *Splash, splash.* From collarbone to chest, breasts, and stomach - her white nakedness was instantly covered in milky fluid.

"Ah, ah, Yuu's hot semen, so much... Haanh... A-MA-ZING... I've... always wanted this... Ah, ah, aah! I-I'm... feeling Yuu so much... so happy... Hah, hah, haaaaaaaaahhn!!!"

Arching backward like a yoga pose, Elena came violently while moving her fingers rapidly. Her vulva sprayed love juice *squirt, squirt* repeatedly.

In her afterglow, Elena blissfully smeared the semen over her body. Even after ejaculating, Yuu couldn't look away from his sister's lewd display - supremely beautiful yet incredibly erotic.

### Chapter Translation Notes
- Translated "おチンチン" as "pee-pee" to preserve childish/affectionate tone while maintaining explicit context
- Rendered "性処理係" as "sexual handler" per established terminology
- Preserved Japanese honorific "姉さん" as "Sis" throughout
- Translated "ぴゅっぴゅっと射精" as "squirting out semen" with onomatopoeic emphasis
- Maintained explicit anatomical terms: "タマタマ" → "balls", "精液" → "semen"
- Italicized internal monologues per style guide (e.g., *What a perverted sister*)
- Transliterated sound effects: "ちゅぱちゅぱ" → "*chupa-chupa*", "ぷしゃっ" → "*splat*"
- Translated "口マンコ" literally as "pussy mouth" per explicit terminology requirement
- Rendered "精液が塗れていく" as "covered in semen" with direct anatomical accuracy