## 58. Siblings ③ ~BE MY BABY~

Even after Yuu had ejaculated on her, Elena remained dazed and motionless, her body surface still covered in semen.

Unable to leave her like that, Yuu managed to get her standing and led her to the bathroom, pushing her inside.

Though Yuu himself felt the post-ejaculation lethargy, perhaps due to mental excitement, he was now fully awake.

So after sending his sister to the bathroom, feeling thirsty, he headed toward the living room.

He was only wearing underwear below, yet his erection remained persistent.

Elena's naked body from earlier was seared into his mind, far from any post-nut clarity.

"Haa~. Guess we know who's the desperate one here."

He couldn't help but mutter self-deprecating words.

In his previous life before rebirth, one ejaculation would calm him down, but in this body, his libido felt strong enough for consecutive ejaculations. At 15 years old, there were times when lust overpowered rationality. Perhaps his mind had rejuvenated along with his youthful body.

Noticing the glass he'd filled with barley tea was already empty, he placed it in the sink. He remained standing blankly in the kitchen for a while until he heard the bathroom door slam open. Elena emerged sooner than expected—likely having just rinsed her body quickly with the shower. Looking toward the door she'd entered, he saw it left half-open, revealing the hallway. Soon after, the pattering sound of Elena's bare feet approached.

Drawn by the sound, Yuu headed toward the living room door. When he opened it wide, Elena appeared—her face half-hidden by a bath towel she'd been using to dry her long hair, but otherwise completely nude. Their eyes met.

"Ah, Yuu!"

Elena smiled happily, having just fulfilled her wish through the sexual service (fellatio).

Standing face-to-face like this, Yuu noticed Elena was about 5cm taller. Though her breasts were modest, her model-like long slender legs caught his eye. Her pubic hair appeared somewhat sparse.

Perhaps unique to this chastity-reversed world, women of all ages wandered around homes nude or in panties without shame—Martina did it, and now Elena before him. During his early teens, Yuu had complained about this, but neither had changed their habits. Thus, Elena showed no embarrassment now. But for current Yuu, this sight was dangerous—no, rather a feast for the eyes—reigniting the excitement he'd tried to suppress.

Yuu approached Elena with unsteady, sleepwalker-like steps.

"Big... sis..."

"Yuu...?"

Elena looked slightly puzzled, but seeing her brother approach while looking directly at her—not rejecting her as before—made her smile bloom just from that happiness.

Yuu gazed heatedly at Elena's pale nude form, while Elena grew excited seeing Yuu's provocative state in just a T-shirt and underwear. Her gaze fixed on his crotch.

"Wow... your penis... so energetic..."

Before the earlier heat could fade, her lower abdomen clenched with desire.

In an instant, the distance closed between them, and Yuu suddenly captured Elena's lips.

"Mmph!"

Elena's light brown eyes widened in surprise but soon flushed crimson. For her, this was her beloved brother's kiss after so long—her high school boyfriend forgotten, only Yuu mattered. As if confirming this wasn't an illusion but reality, she clung to Yuu with both hands.

While their lips locked, Yuu turned Elena's body and pressed her against the wall. The bath towel on her head slipped to the floor with a rustle.

"Mmm... hey, big sis..."

"Yu...u..."

They pulled their lips apart slightly and gazed at each other. Elena's moist, glistening eyes held Yuu captive before she grabbed the back of his head and pressed her lips against his again.

Yuu's right hand stroked Elena's still-damp hair and head. His left hand slid down from her shoulder to her back, confirming the smooth skin texture. Meanwhile, Elena boldly lifted Yuu's T-shirt to his chest, relishing the feel of his bare skin.

"Haa, haa, big sis!"  
"Mmm, Yuu! Ahhaan... mmph, mm, haa~n..."

Their bodies pressed together, they exchanged passionate kisses while shifting angles. Elena's modest breasts rubbed against Yuu's bare skin, while Yuu's hot erection pressed against her lower abdomen. Driven by the flames of desire burning within, both greedily devoured each other.

Yuu kneaded her shapely buttocks while thrusting his tongue into Elena's mouth.  
"Mmph! Ooh... aah..."  
Elena accepted Yuu's tongue, her eyes growing hazy as she actively tangled her own tongue with his.

Not just inside Elena's mouth—they pulled apart slightly, drool dripping as their tongues poked and wriggled against each other.  
"Mmmph... Yu...uun... I love you... anmph... slurp slurp chupaah... chu, chu... aahn, more... Yuuuu!"  
This time Elena attacked with her tongue. Not only clinging to his back with both arms, she pressed her lower abdomen hard against his stiff cock to savor it. Rubbing her inner thighs together, Elena was already dripping with love juices—Yuu knew from the wetness soaking the fingers he'd slid down to her buttocks.

*(I can't stop now!)*

Tonight, Yuu intended to repair his relationship with Elena by taking the lead and making her his sexual handler. Given her abnormal brother-love, he thought it'd be easy. But it seemed Yuu himself had been overwhelmed by Elena's erotic beauty. His erection wouldn't subside—he desperately wanted to thrust inside. The fact they were blood-related siblings posed no obstacle before his blazing lust.

"Big sis!"  
Hugging his sister's slender body tightly, he pressed his forehead to hers as they gazed at each other.  
"What? Yuu... annh"  
"Over there."  
Yuu's left middle finger rubbed back and forth over her slit from behind her buttocks. Just that made thick love juices cling, producing squelching lewd sounds. Keeping their bodies pressed together, Yuu moved them toward the living room.

Yuu sat Elena alone on the sofa, then stripped off his T-shirt and underwear. He showed off his energetically sky-pointing penis before his sister.

"Ahhaa... Yuu's penis... amazing..."  
Elena's eyes sparkled as if with heart symbols, staring fixedly at Yuu's cock. Licking her lips, she opened her mouth.  
"Should big sis suck it again?"  
Though she seemed ready to take it in her mouth, Yuu didn't bite.  
"Hmm, just sucking isn't satisfying enough."  
"Eh... not satisfying...?"  
Seeing Elena's suddenly sad expression, Yuu hastily added:  
"No, that's not it. Since you just sucked me, now let me use your lower mouth... meaning, let's have sex."  
"Se... se, sex!?"

Elena's face showed disbelief as she covered her mouth. But since this was her own desire too, her expression gradually turned into a grin.  
"Ufufufufufu... Okay. Yuu, become one with big sis? Since... it's my first time too, I might not be good at it, but I'll be as gentle as possible. Hehe... Yuu's virginity... *ahem*. J-just leave everything to big sis!"

There seemed to be a misunderstanding. Or rather, even now she still thought of Yuu as her sexually inexperienced little brother? He remembered his sister being quite smart, but when it came to her brother, she seemed to turn incompetent. Or perhaps she just wanted to act superior as the older sister.

"You're misunderstanding something—I'm not a virgin anymore."  
"Huh?"  
"I've had experience since starting high school."  
"Haaaaaaah!?"

The student council trio, two nurses, four delinquent girls, and housekeeper Akiko—he'd already experienced intercourse with ten women. He hadn't planned to detail it that much.

"Lies... no way... I wanted your virginity... ahh, I can't believe it!"  
Elena shook her head in denial.

A virginity fetishist? Or simply her excessive brother-love manifesting as desire? Though Elena seemed shocked, Yuu had no intention of explaining further.

Yuu bent slightly to peer at Elena.  
"Big sis"  
"Hmm?"  
"Starting tonight, we began a completely new relationship, right? To me, what are you?"  
"To Yuu... me?"  
"Yeah. If you can't answer correctly, we're going back to how things were yesterday?"  
"Ehh!? No way! I... I'm..."  
As Elena visibly panicked, Yuu gently stroked her head and whispered in her ear:  
"It's not difficult. Remember what I asked before we started?"  
"Ah..."

Before Yuu's gaze, Elena nodded. Her well-shaped lips formed words:  
"I am... Yuu's... sexual handler."  
"Cor-rect!"

Yuu smiled and gave her a peck. Instantly cheered up, Elena beamed.

"As a sexual handler, new or used shouldn't matter, right? Another question—what if I suddenly want to ejaculate?"  
"Suck it with my mouth or use my pussy to make you cum."  
"Right. Since we live together, I'll be using you plenty from now on."  
"Ahah! Use big sis lots and... huh? Wait a sec."  
"What?"  
Elena tilted her head cutely.  
"Come to think of it, I heard boys can't do it again for a while after ejaculating once..."  
"Not for me. See?"  
He took Elena's hand and made her touch his cock.  
"Seeing you naked, my erection won't go down... I can't wait to thrust inside."  
"...!"  
Feeling the heat and hardness of the cock in her hand while hearing Yuu's words, Elena's cheeks flushed red.  
"Um, um... h-how should we do it? Should I be on top?"

As his flustered sister gripped his cock while looking up at him, Yuu said:  
"Then, big sis. I know better, so do as I say now."  
"Okay. Big sis will do anything, just tell me. Yuu."  
Yuu and Elena smiled at each other.

Before Yuu's eyes on the sofa, Elena lifted her legs completely, spreading them wide—the so-called M-shaped spread. Using her fingers to spread her slit wide open, she exposed her salmon-pink vaginal opening while looking up at Yuu with lust-glazed eyes.  
"Seee, Yuu... hurry and put that penis in big sis's pussy. And give me lots of hot seeeemen."

Smirking, Yuu bent slightly into insertion position.  
"Kukuku. Big sis, you're so lewd and beautiful. Here goes—I'm putting it in."  
"Aahn, hurry!"

Elena was fully motivated, eagerly awaiting Yuu. As Yuu grabbed near her knees and brought his hips closer, her slit twitched visibly, a drop of transparent fluid dripping from her buttocks onto the sofa fabric.

When the tip touched her vaginal entrance, it made a squelching sound. Pushing his hips forward, the glans was immediately swallowed but met resistance from vaginal flesh.

"Agh! It's... coming in! Agh... nnngh! Fuu... aghn! Yuu... your penis... ahhaa... so... good!"  
"Kuhah! Damn, tight! Inside big sis... ngh!"

Penetrating a virgin vagina was indeed challenging. It wouldn't go deep easily. But Yuu didn't rush—he enjoyed even this. 

"Big sis. Look—can you see where we're connected?"  
Grabbing his sister's head, he made her look down at their joining point. Though Elena couldn't see her own vagina from that angle, she could see half of Yuu's penis still not inserted.  
"Ahha... really... Yuu's penis is inside me."  
"Not all yet. Here!"  
"Aghn!"

He pressed his hips firmly and thrust deep. Pushing aside vaginal walls trying to block the foreign object, he advanced further inside. Yuu moved his hips in small motions, slowly inserting deeper.

"Ah, ah, Yuu is... kyau! Yuu is in... nhaa... inside me, ah, ah, aaaaah!"  
"Ooh! Guh... haa... it's in! Aah!"

When he finally reached deep inside, a tingling pleasure ran from his hips to his back. Had he not ejaculated earlier, he might have cum just from that overwhelming pleasure. Even without moving, it persisted intensely.

Due to personal preference—perhaps because he'd had an older sister in his previous life—Yuu had been obsessed with little-sister themed adult content. Though uncertain if true, it was often written that blood-related partners had incomparably good physical compatibility that made one addicted.

Right now, he understood that well. Though he'd succeeded in penetration, he couldn't move at all. Whether consciously or not, the folds inside her vagina writhed, tightly squeezing Yuu's cock. The glans buried deep in her vaginal depths felt wonderfully enveloped. He felt he'd cum if he moved his hips even slightly.

To buy time, Yuu brought his face close to Elena, their upper bodies pressed together. In this position after penetration, Yuu was now looking up at her.  
"Nn... ah...n. Hah... Yuu"  
Drunk on the deeply connected pleasure, Elena understood Yuu's intention and met his lips, exhaling sweet breath.

Keeping their mouths slightly open, they exchanged deep kisses with wet smacking sounds. As passion mounted and they shifted angles while kissing, Yuu's body swayed slightly, making his cock gouge deep inside her. During penetration, Elena's hands—which had been gripping Yuu's shoulders—now roamed over his chest and head.

"Gwah... mmph... chupuu... haan... Yuu, I love you... aghn! Feels good, Yuu... your face, voice, body... and your penis is so wonderful!"  
"Haha, big sis's pussy feels great too!"  
Deliberately acting composed despite being on the verge of cumming, Yuu replied, making Elena's expression soften.  
"Really? I'm so happy... annh"

He was still moving slowly and gradually. Yet due to their deeply connected position, it seemed plenty pleasurable for Elena. Her fair skin flushed pink, intermittent sweet moans escaping her lips.

Suddenly Yuu wondered—he hadn't felt the sensation of breaking a hymen.  
"Come to think of it, I think this was your first time, but doesn't it hurt?"  
"Ah..."  
Elena awkwardly averted her eyes.  
"Hmm? No blood either."  
"Um... I broke it with a vibrator before..."  
"Ahh... I see."

He knew from before his rebirth that his sister masturbated in her room. If she used vibrators besides fingers, that made sense.

What Elena didn't say was that she'd collected three vibrators named "Yuu-chan" No.1 to No.3 since about three years ago, until her reclusive phase.

"So compared to your beloved vibrator, how's my cock?"  
"Haaan! Sooo deeeep... ngh, deep!  
Of course, Yuu's is better... obviously! Ah, ah, annh! Yes! Yuu's penis, so big... so hot... aahn! I love it!"  
"Hoh... that's an honor!"

Yuu gradually increased his hip thrusts. Lewd squelching sounds came from their joining point. Restraint was now impossible. With each thrust that made slapping sounds, Elena's moans grew higher, her brown hair swaying. It was unfortunate her breasts weren't large enough to bounce, but that was fine. Burying his face in her neck and shoulder, Yuu greedily inhaled the mingled scents of shampoo and sweaty skin, his excitement building. Elena clung to Yuu, tossed about as the hard cock thrust deep against her cervix.

"Haa... annh! Yuu! Feels good! Feels so good! Big sis... feels... amazing! Aaaaaaah! Sooo... deep inside... ah, ah, ah, hyah annh!"  
"Kuhah... me too... nngh, too good... almost..."

Feeling his own limit approaching, Yuu leaned forward, putting weight on Elena while thrusting harder. Sweat beaded on his forehead, while Elena—her fair skin flushed red from heat—unconsciously wrapped her long legs around Yuu's waist, intensifying her moans.

"Agh! N-no! Fah... ah, annh! I'm... I'm coming! Aahn! Yuu! Please! Ejaculate! Inside big sis!"

Though lost in violently thrusting his hips, nearing ejaculation, Yuu stopped at the last moment. Cumming inside as Elena wished felt wrong somehow. In his original world, pregnancy risks meant creampies were reserved for partners he strongly wished to share a future with. But this world was different. With scarce men, women desperate for sperm considered creampies normal. Especially for brother-obsessed Elena, it would be her wish.

Yuu intended to let go of their pre-rebirth past. But he couldn't easily forgive how she'd misinterpreted the Akiko situation and gotten her fired. Though he'd had sex driven by lust, he had to reject his sister's wish at the final moment. This needed distinction from when he creampied Akiko, wishing her to get pregnant.

Yuu pulled his cock out just before ejaculation. Though her long legs were wrapped around his waist, he forcibly removed them.  
"Huh? Yuu? Wh-why pull out...?"  
Without answering, Yuu pressed his cock against her slit. It was sopping wet, making it overly slippery.

"Big sis likes being covered, right? I'll... splash it all over you!"  
"Eh, ehh!? No... inside, I want it insi... aahn!"

Yuu closed Elena's legs together, lifting her feet toward the ceiling. Then, like sumata (genital rubbing), he began thrusting his hips. Stimulating her swollen clitoris with his glans and coronal ridge, Elena arched back uncontrollably.

"Hyauun! No... I want it inside... ah, ah, nooo!"  
"That's it... just like this... nngh... I'm... cumming... guh, ah, kah... I'm cumming!"  
"Agh! Agh aaaaaaaah! Yu...u... annh! Annh! Hauu! Hot, so hoooot!"

With a final powerful hip thrust, Yuu reached climax, shooting thick white fluid—splash, splash—in forceful spurts. Viscous globs stuck to Elena's mouth, neck, and modest breasts, coating her white. Ultimately, while receiving Yuu's semen on her body, Elena reached orgasm, licking the cum from her mouth with her tongue, wearing an ecstatic expression.

---

### Author's Afterword

I rejected creampie as a small punishment, but splashing it on her body ended up being a reward too...  
Considering some S&M developments going forward, but I can only imagine Elena enjoying it blissfully...

### Chapter Translation Notes
- Translated "性処理(フェラ)" as "sexual service (fellatio)" to maintain explicit terminology while clarifying the act
- Rendered "童貞" as "virginity" for male context per world setting
- Preserved Japanese honorific "-chan" in "祐ちん" as "Yuu-chan" for intimacy
- Translated anatomical terms directly: "チンポ" → "penis", "おマンコ" → "pussy"
- Used "creampie" for "中出し" to match explicit terminology requirement
- Transliterated sound effects: "ぱさり" → "rustle", "ぐっちょり" → "sopping wet"
- Maintained original name order: "Hirose Yuu", "Hirose Elena"
- Italicized internal monologue: "（もうだめだ。止まらない！）" → "*(I can't stop now!)*"