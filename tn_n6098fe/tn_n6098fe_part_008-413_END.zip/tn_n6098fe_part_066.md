## 59. Siblings ④ ~Surely More Than Anyone in the World~

Pan! Pan! Paan!

"Ah, ah, aah! Yuu! So rough... don't thrust... like that... ahn! Big sister feels so good... I'm gonna... cum again!"

"Well, sis' pussy just feels too damn good.  
Kuu! My hips just won't stop!"

Elena's moans echoed through the living room along with the sound of flesh slapping together. Standing behind Elena who was bracing herself against the sofa, Yuu thrust his hips in a standing doggy-style position. After his spectacular ejaculation all over Elena's body, they had been embracing and kissing for a while, but as their skin touched, Yuu felt arousal building inside him again.

*(Maybe biological sisters really are physically compatible?)*

The incredible sensation inside his sister's vagina and the overwhelming pleasure during ejaculation remained strongly with Yuu even after time passed, and his instincts demanded more. Another erection was inevitable. When Yuu asked Elena to turn her backside toward him, she tilted her head but obediently complied. Her glistening wet vulva seemed to beckon him, and unable to resist, he plunged in to the hilt in one motion. Then he covered her from behind and pumped like an animal.

Though Yuu had started thrusting vigorously immediately after penetration, he came to his senses realizing he'd cum too quickly if he continued and slowed his movements. Sitting upright, he used long, deep strokes while taking in Elena's form from behind. Grabbing her modestly sized buttocks firmly from both sides to spread the joining area, he could see her pussy twitching as it gripped his thick cock. With each thrust of Yuu's hips, it made wet schlicking sounds while dripping with love juices.

Elena's caramel-colored long hair, though thoroughly disheveled from her head bobbing up and down, shone glossy under the room's lighting. Her nape looked temptingly sensual, and the curve from her back to waist was so smooth it was mesmerizingly beautiful.

While thrusting, Yuu ran his hands from her buttocks to her waist, then up her back. Then he touched her breasts from under her armpits. Modest mounds that fit perfectly in his palms. He kneaded them along with her nipples that had hardened from exposure to air. Instantly, Elena cried out "Aun!"

Pleased by her sensitive reaction, Yuu increased his thrusting speed.

"Hah, hah, hah... aahn! No... not like that... aahn! Yu-Yuu's cock feels sooo good... when you thrust deep like that... ah, nn... feels too good... my head... vuuun! Going completely... aaaaaaaaahhhhhn! I'm cummiiiiiiiiing!!!"

Right after climaxing, Elena's hips nearly gave out, so Yuu hurriedly grabbed her with both hands.

"Haa, haa... no more... can't... move..."

"Move forward a bit and grab the backrest."

Still connected, he moved her forward to grip the sofa backrest, causing Elena to lean fully over it. With her legs spread wide and knees planted, Yuu felt secure enough to start thrusting from behind again.

"Uu... aahn! Ahn, ahn! Good! Yuu's cock is the best... Oh, oh, I'm... gonna cum again... Yuu, does it... feel good inside big sister?"

Elena stuck out her tongue and looked back at Yuu with a seductive glance. Combing through her disheveled hair from behind, Yuu brought his face closer to answer.

"Of course it feels good, no question. Sis is an excellent sex handler. Honestly, it makes me want to ejaculate two, three times!"

"Aahn! I'm so happy! If Yuu wants... you can ejaculate... as many times... aahn! This time... I want you to ejaculate deep inside me!"

Whether Elena's words triggered it or not, Yuu felt his climax building. Massaging one breast while tightly embracing her slender body, Yuu pressed so close his face buried in Elena's long hair as he thrust. With each sharp slap of flesh, he felt his semen rising. Though Elena still wanted him to cum inside, Yuu wouldn't change his earlier decision.

"Haa, haa, alright, what should I do with you?!"

"Kyaa!"

A loud slap echoed.

Yuu had spanked Elena's buttock. Of course, he held back somewhat.

The sound of spanking rang out again.

"Aau! I-It hurts! Stop! Hii! Yuu! Nooo!"  
Ignoring Elena's pleas, Yuu alternated spanking both cheeks several times, leaving maple-leaf shaped red handprints on her pale buttocks.

"Ooh! Amazing! It's tightening up!"  
"Ah, ah, ahiiin... vuu, aau... even though it hurts..."  
"What's this, sis? Getting turned on by being spanked?"  
"Fua... no... ahn!"  
"Plus, when I spank you, inside clenches tight and feels absolutely incredible. Nn... kuh... I'm... gonna..."

Seizing the moment, Yuu began his final sprint, slamming his hips violently. Elena involuntarily threw her head back, tongue lolling from her open mouth as she moaned.

"Fuwaaaaah! Ohin hin! Sooo big! Swelling up! Thrusting deep! Zuun zuun! Oh! Aiiin! Iin! Good! Yu... uu... cum inside big sister! Ejaculate lots! Big sister's cumming too! Cumming! Cumming!"

"Gah... hah, hah... guh!"

Once again at the brink of orgasm, Yuu pulled his cock out and immediately moved to Elena's face, grabbing her head.

"Hae? Yuu, wha... mmguh!?"

He forcibly inserted his cock into her already open mouth.

"Here, I'll give you the semen you love so much. Drink it all."

Being so close to ejaculation, Yuu came after just a few movements in her mouth.

"Nmo... ooh! Oohb... nku, nkuu~"  
Elena obediently swallowed the thick semen as it poured into her throat. With each gulp, her slender neck moved visibly.

"Fuuuu... I'm seriously exhausted."

After his third ejaculation, Yuu collapsed onto the sofa. Elena, with her face buried in his crotch, continued sucking his cock. Schluup schluup, licking, she seemed determined not to leave a single drop.

"A~nchu, jupaa... hafuu, Yuu's seeeki, so tasty... nku, gulp... fuu. This is nice too... drinking it from your mouth~"

Ultimately, no matter what Yuu did, Elena seemed delighted. *(Then I'll enjoy all kinds of things with this beautiful sister from now on.)* Yuu thought, but as fatigue set in, he felt sleepiness overtaking him.

"Sis, sorry... I'm... so sleepy..."

"Ah, Yuu..."

Noticing Yuu's hand had stopped stroking her hair and hearing his faint murmur, Elena looked up. Yuu's eyelids were drooping shut.

"Ufufu. Yuu, you worked really hard tonight. Thank you for accepting me. Not only did we become one, but it felt so incredibly good I couldn't think straight... ufufu. Still feels like a dream."

"Ah... ah, big... sis too. Felt... really good..."

Hearing this, Elena sat up and hugged Yuu, sniffing his sweaty scent as her expression slackened into a lewd smile, rubbing her cheek against his.

"Since middle school, this was always my dream. Mom told me to try dating a classmate on a whim in high school, but they couldn't compare to Yuu. On Christmas party day, something unpleasant happened too... I came home and immediately assaulted Yuu while he slept... I think I've been messed up since then. A sister like me deserves to be hated. I even thought I wasn't worth living. But tonight, not only did you let that incident go, we had so much sex... I'm really glad I'm alive. Sex with Yuu was more wonderful than I imagined. Aha! Every part of Yuu is amazing - your voice, face, every inch of your body! Talking again after so long, your personality seems much more mature too, and I love that as well! Ah, Yuu is the most beloved boy in the whole world to me! Big sister will be your cock handler until the day I die! I'll do anything Yuu wants! Nn...? Ah, you fell asleep, Yuu."

Elena gently laid Yuu down on the sofa. The semen clinging to their bodies had started drying, so she reluctantly wiped it off before bringing a blanket from the room. Then she covered Yuu while lying on top of him.

"Wild during sex, but your sleeping face is as cute as ever... ufufu."

After a chu sound kissing Yuu's cheek, Elena closed her eyes while clinging to him.

---

"Nn...? Huh, where...?"

Feeling weight on his chest, Yuu woke up. Not his usual ceiling. Wait, he recognized this white ceiling and large lighting fixture. This was the living room.

Though covered by a blanket, his chest area bulged with brown hair peeking out.

"Come to think of it, last night..."

Memories of passionately coupling with Elena flooded back. After fiercely thrusting from behind on the sofa and ejaculating in her mouth, exhaustion overwhelmed him and he collapsed onto the sofa. He recalled feeling sudden sleepiness while talking with his sister, then losing consciousness.

Peeling back the blanket slightly, he saw Elena lying atop him, breathing softly in sleep. Though Yuu himself was naked, he realized he didn't feel cold because Elena had covered him with the blanket and was pressed close.

Filled with gratitude, Yuu stroked Elena's head and combed her hair, enjoying how it flowed smoothly between his fingers.

"Nn... fe?"

The touch seemed to wake Elena.

"Ah... re... me...?"

Apparently realizing she'd been sleeping on Yuu's chest, she suddenly lifted her head to look at him. One cheek pressed against his chest was flushed red, with strands of hair stuck to it.

"Good morning, sis."

"Hae? Ah... Yuu! Um, good morni... ah!"

Her sleepy half-lidded eyes widened fully upon seeing Yuu, her cheeks slackening into a lewd smile before she noticed their mutual nudity. Blushing crimson, she shyly lowered her eyes. Her rapidly changing expressions were amusing to watch.

"You covered me with the blanket after I fell asleep? Thanks."

"Ah... yeah. Mornings and evenings get cold, didn't want you catching cold."

"And we're both completely naked."

"Tha... that's right, ehehe."

Playing with her hair, Elena smiled bashfully. Yuu slowly sat up to face her. With lace curtains still drawn, gentle sunlight streamed in, making Elena's hair shine like gold. Her uncovered skin resembled fine porcelain in its whiteness. And she stared at Yuu with dewy eyes.

*(A goddess?)*

The thought crossed his mind, but Yuu silently leaned in and gently pressed his lips to hers.

"A good morning kiss."

It was a habit ingrained by Martina during childhood that the family used to share. Yuu had refused once he hit puberty and they stopped. To Elena, it felt like reconciliation and a new beginning for their sibling relationship.

"Aha! Yu, Yuu!"

After their lips parted, tears welled in Elena's eyes as she hugged him tightly.

"I love you! Love you! Love you so much! Big sister... loves you... more than anyone in the world! Mwah! Chu! Chu! Chu!"

"Mm! Nn, I get it... mm~"

Amid passionate declarations, Elena showered him with kisses. But an inorganic ringing interrupted them. Both looked at the intercom, but Yuu suddenly remembered: today was a weekday.

"Shit!"

The clock showed his usual departure time.

"Yes, yes. I'll be late today, I'll contact you when ready. Sorry."

After having Kanako convey his lateness over the phone, Yuu hung up. He considered skipping school entirely, but today was Tuesday with student council meetings. With the intramural sports tournament approaching, he wanted to avoid absence. Of course, he also wanted to see Sayaka and the other student council members.

Suddenly noticing his full nudity, Yuu thought he should get dressed—no, shower first—but turning around, he jumped to find Elena standing right beside him wrapped in the blanket. She spread her arms to envelop him.

"Sis?"

"See? Warm, right?"

"Ah, yeah."

"Ufu."

Their skin touching directly, Elena's warmth and sweet scent felt pleasant. Yuu closed his eyes and relaxed into it. But Elena began gently stroking Yuu's cock with her palm. Then she whispered sweetly in his ear.

"Ufufu. Yuu's cock has been big... all this time."

"Oh."

Actually, he'd had morning wood since waking. Elena must have noticed long ago, but being touched while told this now made it unbearable. She lightly gripped the shaft and began slowly stroking up and down. After raining kisses from his ear to neck and cheek, she peered at his face with mischievous eyes.

"Amazing. Rock hard since morning. Should big sister make you ejaculate?"

"Hey, sis..."

After subsequently pinning her down for another round, Yuu left for school two hours after waking up.  


### Chapter Translation Notes
- Translated "姉さんマンコ" as "sis' pussy" to maintain familial relationship while preserving explicit terminology
- Translated "性処理係" as "sex handler" to convey the assigned role dynamics
- Preserved Japanese sound effects through transliteration (e.g., "ぬっちゅ" → "schlick")
- Translated "朝勃ち" as "morning wood" for natural English idiom while maintaining anatomical accuracy
- Maintained explicit terminology for sexual acts per translation style guidelines
- Preserved Japanese honorific "姉さん" as "sis" to reflect Elena's speech patterns
- Translated "世界中の誰よりも" as "more than anyone in the world" to capture emotional weight of title phrase