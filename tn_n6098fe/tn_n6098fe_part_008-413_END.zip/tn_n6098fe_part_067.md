## 60. Siblings ⑤ ~Return to Myself~

"Welcome home, Mom!"

At the entrance greeting Martina returning from her three-day business trip were not only Yuu but also Elena, showing a slightly bashful smile.

"I'm home...ah...huh? Whaaaaat!? E-Elena!"  
"Yeah, welcome back."  
"Wh-what happened...not that it's strange but...uh, uh..."

Martina stood frozen in the entryway, her gaze shifting back and forth between Yuu and Elena.

Yuu explained again. "On Monday night after you left for your business trip, I decided to have a proper talk with Sis."

Of course, he kept hidden the part about his sister initiating a nighttime visit, how he confronted her about Akiko, and their subsequent physical communication.

"Now I can understand why Sis's emotions spiraled out of control."  
"Um, really, I was out of my mind back then... I wanted to get along with Yuu like before but couldn't..."  
Yuu placed a hand on his sister's shoulder as if to say "I know."

"We're family living together - it's no good staying estranged forever, and it makes Mom sad... Seems like Sis has reflected on things too, so let's consider last year water under the bridge. You understand now that what you said about Akiko-san came from a misunderstanding, right?"  
When Yuu looked at Elena, she nodded repeatedly. "That... about Akiko-san, I got overly emotional without considering Yuu's feelings..."

Yuu had suggested during yesterday's discussion that Elena write a letter apologizing and thanking Akiko for her care.

"I think... from now on I'll act properly like an older sister should. And... Mom, I'm sorry. Even though you were worried about me, I shut myself away and didn't listen."  
Elena, who had been looking down, timidly made eye contact with Martina and bowed her head.

"It's alright, Elena. Don't worry about it. Thank you too, Yuu. I never thought I'd see the day I could talk with both of you like this. Truly... I'm so... happy..."  
Martina beamed as she looked between Elena and Yuu's faces, but tears streamed down her cheeks.

"Mom..."  
"My... how strange. I'm happy, yet I can't stop crying."

Elena also teared up and approached. "Mama."  
"Elena."  
Though Elena's eyes had been dark when she suddenly accused housekeeper Akiko late that night, now - perhaps because her relationship with Yuu was repaired - her beautiful father-inherited eyes glistened with moisture. Delighted, Martina spread her arms and hugged Elena tightly.

Witnessing this beautiful mother-daughter embrace, Yuu's face also relaxed. However it happened, nothing beats family getting along. Come to think of it, even before his rebirth, Yuu had gotten along relatively well with his sister. As children, he often followed her around playing. Around middle school they naturally distanced themselves - daily conversations continued but neither crossed into the other's personal space. He'd thought that was normal for brother-sister relationships. As adults they could talk calmly, but he sometimes wished they'd been closer, more honest with each other when younger.

That said, current Yuu saw Elena less as a sister and more as a beautiful woman who stirred his desires. Evidence being that yesterday after returning home until past midnight, they'd coupled like animals in heat on the sofa, in the bath, and in bed. Though he didn't creampie her, he'd ejaculated all over her slender body and made her swallow while holding it in her mouth. With Mom home they probably wouldn't go that far, and given past events Yuu had ordered Elena to only engage when he initiated, but he wasn't sure how much self-control he'd have.

Noticing Martina watching him as he pondered this, "Yuu too, come here." She raised one hand invitingly.  
"Yeah."  
Though slightly embarrassed, Yuu moved closer and was hugged tightly by Martina along with his sister. Feeling their soft bodies and sweet scent nearly made him dizzy. Martina whispered in Yuu's ear:  
"Yuu... thank you so much. I love you."  
"...! M-me too, Mom."  
"Of course, Elena too. I love you."  
"Ah... I wanted to be like this with Mom and Yuu like before... I love you both!"

Even knowing this was familial love, his heart raced. Even knowing they were his biological mother and sister, Yuu couldn't help but be conscious of them as women.

***

After lingering in the entryway, they prepared dinner since it was already past 7 PM. Though the housekeeper had cooked it, they just needed to reheat side dishes and miso soup before serving - which Yuu did as usual. Because Elena had never done housework.

In this world, work and household roles aren't completely reversed but differ significantly from Yuu's original world. Essentially, it depends on one's upbringing. Children in single-mother households learn housework to help their working parent. But in families with males, mothers work outside while fathers handle housework or hire housekeepers if financially comfortable. Girls raised in such households never learn domestic skills.

Ultimately, since a key requirement for marriage is economic ability to support a man, families don't push girls to learn housework unnecessarily. Rather, it's common to hope they find income-earning jobs during high school/college while forming connections with men.

Not trusting Elena to handle things safely, Yuu assigned her to wipe tables and carry items under his direction. Even so, she seemed happy just preparing things together with Yuu, working cheerfully.

Tonight's menu was white rice, tofu and seaweed miso soup, grilled horse mackerel, simmered hijiki seaweed, boiled komatsuna greens, and chilled tofu - pure Japanese style. Since changing housekeepers, Western dishes decreased while home-style Japanese meals increased. This seemed a shock for Elena who preferred Western food. Served her right.

"Sis, not eating your fish?"  
"But... bones..."  
"Honestly. Fine, I'll debone it for you."  
"Yay! Thank you!"  
Seeing his sister avoiding the fish entirely, Yuu took her plate and removed the bones. Elena finally picked up her chopsticks after receiving the plate with backbone and small bones neatly separated. "Eat your vegetables properly too."  
"O-okay."

Martina watched Yuu and Elena chatting side-by-side with a smile, holding a wine glass with amber liquid. Though sake would better suit Japanese food, Martina enjoyed wine due to her mother's influence. Since they were having fish, Yuu and Elena discussed and prepared white wine.

"Hehe. Opposite of when you were kids."  
"Was it?"  
"Until elementary school, Elena would diligently take care of you like a big sister during meals too."

Elena chewed a piece of mackerel while pondering the past. "Now that you mention it... little Yuu was picky about food."  
"Eh... r-really...?"  
He couldn't immediately recall this body's childhood memories. "Bell peppers, carrots, green onions..."  
"I eat vegetables now!"  
"Hehe, you've grown up."  
Suddenly acting sisterly, Elena drew a counterattack: "Speaking of which, Sis barely ate while shut in, right? And ate stocked retort food at weird times. Bad for health and beauty. From now on let's eat properly together."  
"But I'll get fat."  
"Just eat normally. Sis would look fine with a little more meat. You're too thin now, see?"  
Yuu's hand slid from Elena's hip bone to her waist, then her rib-protruding side.  
"Kyan! Yuu, really!"  
"Wahaha!"

Watching Yuu and Elena playfully banter instead of eating, tears welled in Martina's eyes. She couldn't be happier to have lively family meals together again.

***

After dinner and a short break, Yuu began his training. Martina and Elena watched from the dining table. Previously, Yuu asked Martina to watch from a distance because "it's embarrassing," so this became their spot. For Elena who'd only heard about Yuu's self-training through conversations, seeing him work hard openly was delightful. Though she'd touched his body repeatedly during sex, recalling how his arms and thighs felt harder than before almost made her show a lewd expression.

"Hey, Mom."  
"Yes?"  
"Yuu really is handsome."  
"Hehe, stating the obvious?"  
"No, different. He's become even more handsome than before. Not just looks - his personality matured, he feels reliable... embracing somehow."  
"I know. Just between us, he slightly resembles his father Sakuya-san now. Maybe he's growing to look like him."

Both kept watching Yuu while talking about him. Though he'd be embarrassed to hear, he was too focused on running to notice.

"You know..."  
After watching Yuu awhile, Elena turned to Martina.  
"Yes, Elena?"  
"I want to study hard and take university entrance exams next year. Is that okay?"  
"Oh!"

In this era, university enrollment rates aren't high. Compared to Yuu's world (under 40% in 1990s, around 50% including junior colleges in 2010s), here it's about 20%. Consequently, employment, marriage, and childbirth start younger. Since Elena was academically excellent, university plans weren't surprising, but Martina was shocked she considered her future so soon after nearly half a year of isolation.

"Any particular career in mind?"  
"Hmm... nothing specific yet."  
"Oh? Didn't you want to be a lawyer or prosecutor before?"  
"Yeah. I just wanted qualifications to earn money for Yuu. But passing the bar exam isn't guaranteed, so joining a major company seems safer. I'm considering business or economics departments, but I'll research while studying. Anyway, I want to be Yuu's economic supporter forever."

If Yuu caused her isolation, he also became her motivation to recover. Her brother complex seemed to be progressing. But Martina thought it good she wanted to move forward positively.

***

Around 11 PM. Yuu quietly closed the changing room door behind him.

"Mom seems asleep."  
"Yeah."

Elena was already in pink underwear. Her hair, tied up during dinner, now fell near her waist after removing the hair tie. "Haven't cut it in ages, it's so long. Should get it trimmed."  
The changing area felt cramped with both standing. Facing her, Yuu reached behind to touch her hair. "I like Sis's hair long - it's beautiful."  
"R-really? Hehe. Then I won't cut too much."  
"Yeah."  
Naturally, they embraced. Elena smiled happily. "Wanna undress each other?"  
"Yeah, sure."

Yuu unhooked her bra clasp with his hand behind her. The shoulder straps slipped off, gradually revealing her breasts. Since they were modest, they didn't sway when the cups came off. Well, men here rarely praise large breasts, so she didn't seem bothered. Yuu liked both big and small anyway.

While staring at her pale pink nipples, Elena suddenly pressed her lips against his. Her hands were already on Yuu's pajama pants, trying to slide them down with his underwear. Yuu returned the kiss while squeezing Elena's small buttocks. As they rubbed and squeezed each other's buttocks while pressing their lower abdomens together, they lowered their underwear halfway.

"Mmm... fuam... ah... juru, chup, chu, juruu~ haan..."  
As their passionate kissing intensified, tongues intertwined. Peeking, Yuu saw Elena's cheeks flushed pink. "Ahn... Yuu's dick is hard."  
"Let me see... Sis is already wet too."  
"Aahn, because... just hugging Yuu like this... no, different. Just thinking about Yuu gets me..."  
"Sis really is a perverted slut."  
Pulling her panties to her thighs, Yuu's right hand slid along Elena's slit from behind - *kuchu kuchu* sounds followed.

"Y-yeah. Big sis is a perverted slut in front of Yuu... ah! Ah! Hakun! Y-Yuu too... your dick is so hard and hot..."  
"Ooh."

Elena stroked Yuu's entire cock with her palm before lightly gripping the shaft and jerking up and down. Not to be outdone, Yuu used both hands to play with her nipples and pussy. They continued mutual fondling standing up. When Yuu's right finger traced her slit and rubbed her clitoris with his fingertip, Elena gasped "Haun!" and jerked.

"Sis, your voice."  
"Un... feels so good when Yuu touches me... mmph."

Resigned, Yuu silenced her with a kiss. His right finger thrust deep into her vagina until the webbing was slick with love juice. Meanwhile, precum dripped from his cock, making sticky sounds each time Elena stroked it.

"Ngaauu... nn, nn, muf! Vuun! Ii, vu, muu-nn, nn, nn, nnn!"  
When Yuu inserted his finger deep, bending the first knuckle to stimulate her, Elena trembled intermittently with muffled moans. But she kept jerking him without pause, so Yuu's pleasure also built. He planned to ejaculate on her upper body as she wanted.

But this was the changing room with a washbasin nearby - giving Yuu an idea. Stopping his fondling, he whispered to his sister after breaking the kiss:  
"Sis, put your hands on that."  
"U...nn?"

Elena faced the mirror as instructed, hands on the basin edge. Yuu stood behind her, grabbing her buttocks. "Stick your butt out a little."  
"Like this?"  
"Yeah. Perfect."

Since Elena was taller, rear entry required adjustment. But after rebirth and multiple female experiences, Yuu grew to like doggy style too. That said, he wouldn't penetrate this time - her loud moans might wake Mom.

Yuu removed his underwear for easier movement and rubbed his cock shaft directly against her vagina, the tip protruding between her thighs. In other words, dry humping.

"Ah... your dick...?"  
"Gonna move now. Here."  
"Ah...nnn."

Holding Elena's hips, Yuu thrust back and forth. Moving too wide risked slipping out, so small movements worked better. "Feels good. Your pussy's slippery. Plus I can see your turned-on face in the mirror."  
Perhaps because her sensitive spot was rubbed by his hard cock, Elena's reflected face showed drooping eyes and a lewd expression. "Ah... haa... even without penetration... feels good... nn... aah! Wai...t, me too... ha! Ah, it's hitting... the good spot... aahn!"  
Apparently the upward-angled cockhead rubbed her swollen clitoris.

"Sis, you're loud."  
Saying this, Yuu played with one of Elena's nipples. Small breasts are still breasts - men instinctively want to touch them. "Bu...but... mug... uun! Yu...u... nn, mmu!"  
Elena covered her mouth, but Yuu mercilessly kneaded her nipple and rubbed her clitoris, drawing out moans. Enjoying the soft flesh sensation while rhythmically thrusting, *nucha nucha* lewd sounds emerged, heightening Yuu's excitement. Speeding up, *bitan bitan* butt-slapping sounds echoed. Yuu's rational side worried Martina might hear, but his hips wouldn't stop. Brushing aside Elena's swaying hair, Yuu pressed flush against her back. Wrapping his arms around her front, he clung tightly, savoring his sister's scent while thrusting desperately.

"Aah, Sis, Sis! Feels so good!"  
"Nfu, nfu, nn, nn, Yu...u! Me too... good! So good!"

Their near-vertical dry humping soon reached its limit. "Kuh... I-I'm cumming, Sis... ah, ah, CUMMING, u!"  
After violently slamming his hips *pan pan pan pan*, Yuu reached climax. That instant, he arched back with Elena. A thick glob of semen leaped high, landing near her face before sticking to her collarbone with a *bechaa*.  
"Aann!"  
Consecutive *bechaa, pechaa* sounds followed as hot white liquid splattered from her breasts to stomach.  
"Ahn! Ahn! Amazing! Haaan... so hot... ahhaaaaaa... ah, fu... uun... so... good!"  
Drenched in Yuu's spray, Elena came trembling. Opening her eyes, she saw her semen-covered reflection - viscous strands dripping down to her mons pubis. Touching her breast, thick semen clung to her fingers. She put it in her mouth and sucked. "Ahm... nchu... haa... Yuu, the best..."

Different from sex's intensity, this ecstasy reminiscent of her first orgasm four years ago intoxicated Elena as she wore a blissful expression.

***

---

### Author's Afterword

Part 2 ends here.

Before I knew it, it surpassed 20,000 points and 3 million page views - becoming my most read and highly rated work. I'm truly grateful. I've received far more impressions than expected, which encourages me to continue updating.

As the author, I had various thoughts upon finishing Part 2, but since it would get long, I wrote them in my activity report. Please read when you have time.

https://xmypage.syosetu.com/mypageblog/view/xid/175790/blogkey/224938/

Regarding Part 3, I'll take one update break and resume after May 1st. Though it's Golden Week, I have real-life plans during the first half and holiday work shifts (no 10-day vacation for me). Also, during GW I plan to add content to "Part 0: Settings & Materials."

Currently, Part 3 will feature daily events centered around home, school, and hospital while gradually showing changes in the protagonist's world. Thank you for your continued support of *Reborn in a Chastity Reversal World*.

### Chapter Translation Notes
- Translated "素股" as "dry humping" to maintain explicit terminology for non-penetrative genital contact
- Rendered sound effects literally (e.g., "dopyuu" for どぴゅう, "pan pan pan pan" for ぱんぱんぱんぱん)
- Preserved Japanese honorifics (-san) and name order (Hirose Yuu)
- Translated "おチンチン" as "dick" and "マンコ" as "pussy" per explicit terminology requirement
- Maintained original dialogue structure with new paragraphs for each speaker
- Italicized internal thoughts like *(This is concerning.)* per style guide