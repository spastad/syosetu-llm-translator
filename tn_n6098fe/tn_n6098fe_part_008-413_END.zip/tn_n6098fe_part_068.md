## 61. A Morning Incident ~SINKY-YORK~

### Author's Preface

This marks the beginning of Part 3.  
A minor note: I've changed the part title to "Enjoyment" for Part 3.  
Also, I've updated the character introductions as of the end of Part 2.  

---

Saturday morning.  
Despite having school preparations, Hirose Yuu woke up first with time to spare.  
After drinking a glass of water, he did light exercise and strength training on the treadmill.  
After finishing breakfast with toast, he first opened the bedroom door.  

A king-size bed, a vanity, and closets lined the wall, but the roughly 12-tatami bedroom had ample space.  
Lying face-up on the bed, sleeping in an intensely alluring pose, was Martina.  
The blanket only covered up to her stomach, exposing her large, voluptuous breasts.  

*(Damn, they're huge no matter how many times I see them...)*  
Even though she was his biological mother, he couldn't help staring - it couldn't be helped.  
"Mom, morning."  
As usual, she didn't wake immediately when Yuu called.  
"Mom, wake up."  
His hand, which almost went for her chest, grabbed her shoulder instead and gently shook.  
"Uuunnn..."  
With a sensual sigh, Martina turned sideways. Her wavy long black hair flowed over her cheek as her breasts bounced sideways.  
*(Whoa...)*  
He couldn't help staring, but he needed to wake her.  

So Yuu employed one of his proven methods to wake Martina.  
He leaned close, brushed the black hair from her ear, and whispered:  
"Mom, please... wake... up!"  
Then, Martina's eyelids slowly opened.  
"Nn... faa... Yuu..."  
Her expression softened when she realized Yuu's face was right there. Martina reached out to stroke Yuu's cheek and head.  
"Still... sleepy..."  
"But you have work today, right?"  
"Aahn, I know. Hey, Yuu-chan, wake me up?"  
He must have misheard "wake me up" as "violate me."  
"Can't be helped, Mom."  
Yuu smiled wryly and covered Martina as she lay face-up, wrapping his arms around her back. Martina also wrapped her arms around him.  
"Waking you up now. On three!"  
He lifted Martina's upper body while still holding her.  

"Thanks as always."  
"You're welcome."  
Martina smiled brightly, threw off the blanket, and tried to get out of bed. Not only did her long, slender legs stretch out, but her black lace panties came into view too. She wore only a silk pajama top with just the middle two buttons done, creating a deep cleavage between her ample breasts. Her navel was visible with every movement. Even with the recent temperature rise, this outfit was visually dangerous. But since she felt no embarrassment about it, nothing could be done.  

*(My mom's too erotic - suppressing reason while waking her is tough)*  
He muttered a light-novel-worthy thought in his mind.  
"Now I'll go wake Sis."  
"Fufu. Elena might actually get up obediently if Yuu-chan does it."  
"Well... maybe."  

After hearing Martina head to the bathroom from the hallway, Yuu opened his sister's door and muttered:  
"Now, this one's the tough one."  
Though Elena had adapted to a completely reversed sleep schedule, she'd declared she'd return to mornings to study for university entrance exams. Still unable to wake alone, someone had to wake her daily - naturally falling to Yuu.  

He'd never forget the shock of seeing Elena's room the morning after their intense night together. It was a complete pigsty from her long isolation. With Yuu's help, it had finally become presentable over the past three days. He'd made her throw out the stained body pillow. The pillow had featured an anime character resembling Yuu, but he ignored that. He'd also tolerantly overlooked the scattered vibrators, pink rotators, and erotic books featuring younger brothers and shota, so they were probably hidden under the bed. They might use the vibrators labeled "Yuu-chan No.1-3" during their sessions.  

Elena slept face-down wearing her high school short-sleeved gym clothes as pajamas. Her light brown hair spread messily, hiding her face. Instead, her hem had ridden up, fully exposing her white floral panties and slender bare legs. A completely defenseless rear view. Yuu sat on the bed's edge and lightly slapped her butt.  

"Sis, morning~"  
No reaction. As usual.  
"Sis, wake up!"  
This time he tried rubbing her butt while speaking, but she didn't twitch. Still unaccustomed to morning life, Elena was worse than Martina at waking.  

"Good grief."  
Yuu shook his head, then fully climbed onto the bed and straddled Elena's hips. Covering her, he brushed aside her hair to expose her pale nape and ear, then whispered like he did with Martina:  
"Sis, morning. Time to wake... up?"  
"Nn... uu... nn..."  
She moaned slightly but didn't wake. Lately, Yuu suspected she pretended not to wake - enjoying the skin contact until she got up. Maybe she'd gotten spoiled by his gentle wake-ups.  

"If you keep taking advantage like this..."  
Smirking, Yuu lifted her gym clothes to expose her less fleshy sides and gently began tickling with both hands.  
The effect was immediate.  
"Hyah! Ihii! Uhyahyahya... ticklish... hyan!"  
"Come on, time to wake up."  
"Hahi, nhii... nn, aai, wa-wa-wakatta... ah, ya, stop... nn, feee... a, a, ahi... hiin!"  

As her voice gradually turned sensual, Yuu stopped. He hugged her from behind and lifted her entire body.  
"Aahn, that was intense this morning."  
Leaning back against him, Elena giggled.  
"Well, you wouldn't wake up."  
"Nn~ still sleepy. Yuu, wake-up... service?"  
"Really, Sis is such a spoiled child."  
"Nfufu."  
After combing her messy hair down her back, Elena gave him a sidelong glance. Yuu took her chin and covered her lips. After a brief kiss, Elena wrapped her arms around Yuu's head and kissed back. Chu, chu, chu - about three times.  

"Morning, Yuu."  
"Morning, Sis."  
"Nfufu. Happy from morning."  
"Hahaha."  

Thus began the Hirose household's morning.  
Breakfast was usually toast. Martina couldn't eat immediately after waking, so Yuu prepared drip coffee including hers. Yuu always toasted two slices of 8-sliced bread, spreading margarine or blueberry jam. Elena ate one untoasted slice with strawberry jam and milk. She'd loved milk since childhood - it made her tall but apparently didn't affect her breast size.  

Both Martina and Elena sat dazedly with bedhead, but since they were at the table, Yuu began his own preparations. He wanted to thoroughly admire their revealing outfits, especially their legs, but couldn't miss the school bus.  

After changing and preparing, Yuu returned to the living room. Martina and Elena had already finished eating and seemed to be watching TV. The 32-inch CRT TV had shown the weather report earlier, but now news began. A young female announcer started reading yesterday's events with a serious expression.  

"Ah! I forgot to tell you both something!"  
Martina looked away from the TV, alternating between Elena and Yuu.  
"Huh?"  
"What, Mom?"  
"Remember before Yuu was born? We had mom friends living together?"  
"When I was... around two? Honestly don't remember much."  

Naturally, Elena couldn't recall things from age two. Martina brought over a photo displayed on the chest. Two women held babies in front - one was Martina around twenty, the other a petite, beautiful girl with platinum blonde hair. Behind them stood a woman with wavy, abundant black hair and a beaming smile - resembling Martina but taller and older-looking - holding a toddler.  

"Fufu. Seventeen years since this, huh?"  
Yuu had been told before: the platinum blonde girl was Finnish Suzanna, the long black-haired woman Italian Emmanuela. They were wives particularly close during the marriage. Martina held baby Elena; the other baby was named Saira. The two-year-old toddler was named Anna.  

"After Sakuya-san died, Emmanuela stayed in Japan awhile but returned to Italy. We still exchange letters sometimes - she sends beautiful postcards. Suzanna happened to move to Hokkaido with a Japanese wife friend and still lives there. Now Saira-chan - same age as Elena - got a job there but has training at Tokyo headquarters, so she's coming for two weeks in June."  
"Saira-chan... uun, kinda remember vaguely..."  
"You'll remember when you see her? She sent a high school entrance photo - looked just like Suzanna."  
"Huh."  

Yuu examined the photo again. The girl had an ethereal, fragile beauty unbefitting a mother. He wanted to meet such a beauty visiting Tokyo.  
"That's why I said: 'Come stay with us since we haven't met in ages.'"  
"Ooh!"  
"Ah, I see."  

Only Yuu showed genuine delight; Elena looked slightly conflicted.  
"What? Don't want to meet?"  
"Ah... no, not that. Just... it's been so long, feels unreal. Ahahaha."  

Martina sighed. She recalled Elena was introverted with few friends. Probably because of Yuu, she'd never brought friends home. But Yuu guessed: Elena didn't want him meeting Saira, who resembled Suzanna.  

So Yuu deliberately voiced support brightly.  
"Great, right? Daughter of Mom's old friend. I welcome her."  
Hearing this, Elena couldn't openly oppose.  
"W-well, I don't dislike meeting her! Just... been isolated so long, I'll probably be nervous."  
Martina looked relieved.  
"It's fine. Elena will warm up quickly. Actually worried what Yuu would think - glad it's okay. I'll confirm then."  

As the conversation settled, Yuu's eyes naturally shifted to the TV. The screen showed a chaotic scene: countless women wearing headbands and holding placards and banners. The announcer explained:  

'Last night after 7 PM, over ten thousand women gathered for this demonstration before the Prime Minister's residence. While the government pushes bold policies via new laws against population decline - a common developed-world problem - opposition parties and civic groups protest that women's rights are threatened...'  

Even in his previous life, Yuu had seen intense protests on news. Apart from 60s-70s student protests before his birth, Japan rarely had large-scale demonstrations - maybe 2010s Okinawa base or nuclear plant issues. Though that might just be Yuu's political disinterest. Unlike his vague memories, protesters were mostly women aged 20-40. Their slogans and placards featured unique demands:  

'Relief for female-led families suffocating under heavy burdens with no future!'  
'Give all women opportunities for love, marriage, and childbirth!'  
'FREE SEX!'  

The placards showed crude drawings and flashy lettering. Yuu wondered if they should broadcast images like men surrounded by women with bold pink "SEX" or "BABY" lettering.  

Various anti-government groups seemed gathered, claiming 20,000 attendees. Even accounting for exaggeration, aerial shots showed crowds spreading beyond the plaza into nearby streets. As the announcer said, at least 10,000 people seemed gathered. Such numbers suggested many women here were dissatisfied.  

"The movement itself opposing national male protection/maternal emphasis policies and advocating women's rights has existed for decades. Now it's opposition parties' platform. I get it, but their ideals lack realism, so they haven't gained wide support. But the 'Male Inclusion Movement' - an extreme ideology from mainland China - gained momentum these past 7-8 years. Starting as minor civic groups, they formed parties and got a few Diet members. Anti-government media coverage and alliances spread it nationwide."  
Martina, working at a newspaper, knew well. Groups ranged from moderate to radical.  

"Huh. What do you think, Mom? About these anti-government claims."  
When Yuu asked, Martina looked at him with completely serious expression.  
"Personally, of course I oppose. Their demands boil down to women choosing men, not men choosing women. Meaning 'distribute men to as many women as possible'! Regardless of marriage or age! Unbearable for mothers like me with sons!"  
"Eh! Making Yuu service unknown women? Absolutely not!"  
"R-right..."  

Yuu didn't mind - even wanted to try (depending on the woman) - but it would be tough for average men. Martina explained: originally a moderate movement for women lacking male partners, it radicalized as numbers grew. Demands escalated for broader support. Sounded familiar.  

On screen, representatives gave interviews. One 40-ish woman spoke vehemently; the caption read "Male Inclusion Movement Promotion Union - Tokyo Branch Representative":  
'We know children are taken from mothers under arbitrary "poor parenting" judgments! We know men are confined under "genetic management"! With so many women adrift, how can the state isolate men! Excessive male protection steals love/marriage opportunities from women!'  
Mid-speech, a popping sound cut the screen to black. Martina had turned off the TV.  

"Look! Isn't it almost school time?"  
"Eh... ah!"  
The bus arrived in ten minutes. He'd been too engrossed.  

"Then I'm off. Going to the hospital this afternoon."  
"That... the sperm donation (献精) you mentioned?"  
"Yeah."  
"But that's only every six months... no need to push..."  
"It's fine. Want to contribute to society."  
"Ah."  

Instead of farewells, Yuu hugged seated Martina and kissed her cheek.  
"Geez..."  
Blushing slightly, Martina kissed back.  
"Yuu! Big sister too!"  
"Haha, got it."  
He hugged his standing sister. Stroking her head, enjoying the silky hair, he kissed her cheek. Elena rubbed cheeks with him before chu, chu kissing his cheeks back. Short on time, he pulled away as Elena gazed longingly.  

"Well, Mom, Sis, I'm off."  
""Have a good day!""  

Smiling, Yuu waved, shouldered his backpack from the chair, and left. Opening the door to the shared entrance, Kanako and Touko already waited sharply dressed in black suits.  

""Good morning! Yuu-sama""  
"Morning, Kanako-san, Touko-san."  
"Shall we go?"  
""Yes!""  

Sandwiched between them, Yuu headed to the elevator hall. As mentioned to Martina, he had a sperm donation appointment that afternoon at the city hospital, having requested Shiho and Mio as attendants. Such flexibility was likely due to his exceptional semen analysis results. Yuu looked forward to seeing the nurses again after so long.  

---

### Author's Afterword

I've changed the term "semen provision" (精液供出) used in Chapter 7 to "sperm donation" (献精).  

This time, I imagine the subtitle's meaning might be unclear, so let me explain.  
"SINKY-YORK" is pronounced "shinky-yook" → "shinkyoku" → "new song" (apparently true).  
From there, I intended it to mean "new phase."

### Chapter Translation Notes
- Translated "献精" as "sperm donation" per Fixed Reference Terms
- Preserved Japanese honorifics (-san, -chan) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "ぼよよん" → "bouncy bounce", "ちゅっ" → "chu")
- Rendered internal monologues in italics (e.g., *Damn, they're huge...*)
- Translated explicit anatomical terms directly ("breasts", "panties")
- Maintained dialogue formatting rules (new paragraph per speaker)
- Translated subtitle "SINKY-YORK" literally with explanation in afterword