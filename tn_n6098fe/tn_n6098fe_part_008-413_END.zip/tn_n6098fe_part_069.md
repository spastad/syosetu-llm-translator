## 62. Sperm Donation ① ~Dream Legend~

### Author's Preface

I've interrupt-posted "Worldview/Term Explanations" in "Settings/Materials etc."

Since it's mostly textbook-like stiff writing, it's not necessary to read it to enjoy the main story. If you have time and enjoy settings, please do.

---

After returning home from school in the morning, Yuu had a quick lunch at home before being driven to a general hospital in the city by his protection officers. When he called to make the reservation the other day, he was told to come to the back entrance night reception window. Or rather, whenever Yuu visited this hospital, he never used the main entrance. Presumably to avoid contact with female patients and their families.

When Yuu arrived, he was met by a plainly dressed middle-aged woman in a suit. Apparently someone important from the administration.

"We are truly delighted to have someone as exceptionally outstanding as Yuu-sama use our hospital this time."  
"Ah, no need for such..."

Being bowed to so deeply made Yuu feel rather embarrassed. What made him "exceptionally outstanding" was surely about his semen. Did the hospital benefit from collecting good semen?

Since the middle-aged woman and two hospital security guards would accompany him, protection officers Kanako and Touko were asked to wait in the car. They proceeded directly to the VIP room on the hospital's top floor. The administrative woman tried to make conversation along the way, but naturally avoided private topics, sticking only to harmless subjects.

When the topic shifted to hospital matters, Yuu learned that due to the increasing number of nurses he'd interacted with during both his hospitalization and check-up visits, a fan club of sorts had formed, making him blush. Apparently, many women had become captivated by Yuu - unusually tolerant for a male patient, always greeting them with a smile.

"If you continue using our hospital in the future, all staff will wholeheartedly welcome you."  
"Haha. Well, it's close to home, and all the staff here are kind and excellent. I'd like to continue relying on you too."

When Yuu said this with a shy smile, not only the administrative woman but even the security guards flanking them smiled happily.

Upon reaching the door to the VIP room floor, the administrative woman said:  
"Since it's your first time, they said they'd give you an explanation beforehand. I apologize for taking your time, but thank you for your understanding."  
"Ah, I see. Understood."

Yuu nodded obediently, accepting this as standard procedure. "Then I'll take my leave here. The security guards will wait on this floor, so please call them when you're finished."  
"That's... thank you for going through the trouble."  
"Not at all, please don't worry about it."

Yuu calmly bowed and opened the door to enter the floor. The administrative woman who bowed to see him off raised her head and murmured admiringly: "For his first sperm donation at that age, most would be tense and anxious, but he's quite something." The two security guards nodded in agreement.

Though it had been over two months since his hospitalization, this was the same room where during his final check-up in late April, he'd brought Mio and enjoyed a threesome with Shiho who joined later. It seemed extravagant treatment just for providing semen. But in this male-scarce world, perhaps men like Yuu with superior semen donating sperm was itself highly welcomed.

As Yuu was thinking this and opened the door, he noticed two women sitting in the spacious room, halfway to the right, in front of a black leather sofa. When they noticed Yuu entering, they turned and stood up smoothly.

"Well, well... thank you for your cooperation today. Now please, have a seat? We'd like to talk for a bit."  
"Ah, yes."

The two women bowed in unison and gestured toward the sofa opposite as Yuu approached. On the low table, documents were neatly arranged for three people.

"I am with this organization," they said, handing him business cards in turn. Out of habit from his working days, Yuu immediately thought he should offer his own, then remembered he didn't carry cards as a student.

To Yuu's left was a woman around 30 with her hair up, wearing red-framed triangular glasses. About the same height as Yuu. Dressed in a white open-collar shirt and dark green tight skirt. Not only was she impeccably made up, but her deeply opened collar hinted at cleavage. Combined with her figure that stirred male desires, she exuded a mature sensuality despite her professional appearance - reminiscent of a teacher in adult videos from his original world. Her card read: "Ministry of Health, Labour and Welfare, Insurance Bureau, Birth Division, Chief - Inui Rumiko." She was quite different from Yuu's image of a bureaucrat.

The woman on his right was a contrast. Thick round glasses and twin braids. Dressed in a light gray pantsuit, she looked almost like a student. Barely over twenty? Her short height enhanced the childish impression. Her trembling hand offered a card that read: "Japan White Cross Society, Saitama Branch - Yanai Miku."

Side by side, they resembled a teacher and her student. Facing them directly, their attitudes were polar opposites. Rumiko wore a relaxed smile while scrutinizing Yuu as if appraising him. Meanwhile, Miku covered her mouth with her hand in flustered agitation the moment she saw Yuu. She looked down immediately, then glanced at Yuu only to avert her eyes again. Young women seeing Yuu up close for the first time often acted this way - unmistakably virgins with no immunity to men, Yuu thought.

"Now, let's start with Yanai-san."  
"Y-yes! Th-th-then, I'll ex-explain..."  
"Calm down."

Rumiko gave a wry smile at Miku's obvious nervousness in front of Yuu, patting her back with a *pon pon* to help her relax. After clearing her throat once *gohon*, Miku began her explanation.

"Please look at the materials we provided. Um... these partially overlap with the documents we mailed after your application, but I'll review the key points."

From ancient times until the modern era, childbearing was achieved through one-sided intercourse with men - sharing few men within a community. But entering the 20th century, with advances in artificial insemination technology and rising male protection ideology, the tide changed. Meaning it became possible for women to have children without forcing intercourse that ignored male consent.

This required cooperation from young men - freezing semen in sperm banks for management. The Japan White Cross Society was established for this purpose. The annual April health checkup includes semen analysis, and except for those deemed ineligible (azoospermia), males aged 10-29 (sometimes up to 39 depending on condition) are obligated to donate sperm every six months. The Japan White Cross Society accepts donations at branches in each prefecture or national health insurance centers, and also at designated hospitals. The general hospital in Saitama City where Yuu now was, was one such facility.

"Though not detailed in the materials, if you cooperate with donations beyond the mandatory every six months, you'll receive performance-based rewards!"  
"Oh ho."

As she spoke, her stiffness faded and her words flowed more smoothly. "I saw the semen analysis results for Hirose-sama with the 'Excellent (Special)' rating! Amazing! So many lively tadpoles swimming vigorously! Meeting someone like Hirose-sama with such wonderful semen today has me over the moon... and such a handsome man too... *sigh* it's like a dream~"  
"Hahaha."  
"Ah, sorry."

Miku, getting excited, was nudged by Rumiko's elbow and seemed to regain her composure.

"S-so, about that~. We'd like to request regular donations from Hirose-sama going forward..." She tried to glance up coquettishly, but her thick lenses made it hard to tell. For Yuu, whether paid or not, he had no objection to cooperating. After all, it also gave him reasons to see Mio and Shiho.

"Ah, no, you don't need to answer immediately. Please consider it carefully after completing today's donation."  
"Yes, understood."  
"But just as an example, let me show you. If Hirose-sama were to donate monthly, payments would be every six months, so the amount would be this."

After tapping *pachi pachi* on a calculator, the displayed figure made Yuu wonder if the zeros were wrong. It showed 300,000. From Yuu's memory, high schoolers in this era working part-time jobs earned at most 40,000-50,000 yen monthly. Yet this was what he could earn just by donating once a month.

"That much..."  
Yuu was speechless, but Miku said nonchalantly: "Teenagers rated 'Excellent (Special)' are rare to begin with, and you voluntarily applied! This is only natural! Ah, if six months passed without donation, we might have come to ask. Then we could've offered even better terms..."  
"Haha, this is plenty. The hospital kindly prepared this VIP room too."  
"Muu... Hirose-sama is so selfless..."

After explanations about how donated semen would be stored separately from personal information so recipients wouldn't know the donor when used for fertilization (thus no connection to resulting children), and a Q&A session, they finished.

"I'll excuse myself now. Thank you very much today."  
"Not at all. Thank you for the informative talk."

Apparently only Miku would leave first. After Yuu returned her thanks, she bowed repeatedly *peko peko* and left the room.

Thus, Yuu was left alone facing Rumiko. Facing this teacher-like woman made Yuu feel like he was in a guidance counselor's office.

Now she crossed her long, bare legs right before him. A man couldn't help but let his eyes follow them. Whether aware or not, Rumiko smiled bewitchingly.

"Now, what follows is important information we can't share with others. There might be difficult topics for Hirose-sama who just entered high school, but if anything's unclear, feel free to ask, okay?"  
"Haa. Secrets we can't tell others?"  
"Hmm, perhaps only your family if you do tell."  
"Ah, yes."  
"Fufu. That's right, don't tense up. The thirty-third son of the late Toyoda Sakuya?"  
"Huh?"

A moment of silence passed. Yuu had heard about his father from Martina. Though he had 20 wives and over 30 children before dying, Martina said wives hadn't borne many sons. Still, in this world, some hid sons' births like Yuu or raised them as girls outwardly.

After realizing she was pregnant following her husband's death, Martina left their home and gave birth in Izu. She then returned to her maiden name and lived with her parents. Yuu had almost no memories from that time - by the time he became aware, they lived in a Saitama apartment. Since no one mentioned his father, he never thought about it. Perhaps there were media inquiries, but Martina likely shielded the children.

"About that... I haven't heard details... so I have... um... 32 half-brothers?"  
When Yuu asked, Rumiko picked up a thick file stamped ㊙ in red and flipped through *para para*. "Since the gender balance collapsed, reliable male data only exists from modern times, but no man has matched Toyoda Sakuya's astonishing number of female partners. None before or since. That's why a year after his death, part of his estate was transferred to establish the Toyoda Sakuya Memorial Foundation to compile his achievements."  
"Eh? I didn't know that."  
"Well, most involved parties are still alive, and with young males included, information is mostly classified."  
"I-I see."

Closing the ㊙-stamped file and placing it on the table, Rumiko picked up another file. "By the way, Hirose-sama, do you know Japan's current population?" The sudden topic change flustered Yuu. He recalled checking at the library that it was about 70% of his previous world's population.

"I think... around 80 million?"  
"Yes. It exceeded 80 million in the late 20th century, but gradually declined as the economy worsened. After the Related Laws for Countering Low Birthrate took effect in 1980, the population stabilized but slightly increased the year before last."  
"Ooh."

Yuu thought this world's government seemed more competent than his previous one's for taking immediate effective measures, but Rumiko's expression remained grim.

"The problem lies elsewhere."  
"Elsewhere?"  
"Do you know Japan's gender ratio is roughly 1:30?"  
"Yes."  
"Last year's statistics show 1:32 at age 18. Meaning in 1,000 people, 30 are male. But recent newborn surveys are worse. The latest data shows 1:39 - only 25 males per 1,000. Meaning the male decline isn't stopping - it's worsening."  
"Eh?!"  
"Meaning even with slight population recovery, if males keep decreasing proportionally, we may eventually lose all control. Predictions say in 30 years Japan will have 65 million people with a 1:50 gender ratio. Well, developed countries all face similar issues."

When Yuu realized he was reborn in a male-scarce world, he simply rejoiced. Being an unrelated handsome boy with the same name brought incredible popularity. Even without good looks, this female-surplus world offered an environment with no female shortages - joyous from his original world's perspective.

But looking broadly, this world's problems were severe. His previous world faced declining birthrates and aging populations, becoming pronounced around the 2010s. Here it started earlier due to male scarcity. Even with new laws for fundamental reform, if male decline remained unstoppable, what could be done?

Seeing Yuu looking down pensively, Rumiko glanced at him and reopened the ㊙-stamped file, flipping *para para*. Finding her target, she smiled with red-rouged lips.

"Back to our topic. Sakuya had 20 wives. Born were 5 sons and 32 daughters."  
"Eh? Mother said I was the first son."  
"Ah, that's because she likely told people you were a girl until a certain age. Probably you too right after birth. And because of the uproar after Sakuya's death, it wasn't widely announced."  
"I see."

In this world's Japan, having a son was a 1/30 probability - joyous for mothers but also stressful.

"Sakuya had unbelievably many partners beyond marriage. He claimed to have lost his virginity to a school teacher at 10, then 'fucked like crazy' with elementary/middle school classmates, seniors, juniors, teachers, and neighborhood women. Over 20+ years until death, he had 500-600 partners - too many to count accurately. Children with wives, extra-marital acknowledged children, and those later confirmed through reliable testimony - though many women claimed posthumous pregnancy seeking inheritance or fame (mostly false) - total 33 sons, 169 daughters, 202 confirmed. More likely exist overseas."  
"Amazing..."

A modern Don Juan or Casanova. Yuu had seen magazine/TV features about his father beyond Martina's accounts. Though Martina warned him not to believe exaggerated rumors and legends, reading weekly magazines made him wonder if his father was also reincarnated or transferred from another world. Regardless, he was an extraordinarily wild figure who built a de facto harem. Confirmed by Rumiko's numbers, Yuu felt awe - unaware he was steadily following his father's footsteps.

---

### Author's Afterword

The conversation got long, so I'm cutting it here. My apologies if you expected the nurses' threesome to start. It should begin around the latter half of the next chapter.

(Postscript) Officially, the protagonist is the eldest son of the Hirose family, not the twenty-ninth son, but Inui Rumiko deliberately teased him.

(Another postscript) I revised the part comparing sperm donation compensation to high school part-time wages for clarity. Wages are higher now, but in the author's memory, around 1990 it was about that. Of course, during long vacations, better-paying part-time jobs existed.

2020/4/24  
Revised: Yuu is the 33rd son (last son), not the 29th. Also corrected inconsistencies with later developments.

### Chapter Translation Notes
- Translated "献精" as "sperm donation" consistently with Fixed Terms
- Preserved Japanese honorifics (-sama) and name order (Inui Rumiko)
- Translated explicit terms directly: "ヤリまくった" → "fucked like crazy"
- Maintained transliterated sound effects (e.g., "pon pon", "gohon")
- Italicized internal monologue *(This is concerning.)*
- Used gender-neutral "they" for Amir as per Fixed Rules
- Formally translated professional titles ("主任" → "Chief")
- Preserved specialized terms: "優良（特）判定" → "Excellent (Special) rating"
- Translated anatomical terms directly: "精液" → "semen", "オタマジャクシ" → "tadpoles"