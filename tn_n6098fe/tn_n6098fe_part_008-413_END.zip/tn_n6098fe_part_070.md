## 63. Sperm Donation ② ~Hello, Again~

The story about my father Sakuya from Rumiko was beyond imagination, but something seemed questionable.

  

"The gender ratio of the children...?"

At Yuu's question, Rumiko nodded emphatically.

"That's right. There are more boys, aren't there? For Sakuya-san's children specifically, the ratio is about 1:5."

"Why do you think that is?"

"If Sakuya-san himself were still alive, we might have been able to ask about the circumstances.

His DNA has been preserved, so research is being conducted.

But even with scientific advances, there are still many unknowns regarding genetics."

  

Yuu recalled hearing about genetic manipulation technology being used on plants and animals before his rebirth. But in his previous life, he had no memory of such technology being used on humans. Perhaps it existed without his knowledge.

  

In any case, unlike Yuu's situation, his father probably retained an adult mind when he transferred into a child's body. Rebirth and transference themselves sounded like fiction, but since it actually happened to him, it wouldn't be surprising if others experienced it too.

  

*Pat*. Rumiko closed the file, cleared her throat, and after a slight hesitation, spoke.

"After the decline in male births became unstoppable, various attempts were made to produce boys... You probably wouldn't know about this, Hirose-sama."

"Ah. I wouldn't, no."

"Since we learned that male births come from Y sperm, which is alkali-resistant but shorter-lived than X sperm, it became recommended to inject alkaline gel into the vagina beforehand and have sex on ovulation day—what's commonly called 'lucky days'."

Yuu was stunned by the sudden graphic explanation, but Rumiko continued without pause.

  

"Additionally, it's said that women experiencing orgasm during sex is also effective. When women become highly aroused, alkaline mucus secretion occurs from the cervical canal.

Therefore, deeper penetration and ejaculation shorten the time sperm spend in the acidic vaginal zone, increasing Y sperm fertilization rates."

"Uh, uh-huh..."

"In other words, what I'm trying to say is that men's efforts can increase the probability of having boys, but realistically it's difficult... However, Sakuya-san was exceptional in this regard.

Do you understand? What that means?"

  

Rumiko leaned forward, eyes wide as she stared at Yuu, licking her lips. She seemed like a predator eyeing its prey.

"You mean... because he made women climax easily, boys were more likely to be born?"

Feeling he shouldn't back down, Yuu answered without averting his eyes. Rumiko smiled happily.

  

"Fufu. Well, I can't say that's the only reason.

But it's undeniable that Sakuya-san was extraordinary in many ways.

His sons—your brothers—while having individual differences, tend to be more sexually interested in women than average men.

Most had sexual intercourse early and fathered children before turning twenty.

Statistically, they also have higher male birth rates.

However, none seem as exceptionally lustful as their father."

"So the trait is inherited but diluted?"

"That might be it.

Now, may I ask you a question, Hirose-sama, as one of Sakuya-san's sons?"

"Sure. Go ahead."

Still leaning forward, her expression turned serious. Yuu straightened his posture.

  

"What follows is extremely private and intrusive. I won't record it.

You don't have to answer, and yes or no is sufficient if you do."

"Understood."

"Then... straight to the point. You've had sexual intercourse, correct?"

She asked with apparent certainty.

"Yes."

"Have you had sex with more than one woman?"

"Y-yes."

"To be blunt, do you like women?"

"Yes!"

  

He could have refused to answer, but with no one else around and no recording, Yuu decided it didn't matter. Rumiko smiled faintly and continued.

"During sex, do you believe your partners reach orgasm? Or have you heard them explicitly say they're coming?"

"Uh, well, yes."  
"Fufu. Last question."

Removing her glasses, Rumiko looked directly at Yuu.

"Consider this a bonus question—I won't mind any answer.

See that bed over there?

If I asked you to have sex with me right now, what would you say?"

  

Yuu was startled by the sudden proposition but guessed it wasn't serious—likely hypothetical. Without glasses, her double-lidded eyes were striking, with a tear mole near her right eye and plump lips adding to her allure. Her leaning posture revealed deep cleavage below prominent collarbones, contrasting with a slim waist. Her slightly parted legs showed her thighs but not her panties.

  

Yuu nodded firmly.  
"I'd be delighted to oblige."  
"My! Even though I'm fifteen years older?"  
"Eh? You don't look that old at all. To my eyes, Inui-san, you're quite attractive."  
"Fufu. Flattery is still welcome.  
Though not fully proven... I believe you, Hirose Yuu-sama, are the son closest to your father's nature among Sakuya-san's boys."  
"Eh? R-really...?"  
"That said, I don't intend to act on it immediately.  
I mainly wanted to talk today.  
And I'm glad we did.  
Thank you very much for your time."

  

She extended her right hand. Though unpolished, her well-manicured nails gleamed. Yuu shook it.

  

"May we meet again? I might have a favor to ask."  
"If it's something I can do."  
"Fufu, I look forward to it."

  

Yuu wouldn't mind having sex with her another time—he might even request it himself. In this world where many women in their 20s-30s are virgins, she seemed experienced. After only innocent partners, he thought a change might be nice.

  

  

  

  

"Okay. My part is done. Please prepare for sperm donation."

Rumiko called the nurse station via intercom. Yuu expected her to leave after hanging up, but she sat back on the sofa.

"My throat's dry. May I have another cup?"  
"Y-yes. Please."

As Yuu prepared tea for himself, Rumiko showed her empty cup, seemingly planning to stay. Pouring tea from the pot, they sat silently until the door opened.

  

""Yuu-sama!""

Mio, who seemed youthful for twenty yet exuded both gentleness and allure. Her large breasts swayed as she walked toward Yuu.

Shiho, cool at first glance but softening when meeting Yuu's eyes. Her posture was elegant, her figure captivating as ever.

The two angels in white had arrived.

  

"Uh, it's been a month. Good to see you. Mio, Shiho-san."  
"Of course, me too! Fufu!"  
"Now now, Takano. We have important duties today."  
"But I heard Shiho-senpai was so distracted this morning she kept making rare mistakes!"  
"Ugh..."

Yuu approached them.  
"Because I requested you for this donation? Are you okay?"  
"Ah! S-sorry! It's not Yuu-sama's fault at all, just my incompetence..."  
Yuu felt concerned as Shiho bowed apologetically.

  

*Ahem*. A cough made them turn toward the sofa.  
"Shouldn't we begin soon?"  
"Ah, yes... wait, Inui-san? Are you staying?"  
"I thought I'd observe if you don't mind.  
Please ignore me."

Rumiko smiled smugly.

  

  

  

  

"W-well then... it's my first time, but I received training, so first..."  
They brought what looked like a large 2L water bottle. New and gleaming in black and silver, a 1m hose extended from its side, ending in a 5cm diameter rubber cup. Judging by Mio's handling, it had substantial weight. After checking the manual, Mio pressed a switch, making the lid *clack* open. She removed a test tube-like container, confirmed it was empty, and replaced it. After pressing more switches with *beep, beep* sounds and a final long *beeep*, it seemed ready.

  

With Yuu seated on the bed's edge, the donation device sat on a stand before him. The thought of semen collection via this machine made him slightly nervous. The nurses stood before him.  
""Yuu-sama""  
"Yes."  
"Thank you for requesting us for this donation."  
Shiho bowed politely.  
"I-I'll do my best! Um... please don't hesitate to mention any concerns!"  
Blushing slightly, Mio also bowed.  
"Likewise. Fufu. Relax—I trust you both."

They smiled happily at Yuu's reassurance.

  

"Then, first..."  
"Yeah. I need to undress, right? Will you help?"  
"Ah, yes. Excuse us."  
Despite their prior intimacy, undressing a man clearly made them nervous. Their movements were awkward. Yuu reached out and touched their bent waists.  
"Ah..."  
"Hau..."

With nursing caps on, he couldn't pat their heads, but he stroked Mio's fluffy brown hair and Shiho's smooth locks, then their cheeks, jaws, and necks. They froze, enjoying his touch with blissful expressions.

  

"It's our first time together. Don't worry if it's not smooth. Relax."  
"We should be saying that. Thank you."  
"Ahaha... um, I'll try hard."

  

Regaining composure, they lightly squeezed his hands before clinging to him to remove his pants. Yuu lifted his hips, letting them smoothly pull down his trousers and underwear.

  

"Th-then..."  
"Yeah."

  

Sitting on either side at a careful distance. Shiho neatly folded his clothes, sat primly to the right, blushed after glancing at Yuu's face. Mio sat left, holding the rubber cup while eyeing Yuu's lower body.

  

"...!"  
"Ah!"  
Yuu pulled them close by their waists. Feeling their soft bodies through uniforms and their sweet feminine scent made his lower body react.

  

"We need to get my cock erect, right? Can you help?"  
"Y-yes..."  
"L-leave it to us!"  
"Then..."

  

He first claimed Shiho's lips. Though Rumiko was watching, since he'd admitted being attracted to women, Yuu decided not to care. He needed intimate contact with them—and wanted it.

  

"Mmm... fuu..."

While kissing Shiho, his right hand moved from her waist to her back, shoulders, and nape. After repeated *chu, chu* kisses, Shiho began pressing her lips back.

  

"Unn... Yuu-samaaa, me too..."  
Mio pressed her chest against him from the left. Breaking the kiss, Yuu saw Shiho's eyes were heated and moist.  
"Touch me?"  
"Yes"

  

Seeing Shiho reach for his cock, Yuu turned left to kiss Mio, who'd been watching with longing eyes. His left hand stroked her hip, then began kneading her soft buttocks. *Buchuu*—pressing his lips firmly, enjoying their softness as his lower body heated up. His cock, obediently hanging down, began swelling under Shiho's touch.

  

His left hand moved from Mio's buttocks to her ample breasts, visible through her uniform, and *grasped* them. Breaking the kiss, Yuu whispered in her ear.  
"Hey, open your uniform. Show me your breasts."  
"Hyaa! Y-yes..."  
Shivering at his breath, Mio nodded, blushing.  
"I want to see Shiho-san's breasts too."  
Turning right, Yuu traced Shiho's bra clasp while pleading.  
"M-my breasts aren't much, but if you want..."

  

As they unbuttoned their uniforms to remove camisoles and bras, Yuu unhesitatingly took off his shirt.

  

"Wow! Bold! And..."  
"Eh?"

  

Rumiko had moved from the sofa to stand behind the container, watching with intense eyes.

  

"Waaah! Your cock is magnificent!"  
"Ah... Yuu-sama's cock is wonderful..."

  

Shiho had brought him near erection, but the sight of both women exposing their breasts beside him made him fully hard.

  

"Haa~ I've never seen such an enormous cock.  
It might rival the legendary Sakuya-san's."  
Licking her lips hungrily from behind the container, Rumiko eyed Yuu's cock.  
"T-today is our duty!"  
"Y-yes. Please just watch from there."

Politely refusing, Shiho pressed against Yuu and reached for his cock again. Mio held the rubber cup while subtly pressing her breasts against him. Their bare skin against his heightened Yuu's excitement.

  

"Is this alright?"  
"U-uh-huh. Good..."  
"Tell us before you ejaculate, okay?"  
"Ah... mmph!"  
"*Chu*......nn...muu... Yuu-samaaa, *anmu... chupuu*"

  

Ignoring the watching Rumiko, Shiho wrapped one arm around Yuu's waist and began stroking his cock up and down. Mio stroked his back with her free hand while deep kissing him, tongue probing. Yuu reveled in their smooth skin, occasionally squeezing their breasts.

  

"Ah... haaan... Yu-Yuu-sama, nnph, fuuuuunnn!"  
"Fufu, your nipples hardened. Look, like this?"  
"Annh! There... I'm sensitive... nnph... aahh!"  
"Yu-Yuu-sama's coock... it's abou... to cum... ah! Nnph, nnnn~~~!"

  

As Yuu teased Mio's nipple, sweet moans escaped her. Deep-kissing Shiho, he felt precum coat her stroking hand. His right hand slipped from Shiho's back to her panties, rubbing her crotch—already wet.

  

"Ah, ahh, good... nnph"  
"*Nnfuun*... Today we're collecting your holy fluid."  
"It's so hot and hard. Almost time, right...?"

  

Both now buried their faces in Yuu's crotch, fellating and stroking him. Their tongues *lurululuing* around his glans felt incredible. As Yuu's pleasure peaked, Shiho's handjob sped up *shakoshako*.

  

Feeling semen rising, Yuu groaned.  
"Kuh... haah... I'm... I'm close! Mio, Shiho-san!"  
"...! Yes! Takano!"  
"Understood!"

  

Stopping oral, they moved as rehearsed. Mio fitted the rubber cup snugly over his glans. Shiho kept stroking while pressing a yellow button on the container.

  

"Uooohh!"  
A loud *GYUUUUN* vacuum sound sucked powerfully at his cock. Even a D*yson nozzle wouldn't create such suction.  
"Kuaah! Ah, ah, I'm... ejaculating..."  
*Shakashaka*—Shiho's rapid stroking combined with suction triggered his climax. Unlike oral or sex, this felt like forced extraction—true semen milking. Few volunteered for donation beyond mandatory biannual duties, especially teens. As warned, this world's men faced harsh experiences.

  

The suction lasted about a minute but felt longer. Sliding open the container's window, Mio smiled brightly.  
"Amazing, Yuu-sama's cock! It collected far above the required amount!"  
"Haha, glad to hear."  
Instructions advised abstaining two days prior, but Yuu only managed one day without release. Still, he'd produced substantially.

  

"Thank you for your hard work."  
"Likewise, thank you."  
Yuu and Shiho exchanged smiles. The rubber cup was already removed. Shiho held his still-hard cock while reaching for tissues.

  

Then Yuu felt different fingers stroke his glans. Rumiko had swiftly scooped semen onto her finger and *paku* put it in her mouth. Stunned, Yuu looked up as she smiled.

  

"Hmm. Thick, sticky semen—truly packed with seed. Worthy of your high evaluation.  
Fufu. Meeting you today and gaining so much data makes me truly happy.  
Let's meet again."

Heels clicking, she turned and left.

  

  

  

  

  

  

---

### Author's Afterword

2020/6/29

The earlier statement that genetic manipulation wasn't performed on human births in the early 21st century has been revised. As pointed out in the comments, actual cases existed overseas. Therefore, it's rewritten as Yuu simply having no knowledge of them.

### Chapter Translation Notes
- Translated "当たり日" as "lucky days" (fertile period) per Fixed Terms
- Translated "外れ日" as "off days" (infertile period) per Fixed Terms
- Preserved honorifics (-sama, -san) throughout
- Translated explicit anatomical/sexual terms directly ("cervix," "ejaculation," "cock")
- Transliterated sound effects ("patan," "chu," "shakoshako")
- Maintained Japanese name order (Hirose Yuu, Takano Mio)
- Formatted simultaneous dialogue with double quotes ""...""
- Italicized internal thoughts *(This is...)*