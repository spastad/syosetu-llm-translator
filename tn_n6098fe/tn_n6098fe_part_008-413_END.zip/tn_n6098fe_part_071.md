## 64. Sperm Donation ③ ~Butt-Pressing Sandwich~

### Author's Preface

The mystery of how adding just one "ri" character completely changes the original title's meaning.

---

Right now, before Yuu's eyes on the bed, Shiho is crouched over Mio who's lying on her back. 

Both have their nurse dresses (one-piece type) hiked up high, and their panties were removed long ago. Since both Mio and Shiho have their legs spread, their labia minora (wareme) are completely visible, along with the surrounding areas and pubic hair, all thoroughly drenched. This is because after Rumiko left the room, they'd been passionately kissing and touching each other while sandwiching Yuu between them.

"You're both so wet like this."

When Yuu lightly touched Shiho's and then Mio's vaginal openings, they made squelching sounds. With just small up-and-down strokes, clear love juices immediately clung to his fingertips.

"Nn... Y-Yuu-sama, I just can't control myself in front of you..."  
"Aahn... It's Yuu-sama's fault~"  
"Fufu. That's good. I think it's wonderfully lewd. So then..."

Yuu first brought his face close to Shiho's area, which was turned toward him with its shapely buttocks. When he spread it open with his fingers, he could see the slick glistening inside her vagina. *Chu*—he kissed it and sucked up her love juices.

"Fwaa! Y-Yuu-sama!?"  
"Shiho-san's pussy has such a lewd smell. *Churl*, *slurp*!"  
"Ah... Haaahn! S-sucking it... ah... haaahn..."

As Yuu sucked Shiho's love juices, Shiho let out sweet moans that sounded like she might melt. In this world, it seems women consider it a delightful act when a man performs cunnilingus and drinks their fluids, comparable to how women feel when men swallow after fellatio.

Meanwhile, Yuu didn't neglect Mio. Placing his right palm against her labia minora, he used his index and ring fingers to spread her wareme open, then slowly stroked the inside with his middle finger, widening her vaginal opening.

"Anh! Yuu-sama is touching my pussy..."  
"Mio's pussy is lewd too. Do you want my cock already?"  
"A, yes! I want Chinsama, quickly~"  
"Not yet. You'll have to wait a bit longer."  
"Anh... Yuu-sama, you're mean... nnaaah!"

Judging the timing right, Yuu inserted his right middle finger into Mio's vagina. Since she was thoroughly wet, it slid in smoothly to the depths, but he could feel the vaginal walls tightly squeezing his finger inside.

Yuu began licking and sucking Shiho with his tongue while simultaneously fingering Mio in and out. *Pichapicha*, *kuchukuchu*—watery sounds played from both their private parts while their moans grew louder. "Ah, ah, Yu...u-sama! Nn, I'm... I'm feeling too good... ah, ah, aahn!" "Ha, ha, haun! Yuu-sama's finger... my depths... anh! There... it feels so good!"

Both women writhed their bodies from the immense pleasure and ecstasy brought by Yuu's caresses. On this long-awaited day, their emotions and bodies were rapidly heightening as they touched Yuu. For Yuu too, it was unbearably delightful that they felt so sensitively even after a month apart. That's why he got even more enthusiastic.

"Now then, who can hold out? The one who lasts gets a reward."

Shiho and Mio exchanged glances but both wore ambiguous expressions. When it came to Yuu, they couldn't hold back.

Yuu pressed his mouth firmly against Shiho's vaginal opening and extended his tongue inside. Immediately, the area around his mouth became soaked with love juices, but he kept moving his tongue without concern. "Nnn!? Au! I-inside... nnn~~~~~! Nn, nn, nfuu!" Inserting his tongue into her vagina was something men in this world would never normally do, but Yuu and Shiho had no way of knowing that. Shiho covered her mouth with her hand, suppressing her voice, but her expression was one of complete ecstasy, utterly unlike her usual calm self.

Meanwhile, the middle finger inside Mio was slightly bent at the first knuckle, stimulating her belly side in circular motions. "Aah! Yuu-sama, there... it feels weird! Fuwaaaahn! Even though it's just a finger... it feels way better than when I do it myself! Wh-why~?" Mio unconsciously grabbed Shiho's arms and shook her head side to side as if refusing.

Having pressed his mouth against her vagina, Yuu finished with a loud *juru-juru chupon* sound as he sucked up the love juices. Then he extended his tongue forward and teased her swollen clitoris with *chiro-chiro* flicks. "Kyauun!" Shiho's body jerked, her chin lifting.

"Ah, ha, anh, anh, no, not that... ah, ah, ahi! I-I'm cumming, cumming! Aaaaaaaaahhhhhhh... Yu... Yuu-sama, I'm... I'm... CUMMING!"

"Whoa!"

At that moment, as Shiho arched her back, her squirt sprayed onto Yuu's face with a *pishu* sound. He hadn't expected her to cum in less than a minute after he started licking her clitoris. But having his partner feel that intensely was nothing but joyful. Licking the squirt from his face, Yuu grinned.

"Shiho-san, I thought this before too—you're really sensitive."  
"Hauuu... That's... because it's Yuu-sama~"  
"Fufu. That makes me happy. It makes me want to make you feel even more."

Yuu licked up Shiho's dripping honeypot as if savoring it. "Hyau! Yuu-sama... anh!" Shiho could no longer support herself with her arms and ended up pressed against Mio.

"But the reward goes to Mio. Shiho-san, could I ask you to lower your hips?"  
"Uu... understood."

"Ooh! Nice!"

Below Yuu's gaze, Shiho was on top, covering Mio with their hiked-up buttocks stacked together. Moreover, both had love juices spreading around, wetting the sheets. It's a common sight in eroge, but seeing it in real life was incredibly lewd and arousing. Yuu pushed his hips forward, guiding his cock with his hand, and covered Shiho from above.

"Nn... Yuu-sama?"  
"Here I go, Mio."  
"Eh?"

*Zuburi.*  
"Ooh!"  
"Ngaaaaaaahhhhhhh! Ohhoo! Chinsamaaa! Anh! I-It's in... niiihiiiiii!"

"Kuh! Good... zo! Mio! T-tight!"

Come to think of it, it had been a month since he took her virginity in this room. The tightness was almost the same as when she lost her virginity, and insertion wasn't smooth due to resistance from her vaginal walls.

Yuu leaned his upper body down until it was pressed against Shiho's back, hugging both of them as he pushed his hips forward, slowly but surely achieving insertion. Shiho was disappointed she couldn't come first, but feeling Yuu pressed against her from behind, sensing his breath and heartbeat, she couldn't help but feel joy.

"Guo... there! I'm... in! All the way to the depths!"  
"Ain! Chin...sama is... ah! Ah, ah, I'm... ahhi... aaaaaahhhhh... ahe... sooo goood..."

After reaching deep inside her vagina, Yuu savored Mio's insides for a moment, then began thrusting *guriguri* as if prying open her cervix. "Ooh... Mio's insides feel good." "Hya!? Yu...u-samaaaa... ah! Ah! No, I'm cumming! I'm cummiiing!" "Huh?"

When Yuu peeked from the side, Mio's face was flushed, with large beads of sweat on her forehead, panting as if she'd just run a 100-meter dash at full speed. Her nurse cap had already fallen off, and her fluffy short bob hair was stuck to her forehead and cheeks.

"You came right after insertion?"  
"B-b-because it's been so long since I saw Yuu-sama... I felt it so intensely... And the moment Chinsama entered, my head went completely blank..."  
"Fufufu. Good girl."

Thinking she'd adjusted by now, Yuu began moving his hips with long strokes that thrust deep, slowly pulling back near the vaginal opening before plunging deep again. "Anh! That's... no good... anh, aahn... I just came... fa! Good! Good! It feels sooo good!"

Eventually, after a few more minutes of pistoning, Yuu pulled his cock from Mio's vagina and grabbed Shiho's hips with both hands, entering her. "Shiho-san, sorry to keep you waiting."  
"No... but honestly, seeing such a lewd show right in front of me, I'm ashamed to say I got aroused too..."  
"Then to make up for making you wait, shall I go all out from the start?"  
"Eh... that kind of... aahn! It's coming in...!"  
"Aah! Shiho-san!"

The cock that had just been inside Mio, wet with love juices, was swallowed *zubuzubu* into Shiho. Despite having waited so long, insertion was smooth, but the moment it went all the way in, her vaginal folds tightly gripped it, giving a trapped sensation.

Noticing this, Shiho turned to look back at Yuu with moist eyes. "Yuu-sama..."  
"Shiho-san."  
Since Shiho twisted her body forcefully, Yuu brought his face closer and kissed her. While gently kneading her modest breast swell with his right hand, he repeated kisses, tangling their tongues. When their lips parted, a string of saliva stretched *tsuuu* between them.

"Now I'll make Shiho-san feel really good here."  
Saying this, Yuu thrust deep. "Kyau! Aah... just having Yuu-sama inside me... fa, anh!"

Yuu pressed tightly against her back, hugging Shiho's slender body while starting to move his hips. First slowly in small movements. Occasionally thrusting deep. Repeating this while gradually increasing speed.

"Anh, anh, anh! Yuu-sama, aun!"  
"Aah... Shiho-san's insides feel amazing too!"  
"Me too, me too... aahn! Amazing, amazing! I can't think of anything anymore! My insides... are full of Yuu-sama's cock!"

*Pan! Pan! Pan!*  
As Yuu increased his hip thrusting speed, rhythmic butt-slapping sounds echoed.

"Aaaaaahhhhh! That's... too intense! Aau... already... I'm... again... ah! Oh... I'm cumming! Anh, cumming cumming... CUMMING! AAAAAAAHHHHHH! CUMMIIIIIIIIIIIIIIIIIIIIING!!!"

After Shiho came, Yuu inserted into Mio again. When Mio came quickly, he raised his hips and entered Shiho. The appeal of this position was being able to enjoy both women alternately. Yuu himself was feeling strong ejaculation urges but deliberately held back to prolong the pleasure.

*(But... it's almost my limit. Which one should I cum in...?)*

As he approached the end, Yuu hesitated. Both women, having been made to cum multiple times by Yuu, hugged each other, breathing heavily. Pulling his cock from Shiho's vagina, he aimed at Mio's. Milky white fluid dripped *taraari* from his love-juice-coated cock. *(That's it! Why not try THAT!)*

Yuu called out to Shiho and Mio. "I'm about to cum, but I need your cooperation for that."  
""Huh?""  
As they both looked at him, Yuu smiled.

"Oooh... this is... pretty good in its own way!"  
"U...uun... it feels kind of weird... but if Yuu-sama likes it..."  
"But~ having Chinsama rub against my there feels so good~"

It was what you might call "shell pressing." Mio lay on her back with her legs spread wide in an M-shape, while Shiho lowered her hips so their genitals pressed together. In other words, their pussies faced each other with Yuu's cock moving between them. The so-called "double vulva" or "pussy sandwich" in adult circles. The soft, well-lubricated flesh moved easily, which was convenient.

"Aah... sandwiched between your pussies... good! So good!"  
"Ah! Somehow... I'm starting to feel... good too... anh!"  
"Afuun... having Chinsama rub like this... I love it~"

Each time Yuu thrust with large strokes, his glans rubbed against their clitorises, which seemed pleasurable. Both began making sweet moans, while *nucchanuccha* lewd sounds could be heard with Yuu's hip movements.

"Kuh! Better than expected... I can't hold on... aah! I'm cumming!"  
"Ah, anh... Yuu-sama, please cum!"  
"Yuu-sama~... don't hold back, cum lots!"

Though partly urged by them, as Yuu covered Shiho's back and kept thrusting violently, he sensed his limit approaching. "Nn, guh... I'm cumming... like this... oh! CUMMING!" At that moment, *dopyudopyu*—his semen shot out forcefully, reaching their chest area through the narrow gap, but seemed blocked by Mio's prominent breasts before reaching their faces.

"Fuuu... that felt... so good. Both of you."  
"Aahn... Yuu-sama's hot stuff... haaaa, so much... all over me..."  
"Fuaaaa... amazing... so much hot holy fluid... My body... feels purified."

Though one comment was somewhat incomprehensible, having enjoyed near-ejaculatory pleasure, Yuu hugged both women from behind Shiho.

Cleaning up was troublesome, but after dressing, Yuu sat on the edge of the bed and faced Shiho and Mio, who had straightened their nurse uniforms. Smiling, Yuu lightly patted both his sides. "Well then... excuse us." "Ufuh!"

Yuu wrapped his arms around Shiho's and Mio's waists and pulled them close. "Thank you for today."  
"Not at all..."  
"I thought I'd practiced, but did I handle it well?"  
"Un. You surprised me with various things during my first sperm donation, but since you two handled it, I'm glad it ended safely. I'd like to request you both again."

When Yuu smiled and looked at them alternately, both wore touched expressions. "I... felt incredibly lucky just to meet you again and have my first time with Yuu-sama. Beyond that, being assigned as your handler is an unexpected joy beyond words."  
"Shiho-san."  
"Hai!"

Yuu stared intently at Shiho's face, close enough to feel her breath. Though Shiho averted her eyes once, she timidly looked up at Yuu, who kept gazing at her. Her cheeks were flushed. "Ever since I was hospitalized at this hospital, I've been really happy that Shiho-san became my handler. So please continue taking care of me."  
"Yuu-sama..."  
"Shiho-san."

Calling each other's names, Yuu and Shiho exchanged passionate *chu*, *chu* kisses.

"Isn't it getting a bit too hot in here? Haven't you forgotten about me~?"

Frowning, Mio clung tightly to Yuu and shook him *yusayusa*. Each time, her ample breasts pressed against Yuu's side, *munimuni* changing shape—clearly visible even through clothes.

"Haha. Of course not. Since the first semen test, Mio has been my cock-handling nurse. Please continue taking care of me!" "Ufufu. Leave it to me... anh."

While lowering the hand on her waist to stroke her buttocks, Yuu greedily kissed Mio's lips.

"By the way, why do you call me without honorifics but add '-san' to Kajio-senpai?"

After their lips parted, Mio voiced a question she'd been wondering about. Indeed, when Yuu called their names, it was "Shiho-san" and "Mio."

After thinking briefly, Yuu answered. "Hmm... that's because Shiho-san gives off the feeling of a beautiful older sister I admire, so I use '-san'."  
"My!"  
Shiho happily blushed and rested her head on Yuu's shoulder.

"But then, I'm five years older than Yuu-sama too!"  
"Eh?"  
"Why 'eh?'?"  
"Fufufu."  
Shiho laughed elegantly, caught up in the moment.

"No, somehow Mio only looks about the same age as me."  
"Cruel!"  
"Now now. Meaning I see you as a cute girl around my age."  
"Cute, huh... Un, if Yuu-sama thinks so, then it's fine. Ehehe."

Yuu inwardly thought she was easy to handle.

They spent about 15 minutes flirting like this. He really wanted to start another round with both, but since he was keeping people waiting, he thought it was time to leave the room. Already today's preliminary explanation had been long, and nearly two hours had passed since arriving.

"Well then, shall we go?"  
""Hai.""

As Yuu stood up, the two followed. It would be lonely not seeing Yuu for a while, but this wasn't goodbye forever. Yuu had told them he planned to return for sperm donation within a month. Though Yuu's fans in the hospital were increasing, they reaffirmed that being assigned as his handlers was irreplaceable luck.

At the door, Yuu suddenly turned around. Then he pulled both close. "Shiho-san, Mio. I'll come see you again." Saying this, Yuu kissed Shiho and then Mio goodbye in turn. "Yuu-sama!" "Yuu-sama!" Overwhelmed, both clung tightly, but their expressions now contained joy unlike before.

### Chapter Translation Notes
- Translated "尻あわせのサンドウィッチ" as "Butt-Pressing Sandwich" to convey the physical positioning while preserving the sandwich metaphor
- Translated "ワレメ" as "labia minora" per explicit terminology requirement
- Translated "ちゅるっ" and similar sounds as onomatopoeic representations (*churl*, *slurp*)
- Preserved Japanese honorifics (-san) as per style rules
- Translated sexual acts without euphemisms ("cunnilingus", "ejaculated", "penetrated")
- Maintained original name order: "Takano Mio" and "Kajio Shiho"
- Italicized internal monologue: *(But... it's almost my limit)*
- Translated "精飲" as "swallow after fellatio" to convey cultural context
- Used "love juices" for "愛液" as consistent explicit terminology