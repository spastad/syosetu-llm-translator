## 65. Tournament Support ① ~YELL!~

Whack!

After what seemed like an evenly matched exchange, the tip of the bamboo sword struck the head in a brilliant move that exploited a momentary opening.

"Point for head!"

The referee's voice rang out along with the flag.

""""Whaaaaaaah!""""  
""""Aah!""""

Cheers and near-screams intersected and echoed through the hall. The moment had decided the outcome of the team match that had gone all the way to the anchor bout.

This was the prefectural budo hall in Ageyo City, located almost due east from Saito City where Yuu lived. The high ceiling featured large skylights, with sunlight streaming through gaps in the crisscrossing wooden beams. Had one entered the empty venue first thing in the morning, they might have felt a pure atmosphere. But now, kendo-clad athletes ran across the polished floor with resounding footsteps, while the stands filled with numerous high school girls amplified the heat with their cheers.

The prefectural budo hall was a venue frequently used for martial arts tournaments within Saitama Prefecture, hosting the spring tournament since yesterday after midterm exams. Yesterday featured judo, archery, and naginata. Today's schedule included kendo and karate.

Thanks to Yuu's proposal and Komatsu Sayaka's determined agreement, Sairei Academy's student council had decided to focus this year on having male students participate in supporting athletic club tournaments. It began with a school-wide assembly featuring a passionate speech by student council president Komatsu Sayaka, followed by appeals from club representatives. The newspaper club published a special pre-tournament issue with temporary funding assistance, and posters were put up throughout the school. As a first-year, Yuu himself visited the male classrooms with student council officers and athletic club seniors to personally request support. Until last year, such school-wide efforts hadn't been made, and support only happened voluntarily—for personal reasons like supporting a girlfriend—so male students had been unresponsive.

But as announcements of strong results in the preliminary rounds began building excitement, and with existing personal connections through relationships, an atmosphere had developed where some second and third-year male students considered going to cheer.

Thus, at yesterday's archery tournament, possibly influenced by support from six male students, they achieved their best-ever result of fourth place. Unfortunately, the judo club without male support was eliminated in the second round.

Today's main hall hosted Saitama Prefecture's spring kendo tournament. In team matches, the top two schools advance. In individual matches, the top three qualify for next month's Kanto tournament. While the main high school tournament is the summer Inter-High where most sports clubs participate, spring or fall tournaments vary by sport and aren't as large-scale as Inter-High. Still, for martial arts clubs like kendo and judo, this first tournament of the new academic year held significant importance.

Five third-year boys had volunteered to support the kendo club. As a student council member promoting this initiative, Yuu joined them. After gathering at school first thing in the morning, all supporting students took a bus here.

"Aaahn! So close... They almost had it~"  
Emi, who had been enthusiastically cheering until moments ago, slumped dejectedly into her seat.

"Truly. The opponents were second seed, right? If they'd won, they might have made it to the finals."  
Yuu murmured while looking down at the tournament program he'd received upon arrival.

The intense match that just concluded before their eyes was the team quarterfinals. Sairei Academy High School's kendo club fought almost evenly against Shutoku High School, one of the championship favorites, but unfortunately lost. Still, even to Yuu's amateur eyes, their performance had been engrossing enough to get absorbed in.

"Ahh... Sayaka-senpai would've wanted to see this."  
"Since she's former kendo club."  
Nodding at Emi's murmured comment, Yuu agreed.

Originally, the plan was for Yuu and all three student council members to attend. But yesterday, the principal suddenly summoned them, so today only Emi accompanied Yuu, with president Komatsu Sayaka and vice-president Riko absent.

As the team match competitors approached and bowed in unison, Yuu and others applauded with encouraging cheers. Only Yuu and two third-year boys had supported the team match. Though just three, their male voices stood out. After all, looking around the spectator seats, all one saw were high school girls. A few boys from other co-ed schools were spotted, but the venue was undoubtedly over 90% female.

Suddenly coming to his senses, Yuu noticed they were attracting attention. Still, about twenty Sairei Academy girls formed a tight guard around the boys, so there should be no concern.

Just then, a girl in the same uniform came running over.  
"Emergency! Emergency! Hayase-senpai is advancing! Next is the semifinal!"  
"Seriously!?"  
"Then let's go!"  
""""Ooh!""""

Reportedly, in the individual matches with three participants, one lost in the second round and another in the third, but third-year ace Hayase Mika had won her quarterfinal. Surrounded by girls, Yuu and others moved to the opposite spectator seats where individual matches were held. During this, when Yuu casually took the hand Emi subtly extended, she smiled happily.

Joining other Sairei Academy students watching the individual matches, Yuu spoke to one male student.  
"Ichijo-senpai! What's happening?"  
"The match is about to start. The opponent is... an Eiko player."  
"Eiko... and second seed, right?"  
"Yeah. But winning here guarantees advancing to Kanto tournament. This is Mika's crucial moment."  
"Right."

He was third-year Ichijo Koki. With longish black hair that fell over his eyes and sharp features, he lived up to his reputation as a handsome guy. Moreover, he'd been dating Hayase Mika since their second year. When supporting the kendo club, Koki was the first to volunteer, which helped gather other boys including those close with kendo club members. On the bus ride, Yuu learned Koki was simultaneously dating Ishima Mariko, another third-year. Shown photos, Mika in uniform gave a dignified, beautiful impression fitting a kendo girl, while Mariko appeared youthful with strikingly large eyes. Actually, Mariko had recently debuted as singer Mimei Rin and couldn't attend today due to work. The pre-reincarnation Yuu would've thought "Explode, handsome popular guy," but current Yuu had enough composure given his own deep relationships with the three student council members.

Below, the two called names already waited diagonally opposite on the court. The one in white kendo gear with long dark brown hair tied back visible behind the men was Mika. Earlier, the embroidery on her tare apron showed her school name and "Hayase." The opponent wore dark kendo gear. "Eiko" was shorthand for private Saitama Eiko High School, known for athletic excellence. Yuu and Koki were similar heights, and Mika appeared comparable in photos, but Kuroda was clearly taller.

Just as the match seemed about to start, Koki stood with hands megaphoned.  
"Mikaaa! Do your best! You must win!"  
Despite his cool appearance, Koki shouted support without restraint. It clearly reached her. Turning to look up, Mika nodded slightly at Koki.

Not to be outdone, Yuu and others cheered too.  
"Hayase-senpai! Do your best!"  
"You can do it, senpai!"  
"Win and go to Kanto tournament!"

Though the opponent received cheers too, the gazes directed their way seemed more like competitive hostility and jealousy toward those receiving male support.

After bowing to each other and stepping forward, both took crouching positions. At the referee's "Begin," they rose and the match started.

"Kieeeeeeeeeee!!!"  
Immediately after starting, Kuroda unleashed a fierce assault with a bird-like shriek.  
"Meeeeen!"  
Given her height advantage, she mainly targeted the head. From the outset, she appeared to overwhelm with fierce attacks. To amateur Yuu, there were several dangerous moments where it seemed points were scored.

"I-Is she okay?"  
"Probably fine. Kuroda said she'd faced this opponent before. She planned to endure the early rush and bet on the latter half."  
Koki's calm words settled Yuu who'd begun feeling anxious.

High school matches last four minutes—short yet long. Since it's best-of-three points, scoring first provides advantage. The opponent seemed recklessly pursuing that first point. But upon closer look, Mika deftly parried strikes with her shinai or evaded with footwork. Thus, even when hit, only dull sounds occurred—not scoring points.

While Kuroda forcefully pushed from clinches to target the head, Mika—primarily defending—occasionally preemptively struck at the wrists without scoring. Checking his watch, nearly two minutes had passed when at the three-minute mark, the referee pointed at Mika and said something upon returning from out-of-bounds.

"Trouble. She got a warning."  
"Huh?"  
Like judo, passive stalling earns warnings. If time expired now, they'd enter overtime, but accumulated warnings could mean disqualification.

"One minute left. This is the decider."  
"Right."

The two began exchanging strikes. Now Mika actively swung her shinai too. Kuroda pressed with terrifying intensity. Exchanging strikes for three minutes consumes considerable stamina, but as elite athletes, neither seemed exhausted.

Three and a half minutes passed. While Kuroda targeted the head, Mika aimed for wrists. When Mika tried creating distance with footwork, Kuroda relentlessly closed in.

"No time left! Do your best!"  
"Mikaaa! Stay calm and aim!"  
The tension was palpable. Not just Yuu and Koki, but everyone cheered loudly. Opponents desperately cheered too.

With no scoring hits, they went out-of-bounds for a reset. Both were visibly breathing heavily from their shoulders. Maybe 10-15 seconds remained.

As the referee called to the facing pair, just as Kuroda began raising her shinai for jodan stance, Mika charged.  
"Doooooooh!"  
Wham!

"Ah!"  
"Huh?"

For a moment, silence fell over the nearby area.  
"Point for torso!"  
Three referees raised their flags simultaneously. A splendid nuki-do strike had perfectly exploited the moment Kuroda's elbow lifted.

Whaaaaaaah!  
Before the cheers subsided, the match resumed. The visibly shaken Kuroda couldn't recover her composure before time expired. Thus, Sairei Academy High School's Hayase Mika advanced to the finals.

The finals opponent was Saitama Eiko's top seed—more skilled than semifinalist Kuroda—and Mika unfortunately lost by ippon, securing second place. After watching and cheering this far, Yuu felt his throat dry and gulped barley tea from his bottle. Then he needed to urinate.

For Sairei Academy's kendo club, this was their first prefectural finals and Kanto tournament qualification in years, and the seniors' excitement hadn't cooled. Everyone around—boys and girls—chattered loudly.

Yuu poked the shoulder of Emi beside him.  
"Hm? What is it, Yuu-kun?"  
"Need to use the restroom."  
"Ah! Wait a sec!"

Emi called to reserve kendo club members in front. When boys leave their seats, someone must accompany them—a firm rule.

"We'll be temporary bodyguards."  
"Leave it to us!"  
"Yes, please."

Accompanying Yuu were one third-year and two second-year seniors. Surrounded front and sides, Yuu left the spectator area for the aisle. Girls from other schools stared at moving Yuu, whispering "Whose boy is that?" and "So handsome!" The seniors guarding Yuu at near-touching distance seemed proud, perhaps from superiority.

"Seems pretty far."  
"Eh... really?"  
"Well, no choice! Let's go!"

Checking the guide map near the main entrance, reaching the men's restroom required circling the main hall to the back parking lot. With five restrooms in the spacious hall, only two had men's facilities—inconvenient but understandable given gender ratios.

While walking, they introduced themselves. The third-year leading was Reia—short bob, glasses, about 180cm tall. Additionally, despite being just one year older, she seemed the most alluring and mature among the three. The second-year on the right was Hiromi—short hair and brisk speech giving a boyish impression, height similar to Yuu. Also second-year on the left was Sanae—slightly shorter than Yuu with long hair tied back, seeming unexpectedly youthful for a senior.

For Reia's group, the distance meant more time with Yuu, which didn't bother them at all. After nearly two months since enrollment, most girls knew Yuu was rare among boys—never cold to anyone who spoke to him, never rejecting physical contact. In fact, while discussing today's match and guarding Yuu from approaching girls from other schools—with occasional physical contact—the three secretly enjoyed their janken-won bodyguard roles.

""Well, we'll wait here."  
"Yes. Sorry. I'll hurry back."  
"No rush. Take your time~"

The men's restroom was finally found at the end of a long corridor after a turn. Naturally, girls couldn't wait right outside—problematic if other male users came. After parting with seniors in the corridor, Yuu entered the deserted, silent restroom with two stalls and three urinals.

"Club support was unexpectedly fun."  
Yuu muttered to himself while hearing urine splash into the urinal. In his pre-reincarnation high school days, he'd never have attended tournament support. Everyone hated wasting holidays. But now, as a student council member, he had the pretext of club support. Secretly, he was also interested in the female-dominated tournament scene.

But the big reason was that despite only two months, he'd grown fond of his alma mater Sairei Academy. Partly because many girls were likable—student council trio like Komatsu Sayaka, and Class 1-5 girls. Though initially anxious as a middle-aged man inside, he'd made friends like Rei and Masaya.

Male support wasn't confirmed yet, but after late July's finals, summer prefectural qualifiers would fill the schedule. Through student council activities, Yuu had met many club seniors and wanted to support as many as possible. Thinking this while finishing urination, just as he zipped up—

A hand extended sneakily from behind covered Yuu's mouth and chest.  
*(Huh!?)*  
Without time to scream, Yuu was dragged into a stall.

---

### Author's Afterword

This story about male students supporting club tournaments was first mentioned when visiting the student council room in "16. High School Enrollment ③ ~BOY MEETS GIRLS~".

As suggested in comments, swimming was considered but research showed tournaments are only held in summer. Track and field was another individual sport option, but I chose kendo since I had some experience (though only until elementary school).

2020/7/11  
Corrected the referee's call for scoring strikes after feedback from experienced kendo practitioners.

### Chapter Translation Notes
- Translated "蹲踞" as "crouching positions" preserving the kendo term "sonkyo" in description
- Transliterated kendo shouts ("Kieeeee", "Meeeeen") to convey intensity
- Rendered "にゅうっと" as "sneakily" for the stealthy movement
- Preserved Japanese tournament terminology ("ippon", "men", "do") with explanatory translations
- Maintained original name order and honorifics (e.g., "Hayase-senpai")
- Translated "一条 晃輝" as "Ichijo Koki" following fixed character name format
- Kept sound effects like "Whack!" and "Wham!" for impact noises
- Used gender-neutral "they" when group gender composition was mixed