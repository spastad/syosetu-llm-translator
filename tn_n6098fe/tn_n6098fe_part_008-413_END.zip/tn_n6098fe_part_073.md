## 66. Tournament Support ② ~CRAZY GONNA CRAZY~

### Author's Preface

This is from the perspective of a female athlete who participated in the tournament.

---

I am Kuroda Noriko, a third-year at private Saitama Eiko High School and member of the kendo club.

Not to boast, but I believe I'm among the top five in our nearly 100-member kendo club.  
I've been a regular since my second-year summer, competing in team matches (though on the B-team) and individual tournaments.  
Aside from our captain - who stands out with her exceptional strength at national level - the regular members are all closely matched in skill.  
I'm arguably top-tier in Saitama Prefecture, but my first appearance at the fall Kanto tournament ended in a frustrating first-round loss.  

This spring's prefectural tournament held special significance for me as a third-year.  
A disappointing performance here could mean losing my regular spot to second-years.  
The competition is that fierce.  

With our captain reserved as the absolute trump card for team matches, our coach's supreme order was for us three representatives to sweep the top three spots in individual matches.  
In my bracket as the second seed, I expected the third-seeded Shutoku player to be my semifinal hurdle.  

But unexpectedly, the Shutoku player lost in the quarterfinals, replaced by an unmarked Sairei Academy opponent.  
Come to think of it, I remember facing her last fall and winning.  
She should be weaker than the anticipated Shutoku player - no way I'd lose to someone I've beaten before.  
I was brimming with confidence before the match.  

Then I saw it - my opponent, named Hayase, had male supporters cheering for her!  
And they called her "Mika"!  
Looking at the stands, several breathtakingly handsome boys were enthusiastically cheering for Hayase...  
Right, Sairei is co-ed. She must have close male friends... maybe even a boyfriend?  

I felt my mind boil over like an instant water heater.  
Disgusting. Disgusting. Disgusting. Disgusting. Disgusting!  

Staring at her with jealous, hate-filled eyes through her men, I saw her pretty face - the type boys would love.  
Meanwhile, I've been at the dojo since age five. Seventeen years of nothing but kendo. Spending my youth in sweaty, female-only dojos.  
Whether mistaken for a boy or just pent-up frustration, I've been groped and hugged by girls countless times.  
But I rarely even get to see real boys.  

*Die!*  

I muttered as I unleashed a furious scream at the starting signal, charging at my opponent.  

---

She was tougher than expected.  
No matter how many strikes I landed, I couldn't score a point. The more frustrated I got, the more she toyed with me.  
Had she studied me after our last match?  
But when three minutes passed, the referee warned her.  
Would I win by decision?  
Unacceptable.  
I resolved to strike down from the top of her pretty face for that decisive point.  

But she kept using footwork to maintain distance while persistently targeting my wrists.  

After stepping out of bounds, we reset. Time was almost up.  
I'd push relentlessly in this final chance - absolutely land a head strike.  
Maybe I'd developed tunnel vision.  
Coaches always said I lose composure in crucial moments.  

I unconsciously raised both arms, but her sudden charge caught me off guard.  
By the time I realized she'd struck my torso, it was too late.  

"Torso point!"  

When I heard the referee's call, I couldn't accept it as reality.  

---

I don't clearly remember what followed.  
The match ended somehow, and I bowed when prompted by the referee - probably muscle memory.  

Walking toward my teammates by the wall, I recognized their contemptuous, pitying stares.  
Making top four in the prefecture puts my regular position on shaky ground.  
The borderline regulars must see this as their chance.  
Their "Tough break" and "Don't mind" felt like they were really saying "A loss is a loss" and "You got beaten by an unseeded player."  

I threw down my shinai, tossed aside my men and do, and fled the scene.  

In the hallway, I punched bulletin boards and kicked nearby trash cans to vent, but only felt waves of self-loathing and regret.  
I kept walking toward deserted areas until I found myself sitting in a restroom stall, crying.  

*Ah, I haven't changed since childhood.*  

I recalled skipping the awards ceremony after an upset loss in an elementary championship match, crying in the restroom.  
I often choke in decisive matches - finals, semifinals.  
Maybe I lack the mentality for sports.  

As I wallowed in self-pity, a sudden thought struck me:  
*This isn't... the men's restroom, is it?*  
I'd walked straight into a stall, but something felt off when I entered.  
The sanitary disposal box found in women's restrooms was missing too.  

Coming to my senses, I checked my surroundings.  
Having walked head-down without noticing, I must have entered a restroom far from the main hall.  
Eerily quiet - no voices or footsteps.  
Nobody seemed present now.  
Still afraid to make noise, I quietly unlocked the door.  

My eyes met an elongated white fixture. That's...  

I shut the door with trembling hands.  
Cold sweat trickled down my back.  
Opening it again confirmed it wasn't a hallucination.  
I'd only seen those on TV - exclusive to men's restrooms.  
Which meant...  

*Bad bad bad bad bad!*  

Covering my face, I closed then reopened my eyes.  
I'd mistakenly entered the men's restroom!  
If someone saw me here...  
I recalled news reports about women caught lurking in men's restrooms for peeping or rape (mostly attempted), names published despite being minors.  

Police. Sex offender. Expulsion from club. Expulsion from school.  

Those words flooded my mind.  

*I have to get out before anyone comes!*  

Yet my legs wouldn't move. Why...?  

A devilish temptation crossed my mind:  
*Right here, boys bare their lower halves and press their skin directly against this seat!*  

*What am I doing? No! Must leave now!*  
My rational mind screamed warnings.  
Yet my hands frantically untied my obi as I stripped off my tare and hakama.  

"Ah..."  

I roughly bundled the hakama and tare onto the tank behind me.  
Sitting on the seat in just my underwear, the cool porcelain felt good against my heating body.  
*I'm touching where boys' skin touched!*  
My mind conjured a boy sitting bare-bottomed above me.  

The boy in my fantasy was that incredibly handsome one from the stands.  
*So cool... What if he went to my school? Saying "Good work at practice!" or handing me a towel...*  
*Maybe walking home together? Ho-holding hands?!*  

Yes. I was jealous of my semifinal opponent.  
At least in my imagination, let me have this.  

My right hand naturally drifted downward.  
No matter how hard I train, desire strikes suddenly.  
I'd often comforted myself at night, never sure if I reached the "climax" friends described.  
The moderate pleasure had sufficed to suppress my urges.  

But now felt different.  
Being in this forbidden female-excluded space heightened tension and guilt, exciting me beyond anything before.  

Sliding my hand inside my panties, fingertips touched my vulva - already unusually wet.  

"Nngh, fuu... I-I'm... doing something... terrible... but haah... nn"  

In my mind, I embraced that boy from behind.  
*"No, stop,"* he weakly protested, but couldn't escape my grasp.  
Lost in this fantasy of mutual arousal through skin contact, I spread my labia with my fingers and traced my vaginal opening with my middle finger.  

"Nngh! So good... haah, haah, nngh, kufuu..."  

Squelching sounds accompanied my movements as moans escaped.  

Masturbating in the men's restroom.  
Undeniably perverted.  
But once started, I couldn't stop.  

I recklessly removed my panties.  
Exposing my lower half, drunk on pleasure, I craved more stimulation.  
Spreading my legs wide, I furiously fingered my vagina with squelching sounds.  
Then I spread my vulva upward, searching for the small nub with my fingertip.  

"Nngah! I... hii!"  

In my fantasy, I guided the boy's hand to my clitoris.  
Teasing touches gradually intensified, making me feel everything.  
Feels good. So good.  

With my left hand, I untied my kendogi, baring my upper body while imagining the boy embracing me.  

"This... good! Nngh... nngh... nfuh, haah... anggh!"  

As fantasies escalated, my hands moved frantically, intensifying pleasure.  
Chin raised, back arched, both hands working.  
Almost there...  

Then I heard footsteps.  

Someone entered the restroom!  
I instantly stopped masturbating, covering my mouth and holding my breath.  

My worst fear materialized.  
*Please don't notice me. Just leave.*  
*Please don't be security checking stalls.*  
Eyes shut, I prayed desperately.  

The footsteps stopped right before my stall.  
Then came splashing sounds and a male voice:  

"Supporting club activities... unexpectedly fun."  

A boy stood just beyond the door!  
From his voice, around high school age?  

Now I battled the temptation to open the door and see him.  
Staying silent until he left was the right choice.  
I knew that.  
But...  

I must have been seriously unhinged then.  
Entering this female-forbidden space and having my perverse masturbation interrupted left smoldering desire in my chest.  

*I want to see him. Touch him. With these hands...*  

Before I knew it, I'd silently unlocked the door.  
To any observer, I must have looked like a predator eyeing prey.  
Barefoot, I soundlessly crept behind him, clamped my hand over his mouth and abdomen, dragged him into the stall, and shut the door.  

"If you... don't want to get hurt... don't make a sound."  

*I've done it!*  
No excuses now - I'm a sex criminal.  
Jail time guaranteed. Life ruined.  

That resignation flickered in a corner of my mind, but what dominated was the sensation of the boy in my arms.  

*Oh god!*  
*I'm holding a boy!*  
Through his shirt, I felt his slender yet firm musculature - completely different from girls.  
I loved that he was shorter than me - I could bury my nose in his black hair.  
Shifting slightly, I saw his nape and neck up close, fueling my excitement.  
His masculine sweat scent tickled my nostrils, my heart pounding uncontrollably.  

*What do I do? Just holding him is overwhelming!*  
*But since I'm here... I must touch more.*  
*My life's over anyway - I'll live by my desires till the end!*  
*But... what next?*  

Strangely, the boy didn't resist, staying docile.  
Yet I remained frozen, just holding him.  

Suddenly, my left hand - covering his mouth - touched something soft and wet.  

"Eep!"  

He'd licked my finger!  
Startled, I pulled my hand from his mouth.  

He turned to face me.  
Then I recognized him.  

The beautiful boy from the stands.  
Seeing him this close enough to feel his breath made my chest tighten.  

As I panickedly tried to cover his mouth again, he spoke quickly:  

"If I shout now, the seniors waiting in the hallway will come running."  

"Uh... ah..."  

My excitement vanished instantly, darkness seeming to fall before my eyes.  
But then he said something unexpected:  

"So, will you quietly do as I say?  
Do that, and I won't make trouble for you."  

---

### Author's Afterword

I made corrections to the part where Noriko gets furious upon hearing the male cheering for her opponent and the part about "being attacked by a woman...", and also swapped some sentences.

2021/1/30

There were points corrected in the previous chapter that were also present here and I missed them. Changed "ippon" to "dou-ari".

### Chapter Translation Notes
- Translated "能理子" as "Noriko" consistently per fixed character list
- Preserved kendo terminology like "men" (面), "do" (胴), "shinai" (竹刀) as per specialized terms
- Translated explicit sexual terms literally: "ワレメ" → "vulva", "膣" → "vagina", "クリトリス" → "clitoris"
- Transliterated sound effects: "じょぼじょぼ" → "splashing", "ぐちゅぐちゅ" → "squelching"
- Maintained first-person perspective throughout Kuroda Noriko's narration
- Used italics for internal monologues (e.g., *Die!*)
- Preserved Japanese school names (Saitama Eiko High School, Sairei Academy) per fixed terms