## 67. Tournament Support ③ ~Unspeakable~

Suddenly dragged into a stall while being restrained, Yuu's first fear was that he might have been attacked by a gay man. He vaguely remembered hearing that in some parks, such people would gather in restrooms back in his younger days before being reborn.

However, upon reflection, this was a world with reversed chastity norms. Women were the expected perpetrators when attacking men. Indeed, the sensation against Yuu's back and the smell of sweat in this confined space suggested his assailant was female. She seemed taller than Yuu.

The woman's continued restraint without further action helped Yuu regain his composure. Her ragged breathing against the back of his head and neck indicated excitement, but her lack of violence was reassuring. Perhaps she had no sexual experience? In his original world, he'd heard virgins attempting to assault women would often blank out and try penetration without proper foreplay. Maybe this woman was inexperienced since she wasn't immediately groping him or reaching for his crotch.

Considering his seniors waiting in the hallway, Yuu decided to act. First, he needed to break the strong restraint. But resisting carelessly might make noise audible outside, potentially provoking his assailant and causing him pain.

So he tried licking the hand covering his mouth.

As expected, the woman jerked her hand away in surprise. Yuu immediately turned to see her face. Being male, he'd have protested if she looked gorilla-like.

At close range, her face showed tear streaks but wasn't unattractive. Her hair length was similar to Yuu's, almost mistakable for a man's at first glance. But with her oblong face, narrow eyes, high nose bridge, and thin lips, she gave a handsome rather than rugged impression - androgynous enough to pass as either gender. In Yuu's memory, she resembled a perfectly cast male-role actor from Takarazuka Revue. Far from a delicate beauty but fitting the "beauty in male attire" description - what Yuu considered a cool-looking woman.

Yuu instantly decided: he'd sexually counterattack this flustered woman who'd suddenly assaulted him. Before she could cover his mouth again, he spoke:

"If I shout now, the seniors waiting outside will come running."

"U...ah..."

The woman's face instantly filled with despair.

"So will you quietly do as I say? If you obey, I won't cause you trouble."

"Huh...?"

After a pause, she looked bewildered. Seizing the moment, Yuu grabbed the left hand that had covered his mouth. Her palm was large like his, rough with what felt like sword calluses - likely a kendo competitor from some high school. Yuu pressed further:

"Get caught as an attempted rapist? If you don't want that, do as I say without alerting anyone. Then maybe something good will happen?"

"Something...good? Ah!"

Only now noticing her hand was being held, her cheeks flushed crimson.

"Shhh."

Yuu raised a finger to his lips. The restraint had completely loosened.

"Ah...sorry..."

She hastily covered her mouth with the hand that had been restraining Yuu and lowered her eyes.

Seeing this gesture, Yuu found her unexpectedly cute. The gap between her dignified appearance and this vulnerability was appealing. Her long eyelashes and downcast eyes held a thrilling sensuality. Yuu turned sideways, keeping one hand clasped while stroking her hair with the other, tidying the disheveled strands.

The woman seemed flustered about how to react to having her hair stroked by a boy. Consciously aware of the male contact, her cheeks flushed as her gaze darted about. Yuu placed his hand on the back of her head, pulled her close, and captured her lips.

"Fmyu!"

How long had they been confined? He moistened her slightly dry lips with his tongue. She remained rigid, yielding to Yuu. Breaking the kiss, they stared at each other up close.

"Fah...this...k-kiss? For real?"

Still seeming unreal, she avoided eye contact, pupils darting nervously.

"Your name? Tell me."

"Huh? Ah...I-I'm Kuroda Noriko. 'Ability' no, 'science' ri."

Uncommon to use three-kanji characters instead of typical Noriko/Kinuko names.

"Hmm. Memorable name. I'm Hirose Yuu."

"Yu...u?"

"Yeah. Noriko, let's kiss more."

"Fah! Nn!"

Hearing "Kuroda," Yuu recalled Hayase-senpai's opponent but dismissed it. Now he focused on kissing. After several pecking kisses, they pressed lips slowly to savor the sensation.

"Nmuu...nn, fuun..."

Noriko's eyelids gradually lowered until she closed them, surrendering to the kiss.

After prolonged lip-pressing kisses, Yuu pulled back slightly and whispered:

"Open your mouth a little."

"Ai."

Obediently opening her lips, she gasped as Yuu's tongue invaded.

"Omuu!?"

Ignoring her wide-eyed surprise, Yuu ravaged her mouth, left hand firmly gripping her head. He forcibly tangled with her retreating tongue.

"Uwa...nm...nuu...jupa...au...fumu...uun"

Noriko's gasps mingled with wet, sucking sounds of saliva. As mucous membranes connected, her eyes grew dazed, face unconsciously succumbing to pleasure.

Meanwhile, Yuu reached for her chest to confirm the earlier sensations against his arms. Fortunately, her kendo uniform was open, revealing a plain white sports bra with noticeable cleavage - clearly substantial volume. Though pressed for time, a man naturally wants to confirm when breasts are present.

The bra material felt stretchy despite firm compression. While deep-kissing, Yuu slid the bra upward with both hands.

"Ho...what beautiful breasts."

"Huh?"

Saliva strands still connecting them, Yuu looked down. Broad-shouldered for a woman, her muscular chest featured perky bowl-shaped breasts.

*(Probably C or D cup despite not being huge)*

Yuu estimated. Though not exceptionally large, their shape was superb - clearly benefits of training.

His admiration lasted only a moment before grabbing them firmly.

"Hya!"

A cute gasp escaped her at the suddenness.

*(Hmm. Firm with perfect elasticity)*

Yuu twisted his body down and sucked the other nipple.

"Na! Eeh!?"

Yuu attacked relentlessly from the start. One hand kneaded while pinching and pulling the nipple; his mouth focused on rolling and sucking the other.

"Ya...wait...ah, hi, nnaa! I-i, don't...ann!"

"Noriko, your voice."

"U...sorry..."

Looking up, Yuu saw her hastily cover her mouth again.

"Feels good?"

Still covering her mouth, she nodded repeatedly. As he licked and pinched her nipples, muffled moans escaped. Her body occasionally trembled.

Though rushed, she clearly felt pleasure. Yuu repositioned to face her directly. Her sculpted body came into full view - impressively defined abs. Maintaining left-handed breast play, his right hand traced down her hard-muscled abdomen.

The delta region had thick black pubic hair with poor maintenance, but he noticed something else: extreme wetness.

*(Sweat? Surely not...)*

Schlick.

"Ngi!"

Schlick, schlick-schlick.

"Mu...a! U...uun!"

*(Knew women here were highly sensitive...)*

Unaware she'd been masturbating before he entered, Yuu noted her vagina was as wet as post-shower, slick and softened.

Bringing his schlicking fingers before her eyes, transparent fluid dripped from them.

"Noriko's quite lewd already. This wet."

"...!"

Ears burning crimson, Noriko kept her mouth covered and looked down. She couldn't admit she'd been masturbating. Though interrupted, her first kiss and breast play had made her body react sensitively, burning with unprecedented desire.

Embarrassed. But wanting more touch. The fantasy she'd been masturbating to was materializing differently. Though she'd initiated the attack, being dominated excited her intensely. But Yuu's next words nearly short-circuited her brain.

"Not much time. I'll insert it now. Spread your legs wide."

"...huh?"

"Come on, hurry."

Obediently spreading her legs wide, her vulva gaped open. The unused salmon-pink vagina glistened wetly, obscenely quivering.

Yuu temporarily pulled back, unbuckling his belt and removing pants and underwear without hesitation - for easier movement. His fully erect, fiercely upright cock stood revealed.

"......"

Eyes wide, Noriko stared speechlessly.

Her kendo-focused life left her sexually ignorant. She'd slept through middle and high school health classes. She'd never seen real male genitals, let alone nudity. Even during masturbation, she'd only had vague mental images.

"A...u...th-that...?"

Removing her hand from her mouth, she gaped at the cock. Ignoring her frozen state, Yuu covered her, right hand guiding his cock while whispering in her ear:

"Your first time?"

Seeing her nod repeatedly as expected, Yuu sealed her tightly pressed lips. His cock, coated with her fluids for easier entry, pressed horizontally against her drenched slit.

"! Fa...ahaa...nuu~n..."

Feeling the hot hardness, Noriko moaned uncontrollably, female instincts stimulated.

"It'll hurt at first. Hmm..."

Yuu pondered. Virgin penetration inevitably caused vocal reactions.

"Bite my shirt to muffle sounds."

Noriko looked at Yuu's white shirt collar.

"O-okay?"

"Yeah, fine. And hold onto me without hesitation."

"U...n..."

Yuu supported her back with his left arm under her armpit. Hesitantly, Noriko touched Yuu's back - now with permission, making her cheeks relax involuntarily. Remembering his instruction, she nervously bit his shirt. Just as she felt the hard object entering, an impact pierced her lower abdomen.

"Nguuuuihyaa! Aii! I-i-i-ihyii!"  
"Guo! W-wait, don't...clench! Oo...t-too tight! Relax, relax!"

"Ug...iai!"

Noriko thought herself pain-tolerant. Kendo training was harsh - slacking meant being struck with shinai by coaches. Sparring meant regular blows to unprotected arms and thighs. But defloration pain was beyond imagination - exacerbated by Yuu's exceptional size.

Meanwhile, Yuu encountered unexpected vaginal resistance mid-insertion, forcing him to stop. But he pushed through ruthlessly - no room for sympathy. As he forced through the obstructing flesh, agonizing tightness squeezed him painfully - clearly well-trained muscles. Her arms clenched his back painfully to endure the pain.

Yuu blew softly in her ear.

"Hin!"  
"Not fully in. Relax your lower body."

Her slight nod brought marginal loosening. He began shallow thrusts.

"Fu, fu, fuku..."  
"Gu, oo...n!"  
"Uwa!"  
"Ah...fully in. Whew.  
Sorry, but I can't hold back. I'll go hard now."

Noriko's face showed furrowed brows, closed eyes, and tear-streaked cheeks - whether from pain or not. Yuu whispered comfortingly:

"Feels amazing inside you."  
Her expression seemed to soften slightly. After a cheek kiss, Yuu began thrusting.

---

### Author's Afterword

2019/5/18

Revised the section after "Noriko thought herself pain-tolerant" regarding everyday pain experiences that seemed inappropriate.

### Chapter Translation Notes
- Translated "童貞" as "virgin" to maintain explicit terminology
- Preserved Japanese honorifics (-senpai) per style rules
- Translated anatomical terms directly ("vulva," "vagina," "penis")
- Rendered sexual acts without euphemisms ("insert," "thrusting")
- Transliterated sound effects ("schlick," "fmyu")
- Maintained Japanese name order (Kuroda Noriko)
- Italicized internal monologues per style guidelines