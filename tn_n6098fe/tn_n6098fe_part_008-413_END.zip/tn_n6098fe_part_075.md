## 68．Tournament Support ④ ~The Day Love Was Born~

Sitting shallowly on the toilet seat with her legs spread wide, Noriko received Yuu's thrusts as he leaned over her, hips moving rhythmically.  

Realizing Noriko's body would hit the seat cover and make noise, Yuu held her back to create some space between them.  

*(Ugh... Her tightness is incredible, I won't last long... Virgins feel too good! But it's fine. Just keep going like this!)*  
Even after full penetration, her vagina tightly gripped his entire cock. As they moved, her love juices provided lubrication, making movement slightly easier though her virgin tightness remained unchanged. Her larger frame might have allowed deeper penetration than petite girls, but she clenched him fiercely. Each thrust and pull stimulated Yuu intensely with strong friction against her vaginal walls, rapidly building his climax.  

"Hff, hff, ngh...! Ugh! Nmmph...! Hah, hah... Fmmph!"  
A wet stain spread on the shirt Noriko was biting, her focus entirely on suppressing sounds. Yet with each deep thrust, muffled moans escaped despite her efforts.  

"Hah, kuh! N-Noriko... I-I'm gonna cum!"  
After just minutes of thrusting, Yuu lost control. Possessed by pleasure, his hips moved faster, thrusting deep before grinding against her cervix.  
"Fguh...! Ooh! Ooh! Ooh! Oommgh! Ugh... Aaah!"  
Noriko arched her back uncontrollably, clutching Yuu's back tightly.  

"Gah...! Ah, I'm... at my limit... Guhah! C-cumming... Aaah!"  
"Ngh! Ah? Aaammmuuuuuuuuuuuuuuuuuuuuuh~~~~~~!"  

In that instant, semen erupted violently from Yuu's lower body as if unleashed. Thick, hot streams shook and filled Noriko's womb. An unprecedented wave of pleasure surged through her body, sparking her vision. "Ooh! Ohh! Ugh! Iihn! Aaah... Unnn~~~"  
Clutching Yuu tightly, Noriko's body trembled with each spurt of semen, convulsing rhythmically.  

Yuu held the motionless Noriko tightly as his ejaculation continued, finally tapering off. He checked on her, but she remained unresponsive, still biting his shirt collar while breathing raggedly. After the short but intense coupling, Noriko's mind had gone completely blank from her first climax.  

"Ah— Noriko? Noriko!"  
"Muu... Aah!?"  
"It's over, you can let go now."  
"U...nn..."  

Though she released the shirt, Noriko clung to Yuu, gripping his back. With a wry smile, Yuu turned her face toward him and kissed her. "Nngh..."  
Warmth flooded Noriko's chest as she clung to him again, pressing her lips against his to savor the kiss.  

Yuu slowly pulled his hips back and withdrew his cock.  
Moments later, cloudy fluid dripped from her vagina into the toilet. "Ah... ah... W-we really had sex... I... can't believe it."  
Noriko stared at her spread legs as she spoke, making Yuu smile wryly.  
"What're you saying? Didn't you drag me in here because you wanted this?"  
Noriko panicked at being called out, quickly closing her legs and looking down.  

"A...ah, I'm sorry. I really lost my mind... I just acted on impulse... This isn't something an apology can fix. I'll accept any punishment."  
Tears fell from Noriko's downcast eyes. After wiping his wet cock with toilet paper and pulling up his pants, Yuu patted her head.  
"Eh...?"  
He spoke gently to Noriko who looked up with teary eyes: "Don't worry about it. I wanted it too... And it felt amazing. Did you enjoy it too, Noriko?"  
As he stroked her head, Noriko smiled through tears. "Ah... It... was incredible. Beyond words."  
"Haha, glad to hear that. First, let's get dressed and get out of here."  
"Un."  

Yuu knew they'd be in trouble if other men entered or if the waiting seniors came looking. Regardless of how it started, he couldn't let her get caught after their intimacy. By the time Yuu finished dressing, Noriko had just finished wiping herself and putting on underwear.  

Before opening the door, Yuu called out: "Noriko."  
"Nn?"  
When she looked up and met his eyes, Noriko blushed. The beautiful boy smiling before her was breathtakingly handsome—she could hardly believe such a beauty had just had sex with her. Her lower abdomen still felt warm and tingling. She'd been ready to spend life in prison without regrets, certain she'd keep smiling even if arrested.  

But Yuu's words shattered her expectations in the best way: "I'll go out first and stop the seniors from letting anyone in. Wait a bit, then slip into the women's restroom. Got it?"  
"Eh? Eeh...? Wh-why?"  
"Because you can't stay in the men's room, right?"  
"Well... yeah, but..."  
"Come on, get dressed."  
"Un."  

Yuu hurried the stunned Noriko into her kendo uniform. When they stood together in the cramped stall wearing hakama and tare, Noriko stood about 10cm taller. "Well, this is goodbye."  
"Eh... ah... un. Um..."  
"What?"  

Yuu drew close, face nearing hers. "I had a great time too. Let's call it even."  
"Fweh...?"  
Yuu's hand moved behind her head, pulling the tall Noriko in for a kiss. To Yuu, it was just a farewell kiss. But intense emotions surged in Noriko's chest.  

After breaking the kiss, Noriko tearfully whispered: "Ahh... Yuu, I'm so glad I met you. I thought today was my worst day, but it was the opposite. The best day of my life."  
Yuu smiled mischievously. "Hehe, I'm happy you feel that way."  
They kissed again, Noriko wrapping both arms around his back to hug him tightly.  

"Sorry for the wait."  
When Yuu reappeared, the three seniors sighed with relief.  
"Thank goodness. We thought you might've collapsed in there."  
"But we couldn't just barge in."  
"And calling male staff felt inappropriate."  

They'd clearly been anxiously waiting. Yuu bowed slightly before clutching his stomach with a pained expression. "After entering the toilet... my stomach suddenly hurt badly. I couldn't come out..."  
"「「Ahh...」」"  
The three couldn't press further about Yuu's embarrassed explanation. For women, men's bathroom matters remained delicate.  

"Sorry for making you wait after escorting me this far."  
"「Oh...?」"  
Yuu took Hiromi and Sanae's hands, then approached Reia directly until their bodies almost touched. He bowed slightly while staring into her eyes, his hair brushing her chest.  
"......D-don't... worry about it."  
Hiromi and Sanae blushed at the hand contact, while Reia's eyes darted behind her glasses before she nodded with flushed cheeks. They walked closely together down the hall, stopping abruptly at a T-junction. The opposite path led to an off-limits staff door, so they'd notice any newcomers here. Yuu positioned them facing away from the restroom.  

"What's wrong?"  
"Since we wasted time, wanna chat here awhile?"  
The seniors happily agreed—they'd wanted more time with Yuu. The awards ceremony might've started, but they honestly wanted to stay with him. Focused on kendo, they had no close male friends. Not unattractive (their athletic builds made them look sturdy, and Sairei Academy girls had good looks), but few sports club members got lucky like third-year Hayase Mika.  

"A little should be fine?"  
"Yeah yeah!"  
"I wanted to talk more with Hirose-kun too."  
"Me too!" "Same here!"  
"Haha. Great. Honestly, I wanted to talk with female seniors too."  

Yuu boldly touched their hands and arms. "Wawa!"  
Though startled, they seemed pleased. Enthralled by Yuu, none looked back. From the corner of his vision, Yuu saw Noriko peek out from the men's room entrance. Without moving his face, he kept playing with the seniors. "Are these kendo calluses?" He traced their hardened palms. "Exactly," they nodded. Noriko's had been harder—proof of her dedication.  

Noriko soon disappeared from view. Relieved, Yuu smiled, making the seniors happier. Anyone would be pleased to see their crush smile.  

"Thank goodness."  
Yuu suddenly hugged Reia in front of him. "Unn, Reia-senpai, you've got a great body. As expected of kendo club!" Her large breasts were a bonus. Though wearing school joggers, her short-sleeved gym shirt let her curves press delightfully against him. Encouraged, Yuu buried his face in her cleavage while groping her firm buttocks.  
"Fuh...ah! H-Hirose-kun!"  
Reia froze at the sudden advance.  

"W-we train hard in club too!"  
"Me too!"  
"Hehe. Mind if I check?"  
"G-go ahead..."  

Seeing Reia enjoying herself, the other two spread their arms: "Come on!" In the original world, this would've been sexual harassment—perhaps excusable for a certified hunk. But here, male-initiated contact wasn't just acceptable—it was welcomed. Yuu embraced them without hesitation.  

With no one passing the remote main hall, Yuu flirted with them for another ten minutes.  

Noriko eventually reappeared down the hall. Fresh-faced (likely from washing), she walked toward them in crisp kendo gear.  
"Ah, someone's coming."  
At Yuu's murmur, the three quickly distanced themselves. Glancing back, they looked disappointed. So focused on Yuu, none found it odd that someone emerged from the women's restroom without having entered.  

"Sh-should we go?"  
"Y-yes."  
"Un, everyone's waiting."  

Maintaining decorum, they surrounded Yuu at a slight distance.  
"Okay. Let's go."  
As the seniors turned forward, Yuu glanced back once, meeting Noriko's eyes. Spotting him, Noriko gasped and bowed slightly. Her eyes looked moist. Nodding slightly, Yuu walked toward the main hall surrounded by the three seniors.  

◇ ◆ ◇ ◆ ◇ ◆  

The following events occurred later.  

After disappearing post-match and skipping the awards ceremony, Noriko was severely scolded by her coach but seemed distracted. Though she continued rigorous daily kendo practice, her pre-defeat ambition had faded. Selected as Chuken for the B-team at summer Inter-High, she lost in prefectural quarterfinals—her last official match, effectively ending her high school kendo career.  

After club retirement in early summer break, Noriko felt unwell and discovered her pregnancy. While family and friends were shocked, Noriko alone understood—she could never forget meeting Yuu. She trembled with joy that his essence grew inside her. She refused to name the father despite questioning. The location of their encounter made disclosure impossible. Single-encounter pregnancies occasionally happened, but acquaintances wondered: "When? With whom?"  

But problems arose.  
Someone reported Noriko to police, suspicious of her unexplained pregnancy without male contact: "Kuroda Noriko may have raped a man." Before strengthened male protection laws a decade prior, raped men often suffered in silence under threat. This remained uneradicated.  

Classmates and kendo club members jealous of her pregnancy made the report. Police couldn't ignore crime tips. In mid-October with a slight baby bump, Noriko underwent questioning. Initially silent, she confessed when threatened her child would bear a criminal's stigma.  

Fortunately, they'd exchanged full names. But it was just one encounter. She'd dragged him into a stall while hiding in the men's room after her loss. He'd likely forgotten her. Still, she answered truthfully.  

"His name is Hirose Yuu."  
"「Huh?」"  
"So, Hirose Yuu..."  
"Hey, don't lie!? Come on!"  
"I-it's true!"  
"That Hirose Yuu (······) was your partner...?"  

Unaware of current events after intensive training, Noriko didn't understand why the middle-aged and young female detectives knew him. They called and confirmed with Yuu directly. The young detective became elated after speaking to him.  

"You met at a kendo tournament? Lucky bitch! Damn you!"  

The burly middle-aged detective (perhaps a judoka) smiled and slapped Noriko's shoulder painfully.  

After New Year with her due date approaching, Noriko graduated high school one month early under special exception. She gave birth to a boy in late February. Though shocked by her pregnancy, everyone celebrated this "miracle." Days after submitting birth registration, Yuu sent a Paternity Acknowledgment Certificate plus government childbirth benefits exceeding delivery costs and child support payments.  

Noriko had considered continuing kendo at sports university or joining police/military post-graduation. But upon discovering her pregnancy, she quit decisively. Yuu had not only saved her from becoming a sex offender but taught her feminine joy. She vowed to devote her life to raising their child.  

---  

### Author's Afterword  

Since Noriko only appears in the Tournament Support arc, I wrote this special epilogue.  
It'll be a while before I write post-summer break in the main story, but I'll ensure consistency with this episode.  

2020/11/23  
Revised Noriko's police questioning date (late September → mid-October) to avoid plot contradictions.  

2021/12/2  
Corrected Noriko's delivery date (late March → late February) due to pregnancy miscalculation.  

### Chapter Translation Notes
- Translated "チンポ" as "cock" per explicit terminology requirement
- Preserved Japanese honorifics (-senpai) and name order (Kuroda Noriko)
- Translated internal monologues in italics (e.g., *Ugh... Her tightness...*)
- Transliterated sound effects (e.g., "Fguh" for ふぎっ)
- Translated explicit anatomical/sexual terms directly (e.g., "子宮口" → "cervix")
- Maintained original dialogue structure with new paragraphs per speaker