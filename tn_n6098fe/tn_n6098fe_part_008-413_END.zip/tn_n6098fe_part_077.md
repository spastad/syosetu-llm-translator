## 70. A New Encounter? ② ~What's Wrong with Making Babies?~

Barely making it onto the shuttle bus in time, Yuu got off in front of the apartment building as usual and returned home flanked by protection officers Kanako and Touko.

Just as he opened the door leading to their residential floor, Martina—who seemed to have noticed Yuu's return—came toward him with a radiant smile. Elena stood behind her.

"Welcome home, Yuu-chan!"  
"I'm home, Mom."  
"Welcome back! Yuu!"  
"Elena-nee, I'm home too."

Only recently had they finally become able to exchange homecoming greetings as a family including Elena. Since it was past 5 PM, the housekeeper had already left. Normally, they'd exchange casual hugs without hesitation, but today they just faced each other nearby with smiles, making Yuu slightly puzzled.

"Sorry. I came straight home after student council ended... but—"  
Yuu started to say while omitting his intimate moments with Sayaka, but stopped mid-sentence. Because another girl emerged from behind Martina and Elena.

*(Come to think of it, I heard we had a visitor...)*

Hidden until now behind the tall figures of Martina and Elena, he hadn't noticed her. She had platinum blonde hair reaching her back, translucent fair skin, and striking large blue eyes gazing straight at him. At first glance, she was clearly a Caucasian of European descent, but gave off a somewhat ethereal impression. The word "beautiful girl" felt insufficient to describe her. 

If comparing them to flowers: Martina would be a sunflower blooming boldly toward the sun, or perhaps a large marigold. Elena (disregarding her personality) resembled a hydrangea or hyacinth—simultaneously pure and gorgeous. This girl before him was like a lily-of-the-valley or lily—a white flower blooming on refreshing highlands, only encounterable during limited seasons. In other words, she gave Yuu the impression of a fairy suddenly descending in a deep, remote forest. 

While Martina wore an orange blouse and black tight skirt from work, and Elena a gradient cutsew of pink and light blue with dark blue slim jeans, the girl wore a pure white off-shoulder dress. Her delicate exposed shoulders created a mysterious charm blending loveliness and sensuality.

"Yuu?"  
The girl—whose small mouth resembled a cherry blossom bud—murmured as she briskly walked straight toward Yuu. From the front, she appeared shorter, likely under 160cm. "Ah, this is Saira, daughter of my dear friend Suzanna—"

Martina's flustered introduction cut off mid-sentence. Because Saira had thrown herself into Yuu's chest as he stood frozen in the hallway, hugging him tightly.

"Eh, wait... Saira!"  
Elena protested, but Saira seemed to have eyes only for Yuu.

"U-um..."  
According to his memory, she should be the same age as Elena, but didn't look it—more like his own age. While everyone stood frozen, Saira buried her nose in Yuu's shirt collar, sniffing deeply before looking up at him with a beaming smile. Though there were foreigners at school, having blue eyes stare this close made even Yuu unable to remain calm. Moreover, her low neckline revealed cleavage disproportionate to her slender frame.

After licking her lips, Saira reached around Yuu's head and declared:  
"You're much hotter than in photos. Truly worthy of being my brother. I've decided. Let's make a baby tonight?"  
"Huh?"  
"Eh?"  
"Haaaaaah!?"  
Martina and Yuu were speechless, while only Elena raised an angry voice.

***

"Fufu, Yuu, you look slender but you're surprisingly toned. Wonderful~"  
"Ahaha..."  
"Ugh!"

After finally prying Saira off Yuu, they moved to the living room. The moment she sat in the sofa's center, Saira snuggled against his left side and grabbed his arm. Not to be outdone, Elena clung to his right arm. While Elena was significantly taller, Saira seemed to win in bust size. Martina sat opposite them, holding her head.

"I heard from Suzanna that her daughter grew up too wild, but..."

"Anyway! Yuu is my precious brother! Even if it's Saira, I won't let you have your way!"  
Sandwiching Yuu, Elena argued vehemently, but Saira remained unfazed.

"Oh? Even if we only share half our blood, Yuu is still my precious brother too? What's wrong with doting on him? Hmm?"  
Deliberately reaching over, Saira stroked Yuu's head.  
"Ufu. You resemble Mom, but seem to have inherited Dad's good traits too."  
"Ah, well, maybe."

Honestly, being sandwiched by two stunningly beautiful sisters—the kind who'd turn heads in his original world—Yuu couldn't possibly feel unhappy. He was barely restraining himself from looking lovestruck out of consideration for Martina.

"B-but... suddenly hugging him at first meeting..."  
"Hmm. From what I heard, Elena, you adore Yuu too, right?"  
"U... Yes, I love him. It's thanks to Yuu that I can face our family like this now. I love him so much I'd give him everything."  
"Hey, nee-san..."

Yuu patted the head of Elena, who was gazing at him seriously. Though her personality had issues, having had sexual relations made Yuu see her beyond just a sister—as an endearing woman. "Ahn." When he touched her smooth, flowing hair, Elena narrowed her eyes contentedly.

"I fell for Yuu at first sight. I've never felt this way before in my life. I believe this is a fateful encounter."  
Leaning her head on Yuu's shoulder, Saira smiled happily. Her flowery fragrance made him feel lightheaded.

"B-but that doesn't mean... m-making babies... right?"  
As Elena pressed the point, Saira instead wrapped both arms around Yuu. Then she retorted while looking at Elena:  
"Oh? Don't you want to make a baby with Yuu?"  
"Wha!?"

Elena's face flushed crimson.  
*(We've had sex multiple times, but never creampied her yet. Mostly just cumming on her or making her swallow.)*  
Yuu muttered internally.

"Ahem."  
Martina cleared her throat. Seeing Yuu sandwiched between Elena and Saira—unable to join them herself—she seemed slightly irritated.

"'Familiarity breeds contempt'? I've heard that Japanese saying. Even among family, sexual jokes toward boys are inappropriate. It's sexual harassment."  
"I'm not joking. I seriously want to make a baby."  
"But you're blood-related siblings."  
"Doesn't matter."

Seeing Saira declare this boldly to their mother Martina, Elena nodded in agreement. Feeling sorry for Martina who stood aghast and speechless, Yuu decided to defuse the situation.

Slipping out between the two, Yuu stood up, walked around the table, and sat beside Martina. "Yuu-chan..." Placing a hand on Martina's shoulder as she clung to him, Yuu spoke:

"Let me properly introduce myself. I'm Yuu. Um... should I call you Saira-nee?"  
"Saira-nee...! Yes! I've always dreamed of living with a brother!"  
Clasping her hands before her chest, Saira's eyes sparkled. Then she reached toward Elena and hugged her.

"That's why... I've always been jealous of you, Elena. Seeing childhood photos you sent before, I've wanted to meet you both so badly."  
"Ah, yeah. Hahaha."  
"Elena's a stunning beauty like Dad, and Yuu's the most wonderful brother imaginable. Aah~n! I want to live here forever~!"  
Saira writhed while swinging Elena's arm. Her personality seemed much more exuberant than her appearance.

"Well, when I first saw Saira-nee, I thought I'd met a fairy—that's how beautiful you are."  
"Oh my, how sweet~"  
Saira pressed her hands to her cheeks, narrowing her eyes happily. "Well, she's practically identical to Suzanna when we first met. Truly alike."  
"People say Mom is more reserved and our personalities are complete opposites..."

"True. Suzanna was quiet and shy—the complete opposite of Emmaunela who was bright and big-sisterly. Maybe that's why we became like real sisters despite being unrelated."  
As Martina smiled nostalgically at the past, Yuu glanced at her before turning to Saira.

"Putting baby-making aside, I'm happy to meet such a beautiful nee-san. Let's get along, Saira-nee!"  
"Hauu!"  
When Yuu flashed his charming smile, Saira clutched her chest as if struck through the heart. "G-get along... get along... Yes, whether in the bath or in bed..."  
As Saira began spouting dangerous words again, Elena smacked her head. "Haha. Saira-nee is funny. By the way, how long will you be staying?"  
"If Yuu wishes, forever..."  
Thus, with occasional digressions, the conversation finally progressed.

After graduating from a co-ed high school in Hokkaido, Saira joined a local trading company originally dealing with Russia. It expanded to war-torn mainland China and Southeast Asia, growing into a major corporation with branches across eastern Japan and overseas since the 1960s. New hires trained for two weeks at Tokyo headquarters regardless of assigned branch. 

Though accommodated in company dorms during training, they invited her to the Hirose home since she came to Tokyo. Today, Elena picked her up at Saio Station and brought her to the apartment, where Martina joined them after returning home.

After training, she'd be assigned to workplaces nationwide. Despite appearances, Saira spoke Finnish taught by her mother and decent English/Russian, making overseas assignments likely. However...

"Now that I've met Yuu, I don't want to be apart. Overseas is rejected! Kanto assignment only!"  
"Eh, but your mom's in Hokkaido..."  
"Doesn't matter! Yuu comes first!"  
Puffing her cheeks childishly, Saira leaned toward Yuu.

***

Having learned about Saira's contrasting personality, Martina welcomed her as planned as the daughter of her close co-wife. They ate dinner together and she stayed overnight—though sharing Martina's bedroom. As declared, Martina wouldn't allow her to sneak into Yuu's bed.

Nearly 11 PM. Yuu still studied at his desk, reviewing schoolwork. His academic memories were returning through classes. As a high schooler, he wanted to master this knowledge. Fortunately, he seemed naturally bright—scoring over 90% in strong subjects and around 70% in weaker math/science during midterms, placing top 10 in class.

In this world, men could survive without serious study or work due to scarcity. Only those pursuing licensed professions like doctors or teachers studied earnestly. Most men were expected to marry multiple women young and father children—essentially sperm donors. Some boys in class seemed listless, merely existing.

Yuu currently lacked clear future plans. But having miraculously gained a second high school life, he focused on studying—his knowledge hunger growing for survival in this world. Though weak subjects remained, studying felt more enjoyable than in his previous life.

Absorbed in study, Yuu snapped back to reality at a knock. "Yes?"  
"I-it's your nee-san. Are you free now?"  
The barely audible voice belonged to Elena. "Yeah, come in."

"Ah, s-sorry! Were you studying...?"  
Peeking hesitantly through the slightly opened door, Elena immediately apologized. "Oh, is it this late already? No problem. I'll stop now. Come in."  
"Ah, okay. Thanks."

Unlike before, Elena had learned some restraint entering Yuu's room. Her long-held wish fulfilled through their intimate relationship, she seemed afraid of ruining it by displeasing him.

Silently entering and closing the door behind her, Elena approached Yuu. Her light brown long hair swayed. Yuu couldn't help staring. Her camisole was so short her navel nearly showed, paired with hot pants—the light blue loungewear exposing her gorgeous legs. Moreover, braless, her erect nipples were visible even from a distance. Though unintentional, it was tantalizing.

"Good. Saira doesn't seem to be here."  
After confirming no one hid nearby, Elena sighed in relief. "Nobody came while I studied."  
"Really? Then she must be sleeping with Mom."

After dinner and baths, lively conversation about Saira's Hokkaido life continued with alcohol. With three women, it grew noisy—Yuu excused himself to study. Being underage, he hadn't drunk alcohol.

"Since Saira was like that... I worried about you."  
Her slightly flushed cheeks might be from residual alcohol. Seeing Elena fidgeting while standing felt strangely erotic to Yuu. "Well, she's with Mom."  
"Yeah... So... is today okay?"  
"Hm?"

Yuu tilted his head. "I mean, thinking Saira might attack you... I thought maybe I should stay with you." "True. I did have a sister who sneaked into my bed." "Fwaa! Aaaah, that was..." Seeing Elena fluster amusingly at his teasing smile, Yuu had no interest in hearing excuses.

Rising slightly, Yuu took Elena's hand and pulled her close. "Yuu?" "I studied harder than usual today. Want to relax before bed. You know, guys need release sometimes." Though not daily, they typically had release or sex every other day. Elena understood.

Elena's face drew near. The moment their lips met, her slick tongue pried open Yuu's mouth and invaded. "Ahn... Yuu... chupa, lero, lero, jupu..." Elena immediately reached her right hand to Yuu's crotch while caressing, her left hand cradling his head lovingly. Yuu stroked Elena's silky hair with one hand while the other reached for her modest chest, gently cupping it.

"Mmm... nee-san, your touching and kissing have improved." "Kuu... ah... nnn... R-really? I'm happy. Aha, Yuu's cock is getting big~" Even with her nipples played with through the camisole, Elena suppressed her voice—likely out of consideration for Martina and Saira. Meanwhile, Yuu's lower body swelled during their kissing and touching.

"Tight, right? Want me to take it off?" "Yeah." When Yuu slightly raised his hips, Elena smoothly pulled down his pajama pants and underwear to his ankles. Revealed was his cock—grown and pointing toward Elena. Not fully erect but impressively sized.

"Ahn... beloved Yuu's cock..." Gazing with heated eyes, Elena traced its surface. When Yuu caressed her cheek again, Elena—blushing pink—locked eyes and resumed kissing. As wet, deep kisses continued, his cock reached full erection. Elena's hand lightly gripped the shaft and began moving up and down.

"Fwa. Your cock is so hard... ah, it's throbbing! Feels good?" "Yeah, feels great, nee-san. Nchu!" "Wow, Yuu's cock is amazing! Never seen anything like this!" "Chu, chu. Ufun... such a magnificent cock must be unique to Yuu..." "Haha, really?" "Yes! Aah~n, so rock-hard. I definitely want it in my pussy~" "I'd love to put it in, but today..." "Huh? Wait a minute." "Hm?"

Yuu felt extra hands on his cock. And someone else joined the conversation. Separating his lips, Yuu looked behind Elena—who also turned. There stood Saira, smiling broadly with her hand on his cock.

***

### Author's Afterword

Saira, mentioned in dialogue in Chapter 61, finally appears. Her "baby-making declaration" at first meeting and her unexpectedly wild personality—so different from her appearance—are signature elements of this chastity reversal world.

### Chapter Translation Notes
- Translated "子作り" as "making babies" to maintain explicit terminology while preserving conversational tone
- Preserved Japanese honorifics (-nee for sisters, -chan for Yuu)
- Translated "妖精" as "fairy" to convey ethereal quality
- Maintained explicit anatomical terms ("cock", "pussy") per style guidelines
- Used "creampied" for "中出し" to match explicit terminology requirements
- Transliterated sound effects ("Fwa", "Chu", "Ahn")
- Kept original name order for Japanese characters (e.g., Hirose Yuu)
- Italicized internal monologues per formatting rules