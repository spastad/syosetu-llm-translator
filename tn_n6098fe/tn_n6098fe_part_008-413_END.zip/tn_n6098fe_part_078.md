## 71. A New Encounter? ③ ~Skip Beat~

"Oho! Such magnificent length and thickness... and the color and luster are wonderful too!  
The indentation below the thick glans is perfect too. It'll definitely catch inside during thrusting and feel amazing.  
A-and imagining such a... such a rock-hard cock knocking against my womb makes me shiver!  
.........Fuu, this is the supreme and ultimate cock among all I've seen.  
Just imagining this entering me makes me wet.  
Could it rival Papa's cock that Mama always talked about?  
Unn, your balls are so heavy too♪"

"Hey, Saira! When did you—!? I thought you were sleeping with Mom..."

Saira traced her fingers from the tip down to the scrotum while marveling. Elena, furious about her precious alone time with Yuu being interrupted, showed her irritation, but Saira remained unfazed.

"Martina fell asleep right after we got into bed and talked a bit. Ufufu"  
"Now that you mention it, she kept refilling my wine glass... Could it be?"  
"More importantly, Elena, you're being sneaky too. Trying to monopolize Yuu."  
"Ugh... B-but as his sister, I—"  
"I told you earlier. Yuu is my adorable little brother too."  
"But—"

Seeing no end to this, Yuu placed his hands on both sisters' heads as they sat on either side of his erection.  
"Since we've been caught, there's no helping it.  
How about we ask Saira-neé to join us?"

"I-if Yuu says so..."  
"Ufufu. What would you like me to do?"

Saira smiled with crescent-moon eyes as she looked up at Yuu. She wore a sheer black negligee that transparently revealed everything except her nipples and crotch, creating an intensely alluring sight. Though she'd seemed fairy-like at first meeting, now she radiated a succubus-like sensuality.

Yuu stroked Saira's platinum-blonde hair with his left hand. It shimmered under the room's light, fine and soft with a fluffy texture.  
"Saira-neé, your hair is so beautiful."  
"Un. I love this hair inherited from Mama."  
Elena pushed her light-brown hair toward his right hand as if demanding attention too.

"First, let's kiss."  
"Nn"

When Saira took Yuu's hand stroking her smooth cheek, she rose to her knees and leaned in. Her other hand continued stroking his cock. Her unpainted lips glistened pink as they approached. Yuu tilted his face slightly and kissed her gently, savoring the soft texture...

"*Nnn!*"  
Yuu and Saira broke the kiss simultaneously.  
"What was that just now?"  
"As soon as we kissed, I felt an electric jolt in my head."  
"Me too... Hey, once more?"  
"Un"

They kissed again. Like a first kiss, it was light contact.  
"Nn... fu..."  
A sigh escaped unintentionally. Though only their lips touched, Yuu's cheeks burned hot, his mind going blank. Wanting more, he pressed harder. Saira's eyes had widened at the kiss but soon drooped, her cheeks pink with a dazed expression.

"Nchu... chuu... nnaa... nnfuun..."  
They repeatedly kissed and parted while adjusting angles. Simultaneously opening their mouths, their tongues touched and writhed like separate creatures, desperately pressing against each other and tangling up and down.

Yuu felt like pleasure chemicals were flooding his brain.  
Kuchu, pichu, chupa, chupuu.  
Unmindful of the sounds, they voraciously explored each other's mouths.

"Yuu! Saira! How long are you two going to kiss by yourselves?!"  
Elena shook Yuu's head, bringing him back to reality.

"A... ah?"  
"Faa... nn?"

Staring at Saira's face that resembled an exquisite Western doll, Yuu seemed dazed—perhaps overwhelmed by the kiss's intensity. He'd never experienced such pleasurable kissing before... though actually, kissing Elena felt incredible too. Maybe their blood relation was a factor.

Suddenly, a past memory surfaced. Around age 11-12, Yuu started avoiding greeting kisses with his mother and sister because each kiss made his head tingle and lower body throb, making him fear he was doing something wrong. It was likely adolescent confusion and fear about sexual arousal, compounded by the taboo of being blood-related family. Instinctively, he'd avoided falling into pleasure's abyss. He might have coped better if he'd consulted someone or had time to think calmly, but Martina and Elena's daily passionate advances left no room for composure.

Yuu's recollection was cut short.  
"Aahn, Yuu, more!"  
Saira immediately pushed forward, her glistening red tongue peeking between her lips.  
"No! My turn now!"  
"Opu!"  
Elena forcibly joined in.  
"Egh... aghmu... reero..."  
Their tongues began ravaging Yuu's half-open mouth. They sandwiched and toyed with Yuu's tongue. Elena licked up drool from the corner of his lips. Saira meticulously licked his upper and lower lips. Competing for territory, they kissed Yuu's forehead, nose, cheeks, and chin.

After a while, Saira stared at Yuu with moist eyes, her mouth area slick with drool, and squirmed.  
"Aahn... I'm already so wet...  
Hey, Yuu? Let's have sex?"  
"Nooo, I go first!"  
"Elena, you do it regularly, right? Let me have tonight!"  
"No way!"

While arguing, both began removing their bottoms. Though thrilled as a man, Yuu worried their competition over his cock might spiral out of control. Part of him wanted to indulge his sisters in passion, but that would mean a two-hour session—maybe longer with Saira—repeating his first night with Elena. Tomorrow was Saturday with morning classes and student council duties. Maybe saving intercourse for another day was wiser. Though slightly foggy-headed, his middle-aged mentality and sexual experience helped him resist being consumed by lust.

Yuu extended both hands and placed them on the sisters' heads.  
"*Ah*"  
Looking up in unison, Elena and Saira waited as Yuu spoke.  
"With such beautiful sisters looking so alluring...  
I'd love to see you two in even lewder poses."

"Nnn?"  
"What do you mean?"

In Yuu's original world, men appreciating women's sexy displays was normal. But Elena and Saira only knew a world where men's exposed skin pleased women, while women exposing themselves to men without consent was considered perverted.

"Meaning... while sucking my cock, show me how you masturbate."  
"Ah~, un. Okay."  
"What?! Heh... fūnn... impressive, Yuu."

Elena remained nonchalant—this play seemed normal to her since their first oral session. Saira, however, looked impressed, suggesting such a request required courage.

"Alright! Let's all feel good together!"  
"Ufu. Sucking Yuu's peepee makes it so much easier!"  
Both seemed enthusiastic. Elena shamelessly stripped to reveal her slender body. Saira flung off her negligee—her braless breasts jiggled beautifully. Despite her slim frame, they were ample and bowl-shaped, likely C-cups. Her panties were half-transparent, revealing pubic hair matching her silver-white head hair. When removed, a transparent strand stretched from her vagina to the crotch.

"Ufu, Elena. Who can make Yuu feel better?"  
"Ha, I won't lose!"

From Yuu's view, Elena (right) and Saira (left) knelt around his cock, stroking it with one hand while the other began fingering themselves. Soon, squelching sounds became audible.

"Lero, leroo... afun, oihii"  
"Amu amu... chupaa... nn, nfu, jururi"

While Elena licked his urethral opening and precum, Saira took the glans into her mouth, meticulously licking with her tongue.

"Nn, nn, naa. Sucking Yuu's peepee... kufu, makes me feel so lewd... aa, aann!"  
"Chu, chu, afuun... I know! Seeing such a cock up close... aa, I can't stop throbbing... nn, uun"  
"O, ouu... nn, feels... good..."

Despite busily stimulating themselves, they diligently sucked his cock. Unbothered by their tongues touching, they endlessly licked and sucked with wet sounds.

Yuu moved his hands from their heads to their breasts—Elena's modest mounds and Saira's palm-sized breasts—kneading the nipples until they hardened.

"Aann! Yuu!"  
"Hauu! Having Yuu play with my nipples... feels so good!"  
Both looked up with heated eyes, moaning pitifully. Silently locking eyes, they sandwiched the glans between their lips and began tangling tongues.

"Kuh..."  
The rare sight of two naked beauties making out while connected to his cock was unrealistically erotic. Glancing down, Yuu saw puddles of transparent fluid beneath both sisters. Elena and Saira were clearly aroused despite the deep kissing. Their hands still frantically stroked his shaft.

"Nchu, chu, afuun... Sairaa... fett! A, wait... a, a, there... noo!"  
"Kufufu. Both Yuu and Elena are adorable! I'll make you cum!"  
Saira switched hands, expertly jerking Yuu's cock while inserting fingers into Elena's vagina, making squelching sounds. Whispering in Elena's ear:  
"See? You're already so wet... How about here? Feels good?  
Come on, you can cum first. Then I'll deliciously enjoy Yuu's cock."

"Ya, yadaa... haun! There, no grinding... I, I want—"  
"Ann"

Before Yuu's eyes, Elena and Saira began fingering each other's genitals while still handling his cock. Meanwhile, Yuu felt his climax approaching.

"Ku... neé... Saira-neé"  
Nearing orgasm, Yuu vigorously played with both sisters' nipples.  
"Aann... I wonder who... will cum first?"  
"A, a, a, yaa! Se, Sairaa... stop it! Ha, ha... I, I'm cumming!"  
Elena shook her head as if resisting. Smirking, Saira engulfed the glans and began sucking.  
"Uoo! Th, that... aa!"  
Yuu's back arched sharply, chin lifting.

Elena tried continuing but seemed disadvantaged. Despite her innocent appearance, Saira seemed experienced—perhaps bisexual. If this continued, both siblings would be made to cum by Saira.

Impulsively, Yuu slid off the chair to his knees.  
"Aaun... peepee... faa! Wh, what?!"  
His left hand slid down Saira's back to her butt—her petite frame proved convenient. Tracing her vaginal entrance coated his fingers in slick fluid. He inserted deep inside, thrusting while grinding against her front wall.

"How's this, Saira-neé? Does this feel good?"  
"Aauun! Nnnn~~~ y, yes! Ann, I'm weak there!  
Mufuu~, I'll return the favor... amu"  
"Ooa!"

As Yuu stimulated her G-spot, Saira deepthroated him, using tongue and lips while bobbing. Relieved by Yuu's intervention, Elena focused on sucking.

The three continued mutual stimulation in near fusion. Within three minutes, the end approached.  
"Guaa! I... can't... I'm cumming!"  
First to break was Yuu under the double fellatio.  
"Wa, me too... a, ahiiin! Saira... making me cum!"  
Elena cried out immediately.  
"Ha, ha... neé... Saira-neé... a, kaha, I'm cumming... nn"  
Yuu called to his sisters while fingering Saira's G-spot.

"Oou! Cumming!"  
"Nmu... ugh, agh... no, cumming... I'm cumming!!"  
"Muuuuu... nn, nn, nfuu!"

Dopyu dopyu dopyuu!!!  
Yuu and Elena climaxed simultaneously—thick semen shot through the sisters' lips.  
"Aann, sho gooiiii"  
"Igh, agh, kuhii... in!"  
Slightly later, Saira came with a dazed expression, tongue out as she squirted. Elena also caught semen with her tongue.

"Hafuu... wow... so much came out..."  
"Ahaa... Yuu's seeed... delicious"  
"This much... Yuu has impressive volume too... kufu"

Before Yuu, Elena and Saira competitively licked semen off each other's faces, even cleaning white droplets from cheeks. Their hands still held his cock.

Having ejaculated, Yuu felt refreshed. Though capable of continuing, he wanted sleep before tomorrow's commitments. He contemplated how to persuade his aroused sisters to return to their rooms.

---

### Author's Afterword

Pervert, pervert, pervert...♪  
Three perverts.

↑If you're wondering what this is about, search "SKIP BEAT" "KUWATA BAND".  
But YouTube only has covers, no original... Superfly's cover has character though. Hatsune Miku version definitely says "sukebe".  
First-timers should read the lyrics too. If you like pervy stuff, you'll probably enjoy it.  


### Chapter Translation Notes
- Translated "スキップ・ビート" as "Skip Beat" to preserve the musical reference from the author's afterword
- Translated explicit anatomical terms directly ("チンポ" → "cock", "膣" → "vagina")
- Preserved Japanese honorifics (-neé for sisters) as per style rules
- Transliterated sound effects (e.g., "dopyu dopyu dopyuu" for どぴゅどぴゅどぴゅう)
- Rendered sexual acts without euphemisms ("射精" → "ejaculation", "潮を吹いて" → "squirted")
- Maintained original name order (Hirose Yuu, Hirose Elena, Saira Yutilainen)
- Italicized internal monologues (e.g., *This is concerning.*)
- Translated "スケベ" as "pervert" in afterword to match the song's playful context
- Kept cultural reference to "SKIP BEAT" song intact per author's note