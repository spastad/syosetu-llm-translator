## 72. A New Encounter? ④ ~Morning Moon~

### Author's Preface

For those who didn't understand the meaning of the previous afterword, I've added an explanation.

---

  

"Mm... wha...t?"

A weight and warmth on his chest and stomach area.

Along with a gradually building pleasure in his crotch, Yuu began waking from sleep.

  

"Aha. Yuu, good morning."

As Yuu opened his eyelids, his vision filled with the familiar white ceiling of his room.

Shifting his gaze toward his own body, he found Saira smiling cheerfully beside him under the blanket.

  

"Ah, good morning, Saira-nee... wait no!"  
"Ufufu. Your cock's energetic this morning♪"  
"Oof!"

  

Last night, he'd managed to persuade both sisters to return to their rooms.

Yet Saira was completely naked, pressed tightly against his right side as if she'd never left.

Moreover, Yuu's pajama pants and underwear had been pulled down to his thighs, and she was stroking his morning erection. Even his T-shirt had been pushed up to his chest.

  

Had this been the pre-reincarnation Yuu, he would've panicked like when his sister assaulted him before.  
But the current Yuu remained calm even after comprehending the situation.  
He'd just learned yesterday that his half-sister Saira had an unexpectedly wild personality despite her fairy-like appearance.  
So while he hadn't anticipated a nighttime visit, a morning ambush was well within expectations.  
Rather, upon waking, Yuu immediately felt a bubbling surge of passion.

  

The curtains were closed, leaving the room dark.  
But sunlight peeked through the gaps, and the sound of birds chirping "chun chun" suggested it was around dawn.  
Probably still before his usual waking time.

  

Saira's distinctive platinum blonde hair shimmered in the faint light, her naked body generously displaying smooth skin. Though covered by the blanket in the dimness, she glowed white and beautiful like moonlight.  
Moreover, her front pressed against Yuu who lay on his back, making the warmth feel pleasant.

  

"Kuh... ah..."  
"Ufu. Yuu... so cute"  
Saira's hand, which had been stroking the surface, now lightly gripped his cock and began jerking him off.  
While stroking Yuu's head with her other elbow-propped hand, she brought her face closer.  
*Chu*, their lips pressed together.  
A minty scent came from Saira's mouth.  
Had she rinsed with mouthwash beforehand?

  

"Good morning kiss. I got the first one."  
"Se-, Saira-nee..."  
After pressing her lips two, three more times, Saira gazed at Yuu with her blue eyes and relaxed her mouth.  
Viewed like this, she seemed like an angel or fairy—a woman of fantastical beauty.

  

"I tried to sleep properly after that?  
But my body got all hot, so I masturbated while thinking of Yuu before sleeping.  
This morning too, I wanted to see Yuu first thing, so I woke up early...  
Oh my, seeing this cock, I just can't hold back."

  

*Are all my sisters sex demons?*  
Yuu felt exasperated internally.  
To avoid disrupting his routine, he'd ordered Elena not to ambush him morning/night without permission.  
He'd said he'd initiate when he wanted to ejaculate.  
He'd even threatened to leave home or kick Elena out if she attacked him in his sleep.  
If left unchecked, she'd clearly demand Yuu 24/7.  
But he hadn't said the same to newly arrived Saira, hence this outcome.

  

"Honestly..."  
"Hey, let's do it? Put it in? I can't hold back anymore. C'mon, just the tip?"  
Yuu found it strangely relatable that this world had the same "just the tip" excuse.  
Though the roles were reversed, the result would inevitably go beyond just the tip.

  

"Haa. If my sister next door notices, it'll be trouble. Can you keep quiet?"  
They'd been whispering closely already, but at Yuu's words, Saira whispered even softer.  
"Mm. I'll hold back, won't make noise. But ah, if Yuu's cock enters me, I might moan. Ufu."

  

Interpreting this as consent, Saira smiled happily and straddled Yuu's lower body.  
She clung tightly to him.  
Her ample breasts pressed *munyu* against Yuu's chest, their softness palpable.

  

Suddenly Yuu wondered.  
No matter how attractive women were in this world, they had minimal experience with men.  
Every woman Yuu had slept with so far had been a virgin.  
Was this horny Saira the same?  
As Saira brought her face close for another kiss, Yuu asked.

  

"Hey, Saira-nee?"  
"Mm... what?"  
"Aren't you a virgin?"  
"Nfu. Why?"  
Saira stared at Yuu with big blue eyes, a mischievous smile playing on her lips.  
"Umm, just a feeling. You seemed experienced.  
Do you have a boyfriend?"  
He guessed she didn't currently, but asked anyway.  
Saira chuckled "fufu".  
"Haven't dated anyone in over half a year."  
"So you've had boyfriends before?"  
"Well yeah. Let's see..."  
Tilting her head cutely, Saira began counting on her fingers.  
Even this gesture was coquettish and charming.

  

"Three guys I had sex with.  
Including those I dated but didn't go that far, maybe five."  
"Heeh"  
Even considering she attended a co-ed school, three partners by age 18 was quite experienced in this world.  
Her beautiful, ephemeral looks must be irresistibly attractive even to this world's men.  
But Yuu's assumption was betrayed by Saira's next words.

  

"But for some reason, none lasted long.  
After just three ejaculations in one night, they'd say 'no more' the next day.  
By fall of third year, rumors spread—boys would run away if I just spoke to them. So rude!"  
"Ah..."  
"Plus my current company's local branches are all women.  
Ah, I was depressed thinking I'd grow old without ever having sex again... then Martina contacted me.  
When I learned I'd meet Yuu—who I'd only seen in photos—I was overjoyed.  
Ufufu. To have such a wonderful brother. With a cock bigger than any I've seen! Nn~"

  

Saira stuck out her tongue slightly and pressed her lips against Yuu's, prying open his mouth.  
Naturally, Yuu met her with his own tongue.  
"Nfuu, *rero chupa*... *chu*, *churun*! Nku... Yuu... *amu*... *rero*, *rero*, nn~~~ *chu*!  
Afuu, kissing Yuu feels so good... I'm getting so wet...  
Can't hold back anymore. W-want it in! Putting it in?"

  

After suddenly exchanging saliva in a passionate kiss, Saira—wearing a dazed expression—placed a hand on Yuu's cock without waiting for consent.  
At this point, stopping was impossible.  
"Nn... okay, Saira-nee"  
Stroking Saira's silky hair while placing his other hand on her slender waist, Yuu awaited the moment.

  

When the tip touched Saira's already drenched vaginal entrance, it made a *kuchuri* sound like splashing water.

  

"Nnn!"  
"Kuu..."  
"Ha... w-wait... i-it's too big, won't go in.  
I knew it was huge but... ah, aahhh..."  
"Se-, Saira-nee inside... so tight"

  

For Yuu, Saira was his first non-virgin partner.  
But apparently, her past partners weren't particularly large.  
Though not a virgin, Saira's interior wasn't loose at all—rather, it felt tight.

  

Yuu whispered gently to Saira who frowned with a pained expression.  
"Okay? Saira-nee. Need help?"  
"Nn... fi... fine. If I go slow... Thanks, Yuu"  
Smiling slightly painfully, Saira lowered her hips to advance the insertion.  
"Nkuu!"  
Her hands on Yuu's shoulders pressed painfully hard.  
Through small hip movements, Yuu felt his cock gradually entering.  
"Ahh, nn! Going in... ku... fu"  
As Saira lowered her chin, her hair cascaded onto Yuu's face.  
When Yuu brushed it aside, their eyes met.  
"Haan! Ah... i-it's in... ohh"  
Saira's attempt at a cheerful smile instantly slackened into lewdness.  
"Am... aazing... so deep... Yuu's cock... thrusting...  
Ha, ha, hahi... my uterus... being pushed up. Ah, first time... ehehe, ehehehe"  
"Saira-nee?"  
Finally connected, but her eerie laugh ruined the mood.

  

  

  

  

Saira rode him with her hips barely covering his nipples.  
Though not particularly fast, her pace was steady, making her bowl-shaped beautiful breasts sway.  
Yuu cupped and kneaded them with his right hand while stroking her back to buttocks with the other.  
Her long silver hair dangled down, its ends tickling him as it swayed.

  

"Nn... ahh! Ahh! Afunn... Yuu's cock, shoo good... ann! So... so good... didn't... know... feels good!"  
"Saira-nee, lower your voice more"  
"Aah... sorry... can't help... it comes out"  
"Can't be helped"

  

Yuu pulled the blanket up to cover Saira's delicate shoulders and head.  
This should muffle her somewhat.

  

"Ah... aahn... Yuu..."  
Saira—wearing a euphoric expression—pushed forward with her red tongue out.  
With the blanket covering them, her sweet scent filled the space, making Yuu dizzy.  
Stroking her silky hair, Yuu also extended his tongue to tangle with hers.  
After making wet *picha picha* sounds, they pressed their lips together with a *buchu*.

  

"Nmu! Nn, nn, uuuu~n..."  
"Puhah, Saira-nee, I'm... feeling so good too... nna"  
"Yuu... I'm gonna... ahhnn! C-cumming maybe"  
"Ooh..."

  

*Zun, zun, zun*—Saira's hip movements accelerated.  
Burying her face in Yuu's neck while gripping his shoulders, she focused solely on riding.  
"Ahh... ahhh! Nnnmu..."  
Leaking moans, Saira pressed her mouth against Yuu's skin.  
"Nn-, nn-, nn... vuaa, iih, iih, Cumming! Ah........ kuh haa..."  
Only at that moment did Saira arch her back before collapsing again.

  

"Kuh... kufuu... ehe, ehehehehe. Came.  
Ahaa... first time coming this fast... Haan, Yuu, A-MA-ZING! *Nchu*"  
Radiating joy, Saira smiled broadly and kissed Yuu.  
"Haha, glad you enjoyed it that much."  
"Cause I only came during sex like... one out of three times before."  
"Really?"  
"Yep. All thanks to Yuu's cock... no, everything about Yuu being amazing.  
Ufu, sneaking in first was the right call~"

  

Saira kissed not just Yuu's lips but showered his cheeks and neck with kisses too.  
Yuu smiled wryly but thrust upward while grabbing her small buttocks.  
"Hyaun!"  
"My turn to move now."  
He thrust deep, gouging her vaginal depths.  
"Yaah, ahh... whoa, ohh, shoo good! Yuuuuuu~~~"  
Saira gasped open-mouthed while clinging to Yuu.  
"Ah, haan! Just came so... ahii... that deep spot... if you thrust there... I'll... cum again!"  
"Let's cum together this time, Saira-nee"

  

Despite the morning chill, sweat beaded all over Yuu's body under the blanket while thrusting up into the mounted Saira.  
Where they touched had already grown slippery with sweat.  
But far from minding, Saira panted while clinging skin-to-skin.

  

With each *zun, zun, zun* thrust, lewd *nucchu, nucchu* sounds came from their joined parts.  
"Ahii... hiin! Yuu's cock... raging inside me! First time being ground like this... SU-PER good! More! More, please... ahhaan! Good, cumming!"

  

Saira moaned cutely near Yuu's ear.  
Unconsciously, she began moving her hips in sync with Yuu, creating a mutual pounding rhythm.  
Each time, his glans knocked against her descending cervix with a *kotsun*.  
Saira's eyes and mouth slackened, drool dripping unnoticed from her lips.

  

Meanwhile, Saira's smooth skin clinging tightly, her sweet scent, and especially the vaginal folds tightly gripping his cock guided Yuu toward intense pleasure.  
"Ah... kah... I'm... c-cumming too, Saira-nee"  
"Hahi, hahi... cum... inside me... fill me with... your seeeed... kyau! So intense! Cumming, cumming, me too... cumming!"  
"Saira-nee... nn!"  
"Yu... u..."

  

Locking eyes, Yuu and Saira pressed their lips together and climaxed simultaneously.  
"Gumu! Uu... Cumming!"  
"Nn... vii... ih, ohh, ohhooo... vuun! Nn!"  
As hot semen pulsed *doku doku doku* inside her, Saira rolled her eyes white for a moment and trembled *puru puru*.  
"Ahfe... coming... Yuu's seeed... amazing, so much..."  
"Haha... Saira-nee, felt incredible..."

  

Wearing a sloppy *ehera* smile, Saira clung tightly while greedily licking Yuu's lips. Yuu also extended his tongue for *chupa chupa* tangling.  
"Mufuu... baby-making sex with Yuu... felt better than I imagined... ann, still coming out. Aha... this'll definitely get me pregnant~"

  

When Yuu tensed his hips, more semen *pyu* spurted out.  
Inside her vagina, Saira still felt the hard cock plus the joy of receiving seed—her face remained that of a lust-drunk female.  
At this rate, a second round seemed inevitable at her urging.

  

But then, the alarm clock on the bedside table beeped.  
Yuu silenced the alarm while patting Saira's head.

  

"Fuu. Got energetic this morning. But gotta get up now.  
I have school, and my sister or mom might find us soon."  
Hearing this, Saira stayed silent briefly before nodding reluctantly.  
"Sh-, guess so.  
Well... baby-making sex with Yuu was incomparably better than any boy before."

  

Finally separating, Yuu sat up on the bed edge.  
"Ah~, sweated a lot. Should shower quickly."  
Hearing this, Saira smiled mischievously, pressing her cheek against Yuu's chest while looking up.  
"Shower... together?"  
Yuu nearly accepted but barely stopped himself.  
"Nah, better not. Who knows how long it'd take showering with Saira-nee."  
"Fufu, too bad. See ya later~"  
Though removing her cheek, Saira looked up at Yuu and showed an angelic smile.

  

  

  

  

---

### Author's Afterword

Saira was the thirteenth woman the protagonist had full intercourse with, and the first non-virgin.

Though he never used contraception with previous partners, none got pregnant.

Timing issues or men losing their erection midway might be factors.

The main reason, as mentioned in the story, is that relationships never lasted long.

Even in this gender-reversed world where drop-dead gorgeous men naturally attract swarms of girls, her partners fled after the first night saying "my body can't take it" due to her excessive sexual appetite.

While Kuroda Noriko from the Tournament Support arc left a strong impression in the opposite way, we bid farewell to Saira for now.

She's scheduled to reappear after several school events.  


### Chapter Translation Notes
- Translated "モーニングムーン" as "Morning Moon" to preserve the dawn setting and romantic connotations
- Maintained explicit anatomical terms ("cock", "vagina", "semen") as per style guidelines
- Preserved Japanese honorifics ("Saira-nee") and name order ("Hirose Yuu")
- Transliterated sound effects (e.g., "chun chun" for bird sounds, "nucchu" for wet noises)
- Italicized internal monologue *(Are all my sisters sex demons?)*
- Translated sexual euphemisms literally ("baby-making sex" for 子作りセックス)
- Used gender-neutral "they" when original Japanese subject was ambiguous
- Formatted simultaneous orgasm description with simultaneous quotes ""Yu... u..." / "Gumu!""