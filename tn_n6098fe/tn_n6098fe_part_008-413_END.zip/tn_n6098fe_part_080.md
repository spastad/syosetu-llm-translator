## 73. Ball Games Tournament ① ~Shake Hip!~

The new week began.

This Friday was the day of the ball games tournament.

Since this was the first year boys would participate, the organizing committee established in late last month had held numerous meetings, and negotiations with the school administration had also taken place.

Yuu participated as an observer but actively contributed opinions from the male perspective.

In his previous high school life, Yuu had been absorbed in part-time jobs and never participated in extracurricular activities.  
As a result, apart from a few friends who shared his hobbies, his social connections were shallow, and he had almost no opportunities to get close to girls, let alone get a girlfriend.

But now, thanks to his involvement in the student council, his female acquaintances kept increasing.  
Though it was co-ed, there were few boys and they weren't enthusiastic about extracurriculars, so Yuu constantly found himself surrounded by girls - yet he surprisingly adapted smoothly.  
From the beginning, Yuu had consciously maintained a friendly attitude toward every girl he met since enrollment.  
Perhaps because this impression had spread, the senior girls he met through student council activities generally treated him favorably.  
Even without Yuu making special efforts, the atmosphere was naturally easygoing from the start.  
This created a positive cycle where Yuu could enjoy conversations comfortably.

Additionally, though he was just a first-year with much to learn, his core was that of an adult with work experience.  
He was accustomed to the entire process of planning proposals, coordinating in meetings, and taking action.  
As a result, the senior girls increasingly regarded him as a mentally mature and reliable boy.  
Occasionally, he almost mentioned "email" or "cell phone" as communication methods, earning him puzzled looks.

Thus, Yuu himself found it unexpectedly enjoyable to engage in activities for the students.  
Being able to work closely with Sayaka and others who had become intimate with him was also significant.  
For these reasons, he was determined to make this year's ball games tournament a success.

From Monday to Thursday after school was the period for players from each class to practice using school facilities.  
This too differed from previous years when they'd gone in unprepared.  
As a private high school, Sairei Academy had better facilities than public schools:  
The large First Ground near the main gate, the medium-sized Second Ground on the opposite side beyond the administration building and gymnasium, and the Third Ground across the road beyond the backyard.  
Tennis courts, outdoor basketball/volleyball courts.  
A two-story gymnasium and martial arts hall.  
Negotiations with clubs who couldn't use their usual practice spots during this period proved troublesome, so off-campus facilities were rented as alternatives.

Participants in the ball games tournament were all six classes from three grades except physical education majors.  
Even dividing the four afternoons into 45-minute morning and afternoon slots, each class only got one practice day (remaining slots reserved for rain delays).  
Thus it was less about practice and more about confirming position coordination.  
After all, members of relevant sports clubs were prohibited from participating, so most players were amateurs.

In the boys' class, groups of six were formed to support each assigned class.  
Yuu was assigned to Class 5, which he'd had various connections with since April.  
Not only Higashino Rei who was always with Yuu, but Yamada Masaya also joined this time since participation was optional.

"Since it's a gender exchange event, Hirose should lead."  
With this unanimous group decision, Yuu was made group leader.  
Looking at the participant list copy from Class 5 delivered via their homeroom teacher, he saw soccer practice was scheduled for the first Monday slot at Second Ground.

"Shall we head over then?"  
"Sure"  
"Mhm..."

About half responded normally while the other half seemed hesitant.  
Despite experiencing two gender exchange events, the typical male students still reacted with caution.

*(Looks like the left-right combo is playing in soccer. Which means...)*  
While walking outside from the second school building, Yuu glanced at Rei.  
Sensing his gaze, Rei tilted her head quizzically. "What?"  
"Nothing," Yuu swallowed his words and brushed it off.  
With her petite build and androgynous features, even such gestures made Rei seem more adorable than most girls - which was problematic.  
Among first-year boys, though not as popular as Yuu, Rei also had many female admirers, and Yuu knew she had enthusiastic fans.  
Their representatives were the "left-right combo" - volleyball club members Sato Risa and Ukawa Miyoko who were at the Second Ground they were heading to.

Walking along the school path, they passed groups of sailor-uniformed girls walking home in small clusters, while others in gym clothes jogged past.  
Probably heading to club activities or ball games practice.  
Among them, they spotted male classmates also heading to support girls' practice and exchanged brief greetings.  
Looking forward to seeing Rei's reaction when meeting the left-right combo, Yuu smiled as they headed to Second Ground.

At Second Ground, they seemed to be using half the field at a time for practice.  
When Yuu's group arrived, the 13 Class 5 girls participating in soccer (including reserves) were divided into three groups discussing strategy.

"Waaah!"  
Noticing Yuu's group at the edge of the field, the Class 5 girls cheered in unison.

"Yay! Rei-kun came to support us! This gives us 100 times more energy!"  
"Hi-Hirose-kun is with our class again... Ahh, I'm so glad I'm in Class 5..."

Their excitement seemed exaggerated.  
About half the cheers were for Yuu and Rei, partly because Rei's fans were clustered here.

While Rei's appearance naturally appealed to girls in this world, Yuu's reputation for being universally friendly made him exceptionally popular not just among first-years but second and third-year girls too.  
Normally, this might invite jealousy, but most first-year boys still retained an innocent awkwardness around girls, not yet reaching the stage of feeling jealous.  
Instead, they treated Yuu like some brave hero while keeping slight distance - something Yuu found slightly frustrating.

Then Risa called out to everyone and dashed toward Yuu's group.  
With 13 girls kicking up dust as they ran full speed, everyone except Yuu looked slightly intimidated.  
But they stopped in a neat line about 3 meters before reaching the boys outside the white line.  
Risa, at the left end, shouted a command in her crisp, athletic voice (her height over 180cm and berry-short hair accentuating her sports-club vibe).

"Everyone, bow!"  
At Risa's command, they bowed perfectly in unison as if rehearsed.  
"Thank you for coming to support us, Class 1-5!"  
"Thank you very much!"

Yuu decided to step forward.  
He paused mid-step, then gestured for Rei to follow - a small gesture of consideration.

Yuu walked to about the center of the girl lineup, scanning each face.  
Early June's clear weather kept temperatures high even after school.  
They all wore sleeveless gym shirts and bloomers - an outfit Yuu personally wanted to admire forever.  
But he couldn't stare too long, so after a moment he spoke.

"I'm Hirose, leader of Group 5 supporting Class 5.  
Let's aim for victory together.  
Oh, Rei?"  
Prompted by Yuu, Rei stepped forward.  
Several girls including Risa and Miyoko immediately brightened.  
"Everyone, do your best. We're rooting for you."  
Rei offered an awkward smile and small wave.

"Guh... precious"  
"Rei-kun's cute encouragement... saving this in my brain forever"  
Strange murmurs were heard, but Yuu turned and prompted Masaya and others to offer encouragement too.

"Well, do your best"  
"Let's aim for victory since we're here!"  
"We're cheering for you"  
"G-go Class 5, fight!"

Though some voices were soft, receiving encouragement from all the boys made the lined-up girls smile happily or strike determined poses.

After initial greetings, the girls resumed practice.  
They divided their half of the field into three sections:  
Goalkeeper and left/right defenders practicing against two forwards near the goal.  
The remaining four players split into pairs for passing drills.  
Being mostly amateurs, the first session focused on ball familiarity.

Now, right before them, a forward dodged a defender and fired a strong shot toward the corner, but goalkeeper Risa fully extended her tall frame to block it.

"Yoshaaaaaa!"  
"Damn it! Thought that was in!"  
Their contrasting emotions were palpable.  
Even in practice, Risa's successful save before Rei made her strike a flashy victory pose.

"Wow, impressive"  
"Yeah, everyone's trying hard"  
Amateurs being amateurs, there were missed balls and miskicked passes, but they shouted encouragement and ran earnestly.  
Their intensity clearly surpassed regular gym class.  
This enthusiasm definitely reached the watching boys.

Even Masaya, who'd previously said "Sporty girls seem scary and I'm not good with them," watched the practice without boredom.  
With 15 minutes left, when they split for a practice match, even boys besides Yuu started offering spontaneous cheers.  
Hearing this, the girls running across the field visibly intensified their efforts.  
Except those used to sports club activities, running nonstop for 30 minutes after school should have been tiring, yet no one slacked off.  
Yuu felt relieved that the ball games tournament (still practice period) had started well as a gender exchange event.

The next day, Tuesday's afternoon slot involved supporting Class 5's volleyball players in the gymnasium.  
Checking the roster, Yuu noticed it included Hiyama Yoko and Aki Kazumi (whom he'd befriended during basketball club observation and were his closest first-year friends), plus Maegashira Yuma and Goto Mashiro (his teammates from May's Newcomer Welcome Orienteering).

The roster included club affiliations.  
Apparently, sports club members were all assigned to soccer and volleyball.  
Likely aiming for wins in these two events while assigning less athletic girls to dodgeball.

When Yuu's group entered the gym, eight girls including reserves were warming up.  
Here, they seemed to use one court at a time for practice.  
Though outdoor volleyball courts existed, Class 5 lucked out getting gym access.

"Wah! Yu... Hirose-kun!"  
Yoko spotted Yuu first.  
True to her sunny name, she beamed a radiant smile and waved while bouncing on her toes.  
Almost simultaneously, Kazumi noticed too, waving shyly - adorable.

Incidentally, during the Newcomer Welcome Orienteering when hiding from suspicious track-suit figures, Yuu had called Yoko and Kazumi by name and established sexual relationships.  
Afterward, seeing them at school with people around prevented anything beyond hand-holding or light touches.  
Still, among first-years, only Yoko and Kazumi had advanced their relationship with Yuu, which pleased them.

"Yo"  
Yuu smiled back and waved.  
Soon Kazumi, Yuma, and Mashiro noticed and gathered around.  
Having bonded during orienteering, they stood closer to Yuu at the front.

"Yesterday we watched the soccer girls - they were really fired up.  
How about volleyball?"  
At Yuu's question, they exchanged glances.  
Yoko spoke first.

"Well, Kazumi and Mao-chan have middle school experience. We're getting advice from active players Risa and Mii-chan too."  
"Oh, really?"  
"B-but I was mostly a reserve..."  
When Yuu looked at Kazumi, she waved her hand modestly.  
Wondering who "Mao-chan" was, Yuu checked the roster, but prompted by Yoko, a tall girl stepped forward.

"Ah, Nakai-san?"  
"Yeah. I only played one official match in third year."  
Yuu recalled her as the tall, short-haired girl seated in front of them on the orienteering bus.  
The roster listed Nakai Mao, baseball club.  
180cm tall but with a small, cute face and seemingly perfect eight-head proportion figure - though the chest bulge at Yuu's eye level was modest.

"So as the experienced one, you'll lead everyone? Do your best!"  
Yuu stepped forward and took Mao's hand.  
"Fwah!? Thank you. W-wow... I'll super do my best!"  
Mao's instantly flushed face was endearing, making Yuu smile too.

"Ahh! Give me energy too!"  
"M-me too..."  
"Me too!"  
"Ah, wait a sec!"  
Following Mao, Yoko, Kazumi and others pressed forward.  
Yuu held them back with both hands, then called to the boys behind him too.

"Since we're here, let's all high-touch for motivation!"  
"Huh?"  
"Hmm?"  
Boys and girls formed separate lines, high-touching while passing each other.  
Each got a personal word of encouragement.  
Yuu led from the front, so the boys followed suit despite embarrassment.  
After finishing, all eight girls were visibly hyped beyond measure.

Another group of boys watched practice on the opposite court but stood discreetly at the edge without interfering.  
Naturally, hearing the cheers, girls about to start practice there watched enviously.

Watching practice across the net with four players per side.  
First serves and receives.  
They seemed to have predetermined drills, with experienced Mao leading.  
Next came setting and spiking drills with receivers.

"Besides those two, they're all beginners right? They're doing pretty well?"  
"They must have gym class experience... good movement and motivation."  
"Yeah. Like yesterday's soccer, seeing them try so hard makes you want to cheer."  
Beside him, Rei and Masaya shared impressions while watching the girls practice seriously.  
As for Yuu, he was staring so intently at the practicing girls that others hesitated to interrupt.  
But his inner thoughts ran completely opposite to their assumptions.

*(Bloomers really are the best! Since they show butt shapes almost like panties, they're incomparably sexier than half-pants.  
Wow, never thought I'd see bloomer outfits again after 25 years.  
Truly the epitome of high school girls - even their backs are perfect! Such a great view!  
Especially Yoko and Kazumi with their long legs and remarkable figures.  
But Mashiro's wide, childbearing hips are irresistible too, and petite Yuma isn't bad either.  
No, Nakai-san and others over there are also quite...)*  
He felt luckier watching in the gym than yesterday's field since he could see closer.  
Barely keeping a straight face, he maintained a serious expression while observing each movement.  
With 16 girls moving indoors, he imagined he could smell their characteristically sweet sweat.

His side wore white sleeveless gym shirts with crimson bloomers, the opposite side dark green bloomers - probably second-years.  
All generously displayed healthy thighs.  
The gym shirts weren't tucked in, just covering the bloomers' waistbands.  
So when they jumped, their stomachs flashed occasionally - also wonderful.  
Though curious about the second-years, Yuu focused on the four bottoms before him since he was supporting Class 5.  
Even in co-ed schools, gym classes were completely separate, so opportunities to openly admire active bloomer-clad figures were rare.  
He intended to burn this sight into his memory.

About 30 minutes had passed.  
On the adjacent court, boys had left early, and girls' movements visibly slowed.  
But on this side, with Yuu's group watching and occasionally cheering, motivation remained high.  
Eventually, practice shifted to 4v4 matches.

"Here!"  
"Nice serve!"  
"Got it!"  
"Leave it to me!"  
Mao jumped for a set, arched her body like a bow, and swung her arm down for a perfect spike.  
Back-row player Mashiro crouched to receive but couldn't react fully, deflecting the ball backward.  
It bounced over the white line near Yuu, so he picked it up.

"Ahh, sorry!"  
Mashiro ran over, her large chest bouncing.  
Sweat beaded on her forehead and cheeks flushed - whether from exertion or meeting Yuu's eyes.  
Yuu stepped to the white line and handed her the ball, lightly patting her shoulder.  
"Do your best in the real match too!"  
"Hauu! Aah, thank... you..."  
"You're welcome"  
Nodding happily, Mashiro returned shouting "Alright! Let's keep spiking!"  
"T-this time to me!" Nearby Yuma competed for attention.  
"Tch, damn! Even when we score, the glory goes to that side..."  
Mao and her four opponents looked frustrated despite their successful spike.  


### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to preserve cultural specificity of Japanese gym attire
- Transliterated sound effects (e.g., "よっしゃあああぁぁぁぁ" → "Yoshaaaaaa!")
- Preserved Japanese honorifics in dialogue (e.g., "Rei-kun" for 東野君)
- Maintained original name order for Japanese characters (e.g., "Higashino Rei")
- Rendered internal monologues in italics per style guide
- Translated sports terms precisely (e.g., "フォーワード" → "forwards")
- Kept specialized terms like "Newcomer Welcome Orienteering" consistent with Fixed Reference
- Used explicit anatomical descriptions during Yuu's internal monologue per translation style rules
- Formatted dialogue with new paragraphs for each speaker, maintaining attributions