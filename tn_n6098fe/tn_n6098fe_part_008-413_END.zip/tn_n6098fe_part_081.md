## 74. Ball Games Tournament ② ~Boy's Season~

### Author's Preface

One more practice chapter, then the actual tournament begins next time.

---

After school on Wednesday, Yuu and the five other boys headed toward the central courtyard where Class 1-5's dodgeball participants were supposed to gather.

Unlike soccer or volleyball, dodgeball could be played in any reasonably open space. The central area of the courtyard sandwiched between the first school building and administrative offices had lawn grass laid out, with colorful flower planters and benches placed around, normally serving as a relaxation spot for students. But this week only, it had been cleared for dodgeball practice.

As they approached the area roped off into two adjacent squares, they saw a large group of girls in short-sleeved gym uniforms and crimson bloomers gathered together. Excluding the soccer and volleyball participants, there were fifteen girls. Seeing that many girls clustered together in gym uniforms was quite a spectacle. Visually, shorter girls and slightly chubby girls stood out. Though similarly petite and plump, Maegashira Yuma and Goto Mashiro had been assigned to volleyball due to their athleticism, so this group likely consisted of girls who were genuinely poor at sports.

"Ah! The boys came for us!"  
"Aww, Hirose-kun! So handsome..."  
"Higashino-kun is here too. How adorable..."

Though quieter than the athletic girls they'd seen before, the way they squealed excitedly upon seeing Yuu and the others was quintessentially girlish. They hadn't started yet, and from the cluster staring at the boys, one girl stepped forward.

She was slightly shorter than Yuu with a slender build. Thin-framed silver glasses suited her narrow face perfectly. Her long black hair was half-up in a braid, giving her a refined young lady vibe. Yuu recognized her as Aramaki Yoshie, who served as Class 1-5's representative. She must be leading the dodgeball group.

"U-um, this time, uh, you went out of your way, ah... to come for us... aah!"  
She seemed to stumble over her words from nervousness.  
"Yoshie, you can do it!"  
"U-un."

Standing before Yuu who had stepped forward, Yoshie blushed slightly but managed a proper greeting this time.  
"We're the boys' support group 5. Nice to meet you."  
"Ah, ye...s?"  
When Yuu extended his right hand, Yoshie froze momentarily. As Yuu waited with a smile, she hesitantly reached out and touched his hand. Up close, her eyes behind the glasses were slightly almond-shaped with well-defined features - she could be called beautiful. But perhaps she had no immunity to boys? Her extreme nervousness was obvious. Yuu firmly grasped her slender, soft hand, enjoying its delicate texture.

"Yoshie-chan won't let go of Hirose-kun's hand~"  
"No, I think she's frozen in shock..."  
"Huh?!"

Hearing her classmates whispering behind her, Yoshie hurriedly pulled her hand back, her face bright red as she fidgeted. Her innocent, adorable demeanor made Yuu smile. But something caught his attention.

"By the way, what kind of practice are we doing for dodgeball?"  
Yuu himself hadn't played since elementary school and couldn't recall middle school rules. The rules weren't complicated: two teams divided into inner and outer fields throwing balls at each other - if hit, you're out. The team with players remaining in the inner field last, or with more inner field players when time runs out, wins.

"Um, well, first we'll split into teams and try playing," Yoshie answered haltingly when spoken to.  
"Is that so?"  
Another girl stepped beside Yoshie to answer, seeming rather casual.  
"Probably every class has girls who aren't good at sports."  
"Having fun is what matters, right?"  
"Maybe we can win if we're lucky?"  
"Haha, I see. So it's about enjoying ourselves?"  
"Yeah. But now that you boys came, we'll do our best!"

Unlike the soccer and volleyball practices from previous days, they didn't immediately start drills. Before long, fresh conversations with the boys began. Behind Yuu, a girl unusually called out to Masaya, so Yuu eavesdropped.

"Yamada-kun, thanks for coming."  
"I-it's nothing... just decided."  
"Ufufu. I'm bad at sports, but I'll try hard on the day."  
"Ah, you don't have to push yourself."  
"Huh?"  
"L-look, if you force yourself and hurt your hand, it'd be trouble."  
"Ah... ahaha. Thanks for worrying."  
"T-that's not what I..."

*This is like a teen romance comedy,* Yuu thought, turning to look at Masaya. Masaya had been talking one-on-one with a petite, quiet-looking girl with long black hair tied back. Smiling, Yuu nudged Masaya's shoulder.

"Close with her?"  
"N-no! Same band club..."  
"Come on, I get it. Let's cheer her on properly."  
"Ah, come on..."  
Flustered, Masaya adjusted his glasses and looked away. Yuu was pleased to have found rare teasing material about Masaya's romantic life.

After about ten minutes of conversation, Yoshie finally called them to order, and they split into two teams to begin practice. That said, the lively squealing didn't change. Though the girls seemed serious, their movements appeared sluggish compared to the soccer and volleyball groups - likely because many were poor at sports. Some seemed overly conscious of the boys watching, missing catches or getting hit in amusing ways.

"Feels heartwarming, doesn't it?"  
The boys all sat relaxing on the grass. Today's weather was cloudy with wind, feeling slightly cool when stationary.

Yuu suddenly murmured.  
"Somehow, I feel like moving my body too. Mind if I join?"  
"Huh? That would..."  
"Y-you serious?"  
Rei and Masaya nearby were speechless. But Yuu was serious.  
"Come on. The girls might get more fired up with boys joining."  
Yuu stood up, stretching his ankles while doing so. Then he looked around at all the boys.  
"What do you say? Want to try playing together?"  
"Uuum..."

No one could answer the sudden proposal. Though the boys moved during PE, it was quite relaxed. They weren't made to run long distances or play serious soccer/basketball. In Yuu's world, male PE teachers were typically strict tough guys, but this school's few male teachers like homeroom and PE teachers were all gentle. So while joining the serious soccer/volleyball practices might have been tough, the dodgeball before them seemed easier to enter.

As the boys hesitated and exchanged glances, one finally stood up. Hosho Haruto, whose name came after Yuu's alphabetically, had been in the same group since April and talked relatively often with Yuu.

"Alright, I'll do it!"  
"Great! Let's enjoy it."  
"Yeah."

Haruto was slightly taller and slimmer than Yuu, looking like a refreshingly handsome guy suited for soccer or tennis. Come to think of it, he seemed to enjoy moving his body, often enthusiastic during PE. Naturally popular with girls, he hadn't been very proactive until now. Maybe the ball games practice observations this week were changing him.

By the time Yuu took Haruto to ask Yoshie (waiting outside the court) if they could join, about twenty minutes had passed since practice started. Though some girls looked tired, they cheered "Waaah!" upon hearing Yuu and Haruto wanted to join - quite opportunistic.

During a five-minute break, Yoshie made lots from her notebook to divide teams. Officially, inner field had ten players with the rest as outfielders, but now they started with five inner and two outer fielders per team (one extra as referee). Yuu and Haruto were split to join the inner fields. Girls who drew lots for inner field were ecstatic - after all, opportunities to play ball games with boys had been rare since elementary school, and they got to play with Yuu and Haruto, two of the most handsome first-years. Just having boys within reach was a rare opportunity for first-years.

"It's a match, Hirose! Loser buys juice."  
"Hohou, gladly. I accept."  
Though surrounded by girls, the setup felt youthfully romantic, making Yuu secretly happy. Unnoticed by them, girls remaining in classrooms had crowded onto the first building's balcony upon hearing the commotion.

Unfortunately made referee, Yoshie stood at the center line with the ball as the game began. Yuu and Haruto jumped for the high-tossed ball. Though Haruto was taller, Yuu compensated with jump height, both touching it simultaneously. The ball landed slightly behind Yuu to start.

The ball flew between both teams' inner and outer fields. Early on, one girl from each team got hit and moved to outfield, keeping it 5 vs 5.

After several exchanges, Yuu caught a ball from the outfield and immediately threw it at the nearest opposing girl while turning. They used volleyballs - not too painful even when hit, but Yuu didn't throw full force. Still, he aimed low to make it hard to catch. Realizing she was targeted, she tried backing away but turned her back, so Yuu's throw hit her butt.

"Kyahn!"  
"Got her!"  
"Aww, Hirose-kun hit me..."  
Strangely, she looked slightly happy despite being hit.

Exchanges continued as players left the inner field one by one, becoming 3 vs 3 including Yuu and Haruto. A high ball from the opposing outfield went to Haruto - likely aiming to pass to him.

"Fufufu. Time to finish this!"  
Striking a pose with the ball, Haruto pointed dramatically at Yuu.  
"O-oh."  
The two opposing girls sent sparkling gazes at Haruto while Yuu smiled wryly.

"Tee!"  
"Got it!"  
Haruto threw hard, but Yuu caught it easily since it came straight. Yuu threw back at Haruto.

Several exchanges occurred between Yuu and Haruto. Girls from both inner and outer fields watched the boys' showdown breathlessly. Yuu immediately threw the caught ball at Haruto's feet. Haruto hesitated whether to catch or dodge the bouncing ball, letting it hit his leg.

"Damn!"  
"Aah! Revenge for Haruto-kun!"  
The ball bounced sideways right into a nearby girl's arms, who immediately threw it at Yuu.  
"Huh?"  
It was a weak arcing throw, but hit Yuu around the knees while he was off guard. Beep beep.  
"Haruto-kun and Hirose-kun, please go to outfield!"  
At referee Yoshie's call, both slumped and went out.

"I hit him first, so I win."  
"But our team had players left longer."  
"Grr..."

They argued but realized they hadn't set victory conditions. Masaya mediated, suggesting they buy each other juice to settle it.

With the unexpected boys' match over and time running short, the dodgeball group disbanded. When Yuu started removing his sweaty shirt to change into a T-shirt, nearby boys frantically stopped him - the spectator crowd had grown larger than expected.

After promising Class Rep Yoshie and the girls support during the real match, Yuu and the others took their usual school bus home from the second building.

"Whew~. Playing with girls like that was fun!"  
"Huh... Only you would think that, Yuu-kun..."  
"Eh? But Haruto enjoyed it too this time."  
"Well, true."

On the bus, Yuu and Rei sat together as usual. Yuu lightly patted Rei's shoulder. Rei's slender, sloping shoulders felt girlish.

"Since we came to a co-ed school, you should interact with girls more actively too."  
"Uuun..."

Though girls squealed when Rei walked with Yuu, he still seemed conflicted - the typical male reaction in this world.

While discussing the ball games, the bus entered the city. At a red light, Yuu saw many women gathered in a vacant lot.

"What's that?"  
"Hm? What's wrong?"

When Yuu pointed outside, Rei leaned over, naturally closing their distance. With his side hair long enough to cover his ears, Rei could easily be mistaken for a girl at a glance, but Yuu didn't feel attracted.

"What what... 'Dan-kyo'? Is that how you read it?"

Three middle-aged women stood on a box atop a white van like those used in election campaigns, the center one shouting through a megaphone. Not just the van, but banners around said "Male Inclusion Movement Promotion Union," "Aiming for Women's Rights Advancement," and "Take Back Our Right to Choose Men."

*'We must... for all women... break the current situation... cannot allow government tyranny... liberate all men...'*

About a hundred people gathered before the van. Most pedestrians ignored them, but some joined the crowd or listened from a distance.

"I think I saw the Male Inclusion Movement on TV before. Know about it, Rei?"  
"Uun... I think I saw it on news too... not sure."

As they talked, women in matching red happi coats near the van pointed at them. Three or four started approaching the stopped bus while shouting. Though the bus had the school name, tinted windows should hide the boys. Yet they seemed certain boys were inside. Only Yuu and Rei noticed among students, but the security guard aboard tensed.

Fortunately, the light turned green before the women reached the bus, letting it depart without incident. Yuu couldn't tell what they wanted. The encounter was brief and noisy. From TV, he recalled it being a movement for women's rights. *If only I had a smartphone to search...* he thought of his previous life's convenience, but it couldn't be helped.

Honestly, when Yuu was last in high school, he rarely cared about world events unless major. Though slightly curious now, politics felt irrelevant to a high schooler. Yuu never imagined this "Male Inclusion Movement" would later involve him.

---

### Author's Afterword

For ball games besides soccer/volleyball, I considered softball or basketball. I chose dodgeball thinking boys could easily join. Note: Dodgeball has many local rules, but I based this on rules from my elementary school days.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to maintain cultural specificity of Japanese gym attire
- Preserved Japanese honorifics (-kun, -chan) per style guidelines
- Translated "男共運動推進連合" as "Male Inclusion Movement Promotion Union" using fixed term reference
- Rendered internal monologue in italics: *(This is like a teen romance comedy)*
- Transliterated sound effects: "きゃん!" → "Kyahn!", "ピピッ" → "Beep beep"
- Maintained Japanese name order: "Aramaki Yoshie" not "Yoshie Aramaki"
- Translated "体操服" as "gym uniforms" for accuracy