## 75. Ball Games Tournament ③ ~Kiss Me Here~

Friday, June 8, just before the rainy season began.  
The day of Sairei Academy's June ball games tournament had arrived.  
Though cloudy, patches of blue sky peeked through, and according to the weather forecast, the clear weather would hold all day.  
A breeze kept the morning cool, but with temperatures expected to reach 25°C during the day, players running around on the grounds and in the gymnasium would likely feel the heat.  

Unlike the Newcomer Welcome Orienteering, there was no opening ceremony. After a brief opening announcement by the executive committee chair over the PA system, participants moved to their respective event locations according to instructions.  
Tournament brackets and match locations had been posted in advance: soccer by the First Ground management building, volleyball in front of the gymnasium, and dodgeball at the courtyard entrance.  

Matches followed a grade-level tournament format.  
With six classes per grade, two classes received byes and needed only one win to reach the finals.  
Checking the pre-distributed program, Yuu saw that Class 1-5's volleyball team had luckily secured a bye.  

*"First matches for all events begin at 9:15 AM.  
Players and supporting boys should proceed to match venues as directed.  
First Ground: 3rd-year Soccer Match 1, Class 1 vs Class 3.  
Second Ground: 1st-year Soccer Match 1, Class 4 vs Class 5.  
…………"*  

"Alright, soccer first! Let's go?"  
"Okay!"  
"Yeah!"  

At the call of Yuu, their group leader, Rei, Masaya, and other Group 5 members stood up.  
Though not playing, the supporting boys had changed into gym clothes too—white short-sleeved shirts with crimson accents on the sleeves, paired with crimson half-pants.  
Unlike the girls' bloomers, these covered most of their thighs, though girls apparently found glimpses of boys' kneecaps and upper thighs irresistible.  
Because of this, some boys endured the heat wearing track pants over their shorts.  

When Yuu's group reached Second Ground, Class 4 and Class 5 players were warming up for the first match.  
Classes wore colored bibs over their gym clothes: pink for Class 5, green for Class 4.  
Tall Risa and Miyoko were immediately recognizable. Risa, as goalkeeper, wore a black long-sleeved shirt instead of gym clothes and appeared to be putting on gloves.  
When Yuu and the other supporting boys waved and called out, the players instantly smiled and waved back.  

Soccer matches consisted of two 10-minute halves totaling 20 minutes. If tied, penalty kicks would decide the winner.  
Additionally, barring injuries or illness, the two substitute players were required to enter during the second half.  
Right now, the eleven starting players gathered at the center line. The match seemed about to begin.  
After determining first possession by rock-paper-scissors, they dispersed to their positions.  

"On three!"  
""""Class 5, fight!""""  

At Yuu's prearranged cue, their synchronized cheer echoed across the field.  
The Class 5 players visibly rallied at the sound. Just as Class 4's supporting boys began shouting back, the starting whistle blew.  

"Over here! I'm open!"  
"Pass! Pass!"  
"Nice cut!"  

Across the wide field, girls in pink and green bibs ran shouting after the black-and-white soccer ball.  
Perhaps because they'd practiced in PE class, they moved with positional awareness rather than clustering like elementary schoolers.  
Despite all being amateurs, they looked surprisingly competent.  

Whether spurred by Yuu's cheering or not, Class 5 seemed dominant from the start.  
But they couldn't convert chances into goals, and frustrating minutes passed.  
Class 4 occasionally cleared the ball long but couldn't connect near the goal, ending the first half scoreless.  

Early in the second half, Class 5 attacked effectively down the wings.  
From a corner kick set play, the ball reached a Class 5 player who tapped it in, sending it rolling into the net.  
Class 5 had finally taken the lead.  

"We did it!"  
"Nice! Keep it up!"  

Though not a spectacular play, a goal was a goal.  
Not just the players but Yuu and the supporters cheered ecstatically.  
Class 4 desperately tried to equalize but was thwarted by Miyoko's defense and Risa's goalkeeping, failing to capitalize on few chances. The match ended 1-0 for Class 5.  

"Glad you won!"  
"Everyone fought hard!"  
"Ah, winning really makes cheering worthwhile!"  

After expressing their joy, the boys applauded the players to commend their effort.  

"Okay, next is the dodgeball match."  
"Hope they win this time too."  
"Let's cheer our hearts out!"  

After checking the program schedule, Yuu's group headed to the tennis courts where dodgeball matches were held.  

The result was a close match, but unfortunately Class 5 lost.  

"Ugh... after you... cheered for us... sniff... so-sorry..."  
"H-hey, don't cry, Aramaki-san. You fought hard."  
"Waaah... Hirose-kun..."  

Yuu comforted Yoshie as she began crying. Overwhelmed, she didn't notice Yuu holding her shoulders.  
But seeing this, several girls pretended to cry and swarmed Yuu seeking comfort, quickly surrounding him.  

Meanwhile, girls also gathered around Haruto who'd played with them during practice.  
"Losing in the first round drags down our other events..."  
"Ah, it's class rankings, right?"  
"Yes! If we win overall, we get a co-ed after-party!"  
"P-party?"  

The tournament awarded points based on event rankings: 8 for 1st, 6 for 2nd... with first-round exits getting only 1 point.  
After final rankings were announced, top three classes per grade would be recognized as before.  
Some classes then went into town for celebrations while others disbanded immediately.  
Since this was the first co-ed event, the student council budgeted for the winning class to hold a small party in their classroom with supporting boys.  
Other classes could take group photos with boys by event team.  

As a student council member, Yuu knew about the party—it was also in the program.  
Naturally, the girls were enthusiastically anticipating it.  

"We'll cheer for volleyball and soccer next."  
"Um... can we come cheer too?"  
"Ah, sure, okay."  
""""Yay!""""  

But checking the program, Yuu noticed volleyball and soccer quarterfinals overlapped.  
So the boys split—Yuu and Masaya, Rei and Haruto—with about half the dodgeball girls joining each group to support different matches.  

"Here!"  
"Nice set!"  
"Take that!"  

Kazumi's perfect set found Mao, who jumped and arched her body for a textbook spike.  
The opposing team tried blocking with two players, but the ball slipped through and landed with a satisfying smack in an empty area of the court.  

Pii!  
The scoreboard flipped to 15-7, doubling their lead.  

In the 1st-year volleyball quarterfinal at the gymnasium, Class 5 vs Class 6 was becoming one-sided.  
Mao and Kazumi—who'd played volleyball in middle school—showed brilliant coordination, while athletic Yoko scored repeatedly.  
Shorter Yuma and Mashiro created highlights with their receives.  
Class 5 displayed remarkable teamwork for an impromptu team.  

"This looks... promising."  
"Yeah, they've got this!"  
"Everyone, go for it!"  

Amid renewed cheers including girls who'd joined, Class 5 maintained their lead, winning 25-13 to advance to the finals.  

However, Rei's group returned from soccer cheering and reported Class 5 had tied 0-0 against Class 2 but lost in penalty kicks. Risa was apparently so distraught after conceding consecutive goals that Rei voluntarily comforted her.  

With half the quarterfinals completed, the morning session ended. After lunch, remaining quarterfinals, third-place matches, and finals would follow.  
Before returning to class, Yuu stopped by the restrooms near the gymnasium.  

Even alone, boys faced no danger within school grounds.  
Though boys usually moved in pairs, Yuu went to the restroom alone without concern.  
As he exited the men's room, he saw three girls leaving the women's. Recognizing the last one by her grade color as a third-year, Yuu called out without thinking.  

"Sayaka-senpai!"  
"Oh, if it isn't Yuu-kun!"  

Despite student council support duties keeping them busy, Yuu hadn't had time for proper one-on-one talks with Sayaka.  
Running into her by chance made Yuu smile naturally.  
"Got a minute? Is now okay?"  
"Ah... yeah. Sure."  
Sayaka seemed to feel the same. When she asked her friends to go ahead, they glanced between Yuu and Sayaka, smirking as they left.  
Perhaps third-year girls widely knew about Yuu's closeness with student council members.  

Her usually loose, long glossy black hair was in a ponytail today.  
Seeing her nape—normally hidden—exposed looked strangely alluring.  
Her blue-trimmed short-sleeved gym shirt and navy bloomers showcased her stunning proportions and long, beautiful legs without reservation.  
Her thighs—neither too thick nor thin—were toned and mesmerizingly beautiful.  
Even Yuu, familiar with her naked body, found his eyes drawn. He'd noticed mud stains on her back and butt earlier.  

"Were you playing on the outdoor courts?"  
"Ah, we lost in the quarterfinals unfortunately."  
"Th-that's too bad... and I missed seeing senpai play!  
Ahh, it's your last year too, what a shame..."  
"Fufu. I scored several spikes though—we fought back hard till the end?"  

Sayaka's cute gesture of raising a fist made Yuu smile. Given her athleticism and intelligence, he could imagine her excelling.  
Feeling slight jealousy that third-year supporting boys witnessed this, Yuu impulsively took Sayaka's hand.  
Faced with her puzzled look and unable to back down, Yuu glanced around and spotted a suitable place.  

"Senpai, over here."  
"Huh?"  

Just meters from the restroom entrance hallway, Yuu led her behind a building and trees where they wouldn't be seen.  
"Fufu. Bringing me here, Yuu-kun—what are you planning?"  
Sayaka tilted her head with a suggestive smile, her ponytail swaying.  
"This."  
"Ah!"  

Turning to face Sayaka slightly behind him, Yuu wrapped both arms around her.  
The moment their bodies touched, he felt her softness and firm physique.  
Simultaneously, her hair's sweet scent mixed with light sweat from her fair skin.  

"Hah! Yu-Yuu-kun... I-I'm happy but... I'm sweaty from the match..."  
"We both are... And I love any scent of yours, Sayaka-senpai..."  
"Ahh... You really are unusual, Yuu-kun... Nn..."  

Yuu played with her ponytail with his right hand while his left slid down her back to grip her slender waist.  
Then he pressed his lips to her neck and licked.  
"Ahh... st-stop that..."  
As Sayaka tightened her arms around his back, her breasts pressed harder against him, making Yuu almost lose control.  
But going further here was impossible.  

Their cheeks slightly flushed, they gazed at each other before their lips met in mutual attraction.  
Chu, chu, chu—after several light kisses, they embraced tightly.  
Cheek to cheek, they stayed silent awhile before Sayaka spoke softly.  

"It's our first time having boys support us as cheerleaders, but from what I've seen, it's working well.  
When I first heard your proposal, I wondered how it'd go... but I'm glad we tried it. Thank you."  
"Nah, that's all thanks to you and the student council and executive committee seniors working hard.  
Even boys in my group got more into the matches than expected, cheering loudly.  
I just provided the opportunity."  
"Fufu. You're as modest as ever, Yuu-kun."  

Sayaka smiled while studying Yuu's face.  
Closing her eyes, she pressed her lips to his again.  
"Senpai..."  
Growing affection made Yuu part her lips with his tongue.  
Simultaneously, he caressed her back and buttocks.  
"Nchu... hah... nn... Yu... Yuu-kun... amu... relchu... nn... nfa"  
"Sayaka... senpai... nn..."  

After enjoying the deep kiss, they slowly separated, a string of saliva connecting their tongues.  
"Here... we can't... go further... no, I want more but..."  
Seeing Sayaka's moist eyes stirred something in Yuu, but he barely restrained himself considering time and place.  
As Yuu moved to pull away using rational control, Sayaka—still blushing—whispered almost inaudibly.  
"J-just one last kiss... please?"  
"Of course, gladly."  

Still gazing at each other, their lips met as they closed their eyes, savoring the contact.  
After several seconds, Yuu pulled back, resisting rising passion, and gently touched his forehead to her neatly trimmed bangs.  

"Then... we'll continue next time."  
"Okay..."  

After one last tight embrace and cheek press, they separated.  
"Are the first-year classes you're supporting still in contention?"  
"Yes, the volleyball team."  
"Then do your best cheering for them this afternoon."  
"Right... I will."  

Though delighted by their chance meeting, Yuu knew he must focus on supporting the girls today as Sayaka said.  
Regretfully nodding, Yuu released her.  
The lunch break chime had sounded earlier.  
Waving, Yuu and Sayaka returned to their respective classrooms.  

---

### Author's Afterword

The ball games arc focuses on first-year girls, but I suddenly wanted to write Sayaka in gym clothes and bloomers.  
There's something thrilling about seeing a girl who usually wears her hair long suddenly in a ponytail, right?  
I wish I could've included a scene of her tying it up herself though.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to maintain consistency with previous terminology
- Preserved Japanese honorifics (-senpai, -kun) per style guidelines
- Transliterated sound effects: "ピーっ" → "Pii!" (whistle), "ちゅっ" → "Chu" (kissing sounds)
- Maintained original name order (e.g., "Aramaki Yoshie" not "Yoshie Aramaki")
- Translated "お団子状態" as "clustering like elementary schoolers" to convey chaotic gameplay imagery
- Rendered internal monologues in italics per formatting rules
- Kept specialized terms like "Newcomer Welcome Orienteering" consistent with Fixed Reference