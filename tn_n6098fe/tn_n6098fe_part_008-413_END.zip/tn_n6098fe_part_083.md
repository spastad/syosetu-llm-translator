## 76. Ball Games Tournament ④ ~The Decisive Battle is on Friday~

"How about we form a huddle together to psych ourselves up?"  
"A huddle?"

Just before the first-year volleyball finals began, Yuu said this to Yoko and the other players in a corner of the gymnasium. Forming huddles before matches or during crucial moments to boost morale was commonplace in this world too. Yuu had proposed doing it together with both boys and girls before the match.

"Th-that's..."  
"Huh..."  
"Seriously!?"  
"I-is it okay? Is it really okay?"

The reactions from both genders were contrasting. Naturally, it was the girls showing expectant expressions.

Yuu then addressed everyone present, including the boys, in a persuasive tone. "We've come this far. We all want Class 5 to win, right?" When Yuu looked around starting from the boys, they nodded in agreement.

"But our finals opponent, Class 1, seems pretty strong, right? It won't be like the second round. Still, we genuinely want to cheer for Class 5. First, we supporters and you players need to unite as one."

Class 1, like Class 5, had advanced from the seeded bracket and overwhelmed their opponent 25-11 in the first two rounds. According to girls who watched, their crisp movements and lack of amateurish mistakes suggested they'd gathered athletes. Like Class 5, they were led by girls with middle school volleyball experience. It was truly a fitting finals matchup.

Many classmates from Classes 1 and 5 who'd been eliminated in other events had gathered around, creating a natural excitement. "Ah, you're right. Since we're cheering, I really want them to win," said Masaya. "Y-yeah. If we can help even a little," added Rei. Perhaps swept up by the gym's heated atmosphere, the other boys nodded vigorously.

"Alright! Then everyone form a circle!" The boys scattered and inserted themselves between the girls, forming a huddle with genders alternating. Everyone except Yuu showed embarrassment or shyness at shoulder-to-shoulder contact with the opposite sex. Yuu made eye contact with Yoko on his right and signaled.

"Class 5 - fight!"  
""""""Ooh!""""""

At Yuu and Yoko's call, everyone shouted loudly to psych themselves up.

"Alright, we'll definitely win!"  
"Thanks, I feel energized now!"  
"Now that we're here, we're taking the championship!"  
"Everyone, do your best!"

The girl players headed to the court, seen off by Yuu and the boys. Then Yoko came close to Yuu and whispered.

"Yuu-kun, thank you so much."  
"Save your thanks for after we win."  
"Ah-ha, you're right. Then if we win, maybe you could give me some reward..." Yoko fidgeted slightly while glancing at Yuu.

With the match about to start, Yuu responded immediately. "Sure. I'll think of something. For everyone, including substitutes." "Whoa! Yes! I'll look forward to it!" Hearing this, Yoko beamed radiantly. "I'm counting on your performance, Yoko." Yuu lightly patted her butt, and Yoko bounded off to her teammates with a springy step, saying "Yeah!"

When Yuu announced the "reward" would be for everyone, the players on court immediately went "Waaah!" with excitement, their fighting spirit visibly overflowing.

Whether due to the huddle or Yuu's "reward" effect, Class 5 scored three consecutive points right after the match began. But Class 1 was formidable too. With taller players than Class 5, they steadily closed the gap. The scoreboard showed a back-and-forth match with no lead exceeding two points, but after consecutive costly mistakes, Class 5 fell behind 12-13. Fortunately, a substitution timeout at that moment allowed them to reset.

"It's still early!"  
"Let's take it point by point!"  
"Watch carefully, stay calm!"

The whistle blew for the second half. Cheered on by the boys and players who'd been subbed out, the team returned to court.

The second half saw neither Class 5 nor Class 1 yielding, with seesawing exchanges continuing. Mao showed brilliant spikes, Kazumi blocked shots, Yoko pushed through with feints. Yuma nimbly chased balls with her small frame, and Mashiro (who subbed in later) set up chances. Truly, the six players showed unified teamwork.

As the afternoon grew humid, sweat glistened on the brows of the girls in gym bloomers darting after the white ball flying over the net. Yuu couldn't help but follow the movements of the girls' chests, butts, and thighs - both Class 5's players and their opponents. Perfectly natural male psychology. Though his gaze held some lust, Yuu undoubtedly felt genuine affection for Class 5 as his own class. As the match approached its climax, their cheers grew louder.

At 20-20, Class 5 faced crisis when Class 1 rotated their tallest players to the front. "Hyaaa!" An unladylike grunt accompanied a spike that slipped between two blockers, but Yuma made a diving save and Mashiro kept it alive. However, it became an easy chance for Class 1 who scored a powerful spike to take the lead.

Unable to stay still, Yuu cupped his hands like a megaphone and shouted: "Yumaaa, nice receive! Mashiro, great setup! Keep it up! Mao, smash it down! Kazumi, block hard! Don't hold back, jump! Yoko, you've still got more in you! Show us something cool! ........."

Yuu calling each by name released the pressure that had been freezing the players. They smiled at each other and gave Yuu thumbs-up. Though many students in the gym noticed Yuu, he waved back without concern, sending encouragement.

After trading two points each, Mao and Kazumi scored consecutively to take a 24-23 lead. One more point would seal victory. But Class 1 showed their pride, tying it up and forcing deuce.

"One more point! Go!"  
"Please, win!"  
"Class 5, championship is close! Do it!"  
"Class 1, don't lose!"

Not just the cheering boys and classmates, but even students from other classes joined the roaring cheers as the heated battle continued. Whenever Class 5 took a one-point lead, Class 1 equalized. At 28-27, Class 5 seemed dominant but couldn't land the final blow.

Fatigue was likely building among the players, but everyone remained focused on chasing the ball. Yuu and the boys kept cheering loudly, unconcerned about their voices growing hoarse.

A ball heading toward the boundary line - unclear whether it would land in or out - was desperately chased down by Yuma. Mashiro set it forward. A spike seemed impossible, but Yoko cleverly pushed it just inside the sideline. A Class 1 player hesitated momentarily before managing to save it, but the poorly controlled low ball returned to Class 5. Seizing the chance, Kazumi set a low toss, and Mao instantly spiked in perfect sync. Class 1's block arrived too late. The ball landed on the court with a crisp sound and bounced away.

Though Class 5 won volleyball and secured third place in soccer, their first-round dodgeball loss proved costly - they finished second overall in the grade. After taking commemorative photos with each team, the cheering boys disbanded.

Telling Rei he had student council work, Yuu slipped away alone to meet Yoko and the others at their arranged spot: the gym's second floor. While first-floor cleanup was underway by PE students after the volleyball matches, the second floor - usually used for badminton, table tennis, and gymnastics - was eerily quiet. When Yuu opened the door, the eight volleyball participants were already waiting in the back. Both Yuu and the girls were still in gym clothes.

"Sorry to keep you waiting."  
"No, not at all. We weren't waiting long. Ahahaha." Yoko's words sounded like a classic date line, making Yuu smile naturally.  
"H-Hirose-kun, you really came..." Kazumi gazed at Yuu with moist eyes.  
Yuu looked around at all eight present. "Of course. I promised. So once again, congratulations on winning. You all fought incredibly well. I was moved watching you."  
"But... it's because you boys cheered so hard for us."  
"Really, really."  
"Yeah. That pre-game huddle? And your loud cheers during the match really pumped us up."  
"And... th-the reward..."

Though slightly embarrassed, their expectant gazes were clear. "So... gathering secretly here means... wh-what kind of reward is it?" Yoko's question was natural. Given Yuu's openness to physical contact with girls, they had expectations. During the Newcomer Welcome Orienteering, head pats were rewards for correct answers at checkpoints. Gathering secretly here suggested something private? Like individual hugs? Or maybe cheek kisses?! While Yoko and Kazumi (with prior kissing/petting experience) and the others had different expectations, their imaginations ran wild.

"Okay then..." After the match, Yuu had pondered what reward would be appropriate. The championship class would get snacks/juice for a co-ed party in their classroom. Doing the same might cause issues since they didn't win overall, plus convincing the boys would be troublesome. Since he made the promise alone, Yuu decided to handle it himself. Seeing Yoko and Kazumi delighted by his presence confirmed this. All eight were attractive girls. Ideally, he'd attend to each individually. But even Yuu knew having sex with eight at school was reckless - he wasn't that shameless. Both parties - girls especially fond of Yuu, and Yuu with his exceptional interest in girls - could enjoy something mutually satisfying. Keeping details hidden, he began explaining their task.

Beyond a sturdy iron door lay a storage room. At Yuu's request, the girls split into two groups. The first four had been secluded inside with Yuu for nearly 30 minutes.

"Well? Hear anything?"  
"Hmm... Sometimes strange sounds. But not what they're doing..."  
"Strange sounds?"  
"W-well..." Kazumi, ear pressed to the door, stammered at Yoko's question.

"If it's a reward, maybe they're doing enviable, scandalous things with Hirose-kun..."  
"Enviable and scandalous?"  
"Wh-who knows!" Yuma stared at the door as if trying to see through it, then turned back looking genuinely clueless. But Mashiro, who'd made the comment, averted her eyes without answering.

As the four waited restlessly, about 30 minutes later, the door finally opened. Mao, emerging first, looked odd - hugging herself with unsteady steps, face flushed and downcast without looking at them. The next girls emerged covering their crotches and walking pigeon-toed, or with flushed faces.

"Hey, what happened?" Yoko immediately asked Mao, but she startled and avoided eye contact.  
"I-I need to preserve this feeling and smell and image!"  
"M-me too!" Suddenly Mao dashed off, the others chasing after her as they ran outside.

"Heyyy, sorry to keep you. You can come in now." Though puzzled by Mao's group's behavior, it was now their turn. Responding to Yuu's call, they entered the gym storage.

"Please lock the door behind you."  
"Ah, yes." Mashiro, last to enter, locked it with a *gachan*. They'd deliberately left the lights off, leaving the storage dimly lit. Folded ping-pong tables, badminton nets, balance beams and pommel horses for gymnastics lined the walls. Vaulting boxes and gym mats were stacked deep inside. Though spacious, the clutter made it feel cramped. Yoko's group noticed a dusty smell upon entering, but the lingering scent of female sweat remained from the previous group.

On the hard linoleum floor center lay a white gym mat where Yuu sat with one knee raised, wearing short-sleeved gym shirt and half-pants. Even in a co-ed school, girls had never seen a boy like this up close yesterday. Combined with the dimness, it gave Yoko's group a lewd, sinful impression.

"Don't just stand there. Come closer." "Ah... okay." Even usually cheerful Yoko seemed subdued by the atmosphere, taking a step forward with few words. Tallest in the group, Yoko stood slightly taller than Yuu, with short bobbed hair and a slender build. Next was Kazumi, about Yuu's height, with a single braided ponytail. Though slim, her unexpectedly full chest and butt made her physique tantalizing to Yuu. In contrast, short and flat-chested Yuma looked childishly young enough to mistake for an elementary student. Her long hair, which normally reached mid-back, was split and braided to hang forward today to avoid interference during the match, with pale purple ribbon accents at the tips. Mashiro stood around 160cm, slightly chubby with unmistakably large breasts even under gym clothes. Her shoulder-length hair was tied with a hairband on the left side, bouncing perkily.

Clearly nervous, the girls' eyes still busily scanned every inch of Yuu's body. Conversely, Yuu shamelessly admired their chest curves and exposed thighs through their gym clothes. Yuu's crotch remained hard from lingering excitement, hence the knee-raised position to hide it.

"It's too dark to see well. Come sit closer, Yoko." "Fweh!?" "Let's use first names at times like this." "O-okay... Yuu-kun." Yoko happily moved beside Yuu and sat on the mat.

"Don't be shy. Come here, Kazumi." "Hy-hyai!" "Yuma, Mashiro, come closer so I can see your faces." "Mmm..." "Y-yes!"

All four sat before Yuu on the mat. Though not changed, they'd likely wiped off sweat. A refreshing fragrance tickled Yuu's nose.

"Um, ah, Yuu-kun?" Perhaps because they were within arm's reach, Yoko spoke shyly. "Wh-what now...?" "Ah, I'll explain so listen." "Okay." When Yuu looked around at them, they nodded in unison. Yuu then picked up a timer - likely from the gym, found in a nearby basket.

"Starting now, for 30 minutes... you can do whatever you want to me."

Yuu's words left all four momentarily speechless, mouths hanging open.

---

### Author's Afterword

I saw an illustration of a girl in gym bloomers sitting on a mat in a gym storage room that felt strangely erotic and exciting. I aimed for that gender-reversed vibe.

### Chapter Translation Notes
- Translated "円陣" as "huddle" to convey sports team unity ritual
- Translated "体操着ブルマー" as "gym bloomers" for culturally specific athletic attire
- Preserved Japanese honorifics (-kun) and first-name usage as per original text
- Transliterated sound effects (e.g., "gachan" for ガチャン, "dosu" for ドス)
- Translated "ご褒美" as "reward" maintaining ambiguous erotic undertones
- Rendered sexual tension implicitly without adding euphemisms