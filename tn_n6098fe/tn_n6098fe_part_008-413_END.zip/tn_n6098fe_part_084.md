## 77. Ball Games Tournament ⑤ ~Temptation~

"You can do whatever you want with me."

The four girls froze at those words, but Yoko recovered first, followed by Kazumi - likely because they could vividly imagine what this meant after the Newcomer Welcome Orienteering event.

"With Yuu-kun... d-do whatever we want... U-um, question!"  
"Sure, go ahead."  
"Like... hugging you suddenly?"  
"K-k-kissing too!"  
"Of course, that's fine."  
""Wow!""  
"No way..."  
"Huh? Huh?!"

Yoko and Kazumi immediately broke into delighted smiles. In contrast, Yuma and Mashiro stood dumbfounded, unable to believe what they were hearing.

"This timer's set for 30 minutes. Anything goes as long as we don't take clothes off. I thought about different rewards, but figured letting you enjoy me freely would be best. The first group seemed hesitant at first but ended up enjoying themselves right until the end. Is that okay with you too, Yoko?"

"O-of course!"  
"W-with Yuu-kun... doing all that stuff...?"  
*Gulp*... *slurp*  
"A-ah... I can't believe it but... please take care of us"

"Haha. If there's something you want me to do, I'll do my best. You can think about it now if you want. Let's start in one more minute?"

After they nodded kokkoku, Yuu set the timer for 31 minutes and started it. Exactly one minute later when it hit 30 minutes, he called "Start!" - and Yoko and Kazumi immediately threw themselves at him where he sat cross-legged. They wrapped their arms around him, pressing their chests against him and rubbing their faces against his shoulders, having apparently coordinated to flank him - Kazumi on his right, Yoko on his left.

Yuma, who seemed late to start, rolled into position directly in front of him with volleyball-match speed. They instantly became a tangled cluster of four bodies.

"Aww..."

Mashiro was left teary-eyed, having been late and finding all positions taken. Though Yuu could feel the girls' warmth and sweet fragrance pressed against him, he had no intention of leaving her out.

"If you'd like, Mashiro, could you hug me from behind?"  
"U... un!"

Mashiro quickly scrambled behind Yuu and oddly sat seiza-style before hugging him from behind.  
"Wow! Yuu-kun's back is so broad... And it smells so nice... Ah! S-sorry... that was weird to say."  
"Hahaha. Not at all. Enjoy to your heart's content."  
"I-I'm so happy... Yuu-kun, you're so kind even though you're a boy."

Yuu felt grateful himself as Mashiro's incredibly soft, large breasts pressed against his back.

"U-um... Yuu... ku..."  
Hearing a small whisper, Yuu turned left to find Yoko's face extremely close. Without waiting for her to finish, Yuu sealed her lips with his own.

"Mmm... fuh... mmn~"  
He changed angles several times, enjoying the soft lip sensation.

"Umm... me too..."  
"Ah, of course"  
Turning the other way, he kissed Kazumi this time.

"Uuu..."  
Hearing a voice from below, Yuu looked down to see Yuma pressed flat against his chest. After looking up at him, she shyly lowered her gaze. Yuu stroked her head with his free hand.

"Yuma, want to kiss too?"  
"...Y-yes..."  
Seeing Yuma's large eyes grow moist made Yuu's heart twinge.

"Come on. Get closer."  
"Nn"  
Yuu tilted her small chin downward as she raised herself slightly, their lips meeting. Though just a light touch, when he pulled back he saw her face had turned bright red.

"First time?"  
"Y-yeah"  
"Want more?"  
"Yeah!"

As he kissed Yuma repeatedly with chu, chu sounds, he heard a mutter: "Uu~, I-I want too..."

Yuu craned his neck to look back.  
"Mashiro, let's ki... oh!?"  
Yoko sealed Yuu's lips before Mashiro could approach.

"Hey! Yoko, you just did it!"  
"Ehehe, sorry~. But kissing Yuu-kun feels so good it makes my head melt!"  
"Then I want it even more!"  
"Hey now, no fighting. Play nice."

Chastised by Yuu, Yoko finally lowered her head.  
"Ah, right. Sorry, Mashiro."  
"U-um, it's okay. Umm, Yuu-kun, could I kiss you now?"  
"Gladly"

Since she ended up last and got skipped, Yuu took his time kissing Mashiro slowly.

After another round of kissing, all four girls pressed against Yuu with lewd expressions. Being sandwiched by high school girls in bloomers was unbearable for Yuu. He'd been erect since midway through the first group and remained so now. But bound by his "no undressing" rule, he had to endure. *I should've at least taken off my lower half,* he internally regretted, but it was too late. He decided to enjoy himself too.

"Since we're here, why don't we touch each other's bodies?"  
"T-touch bodies!?"  
"Y-Yuu-kun's body..."  
"Damn, I might get a nosebleed"  
"Mashiro, it's too early to go"

Yoko supported Mashiro who looked ready to faint while pinching her nose.

Meanwhile, Yuma raised her hand from the front.  
"Yuu-kun, one question"  
"What is it?"  
"Something hard's been poking my crotch since earlier. What's this?"  
"Ah, that's my cock."  
"Co..."

Not just Yuma, but Yoko and Kazumi who'd previously given blowjobs peered down too. Though shadowed, the clear erection was visible even through his half-pants.

"Hey, Yuu-kun?"  
"Yeah?"  
"Is your cock allowed too?"  
"It is... wait, hold on"

Yuu stopped Yoko and Kazumi who were already reaching for it. Mashiro tilted her head, not following.

"Touching is totally fine, but if you fondle it too enthusiastically and I ejaculate in my pants, that'd be bad. So let's not go overboard today. Since it's a rare chance, feel free to check its size and shape. You can touch anywhere else as much as you want."

Saying this, Yuu reached out both hands to touch Yoko and Kazumi's breasts. Rather than minding, they showed delighted expressions as he kneaded them.

"Aha! Then I won't hold back"  
"S-sorry for this..."

Yuu had his chest groped - boldly by Yoko and hesitantly by Kazumi. Both had sparkling eyes and were clearly getting excited. Though Yuu didn't quite understand, touching a boy's chest counted as proper sexual activity in this world, apparently causing great excitement.

"Uhi! T-ticklish!"  
"Ah... sorry. No armpits?"  
With his chest occupied, Mashiro had touched his armpit from behind. Yuu jumped in surprise, accidentally breaking contact with her breasts - a shame.

"No, I was just startled since there was no warning. It's fine if I know."  
"R-really? Thank goodness..."  
"Actually, Mashiro, why not press your chest against me while touching?"  
"Eh!? M-my breasts...?"

Mashiro tried hiding her chest with both hands, but they were too large, making them bulge instead. *Come to think of it, big breasts are unpopular here. What a waste,* Yuu thought.

"Just so you know, I like both big and small breasts. Right now I want to feel Mashiro's boobs."  
As if proving it, Yuu's hands kneaded Yoko's small breasts and Kazumi's larger ones.

"Ahhn~, having my breasts squeezed by Yuu-kun's big hands... it's making me feel weird..."  
"M-me too... ah, there! I can feel it!"

While Yoko and Kazumi eagerly touched Yuu's chest with one hand, their other hands rested on his as he kneaded their breasts.

Seeing this, Mashiro nodded understandingly and whispered:  
"S-so that's how it is. Even a fatty like me... Yuu-kun accepts me... so kind... I love you"  
Her face pressed against Yuu's back so he didn't hear, but Mashiro wore a happy expression as she pressed her large breasts against him and gently touched his armpit.

"Yuu-kun"  
"Hmm?"  
Busy with Yoko and Kazumi's breasts and talking to Mashiro, Yuu now faced Yuma who'd knelt up close. His face was level with her chest area - disappointingly flat.

*(Hmm... if my hands were free I'd touch to check for nipples, but both are occupied)*  
With hands unavailable, only his mouth remained.  
"Yuma, come a bit closer"  
"Nn"

Yuma's chest came near Yuu's face. Hard to see in the dimness, but closer inspection revealed gentle curves rather than complete flatness, with slight nipple protrusion. Likely wearing thin sports bras or camisoles like middle schoolers since she lacked supporting breast volume. Yuu sucked at the small bump.

"Fwa!"  
Yuma's small body trembled slightly. Bullseye. Though worried about sensation through two fabric layers, Yuma seemed sensitive there. Yuu kept stimulating her nipple, practically soaking her gym clothes with saliva.

Later, when Yuma requested more kisses, it escalated to deep kissing. Yoko and Kazumi wanted it too, so he deep kissed them in turn, simultaneously fondling their bloomer-covered crotches. By the second round, both Yuu and the four girls were highly aroused.

For first-years, such physical contact with a boy was nearly impossible. Though hesitant at first, once aroused they became like cats in heat, wanting Yuu without restraint.

Yuu himself desperately wanted to ejaculate. But unlike his previous life, he could have sex whenever he wanted at home or school now, giving him patience. With about 1/3 time left, he decided to prioritize their pleasure for this reward.

Lying on his back, he said: "Use whatever part of me you like."

"Hah, hah, hah... ahn! Yuu-kun's... legs! So hard and rugged... feels good!"  
"Nn, fuu... faa, ah... me too... doing this... makes my down there feel weird!"

Kazumi and Yoko straddled Yuu's legs, grinding their crotches - already leaving damp stains.

"Haa, haa... ah, ahn! This... this is like a dream... nn, ah, I'm heavy... sorry... but I can't stop my hips... ahn! Yuu-kun's hand... so big, feels so good on my breasts!"

Mashiro had chosen Yuu's chest. Though seemingly uninteresting, grinding against a boy's chest was apparently a secret fantasy for girls. Thinking she needed more stimulation, Yuu reached forward to knead her abundant breasts with his left hand - he felt grateful to handle such overwhelmingly soft mounds.

"Fu-, fuu... nn... fa... aa... nnn!"  
The last one, Yuma, had her bottom placed on Yuu's face at his request, facing Mashiro. Though through bloomers, Yuu's mouth thoroughly stimulated her private area, the crotch visibly damp with drool and her secretions. Occasionally her small body would jerk away from the stimulation, requiring Yuu to hold her down with his right arm. Though embarrassed about sitting on his face, her ragged breathing and constant whimpers showed unusual disarray.

The immorality of using a boy for their pleasure. The heightened arousal from doing this with Yuu - their long-admired crush. The girls' moans naturally grew louder.

"Ah! ...I-I'm cumming... nn, nnaa! Sorry... Yuu-kun's knee... I'm... ah, ah, ah, aaaaah! I-I'm cummiiiiiiiiiiiiiiiiiiing!!!"  
"Ahn, ahn! The hard part of your knee feels... so good... can't stop! Yuu-kun... Yuu-kun! I-I'm cumming too! Cummingggggggggggg!!!"

Kazumi came first, then Yoko, collapsing forward onto Yuu's lower abdomen where his erect bulge protruded. Curling up, they began lovingly licking it from both sides with their tongues.

The warm stimulation on his crotch made Yuu unable to hold back. He had to make Yuma and Mashiro cum before time ran out. Cheating slightly, he slipped his left fingers under Mashiro's bloomer leg opening - feeling her thoroughly soaked pubic hair and swollen clitoris, which he rubbed with his fingertip.

"Ahe? A... iin! Sho... ko... aaahhhn!"  
Mashiro froze mid-movement, moaning loudly. Simultaneously, Yuu used his right fingers to shift Yuma's bloomers and panties aside, running his tongue over her smooth privates.

"Hyaa!? Nyaaaaaaaaaaah! Yu... Yuu... kun, no... aun!"  
Startled by the unexpected mucosal stimulation, Yuma tried lifting her hips but couldn't with Yuu pinning her thighs. Her wandering hands tightly grasped Mashiro's.

"Yuu-kun! Yuu-kun! Sho... ko, shugoku... feels so goooood!"  
"Tha... that place... ah, ah, ah, I'm cumming!"  
"AAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHH!!!"

As Yuu's fingers and tongue brought Mashiro and Yuma to climax while tightly holding hands, the timer beeped - exactly 30 minutes had passed.

***

"Did you enjoy yourselves? Was it satisfying?"  
Sitting up, Yuu held Yuma and Mashiro in his arms - both seemed dazed.

"It felt amazing! Totally satisfied! Right, Kazumi?"  
"Ufuh... Yuu-kuuun..."  
Seeing Kazumi nuzzle his shoulder with climax remnants, Yoko competitively buried her face against his other side.

"Well, I'm fine staying like this, but... won't it be bad if we stay too long?"  
"Ah..."

Though the second gym floor had been unused and empty, anyone could come anytime.

"Really wish we could stay, but we should end it. Yuu-kun, thank you for today."  
"Th-thank you!"  
"You're welcome."  
After exchanging looks with Yoko and Kazumi, he patted Yuma and Mashiro's heads.  
"Shall we go?"  
When Yuu asked, both looked up at him with heated gazes but eventually nodded.

Yoko pressed her ear to the door first but heard nothing. Opening it quietly, fortunately no one was there - their secret storage room activities remained undiscovered.

Even after leaving the gym, the four walked surrounding Yuu at close distance. Over an hour had passed, so the tournament cleanup was finished. Luckily they encountered no one.

All four hated parting from Yuu, but they'd spent a dreamlike 30 minutes as their reward. Greed would bring punishment. They'd say goodbye with smiles.

Yoko couldn't forget the feel of that hot, hard cock she'd touched at the end. While stealing glances at Yuu's lower body as they approached a corridor corner, she noticed distance opening between Yuma/Mashiro ahead and Kazumi/Yuu behind. She saw Yuu stroke Kazumi's butt while whispering something. Kazumi nodded, blushing, before Yuu turned forward and rounded the corner.

*(What did he say to her? I'll interrogate her later!)*  
Proceeding along the covered walkway from gym to school building, they waved goodbye to Yuu with smiles at the fork.

"Kazumi!"  
As Yoko called out, Kazumi panickedly turned back the way they came.  
"Sorry, just remembered I forgot something!"  
"Eh... then we'll go ahead to class."  
"U-um, you can go home first if you want!"

With that, Kazumi bounced away. Walking back to class with Yuma and Mashiro who kept talking about Yuu, Yoko suddenly wondered: Kazumi had been holding her small pouch with handkerchief, tissues, and sanitary products. Had she brought anything else?

### Chapter Translation Notes
- Translated "チンポ" as "cock" per explicit terminology requirement
- Rendered sexual acts without euphemisms: "射精" → "ejaculation", "フェラ" → "blowjobs"
- Preserved Japanese honorifics: "祐君" → "Yuu-kun"
- Transliterated sound effects: "コクコク" → "kokkoku" (nodding sound)
- Maintained original name order: "陽子" → "Yoko" (Hiyama Yoko)
- Italicized internal monologues: *(Hmm... if my hands...)*
- Used explicit anatomical terms: "クリトリス" → "clitoris", "アソコ" → "down there"
- Translated "ブルマー" as "bloomers" for culturally specific gym attire