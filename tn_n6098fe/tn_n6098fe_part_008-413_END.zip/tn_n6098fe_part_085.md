## 78. Ball Games Tournament ⑥ ~One more time, One more chance~

As Yuu stepped into the deserted gym restroom, the innermost door among three adjacent stalls stood slightly ajar.

Without hesitation, Yuu approached and swung the door open to find Kazumi standing inside.

Entering and locking the door behind him, he immediately embraced Kazumi tightly.

"Ah, Yuu...kun!"  
"Thank you, Kazumi. For coming."  
"Of course, since you specially invited me."  
"Yeah. I thought you'd definitely come, but my heart was pounding until I opened the door."  
"Yuu-kun!"

Their eyes met and their lips joined, beginning a passionate kiss while locked in embrace.  
Soon their tongues intertwined, accompanied by wet smacking sounds. "Ahm, chu, chupa...juru...ufuu...Yuu-kun...I love you...ahhn!"  
Yuu's hand slipped under her gym uniform, skillfully unhooking her bra and groping her breast.

During the Newcomer Welcome Orienteering, he'd touched Kazumi's breasts when they hid in the culvert.  
Back then it was too dark to see properly, but he remembered their pleasant size from touch and appearance through the uniform.  
Now, as their lips met, Yuu looked down to see breasts slightly spilling from his palm.

"Fufu. This time I'll touch you without holding back."  
"Ah...then, can I touch you directly too...Yuu-kun?"  
"Sure. Go ahead."  
"Waha..."

Yuu lifted his own hem with his free hand, revealing his toned abdomen from workouts. Kazumi's eyes seemed to sparkle.

"Haa, haa...Kazumi's breasts and ass are just the right size, soft and pleasant to touch."  
Yuu grasped her breast with his left hand while his right slipped into her bloomers to grope her buttock.

"More, more, touch me...ah, ahn! When you touch me, it feels so good... And your body, Yuu-kun, slender yet firm in places...it's wonderful...feeling it directly...hyahn! Th-there..."

Yuu's hand moved behind to her panty crotch.  
Even through the fabric, he could feel it was thoroughly soaked. Yuu whispered in her ear:  
"You're incredibly wet."  
He placed his middle finger over her slit, testing the sensation with light presses and rubbing.  
Through the thin fabric, he could feel the softness of her flesh.

"Nkuh! B-but...after what happened earlier... You've been hard against me this whole time too?"  
Blushing, Kazumi rubbed Yuu's bare back with both hands while deliberately pressing their lower bodies together.

"Kuu...I've been erect the whole time in the storage room. I'm at my limit now. K-Kazumi, I want you."  
"Fweh!?"

Hearing those words at close range, Kazumi stiffened as if struck by lightning.  
Her large dark eyes widened into perfect circles as she stared intently at Yuu.

"I-Is it okay? Wait, did you hear me?"  
"Hah! Yes! O-of course~"

Yuu found it strange, but Kazumi's reaction wasn't surprising.  
This was dialogue only seen in unrealistic romantic comedies featuring men with strong sexual appetites.

"We kissed during the Newcomer Welcome Orienteering...but this would be our first time having sex, right?"  
"U...un."  
"I'm sorry your first time is in a place like this."

From his pre-reincarnation knowledge, Yuu thought girls preferred romantic locations for their first experience.  
Even for students with limited budgets, a love hotel or someone's home would be better.  
Though in this world, he'd done it in the student council anteroom, hospital, and even a boys' restroom.

"I-it's totally fine... Actually, I'd be happy anywhere if it's with you, Yuu-kun. Just having you this close, kissing and holding me...my head feels all fuzzy. It's like being in heaven..."  
"Ahaha. I'm honored."

Kazumi gazed straight at him with moist eyes.  
Though slightly droopy, her features were well-proportioned, and her small yet plump lips glistened with moisture.  
She was a gentle-looking beauty - had the pre-reincarnation Yuu met her in high school, he'd have fallen for her instantly.  
Feeling her sincere affection, warmth spread through Yuu's chest.

"Kazumi!"  
"Yuu...kun!"

They embraced tightly again, exchanging kisses.  
Maintaining their connected embrace, Yuu shifted positions and sat on the toilet seat.

"Lero, amuchu...Kazumi...will you undress me?"  
"Npah...yes."

While licking each other's lips, their tongues poked playfully before their mouths smacked together again. Kazumi smoothly pulled down Yuu's half-pants and underwear.  
Instantly, his fully erect cock sprang out vigorously toward the ceiling.

"Wah! Seeing it clearly like this...it's amazing, Yuu-kun's cock."  
Kazumi gulped while looking down at the glans dripping clear fluid.  
"Then touch it."  
"Hah...un. Th-then excuse me... Wow, rock hard! So this is how it feels..."  
Recalling her previous touch, Kazumi stroked the cock from tip to base with a blissful expression.

"C-can this cock really...fit inside me?"  
"Hmm, they say breaking a girl's hymen hurts terribly. Can you bear it?"  
When Yuu asked, Kazumi stared at his cock, thought for a moment, then replied:  
"I-it might be okay."  
"Eh? Why?"  
"U..."

Blushing, Kazumi clung to Yuu, burying her face in his neck.  
"Umm...I think it's okay to tell you... But! Don't be shocked..."  
"Hm? Okay. Tell me anything. I won't be shocked."  
Yuu gently stroked her head.

"W-well... Ever since the Newcomer Welcome Orienteering, I couldn't forget it. I started...doing it...myself."  
"Hohou."

Seeing Yuu look intrigued rather than shocked, Kazumi continued in surprise.

"When I imagined Yuu-kun's...c-cock that you let me touch...just fingers weren't enough anymore."  
"Un. Then?"  
"V..."  
"V?"  
"Vibrator."  
"I see. So you broke your hymen with a vibrator."  
"Hyai!"

For Kazumi, this confession felt like admitting to being a perverted masturbator, requiring great courage. But Yuu, remembering his sister's example, simply accepted it as normal.  
Rather, he felt happy she'd thought of him so much.

"Sorry for being such a slut."  
"Eh? No need to apologize, not at all."  
"R-really?"  
"Ah. I love slutty girls?"  
"Howawa...Yuu-kun!"  
"Oof."

Kazumi clung to him full-body, putting them face-to-face in a seated position.  
Her exposed breasts, still pushed up, pressed against Yuu's chest and squished softly.  
Her bloomer-covered crotch touched his cock.

"K-Kazumi. I want to enter you now."  
"I-I want you too, Yuu-kun."

Still nuzzling his cheek, Kazumi reluctantly pulled away just enough to slide aside her bloomers and panties.  
Now there was no stopping Yuu.  
Holding Kazumi with one arm, he guided his cock into position with his right hand.

"Lower yourself onto me."  
"Nn...Yuu...kun. Ah...it's entering."

The thoroughly wet vaginal entrance made a squelching sound against Yuu's cock.  
"Ahh..."  
The sensation of his tip being enveloped by soft, slippery flesh drew a sigh from Yuu.  
As Kazumi lowered her hips further, his cock slid in with a wet sound.

"Ahhoh...nnn! Ugh, ahh...it's going in, going in! Yu, Yuu-kun's cock! Ah, ah, ah, so hotttt...auu! A-amazing!"  
"Ohh...Kazumi's inside is incredible, so slippery. Kuh! Wait, hold on!"

Though her hymen was already broken by the vibrator, Kazumi's virgin pussy tightly gripped Yuu's thick cock.  
Just before reaching her depths, the intense tightness nearly made Yuu cum, so he stopped Kazumi's movement.  
After being kept erect for nearly an hour, his endurance had weakened.  
But as Kazumi held still, he gradually pushed deeper.

Thrust, thrust, thump!  
"Ohh, ohh! U...guh!"  
"Kyahi! I-in! Your cock...so deep!"

Suddenly their eyes met.  
Kazumi's cheeks flushed pink, her eyes half-open and dazed.  
"Ahh~ K-Kazumi's inside feels too good. I almost came... D-does it hurt?"  
"Hah! U-um, at first I thought it hurt, but as your cock went deeper...it kept feeling better... Now my mind's going blank... Kyah, what am I saying? So embarrassing!"

Yuu's affection grew seeing her bury her face in his neck.  
"Kazumi..."  
Holding her tight, he whispered in her ear.  
"Yuu, kuun..."  
Timidly looking up, Kazumi's eyes were moist.  
"Being connected like this with you...makes me so happy. Studying hard to enter Sairei Academy, meeting you...getting more and more attracted...and now losing my virginity so soon... I...love you! Yuu-kun, I love you!"  
"O-oh. I'm happy you feel that way...huh?"

During this touching moment, Yuu felt an intense gaze and looked past Kazumi's face toward the door.  
His eyes traveled upward to find Yoko clinging to the top edge of the door, watching them.

"C-hea-ting! Why...are you two doing it alone? When you both acted sneaky leaving the gym...Kazumi said she forgot something and didn't come back..."  
"U...sorry."  
"No, Kazumi's not at fault. I...suddenly called out to her."

Since they'd been caught, they couldn't stay like this. Kazumi reached back to unlock the door.  
Yoko's anger was understandable - among the four girls from the storage room, only Kazumi got special treatment.

"Listen, Yuu-kun."  
"Un."

Yoko's expression wasn't angry as she stared at Yuu still connected to Kazumi, but her gaze was serious.

"Like I said before, I like you. But since you're everyone's idol, I don't mind if you have sex with others. Actually...you're close with the student council president and seniors, right?"  
"O-oh."

While no boys commented, rumors spread quickly among female students.  
He'd been seen holding hands with Sayaka and others leaving the student council room.

"But during the Newcomer Welcome Orienteering, Kazumi and I both confessed to you at the same time, kissed you, even touched your cock... So! Don't...leave me out..."

Though usually bright and smiling, Yoko's eyes welled with tears before she looked down.  
Seeing this, even Yuu felt guilty.  
He'd thoughtlessly called only Kazumi without considering Yoko's feelings, though he liked her equally.

Yuu took Yoko's hand and squeezed it.  
"Sorry, Yoko. I only thought about myself, not your feelings at all."  
"Yu, Yuu-kun...that's...ahh."

Yuu pulled Yoko close, looking directly at her face.  
"Sorry about the location, but want to have sex together?"  
"Ahah...yes yes!"  
"Hahaha. Glad you're smiling. Yoko's smile really is the best."  
"Anh."

Pulling her in with an arm around her shoulder, they kissed.  
Yoko clung to Yuu as they began a passionate kiss.  
While their tongues tangled with wet sounds, Kazumi pressed against Yuu, kissing from his neck to cheek while sliding her tongue along.

"Since it's Yoko...together is...ahha...fine...nnn...but right now...I'm first..."  
Though calmed slightly by Yoko's intrusion, Yuu's cock remained fiercely hard inside Kazumi's tight pussy.  
Breaking the kiss with Yoko, a string of drool still connecting them, Yuu spoke to Kazumi.

"Kazumi, can you move by yourself?"  
"Eh...c-can I? Wah! If I try to move...ah, ah, ah, ahn! No! It feels weird!"

Staying still while deeply penetrated felt incredibly pleasurable for Kazumi.

"Then I'll move slowly. Yoko."  
"Nn...?"  
"I want to see your pussy."  
"Ahaha. Wanting to touch girls' breasts, see their privates...you're really unusual, Yuu-kun."  
"I want to see yours, Yoko."  
"Anh... Hearing that makes me shy."  
"Haha, you're cute, Yoko."  
"...!"

Blushing, Yoko kissed Yuu again.  
As he stroked from her shoulder-length hair to behind her ears and down her neck, she moaned "Afuun" plaintively.  
Simultaneously, Yuu held Kazumi's waist with his left arm and began thrusting shallowly.  
With each thrust deep inside, Kazumi clung to Yuu, intermittently moaning.

"Nn."  
Standing straight, Yoko began undressing below as requested.  
Not removing everything at once but showing her panties first suggested shyness, which Yuu enjoyed.

The pink lace panties with frills revealed when she lowered her bloomers to her knees were quite cute.  
"Hoh. They're cute."  
These might be her special occasion underwear.  
If so, they'd seen the light at the perfect time.

"Ah...r-really?"  
Pleased by the compliment, Yoko smiled shyly.  
Yuu lifted her gym uniform hem to see a slender, toned stomach and matching pink bra.  
Though the bra made her chest appear fuller, her actual bust was smaller than Kazumi's.

"I didn't get to see earlier, but what about Kazumi's underwear today?"  
He asked while thrusting.  
Kazumi, who'd been nuzzling his neck and moaning, looked up weakly.

"Ah...afuu...l-lavender...ahn!"  
"Matching set?"  
"Y-yes...ah, ah, ah, there! Feels good!"

Her bra cups, unhooked earlier, rested atop her beautiful breasts, swaying with Yuu's movements.

Yoko hooked her fingers into her panty sides without hesitation, but paused when neatly trimmed pubic hair became visible.

"Nn? What's wrong?"  
"A~h nothing!?"  
Blushing, Yoko slowly lowered her panties. When the crotch parted, a transparent string stretched from her vaginal opening.  
The panty crotch that had touched her pussy showed a spreading wet spot.

"Ooh!"  
"E-even now...I'm this wet... Ehehe."  
"Yoko, don't worry. I've been erect this whole time too. Kazumi was also very wet!"  
"Ahhn! But...ah, ah, because it's Yuu-kun!"  
"Uu...I want it soon too!"  
"Just wait a bit. I'll take care of you now."

Yuu rubbed the center of Yoko's slit with his fingertip upward.  
"Haun! Yu, Yuu-kuun!"  
Instantly, her love juice coated his finger.  
Bending his knuckle to probe her entrance, soft flesh welcomed him inside with no resistance.  
Though vaginal walls resisted midway, pistoning his finger gradually penetrated deeper.

"Ah, ah, aahn! Better than...doing it myself...when you do it!"  
"Hey, Yoko?"  
"Hah, hah...what?"  
"Do you masturbate? What do you use?"  
"U...eh...do I have to say?"  
"Kazumi was honest. Since we're here, you should tell me too. Or else..."  
"Stop...don't pull out. I'll tell."  
Yuu withdrew his dripping finger, smirking at the fluid string, then looked up at Yoko.  
"I always used my fingers...but...it stopped being enough."  
"Why?"  
"Eh?"  
"Tell me."  
He spread her labia with two fingers, opening and closing them while teasing around her entrance.

"Ah, afuu...nn, nn, kuun... You're so mean, Yuu-kun."  
"I'm interested in how girls pleasure themselves."  
"Geez... Since the Newcomer Welcome Orienteering...after touching your cock...I wanted something thicker and longer!"  
"Hohou. So you started using toys."  
"Anh...a vibrator...nn, put it here...ahn, broke my hymen..."  
"Like this?"  
Yuu inserted his middle finger.  
"Ahhahn! Y-yes! Ah, ah, Yuu-kun!"

As he thrust his finger vigorously, Yoko suddenly grabbed his shoulders, legs trembling like a newborn fawn.

While fingering Yoko, Yuu looked at Kazumi who'd buried her face in his neck with muffled moans.  
"So you both broke your hymens with vibrators, but how's the real cock? Feels good?"  
After several calls, Kazumi finally looked up with a dazed expression, drool dripping from her half-open mouth.  
"Sorry...I came just now..."  
Yuu understood why his neck felt breath and why her uniform shoulder was damp.

"Then let's come together this time? Ready?"  
"Hyaun!"

Though holding back while talking to Yoko, Yuu reached his limit.  
Securing Kazumi with his left arm, he thrust upward.

*Thump, thump, thump!*  
With each thrust, rhythmic flesh-slapping sounds echoed in the narrow stall.

"Ahh, ih, ih, ihin! Amazing! Aahn! Yuu-kun's...cock! Inside me! Thrashing!"  
"Kuu! I'm...almost...cumming!"  
"Hyahn! N-no...don't go so hard...ahn, ahn! I'm cumming too!"

Tossed by Yuu's thrusts, Kazumi clung tightly, rubbing her cheek against his while moaning shrilly.  
Meanwhile Yoko, being fingered, barely held onto his opposite shoulder but neared her limit.

"Ah, ah, no...I'll cum from your finger before the cock!"  
"You can cum as many times as you want, Yoko."  
He kissed Yoko who'd lifted her face.  
Then kissed Kazumi who approached.  
Alternating kisses, all three seemed near climax.

"Guh, oh! I'm cumming! Kazumi! I'm...ejaculating!"  
"Ah...ah, aun! Yu...u...kuun! Ah! Aheee...your cock...amazing!"

As Yuu reached orgasm, Kazumi simultaneously climaxed.  
"Ya, ahh! Yuu...kun! W-wait...stop...yan! Cumming! I'm cumming! It's coming out!"  
While being vigorously fingered with wet squelching sounds, Yoko shuddered violently before gushing copious fluid that splashed onto Yuu's body.  


### Chapter Translation Notes
- Translated "体操着" as "gym uniform" to match school setting context
- Preserved Japanese honorifics (-kun) per style guidelines
- Translated explicit anatomical terms directly ("cock", "pussy", "breasts")
- Used "bloomers" for "ブルマー" as established gym attire term
- Transliterated sound effects (e.g., "chu" for ちゅ, "juru" for じゅる)
- Maintained original name order (Aki Kazumi, Hiyama Yoko)
- Rendered sexual acts without euphemisms ("ejaculating", "squirting")
- Formatted internal monologues in *italics* per style guide
- Applied dialogue formatting rules (new paragraphs for each speaker)