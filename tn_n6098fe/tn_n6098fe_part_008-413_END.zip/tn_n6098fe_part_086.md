## 79. Ball Games Tournament ⑦ ~Together, Aren't We~

"Haaah... ah...nnn! Yuu-kun, you're like a baby. Do you really like breasts that much?"

Yoko, clinging to Yuu, gently stroked his head like she was caring for an infant, not just holding his back.

"Nn? I do. Why? Is it strange?"  
"U...nn, I don't hear much about boys your age liking breasts. Right, Kazumi?"  
"Ahfunn. Maybe... But Yuu-kun can touch them anytime he wants."  
"Even suddenly in the hallway?"  
"Un. Touch them lots."  
"Mine too!"

What joyful news that they'd welcome breast-touching upon meeting in school hallways. But Yuu refocused on enjoying sex with both girls. Considering their age, at 15 they were the youngest partners Yuu had been with. Yet just as Yuu possessed an adult body with fully developed genitals, Yoko and Kazumi also had mature female bodies that reacted sensitively. Their youthful skin felt firm and supple to the touch, stimulating Yuu's desires.

Now with Kazumi having switched places, Yoko straddled Yuu seated on the toilet in a cowgirl position. Since Yoko was slightly taller, her breasts were at the perfect height.

When Yuu penetrated Yoko with his still-erect cock immediately after ejaculation, she seemed to feel slight pain, but her joy at experiencing her first time with Yuu clearly overwhelmed it. For Yuu too, despite her broken hymen, Yoko's athletic pussy felt wonderfully tight - so good he nearly came just from the initial deep thrust. Having already ejaculated once gave Yuu more leeway than with Kazumi. Instead of thrusting immediately after insertion, he lifted her gym clothes, removed her bra, and suckled her modest yet perky upturned breasts. He had Kazumi come close too, caressing her alluring body and fondling her breasts.

"About time? Should Yoko move? Or should I?"  
When Yuu looked up, Yoko nodded with a dazed expression and pressed her lips against his.  
"Nn, nchu... Yuu-kun, please."  
"Okay."

Straightening his back, Yuu pulled Kazumi close with his right hand while firmly grasping Yoko's slender waist with his left, then began shallow thrusts.

"Ah, nn, faa! Ann! Wow, it's pounding deep inside! Ah, ann! I-I'm coming, Yuu-kunn... Yuu-kun filling me up inside... feels so good!"  
"O-oh too! Inside Yoko... feels amazing! Nmu!"

Yoko had been in track and field during middle school, and her well-exercised pussy gripped wonderfully tight around Yuu's fully embedded cock. Meanwhile, recovering from the shock of her first penetration, Yoko's feminine sensuality began throbbing uncontrollably. She could only cling to Yuu while moaning, especially when Kazumi embraced Yuu and stole his lips.

"Nchu... jealous... I want to do it again too."  
"Haha. Your turn's after Yoko's."  
"Th-that's right... It's my turn now aaaahn! Deep inside... being gouged out! Nnaa! Sho, so incredible! I-I'm... coming again!"

When Yuu began grinding against her deepest spot, Yoko threw her head back helplessly. Yuu licked up Yoko's slender neck with saliva-strung tongue while still intertwined with Kazumi.  
"Come for me. Go on, come Yoko!"  
"U...un, I'm coming! Ann, Yuu-kun's making me come! Aaaahhhhhhhhn! I'm cooomiiiiiiing!!!"

"Uwaamu, nn, nchuu... chupaa, le...ro... afunn... Yuu-kun... wonderful... vuaa... ann! Nooo, my body's... melting!"

"Ah... Yoko... nn, guu..."  
"Ah... amazing... Yuu-kunn, I love you... nchu"

Yuu gripped Yoko's slender waist with both hands as he thrust upward. With utterly melted expression, Yoko hugged Yuu's head, kissing him repeatedly while occasionally throwing her head back to moan when overwhelmed.

"See? Where we're connected is all sloppy wet."  
"Uun... truly... is..."

When they slightly separated to look down, they couldn't see the cock inside her vagina, but their sweat-and-juice soaked lower abdomens glistened visibly. Their joining point had been making loud, lewd guchu guchu sounds in time with their movements. Meanwhile Kazumi, watching them closely while clinging to Yuu's shoulder, began fingering her own pussy with parted thighs, breathing heavily.

"Thanks to Yoko squirting, everything's soaked."  
"Never knew Yoko came so loudly."  
"Stooop... both of you... don't say it... ann!"  
"It's fine. Actually, I'm really happy as a man that both Yoko and Kazumi got so aroused during your first times."

Having masturbated while fantasizing about Yuu for a month, both girls lost control beyond expectations during their first actual experience. Though they'd heard sexually hungry women scare boys away and tried to act demure, they completely crumbled before Yuu. Their bodies reacted more sensitively than anticipated, their reason long dissolved - like females in heat. Yet Yuu smiled at them warmly, making their affection overflow.

"Haa, haa... Yoko, I'm about to come too. I'll ejaculate inside you like this. Okay?"  
For Yoko, anything but yes was unthinkable.  
"C-cum! I want Yuu-kun's seeeemen inside me! Kyauun! Your cock feels so goooood!"  
"Gu, Yoko! O, ooh!"  
Whether thrusting or pulling back, the sensation of her vaginal walls milking him drove Yuu toward climax. As the moment approached, they embraced tightly while Yuu thrust violently upward.

"Y-Yoko! Guh! Cumming!"  
"Aaaah! Me toooo! O, ah... aaaaaaaaaaahn! I-I'm cooomiiiiing!!!"

As massive spurts of semen flooded her womb, Yoko reached climax simultaneously, squirting copiously and drenching Yuu's lower abdomen again.

Now before Yuu stood Yoko on the left and Kazumi on the right, both leaning against the door with hips slightly thrust out, exposing their bare lower bodies. The cramped space forced them to interlock shoulders almost intimately. Thanks to years of athletic training since middle school, both possessed youthful, toned figures - their pert, shapely buttocks stimulating Yuu's lust. Their allure showed from behind too. With legs slightly parted, whitish yet translucent love juice dripped down their thighs from their vaginas.

Having sat resting on the toilet seat with both girls on his knees, Yuu suddenly requested: "I want to see your backs properly." When they turned to present their bare buttocks and begged for his cock, Yuu stood up helplessly - his crotch rising with him. Spreading both arms from the center, he embraced them while forcing his hardened meat rod between their buttocks.

""Ah!""  
Both girls flinched at the hard cock touching their buttocks but turned toward Yuu with identical longing expressions.

"Yuu-kun's cock... want it inside soon..."  
"Me too! Want it inside again!"  
"Hey! Yoko just got filled, didn't she?"  
"But~"  
"Fufu, both Yoko and Kazumi are cute with great bodies - and sexy too. Lovely."

When Yuu stretched up to bring his mouth closer, both twisted their necks to compete for his lips. First kissing Yoko on the left, then immediately Kazumi. Alternating kisses soon involved licking lips with tongues tangling together. Saliva strands stretched and dripped each time Yuu turned his head.

After thorough kissing, Yuu shifted his hips toward the right - Kazumi's buttocks.  
"Kazumi's turn now."  
"Aha! Happy!"  
"Here."  
"Aahn! It's in! Yuu-kun's cock... ah... feels good!"

Though just broken in, Kazumi's vagina still resisted the invading object. Yuu forced his way deep inside.

"Aahn! Still... amazing. Reaching... deep inside."  
"Kuu~. Inside Kazumi, still tight tight. But I can move better than last time. Going all out!"

Yuu began vigorous thrusts. Kazumi's pussy drooled with joy around the longed-for meat rod, making loud guchu guchu sounds. With each deep thrust, Kazumi threw her head back, panting with tongue out.  
"Aahn, ah, ah! Yuu-kun... Yuu-kun! Feels... so good! Iyaaun!"  
"Aahn. Jealous. Hey Yuu-kun! Me soon too."  
Yoko wagged her hips cutely while begging. Yuu stroked her head with his left hand, then trailed down her back to her buttocks, gripping firmly while inserting his middle finger deep into her vagina.  
"Hiiin!"  
"Wait a bit. I'll fuck you when we switch. How about switching after she comes?"  
"Ufu... got it. Judging from Kazumi, we'll switch soon."  
"Ya... I-I'm still fine... ann!"

Pan, pan, pan!  
Each time Yuu slammed his hips, satisfying slaps echoed through the stall.  
"Aahn, aahn, aiin! Coming... not yet... don't wanna come yet... aahn! Already... can't hold baaack!"  
Kazumi cried out, dripping sweat, drool, and love juice while tossed about by the cock piercing her abdomen. Her neatly braided hair had come completely undone from shaking. When Yuu pressed his upper body against hers, groping her breast with his right hand while thrusting deep, then began circular motions.

"Ahii! Shoo... nooo! Aaahhhhhn! Cooomiiiiing!!!"  
Seeing Kazumi arch her body at climax, Yuu immediately pulled his cock out with a nyupon sound.  
"Okay, Yoko's turn now. Rest a bit, Kazumi."  
He lightly patted her buttocks, but Kazumi seemed unable to reply with her face pressed against the door.

After licking his finger soaked up to the knuckle from Yoko's vagina, Yuu smirked and moved slightly left - aligning with Yoko's center.  
"Yoko, sorry to keep you waiting."  
"Aahn... Yuu...kunn~"  
Having felt Kazumi's climax through their connected skin, Yoko turned with flushed face.  
When Yuu pressed his glans against her glistening, twitching slit that seemed to await his cock, it swallowed him smoothly with a nurluri sound. Though her vaginal flesh resisted when the glans was nearly in, Yuu forced through.

"Ahe!? V...viiin! Yu...u...k... wai... ahiiin!"  
"Here... all the way... in!"  
"Aaah, o, ooooh... aae...nn, nfunn..."  
"Nn? What's wrong, Yoko?"  
Upon deep penetration, Yoko had arched her body like Kazumi, both hands clawing the door.  
"Did you come already?"  
"Hah!"  
"She came. Kufufu... switch time."  
Apparently Yoko's sensitive body had unexpectedly experienced a G-spot orgasm during her first time, reaching climax again from that thrust.

"Em...barrassing... suddenly... never knew... heat rushed from deep inside... no time to resist..."  
Blushing crimson, Yoko looked utterly flustered.

"It's fine. Switching now would be cruel. Consider this a bonus round. Think you can last till next time?"  
Yuu began slow thrusts while speaking.  
"Ann, thank you, Yuu-kun... nn, nn, nau! But the pleasure... won't stop! Yaan! Again... about to come!"

Both Yoko and Kazumi squeezed tight at orgasm as if trying to milk his semen, but Yuu lasted thanks to having ejaculated twice already and pulling out for breaks. Continuous thrusting might've made him come sooner. Still, alternating between them built his climax.

"Ah, ahi, hiiin! Iiin! Again... coming! Nooo, Yuu-kun's cock too good... can't hold baaack! Aaan! Shoko... coming, coming!"  
While vigorously fucking Kazumi from behind with both arms wrapped around them, Yuu felt Kazumi's body buckling as she barely supported herself against the door with both hands.

"Guu... I-I'm close... too! For the finish... want to cum in both your mouths!"  
"U, un. Okay, Yuu-kun."  
Though Kazumi seemed spent after just coming, Yoko twisted her body and nodded smiling.  
"Gu! Now!"  
After several final slaps against Kazumi's buttocks, Yuu hastily pulled his cock out.  
Yoko immediately clung to his waist, gripping his cock and sucking the glans. Kazumi turned and latched onto it too. Both girls lovingly sucked the cock while Yuu stroked their heads.  
"Haan... your cock's throbbing... amazing..."  
"Aah, kaha... c-coming..."  
"Juru chupaa... cum, Yuu-kunn..."  
"O, ooh! Cumming!"

Urged by their hands and tongues, semen shot out powerfully. Some entered their waiting open mouths which they swallowed with pak sounds, while the rest splattered across their noses, cheeks, and chins.

"Anmu, Yuu-kun's seeemen... wonderful."  
"Aahn, so thick... lots..."

Though Yuu's third ejaculation, the prolonged activity made it seem extra voluminous. Both girls savored it dreamily.

"Yuu-kun, bus time okay?"  
"Ah, classes having victory parties today, so should be later."  
"Ah, good."

The three walked hand-in-hand through the deserted hallway. Nearing Building 1, faint cheerful voices echoed - probably from ongoing victory parties. Though their class didn't win, for Yoko and Kazumi, the storage room reward and being with Yuu were priceless treasures.

"Okay, heading out."  
They parted ways at the connecting corridor through the courtyard. Yuu would return to Building 2's male classroom.  
"Un. Thank you today."  
"Really... can't thank you enough."  
"Haha. I had wonderful time with both of you too."  
""Yuu-kun!""  
Neither wanted to let go, longing to stay connected. But they knew they couldn't.  
"See you tomorrow or next week at school."  
"Get home safe."  
"Th-then... bye-bye."  
Releasing their hands, Yuu waved and walked toward Building 2.

They watched until he disappeared. Yoko then turned to Kazumi.  
Kazumi met her gaze.

"Nn? What is it Yoko?"  
"We met Yuu-kun during April basketball club visit, got closer through gender exchange events."  
"Un. Same group during Newcomer Welcome Orienteering, and he cheered for us during ball games."  
"Kazumi and I have been together regarding Yuu-kun."  
"Un, together."

Yoko extended her hand.  
"Yoko?"  
"I'm glad we became friends after entering high school. Want to stay friends till graduation."  
"Me... me too!"  
"Fufu. Good. Then let's work together for Yuu-kun too!"  
"Eh?"  
"Probably someone else is most important to Yuu-kun. Rumor says student council president? But among first-years, we're definitely leading, right?"  
"Re...really?"

Though becoming more assertive around Yuu, naturally reserved Kazumi lacked confidence.  
"Definitely."  
In contrast, Yoko radiated confidence.

"Don't need to be number one now. But hope Kazumi and I can stay by Yuu-kun's side till graduation. Don't you think?"  
"Me! Un, want to be near Yuu-kun!"  
Kazumi nodded emphatically.  
"Many girls like Yuu-kun. Competition won't stop. Want to form alliance?"  
"Alliance?"  
"Un. Cooperate regarding Yuu-kun."  
"I see."  
"But no sneaking ahead like earlier, okay?"  
"O-okay, sorry. Next time I'll invite you too."  
"Same here."  
"Un!"

Chatting amiably, they returned to their classroom.

---

### Author's Afterword

The Ball Games Tournament arc ends here.

New guest next chapter!?

### Chapter Translation Notes
- Translated "おっぱい" as "breasts" maintaining explicit terminology
- Preserved Japanese honorifics (-kun) throughout dialogue
- Transliterated sound effects: "ぐっちゅぐっちゅ" → "guchu guchu", "ぷしゃあ" → "pusshaa"
- Translated sexual terms literally: "チンポ" → "cock", "膣" → "vagina", "射精" → "ejaculate"
- Maintained original name order: "Hiyama Yoko", "Aki Kazumi"
- Italicized internal monologues: *(This is concerning.)*
- Used explicit terminology for sexual acts without euphemisms