## 80. Saiei Student Council Invasion! ① ~VISITORS~

On Saturday, the day after the safe conclusion of June's school event—the Ball Games Tournament, which this year featured full male participation for the first time—  

After half-day classes ended and the usual after-school period began at Sairei Academy, perhaps due to the liberated feeling of the approaching weekend, the school building overflowed with restless, buzzing voices.  

However, the atmosphere in the student council room was entirely different, tense with anticipation.  
"I-It's here!"  

The shout came simultaneously with the *bam* of the door being flung open violently by Ishikawa Emi, the second-year student serving as accountant and secretary.  
Normally, Vice President Hanmura Riko would have scolded such rudeness, but she merely heaved a heavy sigh as if acknowledging the inevitable arrival.  

Student Council President Komatsu Sayaka stood and looked out the window.  
The sky, nearing the rainy season, hung heavily overcast, threatening to unleash rain at any moment.  
Though the view was blocked by buildings from the student council room window, Emi had confirmed that two black luxury sedans were already parked in the visitor parking area near the administration building entrance.  
Uniformed girls were emerging one after another from the rear doors opened by black-suited chauffeurs, heading this way.  

Riko stood beside her, looking down outside.  
"Shall we greet them?"  
"Their president has visited before."  
"I see."  
"At the very least, they should understand we're not welcoming them."  
"Fufu. You're so stubborn, Sayaka."  
"Well, wouldn't you be?!"  
"Yes. I know. They came despite knowing they're unwelcome."  

Emi watched the two with an anxious expression from behind.  
"Are they... really that intense? The Saiei Academy student council members..."  
Riko turned and shook her head.  
"No. I believe they're ordinary high school students like us. Though some come from high society or hold extreme ideologies.  
It's been ten years since the co-ed transition caused friction, but as sister schools, we've maintained a proper, if distant, relationship.  
The problem arises when males get involved..."  

As the external relations vice president, Riko had met them last year.  
President Sayaka also seemed to have personal acquaintance but remained silent.  
Both turned their gaze toward the waiting room.  

At that moment, Yuu was in the waiting room.  
Hearing that the sister school's student council was visiting, he'd been curious, but at Sayaka and Riko's request, he was confined to listening from the waiting room.  
Apparently, they didn't want him to meet them—likely due to the negative rumors about Saiei Academy's student council.  

Several minutes later, a calm, mature woman's voice was heard—likely an advance notice of arrival.  
Upon hearing this, Sayaka and the others remained in the student council room, waiting.  

Several more minutes passed, and hushed voices of several girls grew closer.  

"Good day. It's been a while, Sayaka-san."  
"Mhm."  
"And yet... how rude not to greet us despite sending advance notice.  
Do Sairei people not understand manners?"  
"You're the ones barging in uninvited."  

From the waiting room, Yuu heard footsteps and the rustle of people entering.  
About five or six people, perhaps.  
The slightly shrill, sarcastic voice belonged to a Saiei Academy student council member, while the low response came from Sayaka. They must have been personal acquaintances.  
Sounds of chairs being pulled out without permission echoed before anyone could offer seats.  
*They really are pushy*, Yuu thought while eavesdropping.  

"Only three of you?"  
"Ah, two members left last winter due to circumstances. We've been managing with three since."  
"Hmm? What we heard was—"  
"Anyway! Let's begin!"  

Riko seemed to cut off the questioning voice—they might already know about Yuu.  
Sairei side gave brief self-introductions first.  
Then Saiei's turn.  

"I am Mitsuse Rinne, serving as Student Council President of Saiei Academy High School. Pleased to make your acquaintance.  
Though I've met Sayaka-san several times before... and Vice President Hanmura-san? We've met once, I believe?"  
"Yes, that's right."  

Her speech resembled that of a noble lady—Yuu had never heard such aristocratic diction in real life before.  

"你好(Nǐ hǎo). Vice President, third-year Li Wei Hui. Pleased to meet you."  
"Helloo~. Also Vice President, Omori Norika here~. Nice to meet you todaaay~"  

One vice president appeared Chinese from her greeting and name. The other spoke with an oddly drawn-out cadence.  
The accountant and secretary who followed the distinctive president and vice presidents seemed ordinary.  
The president and vice presidents were third-years, the accountant and secretary second-years.  

Just when it seemed over, "Actually, we brought a first-year assisting as next-generation council candidate.  
Since it's a good opportunity."  
Prompted, a chair scraped as someone stood.  
"Hello, My name is Kate Grimwood.  
Yoroshiku onegai shimasu."  

A prim voice introduced herself in English with broken Japanese phrases.  
A foreign exchange student? Or perhaps a naturalized citizen? But as Yuu mentally converted "Kate Grimwood" to alphabet, it felt familiar.  
That was definitely...  

"Another thing—you have a male student in your council, correct?"  
Just when introductions seemed finished, a Saiei member spoke up.  
"Eh... no, he's... just helping temporarily—"  
"Nonsense. We heard he actively participates in gender exchange event meetings too."  
"Who would spread such—"  

Indeed, since April Yuu had joined student council activities, and from May onward attended club representative meetings and event planning committees.  
Sayaka and others had wryly noted attendance rates soared unnaturally since Yuu started attending.  
Since it wasn't secret, anyone could have leaked it externally.  

In the student council room, Sayaka and Riko still tried to dodge the question.  
But if they already knew about Yuu, hiding seemed pointless.  
Yuu didn't want to trouble them either.  

Yuu stood, opened the door, and burst into the gathering.  
"Sorry I'm late!"  
"Ah!"  
"Eh?!"  
"Yuu-kun!"  

Amid everyone's astonishment, only Emi waved happily.  
Unusually, two long tables were arranged side-by-side. Sayaka, Riko, and Emi sat on the far side.  
On the near side, six Saiei student council members occupied two tables—three per table.  
Their summer uniforms resembled Sairei's white sailor outfits with pale purple lines and pink ribbons, but featured one-piece dresses with deeper purple lines and red ribbons.  

"Had some trouble with a report due today... We just started, right?  
Ahem, pleased to meet you. I'm Hirose Yuu, helping with student council since April.  
Nice to meet you!"  

"My!"  
As Yuu bowed, a girl at the far left abruptly stood.  
Facing him directly, she stood nearly as tall as Yuu. Coppery-beige hair cascaded past her shoulders with soft waves, while front sections hung in vertical rolls.  
Her wide double-lidded eyes fixed on him, pink rouge visible on fingers touching her lips.  
Heavy makeup gave her an un-high-school-like sensuality.  
The form-fitting one-piece uniform accentuated her full bust, rounded hips, and cinched waist.  
Dressed in a suit and tight skirt, she'd fit perfectly as an OL in 21st-century business districts.  

After visually devouring Yuu head-to-toe, she glided forward and lifted his chin with glitter-manicured fingers.  
"Hmm... Quite the premium specimen. I'll take him home."  
"Huh?"  

Before Yuu could respond, her hand was slapped away.  
"Ouch!"  
"Yuu-kun, over here."  

Sayaka, appearing beside him, pulled Yuu behind the front table.  
She produced a folding chair, placing Yuu between herself and Riko as if guarding him.  

"That's Saiei Student Council President Mitsuse Rinne-san, Vice Presidents Li Wei Hui-san, Omori Norika-san, and..."  
Riko rapidly introduced them before Saiei could interject.  
Their stares burned at having their self-introduction opportunity stolen.  

"...and first-year Kate Grimwood-san... correct?"  
"Yes."  
While all Saiei members stared intently at Yuu, only Kate looked down, her long blonde hair hiding her face.  
"Um, could you show your face?"  
"Uu..."  

When Yuu casually asked, she stammered.  
Resignedly raising her face and brushing aside hair, one sapphire eye became visible though she averted her gaze.  
Her slightly oval face featured sharp eyes and refined features.  
*Hard to distinguish foreign faces*, Yuu thought, *but this beauty's unforgettable*.  
He mentally dressed her in a red jersey instead of uniform.  

"Aaaaah! Keiko-san?!"  
""Eh?""  
"Keiko? Not Kate?"  
"Yuu-kun, you know her?"  
"Well, we met once... haha"  
Before discussions began, the room fell into minor chaos.  

"So that's why—when some rough delinquents tried to hassle me, she and her friends saved me."  
"I see."  
"Huh."  
"How unusual. For Kate to approach a male voluntarily."  
"No, that time my companions acted on their own..."  

He recounted his solo outing day—when his crossdressing was exposed, chased by a female mob, taken to the Red Scorpions' cafe hideout, and his encounter with four delinquent girls.  
Only the blonde, blue-eyed girl in jersey named Keiko hadn't participated, though she'd given him a motorcycle ride home.  
Yuu heavily edited the story, omitting the truth.  
Kate remained silent, only nodding.  

"I remember asking your name—Kurimori Keiko, right?"  
"Ah... th-that's... well... yes! I gave a fake name out of embarrassment..."  
"Oh? So Kate's your real name. That suits you better."  
When Yuu looked at her, Kate—formerly Keiko—nodded reluctantly.  

"Still, Kate. You actually speak Japanese well, don't you? When did you improve?"  
"No... sonna koto, nai desu"  
"No need to revert to broken Japanese now."  
"Yes."  

Perhaps because they were upperclassmen from her school, Kate acted meek—unlike her Red Scorpions hideout demeanor.  
But when Yuu smiled happily at their reunion, her *hmph* and averted gaze matched that day's attitude.  

"Enough chaos. Let's proceed to today's agenda: our proposal to revive inter-school exchange events."  
"We decline."  

Li Wei Hui spoke—her techno-cut hair neatly parted, uniform hiding any curves, tallest among the six.  
Narrow, fox-like eyes. She hadn't smiled once, her tone blunt.  
Though fluent, her Japanese held a slight accent.  
Riko had seemed coolly intelligent at first meeting, but Saiei's vice president felt mechanically cold.  
Her expression hadn't changed upon seeing Yuu.  

Riko rejected her before she finished.  
The two vice presidents glared coldly.  
*Less sparks flying, more blizzard sweeping through*, Yuu thought.  

"Araaan, scary~"  
Norika interjected teasingly while sweeping back hair.  
Contrasting Wei Hui, she had straight black hair at even length, thin curled bangs revealing her forehead. Heavy makeup emphasized large eyes and mouth.  
To Yuu, she recalled bubble-era disco queens.  

"Hmph."  
Rinne snorted dismissively.  
"Something funny?"  
Now the presidents glared.  

"The exchange revival is a board decision.  
Do you truly believe student council can veto it?  
Well... if you insist on stubbornness despite next year's budget cuts..."  
"......"  

Truthfully, Sayaka and Riko knew refusal was difficult.  
Still, they rejected outright to avoid appearing compliant from the start.  

"About reviving exchanges... what activities did you do before?"  
Emi cut through the tension.  
"According to our records, mainly club exchanges.  
Joint practices, friendly matches for sports clubs, joint exhibitions for cultural clubs.  
Some years featured special events like karuta or karaoke contests for general students."  
"Hee~"  

A Saiei secretary explained while opening a thick file.  
Unlike the vivid president/vice presidents, the accountant and secretary both had semi-long hair—pretty girls who'd stand out ordinarily but seemed plain beside the other three.  

*Clap clap*. Rinne struck her hands together.  
"But repeating pre-2010 activities would be dull.  
Hence we propose gathering talented students from across the prefecture for a glorious arts festival!  
This will surely become a historic event!"  

Eyes shining, Rinne gestured like a conductor. Oddly, other council members seemed unenthusiastic.  
*Just her personal passion project?*  
As Yuu listened, Riko leaned over and whispered:  

"Nikkō Group—a major corporate alliance centered on Nikkō Automobile, one of Japan's top automakers. Originally a zaibatsu founded by former nobility. She's direct descendant of the founding family.  
Automotive industry rivals to Sayaka's company.  
Nikkō actively sponsors orchestras, theaters, etc., so she's famously knowledgeable about music/drama."  
"I-I see..."  

Historical nobility often protected arts—her family maintained that tendency.  
Fitting for Saiei Academy's student council president, where half the students were in arts courses.  

"Setting aside our dreamer president's whims."  
"Yes. Let's discuss reality."  
"Cruel!"  
Biting her handkerchief, Rinne seemed genuinely hurt. To Yuu, it felt like comedy.  

"During our discussions, we concluded competitions would be more engaging than mere exchanges."  
Wei Hui took over while Rinne muttered about art.  

"Competitions? Like inter-school tournaments?"  
"Exactly."  
"Even competing seems..."  

Sairei's reaction remained tepid.  
Prioritizing gender exchange events, they wanted to avoid extra work.  
But Wei Hui seemed prepared.  
Her attempted smile only narrowed her eyes further, looking frightening.  

"Since it's a competition, the winner deserves rewards."  
"Well, naturally."  
"We propose: If Sairei wins, Saiei grants facility access to Sairei clubs."  
""Eh!?""  

Sairei's three members gasped in unison.  
"Is that possible?"  
"Of course. We'd need to adjust periods/times/scope, but sports facilities have ample capacity."  
"But weee~ have inactive sports clubs compared to cultural ones~. Some exist in name only~, scrambling for members only during inspections/tournaments~"  

Her drawn-out tone and wriggling gestures made it seem trivial to Yuu.  
Though better equipped than public schools, Sairei's active sports clubs craved more facilities.  
Baseball/softball/soccer/track/rugby teams shared three fields.  
Fields #1-2 were manageable, but #3 had limitations.  
Even with travel time to neighboring Saiei, access to spacious practice areas was valuable.  

"The offer itself is attractive and worth considering.  
What would Saiei gain upon winning?"  
"Naturally, inviting the male to our school. Nothing else."  

Wei Hui stated it matter-of-factly.  
As if expecting this, Sayaka, Riko, and Emi's expressions hardened.  

---

### Author's Afterword

Saiei President Rinne: Fashion leader who enjoys arts/culture rather than sheltered heiress.  
Vice President Li Wei Hui: Ruthless strategist.  
Vice President Norika: Sexy bubble-era one-length bodikon big sister.  
That's how I summarized them.  

I hadn't revealed Red Scorpions leader Keiko (Kate)'s school name for this awaited reunion.  

  

2019/6/16  
Corrected Li Wei Hui's greeting per typo report:  
您好(Nǐ hǎo) → 你好(Nǐ hǎo)  

While ニーハオ is understood in Japan, listening confirmed it sounded like ニーハウ.  
Since it's a Chinese greeting, the correct pronunciation felt more appropriate.  
Though the reporter noted Taiwanese usage, manual correction avoided including comments.  
Thank you. I express gratitude here.  

Typo reports are invaluable, but please avoid including comments as they get applied directly to text. Use the comments section for remarks.

### Chapter Translation Notes
- Translated "彩麗学園" as "Saiei Academy" per Fixed Special Terms
- Preserved Japanese honorifics (-san) and name order (e.g., Hirose Yuu)
- Transliterated sound effects (e.g., *bam* for バタン)
- Maintained explicit terminology for sexual references (e.g., "crossdressing")
- Formatted simultaneous dialogue with double quotes (""Eh?"")
- Italicized internal monologues per style guidelines
- Translated cultural terms literally with context (e.g., "OL" for office lady)
- Corrected Chinese greeting to "你好(Nǐ hǎo)" per author's note