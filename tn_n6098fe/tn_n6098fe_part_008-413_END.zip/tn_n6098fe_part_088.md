## 81. Saiei Student Council Invasion! ② ~Let's Do Our Best~

First came Sairei's side's firm rejection - an absolute refusal to accept the proposal.

Saiei's council didn't back down either.

They argued: "It's unfair for Sairei to monopolize boys just because you're co-ed. As sister schools, reviving past exchanges to give our students male interaction opportunities shouldn't be punishable."

To Sairei, this sounded like arbitrary, forceful reasoning.

The heated debate continued - a true war of words - until Kate, who'd remained silent, finally spoke up.

"What does the boy here think?"

Her cold blue eyes fixed intently on Yuu.

"Hmm..."

As the only male present, Yuu felt like a representative for all boys. That thought made him ponder.

An all-girls school - a garden of women. As a man with his original world's values, he absolutely wanted to visit such a place. But he knew he was the only boy in this world who'd think that way. Ordinary boys were timid as herbivores around the overwhelmingly female majority.

"Well, even if you invited them now, practically no boys would go."

"Huh? But... Sairei holds co-ed events, right? Then occasionally-"

"That's only possible because Sairei has spent ten years co-ed, experimenting through trial and error."

Yuu had heard from Sayaka and others about how seniors had carefully planned events considering boys' needs. He passionately explained this.

"Though I'm new to the student council, I've seen with my own eyes how not just the council but female seniors and classmates have been considerate. Ignoring that daily effort and suddenly wanting to 'get along with boys' is unreasonable!"

""Yuu-kun!""

Sayaka and the other two Sairei council members gazed at him with sparkling eyes, making him feel embarrassed.

The Saiei council members fell silent at this, until Rinne stood up with a bang.

"Then! We'll appeal to Sairei's boys through our school's specialty - the splendor of art!"

The vice presidents looked exasperated, but surprisingly, Yuu expressed agreement.

"Hmm... That... might actually work?"

""""Wha... WHAAAAAT?!""

Even Rinne herself looked stunned.

"Actually, quite a few boys are interested in art and cultural activities."

Yuu recalled Masaya, who'd learned piano since childhood and now belonged to the brass band, and Rei who practiced flower arrangement and tea ceremony. Many classmates had also joined cultural clubs after entering high school.

"Unlike us, Saiei specializes in arts and culture, right? If you effectively showcase that to spark interest while guaranteeing safety, some boys might consider visiting."

"My! How wonderful!"

Rinne beamed radiantly, suddenly hiking up her skirt and vaulting over the table. She dashed toward Yuu and grabbed his hands. Her long copper-beige hair swayed, tickling his nostrils with floral perfume.

"How about it? Join us for dinner tonight-"

"No touching allowed."

"Ow! Jeez..."

Riko slapped Rinne's wrist away with a crisp sound, forcibly separating them.

***

A provisional agreement was reached: If Sairei won, they'd gain limited usage rights to Saiei's facilities (especially sports-related). If Saiei won, they'd get an opportunity to promote themselves and invite boys to their summer presentation. Actual attendance would depend on the appeal's effectiveness. Details would be finalized later.

Next, discussions deadlocked again over what form the inter-school competition should take. Sairei advocated sports club matches while Saiei insisted on cultural club presentations. When someone suggested doing all clubs, questions arose about judging cultural presentations. Saiei proposed bringing in specialists, but Sairei objected that Saiei-connected experts would lack fairness.

As the heated debate showed no signs of resolution, Yuu pushed back his chair.

"I'll make some tea."

As he rounded the table-

"I'll help too."

Kate, who hadn't participated in the debate, also stood.

"Ah, thanks. This way."

Though she avoided eye contact, Yuu felt grateful for her offer and led her to the water heater room.

"Thanks for earlier."

"Huh? Oh."

While waiting for the kettle to boil, Kate spoke softly, barely audible. She was likely thanking him for covering up their Red Scorpions encounter with a fabricated story.

"I couldn't be completely honest either. We're even."

"Heh. True."

"But still... I'm shocked. Never imagined you'd be in Saiei's student council."

When Yuu glanced back, Kate averted her eyes.

"Same here. Never thought you'd be in the council."

"Haha. Well, circumstances."

As the kettle neared boiling, Yuu took cups and teapots from the cupboard. Kate came beside him to help.

"You're quite practiced."

"Been a year. We're short-staffed originally."

"Hmm. You're... different somehow."

"Yeah, I get that a lot."

Scratching his head, Yuu looked at Kate beside him. Unlike Saira's near-white blonde, Kate's hair was a brilliant gold blonde. Her back-length hair appeared straight at first glance but had slight waves at the ends. Her height was similar to Yuu's, and her dress-style uniform revealed her assertive figure more clearly than the red jersey he'd seen before - unavoidably drawing his eye.

"Something wrong?"

Noticing his gaze, she glared back.

"Just admiring your beautiful hair. And how well the uniform suits you."

"Hah... To say that so boldly to my face, you sound like a womanizer. Same name but... never mind."

"Same name...? Wait, you're talking normally today?"

"Wh-! I-I have no intention of getting familiar with boys!"

Just when he thought they were conversing normally, Kate reverted to her prickly attitude. Her dislike of men seemed unchanged. To Yuu, she was fascinating precisely because she was different - and beautiful.

***

When they returned with tea, the competition format remained undecided. After an hour-long debate, everyone welcomed the drinks thirstily. Yuu served sliced yokan he'd bought, and the meeting entered recess.

During the break, Riko and Emi explained that since club competitions were deadlocked, alternative proposals had been suggested: Mixed martial arts, giant dominoes, Miss Contest (with cosplay), karuta tournament, karaoke contest... etc. Many ideas surfaced but none seemed decisive.

Yuu organized requirements on a whiteboard while hearing from Sayaka and Rinne:

- Accessible to many students
- Not biased toward either school's specialty
- Decisive wins for individuals/teams
- Use Sairei's grounds/gymnasium to include boys
- Budget from both schools within student event limits
- Held after July finals, preferably after summer break starts

He also listed previous proposals. Yuu found the Miss Contest (with cosplay) interesting but wondered about boys' roles - would they be judges or participants?

As Yuu reread the whiteboard, he felt intense stares. Rinne, Sayaka, and most council members watched him intently while sipping tea primly. Only Kate at the end nibbled yokan - oddly picturesque for a Westerner.

"Don't you think mixed martial arts is best?"  
"Miss Contest is clearly superior!"

Sayaka and Rinne spoke simultaneously, glaring at each other.

"How barbaric."  
"If boys are judges in Miss Contest, Sairei would have an unfair advantage."  
"Guh..."

*They're the ones who suggested it*, Yuu thought privately. Given the forced nature of today's meeting, even normally calm Sayaka might be pushing unreasonable opinions.

"Yuu-kun, got any good ideas?"

Asked by Emi's expectant smile, Yuu pondered again. An inter-high competition... accessible regardless of skills...

An idea surfaced from Yuu's pre-reincarnation memories.

"How about... a quiz?"

""""A quiz?!""

"See... Participants form teams of three. Start with yes/no preliminaries. Main rounds have block competitions between groups, with winners advancing to finals. From main rounds, we can use multiple-choice, buzzer quizzes, timed one-minute rounds - get creative."

Yuu envisioned the "National High School Quiz Championship" broadcast every summer.

"How about question sources?"  
"Each school collects submissions, then the other school screens them for suitability. Ideally covering science, politics, history, sports, entertainment, trivia, etc. Shuffle them randomly before the event."

"I see~"  
"Hmm. Possibly good."

Saiei's reaction was positive. Vice President Wei Hui smiled - though her predator-like expression was slightly frightening.

***

Discussions continued, but Yuu's quiz proposal was ultimately adopted. A tentative date was set for July 27th. They'd coordinate schedules via phone/fax, holding another Saturday afternoon meeting in July.

Since Sairei had more students, they'd hold preliminaries first. For the main event, 100 teams (300 students) per school would compete - including Sairei's boys.

Two hours had passed since the meeting started. The latter half had progressed smoothly compared to the contentious beginning. Though initially resistant, Sairei now actively participated, committed to giving their all.

After adjourning, the Sairei council saw their guests out.

"Well then."  
"Yes. Today was most productive. Farewell, Sairei members."

Suddenly, soft mounds pressed against Yuu's arms. The left felt comparable to Sayaka's, the right was larger.

"Hey wait!"  
"Could you not casually try to take him?"  
"Don't take Yuu-kun!"

Rinne had grabbed Yuu's left arm, Vice President Norika his right.

"My? I've taken a liking to his appearance and personality - I wish to know him better."  
"We won't allow that."

Sayaka's intimidating approach made even Rinne release him.  
"My, scary. Just a joke."  
"When you say it, it doesn't sound like one."  
"My, whatever do you mean?"

Tilting her head in genuine confusion, Rinne suddenly smiled and firmly shook Yuu's hand.  
"I look forward to meeting again, Yuu-san."  
"Yeah, go easy on me."

As Saiei's council departed toward their parked cars, Sayaka and the others sighed in relief with tired smiles.

***

In one car carrying the president and vice presidents, Rinne's previously cheerful expression turned cold as she contemplated something.

"Norika."  
"Yes?"  
"Upon return, immediately contact the 'External Investigation Unit'."  
"That boy from earlier~"  
"I must have him."

Rinne examined her manicured nails, seemingly recalling Yuu's physical presence.

"From touching him, he seems reasonably fit."  
"With those tight jeans, his bulge was quite noticeable. Probably well-endowed. Hehe."  
"Fufufu. I wonder what sounds he'd make in bed..."

Rinne chuckled softly, elegantly crossing her legs before tightening her smile and turning to Norika.

"Address, family structure, parents' workplaces of course - down to hobbies, dating history. Leave nothing uncovered. Understood?"  
"Of couuurse~"

Though Norika's drawl remained, her eyes weren't smiling. Wei Hui alone gazed out the window indifferently.

***

Back in the student council room, Sayaka and Riko looked grim.

"July was already busy enough..."  
"Ugh... This is burdensome."  
"Speaking of July events...?"  
"The school camp. Last year was late July."

Sairei Academy had few off-campus events besides orientation and school trips - part of male protection measures. Even camp used school grounds instead of riverside sites. Despite the location, cooking together in the lodge and campfires made it enjoyable.

"Then why not hold them on the same day?"  
"Same day?"

Sayaka and Riko pondered Yuu's suggestion.  
"Preparation workload won't change, and it'll be dawn-to-dusk on the day... but cleanup would be once."  
"Possible... but if Saiei finds out, trouble."  
"We'll maintain absolute secrecy."  
"And set strict return times."

They tentatively decided to discuss combining the Saiei competition with July's co-ed event.

"Phew. Anyway, we were saved by Yuu-kun today. We'd never have reached agreement alone."  
"Hehe. Truly. So glad Yuu-kun was here."

Sayaka and Riko pressed close on either side.  
"Yuu-kun!"

Emi hugged him from behind. Yuu played with her twin-tail strands.

"Glad to be helpful. But wow... they were intense."  
"I think they were holding back today."  
"Really? Even at that level..."

Sayaka lifted her face from Yuu's shoulder, her serious, worried eyes meeting his.

"With our students, I wouldn't worry no matter how close you get. We've educated them since enrollment with 'be ladylike toward boys' as our motto."  
"Ah... true."

Sairei girls always smiled warmly. Though showing interest, they never forced themselves on boys, maintaining proper distance. Even shy first-year boys gradually grew comfortable - thanks to co-ed education.

"But Saiei's different. They don't respect boys. So... reviving exchanges might cause problems."

Riko clung tightly to Yuu's arm.  
"Riko-senpai..."

"And their president was clearly targeting Yuu-kun!"  
Emi pouted while stroking Yuu's head.  
"Rinne wouldn't commit crimes given her position, but rumors say she cycles through men. If she targets Yuu-kun, she'll persistently pursue him."

Though Sayaka looked concerned, Yuu felt more distracted by their sweet scents and warmth.

"Now that it's started, we must commit. Besides, with you three here, I don't feel anxious at all."  
""Yuu-kun""

"Today's long meeting tired us out. How about relaxing in the lounge?"  
"Is... time okay?"

Riko blushed slightly at "lounge," her upward glance adorable enough to make Yuu smile. Checking the clock, he nodded.

"Still time. So..."

Still sandwiched between them, Yuu slowly stood. After kissing each in turn, they pressed closer. The four moved toward the lounge in a tangled cluster.

***

---

### Author's Afterword

Though Saiei's student council finally appeared, their return will be after an interval.

2019/8/3  
Changed "Investigation Department" to "External Investigation Unit" to match Interlude 3.

### Chapter Translation Notes
- Translated "侃侃諤諤" as "war of words" to convey intense debate atmosphere
- Rendered "草食動物のように臆病" as "timid as herbivores" to maintain animal metaphor
- Translated "高校生クイズ" as "National High School Quiz Championship" for cultural context
- Preserved Japanese honorifics (-san for Yuu, -kun for classmates)
- Transliterated sound effects (e.g., "ban" for ばんっと, "guh" for ぐっ)
- Maintained explicit anatomical terms ("bulge" for 股間が盛り上がっている)
- Used gender-neutral "they" for singular references to Kate during internal monologue