## 82. Saiei Student Council Invasion! ③ ~LOVE LOVE LOVE~

"Uuun, whenever I see Yuu-kun's cock, it's so thick and strong~ Just holding and licking it like this makes me wet! Anmuh... chuparelochu~"

"Ufufu, it's so rugged and throbbing like this. And... haa~, so hot... nchu, chu, leroo"

In front of Yuu, Riko and Emi were caressing his erect cock with hands and mouths from both sides. Yuu had long since had his pants and underwear removed. Emi not only took the glans fully into her mouth but also moved her tongue inside, licking lewdly with rorelero sounds. One hand stroked Yuu's stomach while the other gently massaged his scrotum. Riko stroked the shaft shiko shiko from the base while running her lips and tongue along it.

Emi clearly took the lead in fellatio enthusiasm. Though Riko had initially lacked any technique, her earnest nature seemed to have helped her improve considerably. Perhaps their shared love for Yuu's cock was the secret to their progress.

Meanwhile, Yuu was enthusiastically sucking while kneading Sayaka's breasts as she hugged him from the side. Sayaka's beautiful breasts—perfect in size and shape—were such exquisite firm mounds that he wanted to knead and suck them forever.

Whenever Yuu found himself alone with Sayaka in the student council room, he'd end up groping over her uniform when they hugged. Though Sayaka would lightly scold him at first, once his fingertips reached her nipples, she'd let out sweet moans—her sensitivity was delightful too.

"Kwaaaa... ann! Really... Yuu truly loves breasts, doesn't he? Looking at us like this, it's like you're a big baby... nn, kufuu..."

"I love Sayaka's breasts. But you're feeling good too, right?"

"U, uu... y-yes, it feels good... aaan!"

Sayaka cradled Yuu's head affectionately. By now, when these four had sex, they'd dropped formalities and used first names without honorifics. Only Emi still preferred calling him "Yuu-kun" and showed no intention of changing. Yuu rolled the nipple in his mouth with his tongue, lightly pinching it with his lips. His other hand kneaded the voluminous breast that overflowed his palm before sliding downward.

The girls had already removed their skirts and panties. Sayaka had unbuttoned her sailor uniform and pushed her unhooked bra upward. Thus Yuu's hand easily found its way from Sayaka's toned abdomen through her pubic mound to her glistening wet slit. When he parted her labia with two fingers and stroked the center with his middle finger, love juice immediately clung to his finger. As he inserted his fingertip into her vaginal opening and moved it with bent knuckles, lewd kuchu kuchu sounds emerged.

"Ah... aah! Th-there... Yuu!"

"Sayaka's pussy is already this wet, huh?"

"B-because... Yu... uuuu"

With a pained expression, Sayaka lowered her head seeking Yuu's kiss. Since the kneeling Sayaka was looking down at him, when she lowered her head, Yuu's face was enveloped in her lustrous black hair—a blissful sensation in itself. Stimulated by Yuu's attentive caresses, Sayaka passionately pressed her lips against his.

"Nn... chu, chumu... nn, nfu... amu... rorechupa... haa, haa, Yuu!"  
"Aah... Sayaka!"

As Yuu licked the saliva from Sayaka's slightly parted lips, his excitement grew, and his fingers at her vaginal opening moved faster. When he inserted his middle finger deep into her vagina and moved it, the sounds became thick, sticky nucchu nucchu noises.

"Yaaah... Yu, Yuu! If you move any more...!"  
"What happens if I move more?"  
"Yuu, you tease... nnn~~~! Ah, ann! N-nooo... stooop!"

While Yuu tormented Sayaka, Riko—unable to hold back any longer—tried climbing onto him. "Aaan. I want Yuu-kun's cock too..."  
"Nfu. Wait your turn."  
Ignoring Emi who was watching while sucking her finger, Riko eagerly straddled him, spreading her own slit to swallow his cock. Having fingered herself while giving oral, she was already fully prepared.

When the three had sex, they took turns in rotation. Last time—though it had been over a week due to ball game preparations—Sayaka had gone first, so today Riko was first. The order Sayaka → Riko → Emi was strictly observed.

"Yuu... nfuu... I-I'm putting it in now."  
Rubbing the hardened cock against her lower abdomen like grinding, Riko whispered sweetly. Yuu turned from Sayaka to face Riko. With glasses removed and cheeks flushed pink, Riko was fully in heat—a female expression her usual sharp self would never show others.

"Riko's riding me today?"  
"Un... I think I've gotten a little better at it. So... let's... cum together?"  
"I love that look on Riko's face—so erotically cute. Here, lick this first."  
"Aha"

What Yuu offered was the middle finger that had just been pistoning in and out of Sayaka's pussy. Not just between the fingers, but his entire palm was coated in transparent fluid.

"Nfu... leroo... afu... delicious. Nmu, nn, juru churu churu rore chupaa"  
While slowly moving her hips, Riko enthusiastically licked Yuu's finger. She caught droplets about to fall from his fingertip with her extended red tongue, taking them into her mouth. After swallowing to savor Sayaka's flavor, she kissed and sucked Yuu's finger from top to bottom, meticulously licking between them. Then she opened her mouth wide and began sucking his finger like giving a blowjob.

*(So incredibly... erotic)*  
The sight of this beautiful senior lewdly licking his fingers was arousing. Meanwhile, Emi—now free-handed—hugged him from the right.

"Yuu-kun!"  
"Emmy!"

Their nth kiss since entering the room began with tongue tips meeting and tangling from the start. Yuu's left hand had been holding Sayaka's waist but now probed toward her vaginal opening from her buttocks. Unable to endure, Sayaka clung to Yuu, planting passionate kisses on his shoulders and neck.

"Enough! I can't wait any longer!"

Yuu shifted his hips slightly to align with Riko's entrance.  
"Nfue? Yuu!?"  
Riko—still diligently sucking his finger with chupa chupa sounds—was startled. Yuu had initiated penetration.

"Because you teased me, Riko."  
"Th-that's not what I... aun!"  
"I want Riko so badly... guh"  
"Yu, Yuu... nn... aaan!"

When they connected deep inside through their joint efforts, both let out involuntary moans of pleasure.

"Hah, it's in... ah, good... so good! Yuu!"  
"Riko! Feels amazing... feels even better... u, move!"  
"Unn! Yuu, Yuu's cock... hitting my deepest... ah, ah, aah! S-so, so good! Ann! So gooood!"

Riko desperately rocked her hips while firmly gripping Yuu's shoulders. With each thrust, guchu, guchuu sounds leaked from their joined parts. Though usually intellectual, she'd now transformed into a female completely dominated by pleasure—a creature simply craving her male.

The other two also grew bolder in claiming Yuu. Sayaka—having her pussy played with again—moaned while covering Yuu's mouth with a passionate kiss. Emi licked and sucked from his neck to collarbone. Yuu too used both hands to stroke and savor Sayaka and Emi's bodies. The foursome's banquet had only just begun.

***

After bringing Riko to climax several times and flooding her womb with copious semen, she collapsed limply. Before he could check on Riko, Emi—next in line—clung to him.

"Yuu-kun, hurry, give it to me!"  
"Haha, okay okay."

Yuu smiled wryly at Emmy rubbing her lower abdomen against him and pushed down her slender body with both hands. Understanding that Yuu usually took missionary position—called "male superior position" in this world—when with the three student council members, Emi spread her legs with a mischievous smile, waiting for him.

"Fufu"  
Just as Yuu brought his hips close for insertion, Sayaka hugged him from behind. Yuu felt her plump breasts press mushily against his sweaty back—he'd removed his T-shirt.

"I'll help you"  
"Haha..."

Feeling Sayaka's breath near his ear, Yuu leaned forward. Sayaka's hands gently guided his cock from behind as he lowered his upper body. In this slightly angled position, Yuu gazed at Emi—one hand on her slender waist, the other holding her outstretched hand—aligning only his cock's angle. Just the tip touching revealed how soaking wet Emi was.

"Even though it's slippery... it's so hard and... hot"  
"Fufu, I'll put it in Sayaka too later"  
"Aan, enough. Right now I want you pounding deep inside me!"  
"Ah, sorry sorry. I'll put it in Emmy now. Is it okay if I go hard suddenly?"  
"Un. Do whatever Yuu-kun wants to me!"

Guided by Sayaka's hands, Yuu's cock slid into Emi. Though Emi's pussy—the smallest among the three—felt tight, perhaps because she was already broken in, it firmly accepted his cock, squeezing kyu kyu tight.

"Gyaaaah! Ah, aah... Yuu-kun is... going in! Haaan! I wanted this so baaad... gyaaaah! Deeep!"  
"Kufuu... all the way in! Here I go, Emmy!"  
"Kyan!"

Even after penetration, Sayaka remained hugging him from behind. Though movement was somewhat restricted, not enough to stop him. Rather, with the wildly thrashing Emi before him and Sayaka's warmth behind, Yuu's excitement only intensified. So he immediately began thrusting vigorously into Emi.

"Hyaaan! Yu, Yuu-kun! Ah, ann! So, so intense... hahi, hahi... I-I'm cumming... don't... ann! Stop, I'm cumming... gyaaah! Gah, cumming uuuuuuuuuu!!!"  
"Haha, already came? But we're not done yet?"  
"Aaan... Yuu-kuuun..."

Emmy pulled herself up by his hand and kissed her beloved Yuu. After pressing their lips together with a butchu sound, they tangled tongues rore rore while Yuu kept thrusting. When he knocked against her descending cervix, Emi inevitably arched back and moaned. As she shook her head side to side as if refusing, her flaxen twin tails swung wildly. Her second climax seemed imminent.

***

"Fufufu. Being third means a painful wait, but having Yuu all to myself like this is delightful. Still... even after ejaculating twice... it's unbelievable how... that thing... strong it is."

Sayaka placed her hands on Yuu's shoulders as he sat cross-legged, slowly lowering her hips. Her other hand reached toward Yuu's crotch, touching the still-erect cock that had ejaculated twice already.

Emi—thoroughly filled with Yuu's semen after multiple climaxes—lay beside Riko, unable to rise. Watching them, Yuu and Sayaka now prepared to connect. With his face buried between Sayaka's ample breasts, savoring their softness and sweet scent, Yuu lifted his face slightly to look at her.

"Because I love Riko, Emmy, and Sayaka so much. Even now, I can't wait to connect with Sayaka and ejaculate deep inside."  
"Ah..."

The glans kissed her vaginal entrance with a kuchuri splash. Guided by Sayaka's weight, the cock slowly sank into her. Meeting Yuu's gaze, a hot surge welled in Sayaka's chest—she reflexively cradled his head. It was maternal instinct, protective desire for a younger male, gratitude and respect for the man who taught her heartwarming intimacy and sexual pleasure—all at once. The complex emotions swirling in Sayaka's heart could be expressed in just two syllables.

"Su ki" (I love you)

"*Nnn!*"  
Their lips sealed together deeply, deeply as they connected. "Nn... nna... a, a, aaaaaaaaah!" Sayaka threw her head back with a long moan, her lustrous black hair swaying dramatically. Simultaneously, she hugged Yuu tightly, her pressed breasts mushing into new shapes.

"Sa, Sayaka...!"  
"Yu... Yuu! Haaaaaaan..."  
"Could it be?"  
"No!"

Sayaka hugged Yuu's face as if enveloping it, heat transferring from her pressed cheek. Though shadowed by her long hair, Yuu could imagine Sayaka's snow-white cheeks blushing lantern-red.

"You came just from insertion?"  
"Enough, Yuu!"

Sayaka rubbed her forehead against him to hide embarrassment. Yuu combed back the hair falling over her face, gazing at her up close. Sayaka immediately brought her lips closer. Chu, chu—they kissed repeatedly.

"I... my heart and body... seem completely drowned in Yuu..."  
"Same here"  
"R-really?"  
"Un, yes. See?"  
"Ann!"

When Yuu thrust upward, Sayaka's body jolted. "Even though I just came... I can't stand wanting more Yuu. Feeling like this... I never imagined..."  
"I want to feel even better with Sayaka too"  
"U, ah! So much... ann! Yuu!"  
"Aah! Sayaka... squeezing so tight..."

Though their movements were small due to full-body contact, each thrust of his hard cock knocking deep inside made every vaginal fold cling and milk him desperately.

"Ah, ah, Sa... yaka!"  
"Yu... Yuu! Guh ah... cumming again! Yuu, Yuuuu... hah, hyiin! I-I'm cumming! Cumming cumming cumming!"  
Desperately rocking her hips while watching Sayaka panting with tongue out, Yuu found her utterly debauched expression endearing. He stroked her lustrous, silky hair and licked the sweat beading on her jade-like skin.

"Guh... I-I'm...!"  
"Yu, Yuu... close too... kaan! Swelling inside!"  
"G-going to... ejaculate! Inside Sayaka... everything!"  
"Aah, give it to me! Yuu's... aaaaaah! Me too... together!"

Feeling climax approach, they pressed cheeks even tighter, hugging fiercely while slamming hips together. With each upward thrust, Yuu felt a numbing sensation run from waist to back unlike anything before when he finally plunged deep.

"Gah, Sa, Sayaka! Cumming!"  
"Yu... guh! Coming! Something amazing... gyaaaaah! Ooh! Shooting out! Aful... me too... cumming uuuuuuuu!!!"

Feeling hot semen flood her womb, Sayaka experienced her strongest climax of the day. The shock was so intense she forgot to think, consciousness fading.

Catching Sayaka as her head lolled forward, Yuu sighed in relief. Over Sayaka's shoulder, he saw Riko and Emi smiling at him while lying down.

"It always feels so good with Yuu-kun that I cum multiple times, but today was especially amazing..."  
"I have to agree. Honestly, Yuu overturned all my assumptions about males."  
"But that's because Yuu-kun is special, right?"  
"Uun... probably. Meaning I couldn't do this with any other boy."  
"Me too! I can only think about Yuu-kun!"

Hearing such conversation while being watched made him oddly embarrassed. But for Yuu too—including Sayaka, his first partner—Riko and Emi were special because they shared so much time together. That hadn't changed even after experiencing sex with many others.  


### Chapter Translation Notes
- Translated "おチンポ" as "cock" following explicit terminology requirement
- Preserved Japanese nicknames: "ゆーくん" → "Yuu-kun", "エイミー" → "Emmy"
- Transliterated sound effects: "ちゅぱれろちゅ" → "chuparelochu", "ぐっしょり" → "soaking wet"
- Rendered sexual acts without euphemisms: "挿入" → "penetration", "射精" → "ejaculation"
- Maintained original name order: "清華" → "Sayaka", "莉子" → "Riko", "栄美" → "Emi"
- Italicized internal monologue: "（すっごい…エロいなぁ）" → "*(So incredibly... erotic)*"
- Used gender-neutral "they" when plural subjects shared actions
- Translated "男性上位" as "male superior position" to preserve cultural context
- Kept intimate dialogue in single paragraphs when attributions connected speeches