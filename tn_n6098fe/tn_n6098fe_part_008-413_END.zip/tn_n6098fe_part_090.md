## 83. Requesting the Protection Officers ~Touch~

When Kanako returned and opened the door from the entrance to the common area, she involuntarily gaped in astonishment at the sight before her.

Touko was perched neatly before Yuu, who sat deep in his office chair.

Only because of Touko's petite stature was this possible, but it was a situation that normally wouldn't occur without an extremely close relationship.

"Wh-what are you doing!?"  
"Tch, she's back already."

Kanako's sharp ears caught Touko's soft mutter, causing her to furrow her brow. Yuu remained oblivious as he focused on Touko's head, only noticing Kanako after a while and smiling while still holding a brush.

"Welcome back, Kanako-san.  
Touko-san doesn't seem to take good care of her hair, so I was helping her."  
"Haaah..."  
"Touko-san has good hair quality, so she should take better care of it."  
"It's bothersome. But... i-if Yuu-sama does it for me..."  
"Wh-what are you saying?"

Before Kanako could interject, Yuu responded.  
"Guess I can't help it. You always take care of me, so this much is fine.  
But you're a girl, so try to do it yourself as much as possible."  
"I'll consider it positively."  
"Hahaha. Please do. There, all pretty now."

Yuu had brought out the hairbrush and some styling products that his mother and sister used. He'd first wet Touko's hair in the washroom, brushed it while blow-drying, then moved here for the finishing touches. Rather than the traditional bob cut, she'd look better with a modern hairstyle from a salon, but Touko was rather lazy and didn't bother with appearances. Still, her facial features were quite cute when observed closely. He swept the voluminous sides backward and appropriately tousled the previously messy bangs. Though it still resembled an 80s idol style from Yuu's memory, she looked cuter than usual.

Yuu noticed the heavily laden shopping bags in Kanako's hands.  
"Did you go shopping since Kanako-san was unusually absent?"  
"No, this is..."

The on-duty protection officer couldn't be away for long. So she regularly had company staff do the shopping, which Kanako received in the underground parking area. She'd also received documents from the company during this absence of about 10-15 minutes. Coincidentally, Yuu had arrived just as Kanako left and had been tending to Touko's hair.

Since his sister Elena had been holed up in her room, Yuu had frequently visited the protection officers' room. Though Kanako and Touko were initially flustered when Yuu started hanging around, they now welcomed him warmly. Yuu was delighted to have heard their personal stories during their chats.

Kanako had a brother one year younger than Yuu, and despite the age gap, they apparently got along well. However, he'd entered a boys' school dormitory last year, leaving her feeling lonely. Indeed, a photo of them together was displayed on Kanako's desk.

Touko's father was unusually amorous for a man in this world, having taken seven wives. Touko herself was the child of the sixth wife and the third youngest of thirteen siblings. They lived in an impressive mansion as a large, lively family, though Yuu wondered how Touko lived among them.

The space was more compact than the Hirose family's living area, about 2DK size. The slightly smaller kitchen than the Hiroses' had a toilet and bath, with private rooms for each officer in the back. Yuu and the others were now in the approximately 12-tatami dining room. Dull gray carpet covered the floor, with a long desk for about three people and three office chairs. The plain white walls held a calendar along with several posted papers like local maps and schedules. The shelf against the wall was a plain steel type like those found in offices. The desk held document cases, a word processor, and a fax-equipped phone, creating a small office-like atmosphere.

Yuu and Martina usually handled weekend dinners, but today Yuu had informed them he'd be late due to student council matters, so Martina offered to buy food on her way home. After the meeting with Saiei Academy and enjoying a foursome with the student council trio, Yuu returned home around 6 PM. When Martina wasn't home, Elena usually clung to him, but with it being Saturday, Saira had also come from the company dormitory. Contrary to her fairy-like delicate appearance, Saira was unreserved. She restrained herself somewhat in Martina's presence but seized opportunities to demand kisses, slip hands under clothes to caress his body, get carried away and touch his dick, and even sneak into bed with her lower half exposed - acting like a complete pervert. Of course, most boys would flee, but Yuu openly reciprocated, which inevitably pleased Saira.

Feeling particularly tired today, Yuu had come to the protection officers' room immediately after dropping his bags at home. He had business with them.

"Well, since Kanako-san is back, may I talk?"  
Patting the small shoulder before him, Touko stood up. Glancing back, Touko wore a somewhat reluctant expression.

"Th-thank you, Yuu-sama."  
"You're welcome."

Yuu sat on the two-seater sofa for guests opposite the shelf, facing Kanako and Touko who had taken their own seats.

"Today I came to ask a favor from both of you."  
"A favor, you say?"  
"Yes. Straight to the point - I want you to teach me self-defense."  
"Eeeeh!?"

Not only Kanako but even Touko showed surprised expressions.

What Yuu had in mind was his experience meeting delinquent girls when going out alone, and another time being dragged into a toilet stall during a tournament cheering session. Both times turned out fine since the women were worthy of sex. Today he'd met the Saiei Academy student council members who made bold advances without hesitation. Not that he disliked them - he'd even welcome approaches from president Rinne or Kate (formerly Keiko). But as with the Ichimatsu case, those targeting Yuu weren't always beauties. He wanted to avoid being assaulted by ugly women he'd flee from at first sight. In that sense, he thought learning self-defense would be good for his future.

"May I ask one thing?"  
Kanako straightened her posture and looked at Yuu.  
"Do you remember the contents of the 'Handbook for Men's Life Safety'?"  
"'Life Safety Handbook'?"  
"Yes. I heard it's distributed to boys after graduating elementary school."

Yuu vaguely recalled seeing a booklet by that name in his desk drawer. Tracing his memory, he seemed to have skimmed through it when received. However, over three years had passed, so he didn't remember details.

"Hmm... I remember reading it, but not well."  
"Well, I suppose that's normal."

Kanako sighed softly. Perhaps few people read it earnestly. Touko continued.  
"As written in the 'Life Safety Handbook,' resisting when assaulted by women isn't recommended. The principle is to flee. Then seek help from protection officers, security guards, police, or those nearby."  
"Eh... that's..."  
"Sexual offenders are often well-prepared when multiple, making resistance or escape difficult. Even with one impulsive attacker, they're excited so reckless resistance could cause injury or even death. Best is to avoid unescorted outings or approaching female-dominated areas."  
"Ugh..."

Both were things Yuu had done.

"Still, Yuu-sama wants to learn self-defense?"  
"Y...yes."  
"Then perhaps find a male specialist..."  
"Can't Kanako-san and Touko-san teach me?"  
"Th-that's not impossible but..."  
"Then! I know it's an extra burden, but please!"

Even after three months in this new life, discomfort remained at being protected by women. Yuu's desire to train his body and learn basic combat skills since leaving the hospital might stem from innate male instincts. Yet asking female protection officers was contradictory.

Kanako and Touko couldn't refuse when Yuu bowed his head. "Nee-chan," Touko poked Kanako's side with her elbow. Kanako made a troubled face but wasn't truly unwilling.

"Then when shall we start? Tomorrow is Sunday... ah, we have plans from 10 AM."  
Kanako murmured while checking the schedule behind her.  
"Ah! Come to think of it..."  
Yuu recalled receiving a call from Inui Rumiko, a Ministry of Health, Labour and Welfare official, two nights earlier.

◇ ◆ ◇ ◆ ◇ ◆

At 8:30 AM on Sunday, Yuu arrived at MALSOK's Saitama Training Center to learn basics about mindset during assaults and self-defense. However, with travel time needed for the next appointment, they only had about an hour.

Descending underground revealed a training area - half with tatami mats for judo, half with low-rebound mats suitable for wrestling. Yuu thought no one else was there so early, but actually Kanako had reserved it privately the previous day.

Told to wear easy-to-move-in clothes, Yuu wore his school-issued short-sleeved gym shirt and half pants. But seeing this, the women immediately made him change into the training center's jersey set.

Kanako wore a gray tank top over a white T-shirt with black spats underneath. Unlike her usual pantsuit, the light clothing clearly showed her figure's magnificent proportions.

"First, a demonstration! Yuu-sama, come at me!"  
When Yuu changed and stood on the judo mat, Touko - wearing a judogi with black belt - declared proudly. She didn't seem to wear an undershirt, probably just a bra directly. Though regardless, her modest bust meant it hardly mattered.

"Ah, wait..."  
"Alright, here I come!"

As Kanako tried to stop them, the enthusiastic Yuu approached for a frontal grip. At 155cm, Touko was especially petite among this world's women. Kanako said she was a close-combat specialist despite her childish looks, but Yuu had never seen Touko fight, only Kanako's prowess. That might have made him careless.

The moment Yuu carelessly extended his hand, he felt Touko vanish. Actually, she'd moved too fast to see, entering Yuu's space for a throw. His body floated momentarily before his butt hit the tatami with impact, his neck in a rear naked choke. Though not applied fully so it didn't hurt, he could only stare blankly. Probably some hip technique.

"Mufuu. Caught you, Yuu-sama."  
"Ah, haha. You got me."

More hugging than choking from behind, Touko looked triumphant until: "Hey!"  
Thump!  
"Gyah!"

When Yuu turned after Touko released him, she was holding her head with teary eyes, apparently having been knuckled by Kanako.  
"What if Yuu-sama got hurt!?"  
"S-sorryyy!"

After Yuu pacified Kanako's anger, they started over. "She was national-level in lightweight judo during high school and vocational school. That movement isn't learned overnight," Kanako explained.  
"Well, true."  
"Time is limited, so today will cover introductory self-defense basics... say, for single attackers..."  
"What if suddenly restrained from behind with mouth covered?"  
"From behind?"

Yuu recalled being dragged into a toilet stall during the kendo tournament. Had the attacker been gorilla-like, he might have resisted but couldn't have won. What then?

"Let's try it! Kanako-san as attacker."  
"Huh?"

Kanako hesitated as Yuu turned his back. "Um..."  
"Come on, time's short!"  
"Haa."

Reluctantly, Kanako approached Yuu's back. "Really restrain me. Then Touko-san can teach what to do."  
"Uh..."

Kanako fearfully wrapped her arms around Yuu from behind, unable to hide her tension. She'd stood close for protection before and accidentally touched him, which Yuu never minded - he even held her hand in the car sometimes. But hugging from behind was too stimulating.

Yuu smiled looking back at her. "You can do it stronger."  
"Hya... yes."

Kanako pulled Yuu's arms forward and clung tightly. Being protected by Kanako daily, Yuu felt sheltered rather than restrained. Moreover, her ample breasts pressed so firmly against his back that he felt inner delight. Meanwhile, Kanako felt Yuu's refreshing scent up close, her heart pounding uncontrollably. She nearly relaxed her expression but held back with Touko watching.

Observing them with half-lidded eyes, Touko spoke. "Breaking free isn't easy when caught by a big woman like Nee-chan."  
"Yeah... true."  
Though not painfully strong, Yuu was indeed firmly pinned. He knew he couldn't move his arms.

"But if you can move below the elbows, there's a way."  
Touko approached Yuu frontally and unhesitatingly took his right hand. "No need to force escape - break fingers."  
"Huh?"  
Holding Yuu's hand, she made him grasp Kanako's right pinky and bend it backward.  
"Gyuh!"  
Even Kanako couldn't endure the pain, loosening her right arm's restraint.  
"See?"  
"I see."  
"Many resist by clawing the hand's back, but clawing the lunula area hurts considerably. Want to practice?"

Perhaps revenge for the knuckle, Touko did it unsparingly, genuinely hurting Kanako. But under the pretext of teaching Yuu, Kanako couldn't get angry.  
"Er... no, I understand. More importantly, Kanako-san, are you okay?"  
"Y-yes. Fine. Just this much."  
Kanako forced a smile while Yuu worriedly held her hand.

Next, Touko stood beside Yuu facing Kanako, simulating an attack in narrow indoor passages or alleys.

"The human body has unavoidable vulnerable points - eyes, temples, cervical spine. But attacking the face is difficult against taller women." Today Touko was uncharacteristically talkative. "With height difference, lower body attacks are easier. Well-known targets are the crotch..."

Touko pointed at Kanako's lower abdomen. The tight spats made it appear slightly wedged when stared at.

"A crotch kick will make the opponent writhe if landed well. But the motion makes it easily dodged. Yuu-sama, try kicking."  
"Eh...?"  
"It's fine."

Unlike men with testicles, women's crotches could still be vulnerable. Yuu hesitated to kick there. But Kanako approached zombie-like with hands forward. When within 1 meter, Yuu reluctantly tried a soccer-style right kick toward her crotch, but Kanako easily closed her legs to stop it and placed both hands on his shoulders.

"Caught you!"  
"Ah... caught."

Balancing on one leg, Yuu grabbed Kanako's hands. Kanako looked delighted.

Realizing crotch kicks were risky, they reset facing each other. Next, they'd learn simple counterattacks effective even for martial arts novices.

One was a knee strike - less motion than Yuu's soccer kick and easier to land.

Another was a palm heel strike - striking with the fleshy base near the wrist or firm heel of the palm. Done well, it penetrates deeper than punches for heavier damage. Disadvantages included short reach making misses dangerous, and potential wrist injury even when successful. While face strikes were standard in combat, targeting the chest toward the heart worked for self-defense novices. To Yuu, it resembled sumo's thrusting technique.

"Then, begin!"  
"Practical again?"  
"Yuu-sama, I'm trained so strike without holding back."  
"Hmm. Then..."

As Kanako approached frontally again, Yuu ducked under her extending hands to avoid capture, thrusting his right palm forward toward the prominent breasts. But Yuu's ingrained "don't assault women" consciousness made him lose momentum mid-strike.  
Squish.  
"Ooh."  
"Ah."

Unconsciously, Yuu had grabbed a breast. Even his full palm couldn't contain its size.  
*(Amazing...)*  
Through the fabric, he felt firmness and softness. His spread fingertips sank in but were pushed back by the elasticity. Yuu kneaded it mesmerized.  
"Yu, Yuu-sama... ah... ahn!"  
Though initially flustered by the sudden breast-groping, Kanako seemed to feel pleasure, grabbing Yuu's shoulders without stopping him while leaking sweet moans.

After about an hour of self-defense training, Kanako and Touko were changing.  
"Fuuu... Maintaining rationality was harder than usual."  
"True, physical contact was frequent this time. Perks, perks."  
"That's not what I meant..."

Topless in her underwear, Kanako touched her own breast pensively. While self-touching evoked no feeling, she was bewildered by the indescribable pleasure that had pierced her body when Yuu kneaded it earlier.

Seeing this, Touko also looked down at her modest chest wrapped in a plain white sports bra. She couldn't hide her surprise at Kanako's earlier expression. How would it feel if Yuu kneaded her breasts? Touko couldn't stop wondering.

---

### Author's Afterword

The first interaction with the protection officers in a while. 

Even with increased physical contact, their professional ethics prevent their rationality from easily crumbling. 

But what if this continues...?

Note: Regarding self-defense techniques, some parts were properly researched while others were fabricated for story purposes - please understand.

### Chapter Translation Notes
- Translated "警護官" as "Protection Officers" to match Fixed Reference terminology
- Preserved Japanese honorifics (-san) throughout
- Translated explicit anatomical terms directly: "チンポ" → "dick", "乳房" → "breast"
- Rendered sexual acts without euphemisms: "揉みしだいた" → "kneaded"
- Transliterated sound effects: "あんぐり" → "gaped", "ゴンっ" → "Thump", "むにゅっ" → "Squish"
- Maintained Japanese name order: "乾 留美子" → "Inui Rumiko"
- Italicized internal monologue: "（すごい…）" → *(Amazing...)*