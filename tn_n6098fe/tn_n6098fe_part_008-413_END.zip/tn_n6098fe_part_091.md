## 84. Special Examination ① ~At the Mercy of the Flow of Time~

### Author's Preface

The first half is set further in the past than the previous chapter.  
The latter half chronologically follows immediately after the previous chapter's location.

---

Rewinding to Thursday, the day before the ball games tournament.  

I returned home around 6 PM that day, and unusually, there were visitors at such an hour.  
They seemed to have just arrived, the two guests having only just taken their seats.  
Elena, who happened to be home, and Saira—who normally would've come on the weekend—were also shamelessly joining them.  
Since it concerned Yuu greatly, he was immediately seated on the sofa facing them upon returning.  

One was Inui Rumiko, an official from the Ministry of Health, Labour and Welfare.  
It had been nearly two weeks since they'd last met during his first sperm donation at the general hospital.  
She wore a business style with a pure white open-collar shirt and navy blue tight skirt, her well-proportioned body still stirring men's hearts as always.  
The other was an elderly woman—though it was ambiguous whether to call her that—a woman who appeared around sixty years old.  
Her hair, more white than black, was neatly tied up in a bun, and she wore rimless glasses.  
Dressed in a slightly plain floral shirt and pale purple long skirt, her petite frame held excellent posture that hinted at refinement.  
When her eyes met Yuu's, a gaze overflowing with affection came from behind her droopy-lidded glasses, strangely filling him with a warm feeling.  

"You've returned at just the right time, Yuu-sama. Allow me to introduce you.  
This is Ichinose Hatsumi-san, chairperson of the Toyoda Sakuya Memorial Foundation."  
The woman called Ichinose bowed slightly and spoke.  
"I am Ichinose, honored by the introduction."  
"I-Ichinose? Could it be...?"  
As if recognizing the name, Martina showed a surprised expression.  
"Yes, exactly as you imagine. I had the honor of being Sakuya-san's first partner."  

It's well-known that when Yuu's father, Toyoda Sakuya, was ten years old—shortly after entering fifth grade—his first sexual experience was with his homeroom teacher at the time.  
Even considering how beautiful the child was, it wasn't that the teacher made the first move; rather, Sakuya developed an un-childlike lust for the then 25-year-old Ichinose and launched a fierce assault, leading to a physical relationship.  
Otherwise, she couldn't have continued teaching after being discovered having sex with an elementary school boy.  
All because when she became pregnant, Sakuya boldly declared before the principal that he was the one who impregnated her.  
Their relationship continued throughout Sakuya's elementary school years, and she reportedly gave birth to one boy and one girl.  
Though they never married, she is the mother of Yuu's oldest half-siblings.  
Yuu learned all this from a TV special he watched on his father's death anniversary.  

"Nice to meet you. I'm Martina, Sakuya-san's eighteenth wife.  
This is my daughter Elena, and my son Yuu.  
And this is Saira, daughter of Suzanna, the seventeenth wife.  
She lives in Hokkaido but happened to come here for company training."  

Following Martina's introduction, Yuu and the others greeted in turn.  
Hatsumi smiled warmly while looking at their faces, but especially toward Yuu, her gaze held a nostalgic, cherishing expression.  
"How curious. Though your appearance types differ, you somehow resemble Sakuya-san in his youth. I wonder why?"  
Martina listened to these murmured words—spoken like a soliloquy with a hand against her cheek—with a complicated expression, while Rumiko nodded in understanding.  

"Um, Ichinose-san?"  
Martina initiated the conversation, a hint of tension visible on her face.  
"Please call me Hatsumi, Martina-san. What is it?"  
"Ah... then, Hatsumi-san.  
I heard things were difficult after Sakuya-san passed away?"  
Like Martina and the others, she had been grieving the loss of her beloved husband, but she never showed it.  
When asked, Hatsumi modestly said, "Not as much as you wives," while wearing a reminiscent expression.  
"It was about a month after Sakuya-san died, I think.  
Strange people came swarming in droves."  
"Huh? Why?"  

Yuu was puzzled.  
He'd heard that the relationship between his father and Hatsumi had ended after elementary school graduation.  
Though they might have met occasionally since having children, his father's reputation as a sexual powerhouse truly began in middle school.  
It's said that even his father never impregnated an elementary schooler.  

Rumiko interjected here.  
"Even during his lifetime, Sakuya was called by various titles by the media and fans.  
For example... he was famously known as the 'Sexual Magnate Duke' for having children with an unimaginable number of women. Since he actively formed relationships not just with Japanese but foreigners too, they likened women to the sea and called him the 'Ocean Conquering King.' There was also the grandiose 'Savior Star Lord' as he was the hope of all women on Earth."  
"Haha... amazing."  
"With a chance to be embraced by him and a high probability of pregnancy, his popularity was tremendous even without physical relations, bordering on deification."  
"So why did strange people swarm Hatsumi-san's place?"  

At Yuu's question, Hatsumi and Rumiko exchanged glances.  
Rumiko seemed to take charge of the explanation.  
"After Sakuya's death, several religious groups were established.  
They deified and worshipped Sakuya, of course, taking those honorifics directly for their group names—'Servants of the Ocean Conquering King' or 'Church of the Savior Star Lord.'  
Some were cases where existing private fan clubs were taken over by fanatics.  
They needed to install a living person as their representative or symbol."  
"I've heard from Suzanna and Emmanuela. Strange people swarmed them too, making it so difficult they had to move."  

Martina had gone into hiding early while pregnant with Yuu, but it seemed such religious groups had swarmed the wives who remained at their original residence.  
Since there was no hierarchy among the wives despite their order, they apparently weren't pursued relentlessly to their new homes.  
Instead, they targeted Hatsumi.  
Being Sakuya's first woman made her the perfect symbol.  

"It was... absurd. Capturing an ordinary teacher and calling her queen or duchess..."  

Though she could laugh about it now, one could imagine how difficult it was then.  
Among new religious groups, so-called cults aren't reasonable opponents.  
They couldn't care less about people's circumstances or inconvenience for their doctrine.  
In fact, they genuinely believe their actions are righteous, not hesitating even at criminal acts.  
From the current timeline, it would be several years later, but Yuu recalled a certain cult in his original world causing a terrorist incident that claimed many lives.  

"Well, it began interfering with my work, so I sought help from the government.  
I resigned from teaching and went overseas, mainly working on school establishment support in Southeast Asian countries.  
Then, about ten years ago, I was invited to serve as director of the current foundation, so I decided to contribute my modest efforts."  

Here, the conversation finally reached its main point.  
"Our foundation collects and preserves all of Sakuya's mementos and materials, while also maintaining connections with people related to him—wives, lovers, and children.  
We hold irregular fellowship meetings and consultation sessions, and publish seasonal newsletters, so I believe Martina-san has received them too, but..."  
"Ah... yes, indeed. But..."  

This was news to Yuu.  
Martina had never mentioned connections with other wives or children beyond showing photos of Suzanna and Emmanuela, keeping such ties completely hidden.  

Hatsumi maintained her gentle smile as she spoke to Martina.  
"I understand your concerns, Martina-san.  
Our foundation is a special organization—media interviews are strictly prohibited, and information is non-disclosed in principle.  
Well, we do receive cooperation requests from the government regarding Sakuya matters."  
Hatsumi looked toward Rumiko.  

"We conduct a special investigation for all of Sakuya's children when they turn fifteen.  
Due to various circumstances, some haven't undergone it yet, but with Yuu-sama—the last generation—as the subject, we'd like Elena-sama and Saira-sama to undergo it together."  
"Investigation? Different from the health checkup in April?"  
"Yes. There are physical examinations, but it's more about observing psychological aspects."  

Rumiko seemed to have prepared pamphlets.  
But the one given to Yuu differed in thickness from those given to Elena and Saira.  
Elena and Saira's had about two pages of double-sided content excluding the cover, while Yuu's seemed to have five or six pages.  

"Does the male have more tests?"  
"Yes, inevitably regarding sexual matters."  
"Sexual... Is it okay for him to undergo such things?"  
Martina naturally expressed concern.  
In her mind, Yuu might still be an innocent fifteen-year-old boy.  
"Hmm. It should be fine, right? There are things like psychological tests too, seems interesting."  
After flipping through the pamphlet, Yuu turned to Martina—still wearing a worried expression—and answered with a reassuring smile.  

◇ ◆ ◇ ◆ ◇ ◆  

On Sunday morning, after learning self-defense from protection officers Kanako and Touko, Yuu headed to Saitama University Hospital in the prefectural capital.  
As pre-arranged, the car was parked in the staff parking lot behind the main building—likely to avoid the eyes of general patients and families.  
As Yuu headed toward an inconspicuous staff entrance surrounded by protection officers, two women were waiting nearby.  

"Yuu!"  
"Ah, Sis, Saira-nee! You arrived earlier than I thought. I expected to get here first."  
"W-well... ahaha"  
"If it were just Elena, she definitely wouldn't have arrived on time, right?"  
"Y-yes, thanks to Saira."  
"Ah, I see."  

Having commuted by bus in high school, Elena had hardly ever taken trains.  
Naturally introverted and obsessed with Yuu, she'd rarely gone outside the city alone during her three high school years.  
That she could transfer trains and come this far was thanks to Saira, who was surprisingly proactive.  

At the entrance, waiting were Rumiko leading about eight people: women in plain suits from their twenties to forties (likely Rumiko's subordinates and hospital administrators), veteran nurses in white coats, and hospital security guards.  
Yuu felt it was an overly grand welcome, perhaps because this examination held significant meaning.  

There, it was explained that Elena and Saira would separate from Yuu to complete their own schedules.  
The women would finish by noon, but as a male, Yuu had many examination items and would take until evening.  
So Kanako and Touko would leave after contacting them, planning to meet Elena and Saira during lunch.  

"Then let's eat lunch together!"  
"Got it, Sis. I might make you wait again though."  
"It's fine. I'll wait for you, Yuu."  
Elena smiled brightly.  
Seen like this, she was just an ordinary doting older sister.  
Saira slipped close from the side and whispered in his ear.  
"I didn't get to drink Yuu's penis milk. After we get back... let's do it?"  
"Hah..."  

Saira pulled away with a mischievous chuckle.  
Where she learned such words or whether she was serious remained part of her peculiar charm, leaving Yuu no choice but to sigh.  

"Thank you for your hard work. We'll begin the afternoon examinations after a one-hour break."  
"Yes. Understood.  
.........Sigh. Tired..."  

After confirming that the accompanying nurse and security guard had left, Yuu quietly sighed.  
CT scans, MRI, EEG and ECG with electrodes, ultrasound, blood and urine tests—  
With no other patients, there was almost no waiting time. Moving from room to room felt like being on a conveyor belt, undergoing examinations nonstop.  

Finally, several doctors and nurses conducted a thorough physical examination of every part of his body.  
This included his genitals, and being directly touched by a beautiful mid-twenties nurse somewhat resembling Shiho inevitably caused an erection.  
Perhaps due to his massive size, everyone stared with surprise and enthusiasm, even taking photos of him half-naked.  
*Getting groped by female doctors and nurses like this is pretty exciting*, Yuu thought during the examination.  
The doctors and nurses seemed to find it unusual how calmly Yuu endured being touched while under their heated gazes, as they repeatedly expressed gratitude and apologies.  

"Thank you so much. Thanks to you, we finished much earlier than expected."  
"Sorry for making you endure being surrounded by women for so long."  
"No, it's totally fine. Rather, I was happy to be surrounded by pretty ladies."  
When Yuu answered, they visibly relaxed or blushed happily.  

After three solid hours of examinations, Yuu felt mental exhaustion wash over him upon entering the break room where his sisters waited.  
Perhaps to thoroughly confirm his physical health?  
Completing such expensive, time-consuming tests in half a day proved Yuu was receiving special treatment.  

Yuu's examinations took place in a building called Block D, part of a four-building complex.  
It seemed normally used for male patients, with only a few elderly inpatients besides staff like nurses.  
The break room on Block D's third floor was cleared of people beforehand—a space as large as a school classroom contained only Elena and Saira.  
While Yuu still wore his thin examination gown over his T-shirt and pants, they had changed back into their original clothes.  
Elena wore a casual combination: a short lavender crop top showing her navel with slim jeans.  
In contrast, Saira wore a white dress with abundant frills similar to when first seen, plus a straw hat with a red ribbon since it was sunny—giving pure young lady vibes.  

"Good work! C'mon, let's eat lunch!"  
"You're hungry, right? Which one do you want?"  
"Thanks. You bought them in advance?"  

Apparently purchased at the shop beforehand, three lunch boxes were lined up.  
Seeing their contents, Yuu smiled faintly.  
The salmon nori bento was likely Saira's preference, the hamburg steak bento Elena's.  
Thus, the remaining assorted bento must be Yuu's.  

While eating lunch facing his sisters in the empty room, they talked about the morning examinations.  
Unlike Yuu, their examinations focused mainly on female-specific areas: breasts, genitals, uterus, etc.  
They pointed at their chests and crotches without any shyness while explaining, making Yuu blush instead.  
They also had interviews about menstruation and sexual matters, with Yuu having to stop Saira when she tried to share excessive details.  

As break time neared its end, the sisters decided to go shopping at the department store near the station since they'd come all this way.  

"Well then, Yuu, do your best this afternoon too."  
"Ah, you be careful too, Sis. Don't get lost."  
"Got it!"  

As Yuu stood up to head toward the exit, Elena took his right arm from the side.  
Of course, Saira hugged his other arm, pressing her chest against him.  
Her dress's neckline was wide open, so when Yuu looked down, he could see her cleavage.  

"Couldn't drink Yuu's penis milk. When we get back... let's do it?"  
"Haha... if I have energy left."  
"It's fine, Yuu just needs to lie there."  
"Don't leave your sister out, okay?"  
"I know."  

Breaking free, Yuu pulled both toward him simultaneously.  
Elena's light brown hair and Saira's platinum blonde—  
Both felt smooth and pleasant to touch when stroked.  
While stroking their hair, he kissed them alternately.  
After repeating this five or six times and hugging them tightly, someone knocked.  

"Well then, see you later. Sis, Saira-nee."  
"Bye bye, Yuu."  
"Yuu, I'll be waiting naked."  

After parting with his sisters, Yuu headed for the afternoon examinations accompanied by the nurse and security guard who came to fetch him.  

---

### Author's Afterword

I initially wrote "almost ten days" since meeting Rumiko again, but I miscalculated the days.  
It had been about two weeks. Corrected.  


### Chapter Translation Notes
- Translated chapter title subtitle "時の流れに身をまかせ" as "At the Mercy of the Flow of Time" to preserve poetic reference to Teresa Teng song
- Translated "筆降ろし" as "first sexual experience" to convey cultural euphemism for virginity loss
- Rendered "性豪公" as "Sexual Magnate Duke" combining literal meaning with aristocratic honorific
- Translated "救世星主" as "Savior Star Lord" maintaining religious deification nuance
- Preserved Japanese honorifics (-sama for Yuu, -san for adults)
- Translated "おちんぽミルク" literally as "penis milk" per explicit terminology rule
- Used "Sigh" for "はぁ" to convey exasperation in internal monologue
- Translated "ノックされてしまった" as "someone knocked" to imply interruption of intimate moment
- Maintained Japanese name order throughout (e.g., Inui Rumiko, Ichinose Hatsumi)