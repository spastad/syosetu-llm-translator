## 85. Special Examination ② ~You're the Only…~

In contrast to the morning, the afternoon consisted of personality analysis starting with psychological tests by a psychiatrist, as well as interviews by a specialist in sexual issues.

The psychological tests included: being shown strange pictures and saying what they looked like; answering questionnaires with "yes," "no," or "neither"; and creating a short story (past, present, future) based on a picture depicting a certain scene. Some tests were ones Yuu had seen or heard of before, but gradually, more and more of them began to suggest male-female relationships and sex.

The next interview directly questioned his views on women, interest in sex, and even delved deeply into his past experiences. Yuu agonized over how much to reveal, but the counselor had declared at the outset that she was bisexual and attracted to both men and women. She was a dignified woman who might resemble Kuroda Noriko after another decade of refinement - someone who indeed seemed popular with women. Moreover, since she candidly shared her own sexual experiences (with both men and women), Yuu felt compelled to respond to some extent. Despite her androgynous beauty, her friendly smile and unique way of speaking made the time unexpectedly enjoyable.

After a short break, Yuu was made to sit on a bed in what appeared to be an examination room, with electrodes attached to his head and chest like for an ECG. Then, women ranging from about 10 to 40 years old came and went one after another. Each had one minute to talk while engaging in light body contact including handshakes while pressing close beside him. There were 50 in total, with about one-third clearly being foreigners. Some were plain, others very beautiful; some thin, others plump. Was this to determine his preferred type of woman or the breadth of his attraction? Told he could touch anywhere without reservation, he hesitated at first, gently patting heads or lightly hugging, but gradually grew bolder and touched breasts and buttocks.

After completing the afternoon examinations, Yuu was guided by a nurse to a small room where Rumiko and another woman in her late twenties wearing plain business attire were waiting. The business card she gave showed she belonged to the Toyoda Sakuya Memorial Foundation's administrative office.

"Thank you for your hard work since this morning. I wish I could say that's all..."  
"Huh?"  
Just as Yuu started to relax, he tensed up at the implication of more. Seeing this, Rumiko smiled mischievously.  
"Fufu. Don't be so stiff. I just want to briefly discuss today's examinations. Then there's one last request, but whether you accept it is entirely up to you, Yuu-sama."  
"Haa."

Yuu sat facing Rumiko and the foundation woman on a sofa. The latter maintained a poker face, but her aloof expression was quite beautiful, and when Yuu glanced at her repeatedly, she shyly looked down. *She might be surprisingly innocent*, Yuu thought, forming a favorable impression.

Holding finely printed papers, Rumiko began:  
"The detailed results of today's examinations will take some time, so we'll mail them later. For now, I can say that Yuu-sama's body shows no issues, including congenital diseases. We can determine you're in extremely good health."  
"That's... a relief."

Though the pace had been intense, Yuu felt relieved to be reborn as a healthy 15-year-old after such thorough examinations.

"Moreover... despite your strong interest in women, you're considerate and have an unprejudiced, tolerant heart toward a wide age range. Combined with your appearance, your genitals are supremely exquisite. Most importantly, you have excellent reproductive capacity..."  
Rumiko glanced at the woman beside her, who nodded happily with evident delight. While flattered by such praise, Yuu wondered where this was heading.

This time the foundation woman spoke:  
"We measure comprehensive similarities to the father among Toyoda Sakuya-sama's sons. Each trait forming Toyoda Sakuya-sama's character discovered so far is named an 'S-factor,' and we investigate how many S-factors each son possesses from various angles."  
*This is getting serious*, Yuu thought as he nodded.  
"The highest score so far was 55 out of 100. But based on today's preliminary calculations from your results, Yuu-sama scored an astonishing 85 points!"  
Though it was about Yuu, she puffed out her chest proudly (which wasn't particularly large).

"Ha, 85 points...?"  
"Yes! The highest score in history achieved by the last generation's Yuu-sama. Amazing! I can't help but admire you!"  
"Ahaha..."

As Yuu struggled to grasp the significance, Rumiko interjected with an amused expression:  
"Even among blood relatives, scores above 90 are considered virtually impossible since they're different people. So you could truly be called the worthy successor to Sakuya."  
Even hearing this, Yuu remained calm.  
"Well, people called 'the second generation' often fail to live up to expectations rather than surpass the original."

In his original world, it was standard for media to hype promising young athletes as "the next [famous athlete]," but it usually ended as mere publicity. Though in this case, as a son, calling him "the second generation" wouldn't be wrong.

"My, how modest. True, the psychological tests as one evaluation method have mixed opinions on their validity... Sakuya-sama was Sakuya-sama, Yuu-sama is Yuu-sama. Whether the same person or different, times and environments change how one feels and acts."

Having said that, Rumiko removed her glasses and fixed Yuu with an intense gaze. The foundation woman also watched him expectantly. Stared at by two attractive women, even Yuu felt embarrassed.

"But let me say this: Toyoda Sakuya-sama was once called a beacon of hope for women of marriageable age not just in Japan but worldwide. You are the most suitable person to be his successor."

Indeed, Yuu liked women as an ordinary man. He had no particular type - decent looks and compatible personality sufficed. Or so he thought, but in his past life, he couldn't even keep one woman. Now reborn as a handsome youth in a male-scarce world, he enjoyed constant popularity. Since most women showed him special favor, he could respond with happy, relaxed attitudes.

About three months since rebirth.  
After entering high school, falling for the student council president, and losing his virginity, he'd had more sexual encounters than imaginable in his original world. Though sometimes encountering trouble, his smooth life resulted from luck and his own looks/actions.

"The S-factor results won't be publicly disclosed. But they'll be known to certain influential politicians and bureaucrats. Some women in key political/financial positions had relations with Sakuya-sama in their youth and still strongly admire the deceased. If they learn his successor has appeared..."  
"Eh? That sounds like pressure. What should I do...?"

Yuu had indeed been carried away since rebirth, living freely while popular with women. Hearing this unexpected development made him nervous internally. Though mentally adult, his petty bourgeois nature remained.

"Ah! I didn't mean to pressure you..."  
"Aah-"  
Seeing Yuu's troubled face, the two panicked. Rumiko smiled wryly before speaking reassuringly:  
"You seem calmer than you look, but Yuu-sama is still 15. Sorry for spilling adult matters. Even if known, no one intends to immediately do anything to a minor. Please remain as you are. That's fine."  
"So I should just act naturally as before?"  
"Of course!"  
Their voices harmonized.  
"Then I shouldn't overthink it?"  
"Yes, please continue interacting closely with many women without hesitation?"  
"Haha. Well..."

Though he never expected opposition, Yuu was surprised to receive active encouragement.

"Now, may I discuss the last request?"  
"Yes."  
Rumiko licked her lower lip as if savoring the moment. Though initially startled, Yuu had calmed enough to find her vivid red lips alluring.

"We'd like Yuu-sama to have sex with one woman now... Oh? Not surprised?"  
"Well, given the conversation so far..."  
Yuu wouldn't be shocked even if asked to have sex with these two.

"Then what if I said she's your sister, though with a different mother?"  
"My... sister?"  
Yuu pondered. Having already slept with Elena and Saira, he had no reservations beyond the partner's consent.  
"Okay. But why a sister?"

The foundation woman answered:  
"We've analyzed tendencies and preferences not just among sons but daughters. One characteristic is they're more lustful than average women and strongly desire pregnancy/childbirth."  
"Ah~ I see."  
Relieved Elena and Saira weren't exceptions, Yuu paused. *Wait - 100, no 150+ sisters potentially like them?* He felt conflicted. But with attractive parents, daughters would likely be beauties - which intrigued him greatly.

"There are five cases of siblings among Sakuya-sama's children bearing children."  
"Though calling them samples is rude, two of those five were boys."  
"Eh? Then..."  
"Perhaps children between Sakuya-sama's sons and daughters have higher male birth probabilities."  
"But consanguineous marriage..."  
"Yes. We know risks of recessive genes causing disabilities/congenital diseases. But considering that, if male birth rates are significantly higher..."

Medieval European nobility's inbreeding increased deformities/disabilities/early deaths. Yuu vaguely recalled isolated Japanese villages offering young girls to travelers to introduce outside blood, knowing villages of relatives would decline. He lacked detailed knowledge about risk levels.

But during sperm donation, he'd heard Sakuya's children had higher male birth rates - possibly inherited by sons, and further increased with daughters?

"We apologize for this experimental approach and won't complain if refused. But if you're willing, could you oblige? We intended to let you choose from two or three, but only one could come due to timing..."  
Though Rumiko's expression held apology, she seemed somewhat amused.  
"What's she like?"  
"Fufu. That's the surprise."  
*She's definitely enjoying this.*  
"But she's met you before. Shy and innocent for 23, but cute. About 158cm tall, bust 89cm, waist 69cm, hips 95cm... slightly plump?"  
"No, that's fine."  
In this world where slim figures are ideal, short height with large breasts seemed unpopular - a shame.

Regardless, Yuu agreed without much hesitation. Guided to the woman's room, he resolved not to overexpect since women's "cute" often differed from male perspectives. Rather, he couldn't stop wondering who he'd met before.

The room on D Building's top floor resembled the male VIP suite from his hospitalization. The luxurious furniture and chic interior felt familiar upon entering. The king-sized bed could easily fit two or three.

Entering, he saw a large CRT TV against the right wall near black leather sofas - similar to the VIP room. Before the sofa sat a woman hunched over, curled up. She hadn't noticed the door or footsteps.

"Um..."  
"Hyaa!"

Startled by his voice, she jumped up and turned. Her wavy black hair reached mid-back. Hidden by her hair, she had a small face with petite features. As Rumiko said, she was shorter than average. Wearing a loose white gown after showering, it only reached her knees, revealing slender calves.

As Yuu approached, she briefly looked delighted before shyly looking down. Yuu stood facing her.

"Um, you might know, but I'm Hirose Yuu. I heard from Inui-san we've met... Sorry, I can't recall your name."  
"Ah... ah, um, I-I'm..."  
She seemed extremely flustered by Yuu's proximity. Many women in this world lacked male exposure. Having met many women, Yuu might forget unless they made strong impressions.

"May I see your face?"  
Her face remained hidden by hanging hair, and she seemed too flustered to hear. Yuu leaned in, lifting her chin.  
"Aww"  
"Hmm"  
Their eyes met as she looked up with large eyes. Instantly, her face reddened. Truly cute like a small animal. Though 23, she seemed younger.

Her shampoo/soap scent tickled Yuu's nose, making him want more contact.  
"Cute."  
"Y-Yuu-sama!? Ahyun!"

Hugging and stroking her hair, she turned beet red and froze like boiled octopus. Yuu's downward gaze caught her cleavage through the gown's open collar.  
*(Come to think of it, 89cm bust?)*  
Holding her close, he felt soft breasts against his chest. Feeling her soft body and heated cheeks, he noticed round black-framed glasses with thick lenses on the low table.

Such an innocent, easily flustered woman... Yuu slightly pulled back to see her face.  
"Mmmph, haaah, suuuuuu... haaaaaa... ah?"  
Strangely, she'd pressed her nose against his chest, and her mouth slackened when he lifted her chin.  
"Could you be... Yanai Miku-san?"  
"Ah... yes."

He remembered her from the Japan White Cross Society during sperm donation two weeks prior.

---

### Author's Afterword

This dialogue-heavy chapter was somewhat difficult due to content indicating the protagonist's future direction. I may revise it later.

### Chapter Translation Notes
- Translated "初心(うぶ)" as "innocent" to convey lack of sexual experience
- Translated "S因子" as "S-factor" to maintain technical precision
- Preserved Japanese honorifics (-sama) and name order (Yanai Miku)
- Translated "ぴょこん" as "jumped up" for natural movement description
- Used explicit terms: "genitals," "sexual experiences," "breasts," "buttocks"
- Italicized internal monologues per style guidelines
- Maintained original measurements (cm) for anatomical descriptions