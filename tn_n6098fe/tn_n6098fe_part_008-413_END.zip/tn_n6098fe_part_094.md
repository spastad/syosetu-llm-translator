## 87. Special Examination ④ ~WHITE LOVE~

### Author's Preface

WHITE = White ----> White liquid

---

Having just made Miku climax continuously through cunnilingus, leaving her completely limp, Yuu rolled her onto her side and sat up to gaze at her disheveled form. The sight of her wanton female body ignited beastly desire within him. Perhaps it was also because Yuu himself had been left unsatisfied during their sixty-nine position.

"Miku... nee!"  
"Ahhn"

Yuu covered Miku's body and guided his erect cock with his right hand to her soaking wet vagina, thrusting in all at once.

"Yeeeeeeeees! Ah! It's... Yu... ah! Haaah!"  
"Oooh... guh..."

Unaware of Miku wincing from the pain of losing her virginity, Yuu frantically pumped his hips. Even when encountering strong resistance from her vaginal walls, he recklessly pistoned deeper until finally plunging into her depths with a *slurp*. "Ooooh... kaha... ahh... i-it feels... good..."

Feeling a paralyzing pleasure shooting through his entire body, Yuu stopped his hip movements, thinking he'd climax if he continued. Burying his face in her neck where disheveled hair clung to her sweaty skin, enjoying her feminine scent, Yuu came to his senses. He realized he'd thrust into her like a virgin getting his first chance at sex - desperate and forceful.

Miku's forehead glistened with sweat as she continued frowning, but when she slightly opened her eyes, she looked at Yuu and smiled.

"I-it's all in... right? My belly... feels full of Yuu's cock..."  
"Ah... Miku-nee, sorry! I forced it in. D-did it hurt?"  
"Huh? It did hurt... but you've got nothing to apologize for! A little pain is nothing. It's the price for the joy of being able to accept a man. Especially when that man is you, Yuu."  
"Miku-nee!"  
"Ah... nn..."

Without her glasses, Miku looked petite and cute, yet her body was surprisingly alluring to men. By his original world's standards, eight or nine out of ten men would want her as a girlfriend. Though compared to Elena and Saira, she wasn't an exceptionally beautiful girl - more like a cute girl you might occasionally see on the street. But having been accepted so completely as both brother and man in such a short time, Yuu couldn't help but feel growing affection. Combing through her messy hair with his right hand, he embraced her head and pressed his lips against hers. Kissing felt wonderful. Starting with peck-like kisses, they gradually transitioned to passionate lip-locking, exchanging long kisses. His left hand took Miku's right hand, interlacing their fingers in a lover's clasp.

"Mmmph~ nn... *chu*, *chu*, *chup*... aahn, I can feel it... Yuu's hard, hot cock inside me... nnah! Ah! Even without moving, my deepest parts are tingling! Afuu... amu... *lero*, *juru-chup*..."

After sharing a deep kiss that felt like devouring each other's mouths, Yuu pulled his lips away slightly and whispered with a smile.  
"Are you okay now? Can I move?"  
"Y-yes... come on, Yuu... aahn!"

He started with slow, small thrusts to acclimate her. As Miku reached out with her other hand, Yuu kept their fingers interlaced while gently rocking his hips. Her body had relaxed more since the initial penetration, and the oozing love fluid acted as lubricant, making movement easier. After several shallow thrusts, he plunged deep in one motion. Each time, Miku jolted and let out increasingly high-pitched moans.

"Ah! Ah! Ann! Ah... hah, hah... haun!"  
"How is it? Feeling good now?"  
"Yu... u... yes! I've been... aun! Feeling good for a while now!"  
"Glad to hear that... take this!"  
"Kyan! Come on... Yuu, don't bully... your onee-chan..."  
"Ah, it's just that Miku-nee is so cute..."

While moving his hips, Yuu thoroughly observed Miku's disheveled form lying on her back. Her long black hair spread haphazardly across the pillow. Her fair skin had turned pink, and with each thrust of Yuu's hips, she'd throw back her head or shake it side to side as if resisting while panting. At times, she'd gaze at Yuu through half-open eyes with her mouth slightly agape - an incredibly erotic sight. Her ample breasts swayed *yussa yussa* in rhythm with his hip movements.

Stretching their interlaced hands straight out, he pinned them to the bed, then covered her glistening, half-open lips. As their tongues tangled fiercely, Yuu's excitement grew, and his hip movements gradually sped up.

"Nnn! Nn! Mph! Oh! Ooh! Ooh! Aauu! Npf... Yuu! Yuu! Aun! No... something's... coming! I'm coming!"  
"Gonna cum? Go ahead... cum... here!"

Yuu covered Miku completely, burying his face in her sweaty neck as he thrust deep. Truthfully, the tight virgin vaginal constriction had heightened Yuu's pleasure too, and he was nearing his limit.

"Ah! Ah! Aaaaah! It's... too much... intense! Cumming cumming! Aaan! Already... I'm... c-c-cuuuumiiiiiiiiiiiiiiing!!!"

Just as Miku reached climax, squeezing his hand hard enough to leave nail marks, her vaginal folds contracted around his deeply embedded cock as if trying to wring out every drop of semen. "Agh! Mi... ku... kaha! I'm cumming too... ugh!"

After a momentary pause, an intense pleasure shot through Yuu's hips, and he uncontrollably released his semen. It felt as if he'd been led to ejaculate against his will, pouring thick spurts *dokudokudoku* inside Miku.

"Ah... ahh... haan... Yuu, it's coming out... so much hot... stuff... ahaa... amazing..."  
"Ha, haha... incredible... felt so good... couldn't hold back"  
"Ufu. I'm glad... ann"

After the ejaculation subsided, Yuu released her hand, and Miku wrapped her arms around his back, clinging tightly. Yuu lovingly hugged her back.

"Fuaaaaaah... Yuu's semen mixed with my lewd juices makes such a naughty smell."

Dogs and cats have more developed senses of smell than humans, yet when they encounter an interesting scent, they sometimes press their noses against it to smell. Miku was in such a state now. Honoring her request to smell it, Yuu pulled his cock from her vagina - still hard - and presented it before her eyes. Miku herself couldn't move immediately after her hard-fought loss of virginity, still lying on her back. Instead, Yuu placed a large pillow under her head.

Miku brought her nose and mouth close to the sticky cock, savoring it. "Ahhaan... just the smell might get me pregnant."  
"Actually, I creampied you plenty. And today's your... 'lucky day', right?"  
"Ufu. That's right. Aahn, *pero*"

With a truly happy expression, Miku licked up the shaft glistening with fluids. When she pressed her nose against the glans, the last bit of semen oozing out stuck to it. When Yuu pointed it out, she giggled "Ehehe," scooped it with her finger, and licked it off with her red tongue. Then Yuu had an idea. Such magnificent breasts shouldn't go to waste here.

"Hey, Miku-nee, stay like that. I have a request."  
"Nn?"

Miku looked up at him with an utterly innocent face.

Yuu knelt over Miku, resting his weight on her abdomen without crushing her, and placed his erect cock between her breasts. They had enough volume to hold it even without assistance, but when he asked Miku to press them together from both sides with her folded arms, the added breast pressure made it perfect.

"Th-this is...! The so-called 'breast press'?!"  
"Also called paizuri."  
"E-either way, my breasts are touching a cock directly!? Ah... the cock is right before my eyes!"

With his cock sandwiched between her breasts, Yuu slowly began moving his hips, making the glans pop *pyoko pyoko* from her cleavage. Combined with the heavy sweat around her chest and the cock's lingering moisture, movement wasn't a problem. When Miku lowered her chin, the glans came right before her mouth.

"Ooh... soft yet with just the right flesh pressure. Feels good. If you lick it too, it'd feel even better."  
"Ufu. Then... aahn, *pero*"

Yuu pushed his hips forward to make licking easier, causing her twin mounds to swell further. He rocked his hips in small movements right where they almost touched Miku's mouth.

"An... your cock... don't run away"  
Miku lowered her chin further and stuck out her tongue, trying to suck on the cock. She licked *peropero* or took it into her mouth *kapuri*. "Nn... good... really good, Miku-nee"

Not only was there breast pressure on the shaft, but the mucosal stimulation on the glans heightened Yuu's pleasure too.

"Ahhaa... I'm happy too... to suck Yuu's cock like this... nmu, *chu-pu-lero*"  
"Haah, haah. So... I'm gonna cum now. Do you want to swallow it or take it on your face?"  
"Uuun... can't decide... but since it's special, I want to drink... Yuu's seeeemen. *Chu*, *chu*... aha, it's already leaking clear fluid!"  
"Nn... Miku-nee's mouth and breasts... feel so good..."  
"Amuun... whatever feels good, make me drink lots"

As if to make him ejaculate faster, Miku sucked on the glans *chuu chuu*.

They continued paizuri for a while. The sweat from her cleavage mixed with precum and Miku's drooling saliva increased the slipperiness to a perfect level. Each thrust produced a sticky, *nechi nechi* wet sound.

"Hah, fu... ahh, good, Miku-nee... I'm about to cum..."  
"Amu... *rero*, *rero-chup*... nn, mph... oh, it's twitching, *pikupiku*..."  
"Ah! Nkuh... guh!"

When Miku looked up and saw Yuu's pained expression as he neared his limit, her love for him swelled even more. So she squeezed her armpits tightly, milking the shaft with her breasts while licking and sucking the glans.

"Ah! Kaha! Mi, Miku-nee! Ugh, I'm cumming, ejaculating!"  
"Nn... uun!"

Feeling Yuu's hand on her head, Miku realized the moment had come. She lunged forward as if to devour the cock, taking it fully into her mouth. She felt the cock she was sucking tremble slightly, then a gush of white fluid spurted out, filling her mouth.

"Ummmu!?"  
"Ah, ahh... it's coming!"

Everything was a first for Miku. But since she'd said she wanted to drink it, she tightly sealed her lips to prevent spills and swallowed the thick, sticky fluid several times as it threatened to choke her. Some spilled, but it couldn't be helped. The ejaculation didn't stop with one spurt - *pyuru pyuru* it shot out several times. Even after Yuu pulled his hips back slightly, her open mouth was filled with white fluid, and white strings stretched *nechaa* from her lips.

Thirsty, Yuu opened the room's refrigerator and took out a canned tea without permission. When he tried to give one to Miku, she said "If possible, share yours," so they drank from the same 350ml can. She explained that in a romance manga she'd read long ago, a scene where the heroine blushed while drinking from the male lead's half-finished can during an indirect kiss left a strong impression, leaving her with a girlish longing.

To Yuu, it seemed like a common trope in romance manga, but for girls in this world, it was nearly impossible outside of fiction. That must be why they longed for it so much. Even after their deep kissing earlier, seeing Miku hold the can carefully with both hands and sip daintily felt endearing to Yuu.

Now they sat shoulder-to-shoulder on the edge of the bed. Having sweated heavily and gotten thirsty, they quickly finished the tea. After placing the empty can on a nearby chest, Yuu sat properly and put his arm around Miku's shoulder. Smiling happily, Miku rested her head *koten* on his shoulder.

Miku gently placed her hand on her lower abdomen. "Fufu. Right now, Yuu's little sperms are swimming hard inside my womb. Meet my egg properly and fertilize it. Do your best!"

At this point, pregnancy wasn't guaranteed. Still, Miku hoped to conceive Yuu's child and called out to the sperm inside her womb.

"Hey, Miku-nee"  
"What is it, Yuu?"

By the time they finished paizuri, dusk had fallen outside, and the room had grown quite dark. They'd only turned on the bedside lamp, so deep shadows covered their faces when they looked at each other. Realizing their time to part was near, Miku buried her face in Yuu's chest from his shoulder, rubbing her cheek against him - as if savoring his scent until the last moment. When called, Miku lifted her face and gazed at Yuu with round eyes.

"Does more semen increase pregnancy chances?"  
"Uun... probably, yes"  
"Then let's... do it again!"  
"Eh, eeeh!?"

Yuu took Miku's hand and guided her toward the center of the bed - the edge risked a fall. Holding Miku close, Yuu lay on his back. "This time, why don't you get on top?"

"Ah, umm...! Your cock!?"

Miku noticed something hard pressing against her lower abdomen. Though she hadn't noticed earlier in the heat of the moment, she remembered hearing men needed intervals after ejaculating. Especially that erections so soon after cumming twice should be impossible.

"You came twice already... liar?"  
"I can still go. Come on, let's do it?"  
"An... Yuu..."

Miku had no choice in Yuu's embrace. Rather, she felt so happy she could cry. Positioning her hips just right, she guided the cock with her hand to adjust the angle.

"L-like this?"  
"Yeah, just like that... nn!"  
"Ah... aahn! I-it's going in... nku..."

With a *nuchari* sound, Miku's vaginal entrance swallowed the glans. Though insertion seemed smoother this time, Miku's freshly deflowered vagina remained extremely tight. While Yuu thrust in slowly, they kept holding hands and gazing into each other's eyes with passion.

"Ah! Ah! Aaaah! Haa! It's... in!"  
"Y-you okay?"

Miku furrowed her brows and collapsed *pofun* onto Yuu's chest. Her ample breasts pressed *munyu* firmly against him from the impact.

"Somehow... it's in but... Yuu's cock... is still so big"  
"Fufu... but inside Miku-nee... feels so good"  
"Nfu. I'm happy"

Lifting her face, Miku smiled and pressed her lips to his. After exchanging *chupa chupa* kisses, Miku began rocking her hips. Each movement made her large, swaying *tapuntapun* breasts distracting, so Yuu freed one hand to cup and knead them from below. Soon Yuu himself began thrusting upward, making Miku's moans grow even higher.

---

### Author's Afterword

This concludes the special examination arc.

I intend to have him impregnate other sisters eventually.

Look forward to seeing which sister it'll be!  


### Chapter Translation Notes
- Translated "美玖姉" as "Miku-nee" to preserve the honorific while indicating the sisterly relationship
- Translated "お姉ちゃん" as "onee-chan" to maintain the intimate form of address
- Rendered explicit anatomical terms directly ("cock", "vagina", "semen") per translation style rules
- Transliterated sound effects (e.g., "gusshori" for ぐっしょり, "pyoko pyoko" for ぴょこぴょこ)
- Preserved Japanese honorifics and name order throughout
- Translated "当たり日" as "lucky day" to match fixed terminology for fertile period
- Maintained original paragraph structure for dialogue with new lines starting after attributions
- Italicized internal monologues like "*(This is concerning.)*" per style guidelines