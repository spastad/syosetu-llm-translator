## 88. Weekend Plans ~Confession~

It was the evening of the day after Yuu had undergone a special examination at Saitama University Hospital and, upon request, had sex with Miku, his half-sister.

As soon as Yuu returned home, he called Martina and Elena to the living room and broached the subject, immediately enveloping the room in tension.

The reason was that, although he had previously mentioned joining the student council, today he was confessing that he was simultaneously dating three officers (Sayaka, Riko, Emi).

Sayaka had a fiancé arranged between their families.

However, they had already been in a relationship where they had joined their bodies multiple times, and it was clear that she held affection for Yuu.

At least for the current term of the student council, they had agreed to continue this relationship.

If asked who his favorite woman was, it would be Sayaka, but he also liked Riko and Emi as fellow student council members.

Moreover, he had already shared intimate relations with several other women, including Yoko and Kazumi from the same first year.

But for now, he felt it necessary to at least inform them about his relationships with the three student council members with whom he was closest.

Martina and Elena froze at the sudden confession.

Martina closed her eyes and seemed to be deep in thought.

Meanwhile, Elena looked down and appeared to be muttering something in a voice too soft to hear.

After a while, Martina opened her mouth with a resigned expression.

"I thought that would come later, or rather, I might have been hoping it would. Sigh... Blood will tell, I suppose."

"Huh?"

"Hmm?"

In response to the questioning voices of Yuu and Elena, Martina answered succinctly.

"Yuu-chan is also Sakuya-san's son, after all."

Yuu nodded as if it made sense, but Elena still seemed unconvinced.

"Well, I knew that since Sairei Academy is co-ed, he'd eventually date a girl... But isn't it too early for Yuu? It's still the first term of his first year. Wouldn't it be better to start in his second year...?"

"Compared to Sakuya-san, who lost his virginity in fifth grade, isn't this still within the realm of common sense?"

"Huh?"

Apparently, Elena hadn't known about the beginning of the Sakuya legend.

"I was surprised that it's three at the same time... But given how charming Yuu-chan is as a boy, it can't be helped. It's better than having them fight over him and causing trouble. What I'm more concerned about is what kind of people they are. Hey, tell me in detail."

"Ah... okay."

Martina leaned forward toward Yuu.

Elena also seemed interested and stared intently at Yuu.

Yuu wanted to keep it light, but it was only natural they'd be curious upon hearing he had girlfriends. Resigned, he began to talk.

"First, student council president Sayaka-senpai. She's the daughter of the president of Komatsu Group, which is famous for motorcycles and cars."

"Whaaat?!"

"Her motto is excelling in both academics and martial arts. She has excellent grades and holds several dan ranks in martial arts. She's the epitome of a student council president, helping the weak and crushing the strong, so she's popular among both boys and girls at school. Although she does have a cute side where she sometimes gets carried away and goes on a rampage."

Having learned from his short married life that when praising one woman to another, it's not good to focus on appearance, Yuu deliberately avoided mentioning her beautiful looks and instead emphasized Sayaka's wonderful personality. Taking advantage of the fact that Martina and Elena didn't say anything, he continued by talking about Riko and Emi.

He mainly talked about how they had cooperated in the student council and touched on the family circumstances he had heard about each of them.

Only Sayaka had a father on her family register and sisters.

Riko was born through artificial insemination and was an only child.

Her mother, though not a big business owner, was an entrepreneur and apparently wished for Riko to go to university since she had been good at studying since childhood.

Emi lived only with her grandfather. Her mother was the youngest of three sisters.

Emi was born when her mother fell in love with a man she met during a vocational training program after graduating high school and going to an art college.

Few female students had shared their family circumstances with Yuu, but among them, only Sayaka had both parents. Even naturally born children like Emi seemed to be a minority.

Conversely, among boys, Yuu had only heard of those born through natural childbirth.

"Hmm, well, I kind of get what kind of people they are. Another thing I'm curious about is, um, who initiated the relationship?"

"Of course, it was me!"

Martina was taken aback by Yuu's confident declaration. She had feared that the seniors might have approached him, but it seemed that was unfounded.

"The first one I fell for was Sayaka-senpai. It was almost love at first sight. She was considerate because I'm her junior, but I pushed hard... Looking back, I think I was pretty forceful when I proposed dating. But Sayaka-senpai didn't seem to mind, so we became lovers quickly. Then, Riko-senpai and Emi-senpai, who were always together, found out. So we ended up dating all three at the same time."

Without mentioning the existence of Sayaka's fiancé, he emphasized that it was the result of him falling in love and taking the initiative. Martina couldn't help but smile at Yuu's nonchalant declaration.

"Heh, heh, heh. So even that part is like Sakuya-san. I can only laugh."

Elena remembered that Yuu had previously mentioned he was no longer a virgin.

"So, you've already had sexual relations with those three?"

"Yeah. Well, yeah."

"Ah, I thought so..."

Then Elena realized she might become an "aunt" while still in her teens. Moreover, not just an aunt, but in this case, a paternal aunt. As Elena buried her face in her hands, Yuu gently touched her.

"Sis, you don't have to worry about anything. No matter how many girlfriends I have, you'll always be my sister for life, right? I have many half-sisters like Saira-nee with different mothers, but you're the only one who was born from the same mother and took care of me since I was a baby."

"Yuu..."

Whether he dates or marries, others are ultimately others. It's common for temporary relationships to end. But family connected by blood will always have that bond. Of course, if they live far apart or have separate families, sibling bonds can fade, but Elena didn't think that far ahead.

Anyway, grabbing Yuu's hand tightly, Elena's expression suddenly turned happy. However, Martina then spoke to Yuu in a calm voice.

"Hey, Yuu-chan?"

"Y-yes, Mom?"

Yuu felt like he might falter under Martina's overwhelming presence.

"I'm not saying right away, but next time, bring Sayaka-san, Riko-san, and Emi-san home to meet me, okay?"

"Huh...?"

"Because I want to meet the people you're dating in person, not just hear about them from you."

"I want to meet them too!"

Of course, Elena jumped on the bandwagon at times like this.

"Ah, umm... The student council is going to be busy from now on..."

"Then when will you be able to bring them?"

Yuu averted his eyes and looked at the calendar. It was almost mid-June.

He really wanted to avoid introducing his girlfriends to his mother. He had to postpone it as long as possible.

"W-well, after summer vacation starts?"

"Fine then. I'll look forward to it."

"O-okay. Also, there's one more thing I need to talk about."

For Yuu, this was the main point.

"Since Sayaka-senpai and I both have birthdays in June, we're planning to have a birthday party just for the student council members, including me, this Saturday."

"Oh?"

His actual birthday, the 30th, would probably be spent with family. Sayaka's birthday had already passed. So they had discussed holding it on the coming weekend, right in the middle.

"The location is the apartment near school where Sayaka-senpai lives alone. So... I'll stop by after school that day and stay overnight."

Since he lived at home, he had never stayed out overnight before. As an adult in spirit, Yuu found it bothersome, but as a high school student living with family, it was unavoidable. So he thought he should mention it to avoid unnecessary worry.

"Hmm..."

"Ehh..."

Even Martina and Elena made difficult faces upon hearing Yuu's request. But since he was already in a sexual relationship with the girl, it might be better than having him go to a hotel in town if they objected. As long as Yuu's safety was considered, they had no choice but to accept.

Martina was the first to speak.

"Um, I was actually going to tell you today too, but I have an overnight business trip starting Friday afternoon, and I won't be back until around noon on Sunday."

"Eh, really?"

Martina's expression made it clear she really didn't want to go.

"I really don't want to... But since this fiscal year, my responsibilities have increased, and I have to go out more often."

She worked for a local newspaper, but occasionally had business trips outside the prefecture. Essentially, Martina had now been promoted to such a position.

Martina, who started as a part-timer, was evaluated by her fellow employees and rose to quasi-employee, then full employee. If she was promoted because her work performance was highly evaluated, it was something to be happy about as a family. However, Martina herself seemed disappointed that she would have less time to spend with Yuu. Additionally, as a manager, she would be caught between superiors and subordinates, which Yuu, as a former company employee, could easily imagine would be mentally taxing.

"I'm happy that Mom's work is being recognized, but if it breaks your heart or body, it's not worth it. If it's okay with me, I'll listen to your complaints, but make sure to take breaks and don't overdo it."

"That's right. I've caused you a lot of worry until now, but I'll be more responsible from now on. If anything happens, tell me."

"Yuu-chan, Elena... Hehe. I still thought of you as children, but before I knew it, both of you have become so mature."

"Well, I'm already an adult. I'll be 19 soon."

"I'll be 16 at the end of this month..."

"That's right. First, we have to celebrate Yuu-chan's birthday in a big way!"

"Ahaha. I'm looking forward to it."

As the atmosphere became more relaxed, Martina continued.

"So, I was thinking of having a farewell party for Saira-chan, who's going back to Hokkaido this weekend... But Yuu-chan won't be here on Saturday or Sunday. And I'll be on a business trip..."

"Ah!"

Saira, who had been visiting over the weekend, was finishing her training period and would be going back this Sunday. Regardless of her wishes, it seemed highly likely she would be assigned to the Hokkaido branch. After saying goodbye here, it wouldn't be easy to meet again. That's why they had planned to invite her to their home for a meal as a farewell, but now Martina and Yuu couldn't make it.

"If it's Sunday noon, I think both Mom and I can make it, but it might be bad for Saira-nee since she has to leave..."

"I might be late..."

"Maybe another day would be better?"

"Then I'll ask Saira directly!"

Since work was already over, Elena decided to call the lodging where Saira was staying, which she had gotten the number for earlier.

The landline phone was at the end of the living room, so they could hear Elena's conversation. Thus, they could somewhat understand what was being said.

Elena returned to the sofa where Yuu and Martina were sitting, smiling wryly.

"Saira said she just wants to see Yuu!"

"Sigh... Fine. Mom can just work, I guess."

"Mom!"

Yuu took Martina's hand, who seemed a little downcast at Saira's blunt words, and comforted her.

"And she said she has Saturday off, so she wants to go to Tōbō Another World Park."

Tōbō Another World Park, abbreviated as TAWP, somewhat resembled a top amusement park in Japan that was in Chiba but bore Tokyo's name in Yuu's original world. It recreated a fantasy world based on medieval Europe, with swords and magic, and even legendary creatures like fairies and elves. Characters from fairy tales and myths that would appeal to women, like Cinderella and Sleeping Beauty, were said to welcome visitors. Therefore, Yuu knew from TV that it was extremely popular with women of all ages and got very crowded on holidays.

"Then why not have her come over on Friday night for dinner, and then Elena can go play with her on Saturday? Elena hasn't been there either, right?"

"Th-that's true."

His sister, who doted on Yuu at home but was introverted at school with few friends, was unusually for a girl her age, had never been to TAWP. This would be a good opportunity.

"Then let's do that."

"Okay. What about dinner?"

"Why not order sushi for such an occasion? Saira-chan likes fish, right?"

So it was decided: on Friday, Martina would go to work and then leave for her business trip. Saira would come to stay over in the evening. The next morning, Elena and Saira would go to TAWP, and Yuu would stay over at Sayaka's apartment after school.

On Friday night, Martina, the stopper, wouldn't be there.

How far would his two sisters go without her?

Yuu felt a little scared, but in his heart, he was filled with anticipation and looked forward to the weekend.

---

### Author's Afterword

I intend to write the two events from the next chapter—Saira's farewell party and the birthday party—to conclude Part 3. Together, it should be about 10 chapters.

↑ I initially wrote this in the preface by mistake, so I've corrected it.

### Chapter Translation Notes
- Translated "身体を重ねる" as "joined their bodies" to convey the intimate relationship without being overly explicit in this context
- Preserved Japanese honorifics (-chan, -san, -nee) as per style rules
- Used "Sakuya-san" for Toyoda Sakuya as the text uses "サクヤさん"
- Translated "おば" as "aunt" and clarified the relationship as paternal aunt in the note for context
- Translated "童貞を卒業した" as "no longer a virgin" to convey the meaning naturally
- Translated "ストッパー役" as "stopper role" to indicate Martina's function in restraining the sisters
- Transliterated "TAWP" as per the fixed term, with the full name in parentheses on first mention
- Kept the name order as in the original: Hirose Yuu, Komatsu Sayaka, Hanmura Riko, Ishikawa Emi, etc.