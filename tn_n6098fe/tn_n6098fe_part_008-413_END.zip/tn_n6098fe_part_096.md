## 89. Farewell Party ① ~M~

### Author's Preface

After hesitating over the subtitle, I settled on the minimum character count.

It became slightly longer as I kept adding to it.

  

[Note] Contains SM-related descriptions.

---

  

Friday finally arrived.

That day, Yuu returned home as early as possible, welcoming Saira who left work right on time and came straight over.

  

They savored premium sushi ordered for delivery, with only Saira and Elena lightly toasting with chuhai.

Incidentally, perhaps due to racial reasons, Saira had a very high alcohol tolerance. Elena, however, wasn't particularly strong.

Yuu also felt like drinking, but considering his body's future growth, he refrained.

  

A peaceful time flowed during the meal.

Superficially, Elena and Saira seemed excited about tomorrow's trip to TAWP (Tōbō Another World Park).

However, Yuu definitely noticed them stealing glances at his body.

Though unspoken, they were likely envisioning the main event after dinner.

Yuu himself was also subtly eyeing his two beautiful sisters, so he couldn't criticize.

  

In other words, all three were excited about the upcoming feast in their own ways.

Yuu fantasized about things like double blowjobs or taking them from behind with their buttocks lined up.

Elena planned to finally have Yuu ejaculate inside her this time, aiming to cling to him until the finish.

But Saira had the highest expectations.

Last Sunday, Yuu's return was unexpectedly late, so she could only secretly kiss him.

Neither Yuu nor Elena had anticipated Saira's determination to bring such large luggage for tonight's gamble.

  

After eating, they took turns showering.

Yuu went first, followed by Saira.

Before Elena entered last, she repeatedly insisted they shouldn't start without her.

So Yuu tried to go to his room separately from Saira, but she stopped him in the hallway.

Saira was already wearing the black lace negligee he'd seen before.

The top clearly showed she wasn't wearing a bra, and the bottom was likely transparent panties.

With her platinum blonde hair swaying, her smiling stance looked angelic, but a little devil resided within.

"Yuu, you know..."

Approaching, Saira whispered softly so Elena in the bathroom wouldn't hear.

A wonderful scent of shampoo and soap drifted from Saira as she drew near.

  

Hearing Saira's proposal, Yuu pondered slightly.

"Hmm... Well, tonight is Saira-nee's farewell party. If that's what you want, I'll cooperate."  
"Really!? Great! Elena will be surprised, but I think she'll be pleased. Ehehe."  
"If you say so."  
"Then I'll get ready. Come right after Elena gets out of the bath and enters her room."  
"Got it."

  

Saira waved cheerfully and entered her sister's room.

Just seeing that was heartwarming.

"Saira-nee really knows all kinds of things."

At that moment, Yuu merely thought this innocently.

  

  

  

  

"I'm out!"

Worried, Elena emerged from the bathroom with still-wet hair.

"Okay. Coming now."  
"Yeees!"

Hearing Yuu and Saira's voices from separate rooms, Elena sighed in relief and entered her room wearing only a towel.

Immediately, the door opened, and she heard Yuu approaching from behind.

  

"Eh? Why's the room dark? Saira?"

Elena noticed only the orange nightlight was on when she opened the door.  
"Sorry, sis."

Yuu's voice came from right behind as he grabbed both her arms.

Elena briefly showed joy at Yuu initiating for once, but suddenly the room lights turned on, making her blink.

Saira stood before her with a bewitching smile, stretching something she held.

It was a red rope with a pre-tied knot.

Moreover, looking at Saira's feet, her Boston bag was fully unzipped, revealing restraints and colorful adult toys for SM.

  

  

  

  

"Kuuuu... N-no, I don't want this... Hey Saira, untie me!"  
"Fufufu. It turned out better than I thought. Untying it would be such a waste.  
Here, see for yourself?"

  

After thoroughly examining from neck to crotch, Saira led Elena before a full-length mirror.

While Yuu restrained her, Saira had bound naked Elena with red ropes.

It was kikkou shibari (tortoise shell bondage).

Her modest breasts were emphasized by ropes pushing out the flesh.

Her arms were bound behind her back, rendering them immobile.

A knotted rope passed through her crotch, forming a crotch rope.

  

Though using illustrated instructions, it took about 20 minutes.

Not exactly skilled, but she didn't seem inexperienced. Perhaps she'd done it locally before.

  

"How is it, Yuu?"

Asked by Saira, Yuu gazed intently at his bound sister from all angles.

Though Elena had verbally refused, seeing herself in the mirror and being watched by Saira and Yuu gradually flushed her cheeks.

Rather, even when Yuu restrained her movements and Saira began binding her with ropes, she hadn't seriously resisted.

  

*'I think Elena has masochistic tendencies. So tonight, I want to thoroughly torment her and expose her true nature.'*

Yuu recalled Saira's earlier words.

When had she noticed this?

Last Sunday when Yuu returned late, they'd bathed together.

  

"Yuuu... Don't... Don't stare like that..."

As Yuu stared intently, Elena unusually looked down shyly.  
"What are you saying? Sis, it suits you perfectly."  
"N-no it doesn't... Nnah!"

Saira, who'd moved behind, seemed to pull part of the back rope.

The crotch rope tightened sharply, drawing a sensual moan from Elena.

  

"Kufu. But this isn't the end?"  
"Eeh... St-stop..."

  

Saira smiled like a little devil.

Though Elena tried to refuse verbally, her expression showed anticipation.

  

Delighted, Saira reinforced Elena's bondage with items from her Boston bag.

First, a red leather collar like for pets was fastened around Elena's slender neck, its leash tied to the doorknob.

A pole with attached belts fixed Elena's knees and ankles in a wide-spread position.

A folded bath towel was placed under her knees to prevent pain from the floor.

When Yuu experimentally pulled the rope at Saira's urging, the crotch rope knot digging into her slit became clearly visible.

Finally, a ball gag silenced her mouth, and a black blindfold covered her eyes.

  

Elena could only moan "Mmmph!" unintelligibly.

Her now-dry long hair swayed wildly as she writhed and squirmed.

Feeling slightly sorry, Yuu saw Saira silently smirking and pointing.

Between her widely spread thighs. The two ropes digging into her slit appeared moist.

Then Saira lightly touched Yuu's pajama crotch.  
"My, how nice. Seeing Elena like this made your cock hard, Yuu."

Seeing restrained Elena and her damp crotch had unconsciously erected him.

Elena's cheeks flushed crimson at Saira's words.

  

"We'll both pamper Elena now. Ufufu. Look forward to it."

Saira rummaged through the Boston bag.

Blindfolded and gagged, Elena blushed pink while panting.

  

"Ta-daa!"

Saira proudly held up a black rod-like object with a flattened end.

Resembling a cake spatula but with a larger flat surface.

  

"What's that?"  
"It's called a spanking racket."

Saira moved behind Elena.

  

Spanking... Yuu recalled the term as Saira swung the racket lightly and struck Elena's buttock.

Paan!  
"Mugyii!"  
"Whoa!"

  

When Yuu went behind, the struck area was vividly red.  
"I-isn't it painful?"  
Even knowing his sister had masochistic tendencies, inexperienced Yuu worried.

But Saira was nonchalant.  
Whispering so only Yuu could hear:  
"This makes a loud sound but isn't very painful.  
Hand spanking is fine but hard to control. It's basically beginner SM gear."  
"O-oh really..."  
"Really... now!"

Paan!  
"Gyuu!"

  

Saira swung again, striking the other buttock.  
Consecutive satisfying sounds echoed as she alternated sides.  
Each strike drew screams and writhing from Elena.  
Yuu noticed:  
Despite the loud noise, Elena didn't seem hurt. Rather, she seemed pleased?

  

"Here here, you perverted slut! Getting turned on by being spanked!?"  
"Gyaaun!"  
"Fuu. Want to try, Yuu? The key is insulting while spanking."  
"Mmm..."

  

Yuu took the spanking racket.  
Elena's small buttocks were now bright red.  
"Elena, Yuu will spank you now?"  
When Saira spoke, Elena shook her head as if refusing, but her visible cheeks were flushed.  
Her breathing was noticeably ragged even from a distance.  
Elena's slender, beautiful back was completely exposed, her hips wiggling as if begging to be struck.  
Yuu felt sadistic urges toward his sister bubbling up.

  

"Heh, so you want your little brother to spank you? You extreme brother-complex perv."

Paan!  
"Vvuuun!"

  

Yuu didn't swing wide but ensured full contact.  
Struck, Elena arched her back sharply.

  

"Peeping tom masturbation addict!"

Paan!  
"Ghyiin!"

  

"Want me to cum on you? Wanna be a cumdump?"

Paaaan!  
"Muhhoo!"

  

Elena's reactions amused Yuu, making him enjoy it.  
"Wow, Yuu, amazing! Your verbal abuse is great, you've got talent!"  
"Ahaha. Got carried away."  
"Spanking's good, but let's try more today. Next is..."

Saira rummaged through the large bag again.  
Yuu was slightly exasperated at how much she planned to play with Elena.

  

He expected candles next, but was wrong.  
Saira produced what appeared to be a magnificent feather about 20cm long.  
Likely from a raptor like a hawk or eagle, with a gradient from dark brown to white.  
With a wooden handle, it might be a feather duster.

  

From an opaque black vinyl bag—like an adult shop bag—came pink thumb-sized oval cylinders with remote controls.  
Unfamiliar but seen in adult videos.  
Pink vibrators. Several were inside.

  

Saira handed one to Yuu, smirking at Elena.  
By now, Yuu understood without being told.  
Saira approached restrained Elena and touched her collarbone with the feather tip.

  

"Vhyiin!"

Startled by the sudden sensation, Elena's slender body jerked.  
"Thought I'd change things up.  
How about this?"

Saira didn't linger, lightly tracing her neck, shoulders, and chest with intervals.  
"Mmm! Mmm! Vgii!"  
Elena shook her head as if protesting, but Saira didn't understand.

  

If anticipated, she could prepare.  
Or if tormented in one spot like spanking, she'd adjust.  
But blindfolded and unexpectedly touched, she couldn't react.  
Each touch made Elena's body twitch amusingly.  
"V...nnaa...mufu...mufuu...gyiin!"

The feather tip brushing her nipple was most pronounced.  
Perhaps more stimulating than fingers.

  

Sometimes lightly grazing, other times pressing firmly.  
Varying intensity while caressing her chest everywhere.  
From spanking to soft touch.  
Normally unsatisfying, but Saira skillfully toyed with Elena's body.  
Elena seemed completely at the feather duster's mercy.

  

After thoroughly teasing her nipples, the feather descended to her rib-visible thin abdomen.

*(Come to think of it, Elena-nee is extremely ticklish on her sides.)*

Yuu recalled that tickling her sides worked wonders when she wouldn't wake up.

  

"Vgii! Gyaa! Gyaaeeee...vun!"

As Yuu thought, Elena jerked violently and cried out when her armpit was brushed.  
"My my... So Elena's weak here.  
You know? They say ticklish spots are also erogenous zones."

Pausing, Saira whispered in Elena's ear.  
Gently stroking the opposite side with her finger drew sweet moans.  
As Saira began licking Elena's ear with her tongue, she signaled Yuu with her eyes.

  

Approaching, Yuu decided to start somewhere unusual.  
Crouching, he licked the armpit opposite where Saira was stroking.  
"Nng!?"  
Elena reacted noticeably differently, trying to turn her face toward the licked side.  
Finding this pitiful, Yuu kissed and licked her fair skin upward, eventually stroking her head.

  

As Elena's furrowed brows relaxed, Yuu turned on the pink vibrator.  
A faint buzzing operational sound was audible.  
Hearing it, Elena shook her head anxiously.  
Yuu put the remote in his pajama pocket and brought the vibrator to Elena's breast.  
He circled areas distant from her nipple.  
"V...vaa..."

Small tremors, but stimulation seemed weak.  
Gradually narrowing circles, he touched her nipple.  
"Munnaa! Gyiin!"  
Elena's chin jerked up.  
"Vvvuuuu...n! Gah!"

He kneaded her nipple with the vibrator tip.

  

Elena had been looking up at the ceiling but soon slumped.  
"My my my"  
Saira's hand descended, her white fingers stroking Elena's crotch.  
Yuu looked down—the crotch rope was wetter and digging deeper, with surrounding pubic hair thoroughly drenched.  
"Kufu. Came just from nipple play? More sensitive than expected, cute Elena~"  
"Muv..."  
Shaking her light brown hair as if refusing, Elena denied it.  
Yuu smoothed her disheveled hair and whispered:  
"Elena-nee getting more aroused than usual is sexy. Makes me want to pleasure you more."  
"Right!"

Yuu and Saira smiled at each other. Hearing this, Elena sighed wordlessly.  
But her nipples remained erect under Yuu's vibrator, and transparent fluid dripped from her slit—her body likely craved more torment.

  

  

  

  

"Whiiich... ooone... shooould iii... chooose... Alright, you!"

Saira pulled out a box from under the bed—how did she know?—containing three vibrators labeled "Yuu-chin 1-3".  
Elena's favorites for masturbation before reconciling with Yuu.  
Saira chose the pink one labeled "2".  
About 15-16cm long from the forked base. Medium-sized among the three, with a prominently thick glans despite its fancy appearance.

  

Meanwhile, Yuu embraced Elena from behind, using the vibrator on her nipple while pulling the crotch rope deeper, licking her nape, neck, and ears—tormenting her slowly.  
Occasionally pressing his erect cock against her butt, Elena's moans grew increasingly sensual.  
Quivering and moaning loudly with chin raised, she likely came.

  

Silently approaching, Saira knelt before Elena's crotch with the pink vibrator.  
"Like this..."

Curious, Yuu peered as Saira pulled the two crotch ropes apart to create space.

  

"Fufufu, Elena's so soaked. Yuu, touch her too."  
"Ho? Let's see."  
"Muu...n! Gyi!"

  

Elena struggled but her restrained, spread-eagled position only created enticing movements.  
When Yuu and Saira's fingers touched her vaginal opening, a squelching sound followed.  
Their fingers slid in effortlessly to the second knuckle, stirring cloudy, bubbly fluid that overflowed.

  

"Here goes."  
Saira pressed the vibrator tip to her vaginal opening, and it slid in easily with a "nupuri".  
It penetrated deeply with a "zubuzubu".  
"Vwe!? Muguu! Vun! Vaan!"

Recognizing what was inserted from past use, Elena's muffled moans were ambiguous—joy, refusal, or both.

  

It went in smoothly but hadn't reached deep yet.  
Signaled by Saira, Yuu pulled the crotch rope upward from her abdomen.  
The knot pressed against her swollen clitoris.  
"Mugaa! V...gyiin!"  
Elena arched sharply just as the vibrator reached deep.  
"Sis, came again?  
Tonight's Elena comes so easily."  
Elena seemed not to hear, writhing and shaking her hair wildly.  
But Saira wasn't done.  
"Now, switch on!"

*Puchi*—the vibrator's base switch clicked.

Amid Elena's moans, a "guin-guin" operational sound was audible.

  

"Moving inside?"  
Yuu stroked Elena's lower abdomen.  
"Yes. It churns inside the vagina.  
I've used it too—vibrators keep moving until switched off. You can use them until you come.  
But overusing them can make real sex unsatisfying, causing frustration."

  

Men could become too accustomed to masturbating with onaholes, struggling during actual sex.  
In his original world, masturbation-obsessed boys rarely got sexual opportunities anyway.

  

"But... Yuu's different."  
Saira hugged Yuu from behind as he watched Elena.  
"Once you know this cock... vibrators can't satisfy anymore..."  
"Sa-Saira-nee..."

  

Saira's hand slid down Yuu's abdomen, gently stroking his bulging crotch.  
Yuu remained fixated on Elena—gagged with a vibrator inside her, intermittently moaning—letting Saira touch him.

  

  

  

  

  

---

### Author's Afterword

2019/7/10

I mistakenly thought the ball-gag mouth restraint was called "gag ball," but based on feedback, "ball gag" is correct, so I've revised it.  


### Chapter Translation Notes
- Translated "亀甲縛り" as "kikkou shibari (tortoise shell bondage)" to preserve the specific bondage style while making it accessible
- Rendered "チンポ" as "cock" consistently with explicit terminology rules
- Translated "ワレメ" as "slit" for anatomical accuracy
- Preserved Japanese honorifics (-nee for sisters) and name order (Hirose Yuu)
- Transliterated sound effects: "パァン" → "Paan", "むぎぃっ" → "Mugyii"
- Translated "スパンキングラケット" as "spanking racket" to maintain the specialized SM equipment term
- Rendered "ピンクローター" as "pink vibrator" for clarity while preserving the color descriptor
- Kept "Yuu-chin" vibrator names as culturally specific personal labels
- Translated explicit sexual acts without euphemisms (e.g., "膣内を掻き回す" → "churns inside the vagina")
- Maintained SM terminology like "ball gag" and "crotch rope" for accuracy