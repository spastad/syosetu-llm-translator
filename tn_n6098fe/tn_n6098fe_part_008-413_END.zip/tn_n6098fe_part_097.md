## 90. Farewell Party ② ~Slow Sex Please (I want you)~

"Soree!"  
"Whoa!"  

The jersey shorts Yuu wore as pajamas and his trunk-style underwear slid off together.  

"Oh-hoo"  
"Seriously, Saira-neé..."  
"Okay, now raise your hands!"  
"Ba-banzai?"  

Saira looked down at the erect cock standing firm enough to tap his lower abdomen, her eyes narrowing. But her hands didn't stop, pulling his T-shirt up until it slipped over his raised arms.  

"Stay like that, just like that—"  
"Eh? Wait—"  
As his pajamas caught on his outstretched arms, something suddenly bound his forearms from behind.  

"Saira-neé?"  
"It's fine, it's fine."  

Yuu turned to look back at Saira, who winked and whispered:  
"I wanted to restrain you at least once. It's just pretend, not serious. Okay?"  
"Haa... Restrain me for what?"  
"Come on, you know~"  

Saira came around front and hugged Yuu, rubbing her cheek against his exposed chest.  
Yuu sensed this wouldn't end well, but since he planned to have sex anyway, he lightly thought it'd be fine to let experienced Saira do as she pleased.  

"Just no pain, okay?"  
"It won't hurt. I'll make you feel really good instead! Hyah!"  
"Whoa!"  

Where Saira pushed him led to the bed.  
Had he fallen straight back, he'd have hit his head on the wall, but Saira skillfully adjusted his position so he landed diagonally on the bed.  

"Ah— Saira-neé, be gentle, okay?"  
"*slurp*"  

Whether Yuu's words reached her or not, Saira wore a delighted expression as she tied his outstretched hands to ropes extending from both sides of the bed.  
Then turning the opposite way, she bound his legs similarly. As Yuu watched Saira's hips while she hummed and worked, he realized:  
*(She prepared to restrain me too? Not just Elena?)*  
Distracted by Elena's restraints and the ropes' white color matching the sheets, he hadn't noticed them tied to the bedposts. As Saira said, it was just pretend—the binds were loose, not immobilizing, which was reassuring.  

After finishing Yuu's restraints, Saira stepped away from the bed and approached Elena face-to-face, removing her blindfold.  
That was all.  
When Saira moved aside, Elena's field of vision filled with Yuu tied up on the bed. Given the small six-tatami room, she immediately saw Yuu was nearly naked.  
"Mmgggh! Gyaaah! Uuugghhh—!!"  
Her earlier sensual moans vanished, replaced by desperate attempts to communicate.  

Ignoring this, Saira climbed onto the bed, pressing her body flush against Yuu's right side—the wall side—so Elena could see.  

"Ufufu. Let's enjoy ourselves together now.  
Your cock's been hard this whole time—must've been tough?"  
"Ah... yeah"  

Saira poked the glans with her fingertip. Seeing transparent fluid coat her finger, she licked it off without hesitation, then smiled and slowly stroked the shaft.  

"Wanna cum?"  
"U... un"  
Though her touch remained soft, the stimulation brought rising pleasure.  
"But not yet. Who knows when we'll meet again after tonight? I'm going to enjoy Yuu to the fullest."  
Saira brought her face close. Yuu felt a flicker of regret about letting her take charge, but it was too late.  

Saira opened her crescent-moon-shaped mouth, extended her red tongue to lick Yuu's lips, then pried his teeth apart to invade his mouth.  
"Oah..."  
"Mmm... *muph*"  

Her tongue licked his palate, reached deep into his throat, then pressed flat against his tongue. After rubbing top-to-bottom, it moved along his inner cheeks before teasing his gums. Then lifting Yuu's tongue, she tangled hers with his in playful thrusts. Though initially letting Saira ravage his mouth, Yuu actively fought back.  

While her right fingertips traced his cock's shape and her left stroked his head, Saira seemed increasingly aroused by their deep, saliva-swapping kiss. She wriggled against him, using Yuu's body to pleasure herself.  

How long did they kiss?  
When Saira pulled away, a string of saliva stretched from her extended tongue, falling by gravity into Yuu's open mouth.  

"*kufu*. Yuu, so cute. I could eat you up."  
"Se-Saira-neé... *mmph*"  

Chasing the drool, Saira covered Yuu's lips as if devouring them, then planted kisses across his jaw, cheeks, nose, and forehead—*chu*, *chu*—sucking lightly. With Saira's long platinum-blonde hair covering his vision and his immobility, Yuu felt like prey being consumed.  

"Ugh... ah! Aah!"  
"*Mphu*... Yuu's skin... so tasty... *ahphun*"  

Her tongue crawled around his ears, nibbled his earlobes, then stabbed into his ear canal, sending shivers down his spine. When she licked and sucked his neck with wet *pechapecha* sounds, Yuu let out girlish moans. As during their first time, being orally pleasured by a girl felt unexpectedly good. Saira's right hand slowly traced from shaft to base, then gently massaged his balls—less about inducing ejaculation than lovingly caressing his genitals. Plus, with her body pressed against him and legs entwined, writhing, he felt warmth and softness spreading slow pleasure throughout his body.  

"Hyaah! Ah! Ah! Saira... ne... *nku*!"  
Saira's mouth moved from shoulders and collarbones to Yuu's nipples, licking then sucking. Yuu couldn't help but gasp. Her right hand returned to his cockhead, teasing it with three fingertips.  
"Boys feel good here too, huh? *Nfufu*"  
"Ah... ah... maybe"  
"Gonna pamper you more, Yuu"  

Simultaneous attacks: fingers and tongue on his nipples, plus pinching motions on his cockhead. Yuu's body jerked involuntarily. Even the soft, silky hair brushing his chest and armpits became pleasurable.  

"Se-Saira-neé!"  
"Feels good?"  
"U, un. Feels good..."  
"Wanna cum?"  
"W-wanna cum..."  
"Ufu. But not yet."  
"Eeh..."  

Saira gazed delightedly at Yuu's pleading expression, stroked his head lovingly, then planted a wet kiss. As their tongues tapped playfully, she murmured:  
"This time... Yuu lick me"  
"*Mmph*... I'll lick Saira-neé too..."  

Saira straddled him facing away, pressing her butt against his face. She still wore her black negligee—though the hem was hitched up, revealing her translucent black lace panties. Just as Yuu thought she wanted him to lick, he saw her crotch: the black fabric overlapped at the sides, but with her legs spread wide, her intimate parts were fully visible.  

Though familiar with Saira's pussy, her open slit glistened salmon-pink and lewdly slick. Meanwhile, Saira lightly gripped Yuu's cock, peppering kisses on the glans. So Yuu extended his tongue to the dripping slit inches from his nose, licking vigorously as payback.  

*Kuchuu... lerolero, chupa!*  
Saira was clearly aroused too—the more he licked, the more nectar flowed.  

"Hahnnn! Ah... good... so good... Yuu's... just as I expected... so actively perverted... happy... *ahhaan*!"  
"*Fufu*, you're the first girl as lewd as you I've met, Saira-neé"  
"*Amchu... chu, chupaa...* ah! So glad... to have a brother like Yuu who accepts me... *aaaahn*!"  

Unmindful of his face getting soaked, Yuu pressed against her slit, thrusting his tongue deep inside to probe. While moaning, Saira reciprocated by licking every inch of his cock from glans to base.  

"*Aha!* Your cock's... leaking juice... *am... lero, lero, chupaa...* tasty! Nn! Ah! *Hyaan*! S-sucked! Ah... haa... feels so good!"  
"*Kuha!* Feels amazing for me too... nn... ah!"  

Yuu felt his glans fully engulfed. Wrapped in warm mucosa while her tongue probed his urethra, his hips shuddered. Both endured pleasure while orally pleasuring each other. When they neared their limits, Saira raised her hips and spun around. Now in cowgirl position, she smiled mischievously.  

"Nfu. Yuu wanted to cum?"  
"Ah, ah. I was almost there"  
Had his hands been free, he'd have gripped her hips and continued sixty-nine until one climaxed.  

"Cum inside me. I've only had you cum inside me once"  
"Ah—. Right"  

Saying this, Saira straddled Yuu's lower abdomen, rubbing her groin against his hard cock.  
"I want... Yuu's... lots inside me"  
Saira lowered her upper body slowly toward Yuu. In her black negligee begging for his seed, she looked like a succubus. Simultaneously, she rocked her hips minutely, stimulating his cock in a pseudo-penetration—genitals pressed together but not joined.  

With her face breath-close, Yuu couldn't help but plead:  
"Ah... haa... wanna fuck... wanna fuck! Inside Saira-neé... hah, hurry!"  
"Aha! Love that face! Love it! Say more. If you don't... I won't let you in"  
At kissing distance, Saira delivered her final tease.  

"Tch... I wanna shove my cock into Saira-neé's tight pussy... connect deep inside!  
And... cum hard!"  
"If you cum... what'll happen?"  
"Saira-neé... my half-blood sister... I'll knock you up with my cum!"  
"Ufu. So... I'll get knocked up... by my beloved little brother Yuu?"  

The moment Yuu felt his glans enveloped by wet softness, Saira gently covered his lips.  
"Nnnn!"  
"*Mphu... vgh, agh...*"  

With mouths sealed, Yuu and Saira moaned wordlessly as they joined. Yuu thought he heard Elena's muffled cries, but the long-awaited penetration made it feel distant.  

"O... ooooh... gyaaah! Th-this... I wanted this!"  
When his cock hit her deepest point, Saira threw her head back with a cry, then pressed her cheek against his.  
"Saira-neé?"  
Disheveled hair spilled over Yuu's face. Breathing in its sweet scent, he tried to look at her.  
"Ah..."  
Saira kept her face down and began moving her hips—slowly, slowly.  

Contrary to expectations of vigorous thrusting, her movements were gentle.  
But that didn't mean it felt bad. Saira's vaginal walls tightly squeezed Yuu's cock. Pleasure spread gradually, slowly, from his hips throughout his body—frustrating yet intensely arousing. If near-ejaculation pleasure was 99, this hovered around 85.  

"Ah... kuuuu... feels good..."  
"Haa, haa... I-I wanted... to try this slow kind... at least once.  
Because... Yuu's cock... isn't just hard and big... it's sooo strong!"  

Saira's hot breath washed over him as she rubbed her cheek against his. She seemed to be restraining her urge to move faster, savoring Yuu with her whole body. Pressed skin-to-skin, he felt her softness and warmth. Not lust-driven sex, but mutual sensual amplification—gentle and blissful. An uncommon sensation.  

How long did they continue slow sex?  
10 minutes? 20?  
Time felt elongated in the repeatedly overwritten, dissolving pleasure. Finally, Saira lifted her chin and moaned:  

"Haa... can't... anymore... Yu... u..."  
"Se-Saira-neé... I-I'm feeling... incredible too..."  

Saira looked at Yuu, her supporting arms trembling, eyes feverish and moist. Though barely moving with his cock buried deep, arousal clearly intensified.  

"Yeeeees... cumming!"  
Quieter than before but like a boat tossed in waves, Saira reached ecstasy. That instant, Yuu felt crushing tightness and groaned involuntarily, thrusting upward.  
"Yah! Yu-Yuu!? I-I'm still cummiiing!"  
Unlike men, women experience longer climaxes—this one seemed especially prolonged. But Yuu too reached his limit.  

"Can't... hold back... ahh... too good... now!"  
He pistoned his hips, drilling deep into her.  
"Hah! Hah! You... bastard... cumming again! C-cumming in my womb! *Gyaah*! Yuu... cock so good... mind going blank! *Hyaa*! G-gonna faint!"  
"C-c-cumming! Cumming! Cumming!"  

Saira could no longer move, just clinging to Yuu while babbling through continuous vaginal orgasms. Then Yuu—who'd endured all night—finally ejaculated.  

"Hyaaaaaaaaaaaaaaaaaaah... ah! Ah! Ah! Ah! Ah! Ah! Ah! Ah! Nnnnnnnnn~ unyun"  

Throughout Yuu's ejaculation, Saira screamed at length, shuddering violently before finally going limp.  

---

### Author's Afterword

I considered including Elena being anally teased in the beginning like the previous chapter, but decided it was better to focus solely on the main event with Saira rather than continue with Elena.  

Regarding the subtitle, I considered changing the original title but couldn't think of a good alternative, so I left the obscured characters as is.

### Chapter Translation Notes
- Translated "スローな○○にしてくれ" as "Slow Sex Please" based on contextual cues and author's note
- Preserved Japanese honorifics (-neé for Saira)
- Translated explicit anatomical/sexual terms directly (e.g., "チンポ" → "cock", "マンコ" → "pussy")
- Transliterated sound effects (e.g., "Soree!" for そーれ, "kuchuu" for くちゅぅ)
- Maintained Japanese name order (Hirose Yuu) per style guide
- Italicized internal monologues per formatting rules
- Rendered simultaneous orgasm dialogue with double quotes per special case formatting