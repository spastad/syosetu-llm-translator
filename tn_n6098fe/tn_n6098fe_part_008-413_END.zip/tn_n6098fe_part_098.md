## 91. Farewell Party ③ ~Instinct~

*(Phew. That felt amazing. It's nice to have this kind of thing occasionally. Well then...)*

Yuu tried moving his bound wrists.  
As expected since they weren't meant for serious restraint, it wasn't tight.  
He should be able to free himself somehow.  

Instead of forcing them apart, he rubbed his hands together like flies. As he moved them up and down, he felt the binding towel loosening.  
When his right hand slipped out, the rest was easy.  

With both hands free, Yuu paused to think.  
To untie the rope binding his feet, he'd need to sit up - but Saira was currently limp and sprawled on top of him.  

"Sorry, Saira-neé."  
"Ah?"  

He slid his arms under Saira's sides, pulled her close to withdraw his cock, then shifted her sideways.  
Her small frame made moving her easy.  
Saira seemed still half-asleep and didn't resist.  

Pushing Saira aside, Yuu sat up and examined his ankle restraints.  
They were tied with ribbon knots, not tight knots, so the rope came undone easily.  
When he sat up, he noticed Elena bound against the wall, watching him intently, but he'd have to leave her for now.  

"Huh? Yu...u...?"  
Saira finally noticed Yuu had moved away and sat up on his own.  
Yuu smiled at Saira as she gazed at him with drowsy eyes.  

"Now it's my turn to return the favor."  
"Hweh?"  

Yuu turned the sideways-lying Saira onto her stomach, grabbed her hips, and lifted her buttocks.  
Looking at her vaginal opening, semen was slowly flowing back out.  

"Whoops... Need to plug this up so the creampie doesn't leak out."  
"Huh? Yuu? Wha-what?"  
"Is this position new for you, Saira-neé?"  

Yuu covered her from behind, pressed his fully erect cock against her, and thrust deep inside in one motion.  
"Ugh... aahn! Wait... your cock... ooh! W-wait... aaaahhh! This is... aahn!"  

Even Saira seemed unfamiliar with rear-entry.  
Her slender back looked fragile enough to break with rough handling. Her platinum blonde hair spread wildly as she shook her head, yet its beauty remained unchanged.  
Yuu himself felt uncontrollably aroused at the thought of fucking Saira from behind like this.  
Meanwhile, Saira seemed bewildered by the new experience, her earlier succubus-like lewdness gone.  
But feeling Yuu's cock inside her again reignited her passion, and she looked back at him with a seductive expression.  

*Pah! Pah! Pahn!*  
"Ahn! Ahn! Aaahn!"  

Grabbing Saira's shapely buttocks with both hands, Yuu began thrusting violently from the start.  
From stillness to motion - a complete shift from their earlier slow sex to fierce hip movements.  

"Yuu... so... rough!"  
"How do you like this, Saira-neé?"  
"G-good... ahn! So good... like an animal... my head's going stupid. Ahn, more!"  
"Hehe, glad you like it. Can I be a bit rougher?"  
"Do it! Fuck me hard!"  
"Okay."  

Yuu grabbed Saira's slender upper arms and pulled them back.  
Her prone body was pulled upright. "Haah... haah... eh? Kyahn!"  
Holding Saira's arms, Yuu slammed his hips against her.  
"Ah! Ah! Aaahn! What... this... sooo good! So good! I'm... I'm cumming! I'm cumming!"  

It was a position that looked like outright rape, even among rear-entry positions.  
He'd only seen it in eroge and AV, never tried it himself, but felt compelled now.  
Though seemingly rough, it connected deep inside.  
With each thrust, Yuu's cock knocked against her cervix. Saira thrashed her hair, tongue lolling as she moaned.  
Her well-shaped breasts jiggled *purun purun*, though Yuu couldn't see.  

*Pah! Pah! Pahn!* The sound of hips slapping buttocks echoed as Saira's moans grew louder.  
"Ah... aheee... I-I'm cummiiing... my insides... being trained by Yuu's cock... eh? Ah! Already... cumming! I'm cummiiiiiiiiiiing!!!"  

"Was I too rough earlier? Sorry, Saira-neé."  
"I-it's okay... felt... so good... don't... worry... ahn!"  
"Hehe, good. I wanted to try this since you're smaller than me. How was it?"  
"Ah! Ah! Good! Good! First time... but I... like this too. Feels like... Yuu's embracing me... and it's... deep inside!"  

Switching from arm-pulling rear-entry, Yuu now held Saira from behind in a seated position, moving his hips in circles.  
Her smaller frame made this easier.  
Moving to the bed's edge, Yuu hooked his hands behind Saira's knees, spreading her legs wide - putting their joining on full display for Elena.  
Elena couldn't look away.  

"Saira-neé, can you see? Where we're connected."  
He deliberately spread her legs wider and thrust upward.  
Saira looked down at her crotch.  
"Ca... can see. Me and Yuu... connected like this... ah... so deep... my womb... being knocked..."  
"Guh... Saira-neé, I'm... close."  
"O-okay... give it... to me... fill me... with your seed..."  

Saira twisted around, reaching back to stroke Yuu's face.  
Yuu leaned in, tongues entwining in a deep *rero rero chupa chupa* kiss.  

He'd nearly cum earlier during the rough fucking but held back for this position - something he'd wanted to try.  
But even Yuu was reaching his limit.  
Pushing his hips upward faster for the finale, *juppo juppo* lewd sounds increased as milky fluid seeped out, soaking the bed's edge and floor.  

"Nngh! Khaa! Feels... good inside you... cumming!"  
"Aaahn! Give it! Give it! Aaahhh! Yes! Me too! Cumming again!"  

Shaking the bed *gishi gishi*, Yuu headed for the finish.  
"Haah! Haah! Cumming! Giving you lots! Get pregnant... with my... sperm, Saira-neé!"  
"Ahn! Ahn! Cumming cumming cumming! I'll get pregnant with Yuu's seeeed! Fill me... kyahn!"  

As if urged by Saira's words, Yuu thrust deep into her vaginal depths and released, *doku doku* unleashing his seed.  
"Ah... ahaa... it's coming... so much thick Yuu sperm... ahfoo..."  
Saira caressed her lower abdomen contentedly, then suddenly went limp as if a string had been cut.  

Yuu pulled away from the limp Saira, laid her on the bed, and stood up.  
He felt fatigued and thirsty.  
He noticed Elena's intense gaze, clearly wanting something.  
But he only untied the leash binding her to the doorknob before leaving the room.  

Returning, Yuu saw Elena collapsed face-down in a pathetic state.  
Gagged and *muu muu* moaning, she desperately looked up as Yuu helped her up, smiling.  
"Thought I abandoned you? Wrong. Figured you'd be thirsty too."  
Yuu carried a 1-liter bottle of barley tea, glasses, and towels over his arm.  

Placing them on a table, he first removed the ball gag from Elena's mouth.  
He wiped her drool-soaked chin with a towel.  
"Yu...u... Yuu! Yuu! Yuuuu!"  
Overwhelmed, Elena hoarsely repeated his name.  

After lightly patting her head, he poured tea into a glass.  
"Open up, neé-san."  
As Elena obediently opened her mouth, Yuu gulped tea from the glass.  
He transferred it directly into her open mouth.  
"Fwah!?"  
Startled but delighted, Elena accepted the mouth-to-mouth feeding, her eyes softening.  

"Good, neé-san?"  
"Un! Best I've ever had."  
"Haha, exaggerating. More?"  
"Un! Gimme gimme!"  
Elena opened and closed her mouth like a baby bird begging for food.  

After three more mouthfuls, Yuu slipped his tongue in. Elena happily tangled tongues with him - seemingly craving his saliva more than tea.  

Breaking the deep kiss, Elena looked up with a longing expression, tongue still out.  
"I'll give neé-san something better to suck."  
"Aha!"  
As Yuu knelt before her and thrust his hips forward, Elena's eyes formed heart shapes.  

"Amh, amh... lenroo... ahfoo... delicious... Yuu's... cock... amh... mhm mhm... lew jupaa... ufhn! Getting bigger!"  

Though still bound, Elena sucked his cock with dog-like enthusiasm.  
She licked all over with her tongue, face bobbing *beron beron*, then took it deep, sucking *juru juru*.  
Yuu's cock quickly swelled, standing tall.  
Eyelids fluttering, Elena traced its veins with her tongue tip, kissed the glans repeatedly, then diligently licked along the underside.  

"Kuh... ahh, feels good, neé-san."  
"Ah... you know."  
Hearing Yuu, Elena looked up as if to say something.  
Yuu placed a hand on her head, stroking gently.  
"Go ahead."  
Seeing his smile, Elena burst out with previously unspoken feelings.  

"I... I held back! The whole time! Watching Yuu and Saira have such amazing sex twice! I wanted you to do me like that too! But watching you two right in front of me... jealousy and envy and this weird horny feeling got all mixed up... My body ached unbearably, and Yuu-chin #2 kept vibrating inside me... felt better than masturbating. But I couldn't cum no matter how close I got... so frustrating! So... what I mean is... well... I want Yuu's cock in my pussy! I want it so bad! And... like Saira... cum inside me! Please... please! Just for tonight... I want impregnation sex too..."  

Was this confession beyond sister-complex - pure female instinct?  
Tears spilled from Elena's eyes.  
Yuu had intended to have full sex with Saira for her farewell.  
He'd expected a threesome, but Saira's plan left Elena neglected.  
Yuu thought she deserved attention now - but hadn't expected such desperate begging for impregnation.  

Yuu recalled what Ministry of Health official Inui Rumiko had said:  
*Ignore the risks of incest. Impregnate your half-sister and let her bear your child.*  
He'd already creampied Miku and Saira last Sunday.  
So why not Elena too?  
But what would their relationship become if a child was born?  

"Yuu?"  
Elena looked up anxiously at his silence.  
"Ah... it's nothing."  
For now, Yuu decided to untie Elena's legs.  

However, Elena couldn't stand after prolonged restraint, remaining on all fours.  
"Yuu... um..."  
Seeing her defenselessly presented buttocks, an idea struck Yuu.  
He stroked her shapely buttocks as he spoke.  
"Neé-san, head toward the bed like that. I'll support you."  
"...Un."  

He considered untying her arms but doubted he could without Saira.  
Supporting Elena's confused form from behind, he guided her to the bed where Saira lay - in the same position they'd used earlier, on her back sideways at the edge, legs spread.  
He positioned Elena's face at Saira's crotch.  
Then he turned off and removed the vibrator still inserted in Elena's pussy - dripping with love juice.  

"I'll enter you from behind. Then you can repay Saira-neé properly?"  
"Ahh~ hehe, okay."  
"Un... hn?"  

When Saira lifted her head at the crotch sensation, Elena latched onto her vaginal opening, sucking out the overflowing semen.  
"Hyahn! Wha... eh? E-Elena? Ah, stop... don't suck!"  
"Give me Yuu's sperm too!"  
"Ah, ah! Still sensitive!"  

Watching Elena lick Saira, Yuu spread Elena's buttocks and thrust his cock into her dripping wet entrance.  
*(This is a threesome. Saira-neé will remember this fondly too.)*  
Nodding to himself, Yuu penetrated Elena without hesitation.  


### Chapter Translation Notes
- Translated "本能" as "Instinct" to convey primal urges theme
- Preserved Japanese honorifics (-neé for Saira, -san for Elena)
- Translated explicit sexual terms literally (e.g., "膣口" → "vaginal opening", "精液" → "semen")
- Transliterated sound effects (e.g., "ぱん" → "pah", "じゅっぽ" → "juppo")
- Maintained original name order (Hirose Yuu, not Yuu Hirose)
- Used italics for internal monologues per style guide
- Translated "せーし" as "seed" for contextual accuracy in impregnation scenes
- Preserved cultural terms like "neé-san" (elder sister) without localization
- Translated "中出し" as "creampie" for explicit sexual terminology requirement