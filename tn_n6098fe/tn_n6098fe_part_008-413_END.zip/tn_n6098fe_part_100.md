## 93. Birthday Party ① ~Another Saturday~

Saturday, June 16th.

After finishing half-day classes, Yuu was in the student council room as usual.

Lunch consisted of bread bought from the school store with Sayaka and the others. Though Yuu usually ate boxed lunches prepared by the housekeeper on weekdays, he hadn't yet used the cafeteria or school store. While both were certainly cheaper than commercial options, he'd heard they became extremely crowded with female students during lunch hour, so most boys avoided them. Yuu wanted to try them eventually, but since only the school store was open this Saturday and he'd heard fierce battles broke out among sports club girls in the afternoon, he felt somewhat hesitant.

Thus today too, he gratefully accepted the bread Sayaka and the others had obtained after their fierce struggle—of course, he paid for it.

With three girls as company, mealtime became quite lively. Topics jumped everywhere—from the humid rainy weather since the rainy season began, to that morning's news, school life, and rumors about teachers and friends. The saying "three women make a market" certainly held true. The 40-year-old Yuu from before his rebirth might have found such conversations incomprehensible and noisy if he'd overheard them on a train or in a store.

But now, since the three before him were effectively the same generation and he shared an intimate relationship with them after multiple sexual encounters, he found it heartwarming. Particularly because Sayaka and Riko spoke with unexpected maturity and composure for their age. Only Emi acted her age with bubbly energy, which blended well as seasoning between the other two. Yuu mostly watched the three seniors chatting with a gentle smile, only joining when addressed.

The conversation naturally shifted to student council matters—specifically the joint event with Saiei Academy (revived after 10 years, the first since becoming co-ed) and the gender exchange event scheduled for the same evening in July. They were currently finalizing the schedule, tentatively set for July 27th right after summer break began—still over a month away. But with final exams immediately before, they wanted to make progress early. For the gender exchange event, they needed to gather trusted volunteers without leaking information externally.

"Haah... This seems tough no matter how I look at it."  
"Considering final exams, early July will be crucial."

Sayaka and Riko held two A4 sheets after finishing their sweet breads. One contained the joint event schedule draft faxed from Saiei Academy's student council. The other was labeled "㊙" in red—Sairei Academy's July gender exchange event schedule. The three days before finals were blank, leaving about one month of actual preparation. Additionally, starting July, biweekly Saturday meetings with Saiei's student council would begin. Until then, communication would mainly be via phone and fax.

"I wish we could say no, but it's too late now, isn't it?"  
"Not just Saiei—even the board chair got unusually enthusiastic..."  
"Exactly. They're getting ahead of themselves when we've barely started."

Apparently, when they reported the quiz event idea to the board, the chair was delighted and suggested expanding it next year to all group high schools as the "Ayakuni Group Cup High School Quiz Championship." However, Sayaka and the others were wary of Saiei Academy's student council, feeling uneasy about whether things would go smoothly. In fact, they watched Yuu like protective older sisters worried about a younger brother attracting stalkers.

"But holding a school-wide event right after summer break begins, when everyone's feeling liberated—if it succeeds, it'll become an unforgettable memory. With this student council, I'm sure it'll work out." For Yuu, both the Newcomer Orienteering and sports festival had been special events to bond with first-year girls. He was also less wary of Saiei's student council than the others. Seeing Yuu's smile, Sayaka and the others exchanged glances.

"Fufu. Yuu-kun is so optimistic."  
"If Yuu-kun says that, strangely enough I feel like it might be okay."  
"You're the best, Yu-kun!"  
"Hahaha. Not really."

Yuu's words brightened the mood. That was good, but then the three began bombarding him with questions, leaving him flustered.

After lunch around 1:30 PM, Sayaka used the student council room phone to contact Saiei Academy's student council for schedule adjustments. Sayaka kept the conversation strictly businesslike, hanging up after about 10 minutes with a wry smile. When asked why, she explained that their student council president Mitsuse Rinne had persistently demanded to speak with Yuu, but Sayaka flatly refused with a "but I refuse" before hanging up.

*(That young lady... She was a flashy beauty, but quite an interesting person.)*  
That was the extent of Yuu's impression.

Today's business finished, the four left the student council room together. Usually, only Yuu would take the bus home from the second building, but today they all went together—because they were holding a birthday party at Sayaka's apartment. In fact, the real fun was just beginning.  
"The rain won't stop~"  
"It is the rainy season after all."

Exiting the dormitory building containing the student council room, the four looked up at the sky. Rain had fallen steadily all day. Looking over the back garden, the greenery had grown more vigorously compared to when Yuu first visited the student council. Hydrangeas and azaleas bloomed in colorful profusion, a feast for the eyes.

"Since it's raining, shall we take a taxi?"  
Hearing Sayaka say this so casually, Yuu felt mildly surprised—he'd heard the apartment was only a 10-minute walk. But recalling past experiences in this world, he understood. Here, men never walked alone without multiple guards including protection officers, using cars even for short distances whenever possible. Seeing Riko and Emi nod naturally confirmed this. Sayaka's suggestion wasn't due to her family's wealth, but concern for Yuu's safety.

What if Yuu insisted on walking? Even with three companions, leaving school would expose him to countless female gazes. Warnings already circulated about suspicious women targeting boys near Sairei Academy. Plus, Sayaka's apartment was in a newly developed residential area with fewer hiding spots. If Yuu attracted attention like before, causing a panic where women swarmed, the three might get injured protecting him. Yuu didn't want that. After quickly considering this, he obediently agreed.

Using the green payphone by the management building's front desk, he called a taxi company whose number was posted there. It arrived in under 10 minutes.

Naturally arriving at the one-meter fare distance, they got out before twin apartment towers. Both were 10 stories tall—the right for singles, the left for families with the upper half reserved for families with boys. Adjacent to a park, across the road stood about 10 cream-and-dark-brown houses in a subdivision. One covered in blue sheets appeared under construction. Surrounded by green spaces, this area seemed recently developed.

Perfectly timed to avoid notice, they took the elevator directly to the 10th floor. Corner unit 1001 was Sayaka's home.

"Come on in."  
""""Welcome!""""  
""Whoa, it's huge!""

Riko had stayed over multiple times, but Yuu and Emi exclaimed in admiration upon their first visit. Was this really a 1LDK? While the kitchen was appropriately sized for one person, the combined dining and living area spanned about 20 tatami mats—luxurious for a single occupant, almost enough for two.

"Since we're here—I'm gonna check out Sayaka-senpai's place!"  
"Ah, me too."  
"Eh? Ah, wait!"

Emi boldly opened doors without hesitation. Yuu followed, intrigued. Unlike typical single-unit baths, the toilet and bathroom were separate—comparable to Yuu's apartment. The 8-tatami Western-style bedroom had a dresser and vanity against the wall, plus a king-sized bed dominating the space. They only peeked without rudely jumping on the bed, but the rose-like fragrance and imagining Sayaka sleeping there disheveled made Yuu feel a bit flushed.

"Hey! You two! Come sit down over here!"  
""Yes!""

Perhaps embarrassed, a slightly blushing Sayaka scolded them. Yuu and Emi returned to the living room sofa while Riko watched with an "oh dear" expression.

"Nice apartment. Not just tidy, but very classy."  
"Fufu. I'd love to say I'm happy to hear that from you, Yuu-kun... but actually, the regular cleaning is thanks to our housekeeper who comes every other weekday."

Sitting on the L-shaped sofa, Yuu looked around. Seating arrangement:  
Emi  
Riko  
Yuu - Sayaka  

As punishment for opening doors, Emi was separated from Yuu and sulking slightly. Meanwhile, Riko—familiar with the place—had prepared chilled green tea to quench their thirst.

A Japanese landscape painting hung on the wall. In the corner sat a snake plant (Sansevieria) with tiger-striped leaves. A 24-inch CRT TV stood in another corner. On a sturdy dark wood grain sideboard with half-drawers and half-glass doors sat a silver mini-component stereo, topped with a framed photo of a family of four. Nearby, a colorful bookshelf's lower shelves held thick economics/business books and paperbacks, while middle and upper shelves were packed with paperbacks and manga.

Yuu had never entered a teenage girl's room except his sister's—and his pre-rebirth sister's room was uncharacteristically plain, while Elena's was a mess, so no reference. Sayaka's room felt far from typical teenage girl quarters, exuding refined, mature cleanliness—thanks to the housekeeper who came every other weekday. He wondered if her childhood home might reveal more personality. He hoped to see it someday.

"But it feels strange. Usually only Sayaka and I are in this room, but now with Yuu-kun, all four of us are here."  
"Yeah... definitely."

Sayaka and Riko exchanged smiles. Though still in uniforms, the space felt more relaxing than the student council room. And with Yuu beside her, Riko's heartbeat quickened. When Yuu picked up his glass and gulped, his Adam's apple bobbed. Watching from the corner of her eye, Riko subtly closed the gap between them to a barely-touching distance. Yuu deliberately pressed against her.

"Ah!"

Despite initiating the closeness, Riko blushed when their bodies touched. Though they'd had sex multiple times, her occasional shyness was adorable. Yuu rested his head on Riko's shoulder just as Emi raised her hand.

"Heeey! I don't think it's time for cuddling yet!"  
"Hmm. I quite agree."

Sayaka nodded with exaggerated seriousness.

Despite some fooling around, after chatting awhile, it approached 4 PM.  
"Right, right. As Yuu-kun requested, I had the ingredients bought and stored in the fridge. But are you sure about this?"  
When Sayaka suggested ordering takeout for dinner, Yuu had insisted on cooking since it was a special occasion. He'd decided on hamburg steak. Though Elena was an adult (18) in this world, she loved kid-friendly meals, so Yuu often made curry, hamburg steak, or spaghetti on weekends. The girls would handle the whole cake. Yuu wanted to go shopping together but couldn't, so the housekeeper had bought everything beforehand. The three (excluding Sayaka) split the ingredient costs. Sayaka protested, but since she'd provided her apartment and paid for the taxi, Yuu, Riko, and Emi had decided this upon arrival.

"Of course. I cook on my days off at home, so leave it to me. By the way, should someone help? Who here has cooking experience?"  
Sayaka quickly averted her eyes.  
"I can cook rice and miso soup, but..."  
Emi spoke unconfidently.  
"Leave it to me. I can handle most things."  
Riko puffed out her modest chest.

"Then shall we cook together?"  
"Ufu. Sure."

When Yuu took Riko's hand, she smiled happily.  
"In the meantime, Emi and I will work on something else."  
"Y-yes..."

Sayaka, seemingly bad at housework, looked relieved while Emi appeared slightly disappointed.

"Kuh... Onions stinging my eyes. Tears..."  
"Here. I'll wipe them."  
"Thanks."

Yuu had been efficiently dicing onions *ton ton* when tears welled up. Riko wiped them with a handkerchief. After washing rice and setting the cooker, they divided tasks—Yuu on the main hamburg steak, Riko on glazed carrots and mashed potatoes. Though somewhat labor-intensive, hamburg steak wasn't too hard once you got the hang of it.

Riko looked quite professional in her sailor uniform topped with a stylish dark blue apron featuring a moonlit night design. Taller than Yuu with long legs and a slender build, she'd tied her distinctive long hair over one shoulder, exposing her delicate nape—always captivating. In short, she was the serious, capable older-sister type. Though her silver-framed glasses often gave a cool impression, she'd shown various expressions since growing close to Yuu.

Yuu liked Riko very much too. So in the compact single-person kitchen, he deliberately brushed against her bottom when passing behind, enjoying their playful physical contact while cooking. When Yuu did this, Riko—now accustomed—would press close with mischievous eyes.

Sayaka and Emi watched Yuu and Riko's flirty cooking session with narrowed eyes while decorating a birthday corkboard. They made a large "Happy Birthday!" message with colored paper, adding "6/1 Komatsu Sayaka" and "6/30 Hirose Yuu" below. Riko (September) and Emi (December) would go on subsequent lines. After decorating with glitter stickers and washi tape, they planned to add photos taken today below. They'd store the board at Sayaka's apartment for reuse at September and December birthday parties.

While cooling sautéed onions, Riko started glazed carrots and mashed potatoes. Though somewhat involved, hamburg steak wasn't difficult once mastered. After thoroughly kneading the meat mixture, Yuu used ice-water-chilled hands to portion it, tossing between palms to remove air bubbles before shaping into flat ovals.

"Ah, smells delicious. You're good at cooking, Riko."  
"Well, yeah. At home, Mom's busy with work so I handle most chores. You're more skilled than I imagined too, Yuu-kun. You'd make a good son-in-law."  
"Haha... son-in-law?"  
In this world, men who could cook were considered domestic and desirable.

"I think... it shouldn't matter who cooks after marriage—man or woman. I'd want to cook for my wife if she likes my dishes, and I'd want to eat hers too. Ah! So Riko and I are perfectly compatible cooking-wise..."  
"Y-y-yes. I want to try Yuu-kun's cooking too, and I'd like to cook for you too..."

Perhaps because words like "marriage" and "compatibility" came up suddenly, Riko blushed and looked down. But spotting the glazed carrots, she picked one up with chopsticks, blew on it, and offered it to Yuu.

"Want to taste?"  
"Yeah."  
"Here, say ah~"  
"Ah~... Mmm, delicious!"  
"Really!? I'm glad!"

Seeing this, Emi deliberately remarked:  
"Ah~ I'm getting hungry. Is dinner ready yet?"  
"Y-yes... I'm really looking forward to Yuu-kun's hand-kneaded hamburg steak. Yeah."

Noticing their stares, Yuu smiled wryly and resumed cooking.

---

### Author's Afterword

The lead-up to the apartment took too long, and somehow Riko's flirting got included, so we didn't reach the meal. The meal, gift exchange, and nighttime fun will be in the next installment.

2019/7/15  
Revised the recipe and added a bit more detail to the hamburg steak preparation.

2019/7/19  
Changed the protagonist's thoughts and dialogue when told to call a taxi upon leaving school.

### Chapter Translation Notes
- Translated "お誕生会" as "Birthday Party" to match previous terminology
- Preserved Japanese honorifics (-kun, -senpai) per style rules
- Transliterated sound effects: "トントン" → "*ton ton*", "ゴクゴク" → "*goku goku*"
- Translated cooking terms literally: "粉吹き芋" → "mashed potatoes", "グラッセ" → "glazed"
- Maintained Japanese name order: "光瀬 凛音" → "Mitsuse Rinne"
- Rendered internal monologue in italics: "（あのお嬢様の…）" → "*(That young lady...)*"
- Used explicit anatomical term "Adam's apple" for "喉仏"
- Translated "ハンバーグ" as "hamburg steak" to distinguish from American hamburgers