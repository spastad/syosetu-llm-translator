## 94. Birthday Party ② ~Present~

"Waaah! What an incredible feast!"  
"Ooh, this is..."

Emi exclaimed in delight while Sayaka was speechless.

This was their reaction when called to the table after all dishes were prepared and arranged. Though they were standard home-style dishes, even Sayaka—who as an ojou-sama should be accustomed to feasts—looked astonished, which satisfied Yuu. That said, the presentation was thanks to Riko. Unlike Yuu who prioritized taste over appearance, Riko's meticulous personality was better suited for plating.

The rice and consommé soup accompanied the main dish—large hamburg steaks that dominated the table. Supporting players included glazed carrots, mashed potatoes, and a colorful plate of pre-chopped cucumbers and lettuce. Since the apartment only had two matching plates (due to single-person living), they had to use mismatched sets—an unavoidable compromise.

At the table's center sat a strawberry and whipped cream decorated cake. Atop it rested a chocolate-inscribed sugar candy reading "Happy Birthday," reminiscent of childhood memories. Though the dining table usually accommodated one or two people comfortably, it now overflowed with four full meals plus the cake.

"First, let's have you two blow out the candles," Riko said, lighting two candles on the cake before turning off the room lights. Two small orange flames flickered, creating a solemn atmosphere. "Ready? Happy birthday to you♪" Emi began clapping and singing the familiar birthday tune, substituting "Yuu & Sayaka" at the name part.

After the song ended with applause, the seated Yuu and Sayaka—positioned at the table's far side—exchanged shy glances, thoroughly embarrassed.

"Shall we then?"  
"Mmh."

Yuu reached for Sayaka's hand, interlacing their fingers as he guided her face toward the cake. ""Fuuu"" With one breath, both candle flames extinguished amid renewed applause.

"Now! Let's eat while it's warm! It's Yuu-kun and Riko's handmade meal after all!"  
"Right."

***

Regarding hamburg steak seasoning, demi-glace or ketchup-heavy tomato sauce are standard. Yuu had improvised a Japanese-style grated radish sauce upon finding half a daikon radish in the refrigerator—soy sauce surprisingly complements meat dishes.

The hamburg steaks boasted perfect browning, though their shape wasn't restaurant-perfect. Thick and voluminous, they avoided the common pitfalls of being burnt outside yet raw inside—a result of high-heat cooking. In his previous life, Yuu had followed online recipes to make batches for freezing. The key was medium-to-low heat slow cooking, letting residual heat finish the center after turning off the flame.

Just to be safe, Yuu first pierced a steak with chopsticks. Juices oozed out as steam rose. Seeing no redness at the center, he sighed in relief—perfectly cooked.

"Mmph... Ooh, delicious! This is the most amazing hamburg steak I've ever had! I'm moved!"  
"Ooh... Not only does the meat's umami come through strongly, but the refreshing grated radish with soy sauce creates such a blissful harmony. This is dangerously addictive."  
"I knew about Japanese-style hamburg steak, but topping it with grated radish is new. I love it. Maybe I'll try making it at home sometime."  
"Glad you like it."

Emi, Sayaka, and Riko reacted in turn. Apparently, Japanese-style grated radish hamburg steak wasn't common in this world. Yuu's improvisation earned rave reviews, much to his relief.

"The glazed carrots have just the right sweetness, the mashed potatoes are perfect, and the soup is delicious too!"  
"Yeah. I know from the dinners you make when staying over—Riko's cooking is reliable."  
"Side vegetables often feel like afterthoughts, but delicious ones make such a difference!"  
"Th-thank you..."

Praised by everyone, Riko smiled shyly.

"Umm, Yuu-kun?"  
"What is it, Emi?"

Having eaten vigorously, Emi now addressed Yuu across the table more calmly. "Could you teach me cooking sometime?" Though Yuu suspected she mainly wanted kitchen time together, he welcomed the idea. "Sure. Starting with simple dishes. But where should we teach?"

Since Martina and Elena had asked to meet his girlfriends when he revealed their relationship, he'd considered inviting them home. Conversely, he wanted to visit Emi's house too—though cooking there seemed impractical.

"Why not use the home economics room?"  
"Brilliant! We could make it a new student council tradition—Yuu-kun's cooking class!"  
Riko's suggestion immediately excited Emi.  
"That might require lottery draws from overwhelming applicants?"  
"Oh? Sayaka should definitely learn too. We'll make a special slot for you."  
"Eh... M-me?"

Suddenly addressed by Riko, Sayaka flustered.  
"But we'll need separate courses. Sayaka would naturally be in the beginner course."  
"Eh? You can't cook at all?"  
Under Yuu's gaze, Sayaka broke into cold sweat, avoiding eye contact.  
"She once used detergent when washing rice..."  
"Eeeh?!"

Yuu nodded—inexperienced cooks sometimes made such unconventional mistakes—then took Sayaka's hand. "No worries! I'll teach you hands-on!"  
"Um... I-I suppose I'll rely on you then."  
Cornered by Yuu, Sayaka reluctantly nodded—uncharacteristically compliant.

Emi joined in. When Riko also expressed interest, they decided to hold student council cooking/dining sessions.

***

""Thank you for the meal!""  
""Hope you enjoyed it.""  
"Aaahn, I'm so full~ But I still want cake!"  
"We can eat it later."  
"Yeah. We're staying over tonight anyway."  
"Ah... yeah."  
"Like a night snack?"  
"Late-night eating makes you fat though..."  
"Don't worry. We'll exercise it off."

Hearing Yuu, Sayaka and the others exchanged meaningful looks. After finishing dinner, they stored the cake in the refrigerator since no one had room for dessert yet.

Over post-meal tea, the gift exchange began.

"Now then, Yuu-kun! Happy 16th birthday!"  
""Happy birthday!""  
"Eh? Me first?"  
"Yes yes, gentleman first!"

An unfamiliar phrase in this reincarnated world—likely meaning "men first" instead of "ladies first." Seeing all three holding gifts with beaming smiles, Yuu decided to receive first.

"Starting with me. I'd be happy if you use it," Sayaka offered a rectangular package (15cm×5cm). "What is it? May I open it now?"  
"Of course."

Unwrapping the department-store paper revealed a box containing a wooden case. "This is...? Ah!" Handling it like fragile glass, Yuu opened it to find a navy-and-brass ballpoint pen. "A ballpoint pen?"  
"Yes. I considered a classic wristwatch first, but you already have a proper one. Stationery seemed practical since students can never have too much. I debated a fountain pen but thought a ballpoint more practical for school use."

Though she didn't show it often, Sayaka's parents were corporate executives. Her taste was undoubtedly refined. This wasn't an ordinary pen—its appearance alone suggested unaffordable luxury for most students. The engraved foreign letters indicated an overseas brand. Holding it, Yuu felt perfect thickness and satisfying weight.

"Ooh... writes incredibly smoothly."  
"Fufu. Do you like it?"

Yuu returned the pen to its case, then faced Sayaka, enveloping her hands in his. "Yu... Yuu-kun?" Beyond the luxury item, Yuu treasured Sayaka's thoughtful selection. "Thank you, Sayaka. I'm grateful for such a wonderful gift." Expressing heartfelt thanks, he hugged her. "Hyah!? Yu...u...kun"

"Mistake. Starting with Sayaka..."  
"True," Emi nodded subtly.

"After Sayaka's gift, mine feels inadequate... but I'd love you to have it since I prepared it."  
"Yeah! We picked something that'd suit Yuu-kun—Riko-senpai and I discussed options!"

Apparently, Riko and Emi had shopped together. Riko presented a beige safari hat; Emi offered sunglasses. Their outdoor-themed choices made sense. Yuu owned baseball caps but no other hats or sunglasses—perfect additions. Their selections showed mature, tasteful sensibilities.

"Ooh... cool. May I try them on now?"  
""Please!""

Yuu stood and moved where all three could see clearly. Donning the safari hat and sunglasses, he asked, "How... do I look?" His navy polo shirt and black slim jeans weren't particularly outdoorsy, but the accessories suited him.

"Amazing... Yuu-kun, too handsome!"  
"You'd be mistaken for a celebrity walking outside!"  
"I'm worried Yuu-kun will attract even more female attention..."  
"Er... I'm embarrassed..."

Under their praise, even Yuu flushed.

"Anyway, Riko, Emi, thank you. I'll definitely use these in the coming season." Circling the table, Yuu hugged Riko then Emi with gratitude.

Now Yuu's turn. He fetched his backpack from the living room, retrieving a compact camellia-patterned vinyl bag—purchased at a traditional shop during his solo shopping trip nearly a month prior. First, he pulled out a flat box.

"Here. Happy 18th birthday! I chose this imagining a certain part of you."  
"Wh-what part of me...? May I open it?"  
"Yes, please."

Curious about Yuu's words, Riko and Emi leaned forward to watch. Sayaka carefully unwrapped the package. Inside the paper box lay a thin purple camellia-patterned cloth bag. "This is... eh!?" Sayaka gasped, extracting a beautiful boxwood comb. Tracing the elliptical wood grain with her whitefish-like fingers, she stared wide-eyed. "F-for me?"

Yuu turned to the mesmerized Sayaka, speaking gently. "I remember being captivated by your hair's beauty when we first met. Wanting it to stay beautiful, I naturally thought of a comb." Straight hair suits traditional combs better than permed hair.

Previously, hearing about Sayaka's fiancé's birthday gifts—likely expensive but lacking femininity—had bothered him. In his past life, he'd gifted jewelry like necklaces and earrings to his ex-wife. But as a high school freshman, finding items worthy of an ojou-sama within his allowance was challenging. Combs ranged wildly in price—Yuu chose one just under ¥10,000 after consulting the shopkeeper.

"Yuu...kun... For me... such a lovely... Th-thank you. I'll... treasure it." Usually articulate, Sayaka now stumbled over words, warmth rising in her chest. Holding the comb lovingly, she let Yuu take her hand. Brushing hair from her temple, he whispered by her ear: "I love you, Sayaka."  
"...! Yu...u..." Tears instantly streamed down Sayaka's cheeks. "Ah... why... am I crying?" Flustered by her own tears, she flushed crimson. Receiving heartfelt gifts from men disrupted her composure unexpectedly. Smiling, Yuu stroked her hair. Though he often felt like a younger brother, tonight Yuu seemed like an older man to Sayaka.

"Happy for you, Sayaka."  
"Yuu-kun is truly wonderful..."

Riko and Emi watched them with broad-minded smiles, though slightly envious.

As Sayaka calmed, Yuu retrieved two small packages from the vinyl bag. "Sorry for the wait. I bought these for you two too."  
"Eh?"  
"But..."

"Proper returns will come on your birthdays. For now, consider these thank-you gifts for always taking care of me. Nothing fancy, but here."  
"Ah, thank you."  
"May we open them?"  
"Yes. I hope you'll use them."

Not expecting gifts now, they couldn't hide their anticipation. "Waaah!" "Ahh..." Inside were items from the same shop: floral hair clips and round-ball hair ties resembling temari balls. Riko's featured bellflower patterns with light blue/lavender sets; Emi's had cherry blossoms with pink/red sets.

"I love how these suit your hairstyles. And you use hair ties, right? Thought they'd be perfect."  
"Ah... y-yeah."  
"Mmh..."

Both seemed speechless. Yuu grew anxious. For Sayaka's birthday, he'd splurged within his student budget. Comparatively, Riko and Emi's gifts felt childish or cheap—were they disappointed but too considerate to say?

"Er... too childish maybe? I'll give proper gifts on your birthdays!" Seeing Yuu's dejection, Riko and Emi panicked.  
"N-no, Yuu-kun!"  
"Huh?"  
"Um..."

Exchanging glances, Riko spoke first. "I-it's just... I've never received gifts from boys before... so I was flustered."  
"Yeah! We're happy with anything from Yuu-kun!"  
"Then why?"  
"Such pretty, wonderful gifts—how could we not be happy? Like Sayaka... for women, receiving personal care or adornment items from men signifies... special relationships... um..." Riko trailed off.

To Yuu, men gifting women was natural. But in this male-scarce world, few women received male gifts—especially adornments implying romantic or marital bonds.

"Ah... I kinda get it." Yuu looked at each girl. "Sayaka, Riko, Emi. You're all precious to me. Always have been, always will be. Celebrating together makes me truly happy."  
""""Yuu-kun!""""

Sayaka stood impulsively; Riko and Emi circled the table too. Yuu rose to embrace them. Surrounded by their sweet fragrance and soft bodies, his heart raced while his lower body threatened to react. Simultaneously, he savored the happiness.

True, in this male-scarce chastity-reversed world, Yuu was popular. Walking outside, women would swarm him with squeals—not entirely unappealing, though his actual experience had been chaotic. Still, reborn as a 15-year-old with past-life sensibilities, he wanted normal romance. Knowing women outnumbered men 30:1 here, he'd resolved to act proactively.

Meeting extraordinary beauty Sayaka right after entering high school. Learning she was engaged didn't stop his feelings. His desperate pursuit led to Riko and Emi discovering them—an accident that became a blessing in this polyandrous world, evolving into physical relationships with all three. Feeling their warmth and hot breath against his skin, Yuu's excitement peaked. The girls seemed equally affected.

Short Emi pressed against Yuu's right chest, looking up with upturned eyes as her small lips parted: "Yuu-kun, I love you... love you so much!" Playing with her twin-tail strand, Yuu kissed her in reply. "I love adorable Emi too."  
"Ah-ha! Yuu-kun... happy!"

Opposite him, Riko stroked his hair while whispering by his ear: "I never thought I'd care about boys... yet here I am. Love you, Yuu-kun." Turning to crimson-faced Riko, Yuu gazed into her narrow eyes behind glasses. His left hand caressed her nape and tied-up hair. "Riko... thank you. I love you too."  
"Mh..."

Perhaps embarrassed by the direct confession, Riko closed her eyes and brought her lips closer.

"Yuu...kun... I..." Sayaka had wrapped her arms around Yuu's waist, face buried in his neck. Hearing her voice, Yuu faced her as she slowly lifted her head. Their eyes met. "No need to say it. Just being together makes me happy."  
"N-no... let me say it this time."  
"Sayaka..."

Resolved, Sayaka locked eyes at breath-close distance. "I-I find myself constantly thinking about you... my heart races even now... I feel heat rising from deep inside... I must admit—my heart and body are already your captive. What should I call this state... Yes, I'm in love with you."  
"Sa... Sayaka!"  
"Ahhn!"

Their kiss felt more like passionate devouring than a simple peck. "Mmph, huu... I fell for your charms first, Sayaka."  
"Ahfuu... Come to think of it... because of Yuu-kun... mmph... my feminine instincts... went wild before too... *chu*, *chup*. Haa... This too... is because you're too kind and wonderful..."

"Yuu-kun!"  
"Yuu-kun!"

Riko and Emi finally interrupted the endless kiss, grabbing Yuu's shoulders and nape. Even Yuu—and now Sayaka—broke apart blushing.

"You're sweating..."  
"The continuation..."  
"After showering, okay?"  
"Yeah. Understood."

Dinner ended early—only 7:30 PM. Their long-awaited overnight birthday party. The real fun was beginning. Sharing smiles filled with slight shyness but brimming anticipation, Yuu and the three girls prepared for the night's pleasures.

***

### Author's Afterword

The gift purchased in Chapter 43 is finally given. Combs ("kushi") are generally considered unlucky gifts due to homophones with "suffering" ("ku") and "death" ("shi"). Conversely, they symbolize "staying together through suffering and death," making them engagement gifts from men to women. Of course, the protagonist doesn't know this—he chose it purely from admiration for Sayaka's beautiful hair.

### Chapter Translation Notes
- Translated "お嬢様" as "ojou-sama" to preserve status connotation
- Rendered "大根おろし" as "grated radish" for accuracy, adding "Japanese-style" for context
- Kept "ojou-sama" untranslated to maintain cultural nuance
- Preserved Japanese culinary terms: "グラッセ"→"glazed", "粉吹き芋"→"mashed potatoes"
- Translated "ジェントルマンファースト" literally as "gentleman first" to match worldbuilding
- Maintained Japanese gift-giving etiquette descriptions without localization
- Transliterated sounds: "ちゅっ"→"*chu*", "ちゅぱっ"→"*chup*"
- Used explicit anatomical terms: "下半身"→"lower body"