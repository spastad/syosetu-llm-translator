## 95. Birthday Party ③ ~With Love from the Bathroom~

### Author's Preface

I revised the protagonist's thoughts and interactions regarding taking a taxi after leaving school in Chapter 93. The protagonist reflects on the past and comes to understand Sayaka's words. The flow remains unchanged, so rereading isn't necessary.

Additionally, the real action of the birthday party happens at night. The enviable and scandalous intimate moments will only increase from here.

---

Tonight, since the girls would use the bath first, Komatsu Sayaka apologized to Hirose Yuu, but he didn't mind at all. He knew women took more time with bathing. Whether he waited before or after, it was the same to him.

Yuu was led by the hand to the bedroom by Sayaka. "Sorry, but could you wait here?" He'd overheard the three whispering while he went to the bathroom after dinner, so he knew they were planning something. *Must be a surprise for later*, he nodded and obediently complied. As soon as Sayaka closed the door and left, Yuu face-planted onto the bed, savoring its fragrance. Finding several historical manga volumes by the pillow, he picked one up - perfect for killing time.

He became engrossed in reading when he noticed Sayaka opening the door. Hiding half her body behind it, she appeared to be wearing only a bath towel.

"Sorry to keep you waiting."  
"Ah, everyone's done? No problem. This was so interesting I lost track of time."  
As Yuu picked up the third volume he'd started reading, Sayaka smiled. Over an hour had passed unnoticed.

"Fufu. So interesting you forgot about us?"  
"S-sorry! I didn't mean..."  
"It's fine. Women do take time after all. Come here, Yuu-kun."

The moment Yuu stepped into the hallway, he was surrounded not just by Sayaka but also by Hanmura Riko and Ishikawa Emi who'd been waiting.  
"Ah!"

All three wore only bath towels, their hair styled differently after showering. Sayaka had a high ponytail. Riko swept her bangs back in a clean chignon, using the hairclip Yuu had just given her. Emi had modified her usual twin tails into double buns, secured with the pink ball-adorned hair ties Yuu gifted her. Emi's flaxen hair still looked damp, suggesting she'd showered last.

"Sayaka's ponytail... I saw it during the sports festival too. I love how it's not just elegantly beautiful but gives an active girl vibe. Riko's hairstyle is incredibly sexy and beautiful, radiating mature charm. Emi's hairstyle is super cute too! Perfect for summer and would look great with a yukata."

In his previous life, Yuu could never have complimented girls so smoothly, but now the words flowed naturally. Hearing this, the three smiled happily and closed in.

"Yuu-kun is incredibly handsome too."  
"Gentle and accepting..."  
"And I love your naughty side. So..."  
""""Eii!""""  
"Huh?"

Sayaka's hands pulled up his polo shirt, Riko's hands pulled down his jeans, and Emi's hands reached for his trunks. Before he knew it, Yuu was stripped naked and led to the washroom before the bath. There, all three dropped their towels and stood nude. In the cramped washroom where skin brushed skin with slight movement, Yuu's groin rapidly hardened as he was surrounded by three beauties.

"Um... are we going in together?"  
Seeing his erect penis, Sayaka and the others exchanged knowing smiles. "Well, about that..."  
"Since Yuu-kun always makes us feel good..."  
"It's a special day, so we'll wash every inch of your body together."  
"Eh? You really don't have to..."  
"Just get in already!"

Pushed from behind by Sayaka and with arms held by Riko and Emi on either side, Yuu entered the steamy bathroom. Though slightly larger than average, it felt cramped with four people. They divided tasks: Sayaka knelt behind Yuu seated on a stool to wash his hair while Riko and Emi waited perched on the covered bathtub edge.

"I-I've never washed a boy's hair before, so I might be clumsy... If it feels unpleasant, please tell me."  
"No no. I'm looking forward to it."

Come to think of it, in this world, Yuu had only gotten haircuts at male salons Martina took him to. The shop had only male clients, with women dressed like theater actors attending to him - perhaps because men felt more comfortable with obviously feminine staff? Their skills were good, so Yuu was satisfied.

Recalling this, Yuu looked down as water streamed over his head. A soft *munyu* sensation spread against his back. *(Ooh...!)* Though just a slight breast touch, joy spread through Yuu's heart.

In his dentist visits, hospitals, or crowded trains, he'd sometimes wonder *(Did her breast just touch me?)* In his old world, such moments usually proved imaginary - breasts didn't just casually touch you. Yet even that would make the old Yuu happy. In this reborn world, he'd felt lonely having no friends who understood that feeling.

After rinsing, Sayaka took shampoo, lathered it, and began washing. Her touch remained gentle and pleasant. Though not fully pressed against him, her breasts brushed his back at close intervals. Unconscious or deliberate? Either way, Yuu delighted in the feel of Sayaka's ample chest.

"How... how is it? Any itchy spots?"  
The familiar barbershop question. He usually said no.  
"Feels great... but if I had to say, maybe a slight itch near my forehead hairline?"  
"Understood."

As Sayaka leaned forward, the breast contact against his back intensified - exactly as Yuu hoped.

Sayaka applied conditioner too, rinsing thoroughly afterward. She even gently towel-dried his face and head as if handling fragile goods. Though not as skilled as a beautician, her tender care warmed Yuu's heart.

"Phew... That felt amazing. Ah, I wish I could ask Sayaka to do this daily."  
"Fufu. Today's special."  
"Yeah. Got it. Thank you."  
Yuu turned over his shoulder and kissed Sayaka.

"Okay! Now it's our turn to wash Yuu-kun!"  
"Tag out, Sayaka."  
"Mu... fine."

As Sayaka reluctantly detached from hugging Yuu from behind, Riko took the front and Emi the back - sandwiching him.

"Now, I'll wash your upper body."  
"Front and back~"  
Possibly due to steam fogging glasses, Riko had removed hers. She lathered a washcloth and approached head-on.

"Fufu. No need to be so formal, just relax."  
"Ah... yeah. Riko's aura feels different today, got me nervous."  
"...Really."

Riko's flushed face wasn't just from steam. Standing naked within breath's reach, Yuu impulsively kissed her forehead.  
"Nn!... N-not yet, hold on..."  
Yet her gaze remained fixed on his erect penis.

"Haa... Yuu-kun's back is so broad and wonderful."  
Emi murmured dreamily while moving her hands from his nape to shoulders.  
"You can press harder."  
"R-really? Ehe, got it, Yuu-kun!"  
Emi gripped Yuu's shoulder with her left hand and scrubbed vigorously with the lathered cloth. Riko carefully washed around his neck before reaching his chest.

"Ahh..."  
Yuu's inadvertent sigh made not just Riko but even Sayaka watching nearby stare intensely.  
"Ah, having someone wash you feels weird. Haha."  
"R-right... I suppose."

Though planned together, washing a male body excited them more than expected. Their hands worked diligently but words grew sparse.

"Fwaa...! Nhya!"  
Yuu made a strange noise when Riko washed his raised armpits and Emi his sides simultaneously.

"Wh-what's wrong? Did I mess up?"  
"N-no, just ticklish."  
"Ah~ got it. Sorry, Yuu-kun."  
"I-it's fine..."

Being washed by two girls front and back was intensely arousing. Memories surfaced of 11-year-old Yuu being washed by Martina and Elena before his sexual awakening - even with family, he'd felt female presence and ejaculated. With girls he loved, losing control was inevitable.

Yuu lowered his raised arms and embraced Riko. Beyond her smooth skin, he felt her body's softness. The mutual lather added a slippery comfort.

"Hya!? Nmmu... ufuun"  
"Nchu... Ri... ko"  
"Ah, nn... Yuu..."  
"Aahn! Yuu-kun, me too!"

Aroused, Yuu and Riko pressed lips together, exchanging passionate kisses. Seeing this, Emi couldn't hold back.  
"Nn, Emi too."  
Feeling Emi's soft breasts against his back, Yuu kissed her small cherry lips approaching over his shoulder.

*Chu, chu* - as they alternated kisses, Sayaka cleared her throat audibly.  
"Shall we move to the lower half soon?"  
"Right..."  
"Yeah..."

While Riko gazed mesmerized at the hard, hot rod against her belly, Emi still hugging him peered down at it over his shoulder.

With Sayaka taking over, Yuu sat on the bath edge, legs spread. Riko and Emi washed his feet while Sayaka knelt between his legs facing away, washing his toes directly with soapy hands. Though ticklish sounds escaped Yuu, Sayaka seemed to enjoy his reactions.

"Haa~. Yuu-kun's legs are slim yet toned - so cool!"  
Emi cradled his right leg, washing every inch.  
"Ufufu. Know what? During the sports festival, not just first-years but second and third-year girls were eyeing Yuu-kun's legs."  
"Eh? R-really?"  
"Come to think of it, I overheard whispers too - wanting to stroke Yuu-kun's thighs or be stepped on by him."

Yuu thought leg beauty was female-exclusive, but in this world, male legs got attention too.

"Having these cool legs all to myself tonight makes me happy!"  
"Same."  
Even Riko caressed rather than washed Yuu's inner thighs from knee to groin.

Being pampered like this by three beauties gave Yuu a strange sense of elevated status. Though their hands neared his groin, they deliberately avoided touching it despite their heated gazes. *Must be saving the best for last*, Yuu mused.

"Okay! Done here."  
Sayaka turned toward Yuu after finishing his feet, her ample breasts jiggling *purun* as she shifted.  
"Done here too!"  
"Finished."  
"Th-thank you."

The trio's smiles focused on his groin.  
"Now then..."  
"Finally..."  
"The important part..."  
""""Let's wash it!""""  
"Haha... please do."

This became the bathroom climax. With knees bent and legs shoulder-width apart, Sayaka pressed against Yuu's back, Emi on his right, Riko on his left - all gripping his waist or thighs. They began washing from glans to balls with foamy hands.

"Ah, fwaa! G-good!"  
Yuu moaned at their meticulous stroking.  
"Yuu-kun's precious chinko... we'll clean it squeaky cleeaan~"  
"Fufufu. Such a lively boy. Still impressively hard."  
"Been standing tall since the bath started. Don't you want to release soon?"  
"Y-yeah... want to. Want to ejaculate!"

Yuu could only agree as Sayaka whispered this while hugging him from behind. Hearing his moaned response, Riko and Emi exchanged mischievous grins. Their hands shifted from washing to stimulation: Emi lightly stroked the shaft up-down. Riko palmed and rubbed the glans. Sayaka gently massaged his balls.

"Kuu! Ah, ah, yes!"  
The soapy slickness intensified the pleasure faster than usual handjobs. Yuu instinctively grabbed Riko and Emi's backs, squeezing their shoulders.

"An... chinko's twitching. Wants to cum already."  
"Yuu-kun, wanna cum? You can cum noow~"  
Both stared hungrily at the soap-smeared, proudly erect penis.  
"Right! Need to wash the back too."  
"Huh... Kyaaaaah! N-nooo!"

Sayaka reached beyond his buttocks to his anus. The moment she touched it, electricity shot up Yuu's spine. Resistance was impossible.  
"Ah... fo... o... ooh..."  
With a *dopun* sensation of his lower body exploding, Yuu ejaculated.  
""""Aaaaah!""""  
*Dopyuu!* - the spurting semen showered Riko and Emi's upturned faces like white rain. *Pesha pesha!*

""Ahh...""  
"An!"  
Sayaka peering between his legs from behind also got facialed. All three wore ecstatic expressions beneath the white splatter.

---

*Chapun* - the water made soft sounds with minimal movement. The naked bodies before him glowed pink against white skin, radiating warmth where they touched. Half of Sayaka's ample breasts floated *puka puka* above water since he hugged her from behind. Below her taut abdomen, a dark delta swayed, her straight legs bent at the knees against the tub edge since they didn't fully fit.

After Yuu's climax, Riko and Emi washed off semen and soap under the shower before exiting, saying "Take your time alone." Clearly granting the birthday pair private moments. At Yuu's request, he entered the bath hugging Sayaka from behind.

Actually, Sayaka preferred hugging Yuu from behind. While it made Yuu feel oddly pampered, Sayaka probably saw it as doting on a younger brother. But tonight, their reversed positions seemed to embarrass her - she remained silent, leaning against Yuu.

"Sayaka's skin is truly beautiful."  
Yuu murmured, savoring Sayaka's floral scent and the bewitching lines from her nape to jaw, neck, shoulders, and chest at close range.

"Nn... y-you think so...?"  
"Yeah. Being this close, I really see it. *Chu*."  
"Nn!"  
"Anmu... I... love everything about you, Sayaka."  
"An!"

After kissing her nape, Yuu trailed lips down her neck. Seeing Sayaka's cheeks blush pink as she whimpered, he kissed them. Sayaka opened her lowered eyelids, turned to Yuu, and met his lips. After several *chu chu* pecks, she smiled.

"Until middle school, I constantly had cuts from club activities and our family dojo. Even now attending weekly in high school, I've improved somewhat. No more lasting scars."

Perhaps due to the family creed of balancing arts and martial skills, combined with most jobs shifting from men to women in this world, the notion of "don't let girls get hurt" wasn't widespread. Still, Yuu preferred Sayaka's unblemished body.

Sayaka's uniform made her seem slender, but martial arts training meant she wasn't fragile. Rather, her frame was well-developed with solid muscle - lean yet toned. While her body was taut, her bust and hips remained full, maintaining perfect proportions. Paired with her porcelain-doll features, what man wouldn't be captivated? In a non-chastity-reversed world, she'd undoubtedly be an unattainable prize.

Such beauty now bared her defenseless body before Yuu. He kissed her smooth shoulder, then raised her crossed arms to cup her breasts - too large for his palms, so he lifted and kneaded them from below.

"Ah... haan... Yuu...kun... nn, ah... d-don't... that..."  
"Don't what?"  
Yuu pinched her nipples while whispering in her ear.  
"Since earlier... your chinko against my back... makes me want it."  
"Sayaka."  
Meeting Sayaka's lust-drenched eyes, Yuu seized her maple-leaf-reddened lips.

"Ah... muu... yuu... fuun... ah, chupaa... nn, nn, fuumu"  
"*Chu*. Honestly, being like this makes me unbearably want you too."  
"But..."  
"Yeah. The rest should be... in bed."  
"Ah. The others are waiting."  
"Nn."

After enjoying the kiss,  
"I'll go wait first."  
Yuu watched Sayaka leave.  


### Chapter Translation Notes
- Translated "おチンポ" as "chinko" per explicit terminology requirement
- Preserved Japanese honorifics (-kun for Yuu)
- Maintained original name order (Komatsu Sayaka)
- Transliterated sound effects: "むにゅ" → "munyu", "ぷるん" → "purun"
- Italicized internal monologues per style guide
- Used """" for simultaneous dialogue when all three girls speak together
- Translated anatomical/sexual terms directly: "射精" → "ejaculate", "亀頭" → "glans"
- Kept cultural terms: "kikkou shibari" (tortoise shell bondage) untranslated as established
- Maintained paragraph breaks for each new dialogue line