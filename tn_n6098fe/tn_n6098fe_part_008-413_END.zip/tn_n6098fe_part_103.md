## 96. Birthday Party ④ ~Harlem Night~

Three naked beauties smiled on the bed, waiting for me to join them.  
This was truly what could be called a harem.  

"Yuu-kun"  
"Yu...u-kun..."  
"Yu-kun!"  

Sayaka spoke with composed elegance.  
Riko with a hint of shyness.  
Emi with a bouncing, energetic voice.  
Each called my name.  

So Yuu smiled and approached.  
"Yeah. Sorry to keep you waiting."  

Yuu stopped at the edge of the bed after removing the towel around his waist, revealing his fully erect penis. Even though they'd just seen, touched, and made him ejaculate in the bathroom, all three still gazed at him with unabated intensity. Probably the same way Yuu's eyes kept drifting to their breasts and buttocks.  

Though it was a king-sized bed, it was still designed for one person. Sayaka sat in the center with her back against the pillow, Riko pressed close on her left, Emi on her right.  

"Come here now."  
Guided by Sayaka's invitation, Yuu climbed onto the bed and settled among the three. Instantly, their bodies pressed against him, enveloping him in the scents of shampoo, soap, and the sweet fragrance of girls' skin.  

"Ahh, Yuu-kun"  
"Sayaka"  
"Yu...u-kun?"  
"Riko"  
"Ehe, Yu-kun!"  
"Emi!"  

They rubbed against him as if confirming the warmth of his skin while exchanging names. Yuu's body seemed completely covered by the three. Though a pleasant breeze came through the open window, the temperature seemed to skyrocket around Yuu.  

Sayaka, who'd been nuzzling Yuu's neck, lifted her face to look at him.  
"First..."  
"Hm?"  
"I think we'll have you lie down here."  

They must have planned this beforehand. The three switched Yuu and Sayaka's positions, gently pushing him down onto his back in the center of the bed. Sayaka straddled his hips while Riko attended to his right and Emi to his left, each holding one of his arms. They needed to press close to prevent him from falling off the bed.  

"Ahh... Yu, Yuu-kun..."  
Feeling the hot penis against her lower abdomen, Sayaka let out a sensual moan as she leaned over Yuu, hands on his chest. The position emphasized the breasts pressed against both his arms.  

"Yuu-kun, I want to ask you something."  
"Hm? What?"  
"About how many times... you can ejaculate in one night?"  
"I'm curious too."  
"Me too!"  

In this world, men generally need recovery time after ejaculating before they can ejaculate again - not much different from Yuu's original world. However, while women's sexual desire has intensified due to difficulties in relationships and childbearing, men's virility has weakened. Yuu knew from health class that one ejaculation per night was considered ideal. Yet when with the student council trio, he typically ejaculated three times in quick succession.  

"Within a certain timeframe... I've ejaculated four... no, five times before."  
"Ooh!"  
"Fufufu. So after ejaculating once in the bath, you can still ejaculate inside each of us once more?"  
"*Phew*. Yuu-kun really is extraordinary."  
"Yu-kun, amazing!"  

Yuu looked at each girl in turn: Sayaka squirming against his groin, Riko and Emi hugging his arms against their chests.  
"That's why tonight I'll ejaculate inside each of you once too. No - I want to! I want to impregnate Sayaka, Riko, and Emi with my semen!"  

Since he'd already ejaculated inside them many times, at least one - possibly all three - might already be pregnant. Though avoiding the word "marriage" out of consideration for his engaged fiancée Sayaka, this was effectively Yuu's declaration of "my wives."  

"Me! I'll have Yu-kun's baby!"  
Emi happily rubbed her cheek against his shoulder.  
"Can't be helped. I'll have your baby too, Yuu-kun. As many as you want..."  
Riko kissed Yuu's shoulder.  

Instead of replying, Sayaka brought her face close and pressed her lips to Yuu's.  
"Mmm"  
She shifted her hips...  
"Haaah... ugh... mmph... Yu, Yuu-kun!"  
Perhaps still feeling the afterglow from the bath, her entrance seemed drenched and eager for Yuu. Sayaka furrowed her brows, parted her lips, and accepted him with hot breaths as their bodies connected deeply.  

"Yu, Yuu-kun's... inside me... ejaculate, please..."  
Seeing Sayaka's ecstatic expression, Yuu couldn't resist thrusting upward.  
"Hyaan! N-no... I-I'm supposed to move... save your strength..."  
"Sorry. I just love you too much, Sayaka."  
"Fufu. D-don't embarrass me."  
Sayaka leaned over Yuu again, exchanging a deep kiss with tangled tongues before starting to rock her hips.  

"Hah, hah, hah... ahhn! I-it's good! Yuu-kun's penis... hitting my deepest... nnah! At this rate... again... aughn!"  
"Chu, chu, lew chu. Mmph"  
"Ehehe. Yu-kun! Aahn-mph!"  

Sayaka rode Yuu, her ponytail and ample breasts swaying. Her cheeks flushed pink after one climax, her fair skin glistening under the room's lights. Riko and Emi took turns claiming Yuu's lips and meticulously caressing his neck and chest.  

"Ahhaa... Yuu-kun's always amazing, but tonight... mmph, ahhn! I'm feeling it even more... Yu, Yuu-kun, does it feel good?"  
"How could it not... feel good? Ugh...  
Because not just Sayaka - Riko and Emi are loving me so much too.  
I'm overflowing with happiness... feeling all three of you with my entire body!"  

Yuu stroked Riko and Emi's heads and backs. Riko, who'd been licking Yuu's neck, sat up and spoke to Emi.  
"But soon we'll want our turn too. Let's help them?"  
"Ehehe. Help how?"  
"Yes. I'll help Sayaka, Emi helps Yuu-kun. Divide and conquer."  
"Okay!"  

Before Yuu could wonder what they meant, Riko hugged Sayaka from the side.  
"Eh? Riko?"  
"Ufufu"  
"Mmph!?"  

Right before Yuu's eyes, Riko kissed Sayaka passionately while kneading her breasts.  
"Ahh, Sayaka looks so beautiful when she's with Yuu-kun..."  
"Haa... Ri... ko... mmph, mmph, feh... aaghn!"  
Riko expertly pinched and twisted Sayaka's nipples while massaging her breasts. The sight of the two beauties entangled was intensely erotic.  

Meanwhile, Emi pressed her face against Yuu's chest and began sucking his nipple.  
"Kuu... ahh, Emi"  
"Mmchuu! Yu-kun, how does it feel?"  
"Ugh... ah... feels weird... but good..."  
"Ehehe. Yu-kun's aroused face is cute! Makes me want to make you feel even more.  
I'll play with this too!"  
"Heah!? Wait!"  

Emi reached down and began playing with Yuu's anus - his weakness discovered earlier in the bath.  

"Hiiin! Ri, Riko! St-st, no... if you touch that now..."  
"Ufufu. I want to see Yuu-kun and Sayaka come together."  

While rolling Sayaka's nipple with her tongue, Riko reached down to her clitoris. Though Sayaka writhed, Riko's assault was relentless. Yuu couldn't defend himself with Sayaka on top.  

"Ah... kahaa... bad... I'm gonna come..."  
Just as Yuu felt close, Sayaka's vaginal walls clenched tightly around his penis despite her slackening mouth. With each deep thrust, her cervix seemed to suck desperately at his tip, drawing out his moans. Riko and Emi's stimulation rapidly pushed Yuu and Sayaka toward climax.  

"Yuu-kun... Yu, Yuu-kun! I'm... coming! Ah... hah, aaiin! Yu... kuun!"  
"Sa, Sayaka... feels amazing... I'm... coming too!"  

Sayaka ground her hips forcefully against Yuu, hands braced on his chest. Yuu thrust upward in response. Their rising passion peaked simultaneously.  
"Aaaah!"  
"Yuu!"  
"Sayaka!"  

Thick pulses of semen released into her. Feeling it fill her womb, Sayaka wore an ecstatic expression before collapsing onto Yuu's chest like a puppet with cut strings.  

After being thoroughly filled, Sayaka was moved to a prepared chair in the corner by Emi. Now Riko straddled Yuu as he lay on his back. They usually did missionary or doggy style, so her riding him was rare.  

"Seeing Riko from below like this is unusual."  
"Occasionally it's nice. Because I can see Yuu-kun's face."  

Being the tallest of the three, Riko felt slightly imposing in this position, though her modest A-cup breasts and slender frame maintained her elegance. Without her glasses, she seemed more mature.  

"I want Yuu-kun."  
"Riko... ahn-mph"  

Riko pressed forward with parted lips, her tongue greedily exploring Yuu's mouth.  
"Ooh... mmph"  
"Ufuh... slurp, lepaa... ahn, Yu... u... chu, churu, fahmph"  
Yuu tangled his tongue with hers as they kissed open-mouthed. Feeling Riko's slender body heat against him, Yuu's excitement only grew. When Riko shifted her hips and her moist entrance touched his tip, it immediately engulfed him.  

*Thrust!*  
"Nngh! Aah!"  

Still kissing, they connected deeply.  
"Aaaaah! Yu, Yuu-kun!"  
"Riko?"  

Riko had closed her eyes and furrowed her brows during penetration, but now her eyes widened as she gasped, gripping Yuu's shoulders while staring intensely. Her expression shifted rapidly until drool dripped onto Yuu's cheek.  
"N-no... coming... mmph!"  
Connected deep inside, Riko trembled as she moaned.  

"You already came?"  
"Because... I love Yuu-kun... feels too good..."  
Riko pressed her forehead against his.  

"Riko being so affectionate is cute."  
"Ah... dummy."  

Blushing, Riko kissed him to hide her embarrassment.  
"N-now... I'll make Yuu-kun feel good."  
"Fufu. I already feel amazing, but I want to feel even better with Riko."  

"Aahn! So jealous! I want Yu-kun soon too!"  
Emi pressed close from the side as Riko began moving her hips.  
"Emi, sorry for the wait. Let's kiss lots instead!"  
Before Yuu finished speaking, Emi sealed his mouth, drooling into it while wriggling her tongue. Having watched Riko and Sayaka, Emi was fully aroused, kissing him as if violating his mouth.  

Yuu used his left hand to grab Emi's breast.  
"Fah... mmph, ah, umph..."  
He kneaded her moderately sized, soft breast while rolling the nipple with his palm. Emi moaned sweetly but didn't stop kissing, instead intensifying the wet, slurping sounds as she claimed his mouth.  

"Ahh! Ah! Ah! Ahn! Yuu-kun! Yuu-kun! Good! So good! I'm... coming again! Ahhi, so good! C-can't stop thrusting!"  

Riko rode him frantically. Yuu felt simultaneously violated by Riko's vagina and Emi's mouth - a sensation he enjoyed. His hand moved from Emi's breast to her groin. Fingers traced past damp pubic hair to soft labia, easily finding her vaginal opening. Two fingers spread her slit and inserted his middle finger.  

"Fuwaaaaah! Yahn! Shokoohh, haahn!"  
"I thought I'd loosen you with my fingers first, but you're already ready, right?"  
Though tight, his finger slid in to the second knuckle. He curled the tip to stroke her front wall.  

"Haaaah... aah! Nnnhh~~~!"  
"Yu, Yu-kun! Ah! Ah! St-stop... ahn! With your finger... you'll make me come!"  

As Riko neared climax, her elbow buckled and she collapsed beside Yuu's face. He wrapped his right arm around her back and thrust upward in short strokes. On his left, Emi clung to him as he fingered her.  

In this world, women typically pinned men down for sex while men remained passive. But for Yuu, this wasn't true. After being with him, the student council members had discarded their health class knowledge and become addicted to him. Previously constrained by school settings, they now unleashed their desires freely - as did Yuu.  

After ejaculating copiously inside Riko, Yuu carried her limp body to Sayaka. Seeing Riko close her eyes contentedly in Sayaka's embrace, Yuu returned to the bed.  

Sitting cross-legged near the bed's center, Yuu asked Emi to kneel on all fours sideways. Finally getting her turn, Emi obeyed with dazed eyes.  

Supporting Emi's upper body with his left arm around her chest, Yuu made her spread her knees. After stroking her smooth buttocks, he parted her slick slit and inserted a middle finger.  

"Yah... ahn! No more fingers... Yu-kun... I want Yu-kun's penis!"  
Yuu whispered while thrusting his finger deep, making wet *guchu guchu* sounds.  
"You seemed close earlier, right? After one more orgasm, I'll put it in."  
"Th-that's... hyahn! Yu-kun's... mean!"  
"Because I love you, Emi. I want to tease you."  

Emi turned her head and stuck out her tongue. Yuu met it with his own.  
"Mmph, mmpha! When Yu-kun touches me... I feel too much!"  
"Fufu, that's why Emi's adorable."  

Her side bun had loosened, flaxen hair spilling free. Already orgasming once from fingering and nearing another climax, Emi's skin glistened with sweat, enhancing her erotic cuteness.  

With each *juppu juppu* thrust of Yuu's finger, Emi's petite body rocked back and forth until she trembled violently, chin jerking upward.  
"Ah... really, coming! Yahn! Ah! Ah! Aah! Aaaaah! I'm coming, I'm coming oooh!"  

Emi lay face down, breathing deeply as her body rose and fell slightly. Yuu covered her from behind, his groin fully erect and ready.  

"Ah... mm? Yu-kun?"  
"Emi, lift your hips a little."  
"Hweh?"  

Emi obediently raised her small buttocks - the prone position. Rare in this world but familiar to Yuu from eroge, he wanted to try it, especially with her petite frame.  

"Eeh!? I want to see Yu-kun's face!"  
"Sorry, Emi. I just felt like trying this. I don't think it's bad though."  

Covered completely by Yuu's taller body from behind, their skin pressed tightly together. Feeling his breath on her nape made Emi's lower abdomen tingle. Ultimately, she was too smitten to refuse.  

"Here I go."  
"Haun!"  

With Yuu's warning, his rigid penis penetrated her, making Emi's vision spark white.  
"Ooh... Emi inside feels amazing..."  
"Hya... ah... hin..."  

Emi gasped wordlessly, desperately gripping the pillow. Yuu grabbed her slender shoulders for the final thrust.  
"Kuhah! I-in!"  
"Hafu, hahi, iin... nngh! Au~n..."  
Emi buried her face in the pillow.  

Prone position supposedly made women climax easily. Regardless, Emi surrendered easily to Yuu's long-awaited penetration.  

"Huh? Emi? Emi, are you okay?"  
Panicking at her lack of response, Yuu touched her head and cheeks. Finally, Emi turned her face sideways, drool trailing from her mouth.  

"Eheh, I came..."  
"Oh? Haha. But the main event is just starting?"  
Yuu kissed her pink cheek.  
"I-it's okay. Yu-kun, go all out. I'm happiest... when connected to Yu-kun. Ehehe. This feels... good too..."  

Emi smiled coyly at Yuu, utterly adorable. Stroking her disheveled hair, Yuu began thrusting as she desired.  


### Chapter Translation Notes
- Translated "ハーレム" as "harem" to maintain the original nuance of a male-centered polyamorous dynamic
- Preserved all Japanese honorifics (-kun, -chan) and nicknames (Eiimii for エイミー) per style guidelines
- Used explicit anatomical terms ("penis," "vagina," "clitoris") and sexual act descriptions ("ejaculated inside," "fingered") without euphemisms
- Transliterated sound effects: "ぐっちゅ" → "guchu," "ぷるぷる" → "puru puru," "じゅっぷ" → "juppu"
- Maintained Japanese name order and first-name usage as in original text (Sayaka, Riko, Emi)
- Translated "寝バック" as "prone position" to accurately describe the sexual position
- Rendered internal physiological descriptions literally (e.g., "cervix seemed to suck desperately")