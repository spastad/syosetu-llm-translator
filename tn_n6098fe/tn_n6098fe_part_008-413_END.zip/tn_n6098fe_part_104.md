## 97. Birthday Party ⑤ ~One Night In Heaven~

After thrusting vigorously in the doggy-style position and releasing his fourth load of the night inside Emi, Yuu finally felt fatigue setting in.

Even after ejaculating, he remained on top of Emi for a while.

He thought he might be crushing her with his weight, so he asked,

"Sorry, is it okay if I stay like this?"

But Emi, who was on the verge of losing consciousness from climaxing, only muttered incoherently and didn't answer properly.

However, she wore an extremely happy expression and kept repeating, "Yu-kun, I luv you," so he figured it was okay.

After catching his breath and lifting his body, he wiped Emi's vaginal opening with a tissue and turned toward Sayaka and Riko.

Perhaps influenced by Yuu and Emi's coupling, the two were embracing, exchanging passionate kisses, and groping each other's bodies.

"My throat's dry, so I'm going to get a drink..."

When Yuu hesitantly spoke up, Sayaka turned toward him with dazed eyes, but Riko remained attached to Sayaka's breasts.

"Mmm... I, I got it... I'll, I'll come... later, after I, I cum... ahhn! Riko... not so... hard... ahh!"  
"Nom nom... Sayakaa... love you love you..."

Upon closer inspection, Riko's hand was on Sayaka's lower abdomen, seemingly caressing her clitoris based on the position.

Knowing that Riko was usually the aggressor in their relationship, Yuu smiled, thinking he shouldn't interrupt, and silently decided to move.

After putting on just his underwear, Yuu went to the kitchen and opened the refrigerator without permission, taking out the 1L bottle of juice they had drunk during dinner.

The sweetness of the 100% concentrated apple juice seemed to seep into his body, and he poured it into a glass and drank it all in one go.

"Phew. That was delicious."

After catching his breath, Yuu now felt the urge to urinate and decided to go to the bathroom.

Time-wise, the date hadn't changed yet.

Tomorrow was Sunday, and the night was still young.

Even after four ejaculations, his son seemed to have plenty left.

It was a rare harem night.

He wanted to enjoy more sex with his beloved three.

As he thought about what to do next, his lower body reacted, and Yuu couldn't help but wryly smile. Having the mind of an old man and the body of a youth was problematic.

Suppressing his half-erect dick, Yuu finished in the bathroom and jumped in surprise when he sensed a presence upon stepping into the hallway.

When he had entered the bathroom earlier, the hallway was empty, with only faint moans from Sayaka and Riko leaking from the bedroom.

But now, someone definitely seemed to be standing at the entrance.

*(A trick of the eyes? It's not a ghost, right?)*

Yuu, who had no spiritual sensitivity whatsoever, didn't believe in such entities.

He didn't mind hearing about them as stories, but he couldn't believe in things he'd never seen.

Though, having been reborn with his original memories, he knew that mysterious things could happen in this world.

The light leaking through the frosted glass of the living room door only illuminated part of the hallway, and the entrance area was shrouded in darkness.

But there was definitely some kind of presence there.

Steeling himself, Yuu felt along the wall and turned on the hallway light.

"Eh!?"  
"Ah..."

The hallway lit by orange-tinged incandescent lights.

Since it wasn't a long distance, the figure at the entrance became visible.

There stood a single girl, squinting as if the light was dazzling her.

Because it was the entrance area with a step difference, the girl appeared short.

She seemed about 10cm shorter than Emi, who had measured 158cm in April.

For a moment, she looked completely black, but since she was wearing a pitch-black dress, it made sense that she was hard to see in the dark.

The knee-length skirt had multiple layers of frills.

The upper body seemed to be made of a glossy material, but her bust was modest.

The neckline, which exposed her collarbones prominently, was elegantly bordered with lace.

She wore a black lace choker around her neck and a black headband with a ribbon on her head.

She was completely dressed in black.

Yuu thought it might be so-called gothic lolita fashion.

Her long hair, falling to her shoulders and back, was a magnificent black, but in contrast, her chest area and face were sickly pale.

Additionally, her arms and legs extending from the dress were thin, and her tightly cinched waist seemed ready to snap.

A gothic lolita girl who had suddenly appeared in Sayaka's apartment.

Perhaps sleepy, her eyes were often half-open, but they were long and narrow with a high nose bridge. Her lips were a somewhat unhealthy color, but her facial features were overall well-formed.

She gave the impression of being a bit too thin, but she was unmistakably a beautiful girl.

Though she seemed a few years younger than Yuu, her all-black attire exuded a bewitching charm.

But Yuu couldn't shake the feeling that she resembled someone very familiar.

For a while, they stared at each other in this surreal scene, but upon closer inspection, he noticed her lips moving as she muttered to herself.

"Did I intend to enter my sister's apartment but actually open a door to another world?

After all, standing before me is a half-naked beautiful boy. He's been staring at me intently. He doesn't avert his eyes or run away upon seeing me. That's impossible. Even in all the manga and novels I've read, there's never been such a development. Indeed, reality is stranger than fiction. Wait, me. Can I really assert that the beautiful boy standing before me is human?

He has an excellent figure, looks slender but seems muscular. His skin is glossy, and he exudes an indecent aura. Th-there's no way such a boy exists in reality. Is this a dream or an illusion? But why do I smell a pleasant fragrance even though we're at least 2 meters apart?

And... that thing bulging in his underwear...!?

Oh no. Is this the sensation of throbbing!?

An existence that, just by being looked at, awakens a woman's reproductive instincts..."

"Um..."

Her voice was so soft that he couldn't catch half of it, but upon reflection, since she was there, she must have unlocked the door to enter.

Wasn't she someone very close to Sayaka?

Deciding to have a proper conversation, Yuu took one step closer.

For some reason, her cheeks flushed crimson as she clasped her hands in front of her chest, and her small lips, now slightly tinged with color like cherry blossoms, opened.

"Are you an incubus!?"  
"In...?"

Yuu recalled that among demons called dream demons or incubi, the succubus was the female type, so incubus must be the male type.

He inwardly smiled wryly, thinking that to the women of this world, his existence might indeed resemble an incubus.

However, it didn't seem like the time for jokes with a first meeting.

"No, I'm—"

Just then, behind Yuu, the bedroom door opened, revealing not only Sayaka but also Riko clinging to her arm. Naturally, both were completely naked.

"O-oh, Sister!? Why are you naked? Oh, even Riko-sister!?"  
"K-Kiyoka!? Why are you here at this hour!?"  
"Oh, Kiyo-chan. Long time no... or rather, I wish you'd stop calling me that."  
"Mmph! Riko-sister, you've finally achieved your feelings, haven't you!?"  
"Haha... well, I suppose that's one way to put it."

Indeed, both their hair was disheveled and stuck to their foreheads, and their cheeks were still flushed.

Moreover, since they were naked, if one looked at their crotches, it was clear that their pubic hair was glistening wet.

They were exuding the atmosphere of having just finished a sexual encounter.

"Sayaka, Riko."  
""Yuu-kun!""

Yuu turned around and exchanged names affectionately with Sayaka and Riko.

The gothic lolita girl was surprised by this and stared intently at the three of them.  
""Ah!""

Only now did Sayaka and Riko realize they had let Yuu be seen in just his underwear and showed signs of panic.

Afterward, the four moved to the living room sofa.

When they peeked into the bedroom, Emi was still face down, so they told her to come out when she could move.

"Let me properly introduce her. This is my sister, Kiyoka. She's in her third year of middle school now, so she's one year younger than Yuu-kun."  
"Nice to meet you. I am Komatsu Kiyoka."

Kiyoka stood up, pinched both ends of her skirt, and elegantly performed a curtsy.

For Yuu, this was the first time he'd seen such a real-life greeting, and he couldn't help but stare.

Based on his first impression, he thought she was 12 or 13, but it was surprising that she was only one year younger.

Now that she stood next to Sayaka, they indeed looked very similar, and it made sense that they were sisters.

"I am Hirose Yuu. I'm a first-year at Sairei Academy and joined the student council with Sayaka, Riko, and Emi, who's sleeping in the bedroom now."  
"Yuu...sama?"  
"Eh, no need for 'sama'."  
"But, for you to visit the apartment like this and be so close... ah!"

Kiyoka seemed to have thought of something and whispered into Sayaka's ear.

Yuu noticed the word "engagement" in the movement of her lips but remained silent.

Sayaka herself smiled faintly and slowly shook her head as if to say it was nothing to worry about.

"You can probably tell by now? I like Yuu-kun."

Yuu returned Sayaka's serious, determined gaze and said,  
"I like Sayaka too. Of course, I like Riko. And I like Emi."  
"Fufu. I like Yuu-kun too."  
"Heeey! Emi's back in action! Of course, I love Yuu-kun too!"

"Whoa!"

The three-seater sofa had Sayaka, Kiyoka, and Riko sitting side by side, while Yuu sat alone on the L-shaped corner section.

Emi hugged him from behind.

"Got it, Emi. Let's put on some clothes."  
"Huh? When did you get here!?"

Yuu was wearing a T-shirt and half-pants as pajamas, and even Sayaka and Riko were dressed in tank tops and shorts—a tantalizing sight.

Only Emi, who had come straight from the bedroom, was stark naked.

After Emi put on a long T-shirt that reached her thighs—though when she sat on the cushion, it was visible that she only had pink panties on below—and everyone had gathered, they reintroduced themselves.

"So, Kiyoka, why are you here at this hour?"

When questioned by her sister, Kiyoka looked down and remained silent, clutching the hem of her skirt.

"Coming without even contacting us... did something important happen?"

Riko gently placed a hand on her shoulder, and Kiyoka let out a small moan.

"Kiyoka?"

Sayaka gently stroked her head, and Kiyoka's expression seemed to soften slightly.

Meanwhile, Yuu and Emi remained silent. Yuu, for one, was captivated by the beautiful sisters.

As if making up her mind, Kiyoka lifted her face and turned to Sayaka.

"I've run away from home!

Sister! I'll do any housework or anything, so please let me stay here for a while!"  
"Huh!?"

Sayaka, and Riko who had known her for five years, seemed aware, but for about a year now, Kiyoka hadn't been getting along with her mother.

Since childhood, Kiyoka had been sickly and spent much time at home, becoming engrossed in novels and manga, and eventually began creating her own stories.

She had submitted her work to girls' novel magazines several times, and last winter, she finally won a newcomer award.

Originally possessing an excellent intellect and having a broad appreciation for literature from classics to modern works and foreign literature, she also seemed blessed with creative talent.

Winning the award led to a magazine editor offering her a serialization, and Kiyoka became serious about becoming a professional writer, declaring she wouldn't attend high school to secure writing time.

Her tendency to become fixated and run wild seemed to be a family trait.

Her mother had allowed her to write novels on the side while studying, but skipping high school to become a writer was out of the question, and they had clashed repeatedly, as Sayaka knew.

Recently, stuck on ideas for a new work, Kiyoka had been irritable, and during dinner, they had a big fight.

"Get out!" "I will!"

In the heat of the moment, with angry words exchanged, she had indeed run away.

"Sigh..."  
"That's..."

Sayaka, who knew about their longstanding conflict, held her head, and Riko put a hand to her forehead, deep in thought.

"Even if we send her back now, they're both still emotional and it would be awkward to face each other."  
"Auntie usually seems gentle, but I get the feeling she's scary when angry."  
"So that means...?"  
"It can't be helped. It seems better to have a cooling-off period apart for a while."  
"Sister!"

Kiyoka happily hugged Sayaka.

"But what about school starting the day after tomorrow?"  
"Ufufu. I brought my change of clothes and school supplies properly."

Apparently, her luggage had been left at the entrance.

Yuu watched Kiyoka clinging to her sister with amusement, but he had been feeling her glancing at him since earlier.

"Sister, and Riko-sister. Actually, separate from running away, I've been wanting to consult with both of you who attend co-ed schools about something."

Kiyoka glanced at Sayaka and Riko, and finally at Yuu.

"Hmm?"

Sayaka and Riko tilted their heads.

Kiyoka looked down, showing a slightly embarrassed expression, then resolved herself and spoke.

"For my new work, I absolutely need to know about men... specifically!"

According to Kiyoka, her award-winning work was based on 'Romeo and Juliet', featuring a middle school boy and girl in a faint romantic relationship who, on the verge of being torn apart by their parents' circumstances, instead burn with passion, with the boy taking the lead in pulling the girl along.

But for her new work, she wanted to write about the romantic history of one boy with multiple women, modeled after the classic masterpiece 'The Tale of Genji' and the documentary of Toyoda Sakuya, as if he were a sudden mutation in modern times.

Born in an incredibly rural area where animals outnumbered people, he lost his parents early and was raised by old-fashioned grandparents in a natural environment.

At 14, he lost his virginity to a visiting female peddler, who taught him sexual techniques and the full charm of women.

After his grandparents passed away, the boy moved to the Kanto region where distant relatives lived upon graduating middle school, meeting various women and actively engaging with them.

""""Hmmm...""""

Not only Sayaka and Riko but even Emi was deep in thought.

Yuu thought that regardless of this world, the content seemed too advanced for a middle school girl.

She should at least experience love and sex first...

"I feel like I know the perfect person to model..."  
"Me too."  
"Me too."  
"Eh, really? Who could it be?"

He had a rough idea, but Yuu pretended not to know.

As expected, Sayaka, Riko, and Emi all looked at Yuu simultaneously.

---

### Author's Afterword

Komatsu Kiyoka, who appeared in Sayaka's flashback in Chapter 23, suddenly makes her appearance here.

Sayaka and Kiyoka. The readings are a bit confusing.

Initially, I considered an all-white outfit to match the holy image of her name, but since she's a middle schooler and a writer, I thought she'd have chuunibyou, so I went with an all-black gothic lolita style.

### Chapter Translation Notes
- Translated "寝バック" as "doggy-style position" for clarity in sexual context
- Preserved Japanese honorifics (-kun, -sama, -chan) as per rules
- Transliterated sound effects (e.g., "ahhn" for あんっ, "nom nom" for あむぅん)
- Translated "童貞を卒業する" as "lost his virginity" to convey the meaning naturally
- Translated "性技" as "sexual techniques" to maintain explicitness
- Used "chuunibyou" (中二病) without translation as it's a culturally specific term explained in context
- Kept the term "gothic lolita" as is for the fashion style
- Maintained the original Japanese name order (Komatsu Kiyoka) as per rules
- Italicized internal monologues (e.g., *(A trick of the eyes? ...)*)
- Used explicit terms for sexual anatomy and acts (e.g., "clitoris", "ejaculating", "vaginal opening")
- Preserved the author's afterword and translated it faithfully