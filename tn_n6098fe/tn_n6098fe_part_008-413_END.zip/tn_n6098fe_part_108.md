## Interlude 3: Saiei Academy Student Council, Part 1

### Author's Preface

This interlude, presented in two parts, covers the perspective of the Saiei Academy student council that appeared in Chapter 80.

---

  

""Sairei Academy is apparently holding a gender exchange event on the same day as the quiz championship.""

""My, my.""

""Hehh~""

  

At the information brought by Vice President Li Wei Hui, Student Council President Mitsuse Rinne and fellow Vice President Omori Norika uttered words of mild surprise.

However, their expressions soon turned into cold smiles.

  

""They plan to kick out Saiei (our) students by 3 PM, spend three hours cleaning and preparing, and then hold an on-campus camp.

It seems they're trying to keep it hidden from the outside world...""

""Hmph. Do they think they won't be found out?""

""How foolish~""

  

""So, what do you intend to do?""

""Hmm... nothing in particular...""

Rinne dodged the question when asked by Wei Hui.

""I don't really care either way.""

""Indeed. Rather than making a move on their turf...""

""You want to lure him onto home ground and make sure to have your way with him?""

""Ufufu.""

Rinne chuckled suggestively at Norika's words, which captured her intent.

""For that... we must secure a definite victory in the main event!

You both understand, don't you?""

Rinne's eyes turned sharp, and Wei Hui and Norika nodded emphatically.

  

  

  

  

The location was Saiei Academy High School, situated in the northern outskirts of Sakate City, Saitama Prefecture.

Being part of the same Ayakuni Group, it has a relatively short history and was established with a focus on arts and culture, featuring facilities on par with a small university and a vast campus area.

Unlike Sairei Academy, whose student council shares space within school buildings, Saiei's student council has its own dedicated building.

Constructed 15 years ago with the budget left unused after losing the co-education presentation to Sairei, it is a three-story structure with each floor spanning an area equivalent to about three classrooms.

Its exterior resembles a stylish office building that wouldn't look out of place in a prime Tokyo location, a design choice made to accommodate the requests of the student council members at the time.

  

The first-floor entrance features a reception desk for visitors and a conference room about the size of two classrooms.

The second floor has a multipurpose hall equipped with audiovisual facilities and a materials room.

The third floor is where Rinne and the others are currently chatting in the student council room.

  

Though called a student council room, it bears no resemblance to a typical high school space.

The room beyond the stairs has a chic interior dominated by dark gray and brown tones. Sturdy black leather reception furniture and a heavy oak table are arranged in a U-shape, where the accountant and secretary are currently busy with clerical work.

  

Separated by a door, the central area is where Rinne and her group are relaxing. The interior and furniture are coordinated accordingly, featuring a Rococo style with white as the base and lavish use of gold, from the opulent chandelier to the table, chairs, chests, and sideboards, all adorned with elegant, graceful curves.

This area alone evokes the atmosphere of a French royal court in its heyday.

  

Just then, a knock sounded from the door leading to the inner rooms. When Rinne responded, the door opened, and a tea set on a trolley was wheeled in.

Pushing the trolley was a boy who appeared to be around 12 or 13 years old.

He had curly black hair and slightly dark skin. His features were deeply sculpted, giving him a distinct Oriental beauty. He wore black shorts and a white dress shirt, with a bow tie fastened at the neck.

  

""Ladies, I have brought your tea.""

""Oh? Is it that time already?""

When the serving boy addressed them in his pre-pubescent boy soprano voice, Rinne and the others exchanged glances.

They hadn't planned anything specific for today, but after gathering right after school for a chat, it seemed they had passed 3 PM without noticing.

  

The teacups placed before the three, adorned with gorgeous patterns that alone could easily blow away an office lady's monthly salary, were filled with richly steeped tea.

Even the cookies arranged on the large plate were exceptional, specially ordered from a high-end confectionery in Tokyo, unlike anything sold at local supermarkets.

An elegant after-school tea time, sparing no expense.

This tradition had taken root from the custom of heiresses assuming the student council presidency generation after generation.

  

""Darjeeling today, I see.""

Rinne murmured, savoring the rich aroma rising from the cup she held.

She brought the cup closer and took the first sip without a sound.

Maintaining her composed expression, she allowed a faint smile to appear.

""Well... I suppose I could grant it a passing grade.""

""Ha... I am honored. ...kuh!""

""Good for you, Amir. You've finally started to gain Rinne's recognition lately~ It was terrible at first, you know~""

""Ah... y-yes...!""

Without warning, Norika's left arm had reached Amir's buttocks and was groping him lewdly.

  

""Amir is still a cherry boy, so keep it moderate.""

""Mmmph. Nice ass. Hey, President Rinne, can I eat him?""

""No.""

""Tch.""

  

While the flustered boy was ignored, the exchange between Rinne and Norika continued as usual. Only Wei Hui remained indifferent, munching on cookies with a *boribori* crunch.

Norika continued to toy with Amir, and Rinne seemed not to have heard the knock at the door. When they noticed the second-year secretary and accountant peeking in, they straightened their postures.

Seizing the opportunity, Amir bowed and hastily retreated to the inner kitchen.

  

""S-sorry to interrupt your pleasant conversation.""

""What is it?""

  

It seemed a student had come to see Wei Hui. She washed down the cookie she was eating with tea and stood up alone.

  

Wei Hui returned with a thick blue envelope.

""The initial report on that Sairei Academy boy has arrived.""

""My! I've been waiting for this!""

""My, my, how eager.""

Rinne and Norika watched expectantly as Wei Hui slit the envelope open with a paper knife.

The plate with a few remaining cookies was pushed aside, and the contents of the envelope were spread out on the table.

  

First, three photos. The subject was Yuu, seemingly taken at school and in front of an apartment building.

However, since they were shot from the side or at a distance, it was clear they were taken secretly.

  

Then, folded inside were two sheets of A4 paper with printed text.

As Wei Hui unfolded and displayed them, Rinne and Norika leaned in from either side to read.

Titled 'Target SR0126YH First Report', the contents were a background investigation on Yuu.

Information included family structure, his mother's workplace, his sister's alma mater, details about his protection officers, and even his friendships and actual behavior within the school. The investigator seemed to have been stationed inside the school to observe.

  

""Hmm, this is about it for now.""

""You've also commissioned a private investigator, right?""

""Indeed. Their report should come next time. I'm curious about what kind of person his father is.""

  

The main investigators were Saiei students.

Naturally, detailed investigations into family matters, which would be difficult for high schoolers, were outsourced to a private investigator.

Rinne and the others turned their attention to the second page.

  

""My! As expected...""

""Hehh~, I see.""

  

What caught their attention was Yuu's relationships, particularly with the three student council members.

At present, he was closest to Sayaka, but the description strongly suggested he was intimately involved with all three.

Upon learning this, Rinne twisted her lips in frustration.

  

""Keeping a fiancée while having fun at school too... Contrary to his appearance, he's quite the player!""

The object of Rinne's jealousy, of course, was Komatsu Sayaka.

Understanding this, Norika and Wei Hui merely smiled silently.

They knew the two came from founding families of Japan's leading automobile manufacturers and had always been rivals.

  

""If anything, he's surprisingly wild, or rather, proactive, isn't he?""

""I thought it was unusual how he didn't flinch in front of so many girls alone last time, but if that's normal for him, then maybe... no, he must be quite an unusual boy.""

  

The report detailed how Yuu got along well with female classmates through gender exchange events, his popularity across all grades due to his friendly demeanor, and how his attitude towards doctors and nurses during his hospitalization and outpatient visits at a general hospital in the city after a serious injury before high school was exemplary, making him extremely popular.

It even included witness testimonies about the incident in May when Yuu suddenly appeared alone in town, causing a commotion among the surrounding women. Naturally, the subsequent outcome remained unknown.

In any case, while this investigation provided a general overview, it didn't include the information they truly desired.

  

""Hey, this Yuu boy. Might he be quite the ladies' man?""

""Is that Norika's intuition?""

""Maybe we can seduce him without needing to find leverage?""

""Hmph.""

  

Rinne snorted at Norika and Wei Hui's conversation.

""Simply having our way isn't enough.

We'll take him from Komatsu-san, train him until he obeys our every word... and then flaunt it right in front of her!

The perfect opportunity will be when we invite Sairei's boy to our school.

We'll use every means, take our time, and discipline him properly.

I'm looking forward to it already. Oh-hohohoho!""

  

Rinne laughed haughtily like a villainess from a story, while Norika and Wei Hui watched with half-amused smiles.

But neither believed it was mere playful talk.

If Rinne decided to do it seriously, she had the power and money to carry it out.

Because she was the daughter of one of Japan's leading financial conglomerates and the student council president of Saiei Academy.

  

  

  

  

Let us now explain the Saiei student council.

Like a typical student council, the officers consist of a president, two vice presidents, an accountant, and a secretary, totaling five members.

Below them are various committees, with the total membership reaching 50.

Currently established committees are: Discipline Committee, External Relations Committee, Materials Committee, and Health Committee.

Each committee is headed by a student council officer. Some members are dedicated, but over half hold concurrent positions in clubs or hobby groups.

Officially, they engage in activities suggested by their committee names.

  

However, the reality is quite different.

The Discipline Committee is composed almost entirely of loyal followers of the student council president.

Within the school, they police students who make statements or actions against the current student council, sometimes subjecting them to various forms of harassment, even driving them to voluntarily drop out.

They are essentially the school's secret police.

  

The External Relations Committee handles negotiations outside the school, often involving males.

They are the execution unit that, in cooperation with the Materials Committee (described later), works to make targeted males serve the student council.

For example, regarding Amir, who began serving the student council this year, the External Relations Committee infiltrated his family situation, used threats and wads of cash, and negotiated to have him come to Saiei Academy every day after school.

Incidentally, the heads of the Discipline and External Relations Committees are President Rinne.

  

The Materials Committee gathers information.

First, within the school, they conduct surveys targeting all students and collect information from class representatives. They also pick out promising students to scout for the student council. This group is called the ""Internal Investigation Unit"" (内調).

Kate was scouted from this year's freshmen.

For some reason, Rinne took a liking to her and placed her directly under the officers as a member without portfolio.

Though the at-large members handle various odd jobs under the officers' direct orders, the benefit is learning the ins and outs of the student council while working, making it a shortcut to becoming an officer in the next term, just as Rinne did in her first year.

  

On the other hand, the group investigating external males is called the ""External Investigation Unit"" (外調).

Committee members sometimes conduct investigations directly at various institutions or through diligent inquiries, but specialized investigations are sometimes outsourced to the student council's go-to private investigation agency.

Furthermore, over the years, they have cultivated internal collaborators in nearby co-ed high schools — in this case, specifically Sairei Academy — middle schools, and even (male-student-attending) universities.

Understandably, all-boys schools remain out of reach due to distance and strict security.

Their detailed knowledge of Sairei Academy comes from information provided by these internal collaborators.

The head of the Materials Committee is Wei Hui.

  

The last one, the Health Committee, headed by Norika...

  

  

  

  

---

### Author's Afterword

In the initial setting, Sairei Academy became co-ed 15 years ago, but for some reason, it changed to 10 years ago in the author's mind.

If there are any parts stating 10 years, I will correct them.

### Chapter Translation Notes
- Translated "彩麗(うち)" as "Saiei (our)" to convey the possessive nuance and clarify the academy reference
- Transliterated sound effects: "ボリポリ" → "boribori"
- Preserved Japanese honorifics: "-san" for Komatsu Sayaka, "-kun" omitted per original text absence
- Maintained Japanese name order: "Mitsuse Rinne", "Li Wei Hui", "Omori Norika"
- Translated "躾けて" as "discipline" in context of behavioral conditioning
- Translated "調教" as "discipline" with implied connotation of control/training
- Rendered "オーホッホッホッホー" as "Oh-hohohoho!" to match villainous laugh convention
- Translated "標的 SR0126YH" as "Target SR0126YH" maintaining code name format
- Translated "身上調査書" as "background investigation" for accuracy