## Interlude 3: Saiei Academy Student Council, Part 2

### Author's Preface

There are scenes where men other than the protagonist are tormented and engage in sexual acts.

---

"Hey, wanna go inspect the basement?"

After having their tea refilled and chatting while reading Yuu's investigation report, the three were suddenly invited by Norika.

Rinne, who had been intently looking at Yuu's photos, raised her face and tilted her head.

"Hmm, we don't have any particular business today... I suppose."  
"I don't mind either way."  
"Then let's go! Come on, it's our duty as student council officers to check if the committees are doing their jobs properly, right?"

Rinne smiled wryly at Norika's enthusiastic invitation while Wei Hui nodded reluctantly.

---

In principle, only students belonging to the student council and those who have applied to and received permission from the Health Committee can enter the basement of the student council building. Access is restricted to either the locked staircase room on the first floor entrance or the direct elevator from the third floor student council room.

After informing the accounting and secretarial staff in a separate room, the three descended to the basement via elevator. When they opened the thick door at the bottom, a lewd smell mixing male and female body odor and sweat immediately assaulted their noses. Though the air-conditioned room was spacious enough for two classrooms, an odd heat seemed to linger inside. On the huge mat in the center—easily large enough for ten people to lie down—four pairs of naked men and women were intertwined.

"Th-this! President and vice presidents!"

Several female students who had been chatting while watching the four pairs coupling against the wall sprang up the moment Rinne and the others entered. Among them, a third-year student who seemed to be the representative stepped forward.

"Good work. Just our routine inspection~. How's it going today?"

The person being addressed was the vice-chair of the Health Committee, subordinate to Norika despite being the same grade. "Yes. Today, 12 applications for use were approved. With 4 males available to accommodate them, that makes the quota 3 times per person. Currently..."

The Health Committee's actual function is the management and training of males kept by the student council. All are sexually experienced, some even having fathered children. Beyond studying the abundant materials in the reference room, they constantly practice with various devices and drugs, or train to make partners climax through practical experience with males or other females. Led by Norika, the members boast experience unusual for high school students.

Currently, the student council manages 13 males including Amir in the student council room and those servicing females here. However, they don't resort to illegal abduction. Using the influence of the student council members' parents, they pressure families' businesses, employ various schemes to saddle them with debt, or sometimes frame them with false charges in exchange for covering them up... etc. Having accumulated techniques and connections over more than 10 years since losing the co-ed proposal to Sairei Academy, they bring in males "willingly."

The third-year vice-chair continued explaining while pointing at the copulating couples. At the far left, a handsome man appearing to be in his late twenties was penetrating a female student in a facing seated position. Though his movements were slow, the girl's constant moans made it clear she was greatly enjoying herself.

"Mamoru is quite experienced, handling things smoothly."  
"Indeed. It's been over five years since Mamoru came. Though not large, his endurance and technique are top-class among the males we have."

Next to them, a large-built girl was straddling a petite middle-school-aged boy, vigorously rocking her hips. "Y-yes! Feels good! Ah, ah, ahhh... might... cum for... first time..."  
"Haa, haa... I'm... almost..."  
"No! Just a bit more, just a bit more! Hang in there! Shou!"

"Shou is still inexperienced, but his size is decent and he recovers quickly, so he shows promise. He just needs to get used to it."  
"Indeed. Only 13 years old. His future looks bright."

The vice-chair continued smoothly until she looked at the other two couples and grimaced. One man in his twenties and another high-school-aged male sat hunched over with their backs to the girls, their crucial penises shrunken small and not recovering. As two Health Committee members approached from behind the males, Norika raised her hand to stop them. "May I handle this~?"

The Health Committee members' eyes sparkled with anticipation. "Ooh, the vice president herself...", "Might get to see Norika-sama's technique..."

---

"Want to play a little?"  
Rinne and Wei Hui exchanged glances at Norika's question. "I—" Wei Hui began, but Rinne spoke over her. "I'm not in the mood, and... those two aren't to my taste."  
"Ugh..."  
"Come on, Wei Hui, come. You can do whatever you like with them~?" Norika grinned lewdly and pulled a reluctant-looking Wei Hui toward the mat.

Standing beside the mat, Norika deftly removed her sailor-style uniform dress. A Health Committee member immediately took it and hung it on a hanger. After shaking out her long, one-length black hair, Norika revealed purple translucent lingerie underneath. The full-cup bra supported her prominently protruding large breasts. Her waist was beautifully slim, and her rounded buttocks pointed upward. Dressed in lingerie, Norika radiated a sensuality unimaginable for a high school student.

"Ahh... as expected of Norika-sama, wonderful!"  
"I want to be held by her just once..."

Though slender figures are currently fashionable, it depends on the person. For the Health Committee members, Norika's mature sex appeal and superb figure were objects of admiration.

The girl who had been berating the unerect high school boy noticed Norika approaching and bowed, stepping aside. Norika slid close to the crouching boy and lifted his chin. Feeling her perfume and soft skin, the boy immediately flushed. Around 16-17 with short hair and a boyish face still bearing acne marks.

"Cute boy. I'll perk you right up~"  
"Huh...?"  
Norika licked her lips and forcibly captured his mouth. "Mmph!?" The boy struggled momentarily, but couldn't escape Norika's firm hold on the back of his head. Her tongue greedily explored his mouth. The boy teared up in confusion at the unfamiliar sensation but gradually began moaning. Throughout the deep kiss, Norika's left hand roamed his body—neck to shoulders, collarbone, chest to stomach, armpits—her fingertips dancing lightly like piano keys over his skin.

"Mmmph... oooh... ooh, ugh, ughh! Nn, mmph!"  
"「「「Wahhh!」」」"

Cheers rose from the girls watching Norika torment the boy. His previously shrunken penis was slowly rising.

When Norika's lips finally parted, strands of saliva connected them. "Ahh, ahh, ahhh!"  
"Ufufu, feels good~?"  
"Ugh, ugh, feels... goo...ood... ahhh!" The boy answered while flinching as Norika's fingers tickled his sides.

"Stick out your tongue~, say 'ahh'"  
"Ahhh~"  
The boy obediently stuck out his tongue as Norika stroked his head. "Good boy." After licking her saliva-coated lips, Norika sucked his tongue into her mouth as if devouring it. The deep kiss involved persistent, slimy tongue play while her left hand descended to his lower abdomen—not touching the penis directly but attacking from the periphery. Her fingers traced his inner thighs, played with his anus, then gently massaged his scrotum. After ending the kiss, she trailed her tongue down his neck, sucking while descending. When she lightly nibbled his collarbone, his body jerked. When she sucked his nipple, the boy let out a long moan. "Aaaaaaaaahhhhhhhhh!"

Finally, when Norika's fingertip touched the tip and circled the glans before stroking the frenulum, his penis became fully erect. Apparently pseudo-phimotic, the glans had been covered when semi-erect but now the pinkish head was exposed. Though average-sized at about 10cm.

"All right~"  
As Norika signaled, a delighted female student straddled him while Norika continued kissing and fondling his ears from behind. "Uwaaah!"  
"Ahh... guh... ughn! Ah, ahhn! ...Haa, haa, yes! With this, I'm no longer a virgin! Kuhuhu!" Ignoring any hymen-breaking pain, the girl cried out joyfully and began rocking her hips.

---

Meanwhile, Wei Hui only removed her shoes and approached the college-aged man without taking off her uniform. The girl with him glanced at Wei Hui and whispered "P-please" before stepping aside. When the man looked up and met Wei Hui's eyes, she commanded "Lie down" in one word. Trembling at her intensity, he paled and obeyed, lying supine.

Wei Hui looked down at his emaciated, rib-protruding body and declared, "A wretched body. And a wretched sexual organ. If the symbol of manhood remains shriveled before a woman, you have no value living." Simultaneously, she planted her foot on his abdomen and ground down. "Th-that's cruel. I didn't come here because I wanted to—"  
"Weren't you the one whose family lost big in stock trading?"  
"Th-that's...! The securities company said it was guaranteed profit!"  
"Just sales talk. Nothing in this world guarantees profit. That you blindly believed it at your age proves your stupidity. Ah yes, your so-called investor father too. What fools."  
"Ugh... deceiving men is a crime!"  
"Don't flatter yourself! Men aren't special. Useless trash like you is harmful. You maggot."

Wei Hui's toe prodded his head. Though it looked painful, she seemed to control the force to avoid bruising. The man appeared more mentally scarred by her words.

"As harsh as ever, Vice President Li. Though we're the ones who set them up..." the vice-chair whispered to Rinne, who knew the circumstances. The securities company that trapped them belonged to a financial group owned by the student council members' parents.

"Well... Wei Hui's hatred of men runs deep, but that verbal abuse and foot technique sometimes awakens masochism in men."  
"Indeed, Vice President Li never participates in normal intercourse. A waste, I think."  
"She used to be a normal girl who loved her father. But after he abandoned her and her mother... Oh, this is secret, okay?"  
"Yes. Understood."

While verbally abusing him—"You men are social misfits who escape reality, garbage, maggots, gnats, cockroaches"—Wei Hui stepped on his face. Though her skirt contents were visible from his position, she showed no concern, viewing him as inferior. Moreover, she remained perfectly balanced on one foot, suggesting strong lower body training.

"Hah. Though you're hopeless trash, there are girls waiting, so I must make you erect. What a chore." Wei Hui straddled him, prodding with her toes to spread his legs. His previously shrunken penis now seemed semi-erect as if asserting itself.

"What? Getting excited after all that abuse? Haha! I see—you're a pervert who gets off on being tormented!"  
"Kuu..." The man averted his eyes in shame but flushed slightly. When Wei Hui removed her navy knee-high socks and skillfully rubbed his penis between her toes, he screamed "Gwaah!" and jerked.

"St-stop... hiiiiii... ah! Ahh..." His small penis hardened rapidly under her toe manipulation. She alternately stomped it and curled her foot to play with the glans. Soon, clear fluid leaked from the tip, making squelching sounds when manipulated. "Good."

After glancing disdainfully at the now fully erect penis—slightly smaller than the high schooler's—Wei Hui called to the waiting girl. "Y-yes! Thank you! I was mesmerized by your amazing technique!"  
"It's nothing special."

As Wei Hui moved aside, the girl straddled the man and lowered herself. Meanwhile, Wei Hui moved to his head and pressed her toes against his face. "Lick."  
"Ah, ah, guh... hii!"  
"Ahh, nn... oh! Th-this is a penis... Haha. Not as impressive as I thought compared to a vibrator. Oh well. Cum inside me!" The connected girl firmly gripped his sides and began rocking her hips in small motions. Apparently trained for intercourse, having broken her hymen with vibrators beforehand. The soulless-looking man obediently licked Wei Hui's footsole and toes coated with pre-ejaculate.

---

Seated on a chair prepared by the Health Committee, Rinne crossed her legs elegantly while watching the copulating couples. Though sexually inclined, none of the present men moved her. Her thoughts were occupied by the absent Yuu. *(Now of all times, for me to expect something from a man...)*

The investigation suggested he was already skilled with women despite being a first-year. Perhaps with Yuu, she might experience unprecedented sex. Somehow, she couldn't shake that feeling.

*(Expecting too much only leads to greater disappointment. Men are weaklings who can't survive without female protection. Rather, I'll train him to be my good toy.)*

Since middle school, Rinne had dated many men through family influence and had experience. But after her first partner went limp midway, repeated disappointments left her rarely tasting sexual pleasure. She desperately suppressed her growing expectations for Yuu, lecturing herself. Yet since seeing his photo earlier, memories of their meeting—exchanging words, touching his slender but firm body—vividly resurfaced. For some reason, the more she thought of Yuu, the more her heart raced. Unaware, Rinne harbored near-romantic feelings for Yuu despite meeting him only once.

---

### Author's Afterword

The next chapter begins Part 4, but I'll take a one-update break. As it's a milestone, I plan to update the character and setting materials when the next chapter is posted.

### Chapter Translation Notes
- Translated "雄" as "males" to maintain biological precision in sexual context
- Preserved Japanese honorifics (-sama for Norika, -san for committee members)
- Translated "破瓜" literally as "breaking the melon" to retain cultural metaphor for virginity loss
- Used explicit anatomical terms ("penis", "glans", "scrotum") per style guidelines
- Transliterated sound effects (e.g., "Uwaaah!" for う゛ぁっ)
- Maintained original name order (e.g., "Li Wei Hui" not "Wei Hui Li")
- Rendered simultaneous dialogue with double quotes ""..."" for group reactions
- Italicized all internal monologues per formatting rules