## 101. Changing Students ① ~No.1~

### Author's Preface

This chapter doesn't have much action, but in Chapter 4, the protagonist's number of partners is scheduled to increase rapidly.

---

Late June. The rainy season is in full swing.

Cloudy or rainy days outnumber sunny ones, and even indoors, the air feels muggy.

During this period, crowded places like trains, station fronts, and main streets become increasingly humid and unbearably stuffy due to body heat.

But today, as if offering a break in the rainy season, strong sunlight had been beating down since morning.

According to the weather forecast, the temperature would reach 30°C, but rain was expected in the evening.

Yuu recalled how tough commuting was during this season.

But Yuu—or rather, boys in general—were privileged due to their scarcity.

After all, a bus transported them from the apartment building to the second school building, so umbrellas were unnecessary.

The shuttle bus windows couldn't be opened, but the air conditioning made the ride comfortable.

When the bus arrived at school and stopped at the second building's entrance, the male students disembarked one after another.

Following the second and third-year students, Yuu got off with Rei, but the moment they stepped outside, they were hit by a wave of humid heat.

"It's hot again today."  
"Yeah. July's almost here."  
"Ah, once the rainy season ends, summer will be in full swing. About one more month until summer vacation."

As they walked while chatting, they soon saw female students lined up like beads along a roped-off area beside the entrance.

Though standing directly in the blazing sun, the girls in short-sleeved summer uniforms with exposed arms remained energetic despite the heat. After all, boys were walking past them after getting off the bus.

The number of girls waiting had recently been increasing.

According to upperclassmen, the peak was usually around enrollment time, decreasing after Golden Week and halving during the rainy season. It would slightly increase again from fall to winter but hit its lowest point around New Year's.

Yet even now during the rainy season, the numbers hadn't decreased at all. No—though they seemed to dip temporarily, they'd actually started increasing again since mid-June.

And there was another unprecedented sight unfolding before them.

""""""Good morning!""""""  
"Hey."  
"Morning. You're energetic this early."  
"Mornin'..."  
"Mhm."

The boys responded in various ways—waving back at the girls who energetically greeted them. Some boys, apparently familiar with certain girls, even approached to exchange a few words.

Yuu recognized one reason for this change: the recent sports festival.

Until last year, boys hardly participated, but this year, following Yuu's suggestion, they were assigned to cheer for specific classes. Preparation time allowed the boys to cheer passionately during events, fostering unity between genders as teams advanced through competitions.

After the festival, Yuu heard from many that the distance between boys and girls had shrunk school-wide. Considering the co-ed school's purpose of fostering gender interaction, this was a positive trend.

After the third-years passed through and entered the second building, Yuu and Rei stepped into the area as the second-years were halfway through. Today Yuu wore a white polo shirt with beige chinos—a refreshing summer outfit. Rei, despite the muggy weather, wore formal attire: a white long-sleeved shirt and black slacks. Perhaps due to sensitive skin, he tended to cover up as much as possible.

But combined with his androgynous features, this apparently drove girls wild. The moment the two came into view, high-pitched cheers erupted.

""""Kyaaaaaa!""""  
"It's Hirose-kun!"  
"Higashino-kun!"  
"Hirose-kun, you look super cool today~"  
"For cuteness, Higashino-kun still wins!"

"Still as popular as ever," Rei remarked with slight exasperation, but after nearly three months, he'd grown accustomed. He no longer cowered under the chorus of female voices like he did initially.

"Ah, but it doesn't feel bad, right?"  
"Well... being with you, Yuu-kun, kinda forced me to get used to it..."

Rei seemed influenced by Yuu, who remained composed—even pleased—interacting with girls up close. So Yuu and Rei casually approached the end of the female line. Yuu noticed familiar faces among the girls smiling expectantly: about seven or eight members of Class 5 who'd participated in dodgeball.

""""Good morning, Hirose-kun!""""  
"Good morning."

Yuu shook hands with each as he greeted them, feeling like a celebrity meeting fans. Most boys just waved or lightly touched a few in the front row, but Yuu never missed shaking hands with any girl who reached out. While holding hands, Yuu carefully observed each girl. Conversely, the girls scrutinized Yuu from head to toe with intense gazes. Yuu spent longer with each person—a key reason for his growing popularity.

Perhaps influenced by Yuu, Rei was shaking hands with several tall girls slightly farther away.

"Did I get everyone?"  
"H-Hirose-kun! Not me yet!"

Aramaki Yoshie, Class 5's committee member, jumped up and down while stretching her hand from the back.  
"Yocchan, over here!"  
A girl in front made space, so Yoshie came forward with thanks. Sweat already glistened on her forehead, and her long black hair—half-up in braids—was slightly disheveled.

"U-um... Hirose-kun, good morning."  
Yuu took her hesitant outstretched hand. "Good morning, Aramaki-san. Your pretty hair's come undone."

Yuu smoothed her hair with his other hand, brushing strands from her cheek to the back. When his fingers touched her face, Yoshie's cheeks flushed deeper.

"Hau..."  
"That hairstyle really suits you. Very cute."  
""""Ooh...""""  
For some reason, murmurs rose around them.  
"Th-thank... you. H-Hirose-kun..."

Behind her glasses, her eyes sparkled as if heart marks floated in them. Yuu genuinely liked Yoshie's earnest, committee-leader type. He'd even thought about doing something erotic with her someday.

The shrinking gender gap across grades affected Yuu too. While he'd been the only first-year boy interacting freely with girls initially, others like Rei and Haruto were gradually overcoming their reluctance. So Yuu stood out less than before—though his willingness to touch girls and constant smile still made him special.

After Class 5, Yuu slowly progressed, greeting girls who called his name with handshakes and high-fives. Some were regulars he'd befriended here; others were new. Near the line's end, several tall girls called his name in unison. Rei had already entered the building.

"Huh? You're from Class 1, right? Volleyball players?"  
"Yeah! You remembered us?"  
"Back then, we were so jealous of Class 5 getting Hirose-kun's passionate cheering!"  
"Haha. Well, I had to, since they were my assigned class."

The six girls were Class 1's volleyball players who'd faced Class 5 in the finals. Half were clearly taller than Yuu—around 175-180 cm. Likely club athletes, their toned physiques showed even through uniforms. Their hair was short or simply tied back to avoid interfering with sports. Yet true to Sairei Academy's standards, all were exceptionally cute.

Perhaps unused to boys, they blushed with happy expressions when Yuu took their hands one by one.

"Hey, Hirose-kun... um..."  
"Yeah? What is it?"

After shaking hands, the tallest girl spoke haltingly as their representative. This might be their first meeting here—Yuu couldn't recall even waving at them before.

"We've... only watched you from afar until now..."  
"Really? You could've talked to me anytime."  
"Ahaha. I thought you'd say that."  
"See? Too much competition."  
""""Exactly!""""

They nodded together. Indeed, when Yuu walked through corridors or outdoor passages during breaks, girls quickly spotted and approached him. Frequent visitors included Yoko and Kazumi from Class 5. These girls apparently hadn't tried pushing through crowds to reach him.

"So, um... here."  
"Me too."  
"And me."

What they produced one after another were adorable colored and patterned letters. All addressed to Yuu, of course.  
"W-will you accept them?"  
"Of course. I'll gratefully take them."

Yuu accepted each letter.  
"Well, homeroom's about to start..."  
"R-right. Thank you for today, Hirose-kun."  
"Thank you too. Glad we could talk. And thanks for the letters."

When Yuu expressed gratitude, the Class 1 girls smiled with visible relief. Deciding to give love letters to a boy for the first time must've required courage. Yuu himself had once confessed to a crush via letter in middle school—only to be friend-zoned. Now receiving letters felt gratifying, though six at once was a first.

***

During first period break.

Yuu took out the letters received that morning. He didn't open them in class due to prying eyes. Instead, he unfolded an A5 memo pad.

Since the April gender-exchange event's self-introduction rounds, Yuu had started taking notes due to the overwhelming number of girls approaching him. Now he recorded each sender's appearance and conversation impressions on their letters' backs.

In his past life as a new hire in sales, a senior taught him to jot down people's traits on business cards after exchanges. Meeting multiple people simultaneously made it easy to forget faces unless they left strong impressions. Notes helped match names to faces later.

Classmates were easier—Yuu had memorized most boys in Class 5. But with girls across seven classes, one meeting rarely sufficed. So he'd revived this habit from his past life.

"Wow! Yuu-kun, amazing! Six letters today?" Rei, having prepared for next class, turned around in surprise.  
"Well, first time getting six. Just taking notes so I don't forget."  
"Heh, didn't know you were so meticulous."  
"Guys this thorough with girls are rare."  
"Nothing wrong with that! Gotta show gratitude for letters."

Joining Yuu and Rei's conversation were Yamada Masaya and Hosho Haruto from the back seat. Since the sports festival, they'd grown close enough to use first names.

The boys' topic shifted to letter counts. Rei had over thirty—mostly from tall girls like Sato Risa and Ukawa Miyoko in volleyball and basketball clubs. Haruto's count surged after the festival too, reaching twenty, with letters scattered across first-year classes.

Masaya remained vague.  
"Probably from band club girls, right?"  
When Yuu pressed, Masaya mumbled evasively and looked away.

Yuu also fudged his exact count, though today's haul should bring his total near one hundred. Initially, most came from Class 5 girls, but others included today's Class 1 senders and even a second-year stranger.

Letter contents rarely expressed outright feelings—first-years seemed restrained. Most focused on self-introductions mixed with daily life topics about home or school, aiming to make themselves known. They typically ended with requests to talk at school.

Letters from girls like Yoko and Kazumi who knew Yuu well overflowed with praise, making him blush.

Receiving so many letters made replies seem daunting. In mid-April when letters started, Yuu seriously worried about responding to dozens. A luxurious problem compared to his past life.

Early on, second and third-year boys visited homerooms to advise on co-ed school life. Though Yuu had broken the "always move in groups" rule immediately.

When Yuu asked about replying after receiving over ten letters, seniors unanimously advised against it. Replies might excite girls and create endless cycles. Better to just read them—treat them like fan mail.

For contact methods beyond letters, they strictly warned against sharing home phone numbers except with serious partners. One boy at another school had casually given his number to three girls, only for it to spread and subject him to constant calls. Yuu had only given his to Sayaka, trusting her discretion.

As months passed, more letters contained obvious affection, but Yuu still hadn't replied—partly due to volume. Instead, he tried remembering senders and greeting them during morning meetings or breaks. This alone thrilled the girls. Yuu's top popularity among first-year boys stemmed not just from looks but also his friendliness and these efforts.

Though most letters weren't outright confessions, receiving nearly a hundred expressions of interest made Yuu ponder. So far, he'd been physical only with the student council trio and Class 5's Yoko/Kazumi—five total. He had no complaints about them, but why not leverage his handsome rebirth and female attention? After all, girls welcomed his touches eagerly.

The problem was location. With Sayaka's group, he used the student council room. With Yoko and Kazumi, he'd succumbed in a restroom. Wasn't there any convenient, discreet spot at school for sex?

***

### Author's Afterword

Those interested in the origins of Part 3's subtitles can check the activity report. (I may delete this later.)

Also, due to personal reasons, the next update will be on 8/12 (Monday).

### Chapter Translation Notes
- Translated "じめじめ" as "muggy" to convey humid discomfort
- Preserved Japanese honorifics (-kun, -san) per style rules
- Translated "ひといきれ" as "body heat" for cultural context
- Used "Yocchan" for "よっちゃん" as established nickname
- Transliterated sound effects (e.g., "Kyaaaaaa!" for "キャーーーーー")
- Translated "舞い上がって" as "excite" in context of emotional response
- Maintained Japanese name order (e.g., Aramaki Yoshie)