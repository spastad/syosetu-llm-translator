## 102. Changing Students ② ~Embrace Everything~

The second-period class ended slightly early. The moment the chime sounded and the teacher left the classroom, Yuu stood up with textbooks and writing utensils for the next class already prepared.

"I'm heading out first then."  
"Huh? Yuu-kun?"

Without waiting for Rei's surprised response, Yuu swiftly opened the door and dashed out. "What's up with him?" "Dunno... Ah! He did the same thing the day before yesterday. Wonder what he's in such a hurry for?" Rei and Masaya could only tilt their heads in confusion at his sudden action.

After exiting Building 2, Yuu didn't use the covered walkway but instead took a diagonal shortcut across the paved courtyard. His body was enveloped in scorching heat and clinging humidity from the strong sunlight's reflection, but he ran off without concern. Fortunately, since classes had just ended, there were no female students around to stop him.

Upon reaching the administration building, he bounded up the exterior staircase on the schoolyard side, skipping steps. But in his haste, he nearly collided with a female teacher coming down. "Kyaa!" "Whoa!" At the staircase landing, they almost crashed head-on. Seeing the woman lose her balance from his momentum, Yuu immediately dropped the textbooks he was carrying and pulled her toward him by the hand. She must teach girls-only classes. Though he hadn't seen her before, her appearance—black semi-long hair, slender tall frame, white knit top, and navy blue long flared skirt—suggested an elegant teacher who'd suit playing piano. She appeared to be in her late twenties.

"My apologies. Are you alright?" Yuu immediately apologized, acknowledging his fault for running up. "Ah... a-aah... I-I'm f-fine..." Though half-hidden by her long hair, the teacher blushed and flustered upon realizing Yuu was before her. Yuu noticed he was still gripping her hands and shoulders at close range and let go. The teacher showed a slightly disappointed expression, but Yuu didn't notice as he was picking up the dropped textbooks and stationery.

"Excuse me then." "R-running on stairs is dangerous!" "Sorry. I'll be careful." The teacher widened her eyes in surprise at Yuu's straightforward apology. After a quick bow and cheerful smile, Yuu left at a brisk walk instead of running. The teacher watched him blankly, hesitated about chasing him, then gave up. "Ugh... I finally got to interact with Hirose-kun, and what am I doing?" Apparently, even girl-class teachers knew about Yuu.

Yuu hurried up the exterior stairs as fast as possible and reached the third floor. Upon opening the door, he immediately noticed Yoko and Kazumi waiting. "Yuu-kun!" "Hey, you're early." "We just got here too." "I'm so happy you came early, Yuu-kun!" "Hehe. I was looking forward to it too." Yuu took Yoko and Kazumi's hands as they approached, exchanging smiles.

The two girls who'd first become intimate with Yuu during the sports festival had been trying to create opportunities to connect since the new week began. But after-school hours were busy with club activities and student council work.

So they'd secretly arranged during their morning meeting: They'd meet during break on days when the boys' class moved to administration building classrooms for third period. Though breaks between classes were normally only 10 minutes, the period between second and third period was 20 minutes long—a consideration for boys needing extra time to move between distant buildings. Boys' classes were therefore scheduled for mobile subjects like PE or music during third period. Today's third period was chemistry in the science room on this building's second floor.

Thus Yoko, Kazumi, along with Yuma and Mashiro who'd joined them—four girls connected since the Newcomer Welcome Orienteering—had been meeting Yuu during breaks for intimate contact twice last week. But today, Yuu noticed more had joined.

"Oh? Nakai-san and others too?" "We got found out..." "We noticed Yoko and the others rushing out right after class ended. Seemed suspicious." They were at the dead end of the administration building's third floor hallway, in front of the music room. Yoko, Kazumi, Yuma, and Mashiro surrounded Yuu, blocking him from the hallway. Today, four more had joined—all familiar to Yuu. They were the volleyball team members from the sports festival, who'd enjoyed "rewards" of physical contact with Yuu after the games.

The tallest at about 180cm was Nakai Mao. She'd sat in front of Yuu during the orienteering bus ride, starting their connection. Her short hair suited her cute small face, and her legs were so long she seemed eight heads tall (though her chest was modest). Having been in volleyball club during middle school, she'd led her team as ace attacker during the sports festival. In high school, she joined baseball club aiming to become a swift-hitting outfielder.

Next in height was Yokota Satilat—nicknamed Sati—a Thai-Japanese mix slightly over 170cm. Her tanned wheat-colored skin blended with Japanese features, making her heritage unnoticeable unless mentioned. Thai women were famously beautiful among Southeast Asians, and Sati inherited her mother's beauty. Her mature aura suggested she'd become a stunning beauty in a few years.

Ueno Shoko, a softball club pitcher, matched Yuu's height but had broad shoulders and solid muscles. Her large breasts (though not as big as Mashiro's) had drawn Yuu's eyes during the sports festival. Though loud and enthusiastic during games, she was usually shy—a contrast Yuu found fresh.

Lastly, Shimozono Kayo stood about 160cm like Mashiro. Her short bob and cheerful, clear-speaking manner made her pleasant company. Sati and Kayo belonged to soccer club.

Being surrounded by eight girls was unexpected, but Yuu's cheeks relaxed naturally seeing their above-average cuteness. While Yoko and Kazumi (whose virginity he'd taken) were special, the other six had shared intense physical contact too. But one thing concerned him.

"Same spot today?" The music room entrance had a protruding area creating a slight blind spot from across the hallway—where they'd intimately cuddled two days prior. But with nine people including Yuu, they'd be visible.

"Hehe. We planned properly today. Yuma-chan?" "Leave it to me!" Yoko smiled confidently and signaled Yuma. Yuu noticed a desk placed against the wall near the music preparation room—which he recalled was usually locked. Standing on the desk, Yuma reached up and rattled open a high window, then pulled herself through like a chin-up. Though the window was small, her petite frame barely fit. She didn't mind her skirt lifting, revealing tulip-patterned panties.

After dropping inside, Yuma unlocked and opened the door. "Whoa!" "No time, come in!" "Yeah!" Hands grabbed by Yoko and Kazumi, Yuu entered surrounded by girls.

The long rectangular room smelled dusty from disuse. An old wooden desk near the entrance was piled with sheet music and faded handouts threatening to collapse. Steel shelves lined the walls—cardboard boxes below, music-related books crammed above. Opposite stood music stands, peeling wooden chairs, instrument cases, and stacked portraits of composers (discolored and torn, likely removed from the music room). Resembling a storage room, only the entrance area had space for more than two people.

The moment Kayo locked the door behind them, the girls silently exchanged glances before staring at Yuu. Though brief, this guaranteed uninterrupted time with Yuu. Mao, Shoko, Sati, and Kayo especially anticipated recreating their "reward" from the gym storage room. Oblivious, Yuu praised "Yuma-chan, amazing!" while patting her head, making her squint happily.

"Yuu-kun!" As if synchronized, Yoko and Kazumi closed in from both sides, grabbing his arms. "Whoa!?" Mao used her height advantage to embrace Yuu's head from behind. Mashiro pressed from the front, sandwiching Yuma against Yuu. They formed a flesh clump centered on Yuu. "Mm!?" Surprisingly, usually reserved Mashiro was first to claim Yuu's lips. Instantly, not just Yoko and Kazumi but even Yuma stretched up to rain kisses on Yuu's face. They knew: With limited time, hesitation wasn't an option.

Yuu couldn't possibly dislike being mobbed by girls. Surrounded front/back/left/right by soft sensations and sweet scents, he grew excited. His hands slipped under Yoko and Kazumi's skirts, fingers rubbing their panty crotches—already dampening.

"Ahh!" The latecomers Shoko, Sati, and Kayo cried out desperately while approaching Yuu, but the space was packed. They could only touch his butt and thighs through gaps.

"Not fair! Let me in too!" "No way! I don't wanna leave Yuu-kun!" "Mmmph... Kissing feels so good..." "Aahn! I wanna kiss Yuu-kun too!"

Swapping kissing partners, Yuu snapped back to reality at their voices. "Stop, stop! Everyone back up a bit!" The girls already excited from kissing and body contact didn't listen immediately. After repeated calls, Yoko's group finally pulled back.

Surveying the eager girls, Yuu spoke calmly: "Since so many gathered, I want to be fair. Don't fight over me." His words filled the latecomers with joy.

"So how?" "Take turns with time limits?" "Well..." Yuu pondered in the cramped room. Eight at once was impossible, so he'd split them... Wasting no time, he voiced his idea.

"Okay, here we go." "Ufufu." "Yuu-kun." "Come here!" Shoko and Kayo stood at the front—Yuu prioritizing the latecomers. He squeezed between their slight gap and was tightly hugged. First kissing Shoko, then Kayo immediately pressed her lips to his. They alternated kisses while Yuu boldly groped their chests over uniforms. Kayo was average-sized; Shoko noticeably large even through clothes. As Yuu fondled them, Shoko and Kayo freely touched his chest, back, and neck—upper body only by agreement.

"Haa~. So happy... I've wished for this since that day..." "Mmchu, chu, ahn, me too... Yuu-kun..." "Shoko and Kayo are so cute. I'm happy too." "Yuu-kun!" After about a minute, Yuu moved to the next pair: Mao and Sati. Though reluctant, Shoko and Kayo let go for fairness—they'd get another turn.

After enjoying the tall Mao-Sati pair, came Yuma and Mashiro. Mashiro's enormous breasts stood out, and Yuu kneaded them obsessively. In contrast, Yuma lacked breast mass, so Yuu thoroughly stroked her small body from head to neck to back with one hand. Finally, Yoko and Kazumi completed the rotation.

Yuu turned back with a smile. "Now lower body's unlocked." "U...uh-huh." "Ahaa..." All blushed while their eyes seemed to gleam with desire.

Short on time, Yuu stepped between Yoko and Kazumi who spread their arms. Their hands immediately went to his crotch. Naturally, Yuu groped under their skirts too.

"Ufufu, Yuu-kun. Your cock's rock hard." "Chu, chupajuruu! Kuhu... Your cock... ahn! Ah, there... I-I'm feeling it!" Tongues out, they deep-kissed while mutually fondling genitals. Yoko and Kazumi competitively stroked Yuu's cock, while he slid aside their soaked panties and directly fingered their vaginal openings. "Haaaaahn!" Both moaned as Yuu's middle fingers penetrated—simultaneous fingering. With squelching sounds from their crotches, they desperately stroked his cock while craving his mouth. Having experienced dreamlike first times after the sports festival, they'd masturbated using those memories—but Yuu's direct touch felt completely different, making moans unavoidable.

"Sorry. Time's up." "Aahn! Stopping now?!" "Y-Yuu-kun, I was almost..." "Now us!" "Yeah!" Around one minute later, Yuu withdrew. He couldn't bring them to climax in such short time. Frustrated at being interrupted mid-pleasure, Yoko and Kazumi gazed at him with teary eyes but suppressed their lust, finally sucking his neck like marking territory. Yuma and Mashiro already waited eagerly.

As Yuu left them, he licked his wet fingertips. "Heh. Yoko and Kazumi's lewd juice is tasty. See you later." The girls' excitement intensified seeing this—in this world, most men disliked female arousal fluids. Yuu licking it off with a smile should seem perverted, but the girls were thrilled. Yuma and Mashiro waiting before him simultaneously lifted their skirts. Yuma wore the tulip-patterned panties seen earlier; Mashiro vivid peppermint green.

"Yuu-kun, touch us!" They slid down their panties. Mashiro immediately revealed black pubic hair; Yuma showed a hairless, tightly closed slit. "Oh!" Like butterflies alighting on flowers, Yuu approached them, alternately kissing while directly touching their pussies.

Since the others except Yoko/Kazumi were virgins, Yuu avoided vaginal penetration and focused on clitoral stimulation. Despite short individual time, the anticipation and room's atmosphere made Mashiro and Yuma soaking wet. Finding their tiny nubs, he rubbed with his fingertip, making both shudder.

"Fah! Yu... Yuu-kun! Agh... feels so good!" "Ah, nnn... better than doing it myself..." Moaning cutely, they firmly stroked Yuu's cock over his pants. "Mm... nk... lero. Now Yuma. Open your mouth, stick out your tongue." "Aaahn... amchu, lero, lero, afuun... nn, nnn! Juruu! Vun!" Kissing the other pair while being stroked. Yuu fingered them directly with both hands. Sounds of tongues/lips meeting, wet noises from privates, and intermittent moans filled the room—Yuu and the girls held a lewd concert.

As Shoko and Kayo's turn neared its end, the chime sounded. A three-minute warning bell rang before first, third, and fifth periods.

"Perfect timing." "Aah... felt so good, wanted more with Yuu-kun..." "Me too! Your touch feels way better than doing it myself!" The just-finished Shoko and Kayo gazed longingly at Yuu. Normally girls wouldn't admit masturbating to boys, but Yuu was special—he remained calm even hearing about it, even asking details.

"Hahaha. Honored. Let's do it again." Yuu patted their heads, making both smile happily.

Finally, Yuu stood by the door for individual goodbyes. "Yuu-kun, thanks for today!" "You're welcome. I enjoyed it too, Mao." "Can't wait to see you again!" "Me too, Sati." Hugging, light conversation, and kisses. Pressing frontally, they felt Yuu's erect cock against their lower abdomens before leaving with damp eyes. Though happy about the group session, Yuu regretted not ejaculating. Inviting Kazumi alone for sex like after the sports festival seemed inappropriate now—they were serious students who wouldn't skip class.

After hugging and kissing Mashiro while enjoying her large soft breasts, only Yuma remained to lock up and exit through the high window—a role only possible for her small frame.

"Yuma, come here." "Mm." Lifting Yuma like a child, she clung happily after initial surprise. Staring with round eyes, she whispered: "Yuu-kun, I love you." "I love you too, Yuma." "Mufufu, happy." Their tongues lightly touched before a deep kiss with tangled tongues. A string of saliva stretched when they parted. Lowering her flushed body, Yuu patted her head. "Okay, final lock-up's on you." "Mm..." Though slightly worried, Yuma completed her task and emerged.

The girls returned to the main building via the exterior stairs Yuu used earlier, while Yuu descended the interior stairs to the second-floor science room. They'd waited for Yuu and Yuma to exit despite the approaching class time.

"Bye bye, Yuu-kun, see you!" "Yeah, later." Still flushed and restless from the afterglow, they all smiled at Yuu before descending. Yuu felt truly happy about daily closeness with cute schoolgirls—though his crotch remained hard and restless.

"Can't be helped. After school..." No student council today. Sayaka might come, but if busy, that'd be disappointing. Maybe invite Yoko and Kazumi somewhere? But how? The inconvenience of no cell phone struck him.

Mulling this over while descending, Yuu spotted a girl approaching down the hallway, struggling with a large box.

---

### Author's Afterword

The entire volleyball team from Class 1-5 during the sports festival arc appeared with names, but eight opponents was too many.

Also, last week I updated the "Character Introduction" with Chapter 3 content but forgot to announce it.  


### Chapter Translation Notes
- Translated "じりじり" as "scorching" to convey heat intensity
- Preserved Japanese honorifics (-kun, -chan) per style rules
- Translated sexual terms explicitly: "おチンポ" → "cock", "おマンコ" → "pussy", "手マン" → "fingering"
- Transliterated sound effects: "がちゃり" → "clack", "ぺろっと" → "lick", "ぴちゃぴちゃ" → "squelching"
- Maintained original name order: "中井 真央" → "Nakai Mao"
- Italicized internal monologues: *(This is concerning.)* format
- Translated "名残惜しそうに" as "longingly" to capture emotional nuance
- Used explicit anatomical terms: "クリトリス" → "clitoris", "膣" → "vagina"