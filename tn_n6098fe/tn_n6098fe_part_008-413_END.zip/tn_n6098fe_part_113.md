## 104. Changing Students ④ ~BE WITH YOU~

"Then, I'll insert it?"  
"U...un"

"It might hurt quite a bit since it's your first time. If it becomes unbearable, tell me and I'll stop midway."  
"O-okay"

Yoshie's brief responses were likely due to nervousness. For Yuu, having sex within the school grounds - not in enclosed spaces like the student council room or toilet, but in a place where they could be discovered if someone came up the stairs - heightened his excitement with a different kind of tension.

They remained in the facing-seated position with Yuu on the chair. Yuu had lowered his pants and underwear completely, while Yoshie had removed her panties from one leg and tucked up her skirt, prepared to hide quickly if someone came.

"Then..."  
"Ngh"

They had been in a sumata (dry humping) position until now, but Yuu lifted Yoshie's hips slightly from behind and pressed his tip against her entrance. As it touched her vaginal opening, a *squelch* sound echoed simultaneously with the sensation of warm wetness.

Yuu looked away from their joining point to Yoshie. Clutching Yuu's shoulders, she kept her eyes tightly shut. Though she had entrusted herself to Yuu, her body remained stiff with extreme tension.

"Yoshie"  
"A...Yu-Yuu-kun..."  
"If you stay this tense and stiff, it won't go well. Try to relax a bit more."  
"Uu...I-I know but...I mean, having s-s-sex with Yuu-kun...someone everyone admires...I still can't believe it...Now that you're really here...so wonderful...my mind is completely overwhelmed..."

Her frustrated expression showed she couldn't properly articulate her feelings.

"Fufu, you're so cute, Yoshie. I wanted to have sex with you exactly like this."  
His right hand left her hip to stroke her head.  
"B-but I understand if it's someone like the beautiful and dignified student council president...but someone like me..."  
"Don't put yourself down. To me, Yoshie is plenty attractive. I want to have sex with you not just today but from now on too. This isn't the finish line but the starting point, so no need for nervousness."  
"Fah...Yuu-kun!"

Overcome with emotion, Yoshie hugged him tightly. They kissed as if drawn together magnetically. Sensing her body had relaxed slightly, Yuu began insertion. Adjusting the angle with his left hand and hips, he released the supporting left hand - letting Yoshie's own weight sink her down, *slurping* his glans into her vaginal opening.

Feeling resistance from the hymen inside, Yuu wrapped his left arm around Yoshie's waist and thrust forcefully.

"Ngggiiiiiiiiih! Gyaaaah!"  
"Kuh...s-sorry, bear with it now!"

Pressing Yoshie's face against his neck to muffle sounds, Yuu continued penetration. His cock slowly sank deeper with wet *slurping* sounds - like forcibly parting a narrow crevasse.

"Nn...tight..."  
"Nnng-ah! Kahii..."

As Yoshie moaned intermittently, Yuu kept thrusting while slightly moving his hips, invading deeper into her virginally tight vagina until finally *sliiiding* to the deepest point.

"Gyaaain!"  
"Oh! Ah...in...all the way in!"

Just as they achieved full penetration, girls' voices reached Yuu's ears from below.

"Did you hear something just now? Like a scream?"  
"Eh? Did I...?"

They seemed to have come up to the third floor. Perhaps lunch break was ending early for afternoon classes. *This is bad*, Yuu thought. With the rooftop inaccessible, there was nowhere to escape. And in their current joined state, there was no room for pretense.

Fortunately, Yoshie's face buried in his neck prevented her from hearing the voices as she suppressed ragged breaths. *(Please don't come up here...)*

Her virginally tight vaginal walls clenched like they were trying to expel the foreign object. Even without moving, it felt incredibly good. So Yuu stayed still, gently stroking her head while waiting for the students below to pass. Warm fluid trickled down his groin - likely her hymen blood - but he focused only on waiting.

***

"Okay. Seems they're gone. Now I'll move?"  
"Fah? Uun..."  
"Nn? Still hurts?"  
"Fe...n-no! Y-you can move now?"

When Yuu checked Yoshie's expression, her earlier pained grimace had softened...no, her eyes had turned dazed and intoxicated. Staying still had apparently helped her.

"Then"  
"Gyaahn!"  
"See?"  
"Ih! Aahn! Ukun..."

As Yuu slowly began thrusting upward, Yoshie's restrained moans escaped. "My my, already feeling it right after your first penetration?"  
"Eh...I don't know!"

She wrapped both arms around Yuu's back and buried her face shyly.

"Fufufu. That's fine. You'll understand soon enough."  
"Uu..."

Corrupting an innocent virgin like Yoshie through sex - wasn't this the ultimate pleasure of being a man? In that sense, Yuu wanted to continue having sex with her beyond just once. First, he'd make sure to make her cum properly.

*Thrust, thrust, thrust* - Yuu maintained a steady rhythm. Though not moving excessively, his cock reliably struck deep inside.

"Ah! Ah! Ahn! Yuu...kun...th-this is...sex? Ah! Nn...ha! Hahii!"  
"Yeah, that's right. My cock's knocking deep in your pussy to make a baby. Feel it?"  
"Fah...ah! Ahn! D-deep spot...being hit uuu...vun! This...this is..."

"Meaning it's starting to feel good?"  
"Uu...kuu..."  
"Say it?"

When Yuu stopped his hip movements, Yoshie rubbed her cheek against him pleadingly. "Yah...d-don't stop..."  
"You want me to move? Then say it."  
"Uu...At first...it really hurt. But when you stayed still...the pain gradually faded. Then when you started moving...something...hot rushed up from deep inside...and..."  
"And?"  
"I-it feels good! Yuu-kun's cock...feels sooooo good!"

Hearing this, Yuu resumed thrusting. "Me too...inside you feels amazing!"  
"Aahn! Yuu-kun, incredibleeeen!"

Perhaps their bodies were compatible. This unexpected discovery, combined with the usually serious Yoshie beginning to unravel, further excited Yuu. But being her first time, he avoided rough movements. Slow, digging thrusts that reached deep were enough.

"Ah...kahaa...good...Yoshie...feels so...good"  
"Hah! Hah! Hahiin...Yuu-kun, I...I'm...something amazing's coming...aahn! Sex...is incredible...I never knew it was this amazing..."  
"Haha, see? Our bodies must be compatible...nnn...I'm..."  
"Nnn! Yuu...kun!"

The facing-seated position might deepen mutual pleasure. Combined with the characteristic tightness of a virgin, her vaginal walls milked him relentlessly with each thrust and withdrawal. Meanwhile, Yoshie felt increasing pleasure as her cervix was pushed and the glans hooked repeatedly.

"Yoshie"  
"Yuu-kun!"  
"I'm...at my limit"  
"Gyaahn!"

Yuu accelerated his thrusts toward climax.

"Kuh! Haaah!"  
"Gyaaain! S-such...ahn! Ahn! No...amazing...coming!"  
"I-I'm cumming...inside...ejaculating!"  
"Gyah! Hih! Yeeen! Yuu-kun! Yuu-kuuun!"  
"Vuh!"  
"Gyaaaaahn!!"

Like a runaway locomotive, Yuu thrust wildly until ejaculation. Thick, hot semen pulsed *dokudokudoku* into Yoshie's womb. "Ooh! Gah! Kahaaaaaaaan! Nnn! Giiiih!" Receiving this, Yoshie arched her back sharply toward the ceiling. Yuu pressed his cheek against her slender neck, continuing to ejaculate as Yoshie trembled from the shock of her first internal orgasm after losing her virginity.

***

The raging flames of desire weren't extinguished by a single ejaculation. Still excited, Yoshie stood as instructed, placed both hands on the waist-high wall, and presented her small, well-shaped butt. Yuu pressed his hips against her. Noticing semen oozing back from her vagina, he pressed his still-hard cock tip against her entrance like a plug.

"I'll insert it"  
"Un. Yuu-kun, come..."

Yoshie invited him with a dreamy expression. Her usual serious class representative demeanor had vanished, replaced by the face of a female craving a male.

Perhaps due to the mixture of semen and love juice inside, his glans slid in with a slippery sensation, seeming to sink in smoothly. But soon the tight vaginal walls blocked the way. Covering her from behind, Yuu gripped her hips firmly and pushed deeper.

"Kuooh! T-tight!"  
"Gyaaaah! Yu-Yuu-kun's cock...coming in!"  
"Where's my cock going inside you?"

Intoxicated by insertion pleasure, Yuu questioned Yoshie below him. "I-inside...my p-pussy...Yuu-kun's cock...ahn! Prying me open...Yuu-kun's cock is so magnificent...inside...grinding...ah! Ahee...feels...so good..." Overwhelmed by pleasure rather than shame, Yoshie answered despite her earlier embarrassment. Hearing the serious girl say "pussy" and "cock" was arousing. "That's right. Now, I'll go deep all at once."  
"Gyah! Gyah! Yuu...kun!" Yuu thrust deep for her sake.

"Kyauun!"  
Yoshie's back arched, her half-up long hair flying. "Haa, haa, inside you feels amazing. My hips are moving on their own." "M-me too...unlike before...from the start...ahn! Feels good!" "Fufufu. Our bodies really must be compatible." "R-really...happy...nnaah! Ah! Ah! There! Feels goood!"

Worried loud impacts might echo, Yuu tormented her with slow circular motions. But Yoshie's moans grew louder, making his consideration futile. Continuously ground deep inside, Yoshie eventually bent her elbows forward. Hearing voices below, she covered her mouth and looked back at Yuu pleadingly.

Lunch break was ending, and girls were gathering for fifth period classes in the third-floor classrooms. Sensing this, Yuu paused his hip movements. He too heard the noisy group approaching. Fortunately, their loud chatter masked the couple's sounds.

Though stopping his hips, Yuu tidied Yoshie's disheveled hair and pressed fully against her back. Wrapping both arms around her front, he groped her breasts and flicked her nipples with his fingertips.

"Nn! Vuh! Nfuh...Yu-Yuu-kun...stop..." Even without hip movements, having the huge cock inside drove Yoshie's instincts wild. Having her weak point - nipples - played with made sounds escape.

Girls of unknown grade kept coming upstairs. For Yoshie - the class representative of 1-5 - guilt overwhelmed her at being engrossed in sex right before class. Unaware this very guilt spiced her pleasure. "Gah! Gah! Gaauun..." Love juice overflowed down her thighs, forming a puddle on the floor.

Yuu whispered while savoring her long black hair's scent: "Sorry we'll miss fifth period. But I can't stop now. I want more of you."

Yuu's words struck Yoshie's heart. Having consecutive sex with Yuu - practically the school's most admired boy - was too precious an opportunity to pass up. Missing one class hour seemed trivial.

"Nku...me too...want...Yuu-kun..." Covering her mouth, Yoshie began awkwardly rocking her hips. Feeling this movement, joy welled in Yuu's chest. He matched her pace with slow thrusts.

*Squelch, squelch, squelch.*  
"Vuh! Nmuh! Vuun!" Each impact of Yuu's hips against Yoshie's butt produced sounds alongside her suppressed moans. Unnoticing the fifth period bell, they kept pounding against each other. "Nnnnnnn~~~~~~! Nn! Nn! Vuh...vufuun!" Arching her back in climax, Yoshie restrained her voice while whitish foamy fluids dripped endlessly from their joining point.

As Yoshie weakened, Yuu hugged her tightly from behind. With voices gone below, he increased thrusting speed.

*Pomf! Pomf! Pomf!*  
"Ahn! Ahn! Aahn!" "Gu...fuu..." Like mating animals, they forgot about class, crying out and colliding hips like male and female seeking pleasure.

"Yo, Yoshie...I'm...cumming soon. I'll ejaculate loads inside you." "Gyah...cum...Yuu-ku...nn! Lots! Cum inside meee! Inside aah...nn! Nn! I-I'm...cumming cumming uu!" "Then cum together?"

Yuu hugged Yoshie tightly and whispered, making her body shudder. "Sorry...I came...first..." "My my, I didn't know Yoshie was such a naughty girl. I said cum together." "B-but...Yuu-kun's too amazing! Ah! Ah! No...might cum again...kyahii! Too intense! Ahn! Feels too good...can't stop!"

As if addicted to Yuu's cock, Yoshie threw back her head, tongue lolling as she moaned. Yuu mercilessly slammed his hips, pouring out his rising desire. *Gushy gushy* lewd sounds leaked with each thrust.

Yuu too reached his limit. Yoshie's vaginal tightness remained unchanged since first penetration - far from comfortable. "Gyah! Gah! Yoshie! Yoshie! Cumming! Vuh...gah! Cumming!" Shoving his cock deep as if reaching her uterus, Yuu ejaculated another thick load equal to the first. "Gah! Gah! Gahee...c-coming out...Yuu-kun's se-e-e-men...hahyu...vuun! Gyaan! Gahaan!" "Ooh! Ooh..."

While Yoshie milked his spurting cock with final clenches during her last internal orgasm, Yuu groaned uncontrollably. The intense afterglow left him motionless, holding Yoshie tightly long after finishing.

***

---

### Author's Afterword

Though titled "Changing Students," I've only written about some students - maybe false advertising? Well, I'll keep writing about how school women (students and staff) interact with and are influenced by the protagonist, so please watch over us warmly.

### Chapter Translation Notes
- Translated "素股" as "sumata (dry humping)" to preserve the Japanese term while providing English context
- Translated "処女の膣" as "virginally tight vagina" to maintain anatomical accuracy while conveying the narrative context
- Preserved Japanese honorifics (-kun) and name order (Aramaki Yoshie)
- Transliterated sound effects (e.g., "squelch" for くちゅ, "slurp" for ずぷり)
- Translated explicit sexual terminology directly (e.g., "膣" as "vagina", "チンポ" as "cock")
- Maintained internal monologue formatting with italics (e.g., *(Please don't come up here...)*)
- Kept the English subtitle "BE WITH YOU" as in original