## 108. Special Male-Female Negotiation Room ④ ~Opening Hearts~

Just when I thought she might hesitate again, to my surprise, Kiyoko obediently slipped under the covers as Yuu invited her to.

As she pressed against Yuu's right side, her cold feet touched him first.

Then her thighs and waist areas made contact.

  

"Mmh... ahh..."

  

For Kiyoko, she must have felt Yuu's body warmth.

An incredibly sensual sigh escaped her lips.

For Yuu too, with Kiyoko now under the covers, her fragrance, smooth skin, and well-shaped breasts so close at hand, his excitement heightened and his erection wouldn't subside.

Just one more push.

To redo the kiss that failed earlier, Yuu continued his act.

  

"I-I've been thinking about Kiyo-neéchan, and my heart pounds, I feel hot, and this painful, aching feeling comes over me."

  

Kiyoko was propped on her elbow at a position where her upper body barely touched Yuu's.

Looking down at Yuu, Kiyoko's cheeks were flushed, but her gaze was gentle like an older sister looking at a beloved younger brother.

  

"A-a-a... Y-Yuu, do you... like your big sister?"

"Yeah, I like you!"

"Fah! Ah... r-really? I'm happy. Big sister likes you too, Yuu."

"But it's different from how I like Mom and Dad. 

Lately I've been thinking... I want to touch you, hug you... and... kiss you. 

Um, I guess that means I want to be your lover. 

Isn't that weird? Even though we're real siblings..."

"N-n-no, not at all!?"

"So Kiyo-neéchan will be my lover?"

"Y-yes. If it's Yuu..."

"Yay! Then let's kiss!"

"Kiss!?"

  

Deliberately acting excited, Yuu stroked Kiyoko's back.

Prompted by this, Kiyoko seemed to understand this was the third request - the kissing scene.

"Mmm..."

With a serious expression, Kiyoko nodded and brought her face closer.

An innocent kiss where their lips barely touched.

That would have been enough.

""Mmmph!""

Kiyoko seemed about to pull away reflexively, but just before contact, Yuu wrapped his hand around the back of her head.

Along with the sensation of soft lips, he felt a brain-numbing pleasure.

*(Just as I thought - it's the same.)*

Kissing a blood-related sister feels incredibly good.

It felt like pleasure chemicals were flooding his brain.

"Mmm... fuu"

Kiyoko must have felt the same.

Though she'd reflexively pulled away earlier, this time she closed her eyes and accepted Yuu without resistance.

  

After over a minute, they separated their lips.

Kiyoko's eyes were drunken with pleasure, hazy and unfocused.

"Kissing... feels good."

"Y-yes... feels good."

Kiyoko barely managed to answer in a hoarse voice.

"Kiyo-neé, let's kiss more?"

"Y-yes."

  

There was no need to prompt her anymore.

Kiyoko pressed her lips against his on her own.

Of course, Yuu accepted while stroking her head with his right hand.

  

"Mmm... mmph... Yu... u... *chu*... *mchu*... haa, haa, Yuu!"

"*Mchu*, *chu*, Kiyo... neé... ahh... *chu*... mmm~~~ph!"

  

They repeated separating and joining their lips several times.

Yuu embraced Kiyoko who was leaning over him, and as they held each other sideways, their kiss transitioned to a deep, thorough one with lips pressed tightly together.

Then he pressed his still-hard cock against Kiyoko's lower abdomen.

  

"Hey hey, after hugging Kiyo-neéchan naked and kissing, my dick got like this. Touch it."

"Mmm?"

Thinking Kiyoko might resist touching it, Yuu took her right hand and guided it to his crotch.

  

"Ah, it's hot! A-and... so hard... and big."

Having never even touched a fully erect penis before, let alone seen one.

Kiyoko's eyes widened in surprise.

"It's all Kiyo-neéchan's fault... Hey, let me touch your breasts."

"Ah... okay."

Showing no resistance to this request, Kiyoko readily accepted and wrapped her palm around Yuu's cock. As if confirming its hardness and shape.

  

"Ahh, so soft..."

"Mmm... fuu... ah, ahn!"

  

When Yuu tried to cup one breast with his left hand, it was too large to fit in his palm.

Yuu gently kneaded it, moving his palm in caressing motions.

As the nipple rubbed against the center of his palm and he pinched it, Kiyoko let out a sweet moan.

While being touched by Yuu, her nipples immediately reacted, standing stiffly erect.

He sandwiched them between his fingers while continuously kneading her breasts.

  

"Haa, haa, Kiyo-neé, touch my cock more."

"Mmph, nkuu... Yu, Yuu... ahn! Wh-why is it so hot and hard?"

"Because I love Kiyo-neé."

"Yuu..."

  

Yuu used his right arm like a pillow for Kiyoko's head, then licked her nearby lips with his tongue.

"Ah... mm... mfuu"

Kiyoko began moving her right palm to rub Yuu's cock, while placing her left hand on Yuu's chest, feeling his heartbeat and body heat as she sighed.

Yuu's tongue pried open the slight gap between her parted lips.

"Mfue! Vaa... mfuuun..."

The moment their tongues touched for the first time, Kiyoko's eyes flew open wide, but as Yuu's tongue began moving freely inside her mouth, she sighed and accepted his advances.

  

Driven by lust as he greedily explored her mouth, Yuu shifted from their sideways embrace to lay Kiyoko on her back, positioning himself on top now.

He kept his weight on his knees so Kiyoko could keep touching his cock with her hand.

When Yuu opened his eyes while their tongues overlapped, he saw Kiyoko with lowered lashes, eyes half-closed in a blissful expression.

Though Kiyoko should have no experience with men, her intoxicating sensuality was overwhelming.

The flames of lust burned even hotter within Yuu.

  

"Haaah... Kiyo... neé!"

"Mmphu... Yu... ugh!"

  

With their lips barely separated, they called each other's names before pressing their slightly open mouths together, tongues passionately entwining.

Yuu cradled Kiyoko's head with his right arm while his left hand kneaded the breasts that maintained their volume even while she lay on her back.

Kiyoko rubbed his cock fervently while her other hand had somehow found its way to Yuu's back, stroking wildly in the heat of passion.

  

"Mmph... hah, fuu... mmm~~~~ *chuppah*! Ahh, Kiyo-neé, more!"

"Ahfuu... mmph, mmph, mmph... *churuchupaa*... haa, haa, Yuu! I've... never felt this hot before!"

"More, more, let's love each other more. Here."

"Aaaaah----"

  

They stuck their tongues out, poking each other's tips, made eye contact, then slowly pressed their lips together again, making *chupa chupa* sounds as they shared a deep kiss.

  

After enjoying the kiss for a while, Yuu felt hot and pushed the covers down to their waists.

As Kiyoko's slender neck to her chest became exposed, Yuu felt a surge of desire and began sucking there.

  

"Faaaaaah! Ah, ah, ahi! Yu, Yuu... i-it's, ah, ahn!"

  

Probably due to diligent care and having bathed beforehand.

Kiyoko's skin was beautifully pale with a firmness and luster belying her age.

Even with sweat beading, it emitted an elegant floral fragrance, making Yuu ravenously devour it.

  

"Ahh, Kiyo-neé's breasts look delicious too."

"Hyaan!"

  

Moving from her neck to shoulders, collarbone, and then breasts, Yuu focused on the center of the breast he'd been kneading. Perhaps from never having been used, her relatively small, vivid vermilion nipple was taken into his mouth.

He teased it with his tongue tip to confirm its stiff hardness, licked all over with his whole tongue, gently bit, and sucked voraciously.

  

"Aaaaahhhhhh! Th-there... nyah! Why... ah, ah, like that... ahn! Yuu, w-wait, take a break... aaaun!"

  

*(Kiyo-neé seems surprisingly sensitive for a virgin.)*

Despite receiving intimate touch for the first time, Kiyoko reacted sensitively as if her erogenous zones were being awakened wherever Yuu's hands or tongue touched.

Her body was truly worth pleasuring.

Overwhelmed by pleasure, she let go of Yuu's cock and busily alternated between gripping the sheets and reaching for Yuu's head or back.

  

"Kiyo-neé, let me touch your pussy too."

"Hah, hah, ahhn..."

  

Since she was a virgin, Yuu could have continued pleasuring her longer, but he was too curious about Kiyoko's state down there.

After that round of stimulation, Kiyoko was breathing heavily and didn't seem to hear Yuu's words.

With no other choice, Yuu silently slid his left hand down from her belly.

He hooked his leg between hers to spread them open, meeting no resistance.

Feeling moisture around the mound covered with pubic hair, Yuu touched the surface of her labia minora with downward-facing fingers.

  

*Squelch.*

"Whoa!"

"Ahn!"

  

*Squelch, nuch, chupon!*

With just a light touch and movement, he realized she was already flooded.

  

"Kiyo-neé?"

"Fah... ah, ahn! Ah... Yu... u?"

"You're incredibly wet."

"Eh... why...? I don't... know..."

"See?"

"Haan!"

  

He pressed his middle finger along the center of her slit and moved it.

Clear *squelch squelch* sounds could be heard.

It felt like sticking a finger into lukewarm porridge.

Kiyoko's genitals were so thoroughly wet and relaxed, it seemed as if she'd already climaxed multiple times while waiting for Yuu.

  

"Ahhh! Ah, mmph, kuun... Yu, Yuu... touching me there... feels so good... whyyy... ahn! Nyah, I've never... felt this... what's happening to me down there...?"

"Kiyo-neé's pussy wants my cock.

Yeah. The body doesn't lie. It wants little brother's cock so badly it got like this."

"Eh... ehh... Yuu?"

  

At this point, Yuu prepared for penetration without hesitation, positioning his lower body between her thighs.

Leaning over her from above, Yuu pressed his rock-hard cock against her entrance and locked eyes with Kiyoko.

"Kiyo-neéchan, I can't hold back anymore. I'm putting it in, okay?"

Here, Kiyoko spread her legs wide as if accepting Yuu, closed her eyes, and nodded.

"Come, Yuu."

Her expression showed not the guardedness of 28 years of virginity, but rather anticipation of finally having it taken.

  

Just as Yuu guided his shaft to adjust the angle, his raging cock easily connected with her vaginal opening and was swallowed inside with a *nuphri* sound.

The membrane that blocked the way must have been thin to begin with, as it tore easily with just a little hip thrust.

  

"Ugh!"

"Mmph! Ooh... it's going in..."

  

Unlike the teenage girl Yoshie whose virginity he'd taken days before, he didn't feel vaginal pressure strong enough to push him out.

But the tightness inside was the same.

Having experienced many women's first times, Yuu didn't panic when meeting resistance, instead using small, repeated thrusts to gradually penetrate deeper.

  

"Ahh, inside Kiyo-neé feels warm and good."

"Guh! Aaauu... haa, haa, mmmph!"

"Just a bit more. Kiyo-neé, are you okay?"

"O-okay... mmph, kufuu... ahh, Yuu! I-it's so big, coming inside me..."

"Ooh, ooh... i-it's in! Kaha, this is..."

"Aaaahn!"

  

With a *nyuru* sound, it slid smoothly deep inside.

Just as Yuu thought it went surprisingly smoothly for a virgin, he felt countless heated folds wrap around his entire cock.

  

"Wait, Kiyo... neé, d-don't move!"

"I'm not... moving! Ah, haaaaaaaahn! Yuu is... filling me up inside!"

  

Though penetration was achieved, Yuu couldn't move due to the slow, tightening waves of pleasure washing over him, so he just hugged Kiyoko tightly.

Kiyoko too could only cling to him with the hands she'd wrapped around his back.

While hugging Kiyoko, Yuu sucked and licked her sweaty chest, but then heard her sweet voice.

"Hey hey, how do you feel now that you've taken your little brother's cock for the first time?"

"Nyah... don't ask..."

Blushing pink, Kiyoko shook her head as if refusing.

But when Yuu stroked her cheek, Kiyoko looked at him and began speaking haltingly.

  

"Th-this... I thought... I'd never have any connection with a man... in my life...

Wh-when I knew Yuu would meet me... I didn't expect anything... but somewhere inside... I was excited..."

"Really? I was nervous too about what my half-sister would be like."

"Did you think I was a crazy woman? S-sorry."

  

Though he did think she was troublesome internally, Yuu shook his head slightly.

"Kiyo-neé is a wonderful woman. I'm really glad I met you."

"Uu... I'm happy. To have such a kind, cute little brother... and to make a baby together... aahn! M-move."

"Fufufu. Having sex with Kiyo-neé feels better than I expected, I'm so excited.

How is it? Does it hurt if I move?"

"Mmm... haa... ahn. N-no, it doesn't hurt. Rather..."

"Rather?"

  

With flushed cheeks and half-lidded eyes gazing at Yuu through long lashes, Kiyoko looked incredibly sensual.

A hot mass seemed to be growing inside Yuu.

But fearing he might cum if he thrust vigorously, he made circular grinding motions while buried deep inside.

  

"Ah, ah, ahhh! I-it feels good! Yu, Yuu... good! Yuu's cock feels so good!"

"Oooh, me too... feels good..."

  

Whether unconsciously or not, the folds moved as if trying to squeeze out his essence, making Yuu groan uncontrollably.

He might have underestimated a 28-year-old virgin pussy.

Having finally met a male after all this time, Kiyoko's vagina clenched tightly as if never letting him go.

  

"Hah, hah, K-Kiyo-neé, I don't think I'll last long. Soon..."

"I-it's okay! Yu, Yuu! It's fine... don't hold back... Cum inside me, as much as you want."

  

With their hands tightly intertwined, Yuu began thrusting his hips.

His violent piston movements were clearly for ejaculation.

With each thrust, *bachun, bachun* sounds of flesh meeting flesh mixed with *guchu, guchu* sticky wet sounds.

  

"Guh... a, aaaah! I'm cumming, cumming, Kiyo-neé!"

"Hyaan! Aah, aah, aah, it's amazing! Aaahhhhn! I-I'm, cumming, kihyau! Aaaah... Yuuuuuun!"

  

As Yuu's movements reached their final sprint and grew even fiercer, Kiyoko involuntarily threw her head back.

Yuu stretched their intertwined hands to grip the sheets, pressing their bodies tightly together as he thrust mindlessly toward the end.

  

"Vuuh... mmmph! Cumming!"

"Haaun! Cum... inside... aaaah... ah... ah... hinuuuuuu..."

  

As Kiyoko's voice sounded like she was ascending to heaven, Yuu smiled wryly inside while hugging her tightly and continuing to ejaculate.

  

  

  

  

When there's a chance to have sex with a beautiful woman, Yuu would never stop at one ejaculation.

Naturally, he'd go for at least two rounds.

However, the Special Male-Female Negotiation Room had a strict two-hour time limit, and he hadn't confirmed if extensions were possible like at karaoke.

  

After resting together post-climax—Kiyoko seemed to have briefly lost consciousness—Yuu checked the time to find about 40 minutes left.

With no time to spare, they began round two right in bed.

  

"Ah, ah, ahn! Aaahn! I-it's good! Ahn, Yuu, don't thrust like... ah, haaaaaaaahn! Nooo, I'm sensitive there..."

"Eh? Kiyo-neé, doesn't this feel good? Should I stop?"

"Ugh... hah, hah, d-don't... don't stop..."

"Want me to thrust more?"

"Yes... more... aahn! Yu, Yuu! Ahn! I-I'm cumming!"

  

Drenched in sweat, the two threw off the covers, continuing to copulate naked on the bed.

From missionary position, Yuu lifted Kiyoko up as he lay on his back.

Initially, he thought of having Kiyoko move while he was underneath, but being freshly deflowered, she couldn't manage it well.

Eventually, they connected in a facing seated position, with Yuu grabbing her fleshy buttocks with both hands and thrusting upward.

Each thrust made Kiyoko's long hair, tied in a single bundle, sway wildly, and her breasts bounced up and down before Yuu's eyes.

  

Having just taken her virginity in their first coupling, Yuu realized their bodies were highly compatible.

While Kiyoko fulfilled him emotionally the most among his partners, sex with a blood-related sister was physically addictive.

Besides Elena who lived with him, Saira, Miku, and now Kiyoko.

Perhaps because their tryst was time-limited, it felt even more exciting.

  

Indeed, deep inside Kiyoko's vagina, folds clung to Yuu's entire cock, stimulating it relentlessly.

Whether thrusting or pulling out, intense pleasure shot through Yuu's entire body, making his hips unstoppable.

  

"Haa, haa, inside Kiyo-neé feels so good... ahh..."

Yuu opened his mouth and sucked on the breasts swaying before him, *chupa chupa* sounds filling the air.

"Hyaun! My breasts, when Yuu sucks them... mmph, kuun... nooo, I can't stop feeling good! I-I've never felt this... ahh, already..."

  

Meanwhile, Kiyoko felt another climax approaching after her first.

Her vagina instantly memorized Yuu's cock shape, tightly squeezing while receiving constant stimulation.

It seemed her body had already been trained by Yuu inside and out.

Kiyoko moaned intensely while gripping Yuu's back with both hands, but as the thrusts continued, she trembled violently, then threw her head back and arched her spine.

  

"Ahhh! Hah, hi! I'm cumming! Aaaaaaaahhn! I-I'm cumming!"

  

*Thump, thump, thump.*

Seeing Kiyoko about to lose consciousness from the climax's impact, Yuu paused his movements, stroking her head and kissing her.

Once she seemed calmer, he firmly held her hips and began rhythmic thrusts.

Though still floating from continuous climaxes, Kiyoko began being tossed by waves of pleasure again.

Moaning intermittently, Kiyoko not only wrapped both arms around Yuu's back but also hooked her long legs around his waist, clinging tightly.

They became one, approaching their final moment together.

Since Kiyoko clung like a restraint, Yuu couldn't make large movements, but compensated by grinding deep inside her.

  

"Kaha! K-Kiyo-neé... I'm cumming... ngh!"

"Hahee, hahee, Yu, Yuu... ahn, this is amazing! I'm cumming too... ahn, ahn, I'm cumming!"

"Then let's cum together?"

"Yes, cum together... ahhn! Already... no, I can't hold back... I'm cumming!"

"Kiyo... neé! Cumming! Aaah!"

  

As Kiyoko looked up at the ceiling, exposing her slender neck, Yuu sucked there while releasing his second load.  
"Kyahin! Ah, ah, ah, ahhh! This... no... ooh... oh, oh... hi, hinuuuuuu..."

  

With Kiyoko sounding like she was ascending to heaven, Yuu smiled wryly inside while hugging her tightly and continuing to ejaculate.  


### Chapter Translation Notes
- Translated "ちゅー" as "kiss" in dialogue but preserved as "*chu*" in sound effects for consistency
- Used explicit anatomical terms ("cock", "pussy", "breasts") as per style guidelines
- Preserved Japanese honorifics ("Kiyo-neéchan") throughout
- Transliterated all sound effects (e.g., "*squelch*", "*chupa*", "*bachun*")
- Maintained original name order (Takahata Kiyoko) per translation rules
- Italicized internal monologues as per style guide
- Translated sexual acts without euphemisms ("penetrated", "ejaculated", "climaxed")