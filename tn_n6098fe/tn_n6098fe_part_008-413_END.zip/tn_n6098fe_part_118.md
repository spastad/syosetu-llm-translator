## 109. Special Male-Female Negotiation Room ⑤ ~GET A CHANCE!!~

The first time using the Special Male-Female Negotiation Room.  
You could call it a school-approved love hotel.  

While there's the restriction that both parties must be students or faculty, even so, from Yuu's perspective, the pool of potential partners is enormous.  
Normally, usage starts from the second year, but it's not like first-years are strictly forbidden.  
For Yuu, it felt like he'd obtained the perfect fuck room.  

Apart from Tuesdays and Fridays dedicated to student council activities, and Saturday afternoons somehow always occupied with student council work - not to mention enjoying foursomes in the waiting room - his Mondays, Wednesdays, and Thursdays were free.  
Starting the week after having sex with his half-sister Kiyoko, Yuu began making his moves.  

***

June 25, Monday.  

"H-honestly... with me... is it really okay?"  
"Of course. We promised, didn't we?  
After meeting and talking with Saki that day, I really wanted to have sex with you."  
"Aah... I'm happy. So happy, Yuu... mmph!?"  

Saki, formally known as Gonda Sakiko, worked in Sairei Academy's administrative office. A 21-year-old single woman.  
She'd asked to be called Saki rather than her given name Sakiko, so Yuu complied.  
Hearing "Saki" and knowing she was a former delinquent made Yuu recall the Sukeban Deka TV drama in his mind.  

Her straight, probably dyed chestnut-brown hair fell long, and at nearly 180cm tall, her slender figure boasted legs so beautiful they were mesmerizing.  
Even after entering the room, Saki appeared unexpectedly shy. To help her relax, Yuu made small talk, learning she'd indeed been wild from middle through high school.  
But midway through high school, she reformed, became studious, attended junior college, obtained bookkeeping qualifications, and got this job.  

After showering, they sat wrapped in towels on the edge of the bed, embracing.  
Yuu grew excited seeing Saki's alluring neck and shoulders exposed as she tied up her long hair, and he claimed her lips.  

"Hehe... Actually, you're my first kiss, Yuu.  
And now today... this is happening... it's like a dream..."  
"Eh? Really? So you're a virgin?"  
"Umm... no, actually in junior college I worked at a fuzoku place..."  
"Oh ho?"  

Though not the most refined topic, Yuu grew curious about this world's sex industry - where women pay men, of course - and kept kissing and touching Saki while questioning her.  

Men working in this world's sex industry are mostly those diagnosed with azoospermia in health checks who can't father children, thus working semi-obligatorily, or those drowning in debt from reckless spending.  
With already scarce men, those entering sex work are extremely few.  
Thus, each prefecture has only 1-2 shops, all publicly operated.  
Furthermore, they're reservation-only with 2-week to 2-month waits.  
Even if the man fails to get erect during the session, no complaints are accepted.  
Kissing is basically prohibited.  
Men rarely perform foreplay; women entering the shop must struggle to get their partner erect within the 60-minute time limit.  
Most men lie on their backs like dead fish.  
If successfully erect, the woman mounts to penetrate.  
However, creampies are forbidden - women must pull out just before ejaculation. Forcing continuation gets them forcibly removed or staff summoned via panic button.  

During junior college, Saki managed to reserve a standard fuzoku shop (60 minutes for ¥80,000 - expensive even by Yuu's standards) before graduation. There, she lost her virginity to a bald, overweight 50-year-old sex worker.  

Separately, there are high-end shops where regular visits can establish pseudo-romantic relationships allowing "lover-like sex." Rumors say kissing and creampies are permitted there.  
But no matter how much women spend, men hold selection rights - even after spending hundreds of thousands, rejection mid-session happens.  
Attractive male prostitutes are especially popular, making actual penetration difficult, reminiscent of Edo-period oiran courtesans.  

While standard shops rarely have men under 30 (mostly 40-50s, even 60s), high-end shops feature relatively young, handsome 20-30 year olds.  
Thus, socially successful women in this world become obsessed with high-end fuzoku shops.  

"Eh? So... they didn't do things like this for you?"  
Sliding his hand through the towel gap, Yuu gently kneaded her modest, palm-sized breast while licking her neck.  
"Y-yes... ah! Oh! Men have... never... ahhn! Touched me like this before..."  
"What a waste!"  
"Huh?"  

Sucking on her neck, Yuu removed the towel and embraced Saki's larger frame.  
"Hearing that someone as beautiful and well-built as you lost your virginity through such half-assed sex makes me furious."  
"Eh... Yuu?"  
Saki looked dazed but blushed crimson noticing Yuu's serious gaze.  
He brought his lips close and whispered:  
"I... want to teach you real sex."  
"Mmph!?"  

Yuu pressed his lips firmly against hers, invading her mouth with his tongue before she could respond. But timidly, she wrapped her arms around his back.  

***

Yuu spent over 40 minutes meticulously caressing Saki's body, eventually making her experience her first-ever orgasm and squirting through cunnilingus.  
As Saki lay on her back breathing heavily, Yuu settled between her legs, displaying his rock-hard cock.  

"Saki, how does this compare to your first guy?"  
Saki stared wide-eyed at the virile cock standing tall enough to hit Yuu's lower abdomen.  
"Eh? Eh? Eeeeeeh!? Wh-what is that!?"  
"What? It's a dick."  
"I-it's totally different! Thickness, length... No way... will it fit?"  
"It'll fit. I'm dying to be inside you... And... I can cum inside, right?"  
"Ah... yes."  

Though shocked by the massive cock, Saki nodded repeatedly without hesitation.  
She recalled needing to be on top like her first time, but Yuu immediately covered her, positioning his cockhead at her entrance.  
"Ahh..."  
Feeling Yuu's warmth and breath as he fully covered her, joy welled in Saki's heart.  

Male students were normally distant figures for office staff - they rarely visited the office voluntarily.  
Much less Yuu, the object of every woman's admiration on campus.  
After multiple brain-melting kisses and full-body caresses, Saki felt so melted with pleasure she'd accept anything Yuu said.  
"Ahhaa... Yu-Yuu!"  
Her mind blank from deeper pleasure than masturbation, Saki instinctively hugged his back and cried his name when the hot rod touched her soaked entrance.  

"Saki, here I go."  
"Mmph... Yuu, come."  

Though it had been two years since her last penetration, if her deflowering felt like a packaged sausage, this was a frankfurter.  
"Gweh!? Gah! Gah! AAAAAAAHHHHHHHH!!!"  
As the cock split her tight vaginal walls, incomparable impact struck Saki's lower abdomen.  
Though somewhat painful, she panicked at the overwhelming new sensations, tightening her grip on Yuu's back.  
When deeply impaled, Saki's vision blurred as hot magma surged from her core - the true sexual pleasure shaking her feminine instincts.  

"Ahh... Saki's inside feels so warm and amazing!"  
Moaning this, Yuu began thrusting as intermittent high-pitched, sweet cries echoed - Saki was too ravished to recognize her own voice.  

***

June 27, Wednesday.  

In Negotiation Room 1, a woman with an impressive physique rode Yuu on his back, moaning loudly while frantically grinding.  
Similar height to Yuu but with broad shoulders and a sturdy back. Her muscles danced with each movement, clearly indicating athletic experience.  
Her waist was tightly toned with abs, while large bell-shaped breasts swung violently. Her ample buttocks made satisfying *squelch* sounds with each impact.  

"Ah! Aah! So good! Hirose-kun's dick is sooo good! D-deep! Hitting deep inside! Oh! Oh! Oh! Ohho! Hirose-kun... I love your dick! I'm addicted! M-my hips... can't stop!"  

Her bun-tied black hair had loosened, strands sticking to sweat-dampened skin.  
Usually narrow, sleepy eyes were wide open; plump, fleshy lips hung slack with drool as she moaned in a clear voice.  

*(Hmm... Did I underestimate the sexual appetite of a single 30-something woman with no male connections?)*  

The woman riding Yuu was math teacher Dei Kazuko. 33 years old (single with child).  
Yuu originally planned to invite a Class 1-5 girl.  
But that morning during a break in the rainy season, after teaching the boys' class, a relaxed Kazuko exited Building 2 removing her blouse to reveal a purple camisole.  
Yuu happened to see this.  
When he called out, Kazuko panicked, her cleavage-exposed breasts jiggling.  
Seeing this, Yuu couldn't help but invite her - he was powerless against breasts.  

Thinking his after-school invitation to the Negotiation Room was a joke, Kazuko remained skeptical until Yuu pulled her under a tree, embraced her, and convinced her with a deep kiss.  
He also got to grope her breasts and ass - her voluptuous body held irresistible appeal despite her plain face.  

Even after showering in the room, she seemed uneasy, but kissing helped her relax.  
When Yuu freely groped Kazuko's bare breasts and let her grasp his erect cock, she made a strange "Fuhih!" sound before forcefully pinning him down.  

"Dick, dick... Hirose-kun's... the dick from my dreams!"  
With lust-glazed eyes, Kazuko mounted Yuu and forcibly penetrated him.  

For teachers assigned to boys' classes, married middle-aged women are prioritized after men. When insufficient, single mothers fill the gap.  
Kazuko fell into this third category - young at 33.  
Clearly the type with no male connections in this world.  
Though trying to hide it, her gaze at male students was lecherous.  
Essentially, a 33-year-old virgin teacher seduced by the school's most beautiful girl went crazy seeing a wet pussy.  

"Oh! Oh! Oh! Cumming, cumming! Dick feels too good! Ahh! Yes! Yesss!"  

Watching Kazuko approach orgasm while leaving him behind, Yuu felt somewhat detached.  
Physically, it felt good - her vaginal tightness was remarkable despite artificial insemination childbirth.  
For 33, her muscular contractions were superb - a man's body instinctively enjoys pleasure.  
But emotionally, he felt unfulfilled.  

"Gwaoh! Ohh! Ohh! Cumming! Cumming from a male student's dick!"  
Howling like an animal, Kazuko came while staring blankly upward.  
Seeing tears in her eyes afterward, Yuu pitied her obvious sexual frustration.  
But he wasn't done.  

As Kazuko calmed, Yuu reached out and roughly squeezed her prominent breasts - so voluminous flesh spilled between his fingers.  
Though Kazuko frowned, her post-orgasm daze remained.  

"Ah, uhn..."  
"Dei-sensei, did it feel good? Using a student's dick without permission?"  
"Ah...!"  
Only now realizing she'd been selfishly chasing pleasure, Kazuko looked away guiltily.  

"Were you that pent up?"  
"Ah! No... this is... ugh... s-sorryyy!"  
"Apologizing in this state is..."  
"Ah! Me, me... wh-what should I...?"  
"Whoa."  

As Kazuko shook her head unconsciously, her spread legs closed slightly, tightening around Yuu's cock.  
When she tried to pull away, Yuu grabbed her waist firmly.  

"Don't misunderstand. I'm not saying I didn't want sex with you.  
Actually I did, just not like this."  
"Hirose-kun...?"  

Still connected, Yuu strained to sit up. Thanks to workout results, he managed to shift into a face-to-face position - cowgirl style.  
Pressed chest-to-chest, Kazuko's ample breasts deformed against him.  
Tears streamed down her self-loathing face.  
Brushing aside her disheveled hair, Yuu looked up at her downcast face.  

"Sex should feel good for both people, right?  
Only one feeling good while the other feels bad is practically rape."  
"Ah! What have I done...?"  
Kazuko sadly averted her eyes.  
"It's fine, don't worry. Instead, let's have proper sex now. I'll teach you, sensei."  
"Huh? Hirose-k... mmph!?"  

Yuu smacked his lips against hers.  
Unlike their earlier kiss, this deep kiss involved forceful tongue intrusion.  

"Amph? Mmph! Mmph! Mmph! Churu... lero, lero... juruu... afun! Mmmph! Mmmmuuuu~~ puhah! Hah! Hah! Hah!..."  

Seeing Kazuko's dazed expression after ravaging her mouth, Yuu smirked.  
"Now, I'll move."  
"Hyah!"  

*Thrust!*  
"Ah!"  
"Like that"  
"Ahhn!"  
"Now move with me, sensei."  
"M-me...?"  
"Yes, match my timing to hit deep inside. Ready? One, two... three!"  
"Fah!"  

Initially uncoordinated, their hips soon synchronized.  
"Ahh... sensei... feels good. When we connect deep, try tightening your stomach."  
"Ah! Ah! Ahh... l-like this?"  
Instantly, Yuu felt his entire cock squeezed.  

"Ahh! Kaha... good! Sensei, feels amazing! More!"  
"Ahh... Hirose-kuuun..."  

Seeing Yuu's pained expression, Kazuko's chest ached while heat surged deeper in her abdomen than ever.  
This was real sex.  
Among first-year boys, Hirose Yuu - with his handsome face and build - was her top masturbation material.  
Now embracing him tightly, experiencing her first real sex.  
Not only did she feel good, he did too.  
Overflowing affection for Yuu overwhelmed her.  
Deeply connected as one, they sweated profusely while thrusting like beasts without releasing their grip.  

"Ahh, ahh, sensei, feels good. Do you feel good too?"  
"Yes, yes! Feels good! Better than before! Ahh! I'm cumming again! Sorry, I'm cumming!"  
"It's fine. Cum as much as... kuu! I-I feel good too!"  
Tossed by wave after wave of intense pleasure, Kazuko mindlessly worked her hips, tightening internally.  
"Ah... hii... c-cumming cumming cumming! Gah! Oh! Ohho... feels too gooood!"  

Compared to her first climax - a brief high like rough vibrator masturbation - this mutual effort brought a long, deep orgasm like sinking to the ocean floor after violent waves.  
Kazuko clung drunkenly to Yuu.  
But Yuu neared his limit too.  

"Guuuu... if you squeeze like that... hah, hah... I'll cum. I'll cum inside you, sensei!"  
"Huh? Hirose... kun?"  
Kazuko felt Yuu's thrusts intensify, his cock seeming to swell deeper inside.  

"If I cum inside, you might get pregnant... is that okay?"  
At point-blank range, refusal was never an option.  
"C-cum inside... I want your seed... mmph!"  
After a smacking kiss, Yuu smiled.  
"If you conceive, sensei, you'll bear my child, right?"  
Overflowing joy eclipsed her artificial insemination experience.  
"Y-yes! I'll bear it!"  
Stimulated by maternal instinct, Kazuko screamed while hugging Yuu tightly.  

It didn't take long.  
With Kazuko's limbs wrapped around him, Yuu came through grinding motions while buried deep.  
Compared to the minimal semen from artificial insemination, Kazuko took a massive load inside her womb, cumming repeatedly with a lewd expression.  

***

Unable to rise, Kazuko lay spread-eagled as semen overflowed from her entrance.  
"Whoops."  
Yuu grabbed tissues to wipe it up.  

"Haa, haa... Hirose-kun, s-sorry for staying like this.  
T-today was the most wonderful experience, making me grateful to be born. Truly thank you.  
Sensei will never forget today. I'll treasure my memories with you..."  
"Sensei, what are you saying?"  
"Huh?"  
"We only did it once. After resting, we're going for round two."  
"Hweh!?"  

Stunned, Kazuko lifted her head to look.  
When Yuu displayed his still-erect cock, her jaw dropped.  
Just two days prior, he'd cum three times with Saki through blowjobs and sex.  
He intended the same with Kazuko today.  

"Could it be... sensei only wants one round?"  
Yuu's slightly lonely expression had instant effect.  
Rising with surprising agility from her supine position, Kazuko knelt formally and bowed deeply.  
"P-please! I-I want more! Please!"  
"No need to be so formal."  
Smiling, Yuu drew close, pressing against her.  
He idly kneaded her breasts, already imagining titty-fucking them.  

---

### Author's Afterword

I'd been wanting to write about the sex industry in the Chastity Reversal World somewhere.  
In reality, super high-end soaplands apparently charge around ¥80,000 for 120-180 minutes.  
Let's ignore how a 1:30 gender ratio might make this industry unsustainable...  

Also, Dei-sensei was supposed to be a mob teacher without sexual involvement, but our overjoyed protagonist with his new fuck room ended up corrupting her.

### Chapter Translation Notes
- Translated "風俗" as "sex industry" to convey the prostitution context
- Preserved Japanese honorifics (-sensei, -kun) per style rules
- Translated explicit anatomical/sexual terms directly (e.g., "チンポ"→"dick", "膣内"→"inside")
- Maintained original name order (Gonda Sakiko, Dei Kazuko)
- Italicized internal monologues per style rules
- Transliterated sound effects (e.g., "Gweh!?" for "う゛ぇっ！？")
- Used explicit terminology for sexual acts as required