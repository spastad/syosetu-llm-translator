## 111. Special Male-Female Negotiation Room ⑦ ~OH MY LOVE~

Sitting up, Yuu stroked both their heads as he asked:  
"Have either of you masturbated before?"  

"Ma-masturbated!?"  

"That's right. Be honest with me now. I'll decide who goes first based on your answers."  

Hearing Yuu's words, the girls exchanged glances and appeared to think it over.  
After some hesitation, Mashiro was the first to speak.  

"I-I have... quite a bit, maybe."  
"Oho? How often?"  
"Yuu-kun, why do you want to know that?"  
"Mm. I'm interested in how girls relieve their sexual urges."  
"Ahaha. Y-you're weird. Umm... every 3... no, about every 2 days?"  

Normally, boys wouldn't care about girls' sexual habits. This was especially unusual for a conversation between virgins about to have sex. In truth, since being in Yuu's orientation group, Mashiro had masturbated daily but underreported for fear of shocking him.  

"Heeh, quite frequently then. What do you use for material?"  
"B-books and videos..."  
Pressed further about masturbation methods, Mashiro hesitated. She eventually confessed to using pink vibrators and other toys, though she couldn't admit her primary fantasy material was Yuu himself.  

Meanwhile, Yuma shyly admitted she'd never masturbated until recently - specifically after receiving Yuu's "reward" following the sports festival. Naturally, she'd replayed and reimagined Yuu's caresses in her mind for pleasure.  

"Now then, I need to ask something important."  
After extracting their masturbation histories, Yuu studied their faces and bodies.  
"Eh... okay."  
"Your hymens?"  
"Hy... hymen...?"  
"Right. I heard you use vibrators?"  

Mashiro gasped "Ah!" and covered her mouth. Placing a hand on her lower abdomen, she admitted sheepishly:  
"Mine's already broken. It hurt quite a bit."  
Perhaps the atmosphere made her candid as she openly confessed to breaking her hymen via masturbation. Yuu felt relieved since intact hymens typically increased initial pain. Yuma, however, focused on clitoral stimulation and apparently still had hers intact.  

"Then it's decided. Mashiro first."  
"Huh!?"  
"Yuma, I need you to wait a bit. But I have something I'd like you to do instead."  
"Hm?"  

Mashiro and Yuma could only stare blankly at Yuu's refreshing smile.  

***  

"It's fine. Come here."  
"Un... um, am I too heavy?"  
"Not at all."  

Mashiro straddled Yuu's waist as he lay on his back. Though nervous about her dreamt-of union with Yuu, her eyes remained glued to his erect penis.  
"Nn... this area?"  
After his penis disappeared beneath her ample buttocks, she fumbled to align their hips for penetration.  
"That's it. Just like that."  
"Ah... Yu-Yuu-kun's peeenis..."  
Feeling the tip touch her moist vagina, Mashiro's expression turned ecstatic.  

Meanwhile, Yuma sat in an M-leg position near Yuu's head, exposing her hairless pussy. She spread herself open with her fingers.  
"Yuma, I'll watch you. Start?"  
"Nn... with Yuu-kun... watching me this closely... nnnn!"  
Yuu had requested she masturbate. Given her petite vagina, he wanted her pre-lubricated to ease her deflowering later.  

In his original world, no inexperienced girl would comply. But this world was different. Whether due to infatuation or the atmosphere, Yuma began playing with herself right by Yuu's pillow. She traced her childlike labia, wetting her fingers with vaginal fluid before peeling back her hood to gently rub her tiny clit.  

"Haaah... fuh, nn, nn, nnnn!  
Why... does it feel... better than usual...?"  
"Seeing you get off while masturbating is incredibly sexy and cute. Don't hold back, okay?"  
"Ah, ah... nkuu!"  

Yuu's voyeuristic enjoyment created a synergistic effect. Soon, lewd squelching sounds reached his ears.  

"Gyaaah! I-it's... in... ah! Gyaaah! Nnnnnnnnnnnn!"  
Beside the masturbating Yuma, Mashiro finally achieved penetration. Though her hymen was broken, Yuu's penis exceeded her expectations. Seeing Mashiro's pained expression, Yuu stroked her soft body encouragingly.  

"Kuh... almost there, Mashiro."  
"S-sorry. It won't... go in deeper... uu..."  
Virgin vaginas remained tight regardless. Mashiro's hesitant thrusting prevented full penetration, so Yuu gripped her fleshy hips firmly.  

"Mashiro, on three!"  
"Un, s-sorry Yuu-kun..."  
"It's fine. First times are tough for everyone.  
We need to cooperate now."  
"Ahh... Yuu-kun!"  
"Three!"  
"GYAH! AAAAAAAAAAAAAAAAAAAH!!!"  

Their coordinated effort finally achieved penetration as Yuu's penis struck her vaginal depths. Mashiro's pained expression gradually softened until her eyes drooped and mouth relaxed. Her upper body slumped onto Yuu.  

"Ehehe, ahaha... I-I lost my virginity to Yuu-kun! I did it! Haaaaah... your big, haaard penis is inside me... Ah, amazing... this is sex... sex with Yuu-kun! Yuu-kuuun... I love you!"  
"Gu, guhaa... ah!"  

Joy over connection clearly outweighed the pain. Mashiro's heart-shaped eyes bore into Yuu as she pressed her lips against his, her voluminous breasts mushing against his chest.  
*(W-wow...)*  
While accepting her probing tongue, Yuu marveled at the breast pressure.  

"Auuuu... nn... haan! I-I want it too... soon... nnn!"  
Witnessing the penetration seemed to spur Yuma's masturbation.  

Seeing Yuu's blissful expression apparently flipped Mashiro's switch. She hungrily devoured his mouth until Yuu smiled wryly: "If you're okay, move." She nodded dazedly.  

Pachun! Pachun! Pachun!  
Her small thrusts made her ample breasts sway wildly. Gripping Yuu's sides for leverage accentuated their jiggling.  

"Ah, ah, an! I-Is this okay... Yuu-kuuun!"  
"Th-that's good. Ah, Mashiro's insides feel so warm and gooey... and tight... feels great!"  
"Ahhaa... me too... even though it's my first time, it feels amazing... Ah, ah! Every time you hit deep inside... lights flash in my head... Aahn! I never knew it felt this good! Yes! Yes! Yuu-kun! Feels goood!"  

Lubricating fluids smoothed their movements. Though Mashiro's breasts blocked his view, sticky squelching sounds came from their joined area.  

Yuu matched her rhythm while supporting her hip. When he scraped her depths, Mashiro threw her head back with a moan before resuming thrusting with lustful eyes. Her abandon seemed unbelievable for a virgin.  

Her body heat enveloped his penis while vaginal folds milked him. The virgin tightness left Yuu nearing his limit as they drove each other higher.  

"Kuu... fuh, fuh, nnaaaaah... an!"  
Though quiet, Yuma was clearly aroused. Her wet sounds and pink cheeks showed her excitement as she arched her back.  

"Yuma, come here."  
"Nn... nn... Yuu-kun?"  
"Straddle my face. I'll lick you to finish."  
"Ah!"  

Recalling their gym storage encounter, Yuma's expression turned sultry. She eagerly positioned herself over Yuu's face.  

"Yuu-kuuun, pleeease?"  
"Hehe, okay. I'll make you cum."  

Yuu gripped her thighs and licked her dripping pussy earnestly.  
*Juru-juru lewd slurping sounds!*  
"Fwaah! Ah, AAAAAAAAAAAH!"  
Tonguing her vagina and clit made Yuma arch violently. Mashiro caught her from behind, sweat glistening on her forehead as she thrust wildly.  

"An! An! Yuu-kun! Yuu-kun's penis... so amazing... an! Masturbation can't compare... Aahn! I'm... cumming... AAAAAAAAAAAH!"  
"Gwoh!"  

Yuu barely held on, ejaculating as Mashiro climaxed. Virgin creampie ecstasy flooded her as hot semen pulsed inside.  
"A, ahee... it's coming inside... I-I'll be ruined if I remember this feeling..."  
Holding the dazed Yuma, Mashiro trembled through continued ejaculations.  

***  

After cleaning up and laying Mashiro aside, Yuu embraced Yuma missionary-style. They kissed passionately without penetration, enjoying slippery genital grinding instead.  
*Chu, chu, lewd kissing sounds*  
"Affuu... Yuu-kuuun, I love you... love you! N-chuu lewd slurp"  

The once emotionally reserved Yuma now clung desperately to Yuu, grinding against his hard penis. When their lips parted, a saliva strand fell into her open mouth. She swallowed it happily before nuzzling Yuu.  

"I want... Yuu-kun. I can't stand wanting you."  
"Okay. Let's do it."  
"Un."  

Yuu lifted her petite hips slightly. His glans touched her vaginal entrance immediately.  
"O...ohh?"  
The thick glans met fleshy petals before sinking into moist softness - but stopped there.  

"Seems it won't go smoothly. I'll have to force it in - it'll hurt. Can you bear it?"  
"Nn... do it... hard. I want to connect... now."  
"Understood."  

Yuu's heart warmed at her cuteness. He decided rapid insertion would minimize pain. Given her loli physique, he proceeded cautiously.  

Holding her back and hip, he pushed slightly. Her hymen resisted until it tore.  
*Meri*  

"GYUHH! Nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn!!!"  
"Kuu... so tight..."  

Only partially inserted, the tightness was intense. Yuma buried her face in Yuu's chest, suppressing cries. The hymen tear clearly caused sharp pain.  

"Sorry for rushing, Yuma."  
"It's... fine. I'm okay. Yuu... kun, give me... all."  

Women here endured intercourse pain remarkably well - the pleasure evidently outweighed it. To avoid prolonging her discomfort, Yuu pushed deeper while kissing her to muffle moans.  

Yuma's crevice and vagina felt impossibly narrow for Yuu's penis. He moved his hips minutely to acclimate her flesh. Vaginas miraculously accommodate with time.  
"Nn... nku... hii... hiiin... naa... gyaa... uu..."  
Her intermittent moans sounded pained, but Yuu continued. He finally struck her vaginal depths.  

"All the way in, Yuma. Good girl, you endured well."  
"Ah... un. Th-thank you. Yuu-kun... becoming my first... having this experience... I'm happy."  
"I'm honored to take a cute girl like you for her first time."  
"Yuu-kuuun..."  

Tearful Yuma smiled and nuzzled his chest.  

"Um... does it feel good? My pussy?"  
"Of course it feels good."  
"R-really!?"  
"Yeah, really. Mashiro's gooey pussy and Yuma's tight pussy - both are equally wonderful."  

Yuu smiled at both girls. Honestly, he'd nearly cum upon penetration, but his earlier ejaculation helped. Though experienced, virgins remained exceptional - the hymen break and depth penetration caused full-body bliss. Yuma's vagina felt like a vise gripping his penis.  

"Hyahh! That deep thrust... hit deep inside!"  
"Probably hitting your cervix - where babies come from.  
Haa~ dangerous. Yuma feels too good - I might cum first..."  
"I-it's okay... you made me cum earlier... Nnku! Yuu... kun, cum... inside me... please... move... however... ahn!"  

Clutching Yuu, Yuma panted through his thrusts. Her loli physique heightened his excitement.  

Alternating shallow and deep thrusts made Yuma toss her head wildly, hair coming undone. Yuu whispered into her hair.  

"Haa, haa... cumming... I'll ejaculate inside you, Yuma! Ah, ah, guu!"  
"My... belly... full... ahn! Filled with... Yuu-kun's cum... ah! Yuu-kun! Cum... cum inside me... haan! Nn!"  
"Uuuuh!"  

Yuma's red-tipped tongue met his lips as Yuu suddenly climaxed. He thrust deepest and unleashed semen into her womb.  
*Thick pumping sounds!*  
"Muuhh, nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn!!! Fwa... gyaah... gya... faaaaaaaaaa... ukyuu"  

The virgin creampie shock overwhelmed Yuma. After a long moan, she went limp against Yuu.  

***  

Hearing panting nearby while cleaning up, Yuu saw Mashiro masturbating. Her forward-leaning position emphasized her voluptuous breasts erotically. Noticing Yuu, she blushed furiously - but he liked proactive girls. After laying Yuma down, he addressed Mashiro.  

"Now, sorry to keep you waiting. Your turn again?"  
"Eh... ehh!?"  

Mashiro gaped incredulously. Normally sex ended after one round - but two consecutive creampies already defied norms.  

Wiping Yuma's abdomen, Yuu added:  
"But we're sweaty. Let's hydrate during a short break..."  
Mashiro's gaze traveled down Yuu's body. His glistening penis remained erect.  
*(I can connect deeply with Yuu-kun again and feel that ecstasy!)*  
The thought alone made her pussy gush.  

When Yuu approached and patted her head, Mashiro looked up with sparkling eyes.  
*What an incredible person.*  
Overcome, she hugged him.  
"I love you, Yuu-kun!"  
"Haha, thanks. I like you and Yuma too."  

Though Yuu meant "like" as advanced classmates, both girls beamed - Yuma immediately hugging him from behind.  

***  

---

### Author's Afterword

After this, Yuu continues using the Special Male-Female Negotiation Room for consecutive threesomes with Class 1-5 girls:  

- Second session with Hiyama Yoko and Aki Kazumi  
- Tall duo Nakai Mao and Yokota Satilat (Sati)  
- Muscular pair Ueno Shoko and Shimozono Kayo  

However, since the story wouldn't progress with endless sex scenes, I'll skip them.  

Thanks to the Negotiation Room access, Yuu has now slept with over 20 women.

### Chapter Translation Notes
- Translated "オナニー" as "masturbation" per explicit terminology requirement
- Preserved Japanese honorifics (-kun) and name order (Goto Mashiro)
- Transliterated sound effects (e.g., "pachun" for ぱちゅん)
- Translated anatomical terms directly ("clitoris," "hymen," "cervix")
- Rendered sexual acts without euphemisms ("ejaculated inside," "performed cunnilingus")
- Formatted simultaneous dialogue with double quotes when indicated by context
- Italicized internal monologues per style guide