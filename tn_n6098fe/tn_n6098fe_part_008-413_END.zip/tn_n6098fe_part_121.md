## 112. Father's Trajectory ~BEYOND THE TIME~

### Author's Preface

This chapter serves as an explanation for concepts like the Male Inclusion Movement that have been sporadically mentioned until now.

The content is rather formal overall, but please bear with me.

The subtitle was influenced by a certain ORIGIN anime I watched on late-night public broadcasting until mid-last month.

Because of it, I spent some time voraciously reading Wikipedia articles ranging from characters to MS (Mobile Suit) entries.

---

"This morning, the Metropolitan Police Department conducted simultaneous raids on the headquarters and regional branches of a religious group calling itself the 'Holy Maiden Salvation Cult'.  
Eight males held captive at the Tokyo headquarters and various branches were rescued.  
Maria Toho - the cult leader who called herself 'Great Holy Maiden', real name Higashi Mako (42) - and four executives were taken into custody on suspicion of kidnapping, confinement, sexual assault, and fraud.  
The 'Holy Maiden Salvation Cult' had long targeted married women, preaching that all men and women would be saved under the Great Holy Maiden's guidance, but their methods were considered problematic.  
After having female followers bring their husbands, the cult leader and several executives allegedly committed sexual assaults against the men under the pretext of performing unique rituals..."

"A woman residing in Chiba City is being questioned on suspicion of illegally collecting child allowance payments for two years without reporting her son's death.  
Despite the boy having completed elementary school enrollment procedures, when school officials and city hall workers visited to check on his continued absence, she turned them away claiming he was 'unwell and bedridden' and 'didn't want to see anyone'. However, police acting on child protection concerns searched the home and discovered the skeletal remains of a child in the backyard..."

"Regarding the growing problem of women aging without ever having contact with men, opposition parties had been preparing to jointly submit the long-contemplated Equal Opportunity for Gender Interaction Law during the next extraordinary Diet session. However, some parties are now advocating for further elevation of women's status and reduction of male rights in response to the surging Male Inclusion Movement..."

"The Chinese Communist Party government (Chongqing CCP Government), facing worsening treatment of men, continues to see a stream of male defectors. They've intensified accusations against the Republic of China (Nanjing Nationalist Government) and Japan, claiming both countries use underhanded methods to lure away men.  
However, both the Republic of China and Japan dismiss these as baseless accusations that ignore China's own policy failures..."

"Next, entertainment news.  
J·BOYS, Japan's popular boy idol group, concluded their Taiwan concert tour from last week to this week with great success, drawing a total audience of 300,000 over five performances.  
Yesterday, tens of thousands of female fans gathered at Taipei's airport hoping to see them off.  
Fans flooded the airport corridors trying to catch a glimpse of the members, nearly causing a panic. However, the commotion subsided after an announcement clarified that members had already returned to Japan using a different airport."

After finishing dinner at home, Yuu was watching the public broadcasting news.

Except during job-hunting season and his first few working years, he'd never had a habit of daily TV viewing.  
But now he made sure to watch the news every morning and evening.  
News involving men was remarkably frequent - a sign of society's intense interest in the topic, he supposed.

Today's newspapers and weekly magazines bought by Kanako and others lay spread across the table.  
Bookshelves in his room were gradually filling with literature on gender issues.  
In this era without widespread internet, researching meant consulting physical materials like newspapers and books.  
In that sense, libraries were the natural resource.  
He recalled being kindly assisted by a bespectacled, voluptuous librarian and felt tempted to visit, but the potential commotion made it seem troublesome.

The reason for Yuu's intense interest stemmed from hearing the term "Male Inclusion Movement" and witnessing related demonstrations.  
What exactly was this Male Inclusion Movement?

Fundamentally, men's circumstances differed drastically between past and present.  
After intermittent Red Death Disease epidemics caused a sharp decline in the male population, women - now society's dominant force - relegated men to managed roles as semen suppliers.  
He'd heard there were eras when men lived lives that trampled human dignity, though with variations by country, region, and social status.

By the 20th century, human rights ideologies spurred movements to protect men, gradually changing treatment - especially in Europe.  
Men transitioned from being semen-managed resources for population maintenance (ignoring personal will) to being respectfully treated individuals whose consent mattered.  
While eradicating serious crimes like sexual assaults against men and human trafficking proved difficult, protective systems improved and society progressed toward male-friendly environments.

Japan's turning point was likely the 1980 enactment of the 'Male Protection New Law'.  
Though reforms had already begun earlier - like preferential treatment for foreign men, increasing co-ed schools, and creating more interaction opportunities for adolescent boys and girls.

As national treatment of men improved, the majority of women bore the brunt of negative consequences.  
In an era with a roughly 1:30 gender ratio,  
if each man simply chose three marriage partners, the remaining twenty-seven women would inevitably face lifelong singlehood.  
Those who experienced even one romantic/sexual encounter with a man while young were considered fortunate.  
Most women bore children through artificial insemination using frozen semen.  
Though not scientifically proven, most boys were born through natural conception while artificial methods produced predominantly girls - creating the term "negative spiral of female-only lineages."

Women who reached adulthood without meaningful contact with men - let alone understanding how to interact with them - found romance and marriage impossible dreams.  
Such women couldn't help but resent society.  
"It's society's and the government's fault we have no connection to men!"  
"Give us equal opportunities to interact with men!"  
These became their rallying cries.

Meanwhile, in parts of Africa and inland Eurasia where Red Death Disease spread later, male protection ideologies hadn't taken root.  
Nations existed - to varying degrees - that maintained archaic, strict male management systems.  
Though many men planned defections knowing advanced nations like Japan treated men better, most lived under strict dictatorships or faced capture en route, ending in similar circumstances.  
While advanced nations accepting the few successful defectors voiced condemnation, they stopped short of military intervention, leaving the situation unchanged.

Regardless, women dissatisfied with their circumstances in advanced nations began considering adapting these surviving male management systems for their own countries.  
They argued current society was flawed - with most women bearing society's burdens while men lived comfortably as "social burdens" supported by wives.  
Men "wasting tax money" should shoulder appropriate responsibilities.  
Society should return to past practices where men served women according to gender ratios.  
Thus emerged the movement for women to share men for women's benefit - abbreviated as the Male Inclusion Movement.

The ideology actually reached Japan before 1970.  
Initially just a minor faction,  
the Dankyo Party running candidates in the 1974 general election won zero seats.  
The shift came in the late 1980s.

The ruling party argued the 'Male Protection New Law' was curbing population decline - supported by data.  
But economic stagnation since the 1970s, combined with new taxes from the law, increased dissatisfaction among single middle-aged/elderly women.  
The Male Inclusion Movement and opposition parties adopting women's status elevation policies became their outlets.  
As in Yuu's original world, opposition parties reflexively opposed all government policies.  
In the last general election, ruling party Jishin Party secured a majority due to opposition disarray.  
But with anti-government protests like Male Inclusion Movement demonstrations gaining momentum, the ruling party faces an uphill battle in this autumn's election.

*(This feels like a dangerous trend...)*

Having met wonderful women like Sayaka since his rebirth, Yuu felt grateful despite some lifestyle restrictions.  
But if ruling parties changed, this male-preferential society might disappear.  
Opposition parties had varying stances, and election promises weren't guarantees.  
While unsure about the Male Protection New Law's specifics, Yuu feared policies would shift toward prioritizing women's interests.  
He'd learned some Male Inclusion Movement factions advocated extreme measures:

For example: Men over 18 would form groups matching gender ratios and spend set times (e.g., 10 hours weekly with three partners).  
Thus, one man would serve thirty women in rotation.  
Random age-matching could pair 18-year-old boys with 70-year-old women or vice versa - unlikely to involve sex, but still.

Another proposal: Mandatory domestic homestays where high school/college boys would live with female-headed households in other prefectures during breaks - required to comply if sex was demanded.  
This "temporary lending system" for young males gained female voter support despite feasibility questions.  
Essentially, it forced men to service any woman - elderly or unattractive.

*(At least let us have free choice in romance. I'd make exceptions for young beauties like Mom, but women my mother's age? No thanks.  
But this is the result of female surplus...)*

Yuu would gladly have sex with thirty selected women daily - provided they met his standards.  
But men like Yuu who pursued girl after girl were rare here.  
Despite abundant opportunities, his male classmates remained oddly unenthusiastic about romance - unusually so for adolescent boys.  
Though recently, gender interaction events were making them more approachable.

Incidentally, when Yuu raised current politics at school, boys showed little interest - some didn't even know the term "Male Inclusion Movement."  
While typical for high schoolers, their apathy toward issues affecting them concerned him.  
Student council discussions revealed Sayaka and Riko knew about it and shared his concerns.

Open opposition to the Male Inclusion Movement came from parents like Martina with sons or married women - but they were few.  
Worryingly, the movement was spreading among young single women too, leaving Yuu uneasy.

While researching recent developments and 10-20 year trends, Yuu noticed something:  
Documents repeatedly mentioned Toyoda Sakuya - his father - who built connections (including affairs) with young politicians, industrialists, and future leaders since the 1970s.  
This world's acceptance of extramarital affairs puzzled Yuu initially.  
Perhaps since men took multiple wives, women sleeping with other men wasn't stigmatized?  
Having witnessed Sayaka feel no shame about their relationship despite her engagement, Yuu accepted that chastity norms differed here.

His father Sakuya - seen only in photos and TV - was recently known just as an exceptional sexual performer.  
Legend said his exploits began at age 10, and during his remaining 20+ years he had 20 official wives but countless lovers - some estimates ranged from 500-600 women.  
He acknowledged over 200 children, with overseas offspring uncounted.  
(Information from Ministry of Health official Inui Rumiko and Fujiki Hiromi at the Toyoda Sakuya Memorial Foundation.)

Yet beyond his sexual prowess, Sakuya significantly contributed to improving male treatment and bridging gender divides in Japan.  
Achieving celebrity-like fame by his twenties, his approachable nature helped reform efforts culminating in the 'Male Protection New Law'.

But how many knew his true intentions?  
Yuu alone suspected his father might have been a reincarnator or time-traveler like himself.  
Both were reborn into this chastity-reversed world and actively engaged with women.  
But why did his father choose this difficult path despite having a literal harem in an era harsher for men?  
Did he wish to change a world where attractive women aged without male contact?  
Did he hope to correct this gender-imbalanced world?

Sakuya's true motivations remained unknowable.  
But after three months in this world, Yuu found himself contemplating his father's hidden feelings - and felt he could imagine them.  
Having experienced rebirth with memories, one would want to accomplish something meaningful rather than live ordinarily.  
His father's efforts underlay current male protection policies.  
Thus, Yuu opposed the Male Inclusion Movement that threatened to overturn them.  
Rather than extreme changes, society should improve existing policies where needed.  
This conviction grew stronger with each news report.

Before he knew it, almost 9 PM.  
Yuu decided to review today's studies in his room.  
His sister Elena was diligently studying for university entrance exams and likely still at it.

"Mom's late again today."

Silence enveloped the room when he turned off the TV.  
Hand on the living room doorknob, he muttered while surveying the empty space.

Unless emergency work arose, Martina usually returned by 7 PM.  
But since becoming management this year, meetings and client dinners kept her out later, with monthly overnight business trips.  
While her professional recognition was gratifying, she didn't seem pleased - it reduced family time (especially with Yuu).  
Lately, she seemed even later than usual.

Today was Friday, with family plans tomorrow afternoon.  
He'd heard she took Saturday morning off for it.  
She might be drinking a little - perfectly normal for an adult.  
No need for excessive worry.

After about an hour at his desk, Yuu suddenly heard clattering keys at the entrance.

"Oh, she's back."

At a good stopping point, Yuu tidied his textbooks and notes before opening his door and heading to the entrance.

### Chapter Translation Notes
- Translated "男共運動" as "Male Inclusion Movement" per Fixed Reference terminology
- Preserved Japanese name order (e.g., "Higashi Mako" instead of "Mako Higashi")
- Maintained explicit terminology for sexual content (e.g., "sexual assault", "semen suppliers")
- Transliterated sound effects (e.g., "clattering" for ガチャガチャ)
- Formatted news reports as separate paragraphs with standard quotation marks
- Italicized internal monologues per style guidelines
- Translated specialized terms precisely (e.g., "Equal Opportunity for Gender Interaction Law")