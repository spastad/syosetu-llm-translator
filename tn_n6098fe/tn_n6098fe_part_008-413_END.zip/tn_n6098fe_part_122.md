## 113. Mother and Siblings ~The Legend of Huge Melons~

### Author's Preface

I thought about splitting this chapter, but decided to post it as one long piece.

---

"Aaaahhhh~n! Yu~U~chaaaaaaaan!"

"Haha... Welcome home, Mom."

"My beloved Yuu-chan, I missed you! Hey, carry meee~!"

"W-wait, I'm coming now!"

The moment Yuu appeared in the hallway, Martina tried to rush in with her shoes still on, too impatient to remove them. Yuu dashed over and caught her body.

*(Yep, she's drunk.)*

Martina's tanned skin—a Latin trait—showed no visible signs of intoxication. But Yuu immediately knew: the pungent alcohol smell clinging to her nose, her voice higher and more excited than usual. This was the classic drunk homecoming.

With a wry smile, Yuu accepted Martina clinging tightly while sniffing his scent. She'd tossed aside her handbag and beige summer jacket, leaving her in a white tank top. Even without looking, her main weapons—massive breasts—pushed prominently against the fabric, bra patterns visible. Yuu leaned back as they pressed against him but managed to brace himself, the breasts squishing against him with a nearly audible *bonyon* sound. Though hugging Martina daily was routine, something masculine always stirred in Yuu, requiring constant restraint.

"Uu~n... Yuu-chaaan... I can't walk anymore. Carry meee~"

"H-hold on, Mom, you need to take off your shoes first."

As Martina tried to step up while clinging to him, Yuu hurriedly stopped her. Keeping his right arm around her back, he bent down and reached for her feet with his left hand. Naturally, her breasts pressed *monyu* against his cheek.

"Oof."

Blood relation or not, breasts were wonderful. He was a man after all. Trying not to grin, Yuu removed her brown high heels while noting her bare legs extending from the tight beige skirt.

After properly removing her shoes, they embraced in the hallway.

"Ufufuu~ I'm so happy my Yuu-chan grew up to be such a gentle boy. You're my proud son... fufufufu!"

"Haha, and you're my beautiful, youthful mom who always cares for me—someone to be proud of too."

"Aaahn, Yuu-chan, I love you!"

Though Martina appeared sharp and competent at work, she instantly switched to sweet mode upon seeing her beloved son at home. Tonight's stress was worse—she'd attended an unpleasant business drinking session. With a sloppy *dehehe* smile, she nuzzled her cheek against Yuu's chest. Their embrace resembled passionate lovers more than mother and son.

"Ah, Mom's home~"

Elena peeked out from her room. Martina, face buried in Yuu's skin, didn't notice, but Elena seemed accustomed and unfazed.

"Am I interrupting your studies?"

"Nope. It's fine. I was about to take a break anyway."

"Then help me take care of Mom?"

"Sure."

Together they guided Martina to the living room sofa. Her eyes were half-closed as she mumbled.

"She's really drunk tonight."

"Well, tomorrow's a holiday."

Even in his previous life as a salaryman, Friday nights were typical for drinking. Work-related events on weekdays were miserable—especially since he wasn't a strong drinker. Staying out until midnight and working the next morning was torture.

Yuu fetched water but didn't hand it to her, fearing she'd spill. Instead, he brought the cup to her lips while calling her name. Meanwhile, Elena fetched a negligee from the bedroom.

"Mmmph... Yuu-hyan, thank you~"

"You're welcome. Now, Elena brought pajamas. Let's change."

"Nnn~ undress meee~"

"Okay, okay."

In this gender-reversed world, women walked around topless or in underwear without concern, while men were more modest. Martina and Elena didn't mind Yuu's presence—if anything, he struggled where to look. When Elena casually lifted Martina's tank top, revealing a purple full-cup bra, Yuu stepped away to put away the empty cup.

"Yuu, help me!"

"Huh? Ah."

Elena called as she struggled with Martina's tight skirt and bra clasp. Changing someone unsteady was hard work, especially since Martina was taller and larger than Yuu. Yuu sat beside her, supporting her back. The removed bra revealed melon-sized breasts that naturally drew his gaze. Despite their volume, they showed no sagging, and her waist remained remarkably slim.

This resulted from Martina's post-pregnancy weight loss commitment and weekly gym visits. Compared to his previous world, women here cared more about beauty and anti-aging—likely due to the intense competition in a 1:30 gender ratio. Middle-aged women maintained their figures diligently since men could marry women decades younger. With polygamy, wives competed fiercely to maintain their husbands' interest.

Meanwhile, many young men grew slovenly with age. Unlike the past, men now held the choosing power. Yuu's father Sakuya had stayed fit—a "lean muscular" type in his 30s. His wives competed fiercely to maintain their figures. Though widowed, Martina's youthful appearance at mid-30s came from wanting to remain a wonderful mother for Yuu.

"All done."

Elena dressed her in a black sheer negligee, brushing her sweat-damp hair into a ponytail.

"Aahh... Elenaa, thank yooou... *fnyuu~*"

Martina was mostly asleep now, head resting on Yuu's shoulder. Smiling wryly, Elena sat opposite Yuu.

"Earlier, I heard Mom complaining when you were late."

"Hm?"

"Work's tough right now. Some advertisers pulled out simultaneously."

"That's... bad, isn't it?"

Newspapers relied heavily on advertising revenue—20-30% of income. Losing multiple clients was a major blow. Yuu knew publishing would decline with internet growth, but as a high schooler, he could do nothing. The frustration gnawed at him.

"Anyway, they have to find new advertisers now. That's why tonight's dinner happened?"

"Must've been tough."

Yuu knew hosting clients was stressful—some became unreasonable when drunk. He wondered about this world's equivalent of shady entertainment venues given the gender imbalance.

"Ah! I was about to shower."

As Yuu stroked the dozing Martina's head, Elena clapped her hands.

"Better put Mom to bed. I'll take her."

"Okay."

Elena opened doors ahead as Yuu lifted Martina, her arm around his shoulder. Carrying a drunk person was hard, especially someone taller. At least she wasn't thrashing.

"Whoa!?"

He tripped near the bed, tumbling onto the king-sized mattress with Martina still in his arms. Thankfully, he protected her head.

"Mmph... Yuu-hyan!"

Recognizing her son's embrace, Martina happily clung to him. Yuu adjusted their position.

"Mom, you're changed. Time to sleep."

"Uuu~ sleep... so... Yuu-hyan, don't gooo~"

"Alright, I'll stay with you."  
"Unfufu~"

Side by side, Martina buried her face in Yuu's neck with a blissful smile before drifting off.

Lying like lovers, Yuu gazed at Martina's sexy negligee-clad form. To him now, his birth mother was a stunning 36-year-old beauty who stirred his male instincts. Her scent—sweat mixed with perfume—felt comforting as a testament to her hard work for their family. Her breasts, the largest he'd seen, always aroused him during hugs. Now, though her nipples were hidden, most of her breasts pressed *monyuu* against his chest and stomach.

Yuu's right arm cradled her head while his left rested near her waist—unconsciously stroking her plump buttocks. Soon his hand crept under the negligee hem. Gulping, Yuu couldn't tear his eyes from her cleavage.

*(She's asleep, right?)*

His heartbeat quickened with guilt. Though touching her breasts or butt casually wouldn't bother her, tonight Yuu saw Martina less as a mother and more as a sexual being. Testing with light pokes got no reaction, so he boldly palmed a breast.

*(Whoa! Amazing!)*

Her breast dwarfed his hand—truly melon-sized yet soft and springy like rubber balls. Yuu didn't discriminate by size, but large breasts felt incredible. Women here supposedly felt ashamed of large breasts implying high libido, which seemed wasteful. Men definitely appreciated them.

Breasts like Martina's were rare treasures. She often complained about shoulder pain from their weight—Yuu had massaged them before, watching them sway from behind. Now engrossed, he rolled Martina onto her back. Her breasts swayed *boyoyon*, spreading slightly but still forming two distinct mounds. Straddling her stomach, Yuu grasped them firmly.

"...Haa... ah... uun..."

Hearing Martina's sensual moan, Yuu froze—but she didn't wake. Boldly lifting the negligee, he saw her natural breasts. After nursing two children, her nipples and areolae were large and maroon-colored. While young girls' small pink nipples were delicious, Martina's plump ones were equally appealing.

*(Ahh, so nice. I want to be sandwiched.)*

Squeezing *gyumu gyumu*, Yuu buried his face between them. Sweat mingled with a faint sweet scent. Having his face between large breasts was a male fantasy. Enjoying the sensation against his cheeks, he toyed with her nipples between his fingers.

"Fuu... ah... nn, nnn!"

Martina's breathing grew more erotic. Any more mischief might wake her. Unprepared for full intercourse, Yuu had one last desire.

He moved his face and *paku* took a nipple in his mouth. Rolling it with his tongue, he *chuu* sucked.

"Nnaah! Haan... nn, nfuun..."

Whether dreaming erotically, Martina moaned with uncharacteristic femininity. Tempted by the sounds, Yuu kept stimulating her with fingers, tongue, and lips.

"Yaan, stop... Sakuya-san, you... ufufu"

Hearing this, Yuu jerked away. Martina's dream partner was her late husband—replaying their marital intimacy. Yuu suddenly felt guilty.

Standing up, he covered her with a nearby towel blanket. Glancing at her happy expression, he sighed softly. Though he regularly had sex with Elena and felt no incest taboo—seeing mother and sister as attractive women rather than blood relatives—he couldn't reduce Martina to just a woman while she treated him as a son.

"Goodnight, Mom."

Leaving the room, he found Elena fresh from the shower, wearing only a towel.

"Sis?"

The bedroom door had been slightly open—she might have seen him obsessed with Martina's breasts. As Yuu hid his panic, Elena smiled and approached. Placing hands on his chest and waist, she whispered:

"Yuu, want to ejaculate?"

Her fingertip traced his half-pants front. Unnoticed by him, his cock stood fully erect. Elena pressed closer, stroking it as if reading his lust. Her damp hair and fair skin emitted a fragrance that intensely stimulated him.

"Ah... yeah, I want to ejaculate."

Yuu's voice came out hoarse.

Led by the hand into Elena's room, Yuu stood by the bed while Elena sat on the edge. She pulled down his half-pants and trunks in one motion.

"Ufunn..."

Seeing his cock standing skyward against his lower abdomen, Elena's eyes curved happily.

"Did sleeping with Mom put you in a sexy mood?"

Sniffing him, she looked up questioningly. With evidence exposed, Yuu gave up denying.

"Well... yeah."

"Do you want Mom?"

Her fingertip traced the veined shaft.

"Don't... know. Maybe I have those feelings."

If they bathed together like in childhood, he might lose control.

"Mom wouldn't refuse you."

"You think?"

"Un, definitely. She suppresses her feelings as a woman—loving you not just as her son but as the handsome, gentle Yuu you've become. But given the chance..."

"Ugh..."

Elena blew on the glans before nuzzling it.

"I think it's fine for our family of three to love each other deeply. Why can't we do what other women or half-sisters like Saira do?"

"Sis..."

Elena likely said this because Yuu had stayed over with student council members. Kissing the glans, she *paku* took it in her mouth, licking *pero pero* inside.

"I'll take care of your cock and make you ejaculate now. Tomorrow night, all three of us... *chup*"

"Ahh..."

"*Nchu*, *rero*, *rero*, *chupaa*... *anmu*, *juru juru*! *Nku*, *nn*, *nfuu~* oihii... *ann*!"

"Nnaah! Ahh... Sis, feels so good!"

Like when competing with Saira, Elena moved busily, using tongue and lips to pleasure his cock. From glans to base, everything grew slick with her saliva.

Yuu stroked her damp hair while slipping a hand under her towel to play with her breasts. Elena focused on fellatio while gripping Yuu's waist with her left hand and fingering herself with her right.

After licking everything and *pakku* taking the glans in her mouth, *kuchu kuchu* lewd sounds began.

"Kuu... uu... Really... you've gotten so skilled, Sis."  
"Nn? Nfufu."

Praising her while stroking her head, Elena looked up with crescent eyes, still sucking. She deep-throated him until it hit her throat, then began bobbing.

"Oh! Ooh... good..."

Her pursed lips and tongue created wonderful sensations—warm, wet membranes massaging him while being stroked. It felt like his essence might get sucked out. The taboo excitement of releasing his lust for his mother onto his sister was overwhelming. He was close to climaxing quickly, but an idea struck him. Yuu cupped Elena's cheeks.

"Today I want to thrust and ejaculate hard in your mouth."

Treating her mouth as a pussy, Yuu began thrusting—facefucking. Elena would never refuse any request. She delighted in her brother using her body. Cheeks flushed pink, eyes dazed, Elena let her towel fall, baring herself. Spreading her legs wide, she used both hands to stimulate her clitoris and vagina simultaneously.

"Haa, haa, Sis's mouth-pussy is the best."  
"Nn, nn, nguu... *vuu*mun...!"

Elena's light brown hair felt smooth and pleasant, but Yuu was obsessed with violating her mouth. He pulled back until the ridge nearly left her lips, then thrust deep into her throat repeatedly. This must have been painful, but Elena showed no discomfort, focusing on masturbation.

Looking down, Yuu saw two fingers inside her vagina, love juices dripping onto the bed.

After three minutes of facefucking—and the earlier skilled fellatio—Yuu felt his limit approaching.

"Guh... ah... Sis, I'm close... gonna ejaculate."  
"*Vu*, nn!"

Elena, tasting the cock sliding in her mouth, seemed to nod faintly. Sensing Yuu's throbbing cock, she closed her eyes but intensified her finger movements.

"Gah! Aah, cumming!"

*Dop*—the first shot spilled into her mouth. Normally she'd swallow it all, but respecting her preference, Yuu pulled back and aimed the tip at her chest.

*Pshaa*—semen gushed powerfully onto Elena's modest breasts.

"Aah aaahn! Hot! So much hot stuff! Haaaaaaahhh... wonderful... this... I love it... oh, oh, being covered by Yuu... feels so gooood...!"

*Busha*, *busha*—each splash made Elena shudder *bikun bikun*. She seemed to orgasm while being covered. With a blissful expression, she swallowed the semen in her mouth. Then she lovingly spread the white fluid from her collarbone to stomach with her fingers, licking them repeatedly.

---

### Author's Afterword

Among the female characters in the "Character Introduction," Martina and classmate Goto Mashiro both exceed 100cm bust size, standing as twin peaks. Next in the 90cm+ group are nurse Takano Mio, protection officer Kitamura Kanako, half-sister Yanai Miku, Saiei Academy's Omori Norika, and Ushijima Mari from Red Scorpions. The crucial Komatsu Sayaka belongs to the third group, but still sufficiently eye-catching for the protagonist.

### Chapter Translation Notes
- Translated "デカメロン伝説" as "The Legend of Huge Melons" to preserve breast size reference and pun on "Decameron"
- Translated "射精(だ)" as "ejaculate" per explicit terminology requirement
- Translated "チンポ" as "cock" per explicit terminology requirement
- Preserved sound effects: "ぼよん" → "bonyon", "ぎゅむぎゅむ" → "gyumu gyumu"
- Maintained Japanese name order: "Hirose Yuu", "Hirose Martina", etc.
- Italicized internal monologues per style guide
- Preserved honorifics: "-chan", "-san" unchanged