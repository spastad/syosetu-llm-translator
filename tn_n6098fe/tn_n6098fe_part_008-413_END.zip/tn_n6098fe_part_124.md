## 115. To the Hot Springs ② ~Love again~

Though located within the same prefecture and relatively close distance, since we're soaking in hot springs and staying overnight, it should be acceptable to call this a trip.

When it comes to trips, meals are one of the enjoyments. The female members seem particularly inclined toward this. Even if you stay at a nice inn, it would be ruined if the food were bad. As expected, every dish served at Shiromine-kaku was wonderfully delicious.

Thus, the six members of the Hirose family and protection officers gathered around the table, chatting noisily while savoring the lavish meal. While Yuu was in his growth period and ate heartily, Elena had a small appetite, and Martina surprisingly didn't eat much either. Instead, the protection officer Kanako demonstrated her hearty appetite, and even Touko ate voraciously despite her small frame, making one wonder where it all went.

When the meal ended, the maids came to clear the dishes and simultaneously laid out the futons. Though it was still before 9 PM, leisurely spending time before bed is one of the pleasures of traveling.

"Thank you for the meal. If you need anything, please call via intercom."  
"Yes. We look forward to your service tomorrow as well."  
"""Good night."""

Not wanting to disturb the family's private time, the three protection officers withdrew to the second floor. The room that had been lively just moments ago suddenly became quiet, making Yuu feel oddly unsettled.

Seeing the three futons laid side by side, Elena was the one whose spirits lifted. Of course, the arrangement had Yuu in the middle with Elena and Martina flanking him on both sides. The three family members sleeping in a "川" formation hadn't happened since before moving to the current apartment, back when Yuu was in lower elementary school. Though this should be natural when staying at an inn, Martina also seemed unsettled seeing Yuu accept this arrangement when the previous Yuu would have absolutely refused it. Sitting at the table sipping cold sake after dinner, Martina became strangely quiet after the protection officers went upstairs.

"Phew~ I ate so much~ My stomach's full~"  
Perhaps because she relaxed now that it was just family, Elena flopped onto the futon on her back. The female saying "dessert goes to a separate stomach" seemed true in this world too - she completely finished the sliced cake despite having eaten her fill of the main meal. Well, Yuu had thoroughly eaten his portion too.

Yuu sat on the futon and looked at his sister. Relaxing just like at home, she spread her legs wide without concern, revealing her slender long legs up to the borderline. Seeing Elena happily rubbing her stomach with a blissful expression, a mischievous impulse welled up in Yuu.

"Let me see."  
"Ah!"  
"What? It's not swollen at all."

Though Elena normally had a small appetite, today she seemed to have taken her time eating. But to the touch, her stomach was completely flat.

"Geez, Yuu!"  
"Wah!"

Elena sat up and hugged Yuu from behind, reaching her hands around. "Hey, Sis! That tickles!"  
"Wahaha, isn't it fine, isn't it fine... gufufu"  
"Y-your hands are being lewd." Elena not only had one hand around his stomach but slipped her other hand inside his collar toward his chest.

Martina watched Yuu and Elena playfully roughhousing with a smile. Half a year ago, when Elena had assaulted Yuu while he slept, it created a decisive rift between them. This scene would have been unthinkable until about a month ago. Rather, it was unbelievable that Yuu wasn't resisting Elena clinging so closely but was instead touching her back. Watching them play, Martina felt a restless emotion welling up inside. Letting her tipsiness take over, her body moved.

"Mommy's joining in too."  
"Mom."

Yuu spread his arms and caught Martina as she charged at him. Because he'd been playing with Elena, his collar was completely open and his skin exposed. When Martina buried her face in Yuu's chest, she felt a creaking pain deep in her heart. "Ah... fuhn... Yuu...chan..."

Sandwiched between hugs from front and back, Yuu stroked Martina's head with one hand and tightly grasped Elena's hand with the other. Then he said to both of them:

"Let's take a bath together in the private bath."

"R-really? Is it okay, Yuu-chan?"  
Martina asked for confirmation before entering the changing room. Elena, looking buoyant, didn't hesitate at all and quickly stripped naked to enter first. Since there were only two shower areas, Elena and Martina went in first.

"Just this once, I think it's fine."  
"But... Yuu-chan, about five years ago? When Elena and I barged in..."  
"Well, back then I was at that age where even small things embarrassed me. But now I've grown up a bit, or rather... I actually want to bathe together."  
"Eh... but..."  
"Mom doesn't want to be together?"  
"N-no, not at all!"  
"Then it's decided. Go on in."

Yuu spun Martina around and untied the obi around her waist. Her yukata front slipped open, revealing melon-sized breasts over her shoulder.

"I-I can undress myself!"  
"Haha, right."

Gently pushing her exposed back, Martina entered the bath with slight shyness.

Since there were only two shower areas including the shower heads, he let Martina and Elena go first. Since they'd already bathed in the large public bath earlier, this was just to rinse off sweat. Both had washed their long hair earlier and tied it up, so it remained that way.

"Guess it's about time."  
After waiting about 10 minutes, Yuu removed his yukata and underwear and entered.

"Let me wash your back."  
"Yuu!"  
"Huh? Yu-Yuu-chan!? Wait... eeeeeeeeeeeh!!!"

She probably never imagined he'd enter without covering his crotch. While Elena showed plain delight, Martina gaped in shock. After all, what entered her vision wasn't the childlike penis she remembered, but an adult-sized cock with thick pubic hair, fully exposed and swinging with the glans bare.

When Yuu was little, she'd bathed with him and washed every inch of him lovingly. But seeing Yuu's fully grown naked body up close now, Martina couldn't hide her agitation. She averted her eyes in panic, facing forward and looking down. Because of this, she didn't notice Elena calmly looking at Yuu's nakedness, staring intently at his crotch with drooping eyes.

In the world before Yuu's rebirth, this would be like a father flustered upon accidentally seeing his daughter's fully matured body after bathing, when he'd often bathed with her as a child.

Yuu paid no mind and knelt on one knee behind Martina. "Mom, I'll wash your back."  
"Uh... eh?"  
Taking advantage of Martina freezing while washing her front, Yuu took the soapy washcloth and pressed her shoulder with one hand, starting to wash her back.

Martina's back was broad for a woman, yet her ample breasts were visible from the sides. It tapered beautifully toward the waist and had plump, large buttocks.

As a half-Japanese, half-Spanish person with looks favoring her Spanish mother, Martina had a brownish skin tone characteristic of Latin heritage. Though Yuu preferred fair skin, her skin maintained its firmness and smooth texture even in her mid-thirties, and the magnificent curves of her back exuded a mature sexiness that captivated him.

"Mom really has great proportions."  
"Ny... what are you... saying? T-to your parent..."

As Yuu washed her back with moderate pressure, Martina barely managed to reply. Her face had been flushed since earlier - whether from embarrassment or lingering drunkenness, Martina herself didn't know.

After washing down to her buttocks, Yuu hugged Martina from behind. "Hya!?" She trembled at the suddenness, but Yuu paid no mind and whispered in her ear:

"Mom, thank you for today. Honestly, I'm moved to have such a wonderful birthday."  
"Ah... i-it's fine. Thanks to Yuu-chan, our family of three has become close again like before. I just thought we should do something special since we have the chance..."  
"Then tonight, let's get especially close with some naked bonding."  
"Yuu-cha... ahfuu"

Martina let out a sensual moan as Yuu's breath touched her ear. His arms wrapped around her from above and below, sandwiching her breasts. As Yuu tightened his embrace, her sandwiched breasts bulged forward. Yuu enjoyed the softness of her ample breast flesh against his arms, and his crotch swelled up, pressing against Martina's buttocks. "Ah..." Despite being blood-related parent and child, a sensation of perceiving each other as man and woman began to rise. At that moment, Elena placed her hand on Yuu and pleaded.

"Ahn, Yuu! Wash my back too!"  
"Ah, right. Sorry, sorry. Sis's turn now."

Martina felt both relieved and slightly lonely as Yuu moved away. But when Yuu said "Mom, face this way" and she turned, she felt a light touch on her lips. In an instant, Yuu had given her a brief kiss before pulling away.

"Yuu...chan..."  
"Fufu, we used to do greeting kisses before."

Yuu smiled mischievously and moved toward Elena who had sat back down. It might have been a greeting kiss between close family. But now Martina's heartbeat suddenly quickened, and a desire to kiss Yuu more surged within her.

Though lacking breasts, Elena's fair-skinned back was beautiful in a different way from Martina's, captivating enough to make Yuu deliberately tickle her while washing her back. When he finished by inserting a finger into her anus, she writhed with a sensual "Kufuun!" Yuu remembered Saira saying "If you develop Elena's anal area, she'll definitely be happy" and even leaving specialized tools as a gift. As he thought he'd try that someday, Elena turned toward him.

"Now Mom and I will wash Yuu together!"  
"O-oh."

This time Yuu was sandwiched - Martina washing from behind, Elena from front. It coincidentally recreated the night about five years ago when elementary fifth-grader Yuu (before rebirth) began distancing himself from his mother and sister. Martina felt concern, but the person in question was nonchalant.

"Are you really okay?"  
"Mhm. Once in a while, this is nice."  
"Y-yes..."

Martina stared anew at the back before her. When temperatures rose, Yuu would often come to the living room shirtless right after bathing. At those times, Martina would fluster and look away, telling him to put on a shirt.

But today she was looking so closely and openly. Seeing her son naked after so long - he'd grown taller and gained muscle, now exuding a fully adult male aura. For Martina, the only male nudity she'd seen was her husband Sakuya's, so she inevitably superimposed them. Also, just as men get aroused seeing women's backs, in this world women found men's backs sufficiently arousing.

*(Sigh... I thought he'd always be a child, but he's become so sturdy. And... how sexy.)*

Martina forgot about washing and traced her fingertip along his shoulder line while staring at his youthful, dewy skin that repelled water droplets.

"Nn... Mom?"  
"Ah! S-sorry. I'll wash now."  
"Okay. Please."

Shaking her head as if to dispel worldly desires, Martina busily began washing Yuu's back.

Meanwhile, Elena, being accustomed to Yuu's nudity, didn't tense up like Martina but instead had desire swirling deep in her chest. However, since their reconciliation, she'd been disciplined to only fondle him when permitted.

Now that she had the justification of washing Yuu's body, her mouth remained slack-jawed while moving both hands, looking like she might drool any moment. "Ahaa... Yuu's Adam's apple is so sexy..." "R-really?" Not understanding his sister's moe point, Yuu smiled wryly while leaving it to her.

Since the neck area was delicate, Elena washed it directly with soapy hands. Consequently, Yuu felt like he was being fondled, making him feel ticklish and unsettled.

Elena's hands moved from shoulders to chest. Though he lacked squeezable flesh like women, Elena's hand movements felt strangely lewd. As evidence, Elena was breathing excitedly with "Haa, haa." Gripping both his sides, Elena whispered "Yuu" and brought her face close. She must have seen the brief kiss with Martina and wanted the same. Martina behind him seemed focused on washing Yuu's back and hadn't noticed.

Yuu responded with several light "chu chu" kisses while fondling the modest breasts before him. Elena grinned foolishly and lowered both hands toward his stomach while lowering her gaze. Then she noticed.

"Ufufu... Yuu's little penis... it's gotten big♪"  
"Ah..."  
"Eh?"

Hearing this, Martina also looked down over Yuu's shoulder. Her overly plump breasts pressed against Yuu's back. Because of this, his erection that had been at 70-80% fully hardened to the point of hitting his lower abdomen.

"Eeeeeeh... n-no way... this is... just like..."  
Martina covered her mouth mid-sentence.

"Hey, can I wash Yuu's little penis?"  
"E-Elena!"

Martina recalled what happened five years ago. It was fine until they played while washing Yuu's cute penis and he ejaculated, but then Yuu ran away in extreme embarrassment. But Yuu's answer betrayed Martina's expectations.

"Ah, Sis, and Mom too - will you wash it together?"  
Yuu looked back over his shoulder at Martina. Their faces were close. "Yuu...chan..." Staring at Yuu's expectant expression, something hot overflowed in Martina's chest. "Mom, please?" "If Yuu-chan asks... chu" Martina hugged him from behind and pressed her lips to his. "Nn..." "Ah... fuu" Then she stroked Yuu's chest as if caressing it, gradually moving downward.

Elena pressed close from the front and touched his cock first, gently stroking it up and down. Simultaneously, she opened her mouth and ran her tongue along Yuu's neck. Martina's hand enveloped the tip of his cock.

"Ahh... how splendid... and so hard, so hot..." Martina gazed at Yuu with moistened eyes as if he were a beloved man rather than her son, rubbing the glans. "Ah... ahh! I-it feels good... nmu!" When Martina's lips parted, Elena who'd been licking his neck quickly stole them. Resignedly, Martina kissed Yuu's cheeks and ears while moving her hand. By now, Elena and Martina seemed completely distracted from the original purpose of washing, engrossed in alternately stealing kisses and fondling Yuu in their aroused state.

"Amu, chu, chupujuru... reroreroo, afuun... Yuu, I love you!" Going beyond greeting kisses, Elena whispered with a melting expression while deep kissing with tongue. Her right hand jerked the shaft up and down while her left hand played with her own private parts.

"I love Yuu-chan so much I couldn't live without him. Hey, Yuu-chan, let's kiss more chu chu? Aahn, chupureroo... jururu..." "Mo... mom... nn, nku, puha... Mom's breasts feel good."

Martina shook her body slightly in excitement while stroking Yuu's chest and stomach, using her other hand to stimulate the glans to induce ejaculation. Though unconscious, her movements mirrored when she and wife-friends surrounded and served her husband Sakuya.

Meanwhile, Yuu was intensely excited not just by taking turns deep kissing with mother and sister and being touched everywhere, but also by the sensation of Martina's huge breasts pressing "muni muni" against his back. His cock, covered in soapy lather, felt doubly pleasurable as both women stroked it.

"Ah, ah, akuun! Yu, Yuu... good, good, feels so good... ann!"  
"Ku! M-me too, Sis!"

Behavior the former Yuu would never have permitted. Elena masturbated while making squelching sounds as she jerked his cock.

Yuu looked at Martina with a pained expression. "Ahh... Mom, I can't stop feeling good. I'm going to... ejaculate like this!" Seeing Yuu like this, Martina looked at him with affectionate eyes and gave a gentle "chu" kiss. "Ahh, how adorable. Let Mom and Elena make you feel refreshed." "Ahh! Ku!"

As if demonstrating her past expertise, Martina skillfully used her fingertips to stimulate the frenulum and other sensitive spots to induce ejaculation. In Martina's mind, this wasn't sexual behavior with a man but transformed into an expression of affection toward her son Yuu.

"Ann, ann! Yu, Yuu... like this... I-I'm cumming too... I'm cumming!"  
"M-me too... kua! Ah... v! Cumming!"

Guided to ejaculation by the double handjob and caresses from front and back, Yuu couldn't hold back. Semen spurted from his cock, splattering messily onto Elena's chest and stomach as she leaned over him.

"Kuhiiin!"  
Already nearing climax from her own fingers, Elena was hit by the hot white fluid - an impulse stronger than that night five years ago surged through her body. "Ah, ah, ah... hya... i, i, ihi, ihiiin... Yuu's... seeeemen... a, afuiiiiiiiiiiiiii" Gushing "pusha pusha" as she came, Elena arched her back in climax.

"Ah... ahhaa, so much... came out. Yuu-chan, amazing." Martina couldn't stay calm either. Witnessing force and volume rivaling her husband's past ejaculations, and feeling the sticky hot semen on her hand, her female instincts were stimulated. Her lower abdomen burned hot, and love juices trickling from her vagina moistened her inner thighs.

---

### Author's Afterword

To be honest, I hesitated until the last moment about posting "5. Past ② ~Into the Dream~". I wondered if I should have included a normal erotic scene. But I'm glad I could write this bath scene that recreates the past. The difference from five years ago is that a new relationship begins from here.

### Chapter Translation Notes
- Translated "川の字" as "川 formation" to preserve cultural concept of sleeping arrangement
- Translated "ちびちび" as "sipping" for drinking sounds
- Preserved Japanese honorifics (-chan, -san) throughout
- Translated explicit anatomical/sexual terms directly per style guide
- Transliterated sound effects (e.g., "muni muni" for むにむに)
- Maintained original name order (Hirose Yuu, etc.)
- Used explicit terminology for sexual acts without euphemisms