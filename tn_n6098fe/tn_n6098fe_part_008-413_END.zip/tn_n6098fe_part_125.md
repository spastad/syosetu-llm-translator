## 116. To the Hot Springs ③ ~Continuation of the Dream~

"Okay, I'll turn off the lights now."

Elena turned off the room lights, leaving only the faint orange glow of a standing lamp by the wall. The dim light was barely enough to distinguish faces. Yuu lay on his futon face-up without a coverlet. Immediately, Elena came to his left side and pressed herself close against him.

"Come on, Mom too."  
"Eh... but..."  
"Tonight's a special day. Let's sleep together."

Earlier in the private bath, Martina had sandwiched Yuu front and back while washing him. When he ejaculated, she'd passionately pressed her breasts against him as if forgetting they were blood-related mother and child. After rinsing off, the three soaked in the tub while embracing and exchanging kisses.

But after getting out and drying off, Martina's head had cooled slightly, making her wonder if they'd gone too far. Yuu, however, showed no such concern, smiling as he held Martina's hand while returning to their room. Of course, Martina also longed for more skin contact and kissing with Yuu. Yet simultaneously, she hesitated about surrendering completely to the flow.

Unconcerned with Martina's inner conflict, Elena actively entangled herself with Yuu. Even now, she happily clung to Yuu's arm, pressing her face against his neck from her open collar.

"Hahaha. Sis, that tickles."  
"But Yuu, your skin smells so nice."  
"You smell wonderful too, Sis."  
"Hyan! Y-Yuu!"

Watching Yuu and Elena play, a competitive feeling swelled within Martina. She snuggled against Yuu from the opposite side, taking his arm and pressing it against her chest. Though all three wore yukata, their bodies were flushed from bathing, causing their robes to gape open. Martina's especially exposed half of her large, protruding breasts, so Yuu's right arm was directly sandwiched between them - a fact he inwardly delighted in.

"Yuu...chan!"  
"Haha, Mom smells wonderful too."  
"Ahhn..."

When Yuu turned toward Martina and brought his face close, he rubbed his cheek against her shoulder and neck.

"Hey, Mama?"  
"Hmm...?"

Martina nearly moaned from feeling Yuu's body heat and breath, but Elena's voice brought her back.

"This feels like a dream, doesn't it? Sleeping together with Yuu like this."  
"Y-yes. Too happy... it feels like a dream."  
"It's nice for our family of three to sleep together sometimes."

Yuu gently bumped foreheads with Martina while looking into her dark brown eyes. "Ufufu," Martina smiled, but as she gazed at Yuu, warmth spread through her while drowsiness set in, her eyelids growing heavy.

"Goodnight, Mom."  
"Mmm."  
This time, a light kiss in place of words. "Goodnight... Yuu-cha...n... love... you..."  
"Me too, Mom."

Seeing Martina close her eyes peacefully, Yuu noticed poking from the opposite side. Looking at Elena, she pursed her lips like a pouting octopus. Yuu smiled wryly and kissed her, slowly savoring it.

"Ahfuu... hey, Yuu..."  
"Sis, can you wait a little longer?"

Elena, who'd tangled not just her arms but also her bare feet peeking from her yukata hem with Yuu, looked at him with expectant eyes. But Yuu shook his head slightly to restrain his sister.

"If you can't be patient, I won't listen to your requests later."  
"Uu... o-okay. I'll endure with this for now."

Completely yielding to Yuu's control regarding sex, Elena clung tightly to him while waiting for her turn.

◇ ◆ ◇ ◆ ◇ ◆

"Martina's breasts are the best. Not just their appearance - great for squeezing, sucking, and sandwiching. Hahaha!"  
"Hyan! Oh Sakuya-san... ah, ahn! Somehow Sakuya-san seems like a big baby... ah, don't suck so much... aun!"

Since childhood, her larger-than-average breasts had been a complex. In this world, big-breasted women were unpopular - associated with laziness and sloppiness due to heavier builds. The strong stereotype of heightened sexual desire persisted too. In crowded places like packed trains, they were considered nuisances, and finding properly sized clothes and underwear was troublesome. During exercise, the weight and painful swaying hindered agile movements required in sports. Worst of all was the shoulder stiffness.

But Sakuya-san said he loved my breasts. And I knew it wasn't just lip service - his gaze had been glued to them since our first meeting.

From our first time together, Sakuya-san was obsessed with my breasts. Though experienced with women, he claimed he'd love any breast size, but said mine were exceptionally large yet perfectly shaped - the best. So I burned for him not just when we met during my senior year, but even after marriage.

Sakuya-san was skilled at kissing and caressing. Not that I had comparison experience, but among his other wives, some had been with other men and said no one compared. No man was as gentle, knowledgeable, skilled... and large while being able to perform consecutively like Sakuya-san. Especially with my breasts - sometimes he'd caress with gentle, delicate touches, other times boldly kneading them with just the right roughness. And his tongue work when sucking them! Just breast play alone could bring me to ecstasy.

That night too, after many passionate kisses, Sakuya-san's hands soon reached my breasts. Starting with light palm strokes, he gradually increased pressure - not painful, but pleasurable.

"Hyan! Ah... n-nipples... ah, ah, aahn!" Sakuya-san's fingers kneaded and pinched my nipples. "Your nipples got bigger after having Elena. But that's good. And more sensitive now, right?" "Ah... nnn! M-maybe sensitive... ahh! D-don't do that!" "They're already this erect. See?" "Ahh! Sakuya...san! N-nooo, I'm feeling it ooooh!"

Ignoring my moans, Sakuya-san played with my nipples while kissing from my cheeks to jaw, then trailing his tongue down my neck. When Sakuya-san caressed me, every part felt intensely sensitive. Even his breath on my skin drove me toward pleasure - my whole body felt like an erogenous zone. I never imagined I'd make such lewd noises.

"Fufufu. Then I'll help myself to Martina's breasts." "Ah, ah, ahh... Sakuya...san..."

After thorough kissing and foreplay lasting minutes, I'd turned completely pliant. Yet Sakuya-san smiled refreshingly and engulfed my breast, sucking and nibbling at my nipple.

"Haaaaaaahhhhhhhhhaaaaaahn!"

I cried out long as electricity seemed to course through me - then abruptly, the scene changed. A baby was suckling at my breast. Eyes mostly closed, tiny hands resting on my breast, diligently sucking - it was Yuu.

Just being able to have sex with a man and bear children was fortunate, but joyously, my second child was a boy. Though regretful that his father Sakuya-san didn't live to see him, I resolved to raise Yuu well as an offering to Sakuya-san. Anyway, Yuu was the world's most precious son - the phrase "so dear it wouldn't hurt even in my eye" fit perfectly.

*(Ah... wha...?)*

The Yuu suckling at my breast blurred before me - next moment, he'd grown into a boy's form. Like Yuu just after turning 16. 16? Huh...?

Yuu... looked up at me. "Fu. Mom's breasts are the best. Not just their appearance - I want to squeeze and suck them endlessly." Yuu kneaded my breasts with both hands, playing with one nipple. Then he took the nipple into his mouth. His hand movements, his tongue work - just like Sakuya-san...

"Ahh! Yuu...cha... n-nooo, I'm feeling it ooooh!"

I was getting aroused by my son fondling my breasts. Wrong. Wrong. Yet despite my mind, my body reacted sensitively. After thorough licking, having them squeezed between lips, gently bitten... then sucked chu-chu like when he was a baby - lewd noises escaped as my jaw slackened.

Yuu's caresses moved to my other breast. By now I couldn't resist, just surrendering to Yuu while crying out. Unthinkingly, I wrapped both arms around Yuu's head and back, stroking my beloved son's grown body. Until now, Yuu and I had shared many kisses and hugs. Though he distanced himself somewhat during puberty, since around spring this year he'd started initiating contact again - making me so happy.

But mother and son doing this... is bad. Because... toward my son Yuu, my raw female instincts... ignites lustful feelings. That should be directed at a husband. I have Sakuya-san... huh? The Yuu before me seemed just like Sakuya-san...

Yuu lifted his mouth from my nipple and smiled at me. "Fufu, Mom, you're wet." Before I knew it, Yuu's fingers touched my crotch - making a squelching sound.

◇ ◆ ◇ ◆ ◇ ◆

"Hah, dream...? Y-Yuu-hya!"

When Martina awoke, Yuu was covering her, sealing her half-formed words with his lips. Cradling her head with his left arm like a pillow, he kissed her repeatedly while changing angles, then pushed his tongue between her pressed lips. Though Martina's eyes widened at first, far from resisting, her eyes grew hazy as she entwined her tongue with his.

Yuu, covering Martina, supported himself on his left elbow to avoid putting full weight on her. Meanwhile, his right hand traced her drenched privates with delicate touches - just like in her dream.

"Amu, churu... nn, vu, a, ahn! Yuu-hya... nn, nnnn~~~! V-hiin! There... no, don't... i, i, aun!" "Mom, amazing, you're soaking wet guchu guchu. See? My finger slides right in." "Ah, ah, aaaaaaahhhhhhh..."

As Yuu's middle finger inserted and began moving deep inside, squelching ju-pu-puu sounds of love juices echoed while Martina cried out. Unnoticed, Elena beside them was completely naked, and Martina's yukata had been opened to expose her chest while her sexy black lace panties were removed.

"Now two fingers. Ooh... going in. Mom, how is it? Feel good?" "Ahh! Yuu-cha... stop, don't move... ah, ahn!" "Fufu, seems like it feels good." "N-no... aun! Yuu... this is... wrong... ah, ah, ah, aaaaaahhhhhh! M-my breasts too... don't suck them!"

Not only did the two fingers in her vagina move faster, but her nipple was sucked again, making Martina shake her head side to side as if refusing. Though her mouth said no, her awakened female body gladly accepted Yuu's caresses. Proof being how she clung tightly to Yuu's back and spread her legs wide without resistance.

After thorough licking, Yuu released her nipple with a chu-pon sound and brought his face close again. "Mom, let's kiss?" "Yu...u..." Seeing Yuu approach with tongue out through half-lidded eyes, Martina opened her mouth slightly to accept. Like a chick receiving food from its parent, she licked deliciously at Yuu's tongue. The vaginal assault continued uninterrupted, Martina intermittently moaning while never stopping the kiss-play.

After kissing awhile, Yuu whispered in a husky voice, lips nearly touching:

"I can't hold back anymore. I want to love you not as my blood-related mother, but as an attractive woman. Because... see? You can feel it, right? How hard I am." "Ah... nn... I-I can feel it."

Earlier in the bath, Martina had realized when seeing and gripping it - that it was an impressive manhood identical to her late husband Sakuya's. But feeling its heat and hardness pressed directly against her lower abdomen now made her throb intensely, emotions welling from her chest. The instinctive female desire to be penetrated hard and impregnated. Yet if this entered her, there'd be no turning back.

Still, Martina had no option to refuse Yuu's desire. If her son wanted it, her duty as a mother was to provide. Even if her son became a criminal, a mother could pour out unconditional love. Though currently, Martina wavered greatly between maternal love and lust as a woman.

Martina gazed at Yuu with moist eyes, then embraced his head and opened her legs to ease insertion while their lips met. She spoke one phrase:

"Co...me... Yuu"

### Chapter Translation Notes
- Translated "おっぱい" as "breasts" consistently per explicit terminology rule
- Preserved Japanese honorifics (-san) and name order (Hirose Yuu)
- Transliterated sound effects: "ちゅるっ" → "churu", "ぐちゅぐちゅ" → "guchu guchu"
- Rendered sexual acts without euphemisms per style guidelines
- Maintained first-person perspective for Martina's internal monologue in dream sequence
- Used gender-neutral "they" for Sakuya's plural wives when context was ambiguous