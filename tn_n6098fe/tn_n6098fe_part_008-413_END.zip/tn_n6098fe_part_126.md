## 117. To the Hot Springs ④ ~One Night of Love~

### Author's Preface

Changing things up a bit, we begin from Elena's perspective.

---

"Aah......... Aaaaaaaaaaaaaahhhhhhhh!!  
Yu... Yuuuuuun, nnnh! Ha, ha, it's going in... haaahhhh!"  
"Guoooh... M-Mama's inside, it's so hot... oh... this is...  
Haah, haah, Mama... it feels so good."  
"Yuu, Yuu... ahhn! Don't, if you move now... mmph!"  

Right before my eyes, within arm's reach, Yuu and Mama are having sex. Even though I love Yuu so much it hurts, unlike me, Mama seemed resistant to having a physical relationship with him.  

But maybe the rare bath together, Yuu caressing her while she slept, and sharing the same futon in an inn room instead of home pushed her over the edge.  
No. With Yuu passionately pursuing her like that, no woman could refuse.  

I could tell Mama let out an unprecedented high-pitched moan the moment Yuu entered her. I know. Yuu's cock is hard, big... and feels so good...  
Plus Yuu's hip movements are amazing. Not just monotonous thrusts - sometimes grinding in circles, sometimes varying the intensity - until you're completely overwhelmed and come multiple times before he ejaculates.  

Especially when he gets excited and pounds your cervix repeatedly - it's unbearable. I nearly lost consciousness. When he came inside me while I was orgasming, I actually fainted.  

"Haa, haa, haa, haaaaan... Yuuuuuu! I-I want it too!"  

As Yuu thrusts and Mama moans with disheveled hair, I've been touching myself between my legs from this close distance where I can feel the heat of their entwined bodies. At first I was rubbing my clit, but when they joined, I inserted my middle finger deep into my vagina.  

Memories of having sex with Yuu and the intense scene before me blend in my head as I move my fingers imagining Yuu thrusting into me. One finger isn't enough. When I move two fingers - middle and index - inside, it makes a squelching sound. My pussy is already dripping slick fluids onto the sheets.  

Just watching Yuu I love so much having sex with someone else excites me. That cock that drives women wild makes loud squelching noises as it ravages a pussy that isn't mine. That thick, hot semen that makes me come just from being splashed on my body is pouring into another woman.  

Just watching this makes me aroused from the depths of my being - I can't help but pleasure myself. I must blame Saira for awakening this strange enjoyment in me.  

Yuu wrapped his arms behind Mama's knees and pushed them forward. He covered her completely, making their joined parts gradually face upward.  

*(Ah... that feels good too...)*  

Until high school, most of my sexual knowledge came from erotic books, usually showing women riding on top of men lying on their backs. But Yuu knows so many positions - he always surprises me. Unlike normal, he often takes the top position or sits facing each other while embracing.  

Right now, Mama is being mounted and taken from above - what Yuu calls the "breeding press" position for impregnating women. When we did it, the deep connection felt indescribably good - when he came inside me, my mind went blank and I fainted mid-orgasm.  

After trying various positions, my favorite is turning my back to Yuu and having him enter from behind. Doggy style or rear entry. Sometimes on all fours on the bed, sometimes standing while he pounds me from behind. That makes me come over and over uncontrollably. Yuu says this is how animals and insects mate.  

Thinking I'm mating with my blood-related brother rather than just having sex excites me even more.  

Yuu's movements are speeding up. He must be close to ejaculating. Mama keeps screaming "I'm coming!" But the climax when he ejaculates is the most intense part.  

After Yuu releases loads of semen inside Mama, it'll be my turn. Normal men can't go again immediately after ejaculating - usually only once per night. But Yuu's different. He can go consecutively, and his semen volume is enormous.  

Handsome, gentle, mature beyond his years, and incredibly strong in bed - no woman could resist drowning in Yuu, whether she's his blood-related sister or mother. At this rate, both Mama and I might end up pregnant with Yuu's child. I'm certain both Mama and I would gladly accept that.  

◇ ◆ ◇ ◆ ◇ ◆  

"Ah, ah, aah! Yes, yes... Yuu... haaaaahn! Don't... don't grind so deep... I can't!"  
"B-but... Mama's pussy feels too good... I-I can't stop my hips! F-for the first time... Mama's pussy and my cock fit perfectly!"  
"Aahn! Why... why does it feel... so good? Ah... aheee... I can't, I'm coming, coming... I'm coming! I'm coming from Yuu's coooock!!!"  

Both Yuu and Martina were surprised by how well their bodies matched while being engrossed in devouring each other. Is it true that blood relatives have exceptional physical compatibility?  

Yuu hadn't expected the tightness of a teenage virgin from Martina, a mother in her late 30s. But when he thrust deep, an electric jolt of pleasure shot through his entire body.  

Meanwhile, Martina only knew sex with her husband Sakuya. It felt like reliving intimate moments with her beloved husband, swept up in waves of ecstasy from the start.  

Yuu intended to slowly thrust to get accustomed after mounting her in missionary without putting full weight. But he quickly lost control and became completely absorbed.  

After making her come twice or thrice, Martina realized her legs were spread wide with Yuu fully on top, her hips raised with their genitals tightly joined.  

"Ah... aah... so deep... Yuu... filling me up ryuu"  
"How is it? Mama, does this feel good?"  
"Haah, haah... I... can't even think... hyaah! My cervix... being tapped! Shoko! Shorekimohiiiroooo"  
"I know. Mama's cervix is wide open, swallowing the tip of my cock. Your womb is accepting my seed. I'll... ejaculate inside now!"  
"Hyaaaaah! Yuuuuuuuu!"  

As Yuu slammed into her, loud flesh-smacking sounds echoed. Martina had not only wrapped her arms around his back but unconsciously locked her legs around his waist too.  

Though overwhelmed by intense pleasure, a scene from the past flashed through Martina's mind.  

Sixteen years ago, around early October when Martina turned twenty. With twenty wives, they celebrated birthdays collectively early each month. Three wives including Martina had October birthdays, and since it coincided with her "lucky days," Sakuya chose her first that birthday night.  

"Martina, would you like to have another child?"  
"Y-yes. I'd be happy to have Sakuya-san's child."  

That night ended in the same position with Yuu now, receiving massive amounts of semen. After Sakuya's death, she discovered her pregnancy - Yuu was born almost nine months later on June 30th.  

*(If he comes inside me now... I might get pregnant...)*  

Coincidentally, Martina's body had reached ovulation - entering the so-called "lucky days" period. She wasn't without resistance to getting pregnant by her son. But now, Martina was nothing but a female craving male seed.  

"Ahh! M-Mama, it feels so good! I-I'm about to come..."  
Seeing Yuu's pained expression as he neared climax made Martina's lower abdomen ache intensely. Femaleness and motherhood mingled within her, filling her with unbearable affection for Yuu.  

"Ahhn! Yuu... don't hold back... let it out! Inside me... lots, give me loooots!"  
"Mama... I love you."  
"I love you... too... ah... mmph... mmph... mmfuun... mmvuu! Nnh! Nnnn~~~~~~!"  

Yuu's hips began sliding rhythmically in small, quick thrusts since Martina's legs restrained larger movements.  

"Ah, ah, oh... ooh... amazing! Ahhn, Yuu! I'm... coming again!"  
"Kuuh... kah! M-Ma... Martina! I-I'm about to come... aah! I'm coming! Ejaculating!"  

Sweat-drenched, Yuu and Martina held each other tightly without separating as they approached climax. When Yuu's body trembled against hers, he released torrents of semen into Martina's womb.  

"Aaaaahhhhhhhhhhhh!  
Ah, ah, aheeeee... it's coming out! Yuu's... se-eeki... ahh... pumping... so much... haahn"  
"Ha, haha... that was amazing, Mama"  

Unaware he'd called her name, Yuu buried his face in Martina's sweaty neck, breathing heavily after ejaculating. Martina also panted while gently stroking Yuu's head, then suddenly spoke.  

"Hey... Yuu?"  
"Hm?"  
"Just for tonight... forget we're mother and son. Treat me like your lover."  
For Yuu, who'd seen her as an attractive woman since they met, this was beyond welcome. "Ah, yeah. Got it, Martina.  
Martina, you're an incredibly sexy woman."  
"Ehe, Yuu... I'm happy. Mmph"  

As Martina smiled happily and Yuu began kissing her, Elena sidled up beside them.  
"Au~. Next... me..."  
Though she'd come from masturbating, her lust burned fiercer as she spread her vulva open and pressed against Yuu.  

Still joined with Martina, Yuu raised his upper body slightly and smiled. "Couldn't wait and masturbated, huh? I know. Next is... Elena.  
Get on all fours over Mama with your ass toward me."  
"Unh!"  

As Yuu separated from Martina lying on her back, a sticky sound accompanied his still-hard cock pulling out. Elena eagerly took her position. Far from calming after one ejaculation, Yuu's erect cock showed endless desire swirling within him.  

Staring at her petite, well-shaped ass up close, he saw everything from her labia to anus glistening wetly.  
"Ahhn! Yuu, hurry!"  
"Haha, can't wait already?"  
"Because~"  

Elena shook her ass enticingly. Yuu grabbed her buttocks and spread them apart. Though dark, the smell of female arousal wafted from her thoroughly soaked sex.  

Kneeling, Yuu positioned himself to enter Elena and declared to both women:  
"Being with two beauties like Martina and Elena today has me incredibly excited. One round each might not be enough. Sorry, but you'll have to indulge me."  
"Ahhn... Yuu, use me as much as you want!"  
"Me too. Ejaculate inside me until you're satisfied."  

Both Martina and Elena smiled seductively at Yuu. Once women cross that line, they become devoted to desire. Positions like mother or sister mean nothing. Naturally, Yuu intended to satisfy them thoroughly in his heightened state.  

"Fufu, first I need to plug up Elena's lewd pussy!"  
"Ahhaa~ Yuu's cock is touching me. Pound me hard... give me lots of seeeemen inside too!"  
Just having the tip against her wet opening made Elena look at Yuu with rapturous delight, nearly drooling.  

"Alright, here I go"  
Grabbing her buttocks, Yuu thrust deep inside in one stroke.  

---

### Author's Afterword

2019/10/6  
I previously had Martina conceive Yuu at the September birthday gathering, with Yuu born 10 months later on June 30th.  
However, I was mistaken about the pregnancy period.  
I've revised it to the birthday gathering in early October, with the birth about 9 months later.

### Chapter Translation Notes
- Translated "種付けプレス" as "breeding press" to convey the impregnation-focused position
- Rendered explicit sexual terminology directly ("cock," "pussy," "ejaculation")
- Preserved Japanese relational terms ("Mama") as used in original dialogue
- Transliterated sound effects (e.g., "guchu guchu," "bachun bachun")
- Maintained first-name basis for characters as per original text usage
- Italicized internal monologues per style guidelines
- Translated "当たり日" as "lucky days" (fertile period) based on Fixed Terms