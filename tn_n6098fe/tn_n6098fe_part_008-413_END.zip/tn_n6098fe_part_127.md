## 118. To the Hot Springs ⑤ ~With You in the Morning Sun~

### Author's Preface

Even after reviewing before and after posting, typos and missing characters still persist. I'm grateful for the frequent error reports. I'd like to take this opportunity to express my thanks.

---

After overlapping bodies with Martina for the first time, I had Elena climb on top of Martina and continued having sex consecutively. Of course, I ejaculated plentifully inside her.

Tonight with both of them, my sexual desire seemed to overflow more intensely than usual. While taking hydration breaks, I alternated inserting my cock into Elena and Martina while they embraced each other. I ejaculated continuously in Martina then Elena in that order.

Feeling genuinely exhausted, Yuu lay down on his back holding the already downed Martina beside him, but then Elena began a clean-up blowjob. With her recently improved technique, Yuu became fully erect again, and Elena sucked enthusiastically until swallowing his semen. Satisfied, Yuu and Elena fell asleep overlapping each other.

"Mm... morning?"

When Yuu awoke, he noticed sunlight leaking through gaps in the closed curtains, making the room dimly bright rather than dark. It must be around dawn.

Yuu had good sleeping posture, so he remained on his back as when he fell asleep, with Martina and Elena clinging tightly to his sides. Naturally, all three were completely naked. Their hair, which had been neatly tied before the private bath, was now completely disheveled, covering their faces, carrying a mingled scent of hair fragrance and sweat.

*(Haha... I finally did it)*

He felt no regret about having overlapped bodies with Martina, his mother by bloodline. Though biologically his mother, to the reincarnated Yuu she was mentally a younger exotic beauty. He had thought this might happen someday - the hot spring inn stay just became the trigger.

*(It felt better than I imagined...)*

If there's a theory that blood-related partners have good physical compatibility, it might be true. The reason incest is considered bad, besides risks to offspring, might include warnings against becoming so obsessed with each other that other matters get neglected.

The morning air was slightly chilly, making the skin-to-skin contact with both women pleasant. But Yuu had woken due to needing to urinate. He carefully extricated himself without waking them. As Yuu moved away, Martina and Elena's hands fumbled until they touched each other, then they seemed to fall back asleep peacefully. Seeing this, Yuu smiled and covered them to the shoulders with a thin summer blanket.

"Fwaaah..."

Yawning hugely, Yuu stretched with both hands raised. His body felt sluggish and still sleepy. "Hmm~ I'll go to the bathroom." As he was about to leave the room bare, he reconsidered and put on underwear and yukata. Checking the clock, it was only around 5:30 AM - normally still sleeping time. Especially after a sex-filled night. Waking so early was probably because they were staying away from home.

The detached building had traditional Japanese-style construction. Sliding open the door revealed white walls on both sides and a dark wood-grained corridor. At the end was an entrance, with stairs to the left and toilet/washroom/private bath to the right. The wooden sliding door had a circular cutout covered with shoji paper, allowing faint light through. But the corridor and entrance were unlit, making it hard to see ahead. Yuu turned on the corridor light as he closed the door.

"Whoa!"

Yuu couldn't help exclaiming when he saw the lit corridor. From his perspective, a girl lay face down as if collapsed from left to right.

"Eh... Touko-san?"

Though he couldn't see her face, the petite body and bobbed hair identified her as bodyguard Touko. Had she gotten sleepy going to the bathroom and fallen asleep? She wore the same white T-shirt from last night but seemed to have removed her red-and-white striped sweatpants, which were discarded nearby. As Yuu approached, following her slender but toned legs with his eyes, he saw her plain white panties directly. So plain it made her look like a middle schooler. Watching closely, her back rose and fell slightly - truly just sleeping.

Suddenly Yuu realized: Depending on when she came down, she might have heard last night's indecent acts. Had she stopped here and fallen asleep while listening? Why had she removed her sweatpants? Though curious, Yuu decided to wake Touko since leaving her here was improper.

"Touko-san, you can't sleep here. Wake up."  
"Mm... uunnn..."

She seemed in deep sleep, not waking from just his voice. Yuu knelt and shook her shoulder area. She only mumbled without waking.

"Er, troublesome... Got it!"  
Yuu touched Touko's bobbed hair, brushed it aside to expose her ear, and brought his mouth close.  
"Touko-san, wa·ke·up... hoo!"  
"Hyaaauuuu!"

The effect was dramatic. Touko's eyes snapped open. After staring blankly at Yuu, she seemed to grasp the situation. She suddenly sat up straight and knelt formally.

"O-oh, you're awake."  
"Yu... Yuu-sama... aahn..."

Somehow while staring at Yuu, Touko's face reddened, and she hugged herself while fidgeting. Yuu guessed she'd heard last night's banquet - Martina and Elena's voices had echoed considerably. Feeling embarrassed, Yuu decided to change the subject.

"Um, it's still early. Why not go back upstairs to sleep?"  
"Mm... What about Yuu-sama?"  
"Eh? Me... hmm, after the bathroom, what should I do?"

Talking with Touko had fully awakened him. Now Yuu noticed his body felt sticky.

"Since we're here, maybe I'll take a morning bath."  
"Bath...? Then I must guard Yuu-sama!"  
"Eh?"  
Even in the safe inn, letting Yuu walk alone seemed unacceptable. "Okay. Then together... is Kanako-san alright?"  
"Being alone with Yuu-sama is a rare opportunity... I mean, I alone am sufficient!"  
"Haha. Got it."

Knowing from yesterday that towels were provided in the large bath, Yuu needed nothing else. After using the toilet, he returned for the room key and left with Touko. When Touko glanced up expectantly, Yuu took her small hand. As they walked hand-in-hand, she smiled shyly with delight.

Walking through the covered corridor, a cool breeze blew - it must have rained overnight. The garden greenery glistened wet in the morning sun. Today's forecast was clear then cloudy - perfect for sightseeing. But even with bodyguards, males walking outside tourist spots was dangerous, so they planned to only visit well-secured buildings. He recalled discussing buying souvenirs at Chichibu's local products center.

Entering the main building, several maids were already working. Seeing women working briskly without slacking even without guests watching felt refreshing.

"Good morniiing!"  
"Goo... eh? Ah... Good morning..."

When an older maid nearby happened to pass, Yuu greeted her. Though startled, she quickly recovered - befitting an inn accommodating men.

"Is the large bath open yet?"  
"Ye... yes. We clean several times daily, but otherwise it's available 24 hours."  
"Right. Then I'll go in."  
"Please take care."

As Yuu walked off with a nod, the maid who'd bowed deeply muttered, "Hirose-sama this early... Can't stay like this," and hurried off somewhere.

Arriving at the 3rd-floor bath entrance, another maid stopped Yuu. "Apologies. We're still preparing. Could you wait about 15 minutes?" They must have been cleaning for early bathers. While the women's bath seemed open, the men's had a "Preparing" sign.

"No problem. I'll wait over there. Please call when ready." Yuu pointed to the adjacent rest area without irritation, making the maid bow with relief. Touko looked pleased they could stay together longer.

The spacious rest area had three familiar massage chairs near the entrance. Several sofas for relaxing filled the center. Along the walls were a large TV, pamphlet racks, drink vending machines, and even nostalgic game consoles - though no ping-pong table.

When Yuu tried entering yesterday evening, many female guests occupied it, so he'd waited in the hallway. Now seeing the unmanned room's contents felt novel. After looking around, he sat beside Touko on a sofa. Throughout, Touko remained silent.

To Yuu, resident bodyguard Kanako felt like a reliable older sister, but Touko seemed more like a younger sister due to her appearance. Seeing her perched daintily on the wide, comfortable sofa meant for post-bath relaxation looked adorable.

"After I bathe, will you return, Touko-san?"  
When Yuu asked, Touko shook her head. "I'll wait here."  
"Ah, well, I won't take long. Sorry to trouble you."  
"No. It's my job... or rather, for Yuu-sama it's no trouble at all."  
"Haha... thanks. I appreciate it."  
"G-glad. That encourages me."

Hearing Yuu's words, Touko's cheeks flushed crimson as she smiled shyly. Initially as a resident bodyguard, she seemed expressionless and silent, but talking revealed rich expressions and decent, if blunt, responses. Though Kanako said this was special treatment for Yuu.

With no one else present, Yuu acted boldly. Moving from beside Touko to face her, he reached for her head - just to fix her slightly messy bedhead. Touko froze momentarily, but as Yuu's hand combed through her hair, she narrowed her eyes comfortably.

While fixing her hair, Yuu gazed at Touko's makeup-free face. She glanced at Yuu with her large, cat-like upturned eyes before shyly looking away. Though youthful, her well-defined features made her cute even barefaced. Her faintly reddened small lips looked as lovely as poppy flowers. He almost wanted to kiss them. Gently stroking her head while combing, she let out a small "Hah..." sigh. Though letting Yuu handle her hair, Touko eventually looked up at him.

"Yu... Yuu-sama..."  
"Hmm?"  
"Um... that... Yuu-sama is... n-never mind."

Perhaps surprising herself by saying Yuu's name, Touko trailed off.

"Sorry to keep you! Please enter now."  
When Yuu tried prompting Touko to continue, a maid called from the entrance, making them spring apart.

"Then I'll go. Let's talk more when I come out."  
"U... Have a good bath."

Touko watched Yuu go with slight hesitation. After seeing Yuu pass through the men's bath curtain, the maid rehung the "Preparing" sign and returned to work.

"Ooh, private bath."

Passing through the curtain and opening the frosted glass door, Yuu entered. The changing room was classroom-sized. Shelves about chest-height lined the walls and center, each with a basket. Opposite were four sinks facing a long mirror, with wall-mounted dryers - a familiar sento scene.

Combined with the bath area, about 20 people could use it simultaneously. But for men's baths, even peak times probably didn't reach half capacity. Places like Shiromine-kaku requiring male accompaniment rarely filled completely given the male population scarcity. Compared to female-only facilities, male-accessible ones incurred extra security costs. Yet they stayed profitable - Yuu imagined national subsidies as rare male recreation facilities, drawing from his salaryman experience.

Though tidy yesterday, the changing room now looked freshly opened - immaculately clean. The floor was dry without a speck of dust or hair. Sink amenities for men were neatly arranged, spotless and gleaming. Having this private bath to himself as first bather felt exceptionally pleasant.

Since alone, Yuu idly looked around before taking a basket from the wall shelf. Just as he untied his yukata sash - knock knock - came a knocking sound. Turning, it seemed from a door labeled "Employee Entrance - No Unauthorized Entry."

"Eh... yes?"

Slightly confused, Yuu responded. The door slowly opened, revealing the nervous innkeeper. Unlike yesterday's kimono, she wore a pure white halter-neck dress. The skirt ended about 10cm above the knees, revealing long legs. Her hair, neatly styled yesterday, was now simply bunched with a barrette.

"Um, Hirose-sama... If acceptable... sh-shall I wash your back...?"

Only glancing at Yuu once, the innkeeper's voice faded as she looked down. She clearly understood the gravity of entering the men's bath - a stark contrast to yesterday's dignified demeanor. Yuu recalled a new employee from his salaryman days who, after a critical error, stayed silent until colleagues pointed it out before reporting to the manager.

That said, the shoulder-baring dress seemed designed for mixed bathing. Hearing Yuu would bathe early, she'd likely changed specifically. Though wearing minimal makeup unlike yesterday, having this 30s Japanese beauty prepare for him gave no reason to refuse.

"Sure."  
"R-really? Most men dislike bathing with women..."  
"No no, from the innkeeper I welcome it. I'd be grateful."  
"Re... really!? Aaah... thank you!"

Seeing her charming smile made Yuu happy too.

"Ah, but wouldn't it be problematic if other male guests came?"  
"Don't worry, I've reserved it privately for now."  
"Haha, thorough preparation."  
"U..."

The innkeeper's eyes darted as if hit a sore spot. But seeing Yuu undress boldly before her - removing not just yukata but underwear to stand completely naked - made her gape in shock. Without covering himself, Yuu let his impressive member swing as he headed for the bath.

"Well, let's go."  
"Ye... yes!"

Having prepared for 90% refusal, the innkeeper not only accepted with a smile but watched Yuu's unflinching naked back with conviction, following him into the bath.

### Chapter Translation Notes
- Translated "身体を重ねた" as "overlapped bodies" to convey physical intimacy while maintaining explicit terminology
- Preserved Japanese honorifics (-san for Touko, -sama for Yuu) per style rules
- Translated "お掃除フェラ" as "clean-up blowjob" to explicitly convey the sexual act
- Transliterated sound effects: "トントン" → "knock knock", "ふわぁーあ" → "Fwaaah"
- Translated "女将" as "innkeeper" consistently, referring to Nishizawa Manami from Fixed Reference
- Used explicit anatomical terms: "チンポ" → "cock", "股間の立派なモノ" → "impressive member"
- Maintained Japanese name order: "Kujira Touko" instead of Western order
- Italicized internal monologues per formatting rules