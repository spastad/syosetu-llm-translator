## 119. To the Hot Springs ⑥ ~Once More~

"My, it's slender yet firm and sturdy.  
And your skin is so smooth... Youth is truly wonderful."  
"Hahaha..."  

Since she asked if she could wash not just his back but his entire body if he didn't mind, Yuu obediently entrusted himself to the innkeeper. Previously at Sayaka's apartment during his birthday celebration, he'd been washed from head to toe by three seniors. Compared to peers like them, the innkeeper felt more like a mother—though that might be rude—or an older sister diligently caring for her younger brother. Her careful washing felt pleasant, and Yuu completely surrendered himself.  

"By the way, what's that?"  
Behind him, the innkeeper held a cloth bag larger than a clenched fist, washing him with slow, stretching motions without applying force. It had a unique scent—not unpleasant, but somehow nostalgic.  

"This is a rice bran bag.  
They're rarely used nowadays, but rice bran bags have skin-beautifying effects."  
"I see. That's why your skin is so beautiful, innkeeper-san."  
"My!"  

Her exposed arms extending from bare shoulders were flawless—fair and glossy. Though he guessed she was likely in her thirties, her youthful appearance could pass for twenties.  

"Fufu, hearing such words from young Hirose-sama makes me immensely happy."  
The innkeeper began washing Yuu's chest while embracing him from behind. Her breasts pressed naturally against his back, revealing considerable volume.  

"How is it? I have no experience washing a man's body..."  
Her breath touched Yuu's ear as a floral fragrance tickled his nostrils.  
"Eh!? You're so skilled, I assumed you must wash someone regularly."  
He considered asking if it was a lover or husband but decided against prying.  
"Hohoho. Unfortunately, I'm single with no such partner. Letting me touch a man's body directly like this... it's been quite a long time."  
"Huh... A beauty like you... what a waste."  

The innkeeper's hands descended from his chest to his abdomen.  
Yuu's crotch was already semi-erect.  
"Ah..."  
Spotting it over his shoulder, the innkeeper fell silent.  
"Th-that part... would you prefer to wash it yourself?"  
"No, since we're here, please wash it for me."  
As Yuu turned his face sideways, their cheeks nearly touched.  
"Y-yes."  
Blushing under Yuu's gaze, the innkeeper nodded slightly.  

While she'd used the rice bran bag for his upper body, soap seemed better for his groin. When her well-lathered hands enveloped him, his cock quickly hardened, standing straight up. *Even after ejaculating six times last night, it's still energetic—I'm amazed at myself.* But with a beautiful innkeeper devotedly attending to him, it couldn't be helped. Her touch was gentle, but the slippery lather felt incredibly pleasant.  

"Ooh... f-feels good, innkeeper-san."  
"Ah... ah... th-this is...!?"  

Her initially tentative movements grew bolder—gently stroking from tip to base, then fondling his balls. Pressing her body against his back, she stared intently at Yuu's crotch. After swallowing hard, she cupped the glans with one hand while lightly gripping the shaft with the other, starting to jerk him from the base.  

"Ah... ahhh!"  
Ignoring Yuu's involuntary moan, the innkeeper became engrossed in her handjob.  
"Haaa~ it's twitching and pulsing... such an impressive specimen. Just like... ah!  
M-my apologies!"  
"Huh...?"  

Releasing him, she suddenly moved in front of him, kneeling formally and bowing deeply.  
"I... lost myself and got carried away..."  
"U-um, I don't know why you're being so formal... If anything, it felt good. Ah, please raise your head."  

Flustered, Yuu gripped her shoulders and lifted her head. Relief washed over the innkeeper's face at his words. As they gazed at each other, she smiled with mesmerizing beauty.  

"Truly... even your attitude toward lust-driven women is the same."  
"Eh?"  
"Please sit."  

Kneeling, the innkeeper began washing Yuu's inner thighs. Though curious about her earlier remark, Yuu found his eyes drawn to her breasts swaying "purupuru" with each movement as she leaned forward.  

"May I share an old story?"  
"Er... yes."  
Washing Yuu's feet with the rice bran bag while wearing a serious expression, she compelled him to nod.  

"My family, the Nishizawa family, has run Shiromine-kaku since my great-grandmother's time.  
This was when my mother was innkeeper.  
Back then, I attended local high school while training here on weekends."  
"Mm."  

*Even now she's this beautiful—what was innkeeper-san like as a high schooler?* Yuu vaguely imagined a dignified beauty like Sayaka.  

"Seventeen years ago, just before the autumn colors emerged—early October, I suppose.  
A very famous person stayed here with his wives.  
His name was... Toyoda Sakuya-sama."  
"Eh..."  
"It seemed one wife struggled to conceive, so upon learning of Manpou no Yu's reputation for blessing women with children, Sakuya-sama brought about five wives for a two-night stay."  
"I see."  

From what Yuu knew, his Saitama-born father moved to Tokyo after marriage. While gradually taking more wives, he traveled energetically nationwide—sometimes abroad—without becoming reclusive. But typically, he rotated between his Tokyo residences. Though involved with many women, he cherished his official wives, and visiting Manpou no Yu was part of that.  

"It was the last morning of Sakuya-sama's stay.  
Being Sunday, I was helping at the main building early.  
That's when Sakuya-sama wandered alone into the morning bath and spoke to me.  
He asked me to wash his back. Then I..."  

As if recalling the scene, the innkeeper touched her cheek dreamily, having finished washing his feet.  

"I often resented having to work early Sundays without sleeping in like classmates.  
But fortune smiled upon me.  
To spend my first time as a woman with a wonderful gentleman like Sakuya-sama...  
Thanks to a veteran maid's discretion, the men's bath was reserved. That morning seventeen years ago, I spent a dizzying moment of love here.  
Unfortunately, it was during my infertile period, so I didn't conceive."  

Pausing, the innkeeper wore a lonely expression before continuing.  

"Working here, men sometimes approach me.  
Shortly after inheriting as innkeeper, one even offered to make me an official wife.  
But I could never forget being held by Sakuya-sama at seventeen...  
Before I knew it, time passed with me single and heirless."  

Her eyes glistened as she looked at Yuu. By now, her wish was clear. Considering the timeline, his father died about a year after their encounter, making reunion impossible. *Is she superimposing Sakuya onto me?* He doubted she knew they were father and son.  

"So this morning, I coincidentally went for the morning bath. Just like seventeen years ago."  
"Yes."  
"But why me?"  

Uncertain if she knew their relationship, Yuu feigned ignorance. The innkeeper smiled shyly.  

"When I saw you yesterday, I was shocked... w-would you... not think me absurd?"  
*Her composure then must've been professional decorum.*  
"It's fine. Please tell me."  
"I s-suddenly felt transported back seventeen years... I-is it... love at first sight? I couldn't stop thinking about you... Ah! Forgive me! How shameful for a woman my age to feel this way..."  

*She likely sees Sakuya's shadow in me.* Though conflicted about receiving ardent affection from a woman who shared his father's first experience, Yuu thought accepting it was manly. Above all, her wet yukata clinging to her form was irresistible. After brief hesitation, he resolved himself.  

Ignoring her surprised expression, he drew close and embraced her beneath the arms.  

"Eh!?"  
"I accept your feelings. Let me be your partner as Sakuya...-san was seventeen years ago."  

He could've revealed being her son but chose silence out of pride. Regardless of her feelings for his father, Yuu wanted to embrace her as himself.  

"Ah... Hirose-sama. I'm too moved for words. Someone as wonderful as you must have many partners, yet you'd choose this aging—"  
Yuu pressed his lips to hers.  

"...! Mm..."  
Her eyes widened upon realizing they were kissing, then closed as she surrendered to the sensation.  

"Sorry for the suddenness. But just as you took interest in me, I also thought you were beautiful."  
"Wh-what joyful words... Please call me 'Manami'. Named after Manpou no Yu—'man' from 'full', 'na' from 'watercress', 'mi' from 'beautiful': Manami."  
"Manami-san, what a lovely name. Then please call me by name too."  
"Eh...?"  
"Come on."  

After a light "chuu" kiss, Yuu gazed into her dewy dark eyes.  

"Manami-san, well?"  
"An... Yuu-samaaa."  

This time Manami initiated the kiss. Savoring each other's lips, they kissed slowly, changing angles repeatedly.  

Breaking the kiss, Yuu lowered his gaze. The wet yukata clung tightly, accentuating her voluptuous curves—arguably more erotic than nudity. But this was a bathhouse. He wanted to see Manami's body fully.  

"It's unfair for just me to be naked. I want to see all of you, Manami-san."  
"Eh... m-my nakedness is unsightly..."  
"Come now—"  

Ignoring her, Yuu lifted the hem. First visible were plump thighs and the dark lower abdomen beyond. As Yuu undressed her, Manami surrendered completely.  

"Ooh..."  
Yuu gasped involuntarily.  

Her slender neck and delicate shoulders contrasted with perfectly shaped, ample breasts that defied her age by staying perky. Her stomach was taut enough to show ribs, with a cinched waist and voluptuous hips—utterly alluring.  

Yuu caressed from her back to buttocks. *I want to embrace her, release deep inside, and impregnate her.* He felt this desire bubbling within.  

"Ah, you're beautiful, Manami-san."  
"Anh!"  

Proving his sincerity, Yuu pulled her close. Since her skin had cooled, he pressed flush against her front, rubbing her back to warm her.  
"Ah..."  
A sweet sigh escaped Manami at the warmth. Hearing it at his ear heightened Yuu's arousal. Kissing her again, he slipped in his tongue. Manami met it with hers, their tongues entwining with wet "pichapicha" sounds.  

"Nha... mufuu, le rochuru... nn, nn, nfuu... ah... nnn... jyu ru... Yu... hya ma... aauun! Nnnn~~~ chupa"  

After a deep kiss like exchanging saliva, a string of drool connected their lips when they parted. Manami's face was utterly blissful. Yuu kneaded her buttock with his right hand while reaching forward to grope her breast with his left. Her beautifully ripened flesh felt soft, stoking his excitement.  

"Shall we do it here?"  
Yuu whispered after licking her wet lips.  
"Hah, hah, anh!"  
Already aroused by his touch, Manami shook her head slightly.  
"J-just accepting Yuu-sama's kindness... w-would disgrace womanhood... uun!  
F-first... let me... serve you... ah, ah... let me serve you."  
"Serve me, huh..."  
Kneading breast and buttock with full palms, Yuu smiled.  
"Okay. Please."  
"Th-then..."  

Manami took Yuu's hands from her body and stood.  
"This way."  
"Eh?"  

Expecting fellatio on the spot, Yuu was surprised when she led him toward the bath's edge—near the women's bath boundary.  

Three doors lined the wall. Yuu assumed they led to sauna or cold baths, but signs read "Special Massage Room 1" with a note:  
*Special Massage Room requires reservation.  
Please inquire at front desk.*  

"Special Massage Room...?"  
"Please enter."  

Smiling, Manami produced keys from a small pouch.  

"It connects to the women's bath, so it's usually locked."  
"Haa."  

Following Manami inside, Yuu found a room similar to a household bathroom. Only the bathtub was larger, fitting two adults comfortably. The key difference was the large vinyl mat on the tiled floor and a garish golden chair with a hole in the middle—a so-called "pervert chair". Having visited such places over a decade ago before marriage, Yuu recognized this as modeled after soap lands. *Who uses this?* Only couples or guests seeking private services.  

Standing frozen just inside, Yuu faced Manami as she fidgeted shyly.  

"Guests in the main building without private baths sometimes use this with lovers or spouses.  
Some regulars request young maids to accompany them here—though that's not official business and depends on personal negotiation. As innkeeper, I always refuse such requests.  
So this is my first time using it... I'm unsure if I can satisfy you...  
But I'll serve you with all my heart. Please be kind."  

Kneeling, Manami placed both hands on the floor and bowed deeply.  


### Chapter Translation Notes
- Translated "ぬか袋" as "rice bran bag" per Fixed Reference
- Rendered "チンポ" as "cock" following explicit terminology rule
- Preserved "-san" honorific throughout
- Translated "手コキ" as "handjob" without euphemism
- Italicized internal monologue *(Even after ejaculating...)*
- Transliterated sound effects: "ぷるぷる" → "purupuru", "ぴちゃぴちゃ" → "pichapicha"
- Maintained Japanese name order: Nishizawa Manami
- Translated "湯あみ着" as "yukata" for cultural accuracy
- Used "Special Massage Room" as predefined term
- Applied dialogue formatting: New paragraph per speaker, attribution exceptions for continuous speech