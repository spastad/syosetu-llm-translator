## 120. To the Hot Springs ⑦ ~Hold Me HOLD ON ME!~

"I'll pour the lotion now."

"Ah, yes. Nngh... It's not... cold...?"

"I warmed it with hot water beforehand."

Yuu obediently lay face down on the vinyl mat as instructed. Manami straddled him, pressing close against his buttocks as she opened the plastic container and poured transparent liquid onto his back. He vaguely recalled that at soaplands in his memory, they diluted concentrated solution with hot water, but what Manami held seemed to be a ready-to-use liquid.

After pouring a sufficient amount, Manami began massaging from his shoulders down his spine, spreading the lotion with both hands.

"How is it? I'm afraid I'm inexperienced, so I'm not confident if I'm doing it well..."

"Nn... Ahh, it feels good. Very skillful... I think."

"I'm glad..."

Manami's touch was gentle yet effectively kneaded his muscles. Pure bliss. But when she touched his sides, the ticklish sensation made him let out an odd sound. This made Manami laugh too, easing the atmosphere - which was fine by him.

After thoroughly spreading lotion from Yuu's back to buttocks during the massage, Manami applied the remaining lotion to her own body. Slowly, she lowered her upper body to press fully against him. Manami stood slightly shorter than Yuu. She rested her chin on his shoulder, their bodies touching down to the toes. He could distinctly feel her breasts squishing softly against his back.

"Ooh..."

"Um... am I too heavy?"

"Not at all. Rather, feeling your body pressed against me feels so good it's exciting."

"My... Ufufu."

Manami smiled happily before showering kisses down from Yuu's cheeks to his ears, nape, and neck. Then she gradually began moving her body.

"Ooh... th-this is..."

"Nn... hah, hah... afu... nngh!"

Her soft limbs undulated slowly from shoulders to back, buttocks to legs. Combined with the slippery lotion, it felt incredibly pleasant. This must be what being smothered by slime feels like. Manami herself seemed aroused by moving her entire body to caress Yuu. The hot breath against his ears and nape transformed into pure pleasure. His erect cock pressed painfully against the mat beneath him.

After a while, she shifted him to a sideways position. With legs bent, it resembled sitting sideways in a gym class posture. From behind, she pinched his nipples while probing his ear with her tongue, sending shivering pleasure through Yuu's head.

"Hauu! Ah, hi, Ma-Manami-fann... nnnn~~~~"

"Nnfuu... lero lero pichu... does it feel good?"

"Ah... uu... ngh!"

Though Yuu had licked ears many times, he never imagined it would feel this intense when done to him. After thorough licking around and inside his ear, his breathing grew ragged. Seeing Yuu's dazed expression, Manami smiled and slightly pulled away. Stroking Yuu's inner thigh with her right hand, she began planting kisses from his armpit to waist.

"Kuu... ah, ah, ah! There too!"

"Nnfu, it feels good, doesn't it? Yuu-sama's face looks so adorable."

Yuu felt utterly overwhelmed by Manami's caresses, as if it wasn't his own body. He'd visited soaplands before, but only budget shops with short sessions - no mat play experience. While her full-body techniques might not match professionals, the pleasure exceeded expectations - whether from his sensitive teenage body or Manami's heartfelt service.

After stroking and kneading Yuu's thighs to feet, Manami's hands eventually reached his buttocks. Then her fingertips began circling his anus.

"Ahh! Th-there, no!"

His body jerked involuntarily, a girlish voice escaping. Though not penetrating, just teasing the wrinkled area around the hole was intensely stimulating. The nuchu nuchu sounds from his own body mixed with lotion felt strange too.

"Kufu. Is this a weak spot?"

"Nn... nnn~~~~~~! P-please, spare me just there!"

"If fingers are no good, shall I try licking?"

"No no... your intention is enough. B-better focus on my cock."

Yuu declined, not wanting to kiss after having his anus licked. Now lying face up, Manami nestled close and kissed him while cradling his head. Her right hand gently stroked his swollen cock like tending to a boil. That alone felt unbelievably good.

Not just his lips, but Manami kissed his forehead, nose tip, cheeks and jaw. Her eyes glazed with lust, cheeks flushed pink. "Ahh... Yuu-sama, how wonderful and adorable you are. I could just eat you up. Aaahn." Her voice carried not just female desire but maternal affection as she licked his lips with her flickering red tongue.

"Ma-Manami-san..."

"Nn... fuun..."

Yuu opened his mouth to capture her tongue. *Buchu* - their lips met, making wet *picha picha* sounds during the fierce kiss. Meanwhile, Manami's right hand stroked his glans with enveloping fingers. Precum mixing with lotion created sticky *nicha nicha* sounds.

"Amuu... nku... haa, haa..."

As their lips parted, a string of drool stretched between them. Manami chased it with her tongue before slowly straddling Yuu. She sandwiched his cock between her thighs and began sumata.

"Ahh! That's... amazing, feels so good!"

"M-me too... haaaa. I'm supposed to be serving, yet I'm feeling this much... ah... haaann!"

Fully settled atop him, Manami rubbed her hips back and forth while nuzzling affectionately. Feeling her soft body against his skin while his cock rubbed against tender flesh made Yuu moan uncontrollably. His hands roamed her back and plump buttocks.

Where their genitals met, precum mixed with lotion and Manami's dripping love juice created constant *nucchu nucchu* lewd sounds.

"This is bad. I'll cum like this. I want to cum inside you, Manami-san!"

"Yes... I can't hold back either. I long to receive Yuu-sama's seed inside me."

Utterly entranced, Manami lifted her hips slightly while showering Yuu's face with kisses. Still kissing, she aligned his hot, hard cock with her vaginal entrance and gradually swallowed it.

*Zupupupu!*  
"“Nnnnngaaaah!””

Their lips remained locked as their genitals deeply connected. As Yuu's cock entered her, Manami's tongue writhed inside his mouth.

But when his cock thrust deep into her cervix, Manami screamed "Kyahii!" and reflexively arched back. Ignoring drool dripping onto his face, Yuu firmly gripped her fleshy buttocks and plunged into her depths.

"Shore... ah, ah, ah, ahhiiiiii! Ku... fuu... g'aaann!"  
"Wah! W-wait! If you squeeze that tight!"

Still arched back and trembling, Manami collapsed onto Yuu's chest. "I-I came... instantly. I'd forgotten... how intense it was... My body remembered... When Yuu-sama's cock hit deep inside, heat surged from my core..." Flushed and feverish, Manami kissed his chest lovingly.

"Ha, haha. Good. I made you cum first. Though I didn't do much." Truthfully, Yuu nearly came too but held back at the last moment.

"Weird question, but which felt better - your first time or this?"

"Eh..." Manami met his eyes briefly before looking away. "Th-that's a mean question."

"Ah, sorry."

Instead of apologizing, Yuu slipped his hands under her arms and lifted her for kisses. After multiple *chu chu chu* kisses, Manami smiled radiantly at him.

"I couldn't compare anyone... but sex with Yuu-sama will surely be a lifelong memory. If possible... I wish to receive your seed and bear a healthy child."

Yuu had no objections - he intended to creampie her thoroughly. Holding Manami's back and waist, he thrust upward.

"There!"  
"Ann!"

"I'll... fill you up... with a huge load!"  
"Hyaun!"

Unexpected trouble arose for Yuu, who normally thrusts vigorously. Unnoticed, lotion had dripped from the vinyl mat to the floor, making his feet slip. While the slippery skin-on-skin felt amazing, the lack of lower body leverage was problematic.

"Uun... can't move well like this."  
"Ah, um... I'm perfectly satisfied like this, but if Yuu-sama can't cum..."  
"No, it's fine. Just being inside you feels amazing even without moving."

Yuu smiled reassuringly. Holding each other tightly, they synchronized small hip movements - any big motion risked slipping out. Slow sex while deeply connected, like mollusks mating.

"Ahh... this feels surprisingly great."  
"Ye... yes... ah! Deep inside... nn, nn... staying connected... ahh, I'm... coming again..."  
"Manami-san! I-I feel great too!"  
"Nn, nn... hafuu, Yuu-sama... ann!"

Manami's tongue crept from his cheeks to jaw as if cherishing him. Their legs intertwined completely while hips kept moving relentlessly.

"Amu... lero julu... chupaa... g'ann! Mufu... g'un! G'uun! Ha, ha, ha, ahh! Yu, Yuu-shama... gah... shore rame, I, I, I'm cumming!"  
"M-me too! Ku!"

Holding each other tightly to avoid slipping apart, they raced toward climax together. Sensing her approaching orgasm heightened his own sensitivity.

"Aaah, ah, ah, ah... I've... never felt... anything this good! Hi, hi... I'm... cumming! Cumming! Gah! G'ann! Yuu-hyama! I'm... nn! C-cummingggggggggg!!"  
"I-I'm... guh... cumming! Cumming so much! Get pregnant! Auuugh!"

Discarding her dignified innkeeper persona, Manami became a pleasure-drowned female in complete disarray. Receiving Yuu's torrent of seed inside her womb sent orgasmic pleasure through her entire body. Clinging to Yuu, unable to move under the long ejaculation, she could only emit meaningless moans.

They learned that using lotion over nearly the entire body made cleanup troublesome. After thorough showering, Yuu and Manami moved to the main bath for a soak.

Now, Yuu relaxed against the bath edge. Manami sat between his spread legs with her back to him - essentially hugging from behind. The transparent water revealed her artistically curved white body over his shoulder. Even with legs extended, she didn't reach halfway across the spacious bath. In this position, Yuu's hands naturally found her breasts, which he kept gently kneading. Probably D or E cup - soft, palm-filling beauties he never tired of touching. While teenage bodies had their springy freshness, Manami's 30-something matured form was equally wonderful.

"Ah, ann! Yuu-sama really loves breasts. Nn... fuu... Sayaka-san was the same... Do men... ah... all love breasts? Hyan! Playing with nipples... I-I can feel it!"  
"Hmm, other men? At least I love all sizes. Yours are magnificent, Manami-san. *Chu*"

Kissing her neck repeatedly while pinching and kneading her nipples, Yuu met her request for a kiss. Though her lipstick was gone, he savored her healthy vermilion lips.

"Nn... fumuu... Um, since earlier... Yuu-sama's hard cock has been pressing against my back..."  
"Yeah, I want another round."  
"Ahh..."

One ejaculation was never enough for Yuu, and his libido felt especially heightened since last night - despite fucking his mother and sister until late. It seemed to calm during their shower. But seeing Manami's disheveled hair, then watching her gather her long wavy hair into a loose updo with a barrette, reignited his desire. For some reason, women styling their hair aroused him. After she secured it, Yuu embraced her from behind and they reentered the bath together.

"I believe Manpou no Yu is said to bless people with children?"  
"Yes. Legend says a childless couple visited, and the hot spring god appeared to teach them how to conceive. They returned home and soon conceived."

More like a conception god than a hot spring spirit, Yuu thought - but perfect timing.

"Then for good luck, shall we do it in the water this time?"  
"Eh...?"

Smiling, Yuu stood up while holding the confused Manami from behind and moved toward the window.

---

### Author's Afterword

After reading accounts by former soapland workers, I learned mat play with lotion is very slippery. Workers must support clients to prevent falls and injuries. Since you can't move normally on slippery mats, full intercourse rarely happens there (they wash off the lotion and move to bed for the main act). I wanted to write a soapland-like scenario in this world without male-oriented brothels, so I pushed through to the end.

※Corrected several odd points in the mat play description. May make further corrections.  
※Corrected protagonist's background: Previously had mat play experience at soapland → Actually no experience.

### Chapter Translation Notes
- Translated "マットプレイ" as "mat play" to preserve the specialized adult entertainment context
- Rendered "ちゅぱぁ" as "*chu*" for kissing sounds and "ぬっちゅぬっちゅ" as "*nucchu nucchu*" for wet friction sounds
- Translated "子種" as "seed" and "孕んで" as "get pregnant" per explicit terminology rules
- Kept "Yuu-sama" honorific throughout as per character relationship
- Preserved Japanese name order "Nishizawa Manami" consistently
- Translated "湯の神様" as "hot spring god" with cultural context implied
- Used "creampie" for "中出し" in translation notes while employing "cum inside" in main text for narrative flow