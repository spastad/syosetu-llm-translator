## 121. To the Hot Springs ⑧ ~A Little Trip~

Pan, pan, paan!

"Ah, oh, oh, aun! Yu, Yuu-sama! So, so rough! Ah, ah, if you...go that hard...ah! Haaaaaaaan! I'm, I'm cumming...I'm cumming!"

The sound of flesh slapping echoed through the large bath. But even louder than that, echoing with reverb, was Manami's moans. Gripping her narrow waist with both hands, Yuu kept thrusting his hips as if pouring out his boiling lust.

The wide rim of the bathtub was covered in smooth marble-like stone, but only the window side was lined with large rocks - each about the size of a crouching human - seemingly brought from the mountains. Perhaps to feel some natural ambiance. Though their surfaces were polished smooth to prevent accidental scratches.

Yuu had Manami grip one of these rocks with both hands as he took her from behind. The wide window over 2m high had frosted glass to prevent peeping. But wanting to enjoy the view, Yuu had requested a small opening. Thanks to the considerate design for male guests and absence of 3+ story buildings nearby, a magnificent view spread before them - the Arakawa River flowing alongside National Route 140 in front, and the Chichibu Mountains stretching to the right.

Taking in the majestic view while coupling in the bath's steam, the man slammed his rising lust into her fleshy buttocks while the woman writhed like mad, her white naked body twisting. Manami's vaginal walls lacked the tightness of a teenager's. But inside was sticky and soft, her folds writhing as if trying to milk the tip of the cock that had entered her for the first time in 17 years.

Thrusting while leaning forward, Yuu reached from her waist to firmly grasp her jiggling breasts. "Haah, haah, Manami-san, if it feels good, you can cum, okay?"

"Hah...nnngh...Yu, Yuu-sa...ma...ye...yes! I'm...cumming! I'm cumming! Ann! Ann! Aaaaaaaahhhhhh-I'm cummiiiiiiiiiiiiiiiiiiiiing!!!"

As if triggered by Yuu's voice, Manami threw her head back, arching her body sharply as she climaxed. Yuu gripped one breast firmly while supporting her waist with his other hand.

"Yu, Yuu-sama..." Having experienced countless climaxes since morning, Manami looked back with dazed eyes, seeking a kiss. Yuu pressed close and obliged, swirling his tongue against hers while now grinding his hips in circles.

***

After making Manami cum three times from behind, Yuu also came simultaneously, pouring the same amount of semen as before into her womb. Though Yuu felt he could go another round, considerable time had passed since entering the morning bath, so he decided to leave soon. After holding the limp Manami in the bath for a while, Yuu decided to get out.

"Oh crap!"

After parting from the satisfied, smiling Manami, Yuu remembered while changing in the dressing room that he'd kept Touko waiting. He'd said 30 minutes but checking the clock revealed over an hour had passed. Having had sex twice with Manami's service, it was unavoidable.

Entering the still-empty lounge, he found Touko curled up on the sofa, breathing softly in sleep - perhaps tired from waiting or sleep-deprived from last night. Or both.

"Hmm, what to do... Got it!"

Feeling guilty, Yuu crouched before the sleeping Touko's sofa. Since bath amenities were provided, his hands were free. He reached behind to lift her for a piggyback ride - her small frame made this easy.

Carrying Touko through the corridor, he encountered several women heading for the morning bath. Recognizing Yuu, they all froze in surprise - likely unused to seeing a man carrying a woman. Unaware of this, Yuu just felt embarrassed and hurried to their room.

"Shi~no~bu~"

The first to greet him upon entering their detached room was Kanako. Having noticed Yuu and Touko missing, she'd contacted the front desk and learned they were at the bathhouse, and was about to go there.

Yuu recalled that protection officers called each other by codenames to avoid revealing identities - Kanako was "Neki" and Touko "Shinobu".

"Wait! It's my fault for taking so long in the bath - she must've fallen asleep waiting!"  
"Eh...b-but still..."  
As Kanako moved to peel Touko off, Yuu explained. Touko, awakened by their voices, made a sleepy "Huh?" sound.

"Sniff, sniff. What wonderful skin texture and scent...nnn?"  
"Good morning. Finally awake, huh?"  
"Wha, what...eh? Ehhh? Heeeeeeeeeeh!?"  
Meeting Yuu's eyes as he turned, Touko finally realized her situation and let out an unusually shrill cry - promptly earning a "Quiet!" and knuckle rub from Kanako that left her teary-eyed.

Meanwhile, Martina had been genuinely worried upon waking to find Yuu gone, while Elena's disappointment at missing last night's continuation was obvious. For Yuu, having had intense morning sex with proprietress Manami left him refreshed.

Perfect timing - they ordered breakfast from the front desk, served about 20 minutes later. An extravagant spread: white rice, miso soup, seasoned seaweed, tsukudani, natto, pickles, onsen egg, grated yam, chilled tofu, salt-grilled sweetfish, boiled komatsuna, simmered mountain vegetables... Too lavish for breakfast.

Among the serving maids came Manami herself in a stunning kimono - white with vibrant red and pink floral patterns from sleeves to hem, makeup perfectly done. Her transformation from bathhouse dishevelment was astounding.

"Please enjoy at your leisure."  
As they withdrew after setting the meal, Manami gave Yuu a sidelong glance, placing a hand on her lower abdomen as she bowed. Yuu smiled and waved her off.

Travel mornings strangely boost appetite. Yuu, having ejaculated multiple times since last night, devoured side dishes while getting rice refills. Even light-eating Elena ate heartily - both from last night's exertion and the delicious food.

***

"The baths were great, but the food was amazing too!"  
"The staff training was excellent."  
"Let's stay here again!"

At checkout, Manami and available maids saw them off. Yuu waved back with a full smile. The considerate male-friendly inn left a wonderful impression - Yuu genuinely wanted to return, partly to see Manami again.

"Well...if I get company discount tickets again..."  
"Ah right. Can't come so easily."  
Though geographically close, male-friendly accommodations were expensive. While Yuu had no tuition and generous allowances, Elena's upcoming university expenses weighed on the Hirose finances. "It's okay! Once a year is fine. I earn quite well too," Martina reassured the worried Yuu with a flexing pose.

***

Chichibu sightseeing mostly involved nature activities. But considering crowds and safety, male-accessible spots were limited to well-secured locations, especially with afternoon rain forecast. Meeting two backup protection officers from the local branch, they first headed to nearby Mount Hodo.

Though under 500m, the steep path prompted ropeway use. While plum blossoms would've been ideal in early spring, early summer brought full greenery. At the summit, they visited the shrine. Weekend crowds included elderly groups and families heading to the nearby zoo. Groups surrounding a male like Yuu were rare.

"Hey! Let's buy amulets!"  
"Ah, good idea."  
Flanked by protection officers and sandwiched between Martina and Elena, Yuu went to the shrine's shop. Today's casual T-shirt/jeans outfit featured the safari hat and sunglasses from Risa and Emi's birthday gift. Still, the young male attracted attention from women of all ages.

Martina and Elena eagerly selected amulets for him - disaster prevention from Elena, household safety from Martina. Yuu didn't notice Elena secretly choosing a safe childbirth amulet.

After parking lot departure, they visited Chichibu Meisenkan - exhibiting valuable folk materials including textiles.

"Wow~ beautiful!"  
"My, indeed."  
Surrounded by mountains unsuitable for rice, Chichibu thrived on sericulture. Until early Kobun (Showa) era when kimonos were common, textiles were produced as everyday wear besides formal attire, making sericulture and weaving core industries. Displays showed dyeing/weaving processes alongside colorful fabrics from subdued to flashy.

"Lovely, but wouldn't suit me..."  
Half-Japanese Martina preferred vivid Latin-style colors. Yuu recalled foreigners loving Japanese culture in his world looking surprisingly good in kimonos.

"Not true. It'd suit you, Mom. Your yukata looked great at the inn. Your figure would carry it well."  
"What about me?"  
"Hmm, Sis is too slim. Your height suits Western dresses better than kimono. Mom's curves fit better."  
"R-really? I'm happy!"  
"Oof!?"  
Beaming, Martina suddenly hugged Yuu. Her ripe fruit-like breasts pressed against him, and her low-cut dress revealed deep cleavage right below. Memories of kneading them and ejaculating inside her last night flooded back, blood rushing to his groin.

"M-Mom...okay, I get it..."  
Pulling away not just from near-erection but surrounding attention.

"Getting hugged without rejection by such a cute boy!"  
"Kyaa! So jealous!"  
With only one male present after an elderly group left, and having removed hat/sunglasses indoors, Yuu became the envy magnet. Kanako's team tightened formation, glaring to disperse encroaching women.

Lunch followed at a pre-checked popular soba shop featuring walnut soba. Traditional coarse-ground buckwheat offered firm texture, walnut-infused broth fragrant and rich.

Walking to Chichibu Jibasan Center adjacent to Chichibu Station - souvenir hunting. The imposing 5-story building housed local products, tourist info, restaurants, cafe, railway exhibits, specialty displays, and public facilities.

Shopping transformed the women. Accompanying them required patience, and entering crowded spaces with Yuu was reckless. Entrusting school souvenirs to family, Yuu relaxed at a cafe with protection officers.

"Phew. After shopping, just heading back? Fun times fly."  
"Hehe. That's how it goes."  
Sighing after black coffee, Yuu saw Kanako smile opposite. The partitioned cafe reserved 1/3 space for males with protection.

"Knowing Yuu-sama enjoyed it makes our duty worthwhile."  
"Mhm. Mhm."  
The backup officers (twenties and thirties) nodded. Among males they'd guarded, Yuu's exceptionally good attitude made work pleasant. Conversely, Yuu thanked them for blocking aggressive women during transit.

"This trip's enjoyment is thanks to Kanako-san and team. Thank you both for coming."  
Yuu stood to extend hands to the adjacent table.  
"N-no need..."  
Unused to male gratitude, they hesitated until Kanako nodded. Timidly offering hands:  
"Hyaa!"  
Yuu firmly shook them, startling but delighting them with young male touch.

Women's shopping took time. After coffee refills and 30 more minutes chatting, Martina and Elena arrived exhausted from crowd-navigating with armfuls of purchases. Finally departing Jibasan Center around 3pm.

During return drive, Yuu recalled memories from 20 years prior - visiting Chichibu during night festival season. Four male student friends wandering excitedly.

Compared then, current glamour came with restrictions - unable to spontaneously explore due to women surrounding him. Travel shame being what it is, women actually approached aggressively - another effect of female surplus. If the 1:30 ratio improved to 1:10 or 1:5, couples and families with sons might sightsee more freely. His father, knowing a balanced world, likely aimed for this.

In this world, men are desired and cherished just for being male. But carelessness invites assault danger. The gender dynamic felt warped. Lately, Yuu understood his late father's aspirations. Health Ministry official Inui Rumiko said Japan's gender ratio was widening. He worked hard with half-sisters hoping his inherited DNA held solutions. Beyond that, what could he do? He needed to understand this world better.

Perhaps overexerted from daytime fun? Martina and Elena dozed off on Yuu's shoulders. Watching scenery, Yuu pondered deeply.

***

◇ ◆ ◇ ◆ ◇ ◆

***

Below is an afterword.

Next spring, after cherry blossoms scattered leaving leafy trees, Manami gave birth after difficult all-night labor - miraculously, boy-girl twins. With low male birth rates already, twins of both genders were rarer. News excited not just Manami's Nishizawa family but Shiromine-kaku and Manpou no Yu staff, even making local papers as proof of the hot spring's child-blessing legend.

The boy was named Yuuma, girl Mayu - reversible readings for twins. The shared "yuu" sound held meaning only Manami knew.

On June 30 the following year, revisiting Shiromine-kaku, Yuu reportedly rejoiced meeting Manami and twins. Considerate of Yuu's same-age fiancée, Manami settled for paternity acknowledgment alone.

Years later, 20-year-old Mayu succeeded as fifth-generation proprietress. University business-major Yuuma married five wives while studying, later joining Manpou no Yu management including Shiromine-kaku. He excelled promoting plans for a large leisure complex beyond hot springs.

***

### Author's Afterword

First afterword in a while. Wrote casually but hope by the twins' adulthood, gender dynamics improve.  


### Chapter Translation Notes
- Translated "パンッ、パンッ、パァン" as "Pan, pan, paan!" for visceral impact
- Preserved "-sama" honorific in "祐さま" → "Yuu-sama"
- Translated explicit sexual terminology literally: "膣内" → "vaginal walls", "男性器" → "cock"
- Maintained Japanese name order: "西澤満菜美" → "Nishizawa Manami"
- Transliterated sound effects: "ぷるんぷるん" → "jiggling", "れろれろ" → "swirling his tongue"
- Italicized internal monologue: *(This is concerning.)* format not used here but applied where applicable
- Translated culturally specific terms: "お守り" → "amulets", "くるみそば" → "walnut soba"
- Preserved specialized terms: "男護院" → "Male Protection Facility" (from Fixed Terms)
- Formatted simultaneous dialogue with double quotes when indicated
- Translated "後日談" as "afterword" for narrative continuity