## 122. Private Lesson ① ~With Love and Selfishness, I Won't Hurt You~

### Author's Preface

To be honest, "Private Lesson" evokes more eroticism than "Personal Tutoring". It sounds like an AV title.

Apparently, there was actually an erotic film with that exact title (the remake starred a member of a famous disbanded idol group...).

---

"One, two! One, two!"

"Hah... hah... shh!"

"Too weak! Harder! Like you're trying to punch through the chin!"

"Kuh... da... ryah!"

"Come on, use your legs more!"

"Nn... hah!"

This was the underground training room at MALSOK's Saitama Training Center.

Standing on the low-rebound mat was Kitamura Kanako, wearing a T-shirt and spats, with mitts on both hands and supports below her knees. She was in the middle of sparring with Hirose Yuu.

Yuu had started learning self-defense techniques from protection officers a month ago. Roughly once a week, initially planned for one hour, but since that wasn't enough, they extended it to two hours when time allowed.

Upon entering the training room, they first did thorough warm-up exercises. After loosening up, they did 20-30 minutes of muscle training under the guidance of the two instructors. After practicing martial arts including self-defense techniques, they did actual sparring: three sets of two minutes each. Now, they had increased it to five sets.

When faced with violence, an amateur won't be able to strike as intended. That's the difference from martial artists who practice fighting people regularly. Therefore, the only way is to get the body accustomed so that it can strike when necessary.

That said, Yuu had an ingrained resistance to hitting women. After repeated sparring sessions with Kanako and Kujira Touko, he had become able to land decent blows to the body and legs, but he still couldn't muster full force when striking the face.

If he were a man who had lived in this world from the start, he would probably fight back with full force if attacked by a woman—assuming he was in a condition to do so. However, having lived for 40 years in a reality where men must not lay hands on women and would be sued for domestic violence, it was difficult for Yuu. Even when he realized his wife had betrayed him, he couldn't even raise a hand. Even against a detestable opponent, he might not be able to land a serious blow if it were a woman. If the attack was sexual, he might even welcome it—depending on the opponent, of course.

Beep beep beep! The electronic sound signaled the end of the fifth round.

Yuu had been striking the mitt held near the chin with his gloved fist, but when Kanako called out, "Okay, that's it!" he seemed to lose tension. Fatigue seemed to have set in his legs, and he nearly collapsed onto Kanako.

Kanako kept her left hand in the mitt and tried to support Yuu's body with her right hand, but unable to grip, she ended up catching his upper body with her ample breasts and embracing his back.

"Hah, hah... Sorry... Kanako-san."

"N-no... Good work. Your movements have improved quite a bit. Though your strikes near the face are still weak."

"Hmm... For example, even if Kanako-san attacked me, I might not be able to punch your face for real..."

"That's a problem."

Kanako's eyebrows formed a troubled "八" shape as she looked up at Yuu. Being gentle to all women was Yuu's virtue, but it was worrying that he couldn't resist seriously when attacked by a malicious opponent. Additionally, having finished sparring, she realized she was pressing her body against Yuu, who was drenched in sweat, and hastily pulled away.

Yuu was wearing a T-shirt over a tank top, but due to the sweat, his nipples were visibly erect. Kanako averted her eyes in a fluster. The sight of his clothes clinging tightly to his body, exuding sensuality, and the body odor of a young man—an ordinary woman might have gotten aroused, but as a protection officer, she managed to hold back. However, Kanako consciously separated her sexual desires by superimposing the image of a much younger brother onto Yuu, seeing him as someone to protect.

Of course, Kanako herself was also transparently wet with sweat, and Yuu had been subtly observing her chest and lower abdomen.

"Yuu-sama, hydrate."

"Ah, thank you."

"Um, let's take a ten-minute break, then move to the final exercise."

Touko, acting like a manager, handed Yuu a sports drink container. Having put some distance between them, Kanako regained her composure and made the announcement.

After a ten-minute break, they moved to the judo hall with tatami mats. Usually, next would be sparring with Touko. So far, they had learned techniques to evade attackers and counterattack. But unusually, Kanako seemed hesitant to speak. Conversely, Touko's usual expressionless face had relaxed, her mouth corners slackening.

After a moment's hesitation, Kanako spoke.

"Th...then, today we'll practice how to handle being pinned down by a woman."

"...! Yes."

*(It's finally here!)*

Yuu responded with a calm demeanor, not showing his inner joy.

"The principle is to escape before it happens or call for help to be rescued. But even if you are pinned down and face a chastity crisis, learning how to resist won't be useless."

"Yes."

If Kanako or Touko were driven by lust and pinned him down, he would probably accept it. But since he was in the position of seeking instruction, Yuu decided to nod obediently. It wasn't impossible that he might be pinned down by someone he didn't want to have sex with in the future.

Then Touko, facing Yuu, spoke.

"When pinned down, escape methods can reference judo ground techniques. First, let me and Nee-san demonstrate."

Touko rolled onto her back, and Kanako pinned her from the side, covering her right arm. It was a basic kesa-gatame (scarf hold). The large-framed Kanako had her upper body on top and her arm tightly around Touko's neck, choking her. Though both legs were free, if Yuu were pinned like this, he would never escape.

"Now, how to reverse this. Normally, you use your legs."

Touko's right leg moved to hook Kanako's leg, but Kanako wriggled away, changing direction. Touko used her free left hand to push and pull Kanako's upper body, but it didn't budge. It seemed all was lost.

After a brief pause, Touko seemed to catch her breath.

"Huh?"

"Nn!"

The movement was too fast for Yuu to see clearly. Like a spring uncoiling, in an instant, Touko raised both legs and hooked them around Kanako's left leg and armpit. Simultaneously, she used her left hand to open Kanako's body.

"Kuh!"

In the blink of an eye, the position Kanako had secured was broken. Still, Kanako tried not to release Touko's right arm, but Touko had already pulled Kanako's collar from behind and started choking her neck. Moreover, Touko used both legs to dig into Kanako's right arm and abdomen. At that point, Touko's right arm was almost free, and the positions were completely reversed.

"Nfufu."

"Th-that's enough."

Kanako looked thoroughly beaten and in pain, while Touko looked triumphant. But Yuu thought: even if he tried to imitate Touko, he couldn't. Unlike Kanako, who was a good teacher, Touko was a natural talent but not very good at teaching. She would show techniques by saying, "Like this, just do this," but for a beginner like Yuu, the hurdle was too high. Basic techniques found in manuals were one thing, but the moves she performed effortlessly despite the size difference were difficult to imitate.

They reset, and this time they practiced a specific pattern. With Touko lying on her back, Kanako straddled her from the front, pinning one hand and burying her face in Touko's neck—similar to judo's tate-shiho-gatame (vertical four-corner hold). It was a position where their genitals aligned, close to a state where the one on top intended to assault.

If the woman was strong, she might restrain both of the man's hands with one hand, but usually, she would leave one hand free, they said.

To escape from here, the reversal of tate-shiho-gatame was still a reference. They taught that it was important to use anything available—hooking legs, pushing the opponent's head with the free elbow—to disrupt the opponent's balance.

"Then... shall we try it... practically?"

"Let's try it!"

Kanako's questioning tone probably meant she thought it would be too much to have Yuu in a position of assaulting her, even for practice. But for Yuu, it was exactly what he wanted, and he agreed immediately.

"...Um, I've heard what's taught in self-defense classes for men: it's okay to scratch with nails, pinch, anything to make the opponent flinch. At this point, it's okay to injure them a little."

"Ehh..."

Touko pouted her lips, but when Yuu said, "I'll try not to hurt the girls' skin," she immediately broke into a smile.

"I'm gonna attack you—rawr!"

"Um... kyaa, stop!"

With both delivering poorly acted, wooden lines, Yuu pretended to be knocked onto his back, and Touko covered him.

"Mufu."

"Ugh..."

Yuu tried to shake off his left hand as it was about to be grabbed, but his right hand (his dominant hand) and neck were pinned. Moreover, Touko, with her lower abdomen pressed against his crotch, had firmly applied her weight and used her legs to clamp from the outside, skillfully hooking her toes behind his knees. Despite being small and light, she pinned him down more effectively than expected, and he couldn't move.

"Come on, Yuu-sama, do your best. If this continues, you'll be done for?"

"Kuu... I'll try."

Yuu tried to resist frantically. But his legs being immobilized was painful. He couldn't move his legs, pinned down with surprising strength from that small body. His only free hand was his left, but with Touko burrowing her head into his shoulder and chest, he couldn't exert force; pushing or pulling had no effect.

After about two minutes, Kanako called out.

"U-um, if it's impossible, tap the tatami twice."

"Not yet... I'll keep trying!"

By then, Touko's ragged breathing was noticeable. She too was experiencing this for the first time—pinning Yuu down like this—and feeling his sweat and body heat made her heartbeat quicken. Being pressed against Touko wasn't unpleasant, but escaping seemed difficult.

Yuu was about to give up when he remembered Kanako's words: "Anything to make the opponent flinch." This wasn't a judo match. To reverse the position, anything goes. And the opponent wasn't a man but a girl.

*(Alright!)*

Naturally curling his lips, Yuu turned his face toward Touko. Lifting his face as much as possible, he brought his mouth close to the ear peeking through her bob-cut hair.

"Fuu!"

"Hyan!"

Touko let out a cute scream and lifted her face. Simultaneously, Yuu's left hand, which had been reaching toward her butt, lifted the hem of her judo uniform and invaded inside. He knew she wore only a plain sports bra underneath. Sliding his hand along her sweat-dampened back, he found a gap at the waistband and tickled her armpit.

"Hih... nya? Hahyahya!"

Feeling Touko's body go limp, Yuu launched a counterattack.

"Take this!"

"Ah!?"

Holding Touko's body from below, he rolled sideways. He successfully flipped their positions. Not only that, but he firmly pinned both of Touko's hands and pressed down on her.

"Now it's my turn to attack you, Touko-san."

Grinning, Yuu stared at Touko's face from close range and rubbed his hardening crotch against her lower abdomen.

Touko's eyes, usually half-closed, were wide open, her round black pupils reflecting Yuu's face. Her face was already bright red.

"Ah... Yuu... sama..."

Touko seemed to resign herself and relaxed. Yuu took her palm—a lover's hold. And Yuu's eyes, glinting with beastly desire, stared at her chest, now exposed by the wide-open collar. Though modestly sized, the white sports bra cups were clearly visible, and he could see her chest rising and falling slightly.

"Fuaaa... ah... nn!"

As Yuu latched onto Touko's chest, a sound she had never made before escaped her lips.

"W-wait, wait a minute!"

Kanako, flustered by the atmosphere that seemed about to turn into a sexual encounter, raised her voice.

Kanako and Touko entered the shower room adjacent to the underground training area and each went into their own booth to shower. Kanako washed her body in silence, but after the water stopped in the next booth, she heard the pattering footsteps. Thinking Touko was leaving, she then heard a creak as her own booth door opened. There stood Touko, dripping water from her head.

"Wh-what is it?"

"Nee-san... When I think about Yuu-sama, the throbbing deep inside won't stop..."

"Ugh..."

Even for professional protection officers who suppress sexual desires, they are still human. Guarding Yuu—with his exceptional looks, gentle and considerate personality—brought great inner joy, but they tried not to show it. Until now, skin contact had been limited to hand-holding or head/back patting, so they could endure. But since Yuu started learning self-defense, physical contact had escalated.

Having a young man like Yuu nearby and constantly touching his body—an ordinary woman would have long been driven by lust and lost control. Still, the two had persevered, not just for their jobs but to avoid betraying the trust of the Hirose family.

Even Touko, a pervert whose mind swirled with fantasies about men, only leaked such thoughts to close confidants like Kanako. She never made the first move. Originally, when interacting with men, she maintained an expressionless, unfriendly demeanor. Even with Yuu, she behaved similarly at first, but over time, she realized she was changing. When talking alone with Yuu or having her head patted, her face would burn hot, and her heart would pound uncontrollably. Though she knew it was wrong, she wished for more contact.

Especially during today's ground techniques, she was reminded of sexual acts, and even Touko couldn't switch off and was still affected. In such situations, protection officers typically comfort themselves alone or with a trusted intimate partner.

Kanako gently embraced Touko, who had come in with her body chilled from cooling off under the water.

"Uu... Nee-san..."

"Yeah, yeah. I understand how you feel."

Touko buried her face in Kanako's ample breasts, and they held each other for a while. Looking up, Touko's face was childishly innocent, her eyes moist. Kanako stroked Touko's wet head and kissed her.

"Nn."

"Nfufu... ah... nn..."

Their embrace continued, rocking each other as if enjoying the sensation of the other's body from the front. Being naked and holding each other, feeling skin directly, felt good. As they kissed repeatedly, changing angles, Kanako and Touko began to get aroused. Naturally, their lips parted, and their tongues touched.

"Amu... churu, nn, nn, nchu... faa, Nee-san."

"Nchu, chu, chu, lero, leroo... haaaa... Shinobu."

At 184 cm, Kanako and 155 cm Touko looked like an adult and a child. But both were grown women, and now they began to release their desires and seek each other. First, Kanako's hand stroked Touko's small buttocks and then invaded her private area.

"Shinobu... you're this wet? Do you like Yuu-sama that much...?"

"Faaaaaaah! B-because... I'm falling more and more for Yuu-sama... ah, ah! Nee-san, you too!"

Touko's right hand touched Kanako's private area from the front and confirmed it was soaked not with shower water but with sticky love juices.

"Nnnnnnnnnn~~~~! Ah, I'm making noise!"

"Nn, nfu... i-it's okay. We have it reserved this morning..."

"Oh, right..."

"So, Nee-san."

"Shinobu."

With moist eyes, they pressed their lips together and began to play with each other's vaginas, making squelching sounds. So engrossed in comforting each other, they completely forgot that the very person they were talking about was nearby.

### Chapter Translation Notes
- Translated "プライベート・レッスン" as "Private Lesson" to convey the intended erotic nuance
- Preserved Japanese honorifics (-san) and used fixed character names (Kitamura Kanako, Kujira Touko)
- Transliterated sound effects: "ピピピピ" → "beep beep beep", "がおー" → "rawr", "ひゃん" → "hyan"
- Translated explicit terms directly: "秘所" → "private area", "膣口" → "vagina"
- Maintained original name order for Japanese names (e.g., Kitamura Kanako)
- For intimate scene between Kanako and Touko, translated descriptions literally without euphemisms per style guide
- New dialogue lines start on new paragraphs except when preceded by attribution
- Internal monologues italicized and enclosed in asterisks (e.g., *(It's finally here!)*)