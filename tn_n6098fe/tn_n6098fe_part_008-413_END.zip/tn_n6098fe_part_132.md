## 123. Private Lesson ② ~I Will Always Love You~

### Author's Preface

Before I knew it, the overall rating reached 30,000 points and page views exceeded 7.5 million.

This is the first time I've achieved such numbers, and I'm trembling with emotion.

Having so many people read my work and share their evaluations and impressions is truly encouraging.

The story continues, so I appreciate your continued support.

---

"You're taking so long."

Hirose Yuu muttered, bored out of his mind.

The facilities attached to the underground training room weren't gender-segregated.

Therefore, Yuu had used the shower and changing room first and was now waiting after changing.

He knew women tended to take longer in such situations.

But this was taking unusually long compared to usual.

"You're not still showering, are you?"

Yuu stood up and knocked on the changing room door.

There was no response.  
"What should I do?"

In this world where gender values were reversed, Yuu wouldn't be blamed for seeing Kitamura Kanako and Kujira Touko changing. Conversely, peeking at a man changing would be a crime.

After some hesitation, Yuu gripped the doorknob and slowly opened the door to peek inside.  
The room remained empty, just as when he'd left.

"Then that means..."

His gaze turned to the door at the back.

That should lead to the shower room.

Yuu slowly walked toward it.

He considered knocking to ask how much longer they'd be.

But halfway there, Yuu stopped.

The wall was thin despite being waterproofed, and voices leaked through.

"Th-this voice...?"

To Yuu, reborn in this world, it was a very familiar voice.

He pressed his ear flat against the wall.

He could hear two women's moans.

It could only be Kanako and Touko, but hearing only fragments through the wall was frustrating.

*Hmm... I need to get closer to tell.*

Yuu stared at the door before him.

Hearing intimate acquaintances moan for the first time was more exciting than hearing strangers.

Unable to resist the temptation, he stepped forward, gripped the doorknob, and slowly turned it.

He opened a small crack to peek, but couldn't see where they were from there.

But the moans became clearer than before.

Kanako's voice was recognizable - slightly restrained and husky as usual.

The other voice, high-pitched and cute like a young girl's, must be Touko's.

Unable to contain his curiosity, Yuu lowered his posture and slipped into the room.

Inside, a central pathway had six shower booths on each side.

The dark green linoleum floor sloped slightly from both walls toward the center, channeling water toward the drain.

Crouching low, Yuu advanced near the pathway and realized the voices came from the left side - facing the changing room.

"Ah, ah, ahhhh! Nee-ki... th-there! Fuaaaaah, I-I can't! I'm, I'm cumming!"  
"Haah, haah, you're adorable... Shinobu... nn, ahn! I-I'm also... kuuun! D-don't finger me so hard!"  
"Nee-ki... l-let's... together..."  
"Ah, ahh, together..."

Kanako and Touko kissed deeply, tongues exploring each other's mouths while vigorously pumping fingers in and out of each other's vaginas with wet "ju-bo ju-bo" sounds.

"Juru-chu-paa... aauu... Ne... kii... mufuu... nrero-churuu... afu, aah! Aahn! Nhyaa!?"  
"Vaa... aaahn... Shi... No... unm... rerorero-juruuuu... haah... vaan! Hyame! Aah! Aah! Iih!"  
"I-I'm cumming!"  
"Me too! I'm cumming!"  
"Aaaaaaahhhhhhhhhh!!!"

They seemed to climax almost simultaneously. Unlike male orgasms which are intense but brief, female orgasms last longer.

After climaxing, they remained embraced, lost in the afterglow.

So they didn't notice immediately.

The booth door only concealed from shoulders to knees - standing in front revealed the interior.

Unnoticed, Yuu had been watching them embrace.

Only when the door creaked open did they finally notice.

"Ehh... Eeeeeeeeeehhhhhhhh?!"

Kanako and Touko screamed in perfect unison.

"You weren't coming out, so I thought..."  
"Auuhh"  
"U-um... this is... s-sorry"

They separated their bodies, but the narrow shower booth made it almost meaningless. Instead, they averted their eyes.

Not from shame at being seen naked, but from guilt over neglecting Yuu.

But Yuu had no intention of scolding them.

He raked his eyes over their naked bodies from head to toe.

His gaze was filled with lust.

Kanako's broad shoulders and imposing, ample breasts that had captivated him countless times.

Her perfectly defined abs and artistic curve from cinched waist to hips.

In a way, she boasted flawless proportions.

Though smaller than Kanako's, Touko's breasts (C... no, sadly B-cup) and pert upturned bottom were unexpectedly feminine beneath her usual suits and earlier judo uniform.

Her taut, athletic body resembled an agile feline.

Seeing their defenseless forms for the first time only heightened Yuu's excitement.

He smiled and spoke.

"It's unfair for just you two to have fun. Let me join."  
"Huh?"  
"What did you say?"  
"So I want to join too."

Kanako and Touko stared wide-eyed, mouths agape in disbelief at Yuu's words.

Yuu approached and embraced them both, not caring that his clothes got wet.

---

Moving to the changing room seemed better since three people in a single shower booth was too cramped.

Kanako and Touko remained silent, unsure how to react, but when Yuu casually removed his T-shirt upon entering, they were startled.

"Ah, um, Yuu-sama...? Wh-what are you..."  
"Hm? I thought I'd get naked too."  
"Whoa!"

When Yuu took off his jeans, Touko gasped.

*I shouldn't look... but I want to.*

Torn between conflicting thoughts, Touko covered her eyes with both hands but peeked through her fingers. Her inner pervert was emerging.

Standing before Kanako and Touko leaning against lockers, Yuu removed his jeans.

Then he sat on the bench in the changing room's center.  
"Ahh..."  
"Ohh"

Kanako sighed, cheeks flushed as she admired Yuu's toned upper body.

Touko, instinctively focused on Yuu's crotch, saw it tenting his underwear. Her subdued desire reignited.

Yuu hesitated not at all before removing his underwear.

"See, now we're the same. Hey, come here."  
"...!"

Yuu called out, but they remained frozen.

Seeing Yuu's fully erect manhood left them speechless and rooted in place.

As trained protection officers, they wouldn't assault Yuu just because he was naked before them.

However, Touko's gaze grew increasingly lustful as she stared at Yuu's cock.

She recalled feeling its hardness during their earlier grappling.

Unconsciously rubbing her thighs together, she began breathing heavily.

*(This is bad)*

Seeing Touko's state, Kanako regained composure and considered how to stop her partner.

Impatient with their hesitation, Yuu stood and suddenly embraced them both.

"Fwah!?"  
"Y-Yuu-sama!?"  
"Kitamura-san, Kujira-san, standing is awkward. Let's sit there.  
Then hear me out."  
"Y-yes"

Led by the hand, Kanako and Touko sat flanking Yuu on the bench.

Yuu wrapped his arms around their waists, pressing their naked bodies tightly against him.

Kanako desperately tried to calm herself, cheeks crimson and eyes darting.

Even with Yuu's face so close, she couldn't meet his eyes. Looking down revealed his erect cock, making her hastily look away.

Touko seemed happier, resting her head on his shoulder and enjoying his warmth.

Smiling at both, Yuu slowly spoke.

"Since becoming my dedicated protection officers, you've always accompanied me outside. I've really relied on you. You've watched over me 24/7 at home too. I'm truly grateful."  
"Th-that's our job."  
"Even so, I'm happy to always have a beauty like Kitamura-san and a cutie like Kujira-san with me."  
"Eh..."  
"Cu... cute?"  
"Yeah"

When Yuu stroked Touko's damp hair with his right hand, she narrowed her eyes contentedly.

"To me, Kitamura-san is a reliable big sister, and Kujira-san feels like a little sister despite being older."

While stroking Touko's head, Yuu rested his head on Kanako's shoulder. His left hand reached around her cinched waist.

"Hauu!"

Yuu's affection and "big sister" made Kanako's heart race.

"Haa, haa, Yuu... sama"  
"Fufu, it's okay, touch me."  
"U... un!"

With Yuu's permission, Touko happily stroked his thigh with her right hand while her left explored his shoulder and back.

She moved her hands as if carefully examining muscle definition and bone structure.

Her slackened mouth made her look like a molester to observers.

"Kitamura-san, don't hold back either."  
"B-but..."

*'Must not touch protected males without reason.  
Exceptions: emergencies or when requested.'*

Kanako recalled the protection officer's code.

Even officers were women.

Falling for a handsome man like Yuu wasn't surprising.

But expressing affection was strictly forbidden - the protector-protected relationship was one-sided.

After past scandals where "protection officers" assaulted males, strict rules were enforced. The exemplary Kanako maintained boundaries despite Yuu's familiarity.

Just as she resolved to refuse despite his invitation, Yuu's left hand grabbed hers and pulled it toward his abdomen.

"Ah"  
"Thanks to your training, I think my body's getting toned."  
"Y-yes... but still..."  
"You dislike touching my body?"  
"That's not..."

Seeing Yuu's pout made Kanako feel guilty.

Her habit of seeing her beloved brother in him shifted - touching him now felt not fraternal but sexual, making her lower abdomen throb.

Her admiration for Yuu and maternal feelings toward younger men threatened to overwhelm her reason.

"Ahaa... Yuu-sama..."

When Touko rubbed her head against his shoulder, Yuu turned toward her.

Their lips accidentally brushed.

"Ehehe... I kissed Yuu-sama"

Touko smiled with childlike innocence she never normally showed.

"Touko-chan, you're adorable. More."  
"Nn"

Watching them kiss repeatedly made Kanako feel "beaten to it" for the first time, confusing her.

Below her downcast eyes was Yuu's dewy smooth skin.

She imagined his boyish scent rising from it, shattering her composure.

She realized Yuu was staring intently at her.

Her gaze fixed on his lips as hunger welled within.

"Yu, Yuu-sama..."

Kanako looked down, ashamed of speaking out.

But Yuu leaned in and voiced his desire directly.

"I want to kiss Kitamura-san too."  
"...! I, I-I... want to too"  
"Great. Same here."

Seeing Yuu's happy smile, warmth overflowed in Kanako's heart.

She realized how deeply she adored Yuu.

Drawn together, they kissed.

"Nnnn!"

Instinctively, Kanako wrapped her right arm around his back and gripped his hand with her left.

---

After repeatedly kissing Touko on the right with "chupa chupa" sounds, Yuu turned left to kiss Kanako deeply, changing angles repeatedly.

Yuu stroked their drying hair and backs while Kanako and Touko lovingly caressed his back and chest.

After three kissing exchanges, Yuu parted Touko's lips with his tongue.

"Uwa!?"

Touko looked momentarily surprised but accepted Yuu with half-lidded pleasure.

"! Nmuah... nn, churuu... reero, reroo, mufuu... Yuu... hyama... naa! Fafuu..."

When their lips slowly separated, a string of saliva stretched between their tongues.

Unable to contain her rising emotions, Touko rested her head on Yuu's shoulder, cheeks pink.

Yuu turned to Kanako.

"Kitamura-san, open your mouth and stick out your tongue."  
"Fai"

Kanako obeyed dazedly.

Yuu felt thrilling lust seeing the red tongue peeking shyly from her flushed face.

Her ample breasts pressing against his chest felt unbearably good.

Yuu extended his tongue to touch tips with hers.

"Afue"

Kanako gasped emotionally and tightened her embrace.

Like two creatures seeking each other, their tongues increased contact. When their lips closed, they actively intertwined.

"Nnaaaah... nn, reero-churu! Nn, fuu... muwa... aan! Ahuu... yu... u... samaah... an... uhuu... nn, nn, nmu!"

Kanako's reason neared collapse as excitement overwhelmed her. Unconsciously, she pressed her body against Yuu.

Sandwiched naked between them while constantly kissing, Yuu's excitement only intensified.

Naturally, he wanted to advance to the next stage.

"Hey, Kitamura-san, Touko-chan"  
"Ye... s..."  
"Fe?"

Though Touko was called "-chan" for the first time by non-family, she accepted it naturally from Yuu. Rather, she was delighted.

"Like this... I want to have sex with both of you."  
"...!"  
"Nn... If Yuu-sama will have me, nothing could be more honorable. My body's been burning, aching, wanting you unbearably since earlier."

Hearing Touko's clear declaration, Kanako felt envy.

But when Yuu turned to her, she knew she couldn't refuse or evade.

"Kitamura-san?"  
"I... I also... want to... with Yuu-sama..."  
"Thank you"

When Yuu smiled and kissed her again, Kanako felt feminine joy welling within.

---

### Author's Afterword

♪And Iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii wiiiiiiiiiiiiiiiiiiiiii alwaaaaaaays loooooove yooooooooooooou♪

"You fell asleep mid-afterword and hit send?"  
"Finally lost your mind?"  
"Did a cat step on your keyboard?"

You might have thought such things, but it's that famous(?) "Endaa (Endaaa)" from the streets.

Though subtitles were usually taken from Japanese music (J-POP), this marks the first Western music selection.

This is because it became a huge hit as an insert song in the movie 'The Bo*yguard', making it one of Japan's hit songs in the 1990s.

Admittedly, I favored it since I often listened to Wh*tney Houst*n back in the day.

I've seen "Endaa (Endaaa)" comments in 'Narou' novel forums when protagonists and heroines get together.

So while it evokes images of lovers finally uniting, the lyrics actually sing of choosing separation despite promising eternal love.

### Chapter Translation Notes
- Translated "喘ぎ声" as "moans" to maintain explicit terminology
- Preserved Japanese honorifics (-sama, -chan) per style rules
- Kept original name order (Hirose Yuu, Kitamura Kanako, Kujira Touko)
- Transliterated sound effects: "じゅぼじゅぼ" → "ju-bo ju-bo", "ちゅぱちゅぱ" → "chupa chupa"
- Italicized internal thoughts: "（まずい）" → *(This is bad)*
- Translated sexual terminology directly: "膣内" → "vaginas", "チンポ" → "cock"
- Maintained dialogue formatting: New paragraph per speaker, except attribution
- Translated song reference "エンダァ" as "Endaa" with cultural explanation