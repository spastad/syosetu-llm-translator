## 124. Private Lesson ③ ~The Masked Martial Artist~

"May I ask you something suddenly? Kitamura Kanako-san and Kujira Touko-chan, what about your sexual experience?"

"「……」"

Hirose Yuu, who had begun to grope their breasts with his hands extended to both sides, asked them, and the two fell silent.

"Mm... n-now, I've never had any before..."

"M-me too... ah, nn..."

"I see. Hmm, it's a waste that you haven't had even one or two boyfriends, considering how attractive you are. Well, on the other hand, that means I get to have a good time, I suppose."

Yuu nodded, muttering as if to himself.

Kanako and Touko couldn't quite grasp the meaning of Yuu's words.

In today's world, even before looks or personality, meeting a man and developing a romantic and physical relationship isn't something that can be achieved by effort alone; one must have exceptionally good luck and timing.

The current situation, where the marriage rate for women is about 10%, reflects that.

That's why popular romance stories depict heroines meeting one or multiple men through god-like coincidences and developing passionate love affairs.

Kitamura Kanako, 24, and Kujira Touko, 22.

Both had worked in female-only environments since graduating from school and had no proper experience with men, though they considered themselves fortunate to have male family members.

Moreover, being a Male Protection Officer, a role that protects men from crime, is considered elite among professions.

Only those who pass through high competition rates and rigorous education and training can take on this role.

The hours are long, and the pay is high, including hazard pay.

Above all, being constantly by a man's side makes it a coveted profession for female students nationwide.

One reason is the persistent rumor that protection officers sometimes end up marrying the men they protect.

While there are cases where protection officers are asked to become one of the wives, often the man is over ten years older, or the mother recommends it because they can be protected for free even in private.

Cases where they are close in age and reach marriage through mutual feelings are nothing but legends. Reality isn't so sweet.

Nevertheless, the Male Protection Officer Training School, which accepts applicants with at least a high school diploma, sees over 50 times the number of applicants compared to available spots every year.

Since becoming Yuu's protection officers, Kanako and Touko felt they had gained immense fortune.

Because a man like Yuu, who shows affection without disliking the women close to him, was a miraculous existence.

Though they had sensed from his past behavior that Yuu seemed to have relationships with many women and were surprised, their fondness for him never changed.

On the contrary, they even worried about Yuu, who showed such dangerously defenseless behavior towards women.

"Anyway, I'm happy. I get to be the first man for both of you."

"Ehehe."

"R-really, it's unbelievable... ahn! Y-Yuu-sama?"

"Fufu, I'll say it now, but I've wanted to touch Kanako-san's breasts since the first time I saw you."

"My... breasts?"

Touko smiled happily and clung to Yuu, while Kanako expressed restrained joy, moaning.

With their skin pressed together and touching Yuu, sweet sighs naturally escaped them.

"While this cuddling is fun, it's tricky that I have to decide who to go with first."

While kneading Kanako's ample breasts that overflowed in his palms, Yuu hesitated.

Seeing Touko's dissatisfied expression that seemed to say, "Does Yuu-sama like such unnecessarily big breasts?", Kanako thought.

It was true that she cherished Yuu in her heart.

But she remembered that it was her smaller but reliable partner who had appeared with a completely vulnerable expression, unable to suppress her feelings for Yuu.

That had been the trigger.

Kanako shook off her hesitation, made up her mind, and spoke.

"Yuu-sama, please take Shi... Touko first."

Touko had felt since puberty that she might have a stronger sex drive than others.

During middle and high school, she would get excited with close friends about topics like favorite types of men, frequency of masturbation, and preferred situations.

Being clever, she quickly realized she shouldn't be completely honest at such times.

When she sensed that her friends' masturbation frequency was about once every three days, she would say the same.

If they talked about which male idol from the only male talent agency in Japan was their "material," she would agree.

In reality, she masturbated daily without fail, sometimes more than twice a day.

In her mid-teens, she even went out of her way to spots where she could see men, using her excellent eyesight to stare intently—her small stature made her look like an elementary schooler, which helped avoid suspicion—and mentally violated men she liked in every possible scenario, then went home to "review" it.

She knew she couldn't tell anyone about this sexual proclivity.

With parents, older brothers and sisters, and most family members being older, the uselessly accumulated sexual knowledge was only utilized in her mind.

Since Touko lived with her father, her initial masturbation material was, of course, her father.

Her father was rare among men in this world for being fond of women and having a strong sex drive, and perhaps because his intimate relations with his wives were relatively open, she gained such knowledge early.

However, with seven wives and thirteen children, the time Touko could spend being pampered by her father was extremely limited, and the competition was fierce, so she quickly gave up on clinging to him.

Simultaneously, she also became interested in her brother, who was six years older.

Her brother, surrounded by sisters close in age at home and multiple girlfriends he had met through unknown connections outside, always had someone by his side whenever she tried to approach.

As the one who seemed to have inherited the strongest interest in the opposite sex and the strongest sex drive from her father among the thirteen children, Touko thought that if she couldn't manage at home, she should try outside.

But reality wasn't so sweet.

After graduating middle school, she applied to Sairei Academy High School, the closest co-ed school.

Since she had achieved grades in the top 10% of her middle school, she was confident about the written exam.

However, she failed.

She knew her poor performance in the interview was to blame.

Touko naturally had a cute face inherited from her mother, but she had grown her bangs long to secretly stare at men and even wore non-prescription glasses to avoid detection.

Among teenage girls who were already prone to showing interest in the opposite sex, Touko was especially a horny brat whose mind turned pink instantly.

To avoid having her true nature discovered and being shunned by classmates and adults, she had developed a habit of feigning silence and expressionlessness.

Only her childhood best friend and sisters close in age knew about her hidden sexual proclivities.

Thus, her first impression was dark, creepy because no one knew what she was thinking, and she muttered to herself a lot.

It was terrible.

The presence of a male teacher in his twenties during the interview to observe her attitude toward men was particularly problematic.

While calmly answering questions, Touko's eyes were constantly raking over the male teacher from head to toe.

Of course, Touko had also thought about dealing with her strong sex drive.

Like the common advice, she tried to channel her sexual impulses (libido) through sports.

Judo, which she started in her first year of middle school, seemed to suit Touko, and her skills improved rapidly.

Though she was among the shortest in her class, she had inherited excellent reflexes and explosive power from her mother, who had been active in a national-level table tennis team in high school.

Touko improved rapidly and, despite being the smallest in the club, threw even seniors without hesitation.

Softness overcomes hardness.

Throwing larger opponents onto the tatami became an indescribable pleasure.

But no matter how much she devoted herself to club activities, her daily rising sexual impulses didn't change.

In her second year of middle school, a female advisor in her thirties was dismissed for repeatedly peeping on male students, which made Touko realize that no matter how hard she played sports, her sex drive wouldn't diminish.

Still, she loved judo and earned a black belt after achieving a dan rank. In her third year of middle school, she participated in the national tournament. She entered Saitama Eiko High School, a private school strong in sports, on recommendation, and by her third year, she reached the national best four in the lightweight division.

She participated in the national tournament for two consecutive years. Though she didn't win, her good results led to offers from physical education universities.

But the path she chose was the Male Protection Officer Training School in the prefectural capital of Saitama.

Because she thought it was the job best suited for being near men.

The path was tough, but Touko, excelling in both academics and sports, not only passed but achieved top grades in the school.

During mock combat training, her ever-changing movements that bewildered opponents were described by an instructor as "like a ninja," earning her the code name "Shinobu."

After graduating and becoming a protection officer, meeting the admirable senior Kitamura Kanako in April of her second year and being able to work with her was an unexpected stroke of luck.

Touko was invincible when paired with Kanako, handling attacks on protected men calmly and perfectly.

That Touko's qualifications as a protection officer rose rapidly was also thanks to Kanako.

However, some protected men gave her mixed reviews: "Despite her appearance, she's reliable, but sometimes she's creepy."

Perhaps they sensed her sexual impulses leaking out as she visually violated them.

Touko met Yuu around the end of her second year as a protection officer.

When she first saw Yuu while he was still hospitalized, Touko thought:

*This is going to make my masturbation even more productive! I have to be careful not to let my libido leak out.* In fact, Kanako had warned her too.

Even Touko had the sense to keep her violations of men confined to her mind. When actually interacting with men, she was used to feigning silence and expressionlessness.

But Yuu's attitude and actions went beyond her expectations.

After all, he touched her first.

When he first held her hand, she thought her heart would leap out of her mouth.

She tried hard not to show her inner turmoil, but it probably showed on her face.

There's a saying: "Hearing something a hundred times isn't worth seeing it once."

But *seeing something a hundred times isn't worth touching it once.*

When Yuu held her hand, she could feel her body temperature and heart rate rise.

Protected men were supposed to be unfriendly and speak only the bare minimum at first, but Yuu always smiled at her and chatted casually in the car.

Moreover, having her head patted felt so good!

She realized her face was turning red without her noticing.

Once, Kanako told her:

"Shinobu, you smile naturally when you're with Yuu-sama."

The mask she wore to suppress her stronger-than-average sexual desires and impulses and navigate society safely.

She realized it had been easily stripped away by Yuu.

But it felt comfortable.

Though younger than her, Yuu's attitude reminded her of her father and brother, who had doted on her when she was little.

"Yuu-sama..."

Before she knew it, she was muttering Yuu's name when her guard was down.

Previously, Touko had used men of all ages, from the elderly to elementary schoolers, as masturbation material, enjoying various scenarios based on erotic content she devoured. But now, she paid no attention to other men, and when comforting herself, it was Yuu-only.

Still, a protection officer couldn't make a move on a man.

While she was happy to be close to the beautiful boy Yuu through work, Touko suppressed herself. Until the day came to teach him self-defense.

In fact, her favorite fantasy scenario was practicing judo grips and grappling with a man she liked.

They would grapple so intensely that sweaty skin showed through gaps in their disheveled judo uniforms, leading to an extended battle using their genitals.

On the first day, trying to show off, she threw Yuu with a modified sweeping hip throw and, out of ingrained habit, went for a chokehold from behind. She barely held back her strength.

"Mufu. I caught you, Yuu-sama."

"Ah, ahaha. You caught me."

Despite being thrown one-sidedly, Yuu didn't get angry and laughed.

Hearing that, Touko's crotch dampened instantly from the overly convenient development and the refreshing boyish scent from Yuu's neck.

She immediately got a fist from Kanako, though.

Since then, during self-defense lessons with Yuu, Touko wore pads and double panties even when not on her period.

Because the intense skin contact, incomparable to usual, stimulated her lust intensely.

How many times had she been driven by the impulse to push him down when they clasped hands in a standing position or when she hugged him from behind during a defense against a rear attack?

She suppressed it with the protection officer spirit drilled into her, but after returning home, she masturbated so much that she suffered from lack of sleep the next day.

Recently, she accompanied the Hirose family on a trip and enjoyed hot springs and feasts.

Touko, who had drunk a little beer to avoid getting too drunk just in case, went to bed feeling tipsy.

Then, waking up in the middle of the night needing to pee, she went down to the first floor and heard moans coming from a room.

Yuu was simultaneously pleasuring Martina and Elena, making them moan loudly.

She didn't have the courage to sneak close to the sliding door and eavesdrop, so she just strained her ears from a distance in the hallway, feeling strange.

Every time Yuu's voice leaked out, saying things like "It feels good!" or "I'm going to cum!" she couldn't stand it anymore. Right there, she took off her sweatpants, put her hand between her legs, and started masturbating.

How many times did she climax before the moans in the room stopped? She must have fallen asleep there.

When she woke up, it was morning, and she went to the large bath with Yuu after he woke her.

Apparently, her lack of sleep the previous night took its toll; she meant to wait for Yuu but fell asleep on the sofa and found herself being carried on his back.

Being carried by a man like that hadn't happened since she was a toddler, and her memories were vague.

The only regret was that she was asleep and couldn't fully savor the warmth and scent.

The climax was during today's practice of escaping from pinning techniques.

From the moment she pinned Yuu in a grappling hold, she noticed her mouth relaxing and her breathing becoming rough.

The vertical four-corner hold, depending on how you looked at it, resembled a sexual position.

While restraining Yuu's limbs, Touko felt as if her dream had come true and knew she was dangerously excited. Her crotch was already wet.

She even wished this time would last forever.

But what Yuu did was an incredible surprise.

When he suddenly blew into her ear and tickled her armpit simultaneously, her vision seemed to fog over, and her strength left her.

Then, before she knew it, she was the one being straddled by Yuu.

As if Yuu had attacked her.

When he sucked on her exposed chest, her body went numb as if electrocuted, and she made sounds she had never made except during masturbation.

In the end, even after having water poured over her head, Touko's body wouldn't stop tingling, so she visited the shower booth where Kanako was and they comforted each other.

If this continued, she would break.

If she saw Yuu, she might cling to him on instinct, push him down, and have her way with him.

Making love with Kanako seemed to distract her a little.

Even though the partner was a woman, since it was Kanako, whom she trusted deeply, she didn't avoid it.

But an even more unexpected development awaited.

Yuu came to them while they were still naked.

It was also bad that she was so preoccupied with herself that she completely forgot Yuu was waiting.

But after moving to the changing room and hugging the naked Yuu, Touko gave up thinking.

She instinctively realized that the countless mental simulations she had repeated wouldn't work on Yuu.

It was better to leave herself in the hands of Yuu, who seemed experienced.

Stripping away her pretense, Touko began to act sweetly like a kitten, her expression like that of a teenage girl in love.

"Oh my, you're so wet... Touko-chan, you're quite lewd, aren't you?"

"Ahn... i-it's because it's Yuu-sama. Just being touched makes me feel so lewd."

"That's an honor."

Deciding to take Touko first, Yuu straddled the bench and sat Touko on his lap.

He took her well-shaped breast into his mouth again and reached for her private area, finding it soaking wet.

Just grazing the surface, his fingers were coated with her love juice.

When he probed her vaginal opening with his fingertip, the flesh was softened just right.

"Hey, could it be, already?"

"Nnn... ah, haahn! Yuu-sama! I... I can't hold back anymore."

"I see. Well, Kanako-san is waiting her turn too..."

"P-please don't worry about me..."

Kanako, who had been leaning forward to watch over Yuu's shoulder, choked on her words.

Though positioned right behind Yuu, she kept some distance, perhaps out of reserve.

But Kanako didn't notice that Yuu was deliberately pressing his back against her to feel her breasts.

Even while pleasuring Touko, Yuu was mindful of Kanako.

It could be called Yuu's consideration, or his greed.

"It's okay. I intend to take care of both of you with all my heart. Please wait just a little longer."

"Yuu-sama..."

Kanako, looking back over his shoulder, understood what Yuu wanted and pressed her body, which had pulled away, against him, bringing her lips to his.

While kissing Kanako, Yuu lifted the buttocks of Touko, who was clinging to him from the front, and shifted her to position his cock for insertion.

---

### Author's Afterword

Once I started writing about Touko's circumstances, I couldn't stop... I apologize for the lack of progress.

I think we'll get to the main event next time.

### Chapter Translation Notes
- Translated "性経験" as "sexual experience" to be explicit and accurate.
- Translated "オナニー" as "masturbation" consistently with the explicit terminology rule.
- Translated "リビドー" as "libido" as it is the precise academic term.
- Translated "シノブ" as "Shinobu" for Kujira Touko's code name, preserving the Japanese reading.
- Translated "チンポ" as "cock" to maintain explicit anatomical terminology.
- Transliterated sound effects: "じゅんっと" as "damply", "びんびん" as "intensely", "むふー" as "Mufu", etc.
- Preserved Japanese honorifics (-san, -chan, -sama) as per style rules.
- Maintained original name order for Japanese characters (e.g., Kitamura Kanako, Kujira Touko).
- Italicized internal monologues (e.g., *This is going to make my masturbation even more productive!*).
- Used explicit terms for sexual acts and anatomy without euphemisms.