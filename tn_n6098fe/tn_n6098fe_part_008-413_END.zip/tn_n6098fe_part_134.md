## 125. Private Lesson ④ ~YES MY LOVE~

Hirose Yuu didn't fully understand the masturbation habits of women in the world before his rebirth. Even with his ex-wife, the atmosphere hadn't been right to ask about such things. Probably, fewer women had masturbation experience compared to men.  

But in this world, compounded by the scarcity of men, women's sexual desires were strong, and from what he'd heard, many women had masturbation experience. He'd been confessed to multiple times about women breaking their own hymens using adult toys.  

When he asked, Kanako and Touko both admitted they'd broken their hymens long ago. So he thought that even if they were virgins, penetration might be somewhat easier.  

"Ahhh! Hah, it's coming in...nnngh!"  
"Kuh...ooh! It's tight......"  

Touko sat facing him on the bench, their bodies pressed together like magnets. She gazed at Yuu with lust-filled, moistened eyes, rubbing her lower abdomen against him while begging for his cock. When they first met, she'd seemed plain and quiet, but once familiar, she showed very feminine expressions that Yuu found increasingly appealing. This was his first time having sex with Touko. As Yuu, he couldn't help but burn with desire.  

Yuu smiled faintly and lifted her small buttocks with both hands, aligning his cock with her vagina.  
*Nyupuri.*  
The tip slipped smoothly into the wet, soft vagina, but just as it seemed Touko's own weight would drive it deeper, the movement stopped. Not only that - he felt a tight, squeezing sensation from the vaginal walls that left him completely stuck.  

"Ahfe...hya...ah...ah..."  
"Sorry. Not yet. Hold on a bit longer."  
"I'm okay...Yuu-sama...I...want it...want all of it..."  

Despite her words, her furrowed brows and pained expression made Yuu feel guilty. Holding her petite body, he tried pushing in further - not forcing it, but making small piston-like movements to gradually pry her open.  

"Ah! Ah! Hah! Yuu-sama's...c-cock...i-it's...so big!"  
"Kuhah! Touko-chan's vagina is too tight...ooh!"  

After taking time to gradually advance, his cock finally *nyururi* thrust deep into her vaginal depths.  

"Ahhhiin! Fah...ah...ahh...! My belly's...full of Yuu-sama's hard, hot...thing. Hah, hah...amazing...it's in...deep inside!"  

The moment penetration was achieved, Touko had tightly closed her eyes, enduring the pain with beads of sweat on her forehead, but soon her expression softened. Still gripping Yuu's shoulders tightly, she panted with her mouth half-open. "Finally...all the way in. Um...does it hurt?" Yuu asked at lip-brushing distance, but Touko seemed to have no breath to answer. However, when their eyes met, her pink-cheeked, dazed expression suddenly pressed her lips against his in a kiss.  

"Nngh!?"  
Yuu was startled by Touko's initiative but welcomed it. The moment he'd thrust deep, intense pleasure had shot through his entire body - strong enough to make him climax instantly. Only because he'd anticipated it could he hold back. Though he'd experienced this with several virgins, he never got used to it. While ejaculation was undoubtedly the peak moment for men, these moments after initial penetration - savoring the afterglow of emotion and pleasure while kissing without moving - were equally sublime.  

"*Nchu~, churu~, chu, juru jupaa~...aun~...Yuu-sama, I love you, love you, love you so much! Nn, nn, namuchu~...rero reero~...jurun!*"  
"Nn, na, To-Tou...afu!"  

Touko tangled her tongue with Yuu's as if devouring sweet honey, sucking his saliva. For women in this world, first experiences with men were precious, but for her especially, this held special significance. She'd exposed her true self without restraint and reached this point. Most men would have been put off at some stage, but Yuu accepted her even when she approached him with blatant lust. To Touko, this alone made him her one and only - her beacon of hope.  

"*Nmu!?*"  
This time Yuu pried open Touko's lips with his tongue, ravaging her mouth while gradually starting to move his hips.  

"Mufu...ahii...ii, ii, vaa! Nn, nnn! Nhi! Vun! O, o, oo..."  

*(Guh! Wh-what is this...feels too good!)*  

Among all the virgins Yuu had experienced, Touko's interior was exceptional. Was this what they called a "treasure box"? Even before moving, the folds of her vaginal walls tightly enveloped his cock as if never letting go, undulating inside. Even with small movements, slippery pleasure surged through him, threatening to make his hips give way.  

"Kuha...To-ko...i-it's good! Touko's vagina feels too good!"  
"Hi...ah, ah, ahh...Yu, Yuu-sama! Yuu-sama! Au au...your cock...your cock's amazing...I didn't...know this...ihii...in! Ahe, already...no mo...ii, ann! Kuhiiin!"  

Touko seemed to have lost the capacity to respond coherently. With each of Yuu's thrusts, *guchuri guchuri* bubbly, sticky sounds came from their joined parts, convincing him she was genuinely feeling it.  

The face-to-face sitting position, with them embracing frontally, might have amplified each other's pleasure. Fulfilling her wish to unite with Yuu, Touko was tossed about by waves of pleasure without room to endure the initial pain. But Yuu too was already losing composure. Yet rather than slowing, his hip movements accelerated.  

"Gaha...Touko, sorry! I can't hold on...ahh! Like that, it's sucking me in!"  
"Kyau! Yuu-sama...o, o, your cock! Your coock! Amazing, amazing...it's coming!"  
"I-I'm cumming...inside Touko's...vagina...vuh!"  
"Co...ming...Yu...u...kyahiin!"  

Not much time had passed since they joined - maybe five minutes at most. Yet drenched in sweat as if they'd sprinted full speed, their climax arrived. Yuu released a copious amount of semen into Touko's womb.  
"Faaaaaaah!? E...hi.........ah...hah......kuuuuun!"  
Receiving his seed, Touko jerked her chin up, staring blankly at the ceiling. Rather than speaking, she just gasped while moaning with each breath. Being creampied gave her her first internal orgasm, the shock so intense her consciousness nearly faded.  

After a while, seeing Touko's face slumped limply on his shoulder, Yuu smiled softly.  
"Did it feel good, Touko-chan?"  
"Yu...Yuu...sa...ma..."  
"Rest a bit."  

Looking around, Yuu spotted another similar bench against the far wall. Still connected, he lifted Touko and gently laid her down. Then he looked back.  

"Hah!"  
"Kanako-san, sorry to keep...you..."  

Kanako had been standing right behind where Yuu held Touko, but now she straddled the bench, strangely covering her lower abdomen with both hands - meaning her arms stretched straight down, which to Yuu looked like a sexy pose emphasizing her breasts. Yuu's cock, still hard and curved after one ejaculation, showed no signs of weakening. He wanted to insert it into Kanako immediately. With that thought, he approached.  

Yuu sat facing Kanako across the bench and immediately reached for her hands. That's when he noticed her crotch was wet. Hearing her restrained moans earlier, she'd probably been masturbating. Yuu wasn't particularly fixated on virginity, but the thought of taking this stunningly beautiful woman's first time excited him nonetheless.  

"Kanako-san!"  
Still holding her hands, Yuu pressed closer.  
"Ha, haaah...I'm scared"  
"Eh...?"  

This unexpected reaction stunned him. Kanako shook off Yuu's hands and retreated slightly. Never imagining rejection, Yuu gaped momentarily before his expression darkened. Since most women happily accepted his advances, the shock was profound. Seeing this, Kanako frantically shook her head.  

"Th-that's not it! It's not that I don't want Yuu-sama...!"  

---

In truth, marriage proposals had come Kanako's way more than once or twice. Not just from protected males, but as a young elite protection officer, she'd received countless "please marry my son!" requests from agents or mothers of men she'd never met.  

But everyone was attracted to her achievements and title as a protection officer. Some even included sons of assembly members who wanted to collect elite women - lawyers, prosecutors, doctors, corporate executives - as wives. Moreover, the arranged marriage candidates were invariably men 10-20 years older.  

"It's a good opportunity," her superior would recommend with a broad smile, but Kanako politely declined every time. She hadn't become a protection officer for that. She never told anyone, but she wanted to protect her beloved brother with her own power. Since they lived apart, that dream remained unfulfilled.  

By March this year, she'd been scheduled to lead a five-person team protecting a 30-something husband of a company president. But then came a last-minute request to protect a boy entering high school. For the security company, deploying one of Saitama's only three S-rank protection officers on the first job meant bigger contracts and benefits. But Kanako selfishly chose the latter request. Seeing Yuu's profile, she superimposed her brother's image - that was the deciding factor.  

After meeting Yuu and starting her protection duties, she felt certain her choice wasn't wrong. Though sometimes overstimulated when Yuu held her hand or linked arms, she found unprecedented fulfillment in protecting a younger boy.  

But as time passed with Yuu, Kanako grew troubled by her increasing admiration for him. At first, she'd superimposed her brother's image, but Yuu was completely different. She'd had few opportunities to interact with teenage boys besides her brother, but Yuu's attitude was exceptional. She was amazed he could be sociable with unfamiliar women without fear - not just because they protected him. Fundamentally, Yuu seemed to hold almost no fear of women, as if he naturally accepted their presence. She later learned he was the son of the legendary Toyoda Sakuya. More than a son, he seemed exactly like the man she'd heard about.  

Yet he'd act age-appropriately affectionate with Kanako while showing dignified composure with women twice his age. Though outwardly a teenage boy like her brother, his essence felt like a composed adult. Before she knew it, she realized she was attracted to him as a man and felt confused.  

Touko had expressed affection for Yuu first. But Kanako's heart held the same feelings. She just maintained a facade, suppressing her emotions. As a protection officer, men were objects to protect. No matter how strong her feelings, she must never show them. Even seeing him naked, she mustn't expose her reproductive instincts. She armored herself with reason to suppress the overflowing passion in her heart...  

---

"What are you afraid of?"  
Deliberately not closing the distance, Yuu watched Kanako as she shook her head tremblingly, face downcast. Kanako wandered her gaze before looking at Yuu, but upon seeing his impressive erection, she covered her mouth in shame and closed her eyes. Eventually, she opened her beautiful slanted eyes toward him.  

"I-I too...li-like Touko...wa-want to...d-do that...with Yuu-sama..."  
"Th-thank goodness. I thought I got carried away and you hated me."  
"Not at all...absolutely not!"  
"Really?"  
"Yes!"  

When Yuu reached out both hands and grasped hers, she didn't pull away this time. "But what scares me...is if we become that kind of relationship...can I stay calm protecting you like before...? Just being near you, I might lose control..."  

Kanako's concern might have been the fear of the unknown common in reserved women - fear that indulging in lust would change her for the worse and ruin their existing relationship. Yuu released her hands, drew closer, and embraced her.  

"Ah! Haaaah..."  
Yuu's warmth felt comforting against her chilled body, drawing an involuntary sigh. Simultaneously smelling the boy's sweat, heat pulsed from her core again.  

"Kanako-san!"  
"Y-yes!"  
Yuu and Kanako gazed at each other at close range. "Kanako-san will be fine. I've seen many women and I know. Besides family, no one protects me as preciously as you. No matter what happens, you're steady and reliable - like an ideal big sister."  
"Hau!"  

This must be what they call an arrow through the heart. Kanako's head spun as if drunk, while a painful, aching feeling spread through her chest. At near lip-contact distance, Yuu continued.  

"I want to take a step further with you, Kanako-san. To be blunt, I want to have sex. But this isn't the goal - I want an even closer relationship than before. Haha...saying it out loud is embarrassing, but is that okay?"  
"Ha, ha, hahi...u-um...I'm the one...pleash to..."  

Kanako's words were cut off. Because Yuu sealed them with his lips. After several kisses, Kanako's hands rose to wrap around Yuu's back, hugging him tightly in return.  


### Chapter Translation Notes
- Translated "オナニー" as "masturbation" per explicit terminology requirement
- Preserved Japanese honorifics (-sama, -chan) throughout dialogue
- Translated "チンポ" as "cock" following explicit anatomical terminology rules
- Used "creampied" for "中出しされた" to maintain sexual explicitness
- Transliterated sound effects: "にゅぷり" → "nyupuri", "ぐちゅりぐちゅり" → "guchuri guchuri"
- Maintained original name order (Hirose Yuu) and first-name usage when original text used given names only
- Formatted internal monologues in *italics* per style guidelines
- Used horizontal rules (`---`) to denote scene transitions matching original spacing
- Translated "警護官" as "protection officer" per Fixed Reference terms
- Preserved cultural terms like "S-rank protection officer" without explanation since defined in Fixed Reference