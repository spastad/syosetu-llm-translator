## 126. Private Lesson ⑤ ~The Three Male Protection Siblings~

### Author's Preface

"男護" is read as "Dango".

---

"Ahhh... Kanako-san's breasts. So large and soft, yet with such resilient bounce that they push back against my fingers, truly magnificent."

"Nn... hah, hah, such praise for my chest... nnah! Wh-why... akuu!"

Yuu, covering the supine Kanako on the bench, kneaded breasts too large to fit in his palms. According to hearsay, they were magnificent melons exceeding 90cm in bust. Though the cup size seemed modest due to well-developed pectoral muscles, they formed beautiful hemispheres like inverted bowls - no, like rice bowls, Yuu thought. Enthralled, he kneaded the twin mounds that maintained their hill-like shape even when she lay on her back.

When Yuu squeezed a nipple between his fingers while massaging a breast with his full right palm, Kanako trembled and cried out involuntarily. Seeing Kanako's sensitive reaction, Yuu smiled and stroked her hair. Once cropped shoulder-length, it now reached her back. Fully dried, it shone glossy under the lights, slipping smoothly through his fingers. Playing with the spread chestnut-brown hair with his left hand, Yuu latched onto her other breast.

"Hyaun! A, ah, ahh! Y-Yuu-sama... not there, don't suck..."  
"Mmph. Kanako-san, your nipple's standing up? Does it feel good?"  
"Ha... uun! Yuu-samaaa..."

The nipple being toyed with by fingers and tongue swelled visibly. Flustered, Kanako stroked Yuu's head and back with both hands.

After persistent breast play using fingers and mouth, Yuu noticed Kanako's groin growing wet as his erect cock pressed against her lower body. Sliding his right hand down to her lower abdomen while planting kisses on her dazed face, he murmured:

"Kanako-san, your pussy's gotten like this..."  
Without looking, his fingertips felt the soaked state - the vaginal opening area had loosened noticeably. Just bending his finger and wiggling produced squelching *kuchu kuchu* sounds.

"Haaah! Ah, ah, an! Yuu-sama! B-but... I-I! Ah, an! Already... aaaaaaahhhh! D-don't tease so... nnnnnnnnnnnnnnnnnnnnnnnnnn!"  
"Ahh, wonderful. Seeing the usually dignified Kanako-san moaning so wantonly is exciting me."  
"B-but... Yuu-sa... amm... nn, nn, mmph... nno! Vah... aii! Ii!"

Twenty-four-year-old Kanako and recently-turned-sixteen Yuu. Given the age gap, Kanako should be leading, yet she was completely at Yuu's mercy. Though she'd had opportunities to interact with men, her lack of sexual experience matched Touko's. This didn't mean she lacked libido - occasional masturbation had vented her urges. While maintaining a proper exterior, private sessions with her favorite vibrator had long broken her hymen. But now, Yuu's hands stripped away her rational armor, exposing her female instincts, leaving her fragile - essentially virginal regarding actual sex.

"Look, Kanako-san's clit is so swollen. Feels good when touched here, right? Ah, I'll play with inside your pussy too. Ooh, it tightly squeezes just my finger. Must feel incredible when my cock enters."  
"Fah! Ah, ah, ahi! Ii, ii! Shoko... an, an, Y-Yuu-sama... haaaaaan... nn, nn, hyaan! Shonna... hiin! Can't take it... ah, ah, aaaaaaaaaaahhhhhhhhhhhh!"

Yuu's play-by-play commentary while rubbing her engorged clit with his fingertip, thrusting his middle finger deep inside, massaging her vaginal walls - sensations far stronger than her own touch sent pleasure coursing through her body, making her climax easily. Kanako's erogenous zones seemed to awaken under Yuu's ministrations.

As Kanako climaxed, Yuu paused his caresses to embrace her gently.  
"Can't hold back much longer. I'm putting my cock in."  
"Ha, hahi... Y-Yuu-hya... your cock, please, please"  
"Nn"

After several kisses, Yuu sat up and gazed at Kanako's body. Her ample breasts rose and fell with ragged breaths. Fresh from orgasm, her long legs lay splayed open, the parted vulva revealing a beautiful salmon pink, glistening wetly. Stroking the firm inner thighs, Yuu gripped behind her knees. Pushing them forward to spread her wider, he brought his face to her groin. Milky white love juices dripped from her vaginal opening. The musky female scent rose, her sex seeming to pulsate in anticipation of Yuu's cock.

He pressed his rock-hard cock, dripping precum since her fondling, against her entrance.  
"Look. Kanako-san. Going in."  
"Eh?"

Kanako had only seen male genitals on her childhood brother. Though she'd seen women's magazines and videos - where erect cocks (varying by person, but adult content usually showed larger ones) were about index finger-sized - Yuu's cock exceeded expectations in thickness and length. Its color and shape looked downright savage. That such a fierce thing belonged to someone with her brother's delicate features shocked her. Fear wasn't untrue, yet her body craved it - she felt a twinge deep in her lower abdomen. After all, Touko had writhed so intensely earlier. She couldn't guarantee she wouldn't do the same.

"Ahh... Yuu... sama"  
"Kanako-san... nkuh... aah!"

The cock plunged into her vagina. With no hymen to break, it drove deep inside. Feeling the tight squeeze, Yuu pushed on relentlessly.

"Kuuuaaaaaaaaahhhhhhhh! Iiiaaii! Hi, ng... ah, haii!"  
"Hah, hah, hah... I'm in, Kanako... san... ooh, inside you is... beyond words, incredible."  
"Ha, hahi, Y-Yuu-sama's is... so big, I'm... full already... ah"  
"A-are you okay? You cried out, did it hurt?"

Kanako stroked Yuu's head as he looked at her worriedly.

"It hurt when you entered... but... I'm fine. Rather, being able to receive Yuu-sama... *giggle* makes me very happy."  
"Kanako-san!"  
"Yuu-sama"

As Yuu leaned in for a kiss:  
""Aaaaaaahhhhhhhh!""  
Their voices harmonized unintentionally.  
"D-don't squeeze so tight!"  
"N-noo... too deep... being thrust!"

The insertion position with Kanako's thighs folded forward angled her vagina upward - essentially a "breeding press" position. Yuu leaning forward drove his cock deeper into her depths. Moreover, Kanako's spacious vagina swallowed Yuu's cock down to the base. Naturally, her virgin passage squeezed intensely. Like Touko, her well-trained vaginal muscles unconsciously clamped down fiercely.

"Haah, haah, K-Kanako-san"  
"Hii... Yuu... sama... ah... nn"

Exchanging drunken expressions of pleasure, they embraced tightly and kissed. Their tongues intertwined.

"Am, muchuuuu... jururero, rero, na... nchuu, churu, chupaa... an... Yuu-sa... ma... love you... love you... ii... an! Aaan!"  
"Ahh, Kanako-san... hau... inside you feels amazing! M-my hips... won't stop... dangerous, I..."

Starting with hesitant short thrusts, as his cock acclimated, the copious love juices acted as lubricant, his pumping speed increasing involuntarily. Though his mind said to slow down, his body rolled downhill uncontrollably, pistoning into Kanako greedily.

*Bachun! Bachun! Bachun!*

The emotion of taking Kanako's first time, the unexpectedly penetrating pleasure - these mingled as Yuu thrust frantically, the sound of flesh slapping echoing.

"Ah! Ah! Ah! Ahi! Y-Yuu-shama! So rough! Hii, hia... an! Amazing, feels so good! Hyaun! No, kuaaan!"

Pain vanished completely. With each thrust sending uterine-trembling pleasure, Kanako involuntarily straightened both legs. Not content with hugging Yuu's head and back, she unconsciously wrapped her legs around his waist too - as if refusing to let go until receiving his seed.

"Uwa... ah, ah, Kanako-san... Kanako-san! I'm gonna cum! Gonna cum inside your pussy!"  
"Hai, co... me... Yuu... Yuu-shama! Inside... cum, give me... please!"  
"Gu... u... vu!"

With her legs locked, unlike before, Yuu thrust deep to the hilt, grinding against her cervix. His cock swelled as ejaculation neared. Kanako's jaw lifted involuntarily.

"Gah! Igg!"  
"Hii! Shogo... o... in!"

*Dopyu dopyu doruuu!*

A volume nearly matching what he'd given Touko flooded Kanako's womb.  
"Ah! Hye... nn, nn, nnnnnnnnnnnnnnnnnnnnnnnnnnn! Afu, afui... so much, filling me... hafu... Yuu... sa... ma... ah... nn, mphuun"  
Being held while receiving his seed filled Kanako with euphoric bliss - an unprecedented orgasm. Though wrapping all limbs around Yuu, her face slackened ecstatically, drool dripping from her mouth - a never-before-seen dazed expression.

Touko had recovered unnoticed and clung to Yuu's back when he sat up. Though satisfied after her intense first time, watching Yuu and Kanako had reignited her heat.

The underground training facility was reserved until noon. But checking the locker room clock showed past 11 AM. Considering shower time, they had maybe 30 minutes left. Yuu helped Kanako up and embraced both protection officers.

"An... Yuu-sama... want to do it again."  
Kissing the kittenishly affectionate Touko, Yuu stroked her messy bob. "Sorry. I'd love another round, but time's short."  
"Feeeeee"  
*This girl's too cute*, Yuu soothed. "Instead, wanna touch my cock?"  
"Yuu-sama's cock... un!"  
"Kanako-san too please"  
"Yu, Yuu-sama's... ooh..."

Kanako gulped. Seeing the delighted Touko grab Yuu's cock with both hands, she hastily reached out too. Sandwiched naked between them right after ejaculating inside Kanako, his cock remained hard. The rigid erection was stroked by four hands.

"Waha! Yuu-sama's cock, rock-hard♪ And slippery~"  
"Y-yes... but amazing. Still so magnificent after two ejaculations."

The slipperiness came mostly from Kanako's juices. Blushing slightly, she traced the glans while Touko gripped the shaft firmly, enjoying the texture.

"Hau! G-gently please."  
"Ah... apologies, Yuu-sama."

Despite years of mental training, Touko didn't know how to handle a real cock. But Yuu didn't scold her, just patted her head gently.

"M-male genitals are delicate like women's, I hear. Handle carefully."  
"Un. Carefully carefully."

With cautious, clumsy touches, they thoroughly examined and touched from tip to balls. Not quite a handjob, but Yuu surrendered to the pleasure of his cock being handled by both women pressed close.

"Hey, Kanako-san, Touko-chan"  
"Y-yes?"  
"Un?"  
"I have a request."  
"Anything you command."  
"For Yuu-sama, anything!"

Meeting their serious gazes, Yuu smiled wryly, stroking their heads and backs.  
"Since we're here... want you both to suck my cock."  
"Suck...?"  
"Fe, fellatio!? For Yuu-sama... waaah!"

Though inexperienced, Touko seemed more sexually knowledgeable, offering to demonstrate fellatio. Wrapping her left arm around Yuu's waist, she lightly gripped the shaft with her right hand and licked the glans.

"Like this... use your mouth and tongue... pamper his cock."  
"I see. Let me try immediately. Must repay Yuu-sama for making us feel so good."

Kanako similarly pressed against him, one arm around his back, breasts pushing close, while her other hand gently traced his cock before kissing it. Opening her mouth, she began licking with her tongue. Soon their hands overlapped, stroking rhythmically as they took turns licking from both sides.

"O, oh... feels good..."  
"Mph, Yuu-sama's cute."  
"Juru, rero, rero, chupaa... hah. Is this alright?"  
"Ah, both of you, unbelievably skilled for first-timers."

Even if clumsy, their heartfelt effort pleased Yuu. Frankly, a double blowjob from beauties was a man's dream.

"Nn, nn... haun, amuchu, chururero... haa, haa... Yuu-sama's cock, wonderful. Am... nn, nchuu"

Noticing Touko rubbing her thighs together while sucking, Yuu reached behind to her buttocks and probed her secret place. Two fingers playing with her vaginal entrance produced a *kuchu* sound, making Touko's body jerk.

"Good, keep going. I'll play with your pussy too."  
"Fa... i... mphuu, aam... nn, nn..."

Kanako looked up longingly. But Yuu couldn't reach her buttocks from his position. Adjusting her posture, he had her rest her head on his thigh with one knee up to spread her legs. Reaching from her abdomen, he inserted his middle finger directly into her vaginal opening. *Jupu jupu* sounds accompanied the leakage of cloudy fluid.

"Nn... nnnmuunphuu! Haa, ah, Yuu... hya... aun!"  
Kanako cried out involuntarily as she began sucking his balls. Similarly stimulated Touko moaned while diligently continuing fellatio.

"Haa, haa, everyone together... f-feels good... ah... yes, good..."

Drunk on pleasure from the double blowjob, Yuu relentlessly tormented both pussies with multiple fingers. As the wet sounds intensified, the overlapping hands stroking his cock sped up.

After two ejaculations, Yuu was barely holding on. Previously coated with Kanako's juices and semen, his cock now glistened with their saliva.

"Nn, mphuu! Mua... vu, ah, an! Amuu~n pujuru jupu rero"  
"Fa... nmu, nn, mphuun... hahuu, Yuu-shama, wonderful... vah! Ah! Haun!"

Moaning muffled sounds, they continued diligently until Yuu reached his limit - perhaps because making them climax with his hands broke his concentration.  
"Cumming... cumming... vu!"  
Under the dazed gazes of Kanako and Touko, his cock twitched and shot semen upward.  
""Ahhh!""  
Even for a third time, his voluminous cum sprayed through the air, landing on their waiting faces.

"Haa, haa... amazing, felt so good. And we... almost came together."  
"Faaaah, amazing. This is... Yuu-hyama's... semen."  
"I... never dreamed this day would come..."

Yuu gazed contentedly at Kanako and Touko, semen-smeared and blissful. But glancing at the clock, he suddenly panicked.

---

### Author's Afterword

Though I wanted to do more with these three who finally united, time ran out so we'll end here for now.

Moving forward, I had two events planned but decided to change schedule. After one interlude chapter, we'll jump to late July for Chapter 4's climax: the inter-school quiz championship and July's gender exchange event happening simultaneously. Originally planned events will be moved to Chapter 5 onward.

### Chapter Translation Notes
- Translated "男護3姉弟" as "Three Male Protection Siblings" to preserve the "Dango" reading context
- Rendered explicit anatomical terms directly ("膣" as "vagina", "精液" as "semen")
- Preserved Japanese honorifics consistently (-san for Kanako, -chan for Touko)
- Transliterated sound effects (e.g., "bachun" for ばちゅん)
- Maintained original name order (Hirose Yuu, Kitamura Kanako, Kujira Touko)
- Translated sexual acts without euphemisms ("フェラチオ" as "fellatio")
- Used explicit terminology for sexual content per style guidelines