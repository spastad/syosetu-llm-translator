## 127. Preparation Period ~LOVE AFFAIR~

Her lustrous black hair swayed each time her head bobbed up and down.  
When the cock filling her mouth hit the back of her throat, muffled sounds escaped, but she continued the fellatio undeterred, drool dripping from the corners of her mouth.  
Not only did she apply pressure by pursing her lips, but she also skillfully moved her tongue to stimulate the entire glans.  

"Mmpph...nngh...mmh, mmh, mmh, slurp...hahh...ah~mmph! Chulurelo slurrrrp!"  
"Gh...uuuughhh! Th-that's...good! I'm gonna cum, Sayaka!"  
"Mmph, mmph, mmph"  

Yuu had been stroking Sayaka's back under her flipped-up sailor uniform skirt, but unable to withstand the pleasure, he tightly grabbed her shoulders.  
Sayaka looked up at Yuu, happily narrowing her eyes as she increased the speed of her handjob on the shaft while continuing to suck with her entire mouth.  

On a Thursday in mid-July.  
Though busy days had continued, Yuu was enjoying a rare private rendezvous after Sayaka invited him.  
After entering the student council office and carefully caressing each other, they joined together for their first ejaculation inside Sayaka. While she enthusiastically performed cleanup fellatio, it turned into serious deep-throating.  

Even though Sayaka herself seemed aroused just from sucking Yuu's cock—rubbing her inner thighs together—she didn't cut corners.  
Not only had she received thick, abundant semen inside her womb, but she now tried to milk every drop with her mouth.  
Mixed with precum and saliva, the lewd *shlup shlup* sounds continued as Sayaka sucked.  

"Ah, ah, already...Sa-Sayaka! I-I'm cumming! Cumming...ughh!"  

Though tilting her chin up, Yuu's right hand rested on Sayaka's head, gripping her long hair.  
Feeling the cock pulsate in her mouth, Sayaka tightened her grip on Yuu's hips and began her final sprint.  

"Gmmph!?"  

Like an erupting volcano, a thick, magma-hot torrent flooded her mouth.  
Having anticipated it, she waited with composure. Since becoming intimate with Yuu—sometimes even with Riko and Emi—she'd received his semen many times.  
Yet the volume and force of the milky fluid still overwhelmed her.  

"Mmgghh...mmh...mmgh, mmgh, mmgh...ohh, ohffu..."  
Closing her eyes, Sayaka gulped down the semen filling her mouth with a *gulp*, but the ejaculation continued.  
The thick, sticky semen alone would take time to swallow completely.  
But Sayaka had no reason to dislike it. Rather, this was a woman's joy.  
When she raised her gaze and saw Yuu's moved expression, feeling the pleasure of having guided the cock that had pleasured her so much to climax, her lower abdomen clenched with desire again.  

***

Yuu lay sprawled holding Sayaka sideways as she licked up the last drop of semen.  
Though he'd never taste it himself, he imagined semen must be bitter, pungent, and sticky—not something easily swallowed.  
Even during blowjobs at soaplands in his previous life, the girls would spit the semen into tissues.  
Yet women in this world gladly drank it. Apparently, it was protein-rich and good for beauty and health—essentially like green juice.  
As a man, seeing it drunk before his eyes multiplied his joy.  
So Yuu expressed his gratitude while cuddling her affectionately.  

The pre-rainy-season weather alternated between muggy days and occasional clear summer days.  
But today, a steady rain had fallen since morning, with temperatures only reaching 22-23°C—relatively cool.  
Thus, their sweat-dried skin touching felt pleasant, conveying the softness, scent, and warmth unique to girls.  

Noticing Sayaka suddenly lift her face from his shoulder, Yuu combed her smooth black hair with his fingers—silky strands slipping smoothly through them.  

"Yu-Yuu-kun? U-um...well..."  
"What is it, Sayaka?"  
"E-er...that is..."  

Due to preparations for the joint event with Saiei Academy—revived after 15 years—and July's gender interaction event, recent gatherings often included not just student council members but volunteer committee members from across the school.  
Thus, such intimate alone time was rare. Perhaps she had something hard to say in front of others?  
Yuu gently stroked the hesitating Sayaka's cheek, waiting for her words.  

"J-just something I heard...ahhh, umm!"  
"Calm down, Sayaka."  
"I'm fine! W-wah, I'm flustered...huh?"  
"Here, let's take a deep breath?"  

They sat up facing each other. Taking deep breaths using both hands seemed to calm her.  
Though Sayaka managed a smile, shadow soon fell across her beautiful face.  

"I heard...Yuu-kun has started using the Friendship Hall...and that students saw you going there not just with students but with staff...  
I thought it might be mistaken identity, but she definitely said it was you."  
"Ah. That's definitely me."  

Perhaps she'd hoped Yuu would deny it. His calm affirmation clouded her expression, but she quickly adopted a resolute attitude.  

"If it's our school's staff, that shouldn't happen...b-but you weren't forced...?"  
"I've never been forced. I initiated it."  
"Wh-why...?"  
"W-well...because I wanted to have sex."  

Sayaka fell speechless seeing Yuu answer so nonchalantly, averting her eyes as if tracing invisible characters on the tatami.  
Even Yuu realized this was bad. Lately, he'd gotten carried away, exploiting how no one ever refused him.  
Simultaneously, Sayaka's rare pouting expression felt refreshing.  

"Could it be...you're jealous?"  
"...! Th-that's...not it..."  

Contrary to her words, her dejected demeanor filled Yuu with guilt.  
For reincarnated Yuu, Sayaka was his first love—a feeling unchanged even now.  

"Sayaka, please listen."  
"Eh...?"  

Yuu moved closer, placing hands on her shoulders to face her directly.  
"I'm not like ordinary men in this world—I seem to love women intensely.  
Whether meeting for the first time or older/younger, when I encounter attractive women, I just can't control my urges."  
"U...un. I thought I understood. That's just how you are.  
That's why all the girls at school whisper about it. Yuu-kun is every girl's dream guy.  
That I can be...in such a deep relationship with you is incredibly lucky..."  
"Sayaka."  
"Ah..."  

Sayaka's heart raced as Yuu gazed at her from up close—close enough to see her reflection in his black pupils.  

"Apparently I have an insanely strong sex drive. Following male instincts, I want to have sex with various women. It's truly hopeless.  
But..."  

Yuu pushed Sayaka down while gripping her shoulders. She offered no resistance.  
He whispered by her ear:  

"The girl I fell for at first sight when entering this school—the one I still like most—  
is you, Sayaka."  
"Hauu!"  

Instantly flushing crimson, Sayaka met his gaze.  
"Sorry for worrying you. But did my true, unfeeling feelings get through?"  
"...! Yuu-kun, you dummy."  
"Huh?"  
"Y-you shouldn't worry about someone like me...just do as you like."  

Though likely meant to hide embarrassment, her moist eyes and softened lips betrayed her.  
Smiling faintly, Yuu playfully retorted:  

"No way! Because Sayaka's popular too, right? I have to hold onto you properly."  
"Huh? Th-that's not..."  

Yuu had heard from Riko that several third-year boys had wanted to get close to Sayaka if not for her fiancé.  
Moreover, Sayaka was popular with girls too.  
By Yuu's measure, she was the school's most popular figure, admired by both genders.  

"Sayaka's too attractive—I want more and more of you. See?"  
"Nnfeh!?"  

Pressing his still-hard cock against Sayaka's lower abdomen, Yuu covered her lips.  
Sayaka closed her eyes, wrapping both arms around Yuu's back to hug him tightly.  
As they kissed repeatedly, tilting their heads, Sayaka's lustful sighs escaped.  

"Mmph, mmph...ahfuu...Yuu...kun! I-I also...want Yuu-kun! Fuck me hard...make a mess of me!"  
"Ahh, Sayaka...I'll do exactly as you wish!"  
"Co...me!"  

Sayaka spread her legs wide to receive Yuu.  
After briefly pulling back to adjust the angle, Yuu thrust into her.  

"Uwaa!"  
"Aahhn!"  

Yuu's right hand cradled Sayaka's head while his left grabbed and kneaded her jiggling breast.  
The moment the tip *tapped* deep inside her, Sayaka's long legs wrapped around Yuu's waist.  

"Ah, ahi...hyuun! Yu-Yuu-kun, not yet...don't move!"  
"Eh, why?"  
Shaking her head as if refusing, Sayaka mumbled softly:  
"B-because if you move...I'll cum."  
"Th-that's unacceptable."  
"Yuu-kun is...mean...ah, ahn! Like that...deep spot, aaiihh!"  
"You're so cute when aroused, Sayaka. I'll love you lots so you feel even better."  
"Haaah, ah...ah...AAAAAAHHHHHH! Yu-Yuu...kuuun!"  

The sounds of flesh slapping, sticky wet noises, and Sayaka's intermittent moans.  
Deeply connected as one, the two continued their sexual union, creating an uninterrupted symphony of multiple sounds.  

***

***  

Sairei Academy's final exams ran from July 20th through the 24th (including Sunday), with the semester closing ceremony on the 25th before summer break began.  
The joint event with Saiei Academy and July's gender interaction event would be held on the 27th (Friday), with full-day preparations on the 26th.  
Note: The event would proceed in light rain, postponing to the 28th (Saturday) only for heavy rain.  

Whenever meeting Rinne and other Saiei student council members, Yuu noticed their predatory gazes and meaningful looks.  
Rinne's group often seemed to want to speak with Yuu alone and had directly invited him.  
But Sayaka and other student council members always guarded him closely, never leaving him solo.  

The quiz championship—the finalized joint event—progressed according to the schedule set by both schools' student councils.  
Additionally, two temporary staff members per class were recruited to assist preparations.  
An assembly in early July announced the event details while posters across campus recruited participants.  

With the board's backing, lavish prizes awaited top performers.  
As a school-vs-school format, the winning school would receive special rewards (Sairei would get Saiei facility access; Saiei would get permission to invite boys). This further fueled the girls' enthusiasm.  
Applications reached the 300-participant cap (150 pairs) within two weeks—ultimately about 80% of all students applied.  
About one-third of boys applied too, with 16 pairs (32 boys) confirmed. Teachers would also participate as 5 pairs (10 people).  
The remaining slots would be decided by an in-school preliminary (written test) the afternoon of the closing ceremony.  

Meanwhile, July's gender interaction event was the annual school camping trip.  
Boys and girls would cook together and gather around a bonfire on the grounds.  
Afterward, they'd temporarily disband before remaining students stargazed on the rooftop (accessible only that day) and stayed overnight in the dormitory.  
Previously optional for boys, participation had been around half (mostly second/third-years) but was now mandatory for all.  
In principle, they'd return home after the bonfire ended at 21:00.  
However, couples reportedly spent passionate nights together annually.  
Naturally, the Special Male-Female Negotiation Rooms had been fully booked long in advance.  
Hearing this, Yuu agonized over how to spend that day.  

The gender interaction event would be prepared and run by the event committee appointed in April, seeking cooperation from clubs.  
July posed particular challenges this year.  
With final exams in late July and crucial Inter-High regional/prefectural qualifiers starting around the 27th for sports clubs, students involved in both events faced packed schedules.  
Thus, holding both events on the same day in separate time slots while keeping Saiei students uninformed increased the burden.  

So passed busy days for Yuu and the student council members, until they finally reached July 27th—the day of both events.  


### Chapter Translation Notes
- Translated "フェラチオ" as "fellatio" per explicit terminology requirement
- Preserved Japanese honorifics (-kun for Yuu, -san not used in this chapter)
- Maintained original name order (Komatsu Sayaka)
- Transliterated sound effects (e.g., "shlup shlup" for じゅぷじゅぷ)
- Italicized internal monologues (e.g., *shlup shlup*)
- Translated explicit anatomical/sexual terms directly ("semen", "cock", "intercourse")
- Used gender-neutral "staff" when original Japanese didn't specify gender
- Applied dialogue formatting rules (new paragraphs for dialogue without attributions)
- Translated culturally specific terms literally with context (e.g., "green juice" for 青汁-like comparison)
- Kept specialized terms like "Friendship Hall" and "Special Male-Female Negotiation Room" consistent with Fixed Reference