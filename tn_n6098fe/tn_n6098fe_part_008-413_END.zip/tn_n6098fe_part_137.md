## 128. Quiz Championship ① ~Because This Is the Beginning~

### Author's Preface

The beginning of a long day.  
Due to event proceedings, there won't be full-fledged erotic content including the main event for a while.  
There will be interactions with girls, but at most, it will be mild eroticism.

---

July 27th (Friday)  

The day had finally arrived.  
The day of the inter-school quiz competition between Sairei Academy and Saiei Academy, officially named the "First Ayakuni Cup High School Quiz Championship" by the Ayakuni Group board.  

The rainy season ended just as final exams for the first semester began, leaving clear sunny days in its wake.  
Massive cumulonimbus clouds would appear, and some afternoons brought sudden thunderstorms.  

"The weather cleared up just as forecasted, how fortunate!"  
"Truly. If it had rained and postponed to tomorrow, some club members wouldn't have been able to participate due to regional preliminaries."  

Riko and Emi were talking right next to Yuu.  
Not just the usual student council room, but even the adjacent waiting room had gathered key student council members and event committee students early for final confirmations of today's two events, which had just concluded.  

Looking out the fully open window, a cloudless blue sky stretched as far as the eye could see.  
Today's high was predicted to exceed 30°C.  
But thanks to abundant greenery in the area, the heat island effect seemed minimal here.  
With low humidity, shade provided cool relief, and the air still felt refreshing until around 8 AM.  

"Seems the outdoor preparations are nearly complete, what a relief."  
"I was shocked when I saw how transformed everything looked during morning arrival."  

Yuu approached Sayaka who was looking out the window after finishing his tasks.  
Looking down, he could see girls in gym uniforms sporadically carrying items.  
The building blocked the view of the main gate from the student council room, but one side of the path from the main gate to the schoolyard was lined with festival stalls.  
Additionally, food service operators among parents from both schools were providing discounted drinks and light meals.  
With summer break starting, the school cafeteria and store were unavailable, so these would help hydrate and feed students.  
Several tents were already set up around the first athletic field, the quiz championship's main venue.  
The transformed schoolyard felt like the prelude to a sports festival.  

"Everyone worked late yesterday, huh? How late did you stay, Sayaka?"  
"Huh? Um... well, I live close by... haha"  

Yesterday, workers had delivered materials and spent the whole day on setup.  
Yuu had arrived in the early afternoon to help check and organize event materials like schedules with others.  
Yuu and other male students left by 7 PM, but he'd seen many student council and committee girls including Sayaka staying late.  

There was a reason:  
While Saiei students had come to help with preparations, they left with Sairei's boys at 7 PM.  
Afterwards, they handled deliveries of equipment and ingredients for the co-ed camping event scheduled for that evening.  
These were stored across multiple locations: the management building's second floor, cafeteria kitchen, and warehouses near the second athletic field.  

Instead of Sayaka who was being evasive, Yuu looked at Riko.  
"Last night I stayed over and got home past 10.  
But Sayaka said she had documents to check and started working right after dinner. I went to bed first, so who knows how late she stayed up...?"  
"Eh..."  

Though Sayaka now looked alert, her sleepy appearance during morning greetings made sense.  
"Say-a-ka-san?"  
"Haha! It's nothing. See, I've trained since childhood, so at least my stamina is solid!"  

Yuu looked sideways at Sayaka as she laughed exaggeratedly and flexed.  
But this strong sense of responsibility was quintessentially Sayaka.  
Yuu smiled and casually took her hand.  

"Ah..."  
"Today will be long, so don't overdo it. Not that you'd listen.  
At least take breaks when you can."  
"Yuu-kun... O-okay, got it."  
Sayaka nodded shyly.  

"President and Hirose-kun really do suit each other."  
"They look like a painting together."  

Unnoticed, event committee girls were watching Yuu and Sayaka holding hands and murmuring admiringly.  
Realizing this, Yuu and Sayaka quickly separated.  

"W-well then... Seems we're done here...  
Oh! Look at the time! We should head to headquarters!"  
"Right. Representatives from other schools and the board should be arriving."  

The room clock showed almost 8 AM.  

---

"Oh my, good day everyone. What splendid weather we have today!  
It feels like an omen of our Saiei Academy High School's victory!"  

While heading to the first athletic field, Yuu's group encountered the Saiei student council emerging from the gymnasium.  
The gym had been entirely reserved for Saiei students today.  
Saiei committee members were already in gym uniforms preparing, but the student council led by Mitsuse Rinne had likely been working inside like Yuu's group.  
Officers behind her carried document bundles.  

"No. Victory belongs to Sairei Academy. You should be grateful we even allowed you on this stage."  

Sayaka stepped forward defiantly.  
Rinne and Sayaka glared at each other intensely.  

"Our assigned tasks are complete."  
"Ours too."  

Saiei vice president Li Weihui and Sairei vice president Riko exchanged terse words.  
Weihui instructed the treasurer and secretary behind her to take documents to headquarters before giving Riko a cold look.  

"Participating?"  
"Of course."  
"Looking forward to it."  
"Likewise."  

Though brief, they were clearly referring to the quiz championship.  
Meanwhile, Saiei's other vice president Omori Norika ignored the confrontation and scrutinized Yuu from head to toe.  
When their eyes met, she smirked.  
Not just the student council - nearby Saiei students were stealing glances at Yuu, particularly his lower body.  
Both councils wore uniforms, but Yuu alone wore the school's short-sleeved gym shirt and half pants.  
To these girls from an all-female school, they seemed eager to memorize the sight of a boy's bare legs.  

Suddenly aware of the attention, a flustered Yuu placed hands on the still-glaring Sayaka and Riko's shoulders.  

"Let's go. We're on a tight schedule."  
"Ah... sorry, Yuu-kun."  
"My apologies, I got carried away."  
"It's fine."  

When Yuu smiled and lightly patted their shoulders, Sayaka and Riko beamed happily.  
Though a light touch, seeing their intimacy up close made Rinne watch them leave with envious frustration.  

A large tent stood on either side of the podium: left for headquarters, right for guests.  
Among Sairei's student council, Yuu and Riko were participating in the quiz championship with same-year friends.  
Riko would have preferred partnering with Sayaka, but both schools' presidents had to oversee proceedings from headquarters and handle emergencies.  
Emi would handle administrative duties with Saiei's treasurer and secretary.  

After leaving the secretaries and treasurers at headquarters, Yuu's group proceeded to the guest tent for pre-event greetings.  
First, they met the Ayakuni Group board members.  
Sairei members still harbored resentment towards these proponents of the forced sister-school partnership, but Sayaka and Riko maintained polite professionalism.  

"My! You must be the famous Hirose-kun! Delighted to meet you!  
I'm board chairwoman Kodama Ayako!"  

Likely in her 60s.  
Her ample figure was wrapped in a light gray suit.  
Her short, slicked-back hair and hawklike eyes gave a predatory impression.  
Slightly taller than Yuu, her presence felt overwhelming - more shrewd executive than educator.  

"Good morning! I'm Hirose Yuu, a first-year helping the student council. Pleased to meet you!"  

With such people, a crisp greeting worked best.  
After a momentary surprised "Oh?", she extended her hand.  
Yuu firmly shook it - her hands were unexpectedly large.  
She whispered:  

"Nearly 20 years ago... Toyoda Sakuya was pushing for coeducation nationwide. We were one who responded.  
After various developments, Sairei became coed 10 years ago. Having you here now feels like fate."  

She gave Yuu a meaningful look.  
Her meeting Toyoda Sakuya 20 years ago wasn't strange, but she might know about Yuu's parentage.  
Yuu kept smiling without confirming.  

"Though I've only been here under four months, I'm proud to call Sairei Academy my alma mater.  
That's thanks to the teachers and seniors who built its coed foundation."  
"My! How lovely to hear!"  

Though somewhat model-student-like, the chairwoman beamed and vigorously shook Yuu's hand.  
Yuu similarly shook hands with each board member.  
After greeting both principals (who seemed more like hired managers), the chairwoman remained most memorable.  

In a corner of the guest tent stood student council members from sister schools, there for observation and assistance per board arrangement.  
Next year would feature all four Ayakuni Group high schools in Saitama, likely held in August at a rented gymnasium.  
This event served as the Ayakuni Cup's trial run.  
With additional committee members from both schools, the tent felt overcrowded.  

Per prior briefings:  
Saibo Academy, founded first in Kawagoe City southeast of Saitama City, featured standard white/black sailor uniforms with crimson ribbons.  
Focused on academics with top college placement rates, its students looked studious with long skirts.  
Saiai Academy in Ageyo City was formerly Joubu Technical High. After being acquired by Ayakuni Group, it became a comprehensive vocational school.  
Its similar sailor uniform used dark gray fabric with magenta ribbons, giving a more stylish impression than Saibo.  

"So grateful you came to observe and even serve as judges!"  
"Not at all. We wanted to experience the championship atmosphere while being useful."  
"Coed schools interacting with others is so rare! We appreciate you agreeing!"  
"Haha... indeed."  

While presidents from all four schools chatted amiably (Sayaka slightly stiffly), the room fell silent when Yuu approached.  
Riko introduced him to cover the awkward timing.  

"This is first-year Hirose-kun helping our student council."  
"Hirose Yuu. Pleased to meet you."  
"......"  
"Y-yes... likewise..."  

Saibo's president - twin braids and glasses fitting a "class rep" image - froze upon seeing Yuu.  
Saiai's president - fluffy bob cut with ample bust - managed a strained smile.  

"A b-boy! My first real high school boy (DK)!"  
"Seriously handsome! Way better than male idols on TV..."  

While Saibo's council remained frozen, Saiai's reactions were overt.  
Yuu smiled and extended his hand to Saiai's president.  

"Ah..."  

Noticing, she hastily wiped her hand with a handkerchief before shyly offering it.  
Yuu's firm handshake made her blush crimson.  
Despite being two years older, this close contact with a boy - combined with his refreshing smile - made her heart race uncontrollably.  
Others clamored to shake hands too. With over ten introductions, Yuu couldn't remember all names.  

"My first male contact since starting high school!"  
"So glad we came!"  

Amidst their excitement, Yuu approached the petrified Saibo president.  

"President, your hand..."  
"Ah! S-sorry!"  
"No worries, first meetings are nerve-wracking."  

Urged by her vice president, the Saibo president timidly extended her slender, trembling hand.  
Yuu gently enveloped it.  

"Hyaah!"  
"Hirose Yuu. Pleased to meet you."  
"H-hi! I-I-I'm..."  

Blushing crimson and stammering, she barely managed introductions.  
Her innocence made Yuu smile.  
Saibo students seemed more nervous than Saiai's - some couldn't speak properly or shake hands without Yuu initiating.  

While antisocial types or older women might leer openly, these earnest student council girls reacted differently.  
To Yuu, such innocent girls felt inherently endearing.  

Meanwhile, Sayaka and Riko nostalgically recalled their first meeting with Yuu while feeling superior about their physical relationship.  

"It's almost 8:40! Starting the opening ceremony!"  

At the announcement from headquarters, Yuu's group bowed to guests and departed.  
Everyone from sister school members to board directors stood watching Yuu leave.  

*[Announcement]*  
*'Sairei Academy and Saiei Academy students: The opening ceremony is starting. Participants please enter the track. Supporters gather around the track.'*  

"Let's go, Yuu-kun."  
"Okay. See you later, Sayaka, Emi."  
"Good luck. Yuu-kun, Riko too."  
"Watching Yu-kun and Riko-senpai's success from here!"  

Only Yuu and Riko were participating from the student council, each paired with same-year friends.  
Thus, they weren't involved in quiz content creation.  
After announcing the event in early July, questions were solicited from all students and staff - 300 per school.  
Sairei and Saiei exchanged questions, eliminating biased or inappropriate ones.  

Many students had already gathered on the field while Yuu's group was greeting.  
More were still arriving.  
Participants lined up along a white line in the 400m track's center - Saiei on the right (from headquarters' view), Sairei on the left.  
Non-participants clustered around the perimeter.  

With ~600 Sairei and ~500 Saiei students, over a thousand people created a spectacular sight.  
Most wore short-sleeved gym shirts and bloomers for mobility, followed by uniforms.  
Some wore matching printed T-shirts.  
Sports club members wore colorful uniforms - some even in kendo gear (minus masks) or judo uniforms despite the heat.  
Cheerleading squad brought pom-poms.  
Saiei even had kimono-clad students (tea ceremony/flower arrangement club?) and black skirt/white blouse ensembles (choir/band?).  
Though attire wasn't specified, club members clearly dressed to stand out, enhancing the festive atmosphere.  

Sairei wore white ribbons, Saiei red ribbons, pinned conspicuously on chests or shoulders.  

After entering the track, Yuu separated from Riko and joined the boys.  
Ten first-year boys from Class 5 were participating.  
Since his closest friend Higashino Rei declined, Yuu partnered with Yamada Masaya (3rd in class rank vs Yuu's 10th) for his knowledge.  

"Sorry to keep you waiting!"  
"Been waiting for you!"  

Houjou Haruto from the back seat in class flashed a refreshing smile.  
As Yuu greeted classmates, the opening ceremony began.  

---

### Author's Afterword

The subtitle is deceptive; it hasn't started yet.  

2020/9/16  
Changed the location of the sister schools to cities closer to Sairei Academy.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to reflect traditional Japanese gym attire
- Translated "ハーフパンツ" as "half pants" for the gym shorts
- Preserved Japanese honorifics (-kun, -san) per style guidelines
- Maintained original name order (e.g., "Kodama Ayako" not "Ayako Kodama")
- Translated "男子高校生(DK)" literally as "high school boy (DK)" since DK is established slang
- Used explicit term "co-ed camping" for "男女交流行事" per sexual content rules
- Italicized internal monologue *(This is concerning.)* for equivalent Japanese thought