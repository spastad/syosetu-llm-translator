## 129. Quiz Championship ② ~Kind Feelings~

"First, we'd like to invite Ayakuni Group Chairwoman Kodama Ayako to address us."

"Good morning, everyone."

""""Good morning!""""

"Yes, wonderful enthusiasm. Today, as if celebrating the first Ayakuni Cup High School Quiz Championship, we have clear blue skies without a single cloud. Thanks to the hard work of both schools' student councils and organizing committees during this busy July schedule, we've successfully reached this opening day. Since Sairei Academy became coeducational, I've deeply regretted the severed ties with our sister school Saiei Academy. That after 15 years, this relationship revives through a quiz championship is truly welcome..."

"As chairwoman of Ayakuni Group, I hope this opportunity deepens exchanges among all sister schools. This doesn't just mean Sairei Academy - which promotes coeducation and gentlemanly/ladylike education - but also Saiho Academy with its historical academic excellence, Saiai Academy developing essential professionals in commerce, industry, agriculture, healthcare and childcare, and Saiei Academy cultivating artistic talent. By leveraging each school's strengths and mutually inspiring growth..."

  

  

  

"W-wow, this is long."  
"Ah, really..."

Though clearly experienced at public speaking with her smooth delivery, the chairwoman's speech continued endlessly from one topic to another. Important people's speeches are universally lengthy, it seemed. Her fluid speaking style resembled easy-listening music that nearly lulled us to sleep.

'...Therefore, wishing all participants success in today's Ayakuni Cup Quiz Championship, I'll conclude my brief remarks.'

Finally over? That wasn't brief at all! This sentiment was surely shared by every listening student. Regardless, applause followed the chairwoman's bow at the podium.

Next came competition explanations from the organizing committee. Round 1 featured four true/false questions, with elimination after each wrong answer. Round 2 would be buzzer-quiz format in groups, advancing 50 teams. Rounds 3-4 featured specialized quizzes leading to the finals where six teams would compete. Faculty teams could only advance to Round 4, with finals reserved for students.

Points: 1 point per correct answer in Rounds 1-2, 2 points in Rounds 3-finals. Total school points would determine victory.

Schedule: Round 1 at 9 AM, lunch break at noon, afternoon session at 12:45 PM, ending around 3 PM with closing ceremony at 3:30 PM.

Rules prohibited coaching from spectators, excessive noise, or physical interference - violations meant point deductions or disqualification. Judges were students from Saiho and Saiai Academies.

"It's now 9 AM, so we'll begin Round 1. Blue sheets marked ○ (true) and × (false) are laid on the track. Move to ○ if the statement is correct, × if incorrect when announced. A center line has ropes that will be raised after 20 seconds. Incorrect teams must exit immediately. All four questions concern Ayakuni Group and the chairwoman - those who read the school guide or listened carefully should do fine."

"Trouble... I'm not confident at all..."

Yuu muttered with a dazed expression. Having relaxed after learning it wasn't an all-boys school, he hadn't seriously read the school guide. The chairwoman's speech was so long he'd tuned out midway. Though arrogantly confident in his adult knowledge, he faced immediate danger.

"I considered another coed school during applications, so I remember most guide content. Should be fine unless they ask obscure details," said Masaya, adjusting his glasses as usual. Yuu found him reassuring.

"P-please! You're my only hope!"  
"Jeez..."

Though not particularly friendly, Masaya always helped when asked (albeit complaining). When Yuu and Rei struggled to socialize early on, he'd bridge connections with classmates. Initially seeming cold toward girls, his smooth interactions in the brass band (mostly female) revealed him as a social adept. Unlike typical males here - either overly fearful of women or difficult personalities - Sairei's boys displayed youthful vitality. Yuu hoped more boys bonding with girls would improve society. His musings ended as Round 1 began.

'First question! Ayakuni Group operates six schools in Saitama Prefecture including junior high, high school, and junior college. True or false?'

The track buzzed instantly. Being an easy starter, most knew the answer. Sairei students surged toward ○ where Saiei students stood.

"Going straight to ○ without hesitation... Did you know, Yuu?"  
"D-don't mock me! Of course I knew!"

Though teased by Masaya, Yuu had learned this from Riko during student council work. As Saiei students made space, Sairei students flooded in. With no need for hesitation despite the 20-second limit, movement was relaxed. But cramming 300 students (150 teams) into half the track increased density.

"Push further in!"  
"Eeh? It's already packed!"  
'10 seconds left!'  
"No time! Hurry!"  
"Whoa!"  
"Kyaa!"

The push to enter ○ intensified. Sairei girls naturally shielded boys. Yuu's first-year male group got pushed from behind, crashing into girls ahead - Yuu ended up hugging Ueno Shoko from behind.

"S-sorry!"  
"...! That voice!"  
"Hey, Shoko?"  
"Y-Yuu-kun!"  
"Wow! It's Yuu-kun!"  
"Really!"

Ahead was Class 1-5. Yuu had bumped into Ueno Shoko wearing her softball uniform - purple-striped white sleeveless shirt and shorts, no number as a first-year. Nearby was soccer-team member Shimozono Kayo.

"Oh! Shoko and Kayo made it too?"  
"Yeah!"  
"Mao and Sati are here too!"  
"Whoa, they're that close?"

Tall Mao and Sati stood slightly apart. When Yuu raised his hand high, they high-fived him. Nearby girls joined in, touching Yuu's hand. Among Yuu's female classmates, only these four plus class representative Aramaki Yoshie (visible surrounded by classmates) had qualified. Mao and Sati wore club uniforms. Outspoken girls like Yoko and Kazumi must've failed qualifying.

"Um... Yuu-kun?"  
"Hmm?"  
"Shoko's face is bright red!"

Yuu remained pressed against Shoko's back. Though crowded like a packed train, Sairei's well-mannered girls avoided intentional male contact. Many apologized for accidental bumps, and boys understood without anger. Some girls even celebrated accidental male contact. Meanwhile, Yuu stayed glued to Shoko's back. Their similar heights put her nape before his face - he enjoyed her scent and butt's feel.

"Sorry. Was I too hot?"  
"N-no! Not at all. Really!"  
Shoko beamed, clearly delighted by Yuu's contact. "Glad to hear it."  
"Ah!"  
"Nn!"

Yuu wrapped his arms around Shoko and Kayo, forming a triangle. His right hand groped Shoko's lower body, left hand Kayo's. Both sportswomen had firm yet soft, springy buttocks - perfect for kneading. In the crowd, no one noticed below-waist actions. Through their shorts, Yuu molested them like a groper. "Hah, nn..."  
"Ah... fuu..."  
Shoko and Kayo shyly gripped Yuu's gym pants hem, blushing with shame yet thrilled by his touch. The time limit arrived as they lingered.

'Time's up! First question answer: ○! Ayakuni Group operates four high schools plus junior high and junior college. Amazingly, everyone got it right!'

Cheers erupted. Though some hesitated, all followed the crowd to ○ - the × side stayed empty. The real battle began now.

"Hey, something bothers me," Masaya murmured beside Yuu. "If you just follow others, won't no one get eliminated?"

A valid concern. In national quizzes Yuu referenced, unfamiliar teams couldn't copy others. But here, students could follow smart peers. Yuu had actually looked for top-scorer Riko (unfindable in the crowd).

"Later questions will be harder. They planned for this," said Yuu, who'd helped design the event despite not writing questions.

"Anyway, Round 2 cuts to 50 teams."  
"True. Okay, next question!"

'Second question! Ayakuni Group Chairwoman Kodama Ayako graduated from Saitama University. True or false?'

"What's that... Know it, Masaya?"  
"Uh..."

Even Masaya couldn't answer instantly. The speech hadn't mentioned her alma mater - only school-guide readers would know. Students murmured anxiously.

"A-at least, I think it wasn't Saitama University..."  
"Okay! I'm counting on you, Masaya!"

Some moved to ×, others hesitated. With time ticking, Yuu's group followed Masaya toward × - more chose that side.

'Answer: ×! The chairwoman graduated from Rissei University!'

Cheers and groans mingled. ○ teams dejectedly exited.

Yuu sighed in relief. *(Rissei... wasn't that an old era name? So era names become universities here? Hm... Era names...)* His gaze caught a Saiei blonde in uniform disappearing into the crowd. Something felt off - almost remembered but elusive. Frustrating.

Third question: 'The newest department at Ayakuni Junior College is the 1980-established Sociology Department International Communication Course.' Another nitpicky question requiring memorization of guide appendices or junior-college research.

Answer: ×. Many expecting ○ after ×-○-× pattern got eliminated. Though Masaya's memory failed, Yuu spotted Riko and followed her to victory. Riko was surrounded by third-years; Saiei's Li Wei Hui led another group.

After three questions, about two-thirds remained (136 teams: 69 Sairei, 67 Saiei). As students retreated to a corner, staff prepared for the fourth question - removing ○× sheets and raising a 2m+ curtain of dangling plastic strips.

'Final Round 1 question: Dive-in True/False! Teams of five start together, pass through the curtain, see the question, choose ○ or × frame, and dive in headfirst. Correct sides have mats - wrong choices face... consequences! Failure to dive in time means disqualification.'

To force individual decisions and reduce numbers (group movement minimized elimination), Yuu had proposed this format based on TV quizzes. Instead of mud (too cruel), they used dyed water. Ten questions rotated to prevent cheating.

Queued teams started when ready. The first five teams passed through - screams, relief, and laughter followed.

"Kinda tense."  
Masaya muttered, staring ahead. The curtain lifted briefly revealed a banner question - unreadable and changing per team. Yuu's group was fourth in the boys' queue. Beside them, Saiei girls in "SAIEI VICTORY!" shirts and miniskirts looked equally nervous.

"Count on you, Masaya. Let's reach Round 2."  
"Hey... You think too, Yuu."  
Yuu grabbed Masaya's shoulders, getting a sidelong glare. "Haha... Well, depends on the question." Yuu dreaded getting soaked.

The queue advanced swiftly. At the starting line: "On your marks... go!" A whistle sent them running - not racing (avoiding advantage), but maintaining similar speeds while parting the curtain. The question appeared:

'Ayakuni Group's predecessor, Ayakuni Education, first established a school in 1962: Ayakuni Academy High School. True or false?'

"Know it?"  
"Know Ayakuni was first, but not the year..."  
"Hmm..."

Trust it or suspect a trick? While hesitating, an organizer counted down: "Dive in five seconds! 5,4,3,2,1... now!"

"Probably no trick."  
"Okay, ○!"

Yuu and Masaya dashed together, diving through the ○-marked screen slit onto gym mats.

"Phew... Made it through Round 1. Nerve-wracking."  
"Totally."

Relieved on the mats, they headed to the waiting area when screams erupted.

"Hyah! I-I can't swim!"

The Saiei girls beside them had chosen wrong. The truck-bed-sized tank held red-dyed water - both thrashed waist-deep but panicked. Yuu stopped and reached toward the tank edge.

"Calm down. Here, take my hand."  
"Huh? A b-boy!?"  
"Wah!?"

Resembling sisters with short hair and small stature, the nearer girl desperately grabbed Yuu's right hand and stood. "Ahh! Not just my sister - me too!" The other took Yuu's left hand.

"Th-thank yooou!"  
"Don't mention... it!?"

Yuu realized: soaked through, their white shirts clung transparently - nipples visible, skirt panty lines exposed.

*(Ooh, lucky pervert moment!)* Only Yuu in this world would think so. Oblivious to exposure, the girls kept holding his hands until organizers sharply separated them.

"No need to be that nice to Saiei girls... You're weird, Yuu. Expected though."  
"It was after their round. Part of school exchange."

Though having issues with Saiei's student council and wanting victory, Yuu couldn't ignore girls in distress.

  

  

  

Round 1 results: 136 teams advanced (69 Sairei, 67 Saiei). Total points: 422-414, Sairei leading by 8.

Quizzes typically favor academic schools - Sairei's ordinary course (excluding boys) has ~10 higher deviation value. But Round 1's Ayakuni-specific questions minimized advantage. The real contest begins with general knowledge in Round 2, Yuu thought.

  

  

  

  

  

---

### Author's Afterword

Originally planned as preliminary ○× quizzes, these became Round 1. Post-publication, remaining "preliminary" references were corrected to "Round 1."

2019/10/20  
"Finals narrow to 5 teams" → corrected to 6 teams.  


### Chapter Translation Notes
- Translated "貞操逆転世界" as "Chastity Reversal World" per fixed title reference
- Preserved Japanese honorifics (-kun for Yuu, -san for Kodama Ayako)
- Maintained Japanese name order (e.g., Ueno Shoko, Shimozono Kayo)
- Translated sexual terms explicitly ("groped," "molested," "nipples visible")
- Transliterated sound effects ("Kyaa!" for きゃっ, "Hyah" for ひゃあっ)
- Italicized internal monologues *(Ooh, lucky pervert moment!)*
- Used gender-neutral "organizer" for 実行委員 when gender unspecified
- Translated academic terms precisely ("deviation value" for 偏差値)
- Preserved specialized terms per Fixed Reference (Saiei Academy, Ayakuni Group)
- Applied dialogue formatting rules: new paragraphs for each speaker, simultaneous quotes for group responses
- Translated culturally specific "飛び込み○×クイズ" as "Dive-in True/False" with explanatory description
- Rendered anatomical terms directly ("buttocks," "nipples," "panty lines")