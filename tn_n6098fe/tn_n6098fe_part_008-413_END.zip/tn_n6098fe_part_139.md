## 130. Quiz Championship ③ ~In the Sun and Dust~

The second round divided the 136 teams into 12 groups with roughly equal numbers from Sairei and Saiei Academies. 

The groups were split into first and second halves, with six circles approximately 5m in radius spaced at appropriate intervals along the track lines. 

Competitors sat outside the white lines of each circle. 

A single desk and small speaker stood in the center of each circle, staffed by an executive committee member holding a booklet of questions and a microphone. 

Judges watched for rule violations outside the competitor area.

The executive committee member would read a question, and upon figuring out the answer, teams would dash to press the answer button on the desk. 

Winners would whisper their answer to the committee member, and if correct, receive a beanbag like those used in ball-tossing games. 

Teams advancing to the third round would be determined when they collected three beanbags and delivered them to the staff at the track center. 

The first and second halves would each advance 25 teams (50 total), eliminating nearly two-thirds of participants in this harsh competition.

Yuu was in the first half group, so he headed to his assigned circle and sat down with Masaya. 

They competed against 11 other teams - all female except Yuu and Masaya's pair. 

Though no familiar first-years were present, Yuu recognized some second-years who'd greeted him outside earlier. A young female teacher from Sairei also competed in one pair. 

As the only male team, they received unusual attention.

Until moments before, cheers from outside the track had enthusiastically supported both schools. 

Both male and female voices cheered especially for Yuu and Masaya, who waved back embarrassedly. 

But when the announcement from headquarters began, silence fell instantly.

*'After starting, teams failing to gain answering rights must temporarily return outside the white line.*  
*If an answerer gives an incorrect response, other teams get another chance to compete for answering rights.*  
*After the signal, executive committee members will read questions. You may answer before hearing the full question, but listening completely improves accuracy. Begin now.'*

A whistle *Piiit!* sounded just as the committee member before Yuu read a question:  
*'Japan's first prime minister was-'*

Several teams nearly dashed out but stopped.  
Simultaneously, Yuu nearly clicked his tongue in frustration.  
While generally good at history, he had zero confidence about names from the modern era onward due to drastic historical changes after the Red Death pandemic.  

The question continued:  
*'Tokugawa Sadako, but the third one was-'*

*Pon!* A tap on his shoulder - Yuu and Masaya dashed out.  
They'd have to rely on Masaya's knowledge.  
But Saiei Academy's gym-uniformed pair reached the button first - they'd dashed at "third," their decisiveness paying off.  

One whispered the answer to the committee member, who raised a red flag.  
"Correct!"  
(Red flags indicated Saiei wins; white flags were for Sairei.)

"Got beaten..."  
"Too cautious and you lose, but rushing risks mistakes. Tricky to gauge."

*'Next question: The saying "as fickle as a man's heart and autumn sky" refers to-'*  
(Here it was "man's heart" instead of "woman's heart," likely reflecting women's aggressive pursuit of men.)  
*'Clouds commonly seen in autumn that-'*  
At this point, another group had teams dashing out, but most in Yuu's circle kept listening.  
*'Indicate approaching storms.'*  
Yuu's team dashed.  
This time, a Sairei uniformed pair pressed first.  

But the committee member declared it wrong.  
Yuu's team sprinted back from the white line and secured the button.  
When Masaya gave a questioning look, Yuu nodded - it was half a gamble.  

"Y-your answer please?"  
The female student committee member couldn't hide her tension as Yuu approached.  
A Sairei second-year in green-trimmed gym clothes, her hair in a ponytail revealed small ears.  

Yuu leaned close to her ear:  
"Altocumulus clouds (kensekiun)."  
"...Nghaa!"  
His breath in her ear made her shiver.  
But after checking her booklet, she raised the white flag.  
"Co...correct!"  
"Got it!"  
Yuu remembered this from middle-school review materials.  
*Pan!* He high-fived Masaya triumphantly.

After eight more questions, the first Saiei pair advanced with three wins.  
By the 10th question, Yuu's team had two wins (one needed), but watched another pair advance during three subsequent questions.

"Getting dangerous."  
"Yeah, that last win feels far."

About ten teams had already gathered at the track center.  
Currently, only Yuu's team and one other were at two wins in their group.  
They desperately needed advancement.  

On the 15th question, they won answering rights but answered wrong, while the Sairei teacher pair got their first win, jumping for joy uncharacteristically.  
Yuu could only watch the bouncing chest of the T-shirt-clad teacher.

*'16th question. Eh...?*  
*Who came up with this...?'*  
The committee member looked shocked at the booklet.  
"Just read it!" someone shouted - teams were growing anxious as others advanced.

*"O-okay... Reading now:*  
*The bone around here is called the tailbone.'*  
She pointed above her bloomer-covered buttocks.  
Then spreading her legs shoulder-width, she pointed to her crotch: *'This area's-'*  
Yuu dashed out instantly.  
Two other teams followed, but Yuu was fastest.  

The red-faced committee member gazed up at Yuu as he pressed the button, looking like she awaited a love confession.  
Yuu approached head-on, placing his right hand over hers (still at her crotch) while leaning close.  
As she reflexively closed her eyes, he whispered in her ear:  
"That's... the pu.bic bone!"  
"Ahfue!"  
"Whoa!"  
His breath made her knees buckle - Yuu supported her waist.  
"Correct?"  
"Y-yes... c-correct..."  

She managed to raise the white flag and handed Yuu a beanbag.  
"G-good luck next time, Hirose-kun."  
"Ah... thanks. And good work."  
When she whispered encouragement while handing him the beanbag, her smiling face made Yuu stare, captivated:  
*(She's cute!)*  
He lingered, reluctantly crafting a brief reply.  

Yuu had no memory of speaking with her before.  
Sairei Academy truly selected for looks during admissions.  
Countless attractive girls apparently existed whom Yuu hadn't met yet.  
Such events overflowed with the joy of encountering them.  
*(Should've asked her name...)*  
Prodded by Masaya's exasperated look, Yuu ran toward the track center thinking this.

Ultimately, Yuu's team advanced 20th in the second round.  
Missing that question would have meant elimination - a close call.  
Incidentally, among the winners was Saiei student council vice-president Li Wei Hui, who muttered "Unexpectedly good for a boy" upon seeing Yuu, looking impressed.  
Only Yuu's team represented males in the first half's 25 winners.  
A third-year male pair advanced in the second half, making just two male teams among 50.  

After the second round, Sairei and Saiei were tied at 25 teams each.  
The total score narrowed to 596-592 in Sairei's lead, overturning Yuu's predictions.  
However, among advancing faculty teams, Sairei had just one pair versus Saiei's four out of five entrants.  

Teachers naturally knew their specialties but had uneven general knowledge.  
Suspicions arose that Saiei had recruited quiz-show enthusiasts instead of actual teachers.  
Even if verified as "temporary faculty," this exploited a rule loophole since only "enrolled students/faculty" could compete.  
Future events would require minimum enrollment periods to prevent ringers.

"Getting hot, huh."  
"Yeah, feels like real summer now."

During third-round preparations, advancing teams rested in large school-divided tents.  
It was past 11 AM, with intense sunlight pouring from the midday sun.  
They gratefully drank distributed cold tea.  
Staying still in the shade felt slightly cooler at least.

Yuu and Masaya naturally clustered in a corner with the third-year male pair.  
Riko had apparently advanced too - they exchanged smiles and waves.  
Since she was surrounded by third-years, Yuu didn't approach.

"That's Hanmura Riko, the top third-year, right? You're close?"  
"Yeah, student council together."  
"Huh... Wait, isn't that Iida-senpai, literature club president, with her?  
Those two teaming up makes them Sairei's top contenders."  
"Oho. You know a lot."  
"Hmm, met at the library a few times."

Yuu wasn't alone in cross-grade female connections - Masaya had them too.  
Yuu privately envied how Masaya bonded with senior girls through clubs and library visits - a humanities-track social success.  

Incidentally, Riko was with a plain-looking girl resembling protection officer Touko, with a bob cut and thick glasses - the classic bookworm type who'd excel here.  
The third-year seniors beside them - contrasting skinny and heavy builds - also seemed otaku-ish.  
Perhaps introverted, they only smiled vaguely when Yuu or girls spoke to them.

*'Third round starting now!*  
*Like before, split into first/second halves. First half's 25 teams assemble before headquarters!'*

"Let's go!"  
"Right!"  
As Yuu stood to leave the tent, he locked eyes with Riko.

"Good luck, Yuu-kun!"  
"Yamada-kun, do your best!"  
"Show Sairei boys' spirit!"  
"Let's advance to round four together!"

Teams from the later half cheered.  
Yuu exchanged high-fives with Riko and other girls.  
Following suit, Masaya did the same.  
"We expect great things."  
"Senpai, do your best too!"  
When Yuu and Masaya responded, the girls waved goodbye, visibly delighted.

Three desks stood before the podium, with Sairei and Saiei groups separated on either side - likely accommodating the sole male team per half.  
Saiei girls stared unabashedly - even Yuu noticed their blatant crotch-gazing.  
While Sairei girls showed maidenly reserve through etiquette training, Saiei girls displayed unconcealed lust with openly lecherous attitudes.

*'Explaining third round rules:*  
*This is a "Scatter Quiz." Cross obstacles along half the track to retrieve one envelope scattered inside the soccer goal opposite.*  
*Then cross the track to deliver it to the executive committee at the podium desks.*  
*Envelopes contain question papers, but 20% are "duds" - retrieve another if you get one.*  
*While answers are per team, one member may retrieve envelopes.'*

*'Questions include "World's Three Great ○○?" or "Name three examples of ○○." You may answer one/two/three items or give up early to retry.*  
*Each correct answer earns a stamp on your card. Five stamps mean advancement.*  
*First/second halves each advance 10 teams (20 total) to round four.'*

Runners waited at the starting line before the podium, facing away from the opposing school.  
Waiting members like Masaya clustered inside the track.  

The third round began.  
With scores close, cheers from both schools felt more intense.  
Especially for Yuu - shrill cheers concentrated on him.

""""Hirose-kun!""""

Yuu smiled and waved at the coordinated cheers, eliciting squeals.

"Eeeek! His smile's gorgeous!"  
"So handsome!"  
"Ahh, if only I'd advanced to get closer..."

Even among Sairei runners near Yuu, several girls whispered:

"L-let's do our best! Hirose-kun"  
"Hope we advance together"  
"Yes! Let's all advance here and widen our lead!"

Though mostly unfamiliar second/third-years, they were comrades in this school rivalry.  
Yuu subtly high-fived nearby senior girls.  
This oddly motivated the surrounding females.

---

### Author's Afterword

I wanted to cover the third round, but it got longer than expected - continued next chapter!

2018/10/17  
Changed "dud" rate from 1/3 to 20%.

### Chapter Translation Notes
- Translated "尾てい骨" as "tailbone" and "ち・こ・つ" as "pubic bone" using direct anatomical terms
- Preserved Japanese honorifics (-kun, -senpai) per style rules
- Transliterated sound effects: "ぽん" → "Pon", "ぴーっと" → "Piiit", "あふぇ" → "Ahfue"
- Maintained original name order (e.g., "Li Wei Hui" not "Wei Hui Li")
- Rendered internal monologue *(可愛いっ！)* as *"She's cute!"* in italics
- Translated "バラマキクイズ" as "Scatter Quiz" matching Fixed Reference term
- Used explicit term "bloomers" for "ブルマー" as culturally specific gym attire