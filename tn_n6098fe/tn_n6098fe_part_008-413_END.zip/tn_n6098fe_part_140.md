## 131. Quiz Championship ④ ~Guts!!~

"On your marks…… get set…"

Paaaaaan!

With the same pistol starter crack used for footraces, 25 competitors from Sairei and Saiei Academies simultaneously dashed forward from their divided positions.

Thanks to being given space in the front row, Yuu succeeded in a sprint start and cleared the first obstacle—hurdles—alongside the leading group. Next was a 2m-high triangular hill made of plywood with about a 45-degree incline. Though five ropes hung down, with enough momentum one might clear it without them.

The first to dash out was a girl in a white tank top and purple shorts. With short hair and modest height, her exposed skin was tanned bronze. Likely from the track team. Mesmerizing with her beautiful form, she pulled ahead of Yuu and effortlessly scaled the slope—tap, tap—placed her hands on the peak, and disappeared over the other side. Yuu similarly cleared the slope without ropes, lightly kicking off the opposite incline as he jumped down.

The gap was about 2 meters. She glanced back, noticed Yuu close behind, and flashed a challenging smile. Yuu's competitive spirit ignited as he desperately chased after her. Had he still been middle-aged, he'd never have considered running seriously on such a hot day. But his 16-year-old body moved with unexpected lightness. Current Yuu found genuine joy in running through the wind.

The third obstacle was a cardboard tunnel. Five tunnels sat side-by-side, each about 2m long. Yuu dove in low. But the leading girl, petite and slender, slipped through quickly. By the time Yuu emerged, she'd already sprinted away, widening the gap.

*(I'm no match for her.)*

Though Yuu's current body had excellent athleticism and consistent training, it couldn't match girls who dedicated themselves daily to club activities. She was clearly exceptional at running. Indeed, she approached the final obstacle—a net spread before the soccer goal—faster than any Saiei competitor arriving from the opposite side.

Two blue tarps from the first round lay beneath the rectangular net, staked at four corners like a soccer goal enclosure. Two judges in Saibou uniforms stood beside the goal.

After crawling through the net, competitors needed to grab an envelope from the pile inside the goal, crawl back out, then sprint across the track to the executive committee. As Yuu crawled through, she was already grabbing an envelope to exit.

"I'm first!"  
Meeting Yuu's eyes while crawling on all fours, she smirked mischievously.  
"I'll catch up right away!"  
Yuu retorted defiantly, grabbing the nearest envelope and trying to escape the net. Just then, Saiei competitors entered from the opposite side, with the 2nd and 3rd place runners inexplicably heading toward Yuu—likely hoping to grope him in the chaos. Yuu deftly dodged reaching hands and wriggled free. When he looked forward, she was already 10m ahead. Though momentarily mesmerized by her toned, muscular legs, Yuu immediately kicked off in pursuit.

"Fast work!"  
"Though not first place!"

Yuu handed the envelope to Masaya who'd been waiting. Since the middle of three desks was occupied by the leading girl and her partner, they went to the left desk. The committee member unfolded the white paper and read aloud:

"Question: Name the works generally considered Beethoven's three great piano sonatas. Alternate interpretations acceptable."  
"Huh?"

The classical music question caught Yuu off guard—this had to be from Saiei's music students. But he had a reliable ally. Masaya pushed up his glasses and smoothly answered:  
"Piano Sonata No. 8 'Pathétique', No. 14 'Moonlight', and No. 23 'Appassionata'!"  
"C-correct! Three questions cleared!"

"Masaya... I've never been happier to have you as my partner."  
"Fufun. Didn't expect this question, but... lucky me. I've actually played the third movements of 'Pathétique' and 'Moonlight'."

Masaya's card now bore three "Excellent" stamps, making him prouder than usual.  
"With luck we'll clear next round. I'm going now!"  
"R-right! Be careful!"

But things didn't go smoothly. Yuu's second envelope contained a "dud."  
"Getting it on the second try... damn."  
Drawing a "dud"—present in only 20% of envelopes—on the second attempt was unlucky. As Yuu slumped dejectedly, Masaya patted his shoulder.  
"Tired? Should I go next?"

Grateful for the concern, Yuu shook his head. His reborn body—strengthened by daily training—wouldn't tire from two half-track sprints. Plus, sending Masaya into that female-dominated space felt irresponsible despite his growing confidence.

Three winning pairs already waited at the goal area. More might clear the five-question requirement any moment. They had to hurry. Yuu dashed from the start line for the third time. By the third lap, the group had thinned considerably. After clearing the first hurdle and second hill, he caught up to a chubby girl lagging behind.

*Pat* He smacked her ample buttock.  
"Hang in there!"  
Recognizing Yuu, she blushed and mumbled as he waved and passed her.

At the cardboard tunnel, two girls were entering while two crawled through. Yuu deliberately took the outermost empty tunnel, crawling behind a bloomer-clad rear.

"Ugh... this is..."

The net before the soccer goal teemed with over ten competitors from both schools crawling for envelopes. Most boys would lack courage to enter. But Yuu welcomed this chance for bold physical contact.

"Excuse me~"  
"Eh!?"  
"No way!"

Without waiting for space, Yuu pushed through. To his right, a uniform skirt had ridden up fully revealing polka-dot panties. To his left, bloomers dug into buttocks exposing white underwear. Though erotic, he didn't stare, sliding between them. Girls on both sides gasped at his intrusion but seemed amused by the unexpected accident. Pressed against both, he crawled forward until congestion halted progress—competitors entering and exiting created gridlock. Saiei's side faced similar congestion.

With no progress, Yuu slid beneath a uniformed girl crawling toward him on all fours. As he stretched for an envelope beneath her, someone grabbed his left ankle and pulled, making him lose balance.

"Whoa!"  
"Kyaan!"

Panicking, his left hand grabbed the girl's thigh above him, leaving him supine in a sixty-nine position. His face pressed against shorts-covered buttocks, seeing striped white-and-blue panties through the gap. When he lifted his head, his nose pushed against her crotch. He smelled feminine sweat—not unpleasant.

"Eek! What're you doing!?"  
"Ugh, sorry!"

Though not intentional, Yuu apologized for his roughness—though internally thrilled at the lucky pervert moment.

"A-a boy!"  
"F-fuhoo! Th-thighs... such muscular thighs!"  
During the struggle, her half-pants had ridden up to her knees. Saiei competitors noticing Yuu swarmed, reaching for his legs, stomach, and chest.

"Tch!"  
Normally he'd grope back, but he needed to hurry. Trapped beneath the girl in the crowded net, with multiple hands grabbing his limbs, he couldn't move.

Peeeeeeep!  
"Grabbing and not releasing is against rules! This is point deduction territory!"

The saving voice came from a judge outside. Even Saiei competitors reluctantly released him with disappointed looks. The girl above moved forward, freeing Yuu.

"Hirose-kun!"  
"Over here!"

Saiei girls—one in uniform, one in bloomers—reached out. Yuu grabbed their hands and pulled himself away from the crowd. With their help, he escaped the net.

"Thanks. You saved... whoa!"  
"Ah, careful!"

Distracted after escaping, Yuu stumbled. Both girls caught him.

"Th-thank you."  
"Y-you're welcome!?"

Yuu pulled them close. Their sweat-dampened skin felt soft through thin fabric, nearly arousing him. Meanwhile, the pigtailed uniform girl and short-haired bloomer girl both blushed beet red at Yuu's proximity.

While Saiei girls groped opportunistically, Sairei girls extended helping hands—a stark contrast in attitudes toward boys. Hoping this contact sufficed as thanks, Yuu tried to hurry off. But a girl blocked his path—the uniformed one from earlier.

"Hey, you! What was that earlier!?"  
"Ah."

The girl he'd been sixty-nining with glared angrily. On closer look, she was the boyish track athlete who'd led the first lap. Her tank top had slipped, revealing a white sports bra unnoticed—her chest notably flat.

"You suddenly slid under me then shoved something hard in my face!"  
"Ah—honestly, my bad."  
"Seriously!"

He'd gotten semi-erect while smelling her through the fabric. Her tomboyishness felt refreshing, and she was quite cute. As she ran off, Yuu chased.

"Let me make it up to you! At least tell me your name!"  
"Hayakawa! Second-year PE course!"  
"Hayakawa-senpai, huh? I'm first-year Hirose."  
"I-I know that!"

Blushing, Hayakawa-senpai sprinted at incredible speed, leaving Yuu behind.

"Seemed... eventful."  
Masaya wore genuinely sympathetic expression when Yuu returned.  
"All good. Pray this isn't a dud."  
Yuu smiled brightly, joining the shortest line before committee desks.

"Reading the question."  
First relief: not a dud.  
"Name up to three assassinated U.S. presidents. Answer with first and last names."  
"Wha..."

Modern history—Yuu's weakness. In his known history, he could name two:

"Uh... JFK and Lincoln..."  
"That doesn't count as an answer."  
"Know any, Masaya?"  
"Um... right! Kathleen Kennedy!"  
"Correct. Others?"

This world apparently had an assassinated Kennedy. But Masaya stalled.

"Hmm... Johnson? Ford? No..."  
"P-please, Masaya!"

Needing just one more correct answer was frustrating. Yuu couldn't help with unfamiliar modern history.

After three minutes, Masaya surrendered.  
"Sorry."  
"Don't be. I couldn't answer either. We'll get the next one. If it's a dud, my bad."  
"Yuu..."

Many winning pairs already gathered at the goal area. The third lap had taken too long. But since no final whistle blew, hope remained.

Lashing his tired body, Yuu sprinted from the start. His pace had slowed. But Sairei students cheered loudly, propelling him past three obstacles toward the goal net. With fewer winners, the net seemed less crowded.

As Yuu lifted the net to crawl through, a Saiei competitor smirked lewdly—prioritizing harassment over competition. Just as Yuu grabbed an envelope from the far end, the merciless whistle blew.

Peeeeeeeeep!  
"The tenth advancing team is decided! First half of third round concluded. Lunch break begins—all competitors exit the track immediately."

"Aah... just one more question!"  
A nearby Sairei uniformed girl—the pigtailed one from earlier—slumped dejectedly.

"Fancy meeting. We needed one more too. So close."  
"Huh!? A-ah, Hirose-kun..."

Sitting by the dwindling envelopes, Yuu took her hand. She hadn't noticed him until then—and blushed recalling their earlier embrace.

"Um..."  
"Too bad, Hirose-kun."

Sairei girls in gym uniforms gathered around Yuu—fellow eliminators. Sweaty and dirt-stained, one girl's bloomers were blackened from falling. But these were badges of effort, not dirt to Yuu.

"Yeah. Same to you. Let's cheer hard this afternoon."

Standing, Yuu casually patted their shoulders. Just being near and touched by the school idol made everyone beam.

"Ah—my uniform's filthy?"  
"Y-yeah... my bad. Should've worn gym clothes."

Yuu brushed dirt off her lilac skirt—surreptitiously enjoying her soft buttocks. Though sexual harassment normally, she seemed rewarded.

"H-Hirose-kun, your back's dirty too?"  
"Can't reach—mind brushing it off?"  
""Seriously!?""

Flustered but eager, girls reached out. Yuu freely touched chests and buttocks through uniforms. They seemed delighted.

Yuu noticed attention from across the net—Saiei's group and the two Saibou judges.

"Judges, thank you for your work."

Yuu addressed only the judges, ignoring Saiei. Though he welcomed female contact, this wasn't the time or place.

Startled by the address—plain, serious-looking girls—they stammered:  
"N-no... just doing our job."  
"Y-yes! Couldn't ignore a boy being attacked..."

Had they not intervened, harassment might've escalated. Yuu genuinely appreciated their professionalism.

After the afternoon session, the third round results showed 10 advancing teams each from Sairei and Saiei. Though tied again, Saiei led overall 758 to 756. Notably, Saiei's faculty teams advanced twice versus Sairei's zero, compensating for student performance.

---

### Author's Afterword

・Concept for tomboy track athlete Hayakawa: Her mother desperately wanted a boy, pursuing men until conceiving—only to have a girl. Unable to accept it, she raised her as a boy. But the child grew into a rambunctious, athletic girl completely unlike this world's delicate boys. Though the mother gave up treating her as male, the child kept using "boku" (I, masculine) and still does.

・Explanation: After writing, I realized Beethoven (18th century) would have extremely low probability of being male in this male-depleted world. Therefore, consider Beethoven female here—perhaps named Luisa or Luise. For example, "Moonlight Sonata" could be composed by female Beethoven yearning for an aristocratic boy.

### Chapter Translation Notes
- Translated "ガッツだぜ" as "Guts!!" to convey fighting spirit/enthusiasm
- Preserved "boku" pronoun for Hayakawa to maintain character's masculine speech trait
- Translated "ボクっ娘" as "tomboy" to capture masculine female archetype
- Rendered "シックスナイン" as "sixty-nine position" for anatomical accuracy
- Kept "senpai" honorific for Hayakawa as per translation rules
- Transliterated sound effects (e.g., "Paaaaan!" for starter pistol)
- Used explicit terms like "semi-erect" and "crotch" per content guidelines