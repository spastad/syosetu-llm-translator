## 132. Quiz Championship ⑤ ~Seesaw Game~

### Author's Preface

At the end of the previous chapter, I added a scene where Yuu thanks the Saiei Academy student who served as a referee after his elimination in the third round.

The overall flow remains unchanged.

---

The fourth round was an alternating advance quiz.  
Like the previous rounds, it was divided into first and second halves.  

Here, answers were given individually rather than as pairs. A correct answer allowed advancement to the next white line.  
Reaching the third white line meant clearing the stage, but both members of a pair needed to reach it.  
In other words, each person needed to answer three questions correctly, making this particularly challenging for pairs who had relied heavily on one member.  
Here, the ten teams from each half were reduced to three teams each.  

Ultimately, Sairei Academy advanced three teams and Saiei Academy three teams, but one pair consisted of faculty members. Following the pre-established rule that faculty couldn't advance to the finals, they withdrew here with no replacements.  
The total scores were perfectly tied at 802-802.  
Thus, the outcome of the inter-school competition would be determined by the final round.  

The final stage was set up in front of headquarters.  
Five desks wrapped in white cloth were lined up side by side, mimicking a quiz show format, with answer buttons placed on each desk.  
The contestants sat on pairs of chairs, waiting for the final to begin.  

Facing the contestants was a movable whiteboard with nine large squares.  
Each square contained a quiz category—History, Economics, Science, Linguistics, Literature, Music, Art, Theater, Sports.  
This was a panel selection quiz, with nine difficult questions prepared.  
Rankings would be determined by points earned here.  

With the faculty pair withdrawn, Sairei Academy had three teams (including Riko) versus Saiei Academy's two teams (one being Li Wei Hui). This also became a showdown between both schools' vice presidents.  
Given the difficulty of the questions, numbers might not matter much.  

Until just before the final began, both schools enthusiastically cheered.  
With the competition so close, everyone desperately wanted victory for their school.  

"Now then, we shall begin the final round.  
The pair winning rock-paper-scissors will choose the first category, and we'll present the question.  
The correct pair earns 2 points and gains selection rights for the next category.  
If incorrect, it's minus 1 point, and the other four pairs can buzz in."  

Getting the first correct answer was ideal, but avoiding answering was safer without confidence.  
Rock-paper-scissors gave the first selection right to a Sairei Academy pair.  

"Then... Economics."  
"Now for the economics question.  
In Keynesian economics, the IS curve shows combinations of national income and interest rates, while the LM curve shows money demand and supply. Analyzing a closed economy with these is called the IS-LM model.  
What is the model called when the IS-LM model is expanded to an open economy system that considers external sectors?"  
"Ugh..."  
"Mmm..."  

Even Yuu, who was listening, didn't know. Everyone around looked dumbfounded.  
This might be essential knowledge for university economics majors.  
But for ordinary high schoolers, knowing Keynes's name and basic theory would be impressive enough—detailed knowledge was beyond them.  
Not only the pair who chose the category—third-years in uniforms who looked smart—but the other four pairs also seemed unable to answer immediately.  
Some had completely given up, while others put hands to their foreheads in deep thought or muttered while digging keywords from memory.  
Each question had a one-minute time limit.  
One minute feels surprisingly short in such situations.  

"30 seconds remaining."  
"20 seconds."  
"10, 9, 8, 7..."  
*Ping-pong!*  

Riko pressed the answer button.  
She seemed to have remembered at the last moment, her expression clearing.  
"Mundell-Fleming model."  
"C-correct! Sairei Academy's Hanmura-Iida pair earns 2 points!"  

"Yesss!"  
Yuu was the first to stand and praise Riko.  
A moment later, cheers erupted from Sairei Academy students—both male and female—with thunderous applause.  

Next, Riko chose the Literature category.  
"We'll now read a *waka* poem from the *Manyoshu*. Please identify the author.  

*Tsunehito no / Koi to iu yori wa / Amari nite / Ware wa shinu beku / Nari ni tarazu ya*  
※Paraphrase: Beyond what people call "love"—I'm now so in love I could die.  

This time, answers came quickly.  
The buzzers seemed pressed almost simultaneously, but Saiei Academy's pair was slightly faster.  
Li Wei Hui's partner apparently pressed it.  
"Ōtomo no Sakanoue no Iratsume."  
"Correct! Saiei Academy's Li-Shiroshima pair earns 2 points!"  

*Ooh!* Both schools murmured, but while cheers rose from Saiei Academy, disappointed sighs came from Sairei Academy's side.  
This was especially frustrating since Iida-senpai, Riko's partner, was the literature club president—this was her specialty.  
Riko comforted her as she looked down in visible frustration.  
Vice President Li's pair clearly deserved their place in the finals.  

Afterwards, questions were answered one by one, with Sairei and Saiei Academies locked in a seesaw battle, the lead shifting by 1-2 points (incorrect answers meant minus 1 point).  
After eight questions, the scores stood as follows:  

Sairei Academy's Hanmura (Riko)-Iida pair: Two correct answers, 4 points.  
Saiei Academy's Li-Shiroshima pair: Also two correct, tied at 4 points.  
Sairei's other pairs: One correct and one incorrect each, 1 point each.  
Saiei's other pair: Two correct and two incorrect, 2 points.  
The total scores were tied at 808-808.  
The school competition would be decided by the final question.  

"Now... the last category: Linguistics.  
The origins of the Japanese language we speak daily have various theories and remain linguistically unconfirmed.  
Among these, which language family shares phonological similarities and partial basic vocabulary parallels with Japanese, despite differing in grammar and morphology?"  

When the question was read, one pair each from Sairei and Saiei Academies gave up immediately with resigned expressions.  
After looking up in thought, Sairei's other pair also slumped dejectedly.  
Only Riko and Wei Hui's pairs were seriously thinking, intense expressions on their faces.  

Honestly, Yuu had no idea.  
All students from both schools fell silent, time crawling by in a prayer-like atmosphere.  
Even guessing risked a point deduction.  
With both individual rankings and the school victory at stake, caution was essential.  

"30 seconds remaining."  
Amidst the breathless silence, only the announcer's voice marked the time.  

"20 seconds."  
Riko and Wei Hui's pairs looked down with fingers to foreheads or muttered upward, desperately thinking.  

"...Uh, 10 seconds. 9, 8, 7, 6, 5, 4, 3, 2, 1... Zero!  
No answers were given within the time limit...  
Um, does anyone know?"  
Riko and Wei Hui shook their heads in unison.  

"Wh-what should we do?"  
The organizing committee announcer panicked.  
Answers had always come within time limits before.  
The pressure of the deadlocked competition might have affected the finalists.  

"P-please wait as we deliberate."  
It seemed the student council presidents from both schools would confer at headquarters.  

Ten... fifteen minutes passed since deliberations began.  
As time dragged on, murmurs spread among both schools' students.  

"Will they go into overtime in situations like this?"  
"Hmm... If that was planned from the start, maybe. But I doubt they anticipated a tie."  

Yuu was in the first-year male section.  
Though part of the student council, he'd mainly stayed here after elimination, only briefly visiting headquarters where Sayaka and Emi were stationed.  

Everyone around wondered how the outcome would be decided.  
As part of the planning team, Yuu suspected Masaya's guess was close.  
There were backup questions from the public submissions.  
But he'd heard the final's difficult questions were specially created by teachers from both schools.  
They might not have extras ready.  

The close competition had created more excitement than expected among participants and supporters.  
But no one anticipated a deadlock until the very end—a first-time oversight.  
The clock showed nearly 3 PM, the scheduled end time.  

After about twenty minutes of deliberation, the announcer returned, looking more fatigued—likely from heated discussions.  

"Um, we announce the deliberation results.  
Normally, we'd proceed to overtime to decide the winner...  
But headquarters hadn't anticipated such a close final and made no preparations for suitable overtime questions.  
Preparing now would take too long for a satisfactory final. Thus, we end the final here.  
For the inter-school competition, with scores tied at 808-808, we declare both schools winners."  

A murmur mixing surprise and expected sighs arose, including some dissatisfied voices.  

"Let's give a big round of applause to the five pairs who reached the finals!"  
As the announcement finished, applause came from the guest seats, spreading like thunder through both schools' students.  

With time short, general students helped hastily dismantle the final stage.  
Students from both schools gathered on the field like at the opening, and the closing ceremony began.  
The Ayakuni Cup trophy, provided by the board, had ribbons with both Sairei and Saiei Academies' names.  
It would be displayed at Sairei's management building first, moving to Saiei after six months.  

Individually, Riko and Wei Hui's pairs tied for first place.  
All five finalist pairs received prizes: vouchers for luxury restaurants, department stores, and bookstores based on ranking.  

As for the school victory privilege, the draw meant both schools' wishes would be granted—likely the only acceptable outcome.  
Compared to the opening, the closing ceremony ended quickly due to cleanup duties.  

After the ceremony, Saiei Academy students immediately rushed toward Sairei's male students—they'd prepared invitations to their August open campus.  

Saiei Academy apparently held several open campus events during summer break.  
Their arts course performances were particularly renowned.  
They planned to invite Sairei's male students to one session.  

"Please come on August 3rd!"  
"We'll hire security to ensure safety!"  
"Everyone's eager to show their practice results!"  
"Uh-huh."  

They practically shoved flyers at the boys.  
Around Yuu, being first-years, reactions were tepid. Some glanced at flyers before folding them small—probably fearing rudeness or anger if discarded openly. Only music enthusiasts like Masaya seemed genuinely interested.  
All knew Saiei's basics from their introductory video shown before today's Ayakuni Cup.  

Yuu also received a flyer from a Saiei student and read it.  
Suddenly feeling eyes on him, he looked up and spotted a blonde, blue-eyed girl in uniform watching him from a distance.  

*(That's... Keiko? No, Kate, right?)*  

When their eyes met, Kate beckoned.  
Yuu nodded, excused himself from friends, and approached her.  

"Were you competing today? Or helping headquarters?"  
He spoke first as they walked toward the courtyard, but Kate remained as unfriendly as ever.  
When Yuu waited patiently, she finally replied.  

"Competing. Eliminated in round two."  
"Is that so? I made it to round three."  
"Yeah..."  
"......"  

They sat on a bench in the building's shadow, Kate leaving space for one person between them.  
Today, Kate had her long blonde hair tied back. Her clean profile showed Anglo-Saxon features: a high nose bridge and long eyelashes. Her melancholy expression made her seem older than her years.  
Yuu glanced at her repeatedly, but though she'd initiated this, Kate didn't speak.  

"You wanted to talk, right?"  
"Mmm... *Sigh*..."  

After a long sigh, Kate spoke reluctantly, as if forced to say something unpleasant.  

"August 3rd."  
"Huh? Ah, Saiei's performance day?"  
"Well... our student council plans to invite all Sairei student council members. You coming is assumed."  
"Ah, I see."  

All-girls schools were gardens of femininity—objects of male fantasy.  
In his previous life, Yuu might have harbored such illusions as a high schooler.  
But he'd heard reality was less glamorous. Co-ed schools like Sairei actually made girls more mindful of appearance and manners under male gaze.  

Especially in this world, Sairei girls received etiquette training for interacting with boys.  
He didn't particularly desire to visit a girls' school.  
But as part of student council duties? That was different.  
And going with Sayaka and others was non-negotiable.  

"If invited as the student council, I'll go."  
"Actually, it's better if you don't..."  
Kate's voice trailed off.  
"Never mind. That's all I wanted to say."  

Yuu was slightly bothered by Kate's hesitation but didn't press her.  

"It's the president and that other vice president—Omori-san?—pushing the invitations, right?"  
Yuu's guess hit home.  
"Well... yeah. As a guy, they make you uncomfortable?"  
"No, not really. They seem interesting to talk to."  
"You really are weird."  
"No, you are."  

Reminded of their first reunion, Yuu smiled faintly.  
Kate's mouth relaxed slightly too. In the eased atmosphere, Yuu decided to ask something that had bothered him.  

"When we first met, you used a Japanese name, right? You said it was fake when we met as student council members. Why?"  
"Ah..."  

Kate averted her eyes awkwardly, but Yuu kept looking.  
Using a Japanese pseudonym seemed odd when countless Western names existed.  

"You said 'Keiko as in Keio University's *kei*' when introducing yourself, right?  
Isn't that strange?"  
"Ugh... Ah! Right! I forgot—the president asked me to handle something else!"  
"Huh?"  
"Sorry! We'll talk later!"  

Cutting him off, Kate stood and ran away, leaving Yuu sitting there unsatisfied.  

---

### Author's Afterword

The quiz championship finally ends here.  
Choosing difficult questions for the finals was challenging.  
They might be unrealistically hard for a high school quiz—please don't scrutinize too closely.  

Next up: the night events.  
Please wait a little longer for the main event.

### Chapter Translation Notes
- Translated "交互前進クイズ" as "alternating advance quiz" to maintain gameplay mechanics
- Rendered "どよめき" as "murmur" for crowd reactions during tense moments
- Preserved Japanese name order (e.g., "Hanmura Riko") per style rules
- Translated classical waka poem with literal translation + explanatory paraphrase
- Kept specialized terminology: "IS-LMモデル" → "IS-LM model", "マンデルフレミングモデル" → "Mundell-Fleming model"
- Used explicit "fellatio" for sexual term consistency
- Maintained honorifics: "-san" for Iida, "-senpai" for upperclassmen
- Italicized internal thoughts: *(That's... Keiko? No, Kate, right?)*
- Transliterated sound effects: "ピンポーン" → "*Ping-pong!*"
- Applied simultaneous dialogue formatting: ""Correct!"" for judge announcements