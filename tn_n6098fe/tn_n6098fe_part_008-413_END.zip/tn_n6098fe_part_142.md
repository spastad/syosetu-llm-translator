## 133. That Night ① ~Youthful Passion~

As soon as the quiz championship closing ceremony ended, both schools disbanded.  

Some members of Saiei Academy's executive committee stayed behind for about 30 minutes to handle post-event procedures, but the remaining students promptly left the campus.  

Sairei Academy's female students were all helping clean up the first athletic field, while the boys were exempted and allowed to rest in the male classroom.  

This was because the July gender interaction event - the school camping - would begin in an hour and a half, and the boys were assigned meal preparation duties.  

Perhaps he had been too energetic since morning and gotten tired, because the moment Yuu returned to the classroom and put his head down on the desk, he was swallowed by sleepiness and slept for about an hour until awakened.  
But because of that, he felt refreshed when he woke up.  

Afterwards, Yuu and the first-year boys prepared dinner ingredients in the home economics cooking room of the administration building.  
When it comes to camping, the dish to make is curry rice.  
The entire class divided tasks - washing rice, washing vegetables, peeling and cutting them.  
The second and third-year boys should have gathered in the school cafeteria's large kitchen to do the same work.  
Meaning, these 36 people needed to make curry rice for about 300 people - one-third of the first-year participants and staff who had helped.  

The plan was to place large pots on carts once the vegetables and meat were cooked, take them down via elevator, transport them to the first athletic field where hearths were prepared, then add the roux.  
The borrowed commercial rice cookers should have already been brought to the field with washed rice and water added, where the rice was being cooked.  

Yuu volunteered to stir-fry thinly sliced onions in a wok.  
These were the caramelized onions for the curry.  
Normally, it takes time to stir-fry them until they become soft and caramel-colored.  
A method Yuu had learned online before his reincarnation.  
By microwaving them first then stir-frying while adding small amounts of water, they could be done in about 5-10 minutes.  

However, the amount of onions to stir-fry was large, and standing before the hot gas stove using fire, Yuu became drenched in sweat as he continuously shook the wok.  

"Phew, finally finished... My arms hurt, I don't even want to see onions anymore..."  
"Completely agree. Even with glasses on, my tears wouldn't stop."  
"My hands turned red from cutting too many carrots."  

Yuu was released once the three large pots used for school lunches had been set on heat and the vegetables and meat started boiling.  
Rei and Masaya seemed the same - they had apparently been assigned to endlessly chop mountains of vegetables in baskets.  

"Preparing the field must be tough too, but they have numbers on their side.  
We've never experienced cooking for 300 people before..."  

Rei and Masaya nodded at Yuu's words.  
While it's common for women to enter society, men who don't work tend to handle household chores, so many learn cooking from their teens.  
Still, cooking for family and this were completely different.  
Nevertheless, curry rice - a camping staple - was chosen because it could be made decently as long as water and roux amounts weren't mistaken.  

By the time the large pots were boiling and the assigned boys started skimming off scum with ladles, the good smell of simmering meat and vegetables began drifting through the air.  

The clock's hands were about to reach 7 PM.  
Even in July - when days are longest - dusk had fallen by this hour, making it hard to distinguish people's faces. Twilight time.  
Fire was lit at the center of the crisscrossed firewood pile, and what started as flickering flames gradually gained momentum before flaring up high with a *whoosh*.  
Cheers rose from the surrounding female students.  

By then, the savory smell of curry had begun wafting across the entire field.  
One large pot served about 100 people.  
Nine large pots - three each for spicy, medium, and mild - were lined up in hearths along the field edge near the school building, simmering over low heat.  
*Groooowl* - a hearty sound. *Gurgle* - a cute sound.  
As stomach growls leaked out here and there, murmurs of "I'm so hungry" could be heard.  

*"Sorry for the wait! The curry is ready, so please line up wherever you like to get served."*  

*Thud thud thud* - the starving female mob dashed toward their preferred curry pots.  

"Hey, why is our line weirdly long?"  
"Well... I guess everyone likes medium spicy?"  

Masaya helping nearby said evasively.  
Several floodlights illuminated the curry pot locations, with signs saying "Spicy," "Medium," "Mild" displayed.  
The boys from each grade divided tasks - managing lines, scooping rice onto deep paper plates with spoons, and finally serving curry.  
Yuu, who had been asked to serve curry, had a large sign saying "Medium" behind him, with "(1st Year - Hirose Yuu)" written in parentheses below - though he didn't notice.  
Compared to the spicy and mild pots on either side, his line was over twice as long.  

The first in line were Sayaka and the student council members plus the quiz championship executive committee members - though they had changed over since the camping started.  
They must have been near the headquarters tent.  
They seemed unwilling to yield when it came to eating Yuu's served curry.  

Thus, pushed by Riko and Emi, Sayaka was first.  
Perhaps she didn't have much appetite today - Yuu noticed when serving curry over the modest portion of rice on her plate.  

"You don't look well...?"  
"Hmm... r-really?"  
Emi chimed in from behind.  
"After the closing ceremony ended and the Saiei students left, Sayaka-senpai seemed to suddenly crash and couldn't move from her seat. So we told her to rest and skip cleanup."  
"Yeah... I ended up troubling everyone at the last moment."  

When Yuu stopped by headquarters after talking with Kate in the courtyard, she hadn't seemed unwell.  
But apparently she had been on the verge of snapping from tension.  

"It's fine. We know you've been working hard, Sayaka."  
Riko interjected after Emi.  
"Why not leave the camping to the executive committee and go home?"  
"But... w-well, I can't not eat Yuu-kun's curry!  
Besides..."  
"Besides?"  
"I want to be with Yuu-kun especially at times like this..."  

Yuu suddenly felt affectionate seeing Sayaka looking down at her curry plate.  
He remembered they hadn't had time to talk properly recently because both had been busy.  
So he brought his mouth close to Sayaka's ear and whispered.  

"I'll come see you after today's event ends. Let's spend tonight together."  
"Y-Yuu-kun..."  
"Um... The line is backing up, so could you move along?"  

At Emi's words, Yuu and the others snapped back to attention.  
The line had grown even longer than before.  
Out of consideration for the boys on duty, no one was making a fuss.  
The girls at the front of the line had been waiting patiently while looking enviously at Yuu talking with the three student council members.  

"See you later."  
"Yu-kun, see you!"  
"Yeah, bye."  

After the three hurried off, the next group of girls - the quiz championship executive committee members - arrived. Yuu apologized for making them wait while praising their work during the day.  
Thanks to that, they quickly regained their smiles too.  

In line were not only first-year girls Yuu was friendly with like Hiyama Yoko, Aki Kazumi, and Aramaki Yoshie and five others, but also second and third-years he had interacted with during the quiz championship, and some unfamiliar faces too.  
No matter who it was, Yuu served curry while amiably making small talk.  
Consequently, unlike other lines, his never seemed to end.  

Yuu kept serving curry to dozens of people, and the pot's contents steadily decreased.  
Eventually, the ladle touched the bottom when scooping.  
Only enough remained for about a dozen more people.  

"Hmm!"  

A plate heaped high with rice was thrust before Yuu as he looked down at the pot.  
Even without looking up, he recognized the familiar uniform - white tank top with purple shorts.  
Incidentally, the "Sairei Academy" embroidery on the chest had virtually no bulge beneath it.  

"Oh? Isn't this Hayakawa-senpai?"  
"Extra curry, please!"  
"Sure, sure."  

Facing her directly, her height was around mid-150cm - petite and slim for a girl in this world.  
But being an athletic girl, she apparently ate a lot due to high activity levels.  

"Here, be careful carrying it."  
"Wah! Thank you!"  

Yuu served as much curry as would barely stay on and handed it over.  
When passing the plate, he deliberately let his fingertips touch hers - most girls noticed immediately and blushed or looked happy.  
Hayakawa-senpai touched too, but rather than noticing, she gazed at the heaping curry with sparkling eyes and left without looking at Yuu.  
*(More hungry than horny? Interesting senpai.)*  
Thinking this while continuing to serve, he didn't notice Hayakawa-senpai stopping some distance away to look back and stare intently at him.  

After serving about a dozen more people, the pot was completely empty.  
He could only ask the remaining girls in line to go to other lines.  

"Come to think of it, we're hungry too."  
"True."  
"My stomach's been growling nonstop~"  

Looking sideways, some lines still had people waiting, while others had leftover curry but no lines.  
Yuu's station had apparently run out first.  
Having finished their duty, Yuu's group was about to discuss lining up elsewhere to eat when Masaya came over from a short distance.  

"They've prepared curry for us at the headquarters tent."  
"Ooh! Let's go get it then!"  
"Let's go, let's go!"  

When Yuu's group cheerfully headed to the headquarters tent, the fragrant smell of curry was just beginning to waft from a portable gas stove-heated pot.  
Available executive committee members must have prepared it.  

"Thanks for your hard work!"  
"Good work! We saw you. Hirose-kun's station was super popular."  
"Haha... Thanks to that, we finished first.  
Ah! Since we're free now, why don't available people eat with us?"  
"W-wait, seriously!?"  
"Really?"  

Not only the serving boys but also headquarters-stationed executive committee members had been too busy to eat.  
Just then, the sports club patrol team returned from their security rounds.  
This consideration came from Yuu's kindness, having experienced school festival staffing in his past life.  
For female students, opportunities to eat with boys were rare.  
The girls present gladly accepted Yuu's offer.  

*"It's about time, so let's begin today's main event - the folk dance!"*  

While Yuu had been enjoying conversation - or rather skin-ship - with the senpais who stayed after eating, an announcement came from headquarters, followed by murmurs of "Ooh!" and "I've been waiting!" mainly from second and third-year girls.  

*(Folk dance, huh...)*  
The last time he did this was in sixth grade or maybe middle school.  
For Yuu with a mental age over 40, it was too long ago to remember clearly.  
He remembered feeling embarrassed holding girls' hands during the dance, yet happy when paired with a girl he liked.  

In this world, middle schoolers live separate school lives by gender - they don't even share playgrounds. During elementary school, it varied by region and grade.  
About ten years ago, nationwide curriculum reforms progressed to allow boys and girls to exercise and dance together at least during elementary school.  
Thus for Sairei's female students, this was their first chance since elementary school to openly touch boys.  

*"Boys, please split into your May Newcomer Welcome Orienteering groups and join your assigned classes."*  

Yuu and the five first-year boys hurried to Class 1-5's location.  
When Yuu approached, Yoko and the Class 5 girls immediately cheered and welcomed him.  
Following the announcement, boys scattered and mixed into girls' lines.  
Though only about five boys per class, this scene of boys and girls together was unique to Sairei.  

*"Please watch the morning assembly platform and around the fire!"*  

Since few would remember dance moves right away, executive committee members would demonstrate.  
The first dance was Mayim Mayim.  
The moves themselves were simple.  
Holding hands in a circle, stepping to the music while moving round, narrowing the circle together with the chant "Mayim mayim mayim mayim………mayim be-sasson!"  
Here, it was arranged that when expanding the circle back, boys would move sideways to hold hands with as many girls as possible.  
When the lighthearted music started during the demonstration, Yuu unintentionally murmured "Nostalgic," but with the surroundings noisy, no one seemed to hear.  

Then the real thing began.  
Following the announcement, each class formed circles holding hands.  
Initially, Yuu's right hand held Yoko's, left held Kazumi's.  
Though they would switch soon, they apparently couldn't yield the first position.  

"Ufufu!"  
Holding Yuu's hand firmly, Yoko looked truly happy with a beaming smile.  
"Since I couldn't participate in the quiz... Just being near Yuu-kun makes me happy..."  
Kazumi stared at Yuu with sparkling eyes as if shooting "like-like rays."  
Being gazed at like that, Yuu couldn't help but feel happy too.  
Moreover, though height differences between genders had lessened, the softness of their hands remained unchanged, making him want more contact.  

"Kazumi."  
"Huh...?"  

Yuu pulled Kazumi closer with a firm but painless grip.  
Their arms and legs pressed tightly together.  
"Me too!"  
Not to be outdone, Yoko clung close while still holding hands.  

Girls in the circle facing them watched enviously.  
They wished Yuu would come to them before the song ended.  

"Wah!"  
"Kyaha ha ha!"  
"So fun!"  

Holding hands and stepping, moving forward while raising joined hands during repeated phrases.  
Just that alone felt inexplicably fun, bringing natural smiles.  
This must be the charm of group dancing.  
Faces illuminated by the vigorously burning fire seemed to wear smiles regardless of gender.  
Especially for female students, holding boys' hands under nightfall was itself an extraordinary event. No wonder their spirits soared.  

*(Summer events like this are fun. Cliché as it sounds, it feels like living my youth.)*  

While continuously switching partners and holding girls' hands, Yuu thought to himself.  
Though not particularly woman-crazy, his original late teens had reasonably happy memories too.  
Having miraculously reincarnated, he was now surrounded by an unbelievable number of girls.  
He found it wonderfully enjoyable to live these fulfilling youthful days.  

After Mayim Mayim came Letkiss (Finnish folk song, original title "Letkis").  
Meaning "let's dance in a line," they danced in a long front-to-back line.  
Here, hands rested on the shoulders of the person in front - many first-years touched opposite-gender shoulders for the first time.  
But after holding hands during Mayim Mayim, resistance seemed lower.  

The final dance was Oklahoma Mixer (song originally "Turkey in the Straw").  
In Yuu's previous life, it was the most popular dance.  
But in this world, its spread was delayed - some students hadn't danced it in elementary school.  
When the executive committee demonstrated to nostalgic country music, murmurs arose.  
While previous dances were group-based, this time boys and girls paired up.  

"Ah... Um, nice to meet you, Yuu-kun."  
"Yeah, nice to meet you too, Sati."  
"Hmm..."  

The Letkiss line split into two columns, forming pairs of two.  
By order, Yokota Satilat (nickname: Sati), who had been immediately in front, paired with Yuu, while Nakai Mao, one spot ahead, looked frustrated.  
Both had been on first-name terms since the ball games tournament, and both had lost their virginity to Yuu in the Special Male-Female Interaction Room in early July.  
But here, fortunes clearly differed.  

First, to learn the moves, they danced slowly without music following the announcer's instructions.  
Yuu's right hand reached from behind to take Sati's right hand raised near her shoulder, while their left hands joined in front.  

"Sati, don't be so tense. Heh."  
"B-because... Eek!"  

When pairing, they didn't need to get particularly close.  
Though taller than Yuu by several centimeters and slender-looking, Sati had toned arms and legs befitting a soccer club member.  
Her tanned skin looked healthy too.  
To hold her hand firmly, Yuu deliberately pressed close.  
Sati wore her long black hair - reaching mid-back - simply tied in a ponytail.  
Yuu stretched slightly and blew breath near her neat ear.  

"Geez! Yuu-kun, you... Ah..."  

Sati looked back but found Yuu's face extremely close.  
Seeing his gentle smile made her heartbeat accelerate even more, turning her ears bright red.  

"It's a rare dance, so relax... okay?"  
"Nn... ahn..."  

Keeping their bodies pressed together, Yuu pushed their joined left hands against Sati's chest with a *squish*.  
Judging by her uniform, they didn't seem large, but touching revealed unexpected volume.  

*((((Flirting right in front of us...))))*  

The pairs before and behind - both girl-girl pairs - shared this thought.  
But in the two-column formation, the girl behind Sati would pair with Yuu next, and watching his back made her heart pound uncontrollably.  

The Oklahoma Mixer changed partners frequently in a short time.  
In Yuu's memory, around fifth-sixth grade when kids started noticing the opposite gender, some pairs barely touched hands out of shyness.  
Indeed, some first-year boys seemed that way.  
But Yuu firmly held his partners' hands, bringing faces and bodies close enough to feel breath.  
This made both Yuu and the girls happier.  
Truly a win-win relationship.  

During the roughly three-minute song, about half the girls got to pair with boys.  
When the song ended and they were about to disband, cries of "Encore!" immediately spread among the girls, so they danced the Oklahoma Mixer once more.  

---

### Author's Afterword

While searching with the keyword "youth," I remembered this song existed...  
In this world, it must be exactly what girls fantasize about.  

Also, when I first heard "Letkiss," I mistakenly thought it meant "let's kiss." - The Author  


### Chapter Translation Notes
- Translated "青春りっしんべん" as "Youthful Passion" capturing both "youth" (青春) and passionate connotations of "りっしんべん"
- Preserved Japanese honorifics (-senpai, -kun) per style rules
- Translated "飴色玉葱" literally as "caramelized onions" with cultural explanation in context
- Transliterated sound effects: "ぐーーーっと" → "*Groooowl*", "くぅ～～～" → "*Gurgle*"
- Maintained original name order: "Hiyama Yoko" not "Yoko Hiyama"
- Translated folk dance names per standard terminology: "マイム・マイム" → "Mayim Mayim", "ジェンカ" → "Letkiss", "オクラホマミキサー" → "Oklahoma Mixer"
- Rendered internal monologues in italics: "（色気よりも食い気か...）" → *(...)*
- Translated explicit physical contact literally: "むにゅっと押しつけてみた" → "pushed with a *squish*"