## 134. That Night ② ~Serenade Under the Night Sky~

The co-ed camping event started in the evening, and until last year it had apparently been voluntary participation.  

That's why only about half the boys came, and many athletic girls prioritized practice for upcoming summer tournament preliminaries instead of participating.  

As a result, only about half to two-thirds of the entire school participated, Yuu had heard in the student council.  

However, this year they made folk dancing mandatory for everyone and assigned meal duties to boys.  
This seemed to have stimulated the female students' motivation.  
Thanks to that, it was safe to say it became very lively and ended successfully.  
We must not forget the efforts of the executive committee mainly composed of 3rd-years, and the security team who patrolled the school to ensure no suspicious persons were present.  

By the time the last folk dance ended, it was nearly 9 PM.  
The majority of boys were walking toward the second building entrance to board shuttle buses home.  
The executive committee members had started cleaning up.  
Most would continue during daytime tomorrow, but there were unavoidable tasks like extinguishing fires and storing borrowed items.  

Right after saying goodbye to male friends heading home, Yuu found himself surrounded by over ten girls from Class 1-5.  

"Yuu-kun... u-um, after this..."  
"Won't you watch the stars with us?"  
"Ah, stargazing?"  

This part was optional, but remaining students would go to the school rooftop for summer stargazing led by the astronomy club.  
Though only some would seriously observe.  
For most girls, the goal was to spend romantic moments with their favorite boy while gazing at stars.  
Several groups of girls surrounding boys had already formed on the field.  
Though instructed to move in groups at night, some couples seemed to be having passionate moments in the Special Male-Female Interaction Rooms they'd reserved days prior.  

The girls looking at Yuu had expectant eyes.  
Yuu wanted to respond to that feeling.  
But unfortunately, he couldn't right now.  
Yuu shook his head regretfully.  

"Sorry. After this, I'm spending time with the student council members."  
""""""Aah......""""""  

Disappointed sighs leaked out at Yuu's reply.  
Though not publicly stated, everyone acknowledged that the three student council members including Sayaka were closest to Yuu in this school.  
Since Komatsu Sayaka-senpai—the student council president who embodied beauty and talent—was involved, they could only reluctantly back down.  

"I-it can't be helped, everyone. At least we danced with Yuu-kun and had fun today. Let's send him off cheerfully."  
"Un..."  
"Y-yeah... I think Yocchan's right."  
"Yuu-kun, thank you for today!"  
""""Thank you!""""  

Aramaki Yoshie, the class representative, skillfully mediated at times like this.  
Though some girls looked down or even teared up, voices of agreement rose at Yoshie's words.  

"Really sorry, everyone. Even though you kindly invited me."  
"I-it's okay! Don't worry about it."  
"Anyway, we have club activities tomorrow morning, so we're staying at the dormitory. So we'll have fun just us girls until late night!"  
"Just because there are no teachers like the school trip doesn't mean you can make too much noise though."  
"Eh, really? Sounds fun."  
"Yuu-kun, you can still come! We'd welcome you!"  

Hiyama Yoko said this brightly as a joke.  
Yuu murmured softly, "That does sound nice."  
Then he reached out his right hand, lightly touched Yoko's hair—which had grown to her back since their first meeting when it was a short bob—and stroked her cheek.  

He wouldn't normally do this in front of many people, but tonight Yuu was excited from touching so many girls, or perhaps his affection swelled seeing Yoko's sparkling eyes gazing at him.  
Yoko flushed bright red at the sudden touch.  
Yuu's hand moved from her cheek to her chin.  

"Ah..."  
""""Waah!""""  

In a completely natural motion, Yuu kissed Yoko.  
Just 2-3 seconds. By the time Yoko realized she'd been kissed, Yuu's lips had already parted.  
"Only this much for now."  
"Haaan......"  
""Yuu-kun!""  

Before Yuu could move away from Yoko, Anzai Kazumi and Maegashira Yuma—who'd been at similar distances—approached from both sides.  
Yuu pulled Kazumi's waist with his left hand, kissing her while groping her butt.  
Next he kissed Yuma while stroking her short head.  

Over half the gathered girls had already had physical relations with Yuu.  
Hence there was no hesitation.  
After Kazumi and Yuma, Gotou Mashiro followed, then Yoshie, Mao, and Sati—each embracing and kissing Yuu in quick succession.  

By then, the campfire had dimmed considerably, and spotlights only illuminated the assembly platform and headquarters area.  
Though the school entrance was brightly lit, Yuu's group was at the far edge of the field near trees, so the darkness concealed them.  

For girls who came intending to invite Yoshie's group, Yuu—whom they admired—became their first kiss partner.  
Some were overjoyed by the sudden luck, while others cried from emotion.  

Noticing they might get left behind as many students departed, Yuu's group finally headed toward the school building.  
They parted ways with the Class 1-5 girls near the headquarters tent, waving with smiles.  

When Yuu passed the headquarters tent and reached the management building entrance—their meeting spot—he saw Sayaka slumped against Riko's shoulder on the stone steps, completely motionless.  

"Sayaka!"  
"Ah, Yuu-kun is here."  
"Nn...un?"  

Noticing Yuu's approach, Sayaka lifted her face, but she looked even more haggard than before eating curry.  

"A-are you okay...?"  
"Um..."  
Sayaka stopped Riko from speaking with a hand gesture and bowed to Yuu.  
"Sorry... I threw up the curry rice you worked hard to make."  
"That's fine! You look terribly pale. Wh-what should we do... Sh-should we go to the hospital?"  
"Yuu-kun is overreacting."  
"But..."  

It was cruel to tell someone not to worry when their loved one clearly looked unwell.  
But Riko remained calm while Yuu panicked.  
Considering she was staying close as Sayaka's best friend, she'd have taken her to a doctor if it were serious.  

"Yuu-kun. You see, Sayaka has above-average sense of responsibility, so accumulated fatigue and recent sleep deprivation are the main causes.  
That's why I said she should go home and rest properly.  
But Sayaka insisted on meeting you directly."  
"I-is that so?"  
"Because you said you'd spend time together, but I'm in this state..."  

Yuu hugged Sayaka tightly without letting her finish.  
Though usually steady, Sayaka's body swayed and leaned into Yuu the moment she left Riko.  

"Thank you for your hard work. Rest well today. When you recover, let's do lots together. Promise."  
Hearing this, Sayaka managed a faint smile.  
"Ah, promise. With Yuu-kun... lots, together...nn"  
Just a light farewell kiss with Sayaka.  

"Let me join then too. I'll stay over after seeing Sayaka home.  
If she hasn't recovered by tomorrow, I'll take her to the doctor."  
"Ah, I'm relieved if Riko's with her."  
Yuu reached out to touch Riko, then kissed her as she leaned in.  

Though walkable distance, they'd apparently called a taxi since Sayaka staggered when alone.  
After seeing them off in the car, Emi—who'd been keeping her distance—approached.  

"Yu-kun. Um, sa... uun, never mind."  
"Eh? What is it? I'm curious."  
"Umm..."  

Unusually hesitant for her normally lively self, she avoided eye contact and stumbled over words.  
Yuu sensed she might be unsure how to act now that Sayaka and Riko had left.  
So he approached Emi head-on, hugged her, and whispered.  

"Emi, thank you for your work at headquarters today too!"  
"Aha... Thank you, Yu-kun!"  

Emi hugged back happily.  
After embracing awhile, she voiced a small wish.  

"U-um... It's hard to say with Sayaka-senpai and Riko-senpai gone but..."  
"Don't worry, say it."  
"Un... Come to the rooftop... with me?"  
"Ah, let's go."  
"Ufuh. Yay!"  

Finally she smiled her usual bright smile.  

Stargazing would occur separately on the management building and main building rooftops.  
Arriving last after most students had moved, Yuu and Emi headed to the school building rooftop.  
He'd been to the management building during rotating classes, but hadn't entered the girls' main building except during special events like April's self-introduction, so Yuu wanted to see it.  

However, with few people around, the building interior wasn't much different from Yuu's memory of high school.  
Rather, with minimal lighting, it felt eerily dim.  

"Scary, isn't it? The school at night."  
"Un. Definitely."  

Clutching Yuu's arm tightly, Emi climbed the stairs with him.  
An executive committee member guided them at the entrance, but inside they were alone.  
He thought he heard girls' voices from above earlier, but now it was silent.  
Emi seemed scared, relying entirely on Yuu without looking around.  
Having no sixth sense, Yuu wasn't particularly frightened.  
He considered teasing Emi but held back since panic on stairs would be dangerous.  
After reaching the second floor facing the third-floor stairs, he hugged the still-frightened Emi clinging to him.  

"Emi, I'm here so it's okay."  
"Ah... Ufufu. Yu-kun is so reliable! I'm falling for you more!"  
"That makes me happy."  
"An!"  

They exchanged light chu, chu kisses.  
If any virgin high school girl ghosts were present, they might have appeared from anger and jealousy at such affection.  
But what actually appeared was an executive committee member checking the rear.  

"Um... You're last, so could you hurry?"  
""Sorry!""  

Blushing, Yuu and Emi quickly ascended the stairs.  
The committee member sighed deeply and followed slowly.  

"Look south.  
The particularly bright star is first-magnitude Antares, center of Scorpius.  
Slightly east are Vega in Lyra and Altair in Aquila, with Deneb in Cygnus—the triangle they form is called the Summer Triangle."  

An astronomy club member explained constellations with a penlight and paper at the rooftop center.  
About a dozen people gathered around.  
It seemed fewer than expected, but peering closely, several small groups were at the edges.  

With groups split between buildings, not many were on this rooftop.  
Students remaining this late would mostly stay at the dormitory.  
However, though the dorm baths were large, they couldn't accommodate everyone, so many students bathed first.  
Thus only slightly over one class's worth were on the main building rooftop.  

Yuu and Emi avoided the crowd, turning left after exiting the door and circling along the building wall to the back.  
They reached the opposite side without meeting anyone.  
About 2m of space existed before the white anti-fall railing.  
Prepared Emi spread a large plastic sheet she'd brought, so they sat side-by-side against the wall.  

Temperatures dropped considerably at night, and the height brought a cool breeze.  
Thus pressing shoulders together felt comfortably warm.  

"Nnfu. Yu-kun, you smell nice."  
"Eh? Not sweaty?"  
"Not at all!"  

Today he'd sweated profusely from the quiz competition to curry preparation.  
Since male-specific sweat wipes didn't exist, he'd only wiped sweat with a damp towel during breaks and used deodorant spray.  

Remembering his past high school days, Yuu knew girls' nice post-PE class smell came from deodorant spray, yet it still seemed pleasant just because girls emitted it.  
This might be similar.  

"Emi smells nice too."  
"An!"  

Deliberately bringing his nose to her nape.  
A citrus scent actually came from Emi's exposed nape.  
After such affectionate exchanges, they looked up at the night sky together.  

"I never noticed before, but looking up like this, you can see quite a few stars."  
"Ah, surprisingly many."  

Clear skies without clouds probably helped.  
Located in green-rich Saitou City away from urban areas, many stars were visible to the naked eye.  

But Yuu currently had something more interesting than stars.  
Of course, Emi beside him.  
They say you tire of beauty in three days, but that's a lie.  
Even after multiple intimate encounters, you never tire of a beautiful girl.  
Emi kept her long flaxen hair in twintails since their first meeting.  
Twintails are common until elementary school but rare among high schoolers—probably because they only suit petite girls with small faces.  
Emi still perfectly fit that.  
As his eyes adjusted to darkness, Yuu gazed at Emi's fair profile and neck.  
Sensing his gaze, Emi turned with a crescent-eyed smile.  

"What is it, Yu-kun? Mesmerized by me?"  
"Un, mesmerized by Emi."  
"...!"  

Though meant as a joke, his serious reply instantly flushed Emi's cheeks.  

"Yahn... Yu-kun, really!"  
"Emi."  

Playing with her twintail strands, Yuu kissed the happily bashful Emi.  
His left hand held hers in lovers' clasp.  
They resumed undisturbed where they'd left off.  
After several kisses, both grew aroused and their tongues intertwined.  

"Nchu, chu, chupuu... lero, lero... eroo... afu... I love you, Yu-kun, I love you!"  
"Ah, Emi is so cute. Let me touch more."  
"Okay... touch lots... I want Yu-kun to touch me... an!"  

Emi cooperatively lifted her sailor uniform skirt, removed her bra, and her C-cup breasts tumbled out.  
Kneading the palm-sized breasts, Yuu moved his mouth to caress her slender neck and small ears.  

"Fua... ah, ah, nnn!"  
"People are nearby, so try not to be too loud."  

Saying this, Yuu began noisily licking Emi's ear—her weak spot.  

"Ah... haan... Yu-kun... licking feels... so good... my voice... comes out!"  

When he pinched her hardened nipples, Emi shuddered uncontrollably.  

"Let me touch yours too..."  
"Okay, here."  
"Aahn, it's rock hard."  

Guiding Emi's left hand, he had her stroke his crotch over his half-pants.  
Emi stroked the entire penis shape before slipping her hand inside to touch directly.  

"Nn!"  
"Ahaa... Yu-kun's cock is hot."  
"Emi's too."  

When Yuu slipped his hand into Emi's panties and rubbed her crotch up-down, he felt dampness.  

From their seated position, Yuu hooked his right leg over Emi's left to spread them crosswise, each stimulating the other's genitals.  
With his hand inside her panties, Yuu spread her vaginal opening kupaah and thrust his middle finger deep.  
Emi traced the shaft inside his pants before lightly gripping and stroking.  

They intermittently kissed to muffle sounds.  
Precum leaked from Yuu's cock while love juice dripped from Emi's pussy.  
Squelching nechunechu, kuchukuchu sounds escaped with their movements.  

"Nn, nfuu... a, ahn! Yu, Yu-kun... nnah, ah, nnn... feels too good!"  
"Nchu, chu, chupaa... Emi's pussy is flooding."  
"Yu-kun's cock too... juice is dripping from the tip. Does it feel good?"  
"Ah, Emi's handjob feels good."  
"Then... should I suck it with my mouth next?"  
"Uun..."  

As Yuu started pulling down his pants for oral, his rational mind recalled what he'd heard at the entrance.  
The astronomy club's stargazing explanation would last 20-30 minutes.  
Then free observation for 30 minutes.  
Since it had already started when they entered, they had less than an hour on the rooftop.  
After finishing, other students would likely patrol before locking up. They had to finish before then.  

Yuu withdrew his hand from Emi's privates, hugged her petite body from behind, and whispered while nuzzling her cheek.  

"I can't wait anymore. I want to put it inside Emi."  
"Un... got it. What position?"  

After brief thought, Yuu lifted Emi while holding her from behind.  

"Put your hands on that railing."  
"Ah..."  

Emi seemed to imagine it.  
The rarely used doggy style position with them.  

Bending forward to grip the railing, Emi thrust her butt toward Yuu.  
Yuu lifted her skirt from behind.  
Though dark, he saw frilly cream-colored panties.  
Slipping them off exposed her small buttocks.  
He pressed his fully erect cock against her butt crack.  

"Yahn... Yu-kun, don't tease. Hurry."  
Feeling the hard, hot rod against her butt, Emi grew even more excited.  
She shook her twintails while looking back and pushing her butt against him.  

"Haha. Okay. I'll pound hard from the start?"  
"I want Yu-kun to wreck me... aahn! Aaaaaaaaahhhhhhhh—unmmnn!"  

As his cock plunged in zubuzubu and thrust deep, her loud moan made Yuu hastily cover Emi's mouth with his left hand.  
His right hand supported her body while groping her breasts.  
He pulled back near the entrance before thrusting deep again, starting vigorous strokes.  

---

### Author's Afterword

I'd wanted to write a scene on the school rooftop at least once.

### Chapter Translation Notes
- Translated "天体観測" as "stargazing" for natural flow
- Preserved Japanese honorifics (-kun, -chan, -senpai) per style guide
- Translated "ちゅっ" sounds as "chu" for kissing sounds
- Used explicit anatomical terms ("pussy", "cock") as required
- Maintained Japanese name order (e.g., Aramaki Yoshie)
- Italicized internal monologue *(This is concerning.)* per style rules
- Transliterated sound effects (e.g., "zubuzubu" for ずぶずぶ)