## Interlude 4: The Women Who Captured His Heart - Part 2

"To the trespasser: This is Sairei Academy High School property. If you proceed with intrusion, we will restrain you and hand you over to police."

"Gah, we're spotted!"  
"Damn it!"

The flashlight beams illuminated three girls: one who had just landed on this side with hands on the ground, and two others about to climb over the fence. Dressed in dark clothing to blend into twilight, they scrambled back down. The girl already on this side panicked, "Hey, wait for me!" as she tried to jump back.

Beyond the 2-meter vertical fence lay a 1.5-meter-wide irrigation canal, making crossing difficult. Perhaps they'd set up makeshift footholds under cover of darkness. A *thud* and "Oww!" suggested a failed landing. Soon after, frantic bicycle sounds indicated their escape. Team members approached the wall, the tallest one peering over using a chin-up motion.

"Looks like they made a ladder from long bamboo poles."  
"Good grief. No openings for carelessness."  
"Japanese people are so resourceful."

The last comment likely came from the non-Japanese looking member. Seeing someone make an "OK" gesture with both hands, I picked up the transceiver.

"This is Basketball Team A Squad. Spotted three suspicious individuals—likely middle schoolers—attempting fence breach at second field. Issued warning, confirmed retreat. Over."

"*Roger. Thanks for report. Oh, isn't it shift change time for Basketball A Squad?*"  
"Hmm... true."  
Checking my watch showed past 7:30 PM.  
"*Circle back along fence to HQ. Curry rice is ready—made by girls though.*"  
The voice chuckled. We'd missed the boys' curry. Oh well.  
"Appreciate it. Perfect timing since we're starving. Will return after final patrol. Over."

When I relayed this to our eight-member squad, half cheered while half sighed in relief.  
"I kept smelling curry the whole patrol!"  
"Camping means curry after all!"  
"I know! Japanese Indian curry, delicious!"  
"Pauline, Japanese curry and Indian curry are totally different now."  
"What!?"

My name is Shiina Chizuru. I'm captain of Sairei Academy's basketball team and in Class 3-7 (PE track). Though I attend a co-ed school, basketball consumes my life. Still, occasionally seeing boys is better than nothing. During spring prefectural qualifiers, boys cheered for us in quarter and semi-finals—more privileged than all-girls schools.

There's reason for field patrols during this critical pre-nationals period. During the Ayakuni Cup quiz championship and co-ed camping event starting this evening, sports clubs take rotating security shifts. Guards watch the gates, but we patrol for intruders slipping through. After dark, like moths to flame, trespassers come hoping to see boys... or worse. We'd already caught four groups during our second field patrol.

Our team earned a seed position in spring, exempting us from district prelims—prefectural qualifiers start Sunday. Losing gym access hurts before such a big event. But the first Ayakuni Cup and co-ed events are major school functions requiring constant male protection. The student council promised priority male support for top-tier teams this year.

Plus, the quiz championship draw secured Saiei Academy's sports facilities—a win for us. We've shared gyms with volleyball or used outdoor courts. Though requiring travel, more exclusive gym time will motivate underclassmen. The trade-off—boys visiting Saiei—worries me though.

Back to tradition: sports clubs handle security during co-ed events. Before major tournaments, clubs usually bench starters to avoid injury risks from trespasser altercations. But as captain, I led Squad A myself—my imposing build deters trouble. Other starters insisted on joining too, so we split into two squads.

My Squad A centers on starters, including two foreigners standing out with exaggerated gestures about curry.

Pauline Anderson, an African-American exchange student from our sister school in San Francisco, arrived last September. Her Japanese listening improved but speech remains broken with English mixed in. Starting basketball stateside, her experience is limited but 195cm height and athleticism make her indispensable as center.

Constance Wilson—blonde, blue-eyed Anglo-Saxon—grew up in Japan with naturalized parents. Fluent Japanese. Nearly as tall as Pauline with basketball since elementary, she's a reliable forward. Both are close friends transcending race.

No abnormalities found during the rest of our fence patrol. Greenery surrounds Sairei Academy, plunging it into darkness after sunset. Though a bonfire blazed at first field's center, corners remained dark. Occasional thin light beams likely came from other patrols.

At the west gate, we turned left toward the gym—HQ location. Stadium and building fronts were properly lit.

"Good work!"  
"Ooh, good work!"

Approaching HQ tent, we found eight kendo club members—our replacements. Not in kendo gear but matching gym clothes under crimson happi coats embroidered "Sairei Academy Security." Their bamboo swords were personal gear.

"Trespassers used makeshift ladders over canal and fence at second field. Stay alert."  
"Understood."

Kendo Club's captain Hayase Mika led them herself. Though in general studies, she's their best fencer—reached spring prefectural finals. After a touch greeting, we handed over security.

"Let's eat!"  
"Curry! Curry!"

Relieved after patrol, we chattered excitedly approaching HQ.

"Hmm?"

Next to HQ tent, large rice cookers and portable stove pots steamed on long tables. Deep paper plates already held curry rice servings.

"Ah! Isn't that Shiina-senpai! In that happi... you were on security? Good work!"  
"Fwah... hehe, Hirose-kun!?"

Among HQ staff, Hirose-kun and first-year boys were serving food! Besides him, a small cute boy and other familiar faces.

"Hirose-kun!"  
"Hi!"  
"Um... Connie-senpai and Pauline-senpai, right?"  
"Ufufu, happy to see you."  
"Yah... still cool as ever."  
"Aw, you're making me blush."

While teammates froze, Connie and Pauline high-fived him. Maybe foreigners are bolder. Still, him remembering our names since Newcomer Welcome Orienteering three months ago thrilled me.

"We just finished serving and were about to eat with HQ staff. Senpai, join us!"  
"U-uh, sure."

No reason to refuse—none of us would miss eating with boys. 

Hirose-kun ate curry surrounded by exec members and Squad A. He amiably responded to everyone, even initiating talk with shy girls. With stunning looks yet zero arrogance, his consideration made him universally likable. Everyone vied for his attention.

"Having boys handle meals this year was tough, but girls loved it."  
"Everyone kept saying 'delicious' and getting seconds."  
"Then our hot work paid off. Right, everyone!"

When Hirose-kun asked, other boys nodded. I found it strange—last year, first-year boys rarely chatted freely with senior girls like this. Apparently Hirose-kun proposed and drove these changes after joining student council.

"Speaking of, 'Male Inclusion Movement' protesters crowded the main gate today arguing with guards."  
"Huh? What did they want?"  
"Not sure. Just kept demanding entry. I've seen them handing flyers after school."  
"More lately—moderate to radical—but I can't agree with their demands."  
"Yeah, as a guy... it's troubling."

Bad topic for boys... but Hirose-kun looked adorably troubled.

"Ah, Shiina-senpai! Seconds?"  
"Ah... yeah, maybe... no no, shouldn't trouble you."  
"Don't hesitate. I'm getting more too."

I realized my plate was nearly empty. Hirose-kun stood before me holding his empty plate.

"How much?"  
"Huh?"

He leaned in close to see my face. C-close! Bad—my pulse raced faster than pre-game. When I pulled back my plate, I knocked over my tea cup.

""Ah!""

Half-full, it spilled forcefully onto my chest. Luckily, I'd opened my happi wide before eating—only my gym shirt got wet.

"Emergency! T-towel!"  
"H-Hirose-kun? I-I'm fine."

No big duties left anyway. If it stained... but just tea...

"Sorry. I pushed too hard about seconds..."  
"No no, not your fault."

Hirose-kun borrowed a towel from HQ and sat snugly beside me. Dangerous! This proximity...

"U-um... let me dry your chest?"  
"Ah, yeah..."

Refusing felt rude... or rather, I delighted in his closeness. I lowered my arms, thrusting out my unnecessarily large chest. The wetness revealed my full-cup bra pattern. Hirose-kun stared intently, gulping audibly. He began drying with the towel.

"Ooh, big."  
"Mh... yeah. Annoying for basketball."  
"But nice. Shiina-senpai's boobs."  
"Nngh! R-really...?"

Why? His pressing-wiping motions felt gentle... pleasant. Especially when he scooped and kneaded my breasts upward.

"Big match coming. Can't risk colds—must dry thoroughly inside."  
"But... ah... ahh..."

His towel-hand lifted my gym shirt, drying my wet bra from belly to chest. His right arm wrapped supportively around my back—nearly embracing me. So close I felt his breath... smelled his scent... My heart pounded like bursting. What's wrong with me?

"Shiina-senpai's body is so toned, yet breasts big and soft... nice."  
"H-Hirose...kun! Ah... th-there... haahn!"

Unclear if he wiped or groped through the towel. Didn't matter. When fingers brushed my bra-covered nipple, pleasure made me moan. I ignored gathered stares and my flushed face.

"Ahh!"  
"Oh my god!"  
"Hmm?"

Tea cups spilled onto Connie and Pauline's chests across from me. Hirose-kun missed it watching my chest, but I saw—they deliberately spilled tea on themselves.

"Co-old! I'll catch cold like this. Must dry fast."  
"Troublesome desu ne."  
"Me too!"  
"Kyaa! Cup fell by itself..."

Squad A members' chests got wet one after another. You guys... wipe yourselves. As I thought this, Hirose-kun smiled at them.

"My my, basketball senpai are surprisingly clumsy. Should I dry you?"  
"P-please."  
"Katashikenai."  
"Sorry..."

Don't trouble Hirose-kun then—but I understood. Devoted to club life, they craved male contact.

After finishing me, Hirose-kun moved behind Pauline. She'd stripped her wet gym shirt, leaving only white sports bra over coffee-brown skin. Slender yet muscular, with modest breasts.

"Here wet......"  
Her bra-pulling "wet inside" act was excessive. But Hirose-kun embraced her from behind, kneading-drying from belly to chest. Usually playful Pauline fell silent, then moaned as he massaged through the towel.

Next was Connie with breasts as large as mine. Ultimately, Hirose-kun "dried" all eight members. Everyone grinned wantonly at his approach—yet he never showed annoyance, smiling warmly. An angel!

Nearby exec members tried copying, but an announcement for folk dancing made Hirose-kun wave goodbye.

Perfect timing—Hirose-kun serving food as we finished security—brought blissful moments. For us behind-the-scenes workers, it felt like reward. Greed would be wrong... yet I wished for more contact with Hirose-kun.

---

### Author's Afterword

Shiina Chizuru, basketball captain first appeared in "15. High School Enrollment ②" and reappeared in "35. Newcomer Welcome Orienteering ②." Her full name and the two foreigners' names are now revealed.

Shiina-senpai resembles protection officer Kanako as a reliable big-sister type high schooler. Personally, I enjoy the gap between her sturdy image and elegant name "Chizuru."

The two foreigners' names come from a famous SF author I read long ago.

Originally, Interlude 4 planned three spotlights across two parts. But the first half with exec member Kiriko ran long, forcing me to cut the *bokukko* track girl Hayakawa. My apologies if anyone anticipated her—I'll create another opportunity later.

### Chapter Translation Notes
- Translated "中坊" as "middle schoolers" based on context of trespassers' age
- Preserved Japanese honorifics (-kun, -senpai) and name order (e.g., Shiina Chizuru)
- Transliterated sound effects (e.g., "Gah" for げっ, "thud" for ドスン)
- Rendered explicit physical descriptions literally ("breasts," "groped")
- Used "Male Inclusion Movement" for "男共運動" per Fixed Terms
- Translated "おっぱい" as "boobs" to match explicit terminology requirement
- Maintained cultural terms like "happi coat" and "desu ne" inflection