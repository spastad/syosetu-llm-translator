## 135. That Night ③ ~BOYS BE AMBITIOUS~

Most students who stayed for stargazing will be lodging at the dormitory.  
Many have club activities starting early tomorrow, so avoiding commute is likely the main reason. Some simply want to spend the night with friends while still in festival spirits.  
Of course, this includes couples in romantic relationships.  

After parting with Emi on the stairs, Yuu stopped by the student council room to retrieve his change of clothes before heading to the 4th floor assigned to male students.  
Twenty-one boys including Yuu will stay overnight, assigned to Rooms 401-403 (each accommodating eight people).  
With two rooms left empty, female third-years occupy Rooms 406 onward on the same floor, with subsequent floors housing lower grades.  

Since no first-year boys are staying, Yuu will room with second-years. With few connections among male students, he knows few people but figures it'll work out. He actually welcomes this chance to broaden friendships.  

However, Yuu encounters an unexpected situation.  
Upon reaching the 403 area, third-years in the hallway call out to him. He's immediately led to Room 401 and surrounded by a crowd.  
With over ten second and third-years packed into the eight-person room besides Yuu, it feels cramped.  
*(It's been a while since I've been surrounded by guys like this outside class.)*  

He initially suspects they might reprimand him for being a "cocky first-year"—or at least offer senior advice. After all, Yuu interacts openly with female students across all grades, initiating physical contact. Today especially, he deepened interactions with upperclasswomen.  

But their attitudes aren't hostile, easing his worries.  
The central figure is third-year Ichijo Koki—the ultra-handsome guy dating kendo ace Hayase Mika and singer Ishima Mariko. They cheered together at May's kendo tournament and exchanged greetings in the courtyard. Other familiar third-years from cheering events are present too. Sairei Academy boys tend to be mild-mannered; bullying juniors is unimaginable.  

Koki initiates: "Hirose-kun... is it true you're simultaneously dating Student Council President Komatsu-san, Vice President Hanmura-san, and the second-year secretary and treasurer?"  
"Yes, that's correct."  
Yuu nods frankly since it's no secret. But Koki wants to know more. After exchanging hesitant glances with others, he asks gravely:  

"Then... I-I wanted to ask... have your relationships with these three already become... um... physical?"  
"You mean sexual relationships? Yes, they have."  
"Ooh... If you don't mind... when did that start?"  
"Hmm, around late April? First, I confessed to the president, and after some back-and-forth, she accepted. Then around late April? The other two started dating me simultaneously. Anyway, after joining the student council, all three treated me wonderfully, and I grew to like them."  
"S-so within 2-3 weeks of enrollment?! And you confessed first?!"  
"Ah, yes."  
"Uun..."  
"Unbelievable."  
"Amazing..."  

Koki and the others wear astonished expressions. In this world, no boy besides Yuu develops deep relationships with seniors so quickly after enrollment. Their surprise is natural.  

"I see... Well then, regarding sexual matters, we'd like advice from you as the senior. About... progressing to that stage with girls."  
"Huh? Wait—have you not done it yet with your girlfriends, Ichijo-senpai?"  
"Nope."  
"Eh? You looked so lovey-dovey together, I assumed you had."  
"Well, Mika's busy as kendo captain, and Mariko has singing activities..."  

Yuu had forgotten this world's males are universally herbivorous. While sexually passive, they respect their partners—Koki isn't just handsome but gentle and considerate.  

"Actually, Mika promised we'd start after summer tournaments. Hearing that, Mariko got competitive..."  
"I see. What about other senpai?"  

Apparently, all present second/third-years have girlfriends or similar relationships but remain virgins.  

"Any advice on interacting with girls? Like essential mindsets?"  

Koki asks shyly. Even from a male perspective, he's attractive—protagonist material, though sexually timid. Others nod earnestly, relying on Yuu.  

While this world's relationships feature aggressive women and passive men, Koki's group wants to take initiative—perhaps influenced by recent active promotion of gender interaction. As their mental senior despite being physically younger, Yuu wants to help.  

That said, his previous marriage ended in divorce. His 40-year life included no "popular phase." Post-reincarnation luck granted abundant female experience, but he used no special techniques—just living honestly with different chastity values. Can he offer useful advice?  

As Yuu ponders, the seniors watch intently.  

Finally, he scans the room and speaks:  
"Ultimately... expressing your true feelings through action matters most."  
"True feelings?"  
"Yes. You're probably used to receiving female affection but struggle to show it yourselves, right?"  

After hesitation, all nod. This transcends worlds—many high school boys, including Yuu's past self, struggle with expressing affection.  

"From what I see, Sairei girls aren't just cute—they're considerate toward boys and kind-hearted. So during conversations, compliment them naturally.  
*'Your wide eyes are so cute.' 'Your silky hair is captivating.' 'Your smooth cheeks make me want to touch them.'*  
Compliment while touching.  
Not just looks—praise their personality or passions too.  
Oh! Those little gestures that make your heart skip?  
Keep praising their good points.  
No one dislikes compliments.  
When they smile, you'll feel happy too. The mood improves.  
As you grow closer, you'll want to know them better, see more expressions.  
Deepening physical contact makes them feel more precious...  
You probably know this, but girls' bodies smell wonderful and feel soft...  
Gently stroking their hair brings blissful expressions.  
When you kiss and caress them, hearing their cute moans excites you too—"  
"W-wait! Okay... I think we get it, no need for specifics—"  
"Ah..."  

Yuu got carried away reminiscing about his first time with Sayaka, passion overflowing.  

"A-anyway! Men and women think quite differently. Be clear about what you want."  
"Clear?"  
"Yes. Don't expect them to read your mind—they're not espers.  
Voice every little thing: what you like about them, what you want them to do, what you want to do.  
Now, regarding first-time preparations..."  
"Y-yes."  

Expressions grow more serious. Some take notes.  

"When virgins have their first time, 40-50%... no, probably over 50% fail. Assume failure is more common."  
""""Eeh?!"""  

All are shocked. Compared to girls, boys are surprisingly nervous—trying too hard backfires. Yuu believes passivity causes similar issues.  

"Partners crying from pain or failed penetration is normal.  
Failed penetration isn't the end.  
Celebrate just sharing skin contact. If the first attempt fails, it's not over—it's the beginning. Understand each other's bodies, cooperate, and build a better relationship."  
"I-I see... Experienced advice like this is invaluable."  
"Also, I've heard women typically lead sex while men stay passive, but that's wasteful. Men should take initiative too."  
"Huh?"  

Yuu shares conquest techniques from experience—mildly described, but overwhelming for these virgins. Many look down shyly. With Koki's group being pretty-boy types (slender and androgynous rather than masculine), it's picturesque. Yuu feels nothing special, but imagines how girls would react.  

"More... stimulating than expected... But very informative. Thank you, Hirose-kun."  
Koki thanks him and extends his hand. Yuu shakes it firmly.  

"Thank you!"  
"Let's stay friends regardless of grade!"  
"Please let me call you Master!"  

Yuu exchanges smiles and handshakes. More male friends are welcome. Though "Master" is embarrassing...  

Noticing the wall clock, Koki exclaims: "Ah! Boys' bath time starts at 10:40! Everyone, hurry!"  
"""Ooh!"""  

Following seniors carrying towels and clothes, Yuu asks a nearby second-year:  

"After bathing, what's the plan?"  
"Um... We'll visit girls' rooms before lights-out."  

Seeing the boy—who looks younger than his age—answer shyly, Yuu considers doing the same. He recalls Class 1-5 girls he kissed after folk dancing are staying over.  

After bathing with seniors, Yuu changes into black home-wear T-shirt and shorts. From stairwell shadows, he watches the second-floor hallway.  

*(Which rooms are Class 1-5's?)*  

The dimly lit hallway is quiet. Occasional girls walk to restrooms, but no familiar faces. Without knowing room assignments, he's stuck. Wandering openly would cause a commotion—acceptable but potentially chaotic.  

After minutes of watching, a girl bursts from Room 210. Yuu hides.  
"Uu—gotta pee, gotta pee, I'll leak!"  
In white T-shirt and light blue jersey shorts, she dashes past without noticing Yuu.  
*(That's...?)*  
Her long black hair and glimpsed profile with glasses resemble Class 1-5 representative Aramaki Yoshie.  

*(Yoshie always appears alone at perfect times.)*  
He recalls their first encounter when she struggled with documents—the start of their relationship. Maybe they're fated.  
Hiding opposite the restroom entrance, he waits.  

After five minutes, footsteps approach. Humming cheerfully, Yoshie nears. As she passes, Yuu covers her mouth from behind and pulls her toward the stairs.  

"Mmmpfh!?"  
"Shh, quiet. It's me, Yoshie."  
"Eh?"  

Her eyes behind glasses focus on Yuu, widening as cheeks flush.  

"Mmph?"  
"Ah, sorry. I'll remove my hand—don't scream."  

She nods. Releasing her, he hugs her from behind. Having bathed, her straightened hair emits floral scents. Her soft body smells soapy—he doesn't want to let go.  

"Aahn... Yuu-kun... So happy to see you tonight."  
"Hehe. Me too."  

Yoshie's sidelong glance is alluring. Yuu kisses her repeatedly. After several *chu chu* kisses, he asks cheek-to-cheek with her dazed expression:  

"Is Class 1-5 nearby?"  
"Mhmm... Split between 209 and 210."  
"How many staying tonight?"  
"Um... Sixteen—eight per room."  

Yuu nods. About half the class—too many at once. But he resolves to deepen relationships tonight.  

"Class rep Yoshie, I have a request."  
"Hmm? Sure, anything."  
"Can you gather everyone in one room? Say, 210 since it's adjacent?"  
"Hmm, should fit if we squeeze... But why?"  
"Make them promise not to cause commotions no matter what, then call me."  
"Eh?! Meaning...?"  
"Yeah, I'm visiting your room."  
"Waaah! Yes!"  
"Shh! Quiet."  
"Sorry..."  

Watching Yoshie return gleefully, Yuu feels excited. Staying overnight at school—usually just for classes—thrills him. Plus, visiting sixteen girls (including past partners) with Yuu as the only boy?  
This night promises fun. Yuu's heart swells with anticipation.  

---

### Author's Afterword

This almost became an all-male chapter (lol).  
Next chapter: Yuu storms the room with sixteen waiting girls.

### Chapter Translation Notes
- Translated "童貞" as "virgin" to maintain explicit terminology requirement
- Rendered "ちゅっ" sound effects as "*chu*" per transliteration rules
- Preserved Japanese honorifics (-kun, -san) and name order (Aramaki Yoshie)
- Translated "肉体関係" as "sexual relationship" following explicit terminology rule
- Maintained original paragraph breaks for dialogue as specified
- Italicized internal monologues (e.g., *(...)*) per style guide
- Translated "風呂" as "baths" with contextual clarity
- Kept "BOYS BE AMBITIOUS" untranslated as per title formatting