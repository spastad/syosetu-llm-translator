## 136. That Night ④ ~Kiss and Hold Me~

### Author's Preface

The main text is long, and the afterword is long too.

Combined, they exceed 10,000 characters.

---

Class representative Yoshie's invitation prompted the eight people in Room 209 to move to Room 210.

The room measured 16 tatami mats.  
While spacious enough for eight to sleep with some room to spare, 16 people meant one person per tatami mat - adequate for sitting but not for lying down.  
They had originally prepared snacks and juice to chat among themselves, but these were temporarily stored in the tokonoma alcove.  
Futons intended for laying out were stacked in the corner, with two girls already sitting atop them.

"So why did you gather everyone from Class 5?"  
"Are we having an impromptu class meeting? Even though less than half are here."  
"But 16 people in this room is really cramped."

Hiyama Yoko broke the ice, prompting a flurry of responses.  
Among the 16 present, over half - 10 including Yoko from the basketball club - had club activities starting tomorrow morning.  
The rest were friends of Yoshie who'd decided to stay late as class representatives.

"By the way, a senior I met in the bath said boys from our grade might visit the second- and third-year rooms."  
"Ehh, lucky!"  
"Are the boys on the fourth floor?"  
"I don't think any first-year boys are staying over."  
"I saw them leave in front of the second school building."  
"I got to say goodbye to Higashino-kun and Hosho-kun. And Yamada-kun too."  
"Higashino-kun is so cute!"  
"Hosho-kun is handsome too."  
"I love Yamada-kun's cool, intellectual vibe."  
"But still..."  
""""Hirose-kun is the best!"""" """"It's Yuu-kun, right!""""  
"Wait - not just Yoko and Kazumi, but even Mao-chan and Sati are using his first name now?"  
"Ehehe~"  
"I got permission!"  
"Eh~, unfair~!"  
"Honestly, I wish Yuu-kun would come even just briefly to see us."  
"Totally agree."  
"Just talking with Yuu-kun makes me happy."  
""""I know right~""""  
"But Yuu-kun is..."

While three women make a noisy crowd, 16 created a boisterous uproar.

"Everyone, listen!"  
Yoshie seized a lull near the entrance.  
The classmates, packed shoulder-to-shoulder, turned toward her.

"What I'm about to say is absolutely secret from other classes - only for Class 5 members here."  
Her firm tone silenced even the whisperers.

"We're inviting a special guest tonight. No matter who appears, no loud outbursts, okay?"  
Yoko and several others made "could it be?" faces but remained uncertain - fearing disappointment if it were just their homeroom teacher.

"Okay? Understood?"  
"O-okay. I'm curious. Who is it?"  
"She'll bring them now."  
"Uhh, waiting..."

The girls' expressions when Yoshie revealed the hidden Yuu were priceless.  
Most shot up, barely stifling shouts as they covered their mouths.

""""Hirose-kun!"""" """"Yuu-kun!""""  
All welcomed Yuu to the room's center with radiant smiles, keeping their voices restrained.  
"Hey everyone. Good evening."

"Wh-wh-what's happening? I thought for sure today..."  
"Well, various circumstances. I was supposed to stay in the boys' room on fourth floor, but seniors said they're visiting girls' rooms. So I thought I'd come to Class 5.  
I ran into Yoshie on the stairs earlier."  
"Ugh, I'm so happy!"

Not just Yoko but Aki Kazumi, Maegashira Yuma, and Goto Mashiro looked ready to cling to Yuu in delight.  
Given their joy, Yuu saw no need to explain the full situation.

"Yocchan, nice one!"  
"Staying tonight was the right choice!"  
"Too bad for the girls who went home!"

Yuu scanned the beaming girls.  
Perhaps because they were gathered densely, feminine scents of treatment products and soap wafted into his nostrils, heightening his mood.  
Their casual loungewear - T-shirts, sleeveless tops, tank tops, shorts, half-pants, some in long T-shirts without pants - exposed shoulders and thighs gloriously in the summer heat.  
Smiling, Yuu surveyed the room.

"I want to spend time deepening bonds with everyone here tonight. Okay?"  
""""Of course!""""  
"Super welcome!"  
"Yuu-kun can stay as long as you want!"  
"Ahaha. Thanks."

Yuu took nearby Yoko and Kazumi's hands.  
Immediately, Mashiro, Yuma, Nakai Mao, Yokota Satilat and others surged forward to grasp his hands too.  
As over ten girls surrounded Yuu, a knock interrupted them.

"Hey, the room next door's empty. Know anything?"

"Oh no. Sounds like a neighbor class girl."  
"Yuu-kun, hide!"  
"Uh, where?"  
"Here!"  
"Hurry!"

Pulled by their hands, Yuu squeezed into the closet's bottom section - empty since futons had been removed.  
As he entered, the doors shut, but Maegashira Yuma and Goto Mashiro had slipped in too.

"Huh? What, everyone's here?"  
"Ah... y-yes! Just an impromptu Class 5 meeting. Ahahaha."

Yoshie's flustered cover-up was audible inside.  
The cramped closet reeked of dust and mildew, with low height creating claustrophobia.  
Sitting cross-legged, Yuu leaned forward, face buried in Mashiro's ample breasts while Yuma clung tightly to his back.

"Fuu. Mashiro's breasts are supreme as always."  
"Ufufu. Happy. Ah, no... Yuu-kun, you~"  
"Hafuu. Love Yuu-kun's broad back."

They whispered softly to avoid detection.  
Yuu kneaded one breast, nuzzling its softness, drawing pained sighs from Mashiro.  
Yuma pressed her cheek to Yuu's nape, sniffing him while her hands groped his chest.

Minutes later, the closet doors slid open with a *garari*.  
"They're gone... Ahh! Sneaking ahead, unfair!"  
"I want in!"  
"Me too!"  
"Shhhhh!"

Discovering Yuu sandwiched with Mashiro and Yuma caused an uproar.  
Calming them took considerable time.

Regrouping, Yuu sat against stacked futons and addressed the 16 Class 1-5 girls.

"Some here became close through Newcomer Welcome Orienteering or sports festivals, while others haven't had much chance to talk."  
"Y-yes."  
"Uh-huh..."

Several girls blushed at "become close" while staring at Yuu - unsurprising since he'd been intimate with over half (9) of them.  
Others had shared first kisses after folk dance or given love letters during commutes.  
Confident they'd accept his advance, Yuu continued.

"So I want to properly greet each of you individually..."  
"Greet?"  
"Yes. By attendance number - who's first?"  
"Here!"

Kazumi stood straighter than during class roll calls.  
"Come here."  
"Okay!"

Front-row girls parted as Kazumi approached Yuu, beaming at going first.  
She wore a red-white striped T-shirt and navy half-pants, her usually braided hair now tied with a red scrunchie and draped forward - a fresh look.

"Here. Sit here."  
"Huh?"  
""""Eeeeh!?"""  
Cross-legged Yuu pointed to his lap area.  
"I-is it okay?"  
"Dislike it?"

Kazumi absolutely didn't.  
Standing before him, she slowly lowered her hips.

"Then, nice to meet you."  
Staring breath-close, crimson-cheeked Kazumi nodded.  
"Um, Class 1-5, attendance number 1, Aki Kazumi.  
Basketball club member... and... um... I like... Yuu-kun."  
Her tiny voice reached Yuu clearly.

"Thank you. I like you too, Kazumi."  
"Hauu!"  
They shared a passionate embrace.

"Now, a special greeting just for tonight."  
"Greet... mmm!?"

Yuu captured Kazumi's lips.  
Though startled, she closed her eyes and hugged back.  
They angled their heads, exchanging repeated kisses - pressing lips or quick pecks like lovers.  
Onlookers watched feverishly, fidgeting with inner thighs.

After over a minute of kissing, Kazumi looked dazed.  
"Now, next."  
Yuu stroked her head; she reluctantly moved aside.

Attendance number 3 Yoshie similarly exchanged passionate embraces and kisses.  
With the first two being intimate partners accepting eagerly, the room's atmosphere grew charged.  
For the remaining seven without male experience, the chance to hug/kiss their school idol made hearts pound.

"Um, next?"  
"Here, here!"

A tall, slender beauty stood energetically near the wall - wavy reddish-brown hair, Latina features radiating unteen-like allure.  
Navigating seated classmates, she tripped over someone's foot.

"Kyaa!"  
"Watch out!"

Yuu stood instantly, catching her fall.  
But her height and momentum overwhelmed him, sending both backward onto the futon pile.

"Ahhh... thanks... sorry, Hirose-kun."  
"No problem, Anzai-san."  
"Yan, call me Rosa."  
"Then call me Yuu. First time since after folk dance."  
"Ufufu! So happy to see Yuu-kun again! Love you!"  
"Mmph!?"

Yuu knew her from the passionate love letter she'd given.  
Attendance number 4, Anzai Rosa (quarter-Italian, grandmother's looks dominant).  
Her letter mentioned quitting basketball after injuring her knee in junior high.  
This fall might relate to that or distraction.

Holding her head, Yuu received fervent kisses.  
She'd exploded with joy after their first kiss post-folk dance.  
Her obvious affection now intensified.

Wearing peppermint-green tank top and white shorts, her surprisingly ample breasts felt soft and elastic against Yuu.  
His hardening cock pressed against her lower abdomen via his left hand on her waist, heightening her excitement.

"Uhhuhn... Yuu...kun, mmchu, chu, chu, shuki...nchureru... afu, shukii... anmuchuu! An, kimohii... more... chu!"  
"Hey! Rosa, too much!"  
"Come on, separate!"

To bystanders, Rosa seemed to assault Yuu.  
Front-row girls intervened, but Yuu waved them off.

"Fufu. I don't dislike passionate approaches like Rosa's.  
But others are waiting. Later?"  
His gentle head-stroke while persuading warmed not just Rosa but all watching girls.  
Many noticed his tenting crotch, unable to look away as they rubbed thighs.

After sharing passionate embraces/kisses with attendance number 6 Ueno Shoko and enjoying her full breasts, Ukawa Miyoko came forward.  
Yuu secretly called Miyoko and Sato Risa the "left-right combo" - both volleyball players over 180cm, with Miyoko's very-short hair, cute face, and gentle nature.  
He knew both were close with his friend Higashino Rei.

Miyoko plopped before Yuu, her eye-level still higher despite sitting.  
Seeing her hesitate, Yuu spoke.

"Ukawa-san, sorry I'm not Rei."  
"...! Th-that's not..."  
"By the way, how far with Rei?"  
"How far?"  
"Kissed yet?"  
"K-kiss... no way."  
Miyoko trembled, shaking her head hard.  
"Then hand-holding?"  
She glanced at Risa and nodded slightly.

*Normal couples move this slowly,* Yuu mused warmly.  
Gently taking her hand, she startled but didn't pull away.

"Pretend I'm Rei. Practice."  
"Eh, Hirose-kun as?"

In this reversed-chastity world where men take multiple partners, women face no monogamy expectations - they simply compete for scarce males.  
Kissing Yuu wouldn't constitute cheating.

"Come here."  
"Okay..."

Miyoko settled onto Yuu's lap.  
"Nnn?"  
Feeling hardness below, she flinched; Yuu wrapped arms around her back.  
"Kiss me."  
"Fwa...!"

Assuming Rei would receive rather than initiate, Yuu's invitation sparked aching tightness in Miyoko's chest.  
Driven by passion, she pressed her lips to his.

After motionless seconds apart, Yuu asked:  
"How was?"  
"Nn... uhh... felt warm somehow..."  
"Really? If you feel that with me, imagine Rei!"  
"R-really?"  
"Get more practice?"  
"Hauu"  
Thus under "practice" pretext, they kissed repeatedly.

Attendance number 11 Kino Emiko - short, plain, inconspicuous - approached with feverish expression after watching others.  
Nestling in Yuu's arms, feeling his hardness, she received passionate kisses until dazed and immobile.

Goto Mashiro  
Sato Risa  
Shimozono Kayo  
Nakai Mao  
Hiyama Yoko  
Maegashira Yuma  
All welcomed special greetings with Yuu.  
Except Risa, the intimate partners kissed deeply while stroking Yuu or grinding against his erection, preventing it from subsiding.

Attendance number 29 Mano Shiori - long black hair, refined features, delicate build - cried from joy after their first kiss on the field, revealing emotional volatility.  
Her turn came; she lunged at Yuu, showering kisses while shouting "Love you!" as fervently as Rosa.

Attendance number 33 Yoshihara Makie (class representative like Yoshie) had shoulder-length hair parted down the middle in twin pigtails - resembling a certain anime cat-robot's friend.  
Petite like Yuma (under 150cm), she wore thick round glasses, plain black long-sleeve T-shirt, and blue sweatpants despite the heat.

Before Yuu, Makie declared haughtily:  
"Deplorable how Sairei ladies claiming refinement have degenerated into such lustful disorder!  
All because you, Hirose-kun, indiscriminately charm everyone!  
A-and recklessly touch bodies and k-k-kiss!  
Is this fitting for Japanese males valuing modesty and reserve?"

Clearly a hardliner.  
Yoshie called "Makie-chan..." but Makie retorted "Someone must say this," ignoring her.  
Yuu found this refreshing.

"Eh, but I adore girls. Class 5 girls are all cute, making me crave skinship."  
"Haa!? E-even so, males must guard chastity! Indulging such lewd acts... i-i-indecent! Exercise restraint!"

Yuu grabbed Makie's hand mid-rant, pulling her close.  
"Hyaa!? Wh-what?!"  
Her small frame fit snugly in his arms.  
"Thanks for worrying. You're kind. But I'm fine."  
"N-no! B-b-because such physical contact between..."  
"Remove your glasses."  
Yuu took off her milk-bottle lenses, revealing childish features with large eyes.  
"Cute, Makie-chan."  
"Cu...!?"  
Blushing, she looked down.  
"Ku, I won't fall for sweet words and hugs like others!  
S-so don't pat my head... auuuu"

"Here, Makie-chan, stick your tongue out - say 'ahh'"  
"Ahh"  
"Fufu. Good girl. Chu, leroo, leroo..."  
"Nchureroo... ero, leroo... an... aah... nn, nn, nfuun"  
"How's adult kissing?"  
"Fa... feels so good... so good... Yuu...kun..."

Beyond kissing, Yuu groped under her shirt and licked her ears/neck until Makie moaned indecently.  
Girls stared amazed at her instant capitulation after bold proclamations.

Leaving dazed Makie with classmates, Yuu scanned the room.  
"Um, last one..."  
"Randou-san!"  
"Yori-chan's left!"  
"I-I'm fine..."

The final girl hid near the entrance - Randou Yorika, whose build dwarfed Makie's.  
Plump with bobbed hair hiding her cheeks, she approached escorted by others, hunching unconfidently.

"S-sorry. I shouldn't be here.  
U-um, attendance number 34, Randou Yorika.  
H-happy seeing Hirose-kun today. Bye."  
"Wait!"  
"Waah!"

Yuu grabbed her retreating hand, pulling hard.  
Yorika tumbled onto him.

"Ahh! S-sorry! I'm heavy..."  
"Nah. Not heavy."  
"Liar..."  
"Not lying. Your body's soft and nice. Hug tighter."  
"H-Hirose-kun..."

Modern beauty standards favored tall slenderness, leaving plump or busty girls marginalized.  
Yorika had assumed Yuu would reject her; his unexpected kindness brought tears.

"Uu... sob..."  
"Eh... Yorika? Disliked it?"  
"N-no... happy tears."  
"Good. No more crying."

Yuu wiped her wet cheek with his right hand.  
Up close, her droopy eyes looked gentle.  
Though plump, she wasn't unattractive - slimming could enhance her cuteness.  
Even now, Yuu found her adequately cute.

"Yorika, your skin's baby-soft and smooth."  
"Eh, r-really?"  
"Yeah. Hugging you naked would excite me more."  
"Stop~"

Stroking her blush, Yuu kissed her.  
Yorika's eyes widened, but she yielded rather than pulling away.  
Having envied classmates kissing Yuu, she embraced this unexpected luck for a sweet moment.

---

### Author's Afterword

Chastity-reversal stories featuring one boy in a school/class inevitably involve him bedding numerous girls.  
At gender-segregated Sairei Academy, conquering 35-36 per class is impossible, but 16 seemed feasible.  
This chapter evokes school-trip room invasions.  
With 16 characters, confusion threatens readers and writer alike.  
Below are brief profiles:

Name / Affiliation / Experience / First Appearance  
Aki Kazumi / Basketball club / C (sex) / Ch15  
Aramaki Yoshie / Class rep / C / Ch74  
Anzai Rosa / A (kiss) / -  
Ueno Shoko / Softball club / C / Ch102  
Ukawa Miyoko / Volleyball club / - / Ch34  
Kino Emiko / - / - / -  
Goto Mashiro / Table tennis / C / Ch34  
Sato Risa / Volleyball club / - / Ch34  
Shimozono Kayo / Soccer club / C / Ch102  
Nakai Mao / Baseball club / C / Ch34  
Hiyama Yoko / Basketball club / C / Ch15  
Maegashira Yuma / Table tennis / C / Ch34  
Mano Shiori / - / A / -  
Yokota Satilat / Soccer club / C / Ch102  
Yoshihara Makie / Class rep / - / -  
Randou Yorika / - / - / -  

※Blank affiliation ≠ go-home club; simply unmentioned in text  
※Experience: A=kiss only, C=sex

### Chapter Translation Notes
- Translated "ぽちゃ" as "plump" to convey body type neutrally
- Rendered "粉をかける" idiomatically as "indiscriminately charm" preserving metaphor
- Preserved Japanese honorifics (-chan, -kun) per style rules
- Transliterated sound effects (e.g., "garari" for がらり)
- Translated explicit terms directly (e.g., "チンポ" → "cock")
- Maintained Japanese name order (e.g., "Aki Kazumi")
- Italicized internal thoughts (e.g., "*Normal couples...*")
- Used gender-neutral "they" for group references
- Formatted simultaneous dialogue with double quotes (""..."")