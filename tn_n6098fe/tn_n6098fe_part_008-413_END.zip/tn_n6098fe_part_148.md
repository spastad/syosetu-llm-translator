## 137. That Night ⑤ ~The Love Game of Men and Women~

After greeting all 16 girls, Yuu formally introduced himself.

After sharing his family structure, hobbies, birthday, and blood type, he opened a Q&A session where each girl could ask one question. Everyone wore more serious expressions than during class, with some even taking notes.

Favorite food... Ramen, sushi.  
Favorite drink... Coffee. Black.  
Favorite type of girl... None in particular. Regardless of age or body type, I don't refuse anyone who comes to me. Whoever I develop feelings for becomes my type. Essentially, as long as we connect emotionally, it's fine - unless they have extreme personalities.  
Favorite animal... Cats and dogs, I like both.  
Future dream... Not decided yet, but I want a job where I can help people.  
How many people do you plan to marry in the future?... No particular upper limit.

Just as he continued, an announcement played.

*'It is now 12 o'clock. Lights-out time. Everyone please return to your rooms, turn off the lights, and go to sleep.'*

Though not an official school trip or training camp, there apparently was a rule to turn off lights at midnight.

"Yuu-kun, are you leaving?"  
"Hm? Would it be okay if I left?"  
"No way!"  
"Stay longer!"  
""""Yuu-kun!""""

Instantly, girls crowded around Yuu, creating a packed situation. Though he expected this, being so liked by girls couldn't possibly feel bad, and a natural smile spread across his face. Yuu patted each girl's head with both hands. For Mao who was taller than him, he stroked her cheeks instead.

"I'd love to stay with everyone longer... But aren't there club members who have early mornings tomorrow?"  
"Absolutely no problem!"  
""""That's right!""""  
"Since we can spend time with Yuu-kun, we want you to stay as long as possible!"  
"Ah, what wonderful words!"

Yuu hugged Kazumi who spoke last, then proceeded to hug everyone indiscriminately. After embracing them all, he looked around and spoke as if just coming up with an idea.

"Hey, how about we play a little game?"

---

Eight futons were laid out with only orange nightlights illuminating the room. The faint moonlight coming through the open curtains left the room so dim it was hard to recognize anyone. Sixteen girls sat facing Yuu by the window. The date had already changed. After such an early morning, sleepiness should have been setting in. Yet in the darkness after lights-out, facing the boy they liked in this nearly impossible situation, everyone's hearts pounded, eyes sparkled, and mouths relaxed.

"Do you know baseball rock-paper-scissors?"  
"Base...ball...scissors?"  
"No, I don't know."

Everyone shook their heads. Though not well-known, the original baseball rock-paper-scissors is a game played in teams of three mimicking baseball. But Yuu meant the strip game version. In this world, while the original might be unknown, the strip version apparently wasn't common.

When Yuu explained it was a game where the loser removes one clothing item per loss, several girls made strange excited noises like "Fwooooooah," prompting Yoshie and others to remind them to be quiet. Naturally, it was boys vs. girls, with each girl taking turns against Yuu.

"Since we're at it, how about the loser obeys whatever the winner says?"  
"Huh?"  
"What?"  
"What did you just say?"

The girls couldn't immediately process the meaning of his casual remark. Yuu continued facing them.

"Alright, let's start immediately. I'll say the chant, so try to mimic me."  
"""""Oh!"""""  
"♪Yaa-kyuu, su-ru na-raa…………"

Yuu stood up and began humming a song from memory. He didn't remember the choreography well, but the ending was fixed.

"Out, safe! Yoyoi no yoi!"

After demonstrating once, it was time for the real thing. The girls began mimicking Yuu.

Round 1.  
Yuu: Scissors.  
Lead batter Yoshie: Paper.

"Yess!"  
"Aww, I lost..."

"Fufufu. Then let's have you take something off."

The girls showed disappointed expressions as they started removing clothes from the bottom. There was absolutely no shyness - typical of women in this world. Rosa's short tank top made her black lace panties completely visible, but she stood proudly with hands on hips.

"Hoh!"

Seeing all 16 girls exposing their thighs boosted Yuu's excitement.

"Alright, next round!"  
"This time I won't lose!"  
"Out, safe! Yoyoi no yoi!"

Against second batter class representative Makie, scissors vs. rock meant Yuu lost. "Yesss!" The girls shared joy while covering their mouths to suppress noise. Yuu pretended slight disappointment. "Ah, I lost~" and placed his hands on his half-pants. For such occasions, he deliberately undressed slowly. Though normally girls would be considerate of boys, perhaps the dim light and heightened atmosphere affected them - everyone stared openly without reservation.

""""Oh...""""  
"Hmm, sexy"  
"Yuu-kun in just pants... so precious"

The girls who'd had sex with Yuu remained relatively calm, but the others couldn't hide their rising excitement.

"Now, round 3, here we go!"  
"Yeah!"

Surprisingly, Yuu lost consecutively against third batter Yoko and fourth batter Kazumi. It was as if the girls' obsession to see Yuu naked had possessed them. Fortunately, anticipating this possibility, Yuu had worn an extra tank top under his T-shirt today, but he was now at risk.

*(Damn, this wasn't the plan...)*

He'd hoped to make all 16 girls naked early to fulfill his desire to make them pose lewdly, but that plan was hanging by a thread.

With Yuu now only in blue-and-black striped trunks, 32 eyes stared so intently they might bore holes. Yoshie broke the silence with a slightly hoarse voice.

"N-next, let's go..."  
"Y-yeah"

Against fifth batter Mao, Yuu won. Colorful bras and camisoles with cups were exposed. *(Yes!)* Yuu mentally pumped his fist.

Sixth batter Shiori came forward eagerly, but after several draws, Yuu won again. Now everyone wore just one piece of cloth. Whether looking forward, left, or right - breasts, breasts, breasts... Flat chests, small handfuls, palm-filling sizes, overflowing handfuls, large breasts, enormous breasts - all varieties. This room where 16 pairs of breasts were generously displayed was heaven. Yuu felt emotional warmth in his chest.

"This is effectively the final match."  
"W-who will go?"  
"Hmm... tough choice"  
"Surprisingly, Yorika-chan might have the edge"  
"Randou-san?"  
"Eh...? M-me?"

Yorika desperately tried to refuse but was pulled forward from the back row. Yuu's eyes were drawn to her ample breasts swaying *tapun, tapun* with each step. Though she shrank back with hands forward, this pose resembled the "dacchuu no" pose popular before Yuu's rebirth, unintentionally emphasizing her breasts. Seeing Yorika and the breast brigade before him, Yuu's penis became semi-erect.

"Hawawa... s-such an important match..."  
"It's fine, it's just rock-paper-scissors"

"But if Randou-san wins, Yuu-kun will be completely naked... kufufu"  
"Inside those pants..."

Whether encouraging or pressuring was unclear, but the continuous comments only increased Yorika's tension until she was tearful. For Yorika, facing Yuu semi-naked like this when they'd barely interacted felt miraculous and made her dizzy.

Seeing Yorika stiff with tension, Yuu approached her directly. He slowly extended his right hand and *groped* her breast. Soft breast flesh spilled between his fingers. Simultaneously, his left hand took Yorika's hand and placed it on his own chest.

"Ngh! Y-Yuu-kun?"  
"You seem nervous. Me too. Can you feel my heart pounding?"  
"Ah... yes"  
"Winning or losing depends on luck. No hard feelings either way. Come on, let's start"  
"O-okay"

The baseball rock-paper-scissors began with the chant. Since lights were out, everyone chanted softly. With everything riding on who would be fully naked, their gazes were serious. For Yuu, skin contact with them was guaranteed regardless. Winning to make them obey was fine, but he considered letting her win to give her the glory.

Yorika facing him was extremely tense, her movements awkward. At such times, he predicted she'd likely choose rock.

""""Out, safe! Yoyoi no yoi!""""

Yuu deliberately delayed slightly, throwing scissors. Yorika, eyes closed, threw rock as predicted.

""""""Kyaa!""""""  
"Huh? I... won?"

The girls expressed joy while keeping voices down, some even hugging Yorika.

After brief excitement, everyone turned to Yuu. "Then, Yuu-kun..."  
"Y-you're taking them off, right?"  
"Oh no, it's my first time seeing a boy's thing..."  
"Tsk tsk, I did lose after all. Can't be helped. How about the winner's privilege - Yorika takes them off for me?"  
"Huh?"

Yorika, hugged by Yoshie and Rosa on both sides, froze in surprise at hearing her name.

Pushed forward by everyone, Yorika hesitated but finally resolved herself since it wouldn't end unless she acted. When Yorika timidly raised both hands without even looking at Yuu's crotch - avoiding his upper body too - Yuu noticed and spoke up.

"Wrong, wrong. Not like that." Just as some thought she'd lost courage at the last moment, Yuu grinned. "Come hug me from behind. Otherwise, everyone can't see, right?" Yuu was genuinely enjoying himself.

"Th-then... excuse me..."  
"Sure, go ahead"

When Yorika started timidly, Yuu urged, "Press closer," making her push her breasts firmly against Yuu's back. Her ample breasts pressed so hard they seemed to flatten against him.

"M-my breasts are touching you... is that okay?"  
"Huh? Not just okay - I'm happy. Yorika's breasts feel amazing against me."

Yorika had been heavier in middle school but desperately dieted since third-year summer, losing over 10kg. She'd heard breasts shrink when losing weight, but hers barely changed - a complex. Having the breasts she disliked bring someone joy - especially Yuu whom she admired - was a first in her 16 years. This only strengthened her feelings for him. Yorika clung tightly, rubbing her flushed cheeks against his shoulder.

"Y-Yuu-kun... th-thank you"  
"Don't mention it. Now, everyone's waiting. Slowly take them off"  
"Okay"  
"Oh, and because you're hugging me, my penis inside got excited. See?"

Yuu guided Yorika's right hand to his crotch. Instantly, her palm touched a hard meat rod.

"Wah"  
"Lucky..."  
"Gulp..."

The dark-colored underwear made it hard to see in the dimness, but careful observation revealed the erect penis standing tall. Yorika's right hand, guided by Yuu, traced its surface.

"P-p-peni..."

Touching a man's thing for the first time left Yorika speechless, mouth gaping. Yuu continued unfazed.

"See? If you pull down normally, it'll catch. At times like this, spread the waistband wide while slowly pulling down."  
"Hahh"  
"Got it?"  
"Y-yes!"

The male organ she touched was harder, hotter, and larger than imagined. Her heart pounded so hard Yuu could feel it through his back. Just 2 meters away, 15 girls lined up before Yuu, staring intently at his crotch. If she hesitated any longer, anything could happen. Yorika touched the elastic waistband with trembling hands.

"Put your fingers inside, pull down a bit... See? It caught, right? Then spread the front wider."  
"Ah!"  
Yorika's right hand touched the glans. "It's fine."

Their similar heights meant Yorika couldn't see forward and had to grope. Worried she'd hurt him with the sudden contact, Yuu remained gentle, making her chest feel warmer.

"Spread the front... yes, that much. Then slowly pull down."  
"O-okay"

As the underwear lowered, the first thing revealed was the glans - turtle-head shaped as its name implied. Though reddish-purple from repeated penetration after foreskin retraction, the color was hard to distinguish in dim light. Below the flared glans and constricted coronal ridge appeared a shaft covered in wrinkles and bulging veins.

"Haa~"  
"It's Yuu-kun's penis!"  
"No way...!?"  
"I-it's too big?"

Girls inched forward to see better, but clear differences emerged between those who'd accepted it before and first-timers.

Below hung the wrinkled scrotum containing testicles - the so-called balls or nut sack. These too looked larger and heavier than normal, indicating virility.

To fully remove the underwear while keeping breasts pressed against him, Yorika bent over. Yuu cooperated by lifting each leg as Yorika knelt and took the underwear.

"Ahaha, Yuu-kun's penis! Saw it all!"  
"Still big and wonderful as ever~"  
"Aahn, I wanna touch~"

Girls like Yoko, Kazumi, Mashiro, and Yuma who'd already had physical relations relaxed their mouths as if drooling any moment or rubbed their thighs together. Seeing Yuu's penis reignited their excitement from earlier hugs and kisses - some were already wet.

Meanwhile, first-timers stood dumbfounded, mouths agape, barely speaking. First shock: it was larger than imagined. Second: Yuu showed no shame exposing his genitals before so many girls. Third: it remained fully erect. As sexually curious high schoolers, they'd acquired sexual knowledge through erotic books and videos over years. But tonight, what they'd learned was being overturned.

Yoko stepped forward, staring at Yuu with flushed face. They were practically at point-blank range. Yoko wanted to push Yuu down and unite immediately, but restrained herself for her classmates' sake.

"Yuu-kun, you said the loser obeys anything"  
"Ah, I did say that"  
"Then I want to... with Yuu-kun..."  
"Wait. There are 16 attractive girls here. Instead of one-by-one, how about splitting into two groups of eight to do whatever you want with me?"

---

### Author's Afterword

Long ago, a friend sang a parody lyric: "The love juice of men and women♪"  
Innocent me didn't understand immediately - realization came later (laughs)

### Chapter Translation Notes
- Translated "野球拳" as "baseball rock-paper-scissors" to preserve cultural reference while clarifying gameplay
- Translated "おっぱい" as "breasts" consistently per explicit terminology rule
- Preserved Japanese honorifics (-kun, -chan) throughout
- Transliterated sound effects (e.g., "tapun" for たぷん, "doki doki" for ドキドキ)
- Translated sexual anatomy terms directly: "チンポ" → "penis", "タマタマ" → "testicles"
- Maintained original name order (e.g., Randou Yorika) per Fixed Reference
- Italicized internal monologues per style guide (e.g., *(Damn, this wasn't the plan...)*)
- Used explicit terminology for sexual acts and anatomy as required