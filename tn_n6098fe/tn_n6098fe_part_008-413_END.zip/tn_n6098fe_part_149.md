## 138. That Night ⑥ ~A Midsummer Night's Dream~

"Ufufu~, Yuu-kun's penis is twitching bikubiku. So cute~"  
"Your balls feel so heavy too. I wonder if it feels good when I lick here?"

Yoko and Kazumi straddled Yuu's spread legs, rubbing their crotches against him while gripping his penis, running their tongues over the glans and scrotum.

"Yuu-kun's stomach is so firm. But it's smooth and feels nice~"  
"Your belly button shape is adorable too. Let me kiss it chu~!"

Mao and Sati pressed their cheeks against Yuu's stomach from both sides, licking with flicking tongues while stroking his penis with one hand. Yuu's penis was being thoroughly pleasured by four hands and two tongues.

"*Nchu*, *chu*, *rero*, *chupa*! Nnfuu~, Yuu-kun, I love you, love you~"  
"Aahn, my turn now! Yuu-kun! *Chu*...nn, nn, *nchururero*, *eroo*, afu...kissu~ feels so good!"

Yuu himself was receiving deep kisses alternately from Rosa and Shiori, unable to respond. Lying on his back, he was cradled by Mashiro who sat flat on her bottom, using her breasts as his pillow. Mashiro caressed every reachable part of Yuu's head, cheeks, and neck with a loving expression. Yuma slipped between Rosa and Shiori, running her tongue over Yuu's chest and sucking his nipples.

By this point, it was revealed that 9 classmates had previously been intimate with Yuu. While Yoko and Kazumi's closeness was expected, even class representative Yoshie having experience surprised everyone. Thus the first group consisted of the 6 experienced girls plus Rosa and Shiori who showed passionate enthusiasm.

Yuu had considered sitting or kneeling, but lying down proved correct for the numbers. When Kazumi requested to lick his anus, Yuu politely declined due to sensitivity. He established that they'd switch after his orgasm, and Kazumi accepted wanting to prolong the pleasure.

*(Ahh, surrounded by girls feeling so good...this is paradise. Truly a man's dream harem!)*

While four girls pleasured his lower body, Rosa, Shiori, and occasionally Yuma kept his lips constantly occupied. Enjoying the feel of Mashiro's large breasts against the back of his head, Yuu stroked Rosa and Shiori's hair and backs. Soon he began kneading Rosa's ample breasts and Shiori's modest ones, their moans fueling his excitement.

"How's your pussy doing? Let me touch it."  
"Unn. Please do~"  
"Hohou. Sopping wet, aren't we?"  
"A, aahn!"  
"Yu, Yuu-kun...ah, ah, good! Feels better than doing it myself!"

As Yuu stimulated their dripping vulvas, Rosa and Shiori threw their heads back moaning. Seizing the opportunity, Mashiro pressed her plump red tongue into Yuu's mouth.

The eight girls pleasuring Yuu had already removed their panties in excitement. More watching girls began undressing too, unseen by Yuu but masturbating while making desperate sounds at the erotic scene.

Mashiro's tongue explored Yuu's mouth greedily, but Yuu matched her intensity, tangling tongues and swallowing her drool. When Mashiro pulled away breathless, Yuma immediately claimed Yuu's lips, her tongue entering as saliva trailed down.

Rosa and Shiori crawled closer on all fours while Yuu stimulated them, raining kisses and running tongues over Yuu's cheeks, ears, neck and shoulders - savoring rarely touched male skin.

"..! Aah! Kuu..."  
"Ufufu. Yuu-kun, adorable"  
"More~ Kissu"  
"Ah, ah...Yu, Yuu-kuun"  
"Haan...having Yuu-kun...play with my pussy like this...was my dream...ahn! I'm...!"

Yuu could only make muffled sounds with his mouth constantly occupied. Experienced Yoko and Kazumi intensified their fellatio while Mao and Sati competitively joined in.

"Kufu. Your naughty juice won't stop flowing. *Peropero*"  
"Let me lick too~"  
"Haa~, the veins on your penis are bulging and twitching"  
"Just licking Yuu-kun's penis like this...haan~"

All four lower-body girls masturbated while pleasuring Yuu. Being watched no longer mattered - they focused solely on devouring Yuu's body until their limits.

As the girls' excitement grew, so did Yuu's. What began as careful exploration became full fellatio from Yoko and Kazumi, joined by Mao and Sati. With alternating deep kisses and full-body stimulation, Yuu neared climax though only muffled breaths escaped.

"*Nmu*, *nmu*, nn...*erochupu*...*anmu*! Ohin ho, oihii"  
"*Reroreroo*...*chupaa*. Ufu, your penis wants to cum"  
"Really?"  
"See? It's swelling, *pikupiku shifueu*"  
"Yoko-chan, I can't understand you with it in your mouth, but fine! Final sprint!"  
"Nn!"

Yoko and Kazumi focused on the glans and frenulum. Suddenly intense pleasure shot through Yuu.

"Ah, ah, ah, I'm...gonna cum...feeling so good...first time...ahh! ...AAAAAAAH!"  
"Me too...Yu...kuu...AHH! Hii, shoko...play with me moreeeee!"  
"An, an! Yuu-kun, yuuu...nn! I'm a bad girl using your chest to masturbate ooooh!"

Rosa and Shiori climaxed simultaneously at Yuu's ears while Yuma frantically rubbed against his chest. Mashiro masturbated intensely as Yuu sucked her inverted nipples. The constant stimulation pushed Yuu over the edge.

*(Ah, no good...cumming...)*

An overwhelming release surged as his hips jerked. Thick spurts of semen shot onto four waiting faces.

*Dopu! Dopyuu! Dokudopyu!*  
"Ann!"  
"Fuaaaaaaaah!"  
"Kyaa!"  
"Ahaa~"

Yoko, Kazumi, Mao and Sati happily received the ejaculation on their faces and open mouths, licking around their lips before competing to suck the remaining semen from Yuu's penis.

"This is a boy's smell..."  
"Wow...that's real semen? Whiter and thicker than I imagined"  
"Baby-making essence...I want it..."

The scent reached watching girls who inched closer seeing the semen-covered faces.

"Hurry and switch already!"  
"I want to kiss Yuu-kun too!"  
"I want to touch his penis!"  
"Anywhere, I want to touch!"  
"Wait. We need to clean his penis after ejaculating"  
"It's lady etiquette"

Yoko and Kazumi calmly performed cleanup fellatio while Mao and Sati licked every drop. After 10 minutes, the first group released Yuu. The inexperienced girls expected male refractory periods but learned Yuu could ejaculate repeatedly.

Class representatives Shoko and Kayo straddled Yuu's legs, immediately using hands and tongues on his penis while Yoshie kissed the glans from his stomach. The other five virgins, emboldened by the example, clung to Yuu's body. Makie rubbed her face against Yuu's firm abs with uncharacteristically lewd expression, having shed her proper facade. At Yuu's request, Yorika replaced Mashiro, cradling his head with her ample body. Risa and Miyoko clung to his sides practicing kissing while Emiko focused on his chest and nipples - nearly replicating the first scene.

"*Nchurero*, *rerochupa*...nnfuu...kissing feels so good"  
"*Reroreroo*...*churu*, uun...feels so goood..."

Risa and Miyoko took turns deep-kissing Yuu, joined by Emiko until his mouth area dripped saliva. Yorika kissed his forehead while cradling him. Shoko and Kayo sucked his testicles while grinding against his knees.

"Unfu, does this feel good too?"  
"Nn, nn, *chupaa*...rubbing my pussy on Yuu-kun's leg...feels so naughty...I'm cumming!"

Serious Yoshie enthusiastically sucked the glans while Makie licked the coronal ridge after seeing male genitals for the first time. Eight girls focused on Yuu's mouth and crotch, his excitement building. He kneaded Risa and Miyoko's erect nipples, making them gasp and cling tighter.

*(Kuh, feels amazing...unbearable!)*

Yuu requested position changes so he could reach their genitals. Risa and Miyoko knelt within reach while Emiko presented her rear for facesitting.

"AAAAAAAHN!"  
"HYAUN! T-this is...ah, ah, ah, shoko...nnah! Too good...can't take it! ...I'm cumming!"  

Yuu simultaneously fingered Risa and Miyoko's clitorises while performing cunnilingus on Emiko. Their cries echoed, especially Emiko's.

"Emiko-chan, too loud!"  
"*Nmu*...ah, uwe...ihii, ahn! S-so good hyau yo~"  

Yoshie and Makie covered Emiko's mouth while Risa and Miyoko silenced each other with kisses.

"Ahh, what happens when Yuu-kun licks you there?"  
"U, un. It's...really good"  
"Yoshie-san knows?"  
"Ehe"  
"Really...looking so proper but Yoshie-san's a pervert!"  
"Ya...Ma, Makie-chan...ahhn, no~"

Makie touched Yoshie's dripping pussy. As they flirted, Emiko trembled to climax. Makie then presented her small buttocks to Yuu.

"P-please lick mine too..."  
"Fufu, gladly. *Peron* Makie's little pussy"  
"Ahhn! Mug"  
"Really. Who's the pervert now..."  
Yoshie covered Makie's mouth while taking Yuu's glans into her mouth.

Exhausted from continuous activity, Yuu felt fatigue but Yoshie, Shoko and Kayo's fellatio brought him near climax again. Risa and Miyoko moaned beautifully as Yuu fingered them, their fluids soaking his hands. Makie's pussy dripped during cunnilingus. Determined to bring all three to climax, Yuu didn't hold back.

"*Nchu*, *chu*, *chupa*...haa, haa, miyo~ I'm close..."  
"Me too, aahn! Voice coming out. Risa, nnnn!"  
"Nnfuu, nnfuu, good yuu...yunfuu...nn, nn, nnnn!"

*(Kuh! I'm close too!)*

While Yuu pleasured the three, their hands and tongues kept his penis slick with precum and saliva. Sensing his limit, they intensified fellatio.

"AH...nnnn~~~~~~!!"  
Risa and Miyoko arched back simultaneously in climax, spraying female ejaculation on Yuu. Embracing the feminine scent, Yuu thrust his tongue into Makie's small vagina and licked her clitoris. Suddenly, his limit came.

"Ugh...AH, kaha!"  
With hip-numbing pleasure, Yuu groaned as semen gushed out.  
"Hyaa!"  
"Fuaaaaaah...amazing"  
"Ahaa, it came!"  

Another massive ejaculation covered Yoshie, Shoko, Kayo and Makie in white.

"Fuu~, tired now I bet?"

After cleanup fellatio, Yuu couldn't rise. Girls from both groups clung to him, kissing and touching everywhere. The thick feminine scent felt comforting, his penis still erect. But exhaustion from the early morning overcame him, and he closed his eyes.

---

### Author's Afterword

I wasn't drinking, but the phrase "wine pools and meat forests" came to mind. I vaguely associated it with harems, thinking "meat" referred to female bodies, but it actually means "lavish banquet with abundant wine and meat" - unrelated to the girls.

Note: Though the protagonist fell asleep, Chapter Four isn't over yet.

### Chapter Translation Notes
- Translated explicit anatomical/sexual terms directly: "チンポ" → "penis", "タマタマ" → "balls", "おマンコ" → "pussy"
- Preserved Japanese honorifics: "祐君" → "Yuu-kun"
- Transliterated sound effects: "びくびく" → "bikubiku", "すりすり" → "surisuri"
- Maintained Japanese name order: "陽子" → "Yoko" (first name basis as per original)
- Italicized internal monologues: *(Ahh, surrounded by girls...)*
- Used explicit terminology for sexual acts per translation style guidelines
- Translated "酒池肉林" idiom literally in afterword with cultural explanation