## 139. That Night ⑦ ~An Unyielding Wish~

After Yuu fell asleep on his back, the girls lay on their stomachs, gazing at him while encircling him.

With all 16 of them present, their bodies pressed tightly against each other.

Though the room had been sweltering with heat earlier, their sweat had now dried, and the breeze from the open window felt pleasantly cool.

Having shared this special night with Yuu had deepened their bonds, and with their bare skin touching, the warmth felt comfortably intimate.

It was past 1 AM - their usual bedtime.

Though they certainly felt sleepy after climaxing from Yuu's cunnilingus and fingering, or masturbating while caressing him, their desire to watch Yuu's sleeping face and stay by his side was even stronger.

"Yuu-kun's sleeping face is so adorable."  
"I could watch it all night long."  
"Same here!"  
"Seriously, Yuu-kun's like an angel."  
"A really perverted one though."  
"More like a little devil?"  
"Both!"  
"No, he's practically a god. A male god (GOD)."  
"Yuu-kun is Yuu-kun! His face and personality are the best! Hehe."  
"Hey, don't drool!"

The girls peered at his sleeping face while whispering their assessments. Unable to resist just looking, they tentatively reached out to gently stroke his head and cheeks without waking him.

"Earlier I was too caught up, but boys' bodies are like this..."  
"Even though Yuu-kun is slim, he has nice muscles."  
"When he hugs me, my head goes all fuzzy."  
"He smells good too."  
""""We know!""""

They softly stroked Yuu's shoulders, chest, and stomach, with some even sniffing his skin. His hands had been claimed by the quickest girls and pressed against their breasts.

But the hottest gazes focused on his crotch. The penis that had been fully erect earlier had returned to its normal state after Yuu fell asleep. Regardless of whether they'd experienced Yuu before, their fascination with the male organ remained endless.

"Is this its normal size?"  
"Y-yes, I suppose."  
"But isn't it big? Thick?"  
"I know! I heard the average erect penis is about 10cm. Which means... Yuu-kun's current state is about that size."  
"And it doubles when erect?"  
""""Wow!""""

"You know... I've only been with Yuu-kun, but I couldn't imagine being with another man now. Only Yuu-kun for me."  
""""Me too!""""  
"Ahh~ I'll never forget the day Yuu-kun first took my virginity."  
"Ugh! How enviably shameless!"  
"Don't worry. If you ask Yuu-kun, he'll definitely take your virginity. Though who knows when that'll be."  
"What's with that condescending tone?"  
"Now now."

"But you should prepare yourself. Yuu-kun is incredibly strong down there too. It feels too good. He'll make you climax over and over. You might even faint?"  
"Exactly! Men in adult videos can't compare. Truth is stranger than fiction. Yuu-kun teaches us female pleasure repeatedly - he's the best."  
"Whoa~"  
"Hearing that makes me want Yuu-kun's penis even more!"

The last comment came from class representative Yoshihara Makie. Though she'd maintained a strict facade until now, Yuu had easily stripped away her mask. Panting heavily, she cautiously extended her index finger toward it. Leaning down, she lightly poked the wrinkled penis.

"It's soft!"  
Then several other fingers imitated her, poking the penis. Hands soon reached down to stroke his lower abdomen and firm thighs too.

"In romance manga and dramas, you sometimes see 'goodnight' or 'good morning' kisses, right? I always dreamed about that."  
"How maidenly."  
"What's wrong with that? So when there's a wonderful boy sleeping right before me... I won't wake him... okay? Okay? I'm doing it!"  
""""Ah!""""

Without a word, Kino Emiko - normally quiet and unassertive - stole a kiss. Having experienced intense intimacy with Yuu, she seemed to have broken out of her shell, unable to resist acting.

"Me too!"  
"And me!"  
"Wait, Risa-chan and Miyo-chan like Higashino-kun, right?"  
""""Right now we want Yuu-kun!""""

Ukawa Miyoko and Sato Risa harmonized as they successively claimed Yuu's lips. The girls who'd been watching his sleeping face now showered kisses not just on his lips but his cheeks and forehead.

"Haah, haah... Yuu-kun touched my breasts and everywhere... it felt so good."  
"Yuu-kun's hands are sometimes gentle, sometimes wild... impossible to resist."

Anzai Rosa and Mano Shiori pressed Yuu's hands against their breasts while breathing heavily. Beyond stroking his chest and stomach, some girls even began licking him.

Meanwhile, the six fingers poking at his lower half gradually escalated. They stroked the glans like petting it, formed circles with thumbs and index fingers to gauge its thickness, or cupped the scrotum in their palms. As they did, the snake began raising its head, swelling and rising...

""""Whoa!""""  
"Th-this is...!"  
"Amazing! It's getting bigger!"  
"Go, penis-sama!"

The fully erect penis now pointed toward his face along his lower abdomen. Encouraged by the stroking fingers, it rapidly grew in length and thickness, veins bulging as it reached full erection. Someone audibly gulped.

"I-it got hard."  
"And big... and hot..."  
"Haah, haah."  
"Ahh, Yuu-kun's penis..."

Those watching closely - led by Hiyama Yoko - were mostly experienced girls. They knew firsthand the allure of this majestic, savage flesh rod. Vivid memories flooded back of it plunging deep into their vaginas, knocking against their cervixes, and making them climax repeatedly - their lower abdomens twitching. But for now, they kept their touches soft, not taking the final step.

Meanwhile, though Yuu had initially fallen asleep, he'd begun enjoying this female siege in his half-dreaming state. As kisses rained down, his hands were taken to feel breasts, and his penis was endlessly stroked, he gradually awakened. Understanding the situation, he pretended to remain asleep, surrendering to their attentions.

"I can't... hold back anymore!"  
"Huh?"  
"Ah!"  
"Mashiro!?"

At that moment, among the girls touching the erect penis, Goto Mashiro suddenly leaned forward, straddled Yuu, and guided him into her vaginal opening with her hand. Her classmates froze in shock at this sudden move from the normally quiet girl, only able to watch.

"Ah, haah... Aaaaaaaahhhh! I-it's going in! Yuu-kun's penis! Th-this is what I wanted... ahhn! Feels good!"  
Mashiro had achieved her long-awaited virginity loss with Yuu, followed by sex once more. But with Yuu busy, it had been about two weeks since their last encounter. Both times had been threesomes with Yuma, but sex with Yuu was a seismic experience etched into her mind and body. Masturbation couldn't compare. Yuu was every girl's dream partner - impossible to have at will. Yet she desperately wanted to reconnect, to relive that overwhelming pleasure. Tonight's hugs, kisses, and caresses had been blissful. But watching classmates gleefully stroke and suck Yuu's erect penis became unbearable. Seeing the penis of her dreams rapidly enlarge before her eyes made Mashiro's lust explode.

"Ahh! Mashiro, you!"  
"Sneaking ahead, how unfair!"  
"I was holding back too!"  
"Ugh, sorry sorry sorryyyy... but once it's like this... I can't stop! Ahh!"  
They couldn't forgive this sneak attack. Yet they understood Mashiro's longing to connect with Yuu. And once you accepted that pleasure, you became intoxicated. The experienced girls watched Mashiro with complex feelings.

"Ahhn! Ahhn! Yuu...kun! I'm... assaulting the Yuu-kun I love... like a rapist... I'm a bad girl! But... but ah, ahhhhhhhh!"  
Mashiro shook her ample breasts as she desperately thrust her hips. Tears dripped from her eyes as she looked down, hands on Yuu's chest. Suddenly she noticed - Yuu was looking back at her, eyes open. His left hand suddenly rose, grabbing and kneading her breast. His right hand reached for her wet cheek.

"Ah...nnn!"  
"You're hopeless, Mashiro."  
"Yuu...kun?"  
"If you wanted it this badly, you should've said so."  
"Huh?"

Yuu caught her tears with his fingertips and gently stroked her cheek.

"Fine. Use my penis as much as you want. If it makes you feel good, that's a man's greatest reward."  
"Ah... haaaaaaahn! I... love you... Yuu-kun!"  
Hearing this, an emotional Mashiro hugged him tightly and crushed her lips against his. They kissed voraciously.

"Ahhn! I want Yuu-kun too!"  
""""Me too, me too!""""  
"Ugh... I want to lose my virginity to Yuu-kun too..."  
"Gulp... then me too..."  
"B-but wait! How many of us are here? Even if Yuu-kun is strong, handling 16 is impossible."  
""""Ugh...""""  
"Then how about this?"

Yuu responded to Aramaki Yoshie's words after breaking the kiss. Still kneading Mashiro's breast from below and stroking her head, Mashiro kept thrusting with a blissful expression.

"Honestly, I can't creampie all 16. So let's switch when someone climaxes. We'll go as far as possible."  
"Ah... okay."  
"Then who's next?"

Hiyama Yoko spoke while scanning the group, her expression making clear she wouldn't yield her turn.

"I think Yuu-kun should decide the order."  
"I agree."  
"That's the only way."  
"""""Agreed!"""""

When Yoshie calmly suggested this, Makie immediately supported it. Everyone quickly agreed. Yuu also wanted to prevent the girls from fighting over turns.

Mashiro threw her head back, thrusting violently as sticky wet sounds came from their joined area. Though trying to suppress her voice, her climax was clearly near. After brief thought, Yuu spoke.

"Then... since we started by attendance number, now we'll reverse it."  
All eyes turned to Randou Yorika - number 34, last in order. She'd been relaxing near Yuu's head, thinking her turn wouldn't come soon. "M-me next...?"  
"Sounds good."  
"If Yuu-kun says so, it's decided!"  
Mano Shiori and Yokota Satilat nodded.

"Ugh... I'll endure."  
"I miscalculated..."  
Aki Kazumi and Yoshie - now last - slumped dejectedly. But Yuu offered consolation: "The penis order is set, but I want to kiss and touch everyone simultaneously."  
The girls immediately swarmed his upper body, pressing against his face and torso.

"Ahhh! I-I'm cumming, cumming, aahhnm... nn! Ugh!"  
Mashiro finally threw her head back with a loud cry, prompting nearby classmates to cover her mouth. As she collapsed onto Yuu's chest, her large breasts deformed against him.

"Did you cum? Mashiro"  
"Yes... it felt... sooo good."  
"Glad to hear it."  
"Ahhn, Yuu-kun, love you love you!"  
"Okay, switch time!"  
"Ahhn, just a bit more..."

As Mashiro began nuzzling his cheek, she was promptly moved aside. Lying on a separate futon, she looked satisfied and soon began snoring.

"Um... is this okay? Sorry if I'm heavy."  
"Not at all. Here, I'll help."  
Yorika straddled him with a body as ample as Mashiro's. Yuu sat up into a missionary position, supporting her with his arms. His height placed his face against her breasts, making him smile. Aligning the tip with her vaginal opening produced a squelch.

"You can relax now."  
"Nn... ah, this... it's touching... ah, it's going in!"  
"By the way, is your hymen intact?"  
"Well... it's already broken."  
"I see. Then here we go."  
"Gaaah!"

Yuu felt his penis sink deep from Yorika's weight. Though not breaking through, the pain of first-time penetration showed on her face as she gripped his shoulders.

"Come on, relax more."  
"Hyaahn!"  
Yuu massaged her breast with one hand while sucking it. "Ah, ah, Yuu-kuun... my breasts feel... good too. Haan"  
"Chuupalero, lero, nchuu! Yeah. You're relaxing nicely... oh! Yorika's inside feels amazing!"  
"Ah... ah... gaaaah! I-it's, uwaa... th-this penis... ahhi, it's huge inside me... so full!"  
"Kuu! It's squeezing me!"

Hugging in missionary position, Yuu and Yorika began moving. Three girls pressed close from his sides and back - they'd agreed to wait nearby in order. Others watched from a slight distance.

"Hey, Yuu-kun's different from regular boys, right? Does he prefer bigger breasts?"  
"Hmm... not necessarily."  
"Yuu-kun said he loves all girls' breasts - big or small!"

Seeing Maegashira Yuma - nearly flat-chested - puff out her chest, Nakai Mao, Rosa, Risa, and Miyoko exchanged glances. They'd heard rumors that tall girls weren't preferred by boys, which worried them. But though all four were taller than Yuu, he'd never complained. Learning he didn't discriminate based on size increased their admiration.

"Does it still hurt?"  
"U...n...nah! N-not... painful. Rather... it feels... good! Ahhn... Yuu-kuun!"  
"Good. Ahh... I'm feeling... incredible too..."

Yuu thrust upward while exchanging kisses with Yorika, Satilat to his left, Makie to his right, and Shiori hugging from behind. Yorika's breasts pressed against his chest with each movement, swaying voluptuously. But nothing compared to the virgin vagina tightly gripping his penis - sending electric pleasure through him with every thrust. Already on his second partner, Yuu neared his limit.

"Ah, ah, ah... Yuu-kun, Yuu-kun! Ahn! Th-this is... my first time... gaaah! Feels... so good! Yuu...kuuuun!"  
"Kah... Y-Yorika, I'm... gonna cum! Let's cum together!"  
"T-together... with Yuu-kun... cumming! Ah, ahi, shonna, no! Mmmph! Nnnnnnnnnn ughf...ahn!"  
Hugging tightly, Yuu released his seed inside Yorika. Receiving it, Yorika felt unprecedented pleasure pierce her from the lower abdomen. Trying to scream, her mouth was covered as she climaxed with muffled moans.

"Fu, fu, fu. I never imagined my first time would come so soon. Mmm, but isn't this penis too big? H-how will it fit?"  
"Don't worry. Yuu-kun's penis feels amazing."  
"Is that so... Then I'll accept it graciously."

After Yorika's successful deflowering and creampie, Yoshihara Makie approached with bated breath, watched by Yuma. Both under 150cm with small faces, slim builds, and nearly flat chests, they were Class 5's petite duo.

Though Yuu had just ejaculated for the third time, he remained surrounded - Makie hugging him frontally while others pressed from sides and back. With beautiful nude girls closing in from four directions, arousal was inevitable.

"Hmm. Makie's first time too? Okay! This time I'll be on top!"  
"Huh?"

Yuu gently pushed down the blushing Makie, supporting her head with his left arm as he covered her small body.

"Come on, relax and leave it to me."  
"Yu, Yuu-ku... mmph!"

He began with light kisses. Her small face and lips felt childlike, stirring guilty excitement. But when Yuu spread her legs and pressed his hard penis against her vulva, it was thoroughly wet.

After repeated pecking kisses, their tongues lightly touched before Yuu invaded her mouth. His right hand touched her nearly flat chest, lightly massaging and teasing her nipples. Rubbing his penis against her produced slick sounds.

"Ready? I'm going in."  
"F-fine. Come at me."

Makie's sparse pubic hair framed a tiny slit that seemed too small even for a finger. Pressing the tip against it, Yuu pushed firmly.

"Guh! Gai! Ii... iaaauuuuunnnnnnn..."  
"The pain is only at first. Endure it."  
Makie nearly screamed from defloration pain as Yuma covered her mouth. "Sorry. Your pussy's so tight. Almost... kuu!"

After full insertion, Yuu held Makie and thrust slowly for her sake.

"How is it? Getting used to it?"  
"Gah... haah... I'm, getting... better..."  
Sweat beaded on Makie's forehead as she frowned, but meeting Yuu's gaze, she managed a clumsy smile. "I... I'm... really happy... my first time is... with Yuu-kun. Sorry... for acting arrogant earlier... I couldn't be honest."  
"Makie!"  
Seeing her obsidian eyes looking up with a brave smile, Yuu felt sudden affection and hugged her tightly. "Ahn! Yuu...kun!"  
Makie desperately wrapped her arms around his back. Though they'd never seen male-superior positions even in erotica, watching Yuu and Makie seemed deeply satisfying - making the waiting girls gaze enviously.

*(Kuu~. Even after cumming three times, it's getting dangerous again. Virgins really are special. Maybe I messed up the order.)*  
Yuu thrust with their bodies tightly joined. The freshly penetrated virgin vagina remained incredibly tight, gripping his penis fiercely even after ample lubrication. Though moving slowly, each friction against the folds sent paralyzing pleasure through him. He was already nearing his limit with his third partner.

"Ahk... Makie, sorry... but I'm gonna cum."  
"Ah, nn, nn, nha... Yu, Yuu-kun... don't... mind me... ahn! I'm cumming... nn, nfuun"  
"Oh... guh... Makie!"  
"Yu, Yuu-kun! Ahhn! So intense!"  
Yuu's thrusts accelerated until reaching their peak, when he released his seed against her cervix.

"Ah... ahh... hahyu... it's coming... haaaaahn... so much seeeemen, coming ouuuuut!"  
Having never even masturbated before, Makie didn't climax internally this time. But embraced in Yuu's arms while receiving his cum, she closed her eyes with deep satisfaction.

---

### Author's Afterword

13 left. I certainly don't plan to write everyone at this pace.

I'll pick a few more first-timers to focus on, skipping or abbreviating others while seeing it through to the end.

### Chapter Translation Notes
- Translated "ちびっ子コンビ" as "petite duo" to convey physical smallness while avoiding derogatory tone
- Translated "破瓜の痛み" as "defloration pain" for anatomical accuracy
- Preserved Japanese honorifics (-kun) and name order throughout
- Used explicit terms: "penis", "vagina", "creampie", "defloration" per style rules
- Transliterated sound effects: "gururi" (ぐるり), "chuchu" (ちゅーちゅー), "nchuu" (んちゅう)
- Italicized internal monologue: *(Kuu~. Even after...)*
- Maintained dialogue formatting rules (new paragraph per speaker)