## 140. That Night ⑧ ~You're My Only Shinin' Star~

### Author's Preface

Order is reverse of Chapter 136 except for Mashiro going first.

Goto Mashiro → Clear!  
Randou Yorika (Virgin) → Clear!  
Yoshihara Makie (Virgin) → Clear!  
Yokota Satilat → Next  
Mano Shiori (Virgin)  
Maegashira Yuma  
Hiyama Yoko  
Nakai Mao  
Shimozono Kayo  
Sato Risa (Virgin)  
Kino Emiko (Virgin)  
Ukawa Miyoko (Virgin)  
Ueno Shoko  
Anzai Rosa (Virgin)  
Aramaki Yoshie  
Aki Kazumi  

---

"Haah, haah, haah...nnn...aaahn! N-noo...I don't...want to cum yet...Yuu...ku...nnnnn! I-It feels too...gooood...Vwah! Nnnnnnnnnnnnnnnnnnnnnn!"

Satilat, straddling Yuu who lay on his back while shaking her long black hair tied in a single knot, seemed to have finally reached her limit as she desperately rocked her hips. Covering her own mouth with her hand, she collapsed forward, burying her face in Yuu's neck as she came.

"Aahn, what a shame. I wanted to cum together with Yuu-kun too..."  
"Haha. I felt really good too. But men last longer after ejaculating."  
"I want...more...chu"

Satilat looked down at Yuu with a smile oozing sensuality unbefitting a first-year high schooler, her complexion a healthy tan though her facial features were nearly indistinguishable from a Japanese person's. After pressing her lips against his repeatedly, she reluctantly got off Yuu when urged by Shiori with "Your turn."

---

"This is...ahh! I can't believe these hip movements for a first-timer...kuh!"  
"Haa, haa, haan! I trained...using a vibrator...ahn! For this day! But...Yuu-kun, it's too big! Aah! And so thick...the glans catching on...fah! Ah...no...ah! Ah! Ah! Aah!"

Shiori's long black hair swayed violently like undulating waves as sweat flew from her white skin. Her modest bust and slender waist that seemed ready to snap contrasted with her slender face. With long eyelashes and narrow eyes usually cast downward, Shiori gave the impression of a refined young lady from a good family who was close with class representative Yoshie but never sought attention. 

But after experiencing her first kiss with Yuu, she'd become surprisingly proactive. Beneath that quiet exterior seemed to swirl passionate emotions. When she took over from Satilat and inserted herself, she moaned and trembled, unable to move at first. But when Yuu called out to her, Shiori smiled sweetly and began moving her hips smoothly.

Shiori ground her hips while breathing raggedly, furrowing her brows in a pained expression - not from defloration pain but from resisting being swept away by pleasure greater than expected from accommodating his massive cock. Unlike Satilat before her, Shiori intended to endure until receiving Yuu's seed.

Looking up from below, Yuu grew aroused emotionally as well as physically watching her. He found it wonderful how each girl showed completely different sensual expressions when joining bodies like this.

"Shiori!"  
"Kyaah!"

Yuu used his abs to sit up abruptly, hugging Shiori while kissing her as he shifted to a facing seated position.

"Yah! D-deeper than...before! Hitting...deep inside...ah! Ah! Ah! Ah! I'm going...craaazy!"  
"Hm? Is this no good?"  
"Noo...not 'no'...more...please?"  
"Ahh, so erotically cute. I'm happy to have sex with you like this, Shiori. I'll do my best"

Whispered in her ear by Yuu, Shiori felt something hot melting inside her. Though she'd planned to resist pleasure and make Yuu cum first, she was losing confidence it would work.

Ultimately, Shiori also wrapped her legs around Yuu's waist, becoming one with him as they climaxed simultaneously. That she'd experienced consecutive orgasms would remain Shiori's secret.

---

"Yuu-kun, thank you for your hard work"  
"Are you still okay?"  
"You've taken on five people already. It's natural to be tired"

Starting with Mashiro, Yuu had ejaculated three times with five partners. Including earlier when eight girls pleasured him together, that made five ejaculations. Having unexpectedly ejaculated from pleasure beyond expectations was likely due to three virgins being included. Normally he'd want to rest here, but two-thirds of the girls remained. Seeing them fidgeting while rubbing their thighs together and staring at him with heated eyes, Yuu resolved to push himself to the limit.

Yuu sat leaning against the wall, gulping down the 350ml canned juice the girls bought from a vending machine after their bath. Even lukewarm and half-finished didn't bother him. Not wanting to finish them all, he took three sips each from the three offered cans (orange, cola, oolong tea).

"Ahaha...your cock's energetic again!"  
"Yuu-kun, amazing"  
"Aahn...I want it soon..."  
"Next is Yuma, right?"  
"Unn!"

Among three girls burying their faces in Yuu's crotch to suck him, Yuma looked up and smiled innocently. Finding it adorable, Yuu stroked her head, making her narrow her eyes contentedly.

To conserve energy, Yuu lay on his back as Yuma happily straddled him. Like Mashiro, this was her first taste of Yuu's cock in a while. She intended to endure and enjoy it as long as possible...but...

What followed was Yuu's triumphant advance...or rather, the girls fell one after another. After Yuma, Yoko, Nakai Mao, and Shimozono Kayo lasted only minutes each. The reason? They'd gotten sufficiently aroused masturbating while waiting their turn. Insertion sent them rocketing to intense pleasure with no chance to resist - essentially self-destruction.

"Haaaaa...I was no match for Yuu-kun's cock"  
"I thought I'd lose consciousness..."  
"Pathetic after finally getting my turn...but it did feel amazing"

The four lay strewn like corpses on a separate futon. Though not receiving seed, Yuma slept soundly already, thoroughly satisfied from the intense pleasure. Yoko still displayed a dazed expression after squirting dramatically, legs spread in a starfish position. Mao and Kayo embraced each other, basking in the afterglow.

Ignoring them, Risa tried straddling Yuu. Her over 180cm frame brought some pressure. As a volleyball team attacker, her arms and thighs were solidly muscled with defined abs - a sturdy build. But Yuu wasn't spoiled enough to discriminate by body type. Like when he bonded with protection officer Kanako, he found trained female bodies beautiful.

Yuu knew Risa admired her friend Higashino Rei like Miyoko. He had no intention of stealing them while they remained more-than-friends-less-than-lovers. Rather, he thought this could serve as practice.

"Think of today as practice, so tell me anything you're unsure about"  
"U...un. Thank you. Is this angle okay?"  
"A bit more, lift your hips and shift back"  
"Like this...ah! It touched!"  
"Place one hand on the cock to adjust the angle"  
"Umm...kyah!"

Risa had been attempting insertion on all fours over Yuu when he suddenly groped her modest breasts.

"Don't tense up so much"  
"Anh. Really...Yuu-kun"  
"Let's kiss, Risa. Kissing feels good, right? You'll do better relaxed"  
"Nn..."

As Risa bent her upper body down to kiss, the cock tip touched her vaginal opening. When she lowered her hips, the moistened entrance accepted it easily, but tight vaginal walls immediately blocked further progress. Pausing briefly, Yuu and Risa cooperated to connect deeper. Though Risa moaned somewhat painfully with muffled sounds, Yuu held her head down with his right hand, not letting go. Slowly, taking time, they connected fully.

---

Though tightly squeezed inside athletic Risa's vagina, her movements remained awkward as a first-timer. Perhaps because Yuu was building tolerance, Risa climaxed first at the critical moment, leaving Yuu unsatisfied as he vigorously thrust into next-in-line Emiko.

Intending to muffle sounds by pressing his lips, Yuu fucked like an animal nearing ejaculation. Whether from defloration pain or joy that a plain girl like her lost her virginity to Yuu - or both - tears spilled from Emiko's double-lidded eyes as he ravaged her mouth.

"Ugh...haa, haa, sorry Emiko. I got rough. Did it hurt?"  
"Feh...n-not at...not at all! It's fine. Do...as you like, Yuu-kun"  
"Really...Emiko's so kind"  
"Not really..."  
"I like kind girls like you, Emiko"  
"Fah!?"

Emiko's face flushed crimson when Yuu whispered in her ear, her lower abdomen twitching painfully.

"Yu...u...kun!"  
"Yeah?"  
"C-cum...more...inside me...move!"  
"Thank you...I'll ejaculate...inside you like this!"  
"Ah...ahn! Want it...Yuu-kun's...cum! Give it to me...inside!"

Hugging petite Emiko under 160cm, Yuu gradually increased thrusting speed. Now overwhelmed more by pleasure than pain, Emiko desperately clung to Yuu's back with both hands. Soon both reached climax simultaneously, and Yuu, releasing seed inside Emiko, felt exhaustion wash over him as they remained embraced.

---

Another break for hydration. Though concerned about his condition, Yuu intended to see it through now that he'd come this far. He felt fatigue but his libido showed no signs of waning - seemingly limitless. Indeed, when he beckoned next-in-line Miyoko, he embraced her trained body...or rather, given their physiques, she embraced him. While exchanging kisses with Miyoko, Yuu's cock - attended by Shoko and Rosa joining Miyoko - stood fully erect from their handjobs.

"Yuu-kun..."  
"Think of it as practice too, Miyoko. Just hop on casually"  
"Un, thank you"

As Shoko and Rosa's hands withdrew, Miyoko shyly straddled Yuu sitting cross-legged.  
"Nn...ahh...it's touching. T-this is..."  
"Y-yeah, good. Now lower your hips"  
"Nnn...gah! It's...entering!"

According to prior information, like Risa, Miyoko's hymen had torn unnoticed during intense practice, not from vibrators. Thus no bleeding from defloration. But a virgin vagina first receiving male genitalia proved extremely tight, and Miyoko sweated on her forehead as she applied weight, taking time for full insertion.

---

"Yuu-kun really is amazing. I never thought my turn would come. And now to be with Yuu-kun again...ah...gaaaaaaahn!"  
"Ah, I wanted to have sex with Shoko again too"  
"Anh! Even flattery makes me happy. Leave it to me. I'll make you feel good"  
"Ohh...squeezing my cock tight...feels good"

Ueno Shoko, softball team pitcher (a first-year substitute), had broad shoulders and muscular build - the sturdiest physique among the sixteen. Plus large breasts. Though starting with slow movements to acclimate, Shoko's expression grew ecstatic feeling her cervix being steadily struck. Grabbing Yuu's shoulders firmly, she began thrusting violently.

"Haa, haa...ahn, ahn! Yuu-kun! Good! Good! Aahn! Can't...stop my hips!"  
"Ooh...wow..."

Yuu enjoyed the oncoming pleasure while greedily kneading the breasts bouncing before him.

---

Ultimately, Yuu endured until Miyoko and Shoko climaxed. Though conserving energy by having girls ride him, he thrust at critical moments to make them cum. Nearing physical limits, Yuu never showed pain when meeting Rosa's eyes as her turn came.

Rather than immediately straddling, Rosa snuggled close to Yuu's right side. First gently stroking his cock with her left hand while moving her gaze from crotch to stomach to chest.

"Rosa?"  
"Since this is the last view tonight, I want to look at Yuu-kun's body thoroughly"

Smiling bewitchingly, Rosa traced Yuu's chest with her right hand, gradually moving upward to his face. Slowly covering him while pressing her ample breasts against him.

"Yuu-kun, I'm filled with gratitude to God for meeting you, exchanging words for the first time at the entrance, you holding my hand. And...being able to have sex tonight."

As Rosa's wavy long hair slipped down, her soft lips touched his. At that moment, he heard her whisper "I...love you" just for him.

Stroking her soft hair, Yuu said: "Truthfully, when I first met Rosa, I thought how great it'd be to have sex with such a beautiful girl"  
"Eh...y-you don't need to flatter"  
"It's not flattery. Didn't you notice me staring at your chest when we first held hands at the entrance?"  
"Ah..."  
"Being able to have sex with Rosa like this today makes me really happy too"  
Yuu's right hand scooped up and kneaded a breast too large for Rosa's hand.  
"Ahh! Yuu-kun, really!"

Hiding embarrassment, Rosa pressed her lips to his, spreading her long legs to straddle him.

"Nchu, chu, chu, chupaa...haa, haa. I planned to take more time...but hearing that...I want it now!"  
"Come, Rosa"  
"Yuu-kun! Gah! T-this is...Yuu-kun's cock...bigger than imagined...guh...ugh...so big...nnnnnnnnnnnnnnnnnnnn! Kuh, fuuuuuu...oh, deep...so deep...gaahn!"

Though Rosa possessed sexiness unbefitting a first-year, her movements proved awkward from first-time nerves and the cock's unexpected size. Summoning his last strength, Yuu matched her movements by thrusting upward.

Squelch! Squelch! Squelch!  
"Hauu...ah! Ah! Gh! Giiin!"

With both hands on Yuu's chest, Rosa rocked her hips back and forth. Timing his upward thrusts, uncontrollable moans escaped her.

"Ahh...Yuu...kuun!"  
"Rosa...y-you're good for a first-timer!"

Initially keeping her upper body upright while thrusting, Rosa's movements gradually smoothed, producing loud wet sounds from their joining. Now fully transformed into a lustful woman, Rosa looked at Yuu before covering him completely, not just kissing but inserting her tongue.

Mutual arousal peaked as they devoured each other's mouths breathlessly, slamming hips together. For once, Yuu forgot fatigue as his body moved instinctively.

"Gah! Gh! Gfuuuu"  
"Ugh! Ah! I-I'm..."

Now completely covering him in close contact, only their hips ground together while deeply connected.

"Rosa...I'm...cumming, ugh!"  
"Ah! Inside...growing bigger...ah...no...hiiiiin! Cumming!"

Yuu released his fifth load of the night inside Rosa, the fourteenth girl, as she climaxed simultaneously, wearing an expression of deep satisfaction.

---

Wanting to do something special for Yoshie who'd worked hard organizing, Yuu thought of 69. It wouldn't require much energy and both could feel good. Seemed a nice idea.

But whether good or bad for Yoshie: though she'd resisted masturbating, Yuu's tongue and fingers made her drip arousal fluid as she writhed wildly. Upon insertion, she climaxed in under a minute.

---

Now the room was quiet. Most girls Yuu serviced slept piled together. Nearby on both sides lay Rosa and Yoshie, just disconnected. Rosa lay sideways keeping Yuu in view, both hands pressed to her crotch seemingly to prevent semen leakage. Opposite her, Yoshie still seemed dazed with lingering body heat, staring at Yuu with half-closed eyes.

Finally, last-in-line Kazumi straddled Yuu, showering not just his lips but face, ears, and neck with kisses. Without immediate insertion, she sandwiched his erect cock between her thighs, rubbing slowly.

"Ufufu. I'd nearly given up, but now I think being last is best. After all, I can have Yuu-kun all to myself without anyone rushing us"  
"K-Kazumi..."  
"Yuu-kun, you worked so hard. It's okay. Leave it to me. I might not be skilled...but I want to make Yuu-kun cum last"

As her personality suggested, Kazumi smiled gently. Yuu's body felt heavy as if weighed down multiple times, even moving his arms burdensome. Still, he stroked Kazumi's head with his right hand and her plump buttocks with his left.

"I'm glad you're the finale, Kazumi. Use my cock as much as you want"  
"No way, not just me - Yuu-kun should feel good too"  
"Haha, right. Together..."  
"Un. Yuu-kun...I love you. Since first meeting at club observation. A dazzlingly cool person. Wonderful smile and kindness. And...lewd. I love everything. To me, Yuu-kun is special. Forever..."  
Kazumi shifted her hips slightly forward, aligning the tip with her vaginal entrance.

"Ah...ahh, it's entering"  
"Ooh"

As the cock slid in slowly, Yuu felt enveloped in warm, soft flesh. Simultaneously, he hallucinated: a world without chastity reversal where genders were equal. Reborn as a high schooler, Yuu grew interested in classmate Aki Kazumi. When? When clumsy Kazumi nearly fell in the hallway and Yuu caught her? Or when their fingers touched as he picked up stationery she dropped? They began noticing each other, awkwardly conversing, eventually talking nightly by phone. Even as classmates speculated "Are they dating?", time passed without progress until friends encouraged Yuu to confess behind school. They started dating, gradually deepening their relationship...

"Kazumi, I love you too. However we met, I'd have fallen for you"  
"Gahh! Aahn...nn, nfu...gahfeeeee"  
"Huh? What?"

The moment it fully entered, Kazumi threw her head back with a moan before collapsing face-first onto his neck.

"Because...just as you said that...it went deep inside...I...came already"

Kazumi whispered shyly, just for Yuu. His chest grew warm as he hugged her tightly.

"It's fine. Cum as much as you want. Tonight you're last"  
"U...n...thank you. H-happy"

Lifting her face with a smile, Kazumi kissed him and began moving her hips.

"Ah...nnn...ahn! Nooo, feels too good...going crazy! Haan!"  
"O-oh...me too...so good. Ah, Kazumi's vagina...so hot...rubbing with every move...feels amazing"

Beyond their connection, Kazumi's moderately toned yet soft body pressing close felt extremely comfortable. Though mentally and physically exhausted, Yuu's core seemed to boil hotter, craving more pleasure.

Chup. Jurr. Nechaa. Kuchu, kuchu. Nicha. Jupp, jupp.

Their deep kiss with tangled tongues, sweat seeping where skin touched, and sticky love juice from their joining intermittently created sound. Yuu wanted to ejaculate inside her, to pour his seed - to have it poured into. Their animalistic mating continued as if dominated by primal instincts.

Eventually, unable to endure the persistent stimulation from folds wringing his essence, Yuu's cock neared its limit. Though suppressing sounds, Kazumi dripped sweat from her forehead and drool from her mouth as she came repeatedly at intervals.

"Gah...nnn...nn! Hauu! No more...Yuu...kun! Cumming...again..."  
"Kuuu, Kazumi, I'm at my limit too...ahh! Together...ugh...cumming!"  
"Hya! Ahn! Okay! Okay! Yuu...ku...n...I'm...cumming too! Gah! Cumming!"

Yuu released his eighth load of the night deep into Kazumi's vagina against her cervix. Confirming she'd climaxed too, Kazumi released consciousness with a satisfied expression.

---

### Author's Afterword

This concludes Part 4.

The Saiei Academy visit I initially considered including in Part 4 will be in Part 5.

Thus Part 5 will have many personally challenging scenes, so I'll take about a week to plan and stockpile chapters.

During that time, I'll update the character introductions.

Check out this interesting work I'm introducing here:  
『Nocturne Author Introduces Chastity Reversal Novels』  
https://novel18.syosetu.com/n9397ez/

### Chapter Translation Notes
- Translated explicit anatomical/sexual terms directly: "膣" → "vagina", "チンポ" → "cock", "精液" → "semen"
- Preserved Japanese honorifics: "祐君" → "Yuu-kun"
- Transliterated sound effects: "ばちゅん" → "squelch", "じゅるっ" → "jurr"
- Maintained Japanese name order: "上野 祥子" → "Ueno Shoko"
- Italicized internal monologue: "（ち、近い！）" → *C-close!*
- Used explicit descriptions for sexual acts per translation style guidelines