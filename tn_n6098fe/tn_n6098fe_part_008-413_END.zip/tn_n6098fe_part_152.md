## 141. That Night ① ~Midsummer Fruit~

### Author's Preface

Sorry to keep you waiting.

Chapter Five begins now.

I've added Chapter Four characters to the character introduction section.

---

Even after summer vacation began, Hirose Yuu continued his busy days.

The first peak came on July 27th when they simultaneously held the first Ayakuni Cup Quiz Championship featuring inter-school competition with Saiei Academy, and the school camping event for gender interaction.

In the evening, he cooked curry for the large group during the camping event and danced nostalgic folk dances with the girls, creating happy memories.

Afterwards, on the liberated rooftop, he gazed at the night sky while having sex with Emi.

At the lodging facility, after deepening bonds with senior male students, he barged into the room where Class 1-5 girls were staying.

There, he had sex with all 16 girls present until reaching his physical and mental limits.

The next morning, Yuu woke around 9 AM. The nine girls with morning club activities had apparently showered early and left, so he awoke surrounded by the remaining seven, savoring the blissful feeling.

Though they were no longer naked, wearing pajamas instead.

He rested leisurely that day, but from the 29th to 31st, he cheered for clubs participating in inter-high school prefectural qualifiers.

Along with other boys, Yuu personally supported the basketball club, kendo club, and track and field club where he'd formed connections.

Perhaps because more boys came to cheer than usual, all teams performed beyond expectations.

The basketball club broke through the semifinal barrier they'd long struggled with, advancing to the finals for the first time in ten years. However, they were outmatched by their finals opponent Saitama Eiko High School and settled for runner-up.

Yuu was moved seeing Captain Shiina Chizuru tenderly encouraging the players who collapsed in tears at the final whistle.

In kendo team matches, they took revenge on Shutoku High School - one of the championship favorites who defeated them in spring - advancing to the top four. But they narrowly lost to the public school powerhouse Uraichi First High School after a close match.

In individual matches, seeded captain Hayase Mika reached the finals like in spring. She fought evenly against the Saitama Eiko player who'd previously defeated her easily, but lost by a point just before the end. Still, making the finals meant she secured the kendo club's first-ever ticket to nationals.

Yuu looked for Kuroda Noriko from Saitama Eiko whom he'd encountered in the restroom during spring tournaments, but was disappointed not to find her since she didn't participate in individual matches.

In track and field, second-year Hayakawa Ayumu set a new prefectural record in the 100m dash, taking first place impressively. She also placed second in 200m, qualifying for nationals in both events.

Yuu had certainly been curious about Hayakawa-senpai since deeply interacting during the quiz championship quarterfinals. Her running form was mesmerizingly beautiful, and her aloof attitude felt refreshing. Seeing her sprint from the front rows of spectator seats that day, he found himself captivated anew.

*(Her name's Ayumu... I really want to get closer to her.)*

If she were a third-year like basketball captain Shiina-senpai, he could've grown closer through student council activities and school events. But with second-years, aside from student council member Emi, he only knew them by sight at best, with no close relationships. With second-years, unless they approached first, he didn't even get chances to talk. Still, Yuu thought he wanted to become friends somehow.

---

August 1st.

Thanks to staying home all day, Yuu made significant progress on studying - review assignments given as summer homework - which he'd barely touched in July.

With his sister Elena away taking a prep school practice exam and only the housekeeper present besides him, he could concentrate alone in his room.

At night after dinner, Yuu gave a lap pillow to Elena who'd just finished her exam and was being affectionate, spending time cuddling. As he touched her modest breasts and whole body, Elena became aroused and begged for his cock, so he let her give him a blowjob as a reward for studying hard.

Simultaneously, Yuu pulled down her panties and directly fingered her wet pussy. Perhaps because they'd refrained from intimacy for several days before the exam, Elena's hunger had intensified. Moaning muffled gasps, she came multiple times while continuing to suck, swallowing every drop of semen received in her mouth without spilling.

---

Around 11 PM, perhaps from studying too hard, Yuu started feeling sleepy but was still watching TV news. Though its content hardly registered.

Because he'd been visually tracking his mother Martina heading to the kitchen wearing only a bath towel after her bath.

"Mom, over here."  
"U...un."

Martina came to the living room holding a glass of sparkling wine. Yuu beckoned her over. Martina sat beside Yuu with a slightly embarrassed smile.

Immediately, the wonderful post-bath scent tickled Yuu's nostrils. Her long wavy black hair still seemed damp, the ends moist and wetting the shoulder they touched. With just one towel, her voluptuous body couldn't be hidden, naturally revealing her deep cleavage to Yuu's view, with most of her plump, fleshy thighs exposed.

Martina didn't mind showing such an alluring figure before Yuu at all. Though during their trip about a month ago, they'd passionately coupled at night, making her conscious of Yuu as a man, back home they seemed to have returned to their former mother-son relationship.

There was a reason - since July began, both had been busy, returning to their previous routine of exchanging morning/evening greeting hugs and kisses. Seeing his mother return tired from work, Yuu couldn't bring himself to push aggressively.

If he were just a typical horny 16-year-old, he might not have been able to resist before a sensual woman like Martina. But at school, he'd been taking student council members, female students, and staff to the Special Male-Female Interaction Room after classes, satisfying them almost daily, so he didn't get frustrated.

Martina too had been specially conscious of Yuu that trip night, but after returning home treated him as her precious son as before, never making advances.

Though during relaxed Sunday afternoons with family, they hugged and kissed longer than during greetings, and when she let him squeeze her huge breasts, he got excited and she took out his erect cock. Sometimes Elena joined too, letting him enjoy double blowjobs from mother and sister. But they hadn't had actual intercourse for about a month.

Sitting hip-to-hip in that subtly close position, Yuu and Martina naturally made eye contact and smiled. Martina held a glass of clear golden liquid with characteristic carbonation bubbles floating, and took a big gulp.

Yuu watched the liquid go down as her throat moved up and down.

A beautiful woman tilting a glass to drink is quite a sight. As a high schooler, Yuu naturally had no chances to drink alcohol. Even before rebirth, his wife was very weak to alcohol, so home drinking was usually solo. Before marriage, they'd occasionally drunk alone outside, but she only sipped low-alcohol sours slowly.

Martina, perhaps due to her half-Latin blood, drinks normally. She sometimes comes home after work-related drinking, but since she can make it home properly, he doesn't worry much. Besides, in this world, even if women get drunk, there's no chastity crisis, and men apparently don't drink outside.

"Haahh, delicious. Hmm? What is it, Yuu-chan?"  
"Nothing, just thinking how wonderful you are, Mom."  
"Huh?"

Yuu reached out, embraced her shoulders, and brought his face closer. Though not drunk, Martina flushed as Yuu's face approached. But she didn't refuse, closing her eyes to accept him.

*Chu, chu* - they kissed repeatedly, changing face angles. Between kisses, Yuu's hands stroked Martina's damp hair, fingers gliding *tsutsuu* from her nape to shoulders. Martina also reached out, placing hands on Yuu's chest or gently stroking from his sides to back.

This much was barely everyday in the Hirose household. Yuu parted lips and voiced a thought that just occurred.

"Hey, I want a lap pillow from Mom."  
"Eh... why suddenly?"  
"Just felt like being pampered."

Without waiting for reply, Yuu *goron* laid his head on Martina's thighs. She couldn't not be happy being pampered by her beloved son. "Oh alright," she smiled wryly but her mouth relaxed. Though while kissing Yuu, her chest ached as reason and desire warred as usual, being pampered like this made her honestly happier. Her right hand naturally stroked Yuu's head.

Meanwhile, Yuu was overwhelmed by the giant breasts filling his vision. "Can't see Mom's face."  
"S-sorry, they're uselessly big." Martina leaned forward, finally showing her face. But in exchange, her breasts pressed against Yuu's face.

"No need to apologize at all. I love Mom's boobs." Almost without extending his hand, he scooped up the breast before him. Even spreading his palm wide, he couldn't fully grasp the melon-sized breast.

"Men love women's breasts no matter how old they get."  
"Yuu-chan!?"

Martina recalled her late husband saying exactly the same thing, making her heart waver.

"Hey, let me suck them."  
"Ah... w-wait."

Yuu didn't wait for reply. While squeezing, he pulled the bath towel, easily exposing her large areola and nipple. He gently took the right nipple near his mouth into his mouth.

"Ah...nnh!"  
"Huhu. So this is how I was raised on Mom's milk. *Amu...chuu*"  
"Geez, Yuu-cha...nnh! E-even grown up, like a baby... ah...nnnh!"

At first it was light caresses - rubbing in his mouth, licking *pero pero* - but hearing Martina's rough breathing above, Yuu got excited and gradually escalated. Nibbling sweetly, kneading with his whole tongue, stuffing his cheeks full to suck *chuu chuu*.

Naturally, his right hand didn't just squeeze but used fingers to play with her nipple.

"Nnaah! St-stah, ahhaahn! Yu...U...don't...ahnn! D-don't...oooh...nnh! St-stop...ahh!"  
"Fu... Mom's boobs are delicious. And... I'm getting excited. Hey, touch my cock? Please?"

Mothers are weak when their cute sons sweetly say "please." Shifting gaze downward, her eyes fixed on the obvious bulge in his half-pants despite the fabric.

"Hah, hah... Yuu's... peepee... already, so big...nnh, nfuu..."

Though in a breastfeeding position, Martina started feeling from Yuu's technique and couldn't stay calm. It wasn't lewd intent - telling herself it was her son's request, Martina timidly reached out and touched with her palm.

"Ahh, it got so hard..."  
Muttering "such a hopeless boy" inwardly but relaxing her cheeks, Martina began stroking the bulge.

"Ah... still so splendid... wonderful peepee..."

Memories of accepting this cock at the inn and coming repeatedly flashed through her mind, and having her breasts fondled by Yuu himself made her lower abdomen *kyun* throb. Martina writhing while reaching for his crotch made her breast weight press on his face, but to Yuu it was a happy weight. He redoubled efforts with fingers and mouth.

"Tah it off... touch directly."  
"Eeh?"  
Yuu's voice was muffled with his mouth occupied, but she seemed to understand. "Nnh, nnh... no...ooh... ah, ahnn!" Saying no, Martina's hand - which had been gripping his cock shape over the half-pants - lifted his T-shirt hem. *Sussu* - she slid fingers under the waistband from his stomach downward.

"Aah..."  
When the glans, constricted coronal ridge, and throbbing long shaft appeared, Martina let out a sexy sigh. Finally pulling down the half-pants along with underwear, exposing his ballsack.

Martina's lust-clouded eyes watched as her fingertip *tsutsu* traced his cock upward from below.

"Nfuu... more, please?"  
"Hyaann! Geez... Yuu... ah, ahi!"

Yuu had pinched her nipple with two fingers and pulled while strongly kneading the nipple in his mouth with his tongue. Martina's eyebrows formed a troubled 八-shape - looking like a mother exasperated by a child's selfishness yet also like a female overwhelmed by rising lust.

First she rubbed the entire glans *suri suri* with two fingers, moving as if checking the coronal ridge's step, then made a circle with four fingers and thumb to lightly grip the shaft. With practiced motions, she began stroking.

"Ah, ah, ah... Yuu, don't suck...haahn!"  
"Nnh, nmuu... feels good..."

Immediately pre-cum dripped from the tip, and with each movement of her wet hand, sticky *nucha nucha* sounds could be heard. Martina didn't just stroke simply - occasionally tracing the glans with fingers, changing grip positions to focus on the frenulum, varying techniques.

"Uhh, uhh, uaaah!"  
Seeing Yuu's hips *biku bikun* jump, Martina smiled and asked: "Wanna cum? Yuu?"  
"Nnh!"

Seeing Yuu's head move while *chupa chupa* licking her nipple, Martina sped up her stroking.

"Ah, ah, good... Yuu! Nnh!"

Writhing from the taboo act of jerking her son's cock while having her breasts squeezed and sucked, Martina rubbed her thighs together. Then suddenly her limit came.

"Uuu... I'm... cumming... ahh!"  
"Nnh..."

Feeling the throbbing of the cock she held, Martina shifted her palm to cup the glans and encourage ejaculation. The entire cock trembled *biku biku*, gushing out thick semen. Though she seemed to catch the thick white fluid well in her palm, there was so much it overflowed onto his stomach.

---

"Huhu. Feeling relieved? Yuu-chan?"  
"Fu. Felt amazing. Thanks, Mom."  
"You're welco...meeeeh!?"  
"Now I want to make Mom feel good."

Yuu removed the bath towel that had fallen to Martina's waist, revealing her lower abdomen's dark pubic hair glistening wet. While getting jerked off, Yuu had smelled Martina's wetness. They say as women age, their secretion smell strengthens. An inexperienced boy might find it strong, but Yuu didn't mind. Rather, he was happy she'd been so aroused. After briefly cleaning his cock, Yuu knelt on the floor and forcibly spread Martina's legs.

"W-wait... Yuu...ch... haaaaaaaahn!"

*Chupurero, reroo, juerero jurururururu!*

After licking her entire vaginal opening with broad tongue strokes, he sucked up the overflowing love juice.

"Hya... ah... ah, nnh, don't... ahh... hyaaauuun!"

Spreading her labia *kupaa* with fingers to thrust his tongue inside, focusing on her enlarged clit while roughly grabbing breasts and pinching nipples. Receiving serious cunnilingus from the start, Martina involuntarily threw her head back and moaned loudly. Her legs tried to close but were forcibly spread. Yuu busily moved tongue and fingers, uncaring his face got coated in love juice. Using elbows to pin her thighs while thrusting two fingers in-out, simultaneously clamping her clit with lips to suck.

"Ah... ah... I'm... ahh... nnh, nnh, Yuu... hya... cumming... hyaa... nooo, uhh, ahh, aah! I'm cummiiiiiiiiiiiiiiiiiiiiiiiiing!!!"

Though Martina had received blowjobs before, Yuu smiled at making her writhe and come like this at home, but had no intention to stop tonight. When Martina - leaning back on the sofa looking blankly upward - happened to look forward, she met eyes with Yuu who'd stood up. His crotch stood erect enough to pierce the sky.

"Yu...U...?"

Martina's heart held shyness and fear. But only a fraction. The female desire for Yuu as a man and expectation for further pleasure dominated her heart.

"I want to put it in. Inside Martina."

Martina stared at the cock still radiating male scent without drying, then looked up at Yuu and nodded *kokuri*.

---

### Author's Afterword

2020/2/8

Martina was drinking sparkling wine, initially described as "amber-colored" imagining white wine. Then came the comment "Amber color makes one think of whiskey, no?"

Indeed, "amber-colored" is a standard description for whiskey, which might cause confusion. So I changed the expression.

### Chapter Translation Notes
- Translated "グラスをぐいっと仰いだ" as "took a big gulp" to convey drinking motion
- Preserved "ユウちゃん" as "Yuu-chan" maintaining affectionate nickname
- Translated "ちゅぷれろ" as "*Chupurero*" transliterating wet licking sounds
- Rendered explicit anatomical terms directly ("clit", "semen", "labia")
- Maintained Japanese name order throughout ("Hirose Yuu", "Hayase Mika")
- Italicized internal monologues per style guide