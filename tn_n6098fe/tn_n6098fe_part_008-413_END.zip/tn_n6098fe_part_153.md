## 142. That Night ② ~Tomorrow never knows~

"Hya... gyaaah! Yuu, d-don't be so rough... aahn! Nooo... I-I'm... cumming agaaain... aahn! I'm... already!"

"But Martina's vagina is so hot inside... squeezing me... feels too good!"

Still embracing in the living room, Yuu and Martina moved to the bedroom while tangled together. Yuu kicked off his bothersome underwear and shorts during the move, while Martina swiftly pulled off his T-shirt the moment they entered the bedroom. Tumbling onto the king-sized bed, they alternated positions while kissing passionately until Yuu ended up on top and penetrated her.

At first, Yuu moved slowly as if confirming the feel of Martina's vagina after a month apart, but watching her writhe beneath him gradually increased his thrusting speed.

Yuu lifted his upper body that had been pressing against hers and spread Martina's thighs wide with both arms while pushing them forward - a variation of missionary position close to the legs-on-shoulders style. With Martina's hips lifted, Yuu began thrusting deep into her vagina.

He already knew from their night at the inn that stimulating the front wall of her vaginal depths made her weak. Given Yuu's erection angle and length, he easily reached that spot.

"A-ah... sho... n-no... I-I'm going... craaazy... aahn!"  
"Martina looks incredibly sexy when she's losing control like this. Don't hold back - show me more of your wild side!"

Martina shook her head as if refusing while Yuu looked down at her, but soon threw her head back with a moan. Both hands gripped the sheets tightly while her wavy black hair spread wildly across the pillow. Despite lying on her back, her ample breasts swayed heavily with Yuu's movements.

"Aaah! Martina! I-I can't stop... like this... ngh!"  
"Yuuuuu... ahn, ahn! Really, you're... too much... kihyaa! Cumming, cumming! Aaaaaaaaahhhhhhhh!"  
"I-I'm... too... c-cumming!"

Martina wrapped her long legs tightly around Yuu's waist while grabbing his upper arms. She kept calling his name while staring at his face, but the overwhelming pleasure made her throw her head back as she climaxed.

Yuu thrust wildly with wet slapping sounds until he ejaculated powerfully, pouring abundant semen into Martina's womb. After several spurts, he slowly collapsed onto her ample chest, where Martina gently held him while stroking his head.

"Ahh... that was... incredible, Yuu... aahn, still coming out"  
"When I'm with Martina, I lose myself completely"  
"Such a perverted boy... despite being male"  
"Can't help it when you're this amazing"  
"Oh you..."

After exchanging smiles, they shared light kisses. Though mother and son - or perhaps because they were blood-related mother and son - they desired each other so intensely. Despite having ejaculated copiously, Yuu's passion hadn't cooled, his still-hard penis remaining deep inside her.

Their pecking kisses gradually turned into deep, wet kisses with tangled tongues, and Yuu slowly began moving his hips again.

"Nn? Yuu... kyaa! W-wait... aahn! Why?"  
"Not enough yet. Want more"  
"E-eh? Lies... aahn! After all that... st-stop, moving like that now..."

Yuu's hip movements gradually intensified. With semen filling her vagina without leaking out, each thrust produced obscene squelching sounds.

Though Yuu was accustomed to multiple ejaculations per night, continuous intercourse without pulling out was rare. Tonight, Yuu burned with desire too intense to withdraw.

"Since we're at it... want to try a different position?"  
"Th-then I'll be on top this time"  
"Okay. You're tired from work, let me handle it"  
"Yuu!?"

Martina seemed willing to continue despite her protests, making Yuu happy. Sitting up, Yuu turned Martina sideways and lifted one leg into a spread-eagle position that allowed deep penetration.

Having only done missionary during his marriage, Yuu had experimented with various positions since his rebirth. This world's basics included cowgirl (female on top), missionary (male on top), face-to-face sitting, and doggy style (including standing).

While erotic books for males were scarce at bookstores, female-oriented sections had abundant materials mentioning positions - though male-led variations were only briefly referenced.

"How's... this?"  
Yuu thrust slowly in the unfamiliar position.  
"A...nn, different from... before... hitting... there! Aahn! Deep... that feels... so good!"  
"Good. Feel it more"

Yuu slid his left hand from Martina's damp lower abdomen to her clitoris and pinched it.

"Hyuu! Yuu, n-no! Both at... haaaaaaaahn!"

Martina moaned wildly with disheveled hair. Her sideways-positioned breasts bounced vigorously. Yuu admired her smooth leg cradled in his right arm while maintaining a steady rhythm. Each thrust produced sharp slapping sounds where their thighs met.

Finding climax difficult due to erection angle and unfamiliar position, Yuu turned Martina prone and switched to doggy style.

He started with slow, deep thrusts. Below Yuu's gaze were her slim waist and full buttocks. When slowly pulling out, milky fluid oozed from their joining point. Each hip impact visibly jiggled her buttocks flesh.

Since his rebirth, Yuu noticed that normal and cowgirl positions felt different with larger women, but doggy style always gave him a violating thrill regardless of height.

"Ah, ah, aahn! In this position... aun! D-deep inside... haan! Good, so good... feels amazing!"  
"Ahh, Martina! Me too... feels incredible! Ngh!"  
"Haa, haa... d-don't hold back... Yuu? Cum... ahhhhhhhhhh!"

Yuu suddenly embraced Martina from behind, grabbing her melon-sized breasts with both hands. Now thrusting deep while grinding his hips. Martina panted like a dog with tongue out until the deep vaginal stimulation made her climax first.

"Yuu, Yuuuuu... I already... came... ahin! Came... o... oheeeeh! Hahii... no moooreee"

Martina collapsed face-first onto the pillow while babbling incoherently. Sensing his own climax approaching, Yuu thrust rapidly with short strokes.

Opting for full commitment, Yuu extended his knees into prone position and pressed down on her back. Sharp slapping sounds echoed pleasantly as Yuu finally ejaculated.

"C-cumming... Martina! Take it! Gah! Guh!"  
"Gah! Oh! Yuuuuuuuu... ah... ahh... co... coming... uun..."

After a prolonged ejaculation, Yuu collapsed exhausted onto Martina's back. Both were drenched in sweat where they touched. Yet Yuu found her mingled scent from disheveled hair and damp skin endearing.

***

After cleanup, Yuu and Martina remained in bed. Having used no cover, they disguised the messy sheets with fresh bath towels.

"Don't you need to return to your room?"  
"Nah. Want to stay like this sometimes. Sis seems fast asleep"  
"O-oh..."

Martina snuggled against Yuu's right side as he lay supine, smiling happily while kissing his neck. Though covered by a thin summer blanket, both were naked. Martina's ample breasts pressed against him felt wonderful. Between pillow talk, they exchanged light kisses repeatedly. Martina's hand caressed Yuu's chest while he poked her breasts playfully; she entangled her legs and brushed against his crotch - intimate but not quite arousing contact. Any observer would mistake them for passionate lovers rather than mother and son.

Martina buried her face in Yuu's neck, sniffing his scent and kissing. Yuu gently stroked her completely dried long hair. After silent moments, Martina suddenly sat up.

"Just remembered"  
"Eh? What?"  
"Yuu-chan? I mentioned it before"  
Her changed address signaled she'd shifted from lover back to mother.

"About meeting the girls you're dating once summer break started"  
"Ah!"  
"July was busy, so understandable. But it's August now. Mid-month has Obon festivities. Better before then. Shouldn't postpone this"

Resigned, Yuu gazed upward before answering.  
"Need to check their schedules... Actually meeting them for student council business day after tomorrow, so I'll ask"  
"Sunday the 5th... too soon. How about the 12th?"  
"Ah... yeah, okay"

Yuu accepted defeat. Introducing lovers to his mother was the last thing he wanted, but Martina seemed unexpectedly determined.

Martina continued seriously. "You're dating those three student council members... and sexually involved, right?"  
"Ah, yeah, definitely"  
Since she knew about Sayaka's birthday sleepover on June 30th, he had to admit it.

"Assuming it's not just one-time but proper dating... usually the girl's parents visit the boy's parents"  
"R-really?"  
"At least that's how it was for me. Ah, Sakuya-san had no parents, but Papa and Mama went with me to greet him"  
"Huh, I see"  
"Have they told their parents?"  
"Um... not sure?"

The topic never came up, but Riko and Emi probably had. What about Sayaka? She likely had an arranged fiancée. They'd agreed to continue until the student council term ended in September, with elections in late September. New officers would handle second-term events.

"Anyway, adjust schedules soon. Because..."  
"Hmm?"

Martina paused to stroke Yuu's face.

"You might have gotten them pregnant"  
"Ah!"  
"Legally, marriage is allowed at 16. Though parental consent is needed until 18"  
"M-marriage... marriage..."  
"Getting pregnant doesn't obligate the man to marry. Especially since you're still in high school. But we should discuss it properly"

Having had unprotected sex with Sayaka's trio multiple times, pregnancy was possible. Though previously married, Yuu had overlooked this. That men bore no responsibility even with children surprised him, but he wouldn't disrespect Sayaka, Riko and Emi. Time for proper decisions.

Meeting Martina's gaze, Yuu nodded. "Understood, Mom. Thanks for caring. I'll introduce my beloved girlfriends soon"  
"Fufu. For your sake. Looking forward to it" Martina smiled and hugged him.

Though nakedly embracing his biological mother remained bizarre, her warmth felt comforting now. As sleepiness approached, a thought struck Yuu: Martina could also get pregnant from their unprotected sex. What status would their child have? Officially a sibling?

***

Next morning, Elena woke them still nakedly entwined. Last night's events were obvious. Furious at being excluded, Elena sulked in her room after Martina rushed off to work. Though tempted to leave her, Yuu had evening plans. He couldn't bear them having an awkward night because of him.

After dismissing the housekeeper early, Yuu invaded Elena's room and pounced on her sulking form.

Two hours later, Elena emerged for her shower in the best possible mood.

---

### Author's Afterword

This time Martina got the spotlight, making Elena's treatment rather rough. Martina's meeting with Sayaka's group will come later. Will it be:

"Mother-in-law, please give me your son!"  
"Don't you dare call me mother-in-law!"

...or not?

2019/11/25  
Revised and added to the post-coital conversation between Martina and Yuu which felt slightly lacking.

### Chapter Translation Notes
- Translated explicit anatomical terms directly: "膣内" → "vagina", "チンポ" → "penis", "クリトリス" → "clitoris"
- Rendered sexual positions descriptively: "両脚肩掛け正常位" → "legs-on-shoulders style", "松葉崩し" → "spread-eagle position"
- Preserved Japanese honorific "ちゃん" in "ユウちゃん" as "-chan" per translation rules
- Transliterated sound effects: "ばちゅん" → "wet slapping", "ぐちゃぐちゃ" → "squelching"
- Translated culturally specific term "お盆" as "Obon festivities" without explanation (real-world reference)
- Kept song reference "Tomorrow never knows" untranslated as per author's intent
- Maintained original name order "Hirose Yuu" and "Hirose Martina" throughout
- Used explicit terminology for sexual acts: "ejaculation", "intercourse", "cunnilingus" etc.