## 143. Winner's Privilege ① ~Riverside Hotel~

Approximately 40 minutes by car southeast from Yuu's home.  
Arriving about 5 minutes early for the 6 PM meeting time at the entrance of Kawagoe Princess Hotel in Kawagoe City.  

The hotel built along the riverside flowing through the city had a modern exterior appearance, but when Yuu stepped into the lobby accompanied by protection officers Kanako and Touko, he was overwhelmed by the glittering luxurious interior.  

Decorated mainly in white with red and gold accents as if imagining a royal palace hall. The ceiling featured a dazzling chandelier. The marble floor shone brilliantly.  

While the sofas and tables were comparatively subdued in color, they incorporated rococo-style furniture with white bases, gold filigree patterns, and elegant curved lines.  

Truly a hotel embodying the image of a princess.  

Last month on the 27th, Hanmura Riko and Iida's team from Sairei Academy tied for first place with Saiei Academy's Li and Shirojima team in the individual division of the first Ayakuni Cup Quiz Championship.  
Among the prizes were dining vouchers for Princess Hotel Group restaurants.  

Note: The vouchers were for four people.  
Though not publicly stated, they included the right to invite males.  
Depending on negotiation with the individual, since male contact information couldn't be shared privately, Sairei Academy's administrative office served as the point of contact.  
Promptly exercising this privilege, Riko invited Yuu on August 2nd (Thursday).  
The closest available location to use the voucher was Princess Hotel in Kawagoe City.  

"Yuu-kun!"  
"Ah, Riko...?"  

After entering the lobby, Yuu turned toward the familiar voice calling his name as he was restlessly looking around.  
They seemed to have been sitting on chairs nearby.  

Yuu stared blankly without saying anything at Riko approaching him from the sofa.  
At first glance, her simple navy blue dress featured bold off-shoulder styling.  
The knee-length hem was gathered, accentuating her leg length.  
Though Riko was originally 2-3cm taller than Yuu, tonight her high-heeled shoes raised her eye level further.  
Upon closer inspection, the dress had elegant loose pleats. Unbeknownst to Yuu, this was a drape dress emphasizing glamorous maturity.  
While she usually tied her hair in a single bundle hanging forward over her shoulder, tonight it cascaded down her back with soft curls.  
Furthermore, a gold necklace glittered at her chest, and subtle makeup enhanced her mature aura.  

"Riko... You're incredibly beautiful and mature tonight, even more wonderful than usual."  
"Ah... r-really? I'm glad. My efforts dressing up paid off."  

Riko smiled bashfully at Yuu's frank praise.  
For tonight's restaurant dinner, Yuu had debated his outfit.  
Thinking student formalwear meant uniforms, he chose a black suit and tie over his barely worn gakuran jacket - a decision he now felt was correct.  

Yuu's gaze shifted to the woman hiding behind Riko in the shadows.  
He'd heard Riko's partner was her classmate Iida-senpai, the literature club president, but her appearance was utterly transformed from what he saw at the quiz championship.  

"Come on, don't hide. Greet Yuu-kun."  
"Eh... wait"  

Not just similar but slightly shorter than Riko's usual companion Emi, her height was likely under 160cm.  
Top: Sleeveless blouse with ruffled sleeves. Bottom: Long flare skirt with floral pattern on white background.  
Compared to Riko, she gave the impression of a typically quiet high school girl trying hard to dress up. That was fine.  
Her hair color was what might be called muted brown - perhaps dark blond or ash gray.  
The short bob-style cut with slight fluffiness was adorable.  
Though she'd been looking down, her eyebrows were thicker than average Japanese, eyes somewhat sharp, and with her high nose bridge, her features overall had deep contours.  

"Um, well... Sorry, have we met somewhere?"  
"Ah, well, I-I'm Iida..."  
"Iida... meaning Iida-senpai!?"  

When their eyes briefly met as she glanced up, Yuu noticed her eye color was lighter brown than typical Japanese.  
Though not distinctly, it gave a vaguely non-Japanese impression.  
He recalled briefly conversing with her before the quiz championship's third round and seeing her during finals.  
Back then, she wore large-lens black-framed glasses and had a bulky black bob cut.  

"Ufufu. I knew you wouldn't recognize her. Not only did she switch to contact lenses, but we went to the beauty salon together for a haircut too."  
"So you dyed it?"  
"No. This is actually my natural color."  

According to her, her father was a scholar who fled persecution in a Central Asian country where men were oppressed.  
He married a female Japanese linguistics graduate student who served as his interpreter and caretaker when he began living in Japan.  
However, despite progress in international marriages, during elementary school her lighter hair color and sharp-looking eyes subjected her to bullying.  
Since then, she deliberately wore unfashionable glasses and dyed her hair black to avoid standing out.  

"So that's why I didn't recognize you... But current Iida-senpai is extremely beautiful. I think your natural look is far better."  
"See? I told you nobody at our school would say anything weird."  
"Y-yes... If Riko and Hirose-kun say so..."  

Having deliberately kept a plain appearance, being called "beautiful" by Yuu seemed significant.  
Though her cheeks flushed slightly pink, she nodded firmly.  

For now, Kanako and Touko who escorted him would part ways here.  
At establishments like this hotel that accommodate male guests, security was thorough with no assault concerns.  

"Well then. I'll contact you later."  
"Understood."  

Though they'd become physically intimate in July, Kanako and Touko never acted familiarly, maintaining their professional guard duties unchanged.  
At most, Yuu's physical contact increased during car rides.  
After brief conversation, Yuu subtly touched and lightly squeezed their hands without drawing attention.  
Though merely that, Kanako and Touko smiled happily before bowing and heading toward the exit.  

"Shall we head to the restaurant...?"  
Before he finished speaking, Riko smoothly linked arms with Yuu on his right side.  
"E-excuse me!"  
Prompted by Riko's look, Aiko took his left arm, sandwiching Yuu between them - a "flower in each hand" situation.  

"Now, let's take the elevator."  
"O-okay."  

Though Yuu hardly noticed, he'd attracted many female gazes since entering the lobby, including groups with males.  
His normally loose hair was styled with grooming product (since men's wax wasn't sold, he used mousse) to sweep his bangs up and reveal his forehead.  
Consequently, appearing more mature than usual, he received heated stares.  
Riko and Aiko paraded him sandwiched between them as if declaring "our precious man."  

Arm-in-arm, they boarded the elevator where Riko pressed the button for the top floor (12th) restaurant.  

"Um, French right? I'm nervous since I'm not used to it."  
"Me too."  
"I-I'm also a first-timer..."  
"Then since we're all together, let's not worry about mistakes."  

Truthfully, in his previous life, Yuu had experienced such dining a handful of times.  
Special occasion meals with his wife or colleagues' wedding banquets.  
He remembered minimal table manners but still felt nervous.  
However, the two girls accompanying Yuu clearly showed more tension.  
Thus Yuu smiled at them to ease their nerves.  

"Hearing that helps."  
"Yeah..."  

The French restaurant named "Au bord de la rivière" (By the Riverside) contrasted sharply with the lobby, featuring subdued lighting and chic black/brown decor.  
Being a weekday, it was about one-third full.  
Though mostly female groups, several tables had one male surrounded by multiple females like Yuu.  

They were seated at a window table.  
Yuu sat on the window side of the four-seater, facing the two.  

In today's society, 18-year-olds are treated as adults, allowing drinking/smoking during high school, though most schools prohibit it until graduation.  
Still, some minors indulge, but the two serious students before him ordered soft drinks like Yuu.  

When the first glasses of orange juice arrived, Yuu suddenly realized:  
"Come to think of it, I never asked Iida-senpai's given name. Could you tell me?"  
"Ah, well... 'Ai' as in love, so Aiko."  
"Aiko... Lovely name. May I call you Aiko-san?"  
"Yes... But Hirose-kun calls Riko without honorifics..."  
"「Ah」"  

Yuu and Riko exchanged looks.  
With the student council trio, they'd developed the habit of using names without honorifics when together.  
Unconsciously, this extended to other students, becoming why rumors spread they were dating.  

"I-I'd also like... you to call me Aiko?"  
While comparing Yuu and Riko's expressions, she spoke shyly.  
"Of course. Since we're dining together like this. Please call me by name too."  
"Yu... Yuu-kun"  
"Yes, Aiko-sa-"  
"Just Aiko!"  
"Ah, Aiko...?"  
"And please drop the honorifics!"  
"Eh... okay"  

Her words and tone seemed contradictory, but Aiko's sharp look and strong delivery compelled agreement.  
Likely unconscious, but her impression differed greatly from their first meeting.  

"Le-let's toast first"  
"R-right.  
Then to celebrate Riko and Aiko's quiz championship victory"  
"And to celebrating dining with Yuu-kun like this"  
"「「「Cheers!」」」"  

"Fuu, the night view is beautiful."  
"I never dreamed I could dine with Yuu-kun while seeing such a view."  
"Fufu. Truly."  

After sipping orange juice, Aiko rested her cheek on her hand, speaking dreamily as Riko nodded.  
Yuu himself savored the happiness of dining with two beauties.  
Directly below the window, the river flowed into darkness, but beyond it a large street bustled with car lights amid the city's glitter.  
From the 12th-floor height, the location was perfect.  
Looking ahead, Riko radiated unusual maturity while Aiko exuded exotic charm, both smiling.  

First came the hors d'oeuvres.  
Shrimp, scallops and asparagus clustered at the plate's center, accented by white sauce and herbs.  

*(Now, I remember... Knives and forks are used from the outside in, right?)*  

As Yuu recalled and picked up the outermost knife and fork, the two followed suit to begin eating.  

"Come to think of it, I heard the prize dining vouchers were for four people."  
"Yes, that's right."  
"Meaning it was meant for two males and two females?"  

Yuu suddenly wondered if Masaya, who should know Aiko, could have been invited.  
But only Yuu had been asked.  
After finishing the hors d'oeuvres, soup arrived.  
At Yuu's words, Riko and Aiko exchanged glances, but Riko spoke instead of the silent Aiko.  

"Ah... well, Yuu-kun. Actually, we booked a room.  
Ah! N-not that we're staying overnight! We have tomorrow too...  
We reserved it for about two hours."  

Since they were intimate, spending an adult evening after dinner wasn't strange.  
Tonight, Aiko would apparently join too.  
Aiko jumped when Riko nudged her elbow. Likely signaling her to speak.  
Yuu had finished his soup, but Aiko stopped moving her spoon.  

"U-um, you see... Yu-Yuu-kun, I have a request."  
"Is it... perhaps something between a man and woman?"  
"Yes"  
"Would a hotel room be more suitable to avoid attention?"  
"That's... right. A quiet place is desirable."  
"Should Riko be present?"  
"I'd be troubled if she weren't."  
"Understood. I'll accept your request, Aiko."  
"Eh? You don't need to hear specifics?"  

Riko and Aiko looked astonished.  

"Though I've had no contact with Aiko until now, meeting and talking like this... I've become interested too."  
"I-I'm happy! No other boy would accept such a request... Since Riko, who showed no interest in boys until third year, fell for you, I thought Yuu-kun was perfect."  
"St-stop it..."  

Hearing it stated plainly, even Riko seemed embarrassed.  
Yuu found her adorable, covering her flushed cheeks.  

"Then let's save that for later enjoyment and focus on the meal now."  
"Yes!"  
"Fufu"  

Exchanging smiles, Yuu, Riko and Aiko relaxed completely, savoring the course dishes and enjoying conversation.  

---

### Author's Afterword

Among the three student council members, I wanted to create a scene for Riko who lacked an intimate scene in Chapter Four. Combined with my personal favorite scenario where removing glasses reveals a beauty (Aiko's case being a complete transformation), I intended this as a bridge chapter.  

Despite that intention, it ended up slightly longer.  

As for the full course meal being abbreviated midway... that was purely because writing it all felt tedious.

### Chapter Translation Notes
- Translated "きょろきょろ" as "restlessly looking around" (transliteration: kyoro kyoro)
- Preserved Japanese honorifics (-kun, -san) and transition to first-name basis as per original dialogue
- Translated restaurant name "Au bord de la rivière" with original French and Japanese reading
- Maintained explicit terminology for intimate scenes ("physically intimate," "adult evening")
- Italicized internal monologue per style guidelines
- Used original name order (Hanmura Riko, Iida Aiko) consistently