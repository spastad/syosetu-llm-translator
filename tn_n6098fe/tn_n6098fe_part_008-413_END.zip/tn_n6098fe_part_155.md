## 144. Winner's Privilege ② ~Touch Me Tonight~

"Respect the position of men, care for them, show compassion, and strive not to burden them. It is absolutely unacceptable to impose selfish lust upon men or fight over them. As women, we should love them by taking a step back and embracing them. Like the lady's education at our Sairei Academy High School, this may be the ideal in reality. But at least in stories, isn't it acceptable to kick aside annoying rivals and selfishly bare female instincts to monopolize a man? Three women with completely different personalities and statuses fighting over one man to make him theirs. That's the story I want to write. Now, what kind of man would be at the center of this vortex? A seemingly fragile boy whom women would want to protect might be popular. But! The key is to deliberately portray him as a bewitching man who toys with women!"

After entering the reserved hotel room—a double room—Yuu and Riko sat side by side on the bed while Aiko, seated on a wooden chair, passionately expounded her ideas.

Yuu felt slightly let down, having thought Aiko wanted a threesome to lose her virginity. Aiko, the literature club president, would publish her final high school novel at the autumn cultural festival. Though not top-ranked like Riko, Aiko was academically excellent enough to make the top ten. One might expect her to focus on university entrance exams, but she had already secured a recommendation to a prestigious local university.

Aiko wanted to write a melodramatic love-hate story about three women fighting over one man. The key was portraying the man not as being manipulated by women, but as a "bewitching man" who uses his words and body to toy with them instead.

The setting was a co-ed high school modeled after Sairei Academy, featuring a handsome second-year transfer student—actually a cougar hunter with over ten conquests—caught between the beautiful, talented student council president (daughter of a company CEO), the academically top-ranked genius who previously had no interest in men, and a seemingly innocent but secretly scheming first-year girl. The twist: the three were sisters and cousins, embroiling families in a blood feud. The first two characters made Yuu suspect they were modeled after him and the student council, but Aiko insisted it was coincidence.

"So, I want to understand men better. To depict vivid sex scenes, may I watch you have sex with Riko here?"

Yuu pulled Riko closer by her shoulder. He had already removed his suit and was wearing a T-shirt and pants. Riko wore a strapless black bra and satin panties.

"Se... yes... I suppose..."

Only now noticing Yuu's state of undress, Aiko's voice trailed off.

"Here we go..."  
"Hya!? Wh-what are you—"

Right before Aiko's eyes, Yuu removed his white T-shirt. Though Aiko covered her eyes with her hands, it was obvious she was peeking through her fingers. She might be more repressed than expected.

"'What'? I thought I'd let you see a man's body directly."  
"Fuaaaaah... I-it's true that seeing is believing, isn't it?"

Having come this far, Aiko leaned forward involuntarily, staring intently at Yuu's body. Riko wrapped her arms around Yuu from behind.

"Afu"  
"Ufufu. How is it? Yuu-kun's body looks slim but has firm muscles. Wonderful, right?"  
"Yes... Yuu-kun's body is sexier than I imagined..."  
"You can look closer."  
"Eh... b-but..."  
"It's fine."

Aiko moved her chair closer to the bed, notebook and pen in hand, fully entering observation mode. Normally this would feel awkward, but for Yuu, multiple-partner play had become routine. The same went for Riko.

"Ufu. Today I can have Yuu-kun all to myself for the first time in ages. Let's enjoy ourselves thoroughly. Chuu."  
"Mmm..."

Riko, still wearing her glasses, maintained her usual intellectual aura while flashing a lustful glint in her almond-shaped eyes as she clung to Yuu and claimed his lips. As if cherishing him, she stroked his head, neck, and shoulders while repeatedly pressing and releasing her lips. As they kissed repeatedly, their passions ignited. Yuu turned his body toward Riko and embraced her slender frame.

"Amu... chuu, chu... Riko, you smell nicer than usual today."  
"Haa... mm... today... I'm wearing... perfume..."  
"No wonder... I want to lick you all over. Chupa, leroleroo"  
"Ah... nn... I want to... lick Yuu-kun too..."  
"Haa, haa, Riko!"  
"Yuu-kun!"

They greedily opened their mouths, tongues thickly sliding against each other, then competitively brought their mouths to each other's necks and shoulders for mutual caresses. The male protagonist in Aiko's story was unusually fond of women in this world—meaning Yuu could just act naturally, as Riko suggested. And the genius girl modeled after Riko had become infatuated after knowing a man for the first time. So they didn't need to act unnaturally.

Aiko watched their intimate exchange with wide eyes.

*Picha picha*—their tongues tangled wetly as Yuu stroked Riko's lightly permed hair and smooth back, then paused briefly.

"I'll remove your bra."  
"Hauun..."

A string of drool stretched from the tip of Riko's protruding tongue. Her cheeks flushed pink as she gave Yuu a sidelong glance. Her expression melting behind glasses was strangely erotic. Deeply aroused, Yuu licked the drool from the corner of her mouth, and Riko's tongue chased after his, their red tongues writhing like separate creatures seeking each other.

Meanwhile, Yuu's hands unhooked the three clasps on her back. Without shoulder straps, the bra that clung tightly to her chest fluttered down. The exposed swell of her breasts was modest. Yuu's right hand touched and gently cupped them.

"Nn... ann!"  
"Fufufu. As always, your breasts are sensitive, Riko."  
"I... didn't know... fuu... nn... why... when Yuu-kun touches me... ah, ah... why do I feel... so much..."

Yuu's hand softly kneaded the humble swell. Each time his fingertips toyed with her plump, large nipples, Riko reacted sensitively with little twitches—adorable. While caressing her breasts, Yuu lowered his chin to kiss her prominent collarbone, licking *lero lero* and giving gentle nips.

"Yu, Yu-kun... yan! A, a, there too... I'm sensitive there!"  
"Fumu fumu. 'A woman-loving man excels at pleasuring techniques.' This is very informative."

Holding Riko's seemingly breakably slender waist with his left arm, Yuu continued downward with his mouth. While kneading one breast with his right hand, he slid his tongue toward the opposite side and gently took the other breast into his mouth.

"Hyauun! N-no... ah... ah, ann! Th-that much... sucking... haun!"  
"Ooh... Under Yuu-kun's touch, Riko—always so serious at school—makes such an expression..."

Aiko murmured while watching Riko throw her head back in ecstasy, scribbling fervently in her notebook. During their foursomes in the student council room, Riko was always the aggressor against Sayaka, but when Yuu took charge, she became extremely vulnerable. Her character was like maxed-out attack stats with paper-thin defense.

Yuu kneaded and pulled her nipples more forcefully than before, rolling the one in his mouth. Among the three (including Sayaka), Riko had the smallest breasts but was the most sensitive. Yuu found this delightful, and since they were alone for the first time in a while, he persistently continued breast stimulation until...

"Yaa... a, ahi... not like that... s-stop sucking... nn, nn, nnnnnn! Yu, Yuu-kun! Ann! St... op... already... ah, ah, ah, ah, a... haaaaaaaaaaaaaannn!"

Still clutching Yuu's head, Riko seemed to orgasm from breast stimulation alone. When Yuu reached for her panties next, Riko—her face crimson—stopped him. Though used to it, she seemed embarrassed to climax so easily before a third party.

"N-now it's... my turn!"  
"Mm, got it. I'm in your care."

Since having Yuu pleasure her while she climaxed wouldn't show Aiko what she needed, Riko moved behind the seated Yuu.

"Haa... Yuu-kun... I love you."  
Riko hugged him tightly with both arms, rubbed her cheek against his nape, then whispered too softly for Aiko to hear. Yuu responded instantly.  
"Me too, Riko."  
"My, my, how passionate."  
"Uunnnn—!"

Realizing she'd been heard, Riko flushed again, cleared her throat, and began stroking Yuu's chest while planting repeated *chuu, chuu* kisses on his neck. Her fingertips touched Yuu's nipples and, as if returning the favor, began kneading and pinching them.

"Nn... ah... kuh..."  
"Y-yes! A man's face when aroused is amazing! It's making me excited!"  
"Ufufu. And Yuu-kun's skin smells wonderful too. Aiko, why not come closer?"  
"Hye!? N-no, th-that would be so rude! I'd be punished! Just being allowed to watch is already more than I deserve..."

Aiko waved her hands frantically in deference. Since Yuu had welcomed a threesome from the start, this was the perfect opportunity to invite her.

"For your novel research, touching would be better than just looking."  
"Exactly. Earlier you said 'seeing is believing,' but touching and smelling once is more informative than seeing a hundred times. Besides, isn't your story impossible to write without truly understanding men?"  
"Mu!"

Aiko seemed provoked by Riko's challenging words while stroking Yuu's chest. Resolved, she nodded and stood up, approaching Yuu head-on.

"Y-yes... Not just visually, but understanding men with all f-five senses... uguh..."

Seeing Yuu half-naked up close was too stimulating—Aiko covered her face as if about to get a nosebleed. But determined not to waste this chance, she steeled herself and sat to Yuu's right. Riko continued caressing him, licking *tsuu—* up his neck, making Yuu shiver. Her fingertips traced not just his nipples but also his collarbone and bony armpits, drawing involuntary sounds from him.

"E-excuse me..."  
"Mm... please do."

Tremulously, Aiko brought her face close to Yuu's bicep and touched it.

"Ahh... I can touch Yuu-kun's body... I'm... grateful."  
"See? You can touch more freely."  
"Hau!"

Riko took Aiko's right hand and guided it to his chest. Yuu raised his right arm to embrace Aiko. Naturally, Aiko ended up pressed against him. Something soft and plump made contact. Though detectable through her blouse, she seemed busty. Having showered beforehand? The pleasant shampoo scent from her hair tickled his nose. Stroking her hair, Yuu spoke hoarsely.

"Aiko... look at me."  
"Hyai!"

Unable to hide her agitation at her first contact with a male torso, Aiko answered in a shrill voice and lifted her face. Her eyes were moist. Though her gaze was intense, she indeed had large double-lidded eyes. With her striking features, Aiko was undeniably beautiful. Her pink-glossed lips looked plump and tempting. Without a word, Yuu pressed his lips to hers.

"Nnn!?"  
Startled by the sudden kiss, Aiko tried to pull back, but Yuu's arm around her shoulder held firm. As their lips remained joined, Aiko gradually relaxed into him.

"Sorry for the sudden kiss. I couldn't help it."  
"H-hye..."

Too embarrassed to speak, Aiko looked down. Her innocent reaction felt fresh, making Yuu smile. Now Riko leaned in from the left for a kiss, stroking Yuu's head as her tongue invaded his mouth. Yuu welcomed it, tangling his tongue with hers. After thoroughly intertwining, Riko pulled away with an impassioned expression.

"Afuu... Kissing Yuu-kun... feels better each time."  
"I-is that how it is!?"  
"Yes. A kiss is just a kiss, yet through kissing alone, a woman gets wet."  
"Th-then..."

With Yuu in the middle, the trio continued exchanging kisses. Yuu stroked their hair and backs with his encircling arms. Especially with petite Aiko, his hand easily reached her buttocks. Kneading the soft flesh resting on the bed drew an erotic sigh from her. With Riko, he kept kneading her breast through her armpit, making her moan while kissing.

"Um... I've been wondering about something..."  
"Uun?"

While clinging to Yuu and showering not just his lips but his entire face with kisses, Riko looked down at what Aiko pointed to and nodded cheerfully. His tented crotch was unmistakable. Blocked by their bodies, Yuu couldn't see it himself but knew he was fully erect.

"Ufufu. Yuu-kun's cock is fully grown."  
"Co... cock?"  
"It looks tight. Shall we take it off?"  
"Ah, please."

Yuu lifted his hips as Riko skillfully pulled down his trunks, avoiding snagging the tip. His fully erect, skyward-pointing manhood was exposed.

"Whoa! Th-this... isn't it huge!?"  
"Is it? I don't know other men's sizes."  
"It's absolutely huge! Twice the average in length and thickness? And yet... so fierce, so ominous, and yet... ugh, somehow my lower belly feels painfully tight... ahh!"

Aiko had acquired adult novels, comics, photo books, and even uncensored AVs under the pretext of research, thinking she understood men. But today shattered her assumptions in many ways. Her accumulated sexual knowledge proved useless. The culmination was Yuu's massive member before her.

"This is the cock that drives women mad..."  
Riko reached out dreamily, stroking it lightly with her fingertips.  
"Here, touch it. Smell it too."  
"Eh... auuu..."

The more theoretically experienced type often crumbles when faced with reality. But Yuu stroked Aiko's head encouragingly.

"I really want Aiko to know my cock well too."  
"Yuu-kun..."

In Yuu's mind, it was decided: Aiko wouldn't remain an observer but become a participant.

---

### Author's Afterword

The flow of using novel research to lead to multiple partners... we've had that before, right? I brace for criticism...

Originally, Iida Aiko was only conceived as Riko's quiz championship partner. When deciding to use the winner's privilege for a meeting with Riko leading to a threesome, this resulted from the literature club president setting I came up with on the spot. Since I plan to vary the characters and developments from the Komatsu sisters' arc, I hope you enjoy that aspect.

### Chapter Translation Notes
- Translated "魔性の男" as "bewitching man" to convey supernatural allure while maintaining seductive connotations
- Translated "おチンポ" as "cock" per explicit terminology requirement
- Preserved sound effects: "ぴちゃずちゃ" → "picha picha", "ちゅぱ" → "chupa"
- Rendered internal monologues in italics: "*(thought)*" format
- Maintained Japanese name order: "Hirose Yuu" not "Yuu Hirose"
- Translated explicit anatomical/sexual terms directly: "精液" → "semen", "乳房" → "breasts"