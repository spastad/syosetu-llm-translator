## 145. Winner's Privilege ③ ~Because I'm Weak~

"Th-this is the scrotum where semen is produced... Oh, Yuu-kun's feels quite weighty. H-how much semen do you produce when you ejaculate, Yuu-kun?"

"Nn... ah... Y-Yuu-kun produces... a lot... ahfuh"

"I've heard men can't get erect for several hours after ejaculating once..."

"Yuu-kun always... ejaculates multiple times in a row... yah... haun..."

"What did you say?!"

Aiko crouched on all fours between Yuu's legs as he lay on his back, gazing intently at his entire genitalia. Being so close to his penis seemed to make her unable to contain her excitement, her words coming faster. Though her fingertips trembled when first touching him, she gradually grew accustomed, tracing the shaft from the base while bringing her nose closer.

*Sniff sniff*. "Muhah... th-this is the scent of a boy... hafuh. Why is this? My lower abdomen feels all tight inside. I want to smell more... touch more."

"It's fine, Aiko. Don't hold back."

"Th-that's right. Like this... hyauun! Y-Yuu-kun! Teasing me like this just makes me more sensitive!"

"Fufu. Riko's pussy is absolutely drenched. Want me to touch more sensitive spots? Like this?"

"Ah! Ahn! I-I told you... not to!"

Though having them both give handjobs would've been good, Yuu had Riko remove her panties and ride him reverse-cowgirl style - putting them in a sixty-nine position. 

Though somewhat shadowed, Yuu could see Riko was thoroughly soaked from the moment she straddled him. Beyond her dark pubic hair, transparent fluid dripped down to her thighs. Last time they did sixty-nine, Riko came easily from Yuu's caresses. She'd tried to refrain this time to focus on fellatio, but couldn't refuse when Yuu persistently asked.

Yuu considerately avoided intense stimulation at first, massaging her small but well-shaped buttocks and tracing fingers along her inner thighs. Currently stroking the outer labia with his palm, this teasing only made Riko writhe more intensely.

When Yuu used his left fingers to spread her labia apart, *sploosh* - love juices dripped onto his face. How wet a woman gets depends largely on psychological factors - proof of Riko's feelings for him. Happy at this, Yuu merely moved his finger slightly at her vaginal entrance, producing a *kychu* sound that made Riko moan.

"Riko, you okay?"

"I-I'm fine! Yuu-kun is... being mean... ahn!"

Hearing the conversation between the two handling his penis, Yuu pouted slightly.

"Huh... I shouldn't touch?"

"Th-that's not..."

"Good. Then I'll play with your pussy more to make you feel good."

"Enough! Aiko! I can't lose here either!"

"U-un... ahhaa, Yuu-kun's penis is so hot and hard..."

Deciding to observe their skills, Yuu let them touch freely. Aiko massaged his balls while stroking the shaft with her palm, while Riko focused on sensitive spots like the glans and frenulum with skilled fingers. Aiko's novelty-driven exploration contrasted sharply with Riko's competitive determination to make Yuu come first. Their breathing and delicate touches heightened Yuu's sensitivity.

*(Now I'll get serious too.)*

Even in dim light, Riko's spread labia revealed beautiful salmon-pink flesh, glistening wetly as if waiting for him. Suppressing the urge to immediately suck, Yuu first touched her vaginal opening with his middle fingertip. With a *nup* sound, his finger slid in effortlessly to the second knuckle, her insides tightening around it. Though accustomed to Yuu's penis, even one finger felt tight. As he gently pumped, *squelch* - sticky fluids coated his palm.

"Yah! Aahn... Yuu-kunn... not there!"

*Thump* - Riko's head dropped, something soft hitting the tip of his penis. Probably her cheek. Being told "no" only made Yuu want to tease more. He inserted his middle finger deeper.

"Ah! Ah! Aahn! Nnnn~! Th-then I'll eat your penis! *Omph*!"  
"Whoa!"  
"Wow! Sudden fellatio!? Then I'll..."

Riko must have taken the glans into her mouth - Yuu felt enveloped in warm, soft mucosa. She swirled her tongue around the head while Aiko licked the shaft. With two against one, Yuu couldn't lose either.

While fingering from entrance to deep inside, he bent his second knuckle to stimulate her G-spot.

"*Puhah*! Aah! Ahi! Yuu...kun! Ra...raa... can't concentrate... ah! Ah! Aahn!"

Unable to continue fellating, Riko threw her head back moaning, though impressively kept stroking with one hand. Freed up, Aiko grew bolder with tongue and hand. Precum and Riko's drool dripped from the tip, making *squelchy* sounds with each stroke.

Meanwhile, when Yuu withdrew his finger from Riko's vagina, bubbly juices splattered on his face. She was nearing her limit. Tucking his chin, Yuu extended his tongue and spread her labia. The moment his tongue flicked her clitoris, Riko's lower body jerked violently.

"Hyuun! Yah! Aah! Aah! Aahn! No... I'm... I'm cumming! Ahn! Ahn! Ah! I'm cummiiiiiiiiiiiiiiiiiiiiiiing!!!"

At that instant, *splash* - she squirted copiously, drenching Yuu's face.

"Wow! Amazing! Always cool-headed Riko making such an orgasm face from cunnilingus!"  
"Ah...ah... oh... hyan! W-wait... Yuu-kun!?"

Perhaps overexcited from the fellatio and handjob, Yuu didn't stop after making her cum once.

*Lerojuppochyurujupjurbuchuuuuuun!*  
"Gyah!? Hyaiiiiiii! Aau... stop! No more! Ahn! I'm cumming! I'm cumming agaiiin!"

Yuu plastered his mouth to her vaginal opening, inserting his tongue to scoop out fluids while vigorously rubbing her clit with one hand. Sandwiched front and back, the two melted into ecstasy using four hands to pleasure him. While Riko panted too breathless for fellatio, Aiko enthusiastically sucked the precum overflowing from the tip. This three-way banquet finally approached its climax.

"Hahi! Aah! Aaaaaaaaaaah! No! I'm cumming! Cumming! Ahii... I'm cummiiiiiiiiiiiiiiiiing!!!"  
"*Nguh*... ooh... ooh!"  
"Hyah!"

As Riko threw her head back in her second squirting orgasm, semen shot out powerfully - *dopyudopyudopyuu* - splattering white across Aiko's face as she licked and even reaching Riko's upturned face, hitting her glasses.

"Th-this is male semen... ah, so hot and thick. Completely different from AVs... *Nguh*... *n*... *vgu*. Wh-what concentration. Barely can swallow it. Is Yuu-kun special?"  
"Hah... hah... not sure... but Yuu-kun's is... thick... I want to lick too..."

Riko dropped her chin with a loving expression, eagerly licking off the semen she'd missed earlier.

"Eh... y-you're inserting it just like that?"  
"Un. Everyone's different, but this is Riko's favorite position."  
"Uu..."

Yuu now sat between the legs of Riko, lying face down on the bed. After smoothing her disheveled hair, he caressed her smooth, beautiful back. Sitting pressed beside them, Aiko asked curiously as Yuu answered.

Missionary, cowgirl, facing seated, sometimes doggy... having tried various positions with the student council trio, they'd learned Riko came easiest in doggy style regardless of intention. Currently burying her face in the sheets from embarrassment.

Aiko mainly knew cowgirl position from videos/books, occasionally facing seated. Rarely saw doggy outside eromanga depicting assertive men. In this world, doggy was uncommon, but Yuu knew women like Elena and Riko became addicted after trying it. Currently, Riko lacked energy to ride him after consecutive orgasms during sixty-nine.

"Come on, Riko. Lift your hips."  
"Yu...Yuu...kun. You've already made me feel so good..."  
"What're you saying? The main event starts now."  
"Ah...nn..."

Riko bent her long slender legs, lifting her small but shapely buttocks toward Yuu while keeping her upper body prone - like yoga's cat stretch pose. As Yuu caressed her buttocks, he suddenly had an idea.

"Hey, I want to hear that 'begging' from before."  
"Eh? H-here?"  
"Un. Hearing it from Riko's mouth really excites me."  
"Eeh..."

Riko glanced at Aiko before hiding her face. "I-it's embarrassing, Yuu-kun."  
"But it might help Aiko's writing."  
"Hohou. That sounds intriguing. I'd love to hear this 'begging'!"  
"See? Aiko says so too. No need to be shy now."  
"B-but..."

After hesitating, Riko ultimately complied with Yuu's request. Propping herself on her right elbow, she reached her left hand between her legs and spread her labia open with her fingers.

"Pl-please... put your... thick... penis... inside my... lewd... p-pussy!"

Though blushing crimson, saying this seemed to arouse Riko - Yuu saw a small squirt from her vaginal opening. Gripping her buttocks, Yuu pushed his hips forward while praising her.

"Thank you, Riko. Here's your reward."  
"Ah...ahn! Yuu-kunn! It's coming!"

As Riko looked back with seductive eyes, Yuu smiled and covered her, thrusting deep in one motion.

"Ahh! Riko!"  
"Haaaaaaaaaahn! Aah! Aahn! Ahyu...nnnnnnnnnnnn!"

Unable to hold herself up, Riko collapsed face-first into the sheets with muffled cries. Clearly she came again from the impact against her cervix.

"Fah... amazing. I-is this sex...?"  
"N-no... only Yuu-kun is... special... probably"  
"Though Riko's body is quite sensitive too"  
"Th-that's... because it's Yuu-kun! Ahn!"  
"Fufu. Makes me happy. Then I'll go all out!"  
"Hiyin! S-slowly is fine... no! Don't! Ah! Ah! Aahn! I'll cum again!"

As Aiko watched wide-eyed, Yuu began rhythmically thrusting into Riko who presented her raised hips.

### Chapter Translation Notes
- Translated "陰嚢" as "scrotum" per explicit terminology requirement
- Preserved Japanese honorifics (-kun, -san) throughout
- Transliterated sound effects: "ぷしゃっと" → "splash", "ぬぷっと" → "nup", "にちゃにちゃ" → "squelchy"
- Rendered sexual acts without euphemisms: "フェラチオ" → "fellatio", "おマンコ" → "pussy"
- Maintained original name order: "祐君" → "Yuu-kun", "莉子" → "Riko", "愛子" → "Aiko"
- Italicized internal monologue: "（そろそろ、こっちも本気出しますか）" → *(Now I'll get serious too.)*
- Translated anatomical terms directly: "亀頭" → "glans", "膣口" → "vaginal opening"
- Used explicit terminology for fluids: "精液" → "semen", "愛液" → "love juices"
- Formatted dialogue with new paragraphs per speaker