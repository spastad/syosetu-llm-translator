## 147. Winner's Privilege ⑤ ~This Summer Might Change My Life~

"Gyaaaaaaaaah! I-I'm cumming! Uuungh! Oh... hah, hah, hah... Yu...u...kun, nnnnnnnnnngh! This... this is... gyaaan!"

"Guh! Ah... kaha... It's... in! Ooh... Inside Aiko's vagina... feels so good... amazing!"

"I-I'm glad... ahhn! This is... your cock... ooh... ooh... reaching deep... inside... me!"

In the missionary position, Yuu stopped moving after thrusting deep inside. The moment he penetrated the virgin vagina brought him supreme pleasure. That he could withstand it was likely due to having ejaculated twice already today and his prior experience. Still, individual differences existed. Inside Aiko's vagina, beyond the characteristic tightness of a virgin, he felt a heat that seemed to tightly envelop his cock.

Looking at Aiko's face, beads of sweat dotted her forehead, with several strands of disheveled hair sticking to her skin. Yuu gently combed them aside with his fingertips as he spoke.

"S-so! Does it hurt? Aiko?"

"Ufu... ufufufufufu"

For a moment, Yuu worried she might have broken, but seeing her calm smile reassured him. Aiko had been gripping Yuu's shoulders tightly with both hands earlier, but now she reached around his back, gently stroking while gazing at him with light brown eyes.

"I'd heard there are individual differences for first times, but most people feel pain. Certainly, when Yuu-kun's cock entered me, it felt like a hot rod piercing through my abdomen, and I let out a huge scream... But after your cock reached deep inside with a 'thump'... this warm sensation started melting out from my belly... and now... ehehe. I-it feels... good!"

Saying this, Aiko bashfully raised her head and bumped it against Yuu's chest. Hearing this, no man could remain unmoved. Yuu wrapped his arm around Aiko's head, holding her close while nuzzling her cheek and pressing his lips to hers.

"My, how nice. When I lost my virginity, the pain continued for a while until I cried. After all, Yuu-kun's cock is so big. Yet you moved like a beast..."

"Ahahaha. My bad. I was crazy excited back then... Well, I still get excited when having sex with Riko too. Anyway, your expressions turn me on."

"...Idiot"

As Riko, who had been caressing Aiko's head affectionately, brought her face closer, Yuu stroked her hair while kissing her. Then Aiko reached around the back of Yuu's head, pleading.

"*Mmmchu, chuu... nn, afu... nnaa, ah, ahn! M-move*"

"Well, I'll move. Have you gotten used to it a bit... oof, squeezing inside..."

"Anh! Yuu...kun! I-It's so big... haaan!"

The pause had apparently helped. The love juices seeping inside seemed to provide lubrication, allowing smooth movement at a slow pace. But just as the thrusting became steady, the vaginal folds began wriggling, delivering hot stimulation to Yuu's cock.

"Ah... truly... feels so good..."

"M-me too... good! B-but, don't mind me, move... as you like... aahn!"

"Then I won't hold back"

Yuu slowly lowered Aiko, whom he'd been holding with his left arm. Raising his upper body slightly while holding Aiko's plump thighs, he thrust deep inside, then changed to circular hip movements.

"Hyaaaaaaaun! My insides are being... s-scraped by your cock! Ahn, ahn, amazing! I didn't... know this! Ahi! So good!"

Aiko gripped the sheets tightly with her right hand, clasped Riko's hand with her left, and moaned with an intensity unbelievable for a first-timer. With each thrust of Yuu's hips, sticky wet sounds - *nucchu, nucchu* - came from their joining point, and each shake of Aiko's upper body made her ample breasts sway *tapuntapun*.

Riko, not only witnessing Yuu and Aiko's union but also affected by the heat and lewd smells, couldn't remain calm either. She covered Aiko to kiss her, licked the sweat from her upper body as if drinking it in, then inserted her own fingers into her vagina, making *guchu guchu* sounds while stirring the accumulated semen inside.

Yuu wanted to make Aiko cum internally. That's why he'd been thrusting cautiously while observing her reaction. But the tightness of Aiko's freshly deflowered vagina was no joke. If he'd pistoned monotonously, he would've cum immediately, so he'd been varying the intensity. But gradually, a tingling pleasure built in his lower body.

"Kuuuuu... d-dangerous. I might not last..."

He switched to slow but deep strokes. But now, whether pushing or pulling, the fine folds stimulated and tightened *kyukyu*, bringing immense pleasure. Changing positions was an option, but seeing Riko and Aiko passionately kissing before him, he decided to keep going.

"*Chu, chu*, Aiko!"

"Anh, Riko... *mmmuun... chupachupaleroo... gwaaah! Aah!*"

"Yuu-kun?"

"Final sprint soon"

Yuu grabbed Aiko's ample breast with his left hand like an eagle's talon. His right hand slid down Riko's back from her butt to her semen-smeared privates. Riko already had a finger inside, but Yuu added his own. While buried deep in Aiko's vagina, he began rapid shallow thrusts.

"Gyaaaaaa... Yuu-kun's finger!"

"H-here! I'll... cum inside Aiko!"

"Aaaah aaah... deep thumping nooo... aaah, aaah... too much, amazing... kihyaaa!"

"Kuooh! A-Aiko's inside... aah! Dangerous, gonna cum!"

"Anh, anh, anh... coming... cum inside... Yuu...ku...n!"

"Ahee... I'm also... feeling... good, good!"

Riko, being played with by two fingers intertwined inside her vagina, seemed extremely aroused too. While squirting *pushu pushu* between the fingers, she panted with her tongue out near Aiko's neck.

"Aiko, Riko!"

""Yuu-kun!""

Yuu lowered his upper body, holding Aiko with his left arm while continuing to finger Riko with his right. He knew his semen was nearing its limit, on the verge of ejaculation. Yuu attacked Riko with *juppo juppo* sounds while thrusting vigorously into Aiko, aiming for her womb as he finished.

"A...hi... Yu...u...ku... aaah, aaah, gyaah! My pussy, amazing, amazing! Gyaaaaaaahhhhhhhhhh!!!"

"Gyaah! Yuu...kun! I'm... ah, cumming, cumming, cumming... gyaahn! No! I'm cummiiiiiiiiiiiiiiiiing!!!"

"I-I'm too... c-cumming! Ugh..."

"Heeh!? Ah... eh.................."

Perhaps shocked by being ejaculated into right after orgasming, Aiko's eyes flew open wide. As she received thick spurts of semen into her womb, she opened and closed her mouth wordlessly, emitting voiceless moans.

Despite being his third ejaculation, Yuu released a massive amount of semen before collapsing onto Aiko. Riko, brought to orgasm by two fingers, also lay limp.

"Haa~~~~~~ That felt amazing, Aiko... hm?"

"Afuu... I got fingered to orgasm too... huh?"

Aiko stared blankly into space with a dazed expression.

""Aiko?""

"Hah!? My heart is pounding so hard, yet my head feels floaty, like drifting on clouds."

"So how was your first time?"

"Ah..."

Asked by Riko, Aiko looked at Yuu up close and turned red like a boiled octopus. "I... I..."

"Hm?"

"I'm... supremely happy... I'm glad I'm alive."

It might seem exaggerated, but without excelling in the quiz championship and befriending Riko who's close to Yuu, she might have remained a virgin forever. For her, this day was an unforgettable milestone where she gained happiness.

***

"Wow, the sheets are soaked"  
"S-so they are..."  
"Uwaa, they got this wet?"

After resting while hugging each other, they noticed a large wet stain centered where their lower bodies had been. Yuu had wiped with tissue when pulling his cock out of Aiko to prevent semen backflow, but the wetness mostly came from the two girls. Or rather, Riko's dramatic squirting. Though usually cool and composed, once intimate with Yuu, Riko became highly sensitive and squirted repeatedly. So much so that the student council room kept multiple large towels. Being a hotel, they'd brought nothing, so seeing the aftermath was embarrassing. Riko looked down silently. Yuu comforted her by stroking her head.

"It's fine. Nothing to be ashamed of. I love that side of you. Or rather, I absolutely don't want other men seeing it."  
"Yuu-kun! Only you get to see me like this. I could never imagine anyone else. I love you!"

Riko hugged him tightly, and Yuu gently embraced and stroked her. Watching them fondly, Aiko said:

"I knew many girls across grades admired Yuu-kun, but his true charm isn't just looks - it's how he embraces girls. I... feel a bit envious of Riko now."  
"Oh? Since we've been intimate, I want to get along with you too, Aiko."  
"Eh?"  
"Come here. Don't hold back."  
"Y-yes"

Yuu sat cross-legged on the bed, happily accepting hugs from Riko and Aiko on either side. Though all were sweaty, the smell and warmth felt comforting.

"But we can't stay like this forever. Shall we shower?"  
"Mm"  
"Then Yuu-kun, you go first"  
"Hmm... Can't we all go in together?"  
""Eh?""

Peeking into the bathroom, it wasn't a unit bath. Slightly larger than a home bathroom - comparable to a high-end love hotel. Being a double room, it likely anticipated couples bathing together.

So while filling the tub, they remained naked, cuddling and drinking water. After exchanging many kisses until Riko and Aiko's faces were blissfully relaxed, they stumbled into the bathroom entangled.

Once inside, the three became so soapy it was unclear whether they were washing or fondling each other. They decided to wash backs in order: Aiko → Yuu → Riko. Yuu kneaded Aiko's ample breasts with both hands, while Riko groped Yuu's chest before carefully washing his cock with both hands. Unable to resist, Yuu asked Aiko for a titfuck. Being buried between soapy, soft breasts and stroked by plump flesh was paradise, but when Riko started noisily sucking the tip, it became unbearable. Despite being his fourth time, Yuu came easily, painting Riko and Aiko's faces and chests white.

The tub proved cramped for three, so they soaked while pressed together until slightly lightheaded. By the time they emerged, it was past 10 PM. Girls take time preparing. Yuu, dressed first, called Kanako to arrange an 11 PM pickup.

When Riko and Aiko finished dressing, combing hair, and light makeup, time remained. Riko asked to talk at the window-side table. Aiko sat at a nearby desk, writing intently in her notebook - likely recording today's events.

Sitting across from Yuu, Riko looked melancholic, more than just sad about parting. After sipping bottled oolong tea from the fridge, she broke the silence.

"You're going to Saiei tomorrow?"  
"Yeah. Didn't really want to, but got invited as student council."  
"Mm... Yuu-kun"  
"What?"

Riko's eyes behind her glasses grew serious.

"I have a bad feeling"  
"Hmm... But for inviting boys, they'll surely prevent trouble and provide security"  
"True. According to my intel, Saiei wants to make inviting boys an annual tradition, not just this once."  
"Is that so?"  
"So they'll avoid reckless actions that'd make boys never return. Of course, Sairei will send five times more girls to protect the boys. Plus, contracted security for emergencies."  
"Then it's fine, right?"  
"That's not it"

Riko looked down, shaking her head. Her concern wasn't for all attending boys. Her gaze revealed the answer.

"I'm worried about you alone, Yuu-kun"  
"Me..."  
"I feel Saiei's student council will target you specifically"  
"Ah"

Such signs had appeared since quiz championship preparations. Each time, Sayaka, Riko, and Emi formed an iron defense. Meetings were at Sairei before, but tomorrow at Saiei, they might gather numbers and force their approach. From what Yuu saw, Saiei's president Mitsuse Rinne and vice-president Omori Norika certainly had alluring looks. Honestly, he wanted to have sex. But they were like poisonous or thorny flowers. A casual encounter wouldn't end with goodbye - he'd regret it. He preferred getting along with Sairei girls.

Thinking silently, perhaps seeming anxious, Riko put down her bottle and leaned forward to grasp Yuu's hands.

"No matter what, we'll protect you!"  
"Th-thanks. I'm counting on you, Riko"  
"Nmmu!?"

Smiling, Yuu rose to kiss Riko. While kissing her repeatedly, he felt guilty about burdening Sayaka, Riko, and Emi. His aversion to violence against girls remained unchanged. But if necessary, he resolved to use the self-defense techniques learned from Kanako and Touko to protect himself.

***

***

***

***

---

### Author's Afterword

The Riko & Aiko arc was initially planned for about three chapters, but it expanded once I started writing.

And next chapter finally features the Saiei Academy visit.

### Chapter Translation Notes
- Translated "膣内(なか)" as "vagina" consistently per explicit terminology requirement
- Preserved Japanese honorifics (-kun) and name order (e.g., "Mitsuse Rinne")
- Transliterated sound effects (e.g., "nucchu" for ぬっちゅ, "guchu guchu" for ぐちゅぐちゅ)
- Rendered sexual acts without euphemisms (e.g., "ejaculated inside" for 中に射精)
- Maintained original dialogue structure with new paragraphs for each speaker
- Translated "彩麗" as "Saiei Academy" per Fixed Reference consistency
- Italicized internal monologue indicators (though none present in this chapter)