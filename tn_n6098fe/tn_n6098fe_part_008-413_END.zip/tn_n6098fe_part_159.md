## 148. At Saiei Academy ① ~Melody~

Private Saiei Academy High School is located in the northwestern part of Sakate City, which borders the south of Saio City.

It is away from the station and urban areas, and as can be seen from the nearby Saitama Natural Animal Park used by Sairei Academy for the Newcomer Welcome Orienteering, the surrounding area is lush with greenery.

It is about a 20-minute drive from Sairei Academy, or about 30 minutes by bicycle.

When viewed from above, the grounds of Saiei Academy form a slightly elongated "mouth" shape with four buildings.

The school building on the top side is exactly on the north side, which is Building A used by the general studies course.

The buildings on the left and right (east and west) are Buildings B and C, used by the various arts courses.

The building on the bottom side (south), mainly used by teachers—what would be called the administration building in other schools—is Building D. Each is a three-story building, connected by corridors on the second floor.

The south side of the school grounds is the main gate, with a long straight path extending to the entrance in the center of Building D.

On the east side of the road is a large parking lot that can hold about 150 cars. Across the road to the west stands a multipurpose hall as tall as the three-story school buildings.

North of Building A, sports facilities spread out, including two large and small grounds, tennis courts, a gymnasium, an indoor practice field, and a pool.

Its scale surpassed that of Sairei Academy in the neighboring city.

Saiei Academy was founded 20 years ago.

Half of the students were in the rare-for-high-school specialized arts courses, and the other half were in the general studies course, with the aim of gathering and nurturing talented individuals in academics and sports.

That plan only half succeeded.

Thanks to the instructors gathered using Ayakuni Group's money and connections and the excellent facilities, within a few years, students began participating in national competitions and exhibitions, and even produced alumnae who became famous professionals after attending art and music universities.

On the other hand, the general studies course struggled to attract students.

There was a reason for this.

In terms of academics and sports, the sister school Sairei Academy in the neighboring city was widely known.

In fact, there was opposition on the board to building a school in the city next to Sairei Academy.

But there were adult circumstances, such as a university campus that was scheduled to move in and had been acquired suddenly canceling, leading the Ayakuni Group, which was looking for a new site for a school, to be chosen.

If this had been in the populous southern part of the prefecture, it might not have been a problem, but in the central part with few large cities, the nearby capacity was too small.

As feared, the general studies course continued to fall below capacity for a while, and many of the enrollees were low-level students who couldn't get into nearby public high schools.

Sports clubs were also inactive, and the vast sports facilities were wasted.

While students in the arts courses achieved excellent results and raised the name of Saiei Academy, the tendency for the ordinary course students to cause problems and drag the school down continued for a while.

Thus, 15 years ago, when the Ayakuni Group decided to go co-ed, Saiei Academy appealed with its new and excellent facilities, but the biggest stumbling block was undoubtedly the quality of the students.

After Sairei Academy was chosen for co-education, the sister school exchange with Saiei, which had lost out, was cut off, and the rift deepened.

But that's when Saiei's reforms began.

First, the enrollment for the general studies course, which had fallen below a deviation score of 40, was drastically reduced from 130 to 90 per grade (with the arts-related courses' enrollment slightly increased).

Then, new courses were established: a Special Advancement Course aiming for admission to prestigious universities (with exemption of enrollment fees only or both enrollment and tuition fees based on grades), and a Business Advancement Course to learn about society from a broad perspective and aim to become entrepreneurs or managers.

The remaining general course also saw improvements in teacher quality to raise the level to average.

Also, around this time, the student council's authority was strengthened to allow the students themselves to discipline the unruly general studies students.

For a while after its founding, the student council officers were dominated by students from the various arts courses, but after two or three years, students from the Special Advancement and Business Advancement courses began to mix in.

Moreover, Saiei Academy, which failed to become co-ed, changed in another way.

Particularly noticeable was the attitude towards men.

Originally, Sairei Academy, which focused on academics and sports and valued the position of men, aiming to cultivate women who could become good wives and wise mothers, was the most suitable for co-education.

Conversely, Saiei Academy, due to the low quality of its students in the first few years and the fact that adherents of the increasingly influential Male Inclusion Movement had solidified among the parents, had a tendency to look down on men as inferior to women.

Of course, criminal acts against men off-campus were avoided, but instead, dark rumors began to circulate quietly about the student council over the past ten years or so.

That they were taking advantage of men's weaknesses and confining them.

After school, figures with hidden faces were seen entering the building with the student council, surrounded by student council members.

However, no student made a fuss about it, and if they did, they would suddenly become quiet or stop coming to school.

Thus, for Sairei Academy, Saiei Academy High School was an object of caution in a different sense from the notorious Ichimatsu High School.

But as a result of the quiz championship, male students were invited.

The period was limited, but as a result of Saiei Academy's earnest school appeal, which had mainly pushed its arts programs, 21 male students from three grades decided to participate.

Therefore, through discussions between student representatives including the student councils of Sairei and Saiei, several conditions were agreed upon for the male students' visit:

- To ensure that male students do not have unpleasant experiences due to excessive actions by Saiei students, Saiei will provide prior warnings and strict vigilance on the day.
- Several restrooms will be designated for male use only. To prevent female students from hiding inside, security guards will stand by and prohibit entry except when in use by males.
- Sairei will have five times the number of female students accompanying the males.
- Both Saiei and Sairei will bring security guards contracted by the school.

For the Sairei female students, it was an inescapable anxiety and tension.

For the Saiei students, it was anticipation and joy.

Harboring such contrasting feelings, the groundbreaking day of inviting male high school students to an all-girls school finally arrived.

At 9 a.m., they gathered at the school once.

After boarding buses and arriving at Saiei Academy, Sairei students got off the parked vehicles one after another.

Security guards who had gotten off the security company van first and a security team of large-framed students from sports clubs surrounded the bus doors.

Perhaps the area had been cleared in advance, as there were no Saiei students in the parking lot.

However, from the second and third floors of the nearest Building D, not only students but also faculty were watching.

Since they had boarded the buses by grade, Yuu immediately ran to the first bus after getting off.

The surrounding girls were flustered, but Yuu headed straight for the group of third-year girls gathered.

Standing a little apart from the circle surrounding the third-year boys were Komatsu Sayaka and Hanmura Riko.

Although it was summer vacation, today all the girls were wearing sailor uniforms, their school uniform.

"Sayaka!"

"Ah... Yuu-kun?"

"Yuu-kun!"

"Are you feeling okay?"

"I'm fine. See?"

Komatsu Sayaka smiled at Yuu and struck a pose flexing her muscles.

Sayaka, who often goes without makeup—even without makeup, her dignified beauty stands out—but up close, it was clear that today she had applied makeup to hide her pale complexion.

Looking at Riko, she had a resigned expression.

When he called two days after the quiz championship, he heard that she had a slight cold with a low-grade fever, not enough to see a doctor.

Fortunately, since it was summer vacation, she was resting in her apartment, and Riko had been checking on her every other day.

When Yuu asked if he should visit, she refused in a flustered manner, saying she didn't want to risk infecting him.

Today, there was also an opinion that Riko should act as proxy president and that Sayaka should rest.

But it seemed they couldn't stop Sayaka, who was forcing a smile and putting on a brave face.

Yuu grasped Sayaka's hand.

Although the outside was hot with strong sunlight, Sayaka's hand felt colder than usual.

"Yuu-kun?"

"Anyway, just do your best this morning, finish greeting the student council there, and go home early."

"That's right. That would be good."

They were invited to deepen friendship between the student councils, also as a reflection meeting for the quiz championship, after lunch.

But they could use Sayaka's poor health as a reason to leave early and arrange to meet at Sairei another day.

Not only Yuu, but Riko also had no intention of staying long.

After everyone got off the bus and started walking, several Saiei students in sailor-style one-piece uniforms came out of the entrance of Building D.

Yuu recognized Kate Grimwood among them, her long blonde hair flowing in the wind.

"Everyone from Sairei Academy, welcome. We will be your guides for today."

Kate, who usually seems aloof and unfriendly, was now smiling.

Two from the student council and two from the music course, the main focus of the morning, seemed to have come as guides.

"Thank you for having us. From Sairei Academy, 21 male students and 113 female students have arrived."

Putting aside the past circumstances, Sayaka also answered with a forced smile.

Note that security guards in uniform were attached to the front and back of the group.

"This way."

Guided by Kate and the others, the group crossed the road from the main gate and headed to the multipurpose hall.

Judging from its appearance, it was as tall as the three-story school buildings, an impressively grand building for a high school.

Entering the entrance, the air conditioning was on, and several voices exclaimed, "It's cool!"

Beyond the thick doors was the concert hall, the venue.

The ceiling inside was quite high, and the seats were tiered, with the back higher.

Here, a presentation centered on selected students from the music course, the largest among the arts-related departments, was held. Moreover, as an event for Sairei Academy, the male students were grouped in the center front row, surrounded by female students.

In a hall that seats 1000, there were 133 Sairei students, and in the back seats, a few people sat scattered—apparently music course instructors and students—but the total didn't even reach 200.

Considering the size of the audience, it seemed wasteful.

Yuu was sitting next to Higashino Rei and Yamada Masaya, who were also participating.

Masaya, who had taken piano lessons until middle school and joined the wind instrument club in high school, was in high spirits. It was unusual for him, who is usually cool.

Looking at the program distributed upon entry, Masaya spoke in an excited tone.

"Starting with 'Heroic Polonaise'? And next is Chopin's 'Black Key Etude'!? That's great. If I had continued piano in high school, I would have wanted to play it."

"Is it really that difficult?"

"Of course! Both are advanced pieces with difficulty level F! 'Heroic' and 'Black Key' have many difficult passages and require considerable energy and stamina. I'm looking forward to hearing how well they play. Ah, you might have heard 'Heroic' before, Yuu? It has a famous phrase used in dramas and commercials."

"Hoho. That sounds fun."

"Then I'm looking forward to the accompaniment with flute and violin, but I can't take my eyes off the orchestra with the wind instrument club at the end. Saiei's wind instrument club is said to be top-level in the prefecture."

Masaya's unusually passionate words seemed set to continue, but at 9:45, a beeeep buzzer sounded. It was finally starting.

First, an announcement played.

'Thank you very much for coming to Saiei Academy High School's special open campus today. For the morning session, you will listen to performances by students from Saiei Academy's proud music course in this concert hall. We ask for your quiet appreciation until the end. The first piece is Chopin's "Polonaise No. 6," commonly known as "Heroic Polonaise." Performed by a representative from the music course piano department...'

A glossy grand piano stood in the center of the stage.

The introduced student emerged quietly from the wings.

Her long dress, a vivid crimson, bared her shoulders.

Without anything to compare, it was hard to tell, but she was probably a tall female student.

Her long black hair, wavy down to her back, and heavy makeup for stage effect made her look unusually mature.

Perhaps because it was just beginning and tension filled the air, modest applause greeted her elegant bow.

Sitting on the chair and checking her position, she straightened her back and closed her eyes for a moment, seemingly calming herself.

Then, with a natural movement, she placed one foot on the pedal and extended both hands to the keyboard, beginning the performance.

*(Ah, this phrase, I've definitely heard it before. But still... amazing.)*

The woven sounds were a powerful rhythm and a flowing, beautiful melody.

Meanwhile, the performer's fingers busily moved from end to end of the long keyboard, with hardly any rest.

It was amazing how she didn't make mistakes despite such rapid movements.

The acoustics probably helped, but Yuu had never imagined that live piano playing could resonate so much and make his body tremble.

Once, Yuu himself had been familiar with various pop songs from his teens, but in this reborn world, they were completely replaced, which had made him feel lonely.

This was also due to the drastic reduction of men and the reversal of chastity norms.

After all, over 90% of singers were women, and there were hardly any female idols targeting male appeal.

But for classical music, perhaps because it followed a similar history, many pieces were familiar to Yuu, which was a relief.

Yuu himself wasn't well-versed in classical music, but in the "Heroic Polonaise," phrases he remembered hearing in dramas and commercials in his previous life were repeated many times, which made him happy.

The next piece, officially titled Chopin's "Étude No. 5 in G-flat Major," was better known by its common name, "Black Key Étude."

As soon as a tall student in an eye-catching bluish-purple dress began playing, the audience was overwhelmed by the tremendous finger work and the brilliant, speedy melody.

Even Yuu, who had little interest in classical music, was captivated by the powerful keystrokes and the ever-changing melody.

When the performance ended and the performer stood up with an accomplished expression after the lingering notes, thunderous applause erupted.

Of course, Yuu was among them.

After the piano solos came accompaniments with flute, violin, and soprano solo.

Yuu didn't know any of the pieces, but each was so wonderful that he listened intently.

After a 15-minute intermission, the curtain rose to reveal an orchestra with various instruments filling the stage, and in front of them, uniformed female students lined up.

It was a joint performance by the music course's various instrument departments and the wind instrument club, along with a choir by the vocal music course students, performing Beethoven's "Symphony No. 9."

Even in his previous life, it was known as the "Ninth" or "Ode to Joy," with a festive image.

This piece might have been chosen to express Saiei students' joy in welcoming the male students, Yuu thought.

After the choir left the wings, the second piece was a representative song by a nationally popular singer.

Of course, Yuu had no way of knowing it, but since it was occasionally played on TV programs, he barely recognized the chorus.

Finally, "Bolero" was performed.

It began with a unique rhythm from the snare drum and a quiet flute, but as it progressed through certain parts, the same melody was played alternately by different instruments: clarinet, piccolo, oboe, trumpet, etc.

Even though it was just repeating the same theme, he was drawn in, and as the violin joined, the momentum gradually increased.

Eventually, in the final part, it reached a climax with the overwhelming force of all the instruments.

For Yuu, it was a piece strongly remembered because it was used as an insert song in an anime film based on a space opera novel he loved.

Thus, when it reached the climax, Yuu's chest grew hot with emotion, and the moment the performance ended, he stood up without thinking and gave a hearty applause.

This spread to Masaya next to him and then to other boys and girls, and they praised the performance with a standing ovation.

Music transcends borders.

It means that even if people are divided by religion, ethnicity, or economic circumstances and are hostile, they can become one before the charm of music.

Although they had drawn in the recent quiz championship and had somewhat warmed up, Saiei Academy's impression was not good for Yuu and the Sairei students.

But before an excellent performance, any lingering resentment disappeared, and they were made to feel sincere admiration.

---

### Author's Afterword

"Where there is light, there is shadow"... a narration from a rather old ninja anime.

"As long as there is light, there is also darkness"... the line when the true final boss of Dragon Quest III is defeated.

So, the first part of the Saiei Academy arc was the light side.

Now, what about the shadows and darkness of Saiei Academy...? (playing dumb)

### Chapter Translation Notes
- Translated "彩麗学園" as "Saiei Academy" consistently per Fixed Reference
- Preserved Japanese honorifics (-kun) and name order (e.g., Higashino Rei)
- Transliterated sound effects (ビーーーっと → "beeeep")
- Translated musical terms precisely (英雄ポロネーズ → "Heroic Polonaise")
- Maintained internal monologue formatting in italics
- Translated cultural references in afterword while preserving original context
- Used formal titles for organizations (e.g., "Ayakuni Group")