## 149. At Saiei Academy ② ~Dangerous Premonition~

The morning concert ended.  

Before I knew it, over two hours had passed including the break, but it felt like it ended in the blink of an eye without a moment of boredom.  

Next was lunch at Saiei Academy's cafeteria - not a standard school cafeteria but a stylish one. First, everyone needed to use the restroom.  

We exited the auditorium to the entrance hall for restroom breaks. Since this concert hall anticipated external visitors, it apparently had a men's restroom. However, it couldn't accommodate all 21 boys at once, so third-years entered first.  

While chatting with Masaya and Rei as we exited, Yuu noticed Kate standing idly by the wall. Sairei girls and security guards had formed a pathway to prevent Saiei students from approaching, leaving her with nothing to do. Seeing that third-years were still lined up and first-years wouldn't get in soon, Yuu excused himself from his friends and approached Kate. The other student council girl had gone to the women's restroom, making it a good opportunity.  

"Good work out there."  
"Ah, you... you shouldn't come alone!"  
"It's fine. Just greeting an acquaintance."  
"Honestly..."  

Kate sighed at Yuu's action. Yuu judged it safe since Sairei students were gathered nearby. Guards stood at entrances to prevent unrelated Saiei students from entering, and Saiei girls from the audience seemed to be keeping their distance, not coming to the entrance hall.  

"It was a more wonderful concert than I expected. Everyone was moved."  
When Yuu praised them, even cool-faced Kate broke into a smile.  
"That's good to hear. I heard the selected members practiced like demons every single day since summer vacation started."  
"Wow. Then it was especially worth coming."  
"They must be delighted too."  

Their conversation lapsed into silence. Kate glanced at Yuu, then looked down and started to speak hesitantly without meeting his eyes.  
"Hey, about later..."  
"Huh?"  
Amid the surrounding noise, her soft voice was hard to hear.  

"This afternoon..."  
"Afternoon? Ah, the student council matter?"  
"Yeah..."  

But before she could continue, Yuu heard his name called. His turn for the restroom had come.  

"Time to go."  
"Wait!"  

Kate frantically pulled out her student handbook and pen, scribbled something, then tore out the page. She leaned close to Yuu, shielding it from view as she handed it over.  

"Read this in the restroom. Tear it up and flush it after reading."  
"Huh?"  
"Just do it, quickly!"  
"O-okay..."  

Later, in a stall with several first-year boys, Yuu unfolded the paper Kate had given him. It read:  

*'The student council officers are plotting something.  
Leave quickly before anything happens to you'*  

***

"Something wrong, Yuu?"  
"Huh?"  
"You've been spacing out since earlier."  
"Yuu-kun, are you worried about something?"  
"Um... n-no, nothing!"  
"Well, if you say so..."  

We were having lunch at the stylish cafeteria on D Building's first floor - called a "cafeteria" at Saiei. Despite summer vacation, staff were providing meals today. Likely due to temporary operations, only three options were available: Meat-based A set, Fish B set, and lighter C set with pasta, soup and salad. Yuu chose A, Masaya B, and Rei C, sharing a table, but Yuu couldn't focus on his food, preoccupied with the note.  

Yesterday's warning from Riko echoed in his mind. The Saiei student council president Mitsuse Rinne and vice-president Omori Norika might target Yuu instead of ordinary male students, given past history. That was easy to imagine. Especially concerning since Sayaka's health remained unstable.  

*Just greet them politely but firmly refuse if they persist. Better to wrap up early.* Having resolved this, Yuu nodded reassuringly at his worried friends and finally started eating. The affordable student meal proved surprisingly delicious, and he cleaned his plate.  

***

After lunch, Sairei students mingled regardless of gender for a while, but soon guides with placards appeared along the walls. The afternoon session focused on visiting arts department and active club presentations in B and C Buildings. Courses included: Music Department/Wind Ensemble/Choir, Art & Crafts Department and related clubs, Calligraphy & Traditional Japanese Arts clubs, and Drama & Light Music Club.  

Scheduled from 1:30 PM to 4:30 PM. Girls aside, boys couldn't be sent back freely even if bored - they'd wait on the bus in such cases. The cafeteria remained open as a designated rest area for Sairei students (Saiei students except guides were barred). Homemade cookies would be served by the cooking club from 3:00 PM. Truly impeccable hospitality.  

Masaya naturally chose the Music/Wind Ensemble/Choir course. Rei, who practiced tea ceremony, flower arrangement, and calligraphy with interest in traditional arts, opted for Calligraphy & Traditional Japanese Arts. Yuu would visit the student council with Sayaka and others, separating from them. With five times more girls and guards accompanying boys in each course, Yuu felt reassured as he bid them temporary farewell.  

Walking toward Sayaka, Riko, and Emi waiting near the cafeteria entrance, Yuu recalled Kate's note. *Maybe I should tell the three of them.* But the moment he approached, they pulled him aside.  

"What's wrong?"  
"W-well, you see..."  
"Sayaka." "Sayaka-senpai!"  
"Ah, yes."  

Apparently Sayaka had something to say. Urged by the other two, Sayaka looked Yuu straight in the eye with a serious expression.  

"Yuu-kun."  
"Yes."  
"You'll return to school before going home today, right?"  

Yuu nodded. They'd disband after returning to school.  

"Sorry, but could you stop by the student council room before leaving?"  
"Hm? Sure."  

Club support had settled down, and no urgent student council matters remained after today. Sayaka exchanged glances with Riko and Emi before nodding.  

"A-actually, all three of us have something important to tell you."  
"Something... you want to discuss just the four of us after everything's over?"  
"Y-yes."  

Since Sayaka called it important, Yuu couldn't refuse. "Got it. Okay. Then on the way back." Hearing Yuu's reply, all three smiled with visible relief.  

"Then let's settle the troublesome matter quickly."  
"Okaay. We can finish early and join the tour group. Yuu-kun, want to come along?"  
"Yeah. If Sayaka's feeling well, I'd like all four of us to go together."  
"Mm. Saiei seems more considerate than expected, but I want to see for myself."  

While discussing their next move, Kate's note faded to the back of Yuu's mind.  

The four exited the cafeteria to the courtyard. Unlike the air-conditioned school buildings, the intense summer sun immediately made sweat bead on their skin. The courtyard featured a fountain at the crossroads of walkways connecting buildings, benches scattered about, and flowerbeds blooming with colorful flowers. With summer vacation and students dispersed for Sairei visitors, no students were visible, but one could imagine this being their usual break-time oasis.  

The student council building - a three-story tower-like structure - stood southeast of the fountain plaza. Passing through the north door into the entrance, they found it pleasantly cool inside. Luxuriously, the entire building seemed air-conditioned.  

Noticing their arrival, a girl at the reception desk smiled and began calling someone.  

"Huh? They're already here.  
But... Hah... yes. R-really..."  
"Something wrong?"  
"Feh!?"  

Yuu spoke to the flustered girl. Apparently not expecting a boy to address her directly, she nearly dropped the receiver.  
"Ah, sorry! I thought they'd come at the agreed time."  
"Well... they seem flustered preparing upstairs. Could you wait a moment?"  
"No... we actually wanted to just greet them and leave today. Sorry for the inconvenience, but could you call them?"  
"Uh... I-I need you to wait..."  
"Just the officers?"  
"Um, that's..."  
"My, my?"  

As they debated, a woman descending the stairs noticed them and called out.  

"Could you be the Sairei student council? Welcome!"  
"Ah, hello."  
""""Hello!""""  

The woman in gray pants and white blouse, plump and middle-aged, appeared late 40s to early 50s. She exuded the pushy aura of a teacher in authority - likely vice-principal or grade head.  

"Our student council is waiting. Please come in."  
"No, thank you, but we just wanted to greet..."  

The receptionist asked them to wait while this teacher urged them forward. They only intended a brief greeting.  

"It's the student council room our presidents take pride in. Worth seeing!  
Since you're here, relax inside. Come now!"  

This type of aunt bulldozes through objections, convinced she's being helpful. Seeing their hesitation, she gestured insistently toward the stairs. Though she seemed to hold back with Yuu, she pushed firmly on Sayaka's back from behind. With unreadable expressions, the group headed upstairs under her watchful eye.  

"Seems the whole building is student council facilities."  
"All this? Even a dedicated conference room?"  
"They have ample student council funding."  
"Even among private schools, what a difference."  

Sairei's student council room in the dormitory was simple and unadorned, showing its 30-year age. But this Saiei building, possibly renovated, felt fresh and stylish like a city office. Reaching the third floor, they heard sharp voices from inside.  

"Still not ready!? They're already here!"  
"There seems to be a mix-up... I'm fetching it now!"  
"Honestly! The disorganization is unbelievable!"  
"S-sorry!"  

"Sounds lively."  
"Indeed."  
"Shall we go in?"  

Knocking brought no reply - only scolding and apologizing voices. The main scolder sounded like the president. Though reluctant to interrupt, they couldn't wait forever. Sayaka and Riko looked exasperated; Emi clung fearfully to Yuu's back. Yuu felt like leaving but feared repercussions, so he quietly opened the door.  

"Hello~"  
""""Ah!""""  

Though unfamiliar in his past life, the spacious, opulent interior reminded Yuu of TV depictions of corporate boardrooms. To the right, windows overlooked a U-shaped table of high-quality office materials unlike Sairei's. To the left sat black leather reception sofas. On a single-seater directly opposite, the president sat with legs crossed, making Yuu's eyes inadvertently drop to her exposed thighs.  

Recognizing Yuu, Rinne hastily stood, smoothed her long hair and dress wrinkles, and assumed an elegant smile.  

"My! Welcome!  
I specially ordered rare, premium tea leaves from overseas for this occasion.  
But apologies, the tea isn't ready yet..."  
"No need for trouble. We just came to greet you and leave."  
"S-sorry I'm late... ah!"  
"Kyaah!"  
"Hm?"  

Turning at the voice, Yuu saw someone rushing in nearly collide with Emi near the entrance. Trying to dodge awkwardly, the shorter figure stumbled forward.  

"Whoa!"  
"Whoops!"  

Yuu stepped forward, catching a flying brown paper bag against his chest with his left hand while using his right arm to support the falling figure. The small person had short, curly black hair and wore a white shirt with black shorts - seemingly a boy younger than Yuu.  

"Ah... eh...?"  
"You okay?"  

Looking up, he revealed dark skin and deep-set features suggesting West Asian origin. His wide black eyes stared at Yuu.  

"S-sorry!"  
"Amir!"  
"Hai!"  
"How rude to our guests!"  
"Slacking at the crucial moment!"  
"Were you grabbing some other girl?"  

Amir seemed to be his name. Rinne scolded sharply. Yuu hadn't noticed earlier, but vice-presidents Li Weihui and Omori Norika stood with folded arms by the far left wall.  

Yuu felt disturbed by the scene. Women never scolded men so harshly here. Moreover, this boy looked only 12-13 - possibly elementary age. But Amir quickly pulled away and bowed repeatedly to everyone in the room.  

"S-sorry! I'll start immediately!"  
"Stop talking and get moving!"  
"Wait! However he is, this is too cruel!"  
"Hah?"  

Unaware of the circumstances, Yuu simply found it wrong for multiple older girls to gang up on a child, regardless of gender. Tears welling, Amir hunched to leave, but Yuu stepped forward protectively, hand on his shoulder.  

"Yuu-kun..."  

Sayaka and the others looked worried. Rinne's group appeared genuinely surprised, eyes wide or expressions puzzled.  

"W-well, since his parents sought asylum in Japan, I've been caring for him and having him help our student council."  
"Even so, he's still a child, right? He might make mistakes - wouldn't gentle guidance be better?"  
"Hah..."  

To Yuu, high schoolers were practically adults, and he objected to their treatment of childlike Amir regardless of gender. Sayaka and the others moved to shield Amir too, creating a standoff. Rinne briefly seemed irritated but soon sighed resignedly.  

"Fuu. Very well. I believed strictness was essential for disciplining children this age, but perhaps kindness is also needed sometimes.  
Now Amir, prepare tea for our guests."  
"Y-yes!  
Um... thank you!"  
"Don't mention it."  

Yuu smiled at Amir's deep bow. But he remembered - they'd planned to make this quick.  

"Um, about today..."  
"Come this way..."  
"Mitsuse-san!"  

Yuu called to Rinne's back as she headed toward an inner door without listening. She turned with a slightly displeased expression.  

"As I said before, let's use first names."  
"Ah... regardless, thank you for the invitation, but we just wanted to greet you and leave."  
"Thanks to the wonderful morning concert, our boys are eager for the afternoon tour.  
I'd rather see that."  
"Couldn't the quiz championship debrief wait?"  

Sayaka and Riko backed Yuu up. Hearing this, Rinne's expression vanished like a Noh mask.  

"Oh deaar. Amir is working hard preparing tea after you helped him. Wouldn't he be disappointed if you left without drinking it?"  
"Uh..."  

Norika's words beside Rinne flustered Yuu. Her smiling face targeted their weak spot. Yuu exchanged looks with Sayaka and the others.  

"Hmm... Leaving without drinking might be rude."  
"When you put it that way..."  
"Well, I am thirsty..."  
"Then why not, since we're here?"  

Nodding in agreement, they decided to have just one cup of tea and followed Rinne's group into the inner room.  


### Chapter Translation Notes
- Translated "カフェテリア" as "cafeteria" per Fixed Special Terms definition
- Preserved Japanese honorifics (-san, -kun) throughout dialogue
- Maintained original name order (Hirose Yuu, Komatsu Sayaka)
- Used double quotes ""..."" for simultaneous greetings ("""Hello!""")
- Translated "お手伝い" as "helper" to convey Amir's role without infantilizing
- Rendered internal thoughts in italics *(Just greet them...)*
- Kept sound effects phonetic ("Feh!" for ふぇっ)
- Translated "躾ける" as "disciplining" to maintain nuance of harsh upbringing
- Used "dear me" for "あらぁん" to convey passive-aggressive tone
- Maintained explicit anatomical description of Rinne's exposed thighs