## 151. At Saiei Academy ④ ~Heat Up~

### Author's Preface

Over the next few chapters, there will be expressions of violence, humiliation, and SM.

---

"Well, since it's about time, I wonder if Yuu-san would become the property of our student council?"

Rinne stated this calmly as if demanding rightful compensation.  
The room instantly fell silent.  
Since the windows were tightly shut, no outside sounds could be heard.  
The only sound reaching their ears was the rather loud operation of the air conditioning.  
*Kacha*—Sayaka placed her cup on the saucer.

"We've had our tea... Yuu-kun, shall we go now?"  
"Ah, yeah."  
Yuu nodded at Sayaka, who spoke somewhat languidly.  
Yuu drained the remaining tea in his cup.  
The last sip had an intense bitterness, as if swallowing high-proof liquor, making his throat burn hot and causing him to grimace.  
He briefly wondered if his portion had been stronger but decided not to dwell on it.  
Just as Riko and Emi emptied their cups and placed them on saucers, Rinne panicked.

"J-just joking! Only a light joke.  
Ah, please wait! I'll have a refill served immediately. Come now, there's a saying: 'Drink one cup of tea and meet a monk.' Please have just a little second cup."  
"Isn't that a Japanese tea proverb?"  
"My grandmother often said it."  
"I've definitely heard it at our place too..."

Yuu hadn't heard it before, but Rinne and Sayaka seemed to oddly agree on this point.  
Reluctantly agreeing to a tea refill, Amir was summoned.

---

"Originally, this room was designed for student council members and guests to relax.  
So I've heard that when first built, it had a natural interior inspired by Saitama's nature.  
But that was five student council generations ago.  
The student council president at the time came from an old aristocratic family with a tradition of studying in Europe, and being France-returned, she strongly preferred Western styles.  
Thus, with support from her family home, not just the interior but all furnishings were completely replaced..."

As the Sairei group grew quieter, Rinne's long-winded boasting about the student council continued.  

Around his second cup, Yuu began feeling feverish.  
Wondering if he had a fever, he touched his forehead, but it didn't seem like a cold.  
He wasn't coughing, nor did he feel chills.  
Somehow, it felt like his core was burning intensely.  
Unlike coffee, tea warms the body easily, but this was excessive.  
When entering the room, the AC had been so strong his exposed skin felt cold, but now he felt a blazing heat from within.

That alone would've been manageable, but he realized he was erect.  
Back in middle school, he'd sometimes get erections in cold classrooms without thinking of anything erotic.  
Similar to morning wood, it seemed related to urine retention, but this felt different.  
The heat Yuu felt from within seemed heavily tied to sexual desire.  
After all, he kept visually tracking Rinne's animated gestures and the swaying breasts of Norika, who giggled beside her.

*(I wanna fuck... What am I thinking?)*

Among all Saiei students he'd met, Rinne and Norika were especially alluring beauties with figures beyond typical high schoolers.  
Rinne's hair, long enough to reach her back, was a slightly reddish copper beige with fluffy waves starting midway, while the front sections had vertical rolls resembling a hairstyle popular among female college students and office ladies in his previous world.  
Norika, conversely, evoked the appearance of long-black-haired, one-length-bodycon-clad sisters who danced in bubble-era discos.  
Moreover, both seemed to have altered their uniforms, cinching the waist for a tighter fit that emphasized their breasts.  
Unlike Sairei girls who felt ashamed of large breasts, they proudly thrust their chests forward, suggesting different values.  
Had he met them unaware of the circumstances, Yuu would've been captivated too.  
But having heard negative rumors about the Saiei student council from Sayaka and Riko, he'd tried to restrain himself...

Yuu looked down, gripping his thighs tightly to suppress the surging heat within. Suddenly, a *gachan* sound startled him.  
Sayaka, who'd been strangely silent, had leaned forward and knocked over her cup.  
With about half its contents remaining, a red stain spread across the white tablecloth.

"Sayaka! What... huh? R-Riko? Emi too?!"

Beside Sayaka, Riko slumped forward, her head bobbing *kakun, kakun*, similarly knocking over her cup onto the table.  
Almost simultaneously, Emi also collapsed face-down.

Yuu hastily stood, shaking not just Sayaka but Riko and Emi too—but there was no sign of waking.  
If only Sayaka, who'd been unwell earlier, had collapsed, it might make sense, but all three falling asleep simultaneously was suspicious.  
Yet touching their soft bodies only amplified Yuu's surging lust, unsettling him further.

*(Shit! What's wrong with me?)*

His eyes wandered to Sayaka's smooth, flowing black hair and beautiful profile with closed eyes, Riko's nape and slender back, Emi's flaxen twin-tail tufts and small ears—the very parts he always admired. His heartbeat quickened, and his erection persisted.

"Wh-why?"  

Hearing Rinne's voice, Yuu looked at them.  
Though they appeared flustered like him, something felt off.  
Strangely ignoring the three collapsed girls, they stared at Yuu while whispering among themselves.  
He caught phrases like "Why only one?" and "Because he's male?"  
As if they'd expected the three to fall asleep.

"W-well then, let's proceed."  
Before Yuu could ask "Proceed with what?", Rinne rang the desk bell.  
*Chirin chirin*—within ten seconds of the sound, two Saiei-uniformed students entered from the adjacent office.  
Slightly taller and more robust than Yuu, they had athletic builds typical of sports club members.

One positioned herself between Rinne and Norika as Norika whispered something while looking at Yuu.  
Smirking, the two circled the table and slowly approached Yuu.

"Fuhihi. Big bro, quit resisting and behave. We don't wanna hurt ya."  
"Yeah yeah. Your buddies are fast asleep. Know when to quit."

Yuu noticed ropes and towels in their hands.  
Finally, he understood—they meant to restrain him.  
Had Sayaka, a martial arts master including kendo, been awake, they'd have been in trouble.  
But all three were unconscious.  
He suspected a hypnotic in the tea.  
Yet Yuu felt anything but sleepy—he was excruciatingly aroused.

Yuu didn't dislike sex itself.  
In fact, his erection wouldn't subside, and he desperately wanted to thrust his cock into every pussy in the room.  
But a cool-headed part of him protested against letting them have their way.

The two approached Yuu from left and right.  
He seized the wrist of the smirking girl on the left as she carelessly reached out.  
"Huh?"  
Swiftly twisting her right arm, he took her back.  
"Gyah! Gyaaaaaah! Agh..."  
He pressed her twisted right arm against her back while locking his left arm around her throat in a chokehold, bending her body backward. The self-defense techniques learned from Kanako and Touko proved unexpectedly useful.  
Moreover, his groin pressed against her buttocks—his rock-hard erection jammed right into her ass crack. Yuu deliberately thrust his hips upward against her ass.

"Gah! Gahi... wh-what... heh!? O-hooooh!"  

She writhed from the pain of her twisted arm and choking, further confused by the unexpected sensation on her ass. Clearly unprepared for resistance, Rinne's group froze in shock. The other girl halted her approach.

Seizing the moment, Yuu backed toward the wall to protect his rear, maintaining his hold.  
Shifting his right hand to join his left, he applied a full naked choke, squeezing the carotid artery.  
Her hair's scent filled his nostrils, further fueling his frenzy as he ground his cock against her asshole.  
"Gah... gr... vah... hyu..."  
Simultaneously experiencing heaven and hell, her face turned from red to purple.  
Her left hand feebly struggled to break free before she nearly collapsed. Yuu shoved her forward.

"Wha!?"  
The other girl, confused by her partner's sudden shove, caught her instead of dodging—a fatal mistake. Though physically strong, she seemed inexperienced in brawling.  
The unconscious partner's weight pulled her off-balance, leaving her unable to react as Yuu closed in.  
Aiming for her lowered chin, he pivoted from the hips and delivered a right hook—a boxing "chin shot" to the vulnerable point.  
"Hoge..."

Unlike during gloved practice, Yuu's bare knuckles screamed in pain, but adrenaline let him ignore it as he prepared to follow up.  
Stepping on the fallen girl, he grabbed the front girl's collar and kneed her abdomen.  
"Gofu..."  
With her brain rattled and abdomen struck, she collapsed atop her partner.

Normally, Yuu hesitated to use violence against women.  
But anger over Sayaka's drugging, his own aroused state, and regular sparring with Kanako and Touko made his body move instinctively.

Seeing both girls unconscious, Yuu turned to Rinne's group.  
"I misjudged you, Mitsuse-san. To resort to such cowardly tricks.  
Drugging someone without consent is criminal, no?"  
Rinne and Norika had stood up in shock at Yuu's moves but now sat back down with composed expressions, having resigned themselves. Wei Hui remained calm from the start, while the treasurer and secretary looked dumbfounded.

Clearing her throat, Rinne tilted her head as if completely baffled.  
"Now, I haven't the faintest idea what you're talking about.  
Were Sayaka-san and the others so exhausted they fell asleep mid-conversation?"  
"Wha..."

Yuu faltered but roughly guessed the truth.  
Amir had drugged the tea, but he was likely just following orders.  
Rinne, Norika, and Wei Hui probably hadn't directly instructed him—someone else had interpreted their intentions.  
Given their composure, no evidence likely connected Amir to these three.  
Unable to press Rinne, they stared each other down until Wei Hui broke the silence.

"Your mother works at a newspaper company, right?"  
"Huh? What of it?"  
"I heard that company suddenly lost sponsors about two months ago—quite troublesome."  
"My, how dreadful! I believe newspaper companies rely heavily on sponsor support for income. As someone who'll eventually shoulder a major corporation, I'm curious about the reason."  
"Hmm. Not sure, but something about an employee's family member being the cause?"

The stilted conversation struck Yuu.  
Martina never mentioned it, likely to avoid worrying him, but he'd heard through Elena—multiple companies had abruptly withdrawn sponsorship simultaneously.  
And here was the student council president, heiress to one of Japan's top corporate conglomerates.  
With their pyramid of subsidiaries stretching endlessly, she could mobilize affiliated companies with a single order.

"No way?"

The word escaped Yuu's lips.  
Would they really use such roundabout methods for him alone two months prior?  
But in this world, women fiercely competed to possess rare males, readily breaking norms and rules.  
He'd personally witnessed ordinary women desperately chase after unguarded boys on streets.  
Even now, he'd likely been drugged.  
Male-related crimes notoriously dominated Japan's otherwise safe society.  
So then...?

Bitter memories resurfaced—his first company job where clients exploited their corporate power.  
He recalled Martina, now an executive, struggling with sudden crises, working late nightly.  
Rage surged at causing his beloved mother unnecessary hardship, mingling with his burning lust until he nearly snapped.

*(Wait. Can't get emotional now. Stay cool.)*  
Realizing they'd laid meticulous traps from the start, Yuu defiantly straightened his back. He wouldn't cower just because women surrounded him with leverage.  
They'd played their trump card, but he refused to surrender control easily.  
After a deep breath, he deliberately raised his lips in a daring smirk.

"What's this? You wanted to fuck me that badly? You filthy sluts."

Not just Rinne and Norika but even Wei Hui reacted visibly.  
In this world, calling women "sluts" wasn't insulting, but Yuu's provocative defiance instead of submission astonished them.

*Gata gata*—all three stood.  
"Interesting," said Wei Hui.  
"Love that look. Wonder how long it'll last," said Norika.  
They wore identical predator-smiles before prey.

Silently approaching, Rinne lifted Yuu's chin with her fingertips.  
"How much fun will you give us?"  
*Pashi!* Yuu slapped her hand away, bringing his face close enough for breath to mingle as he gripped her well-shaped chin and whispered like kissing.  
"So, where do we start?"

Blushing briefly, Rinne stepped back and turned.  
"This way."

Surrounded by five women, Yuu boarded the elevator.  
Above the door, floor indicators showed 1-3 and B1—clearly their destination.  
The panel stated capacity: 8 people, but six packed them body-to-body.  
The elevator filled with feminine scents, including perfume.  
For Yuu, barely restraining his lust, it was torture. His breathing naturally grew ragged.

*(Fuck fuck fuck... this ass... fuck fuck fuck fuck fuck fuck fuck fuck fuck fuck fuck... guh... not yet)*  
Precum flooded his underwear around his persistent erection, feeling disgustingly wet.  
He nearly reached for Rinne and Wei Hui before him but held back.  
Just then, Norika beside him touched his crotch.

"...Ugh!"  
"Eh!? Wha..."  
"No touching yet!"  
"But this kid's..."  
"After we get off!"  
"...Y-yes."

Norika, having touched his groin, noticed his severely contorted mouth and started to speak but fell silent at Rinne's sharp command.  
The short ride from 3F to B1 was a mercy, but Yuu had reached his limit.  
Exiting the elevator with Rinne leading, Yuu remained encircled—Norika and Wei Hui flanking him, the secretary and treasurer behind.

Immediately visible was an oversized mat center-left, large enough for 10+ people. To its right stood a pipe-fitted bed with restraints like in a nurse's office.  
Shelves and baskets along the walls overflowed with unmistakable BDSM gear, but Yuu didn't register them.

In a corner, two health committee members waited at a table.  
"Huh?"  
"That boy..."  
"Minor mishap. But the plan's unchanged."  
"Understood."  
"Heh. Can't wait."

As Norika and the committee members spoke, Wei Hui headed toward the restraint bed, loosening the encirclement.  
Yuu suddenly shoved Rinne forward.  
"Kyaah! Wh-what?"  
Emitting a cute shriek, Rinne nearly fell but caught herself and turned.  
Yuu marched forward, grabbing her shoulders and shoving her toward the giant mat.

"Hyah!"  
Her skirt flipped up as she landed butt-first, revealing glossy white silk panties to Yuu.  
He could hold back no longer.  
Fumbling frantically, he unbuttoned his jeans, yanked down the zipper, and stripped off his pants while snarling:

"Spread 'em already, you fucking bitch!"

Before the stunned Rinne could process anything, Yuu's groin was exposed.  
His cock stood rigidly skyward, veins bulging *piki piki*, dripping transparent fluid—a furious erection amplified beyond its usual ferocity by Yuu's extreme arousal.  
Though sexually experienced, Rinne had never seen such a thick, long monstrosity.  
A true encounter with the unknown.

---

### Author's Afterword

As stated in the story, administering sleeping agents without consent to induce unconsciousness constitutes injury under Japanese law.  
It applies regardless of subsequent physical contact—"physiological function impairment (deterioration of health)" includes causing unconsciousness or psychological harm, not just external injuries.  

As Yuu suspected, no evidence visibly links Amir to Rinne's group, but contextually it's clearly malicious. Police investigation could pursue it, but pressure would likely bury the case first.  

One more notice:  
Due to a December 20th (Friday) deadline, I'll be extremely busy this week and likely can't update on Wednesday. Response to feedback will also be delayed.  
We're approaching the climax—thank you for your patience.

### Chapter Translation Notes
- Translated "催眠導入剤" as "sleeping agent" for medical accuracy
- Rendered "尻の穴" as "asshole" per explicit anatomical terminology requirement
- Preserved Japanese honorifics (-san) and name order (e.g., Mitsuse Rinne)
- Transliterated sound effects: "かちゃ→kacha", "チリンチリン→chirin chirin"
- Translated sexual terms explicitly: "チンポ→cock", "マンコ→pussy"
- Maintained internal monologue formatting: *(I wanna fuck... what am I thinking?)*
- Used ""..."" formatting for simultaneous speech by multiple characters