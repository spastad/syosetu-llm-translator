## 152. At Saiei Academy ⑤ ~Drunken Beast~

### Author's Preface

Sorry to keep you waiting.

---

The Komatsu and Mitsuse families—founders of major corporations counted among Japan's top three automakers—still maintain their influence with family members at the helm.

These two houses differed not only in their origins and history but also in their fundamental views toward men.

In the 1930s, a technician named Komatsu Hanako founded Komatsu Technical Research Institute (later KOMATSU), aspiring to develop motorcycles for the masses. Having no romantic experience with men until her mid-twenties, she mustered courage to visit a brothel where she became enamored with a male prostitute her age. After persistently courting him for over a year, her company's motorcycles became a explosive success, allowing her to buy his freedom. 

Ultimately, the male prostitute became husband to Hanako and her two sisters. Their marital relationships were harmonious and blessed with children. Due to this history, the Komatsu family tradition emphasizes respect for men and marriage through courtship. Notably, Hanako gave her only son one character from her husband's name, while daughters like the eldest Reika received a character from her own name. Since then, "hana" (華) has been passed down through generations of direct descendants.

Meanwhile, the Mitsuse family descended from nobility (modern equivalent: counts) and served as aristocratic legislators for over half a century after the Rissei Restoration. Among distinguished families, the Mitsuses particularly emphasized female dominance—a tradition continuing to this day. Men were treated less as husbands and more as breeding tools, with women seeking sexual pleasure among themselves. Even toward male relatives, they withheld familial affection—a stance evident in their support for the growing Male Inclusion Movement and Dankyo Party.

Rinne, born into this household, developed unexpected longing for men after secretly reading popular manga and novels during elementary school. At 13, a housemaid broke her hymen for "sexual initiation," but Rinne held greater expectations for her first real experience.

On her 14th birthday, she met a 15-year-old junior idol at her party—a boy so handsome he rivaled male celebrities. Though Rinne believed they connected naturally, her grandmother had actually arranged this through a talent agency. After several dates, they went to a hotel. Rinne voraciously kissed his skin, leaving red marks on his neck and chest. Her rough handling of his smaller-than-average penis caused him visible pain, yet he endured silently per instructions. When Rinne mounted his erection, she felt little pain due to excitement and his size. But within a minute, he groaned "Ah, cumming!" and went limp, semen spurting onto his own abdomen.

"Huh...?"  
"Haah... haah... I-I came, so... we're done."

Shoved aside naked while still aroused, Rinne stared dumbfounded as the boy dressed and left. This became her first heartbreak—and awakening from romantic fantasies. Subsequent birthday encounters with beautiful boys arranged by her family all ended after one night: some ejaculated before penetration; others finished too quickly. Prioritizing young, handsome partners meant inexperienced boys with small penises—perhaps explaining her dissatisfaction.

By high school, Rinne concluded: "No man can satisfy me. Our family teachings were right—men are mere tools for breeding. Females, not weak males, form society's foundation." Following parental advice, she entered Saiei Academy's management track—an all-girls school. Though nepotism helped, her own brilliance secured a student council position by her first year. Elected president in her second autumn, she entered her third year as leader.

Then she met Yuu. His resemblance to her first love sparked immediate desire—initially like coveting jewelry or a pet. But speaking with him revealed something unprecedented: he voiced opinions confidently among crowds of women, whether facing Sairei's student council or Saiei's eccentric members. Despite being two years younger, he possessed mature charisma. Days until their quiz championship meeting felt endless. When Rinne clung to his hand while leaving, Yuu gently patted her head saying "Let's meet again," making her heart flutter despite three years of emotional numbness. She resolved to make him hers—by any means necessary. She wanted him naked, moaning beneath her, drained of semen.

She knew Komatsu Sayaka—rival heiress and Yuu's lover—would interfere if forced. But stealing Yuu would be triumphant. Once lured to Saiei's student council (Home), anything would be possible. On August 3rd, like summer moths to flame, Yuu's group arrived.

◇ ◆ ◇ ◆ ◇ ◆

"Kyaaaaaaaaaaah!"

Rinne's high-pitched scream echoed in shock and confusion, but Yuu ignored it. He ripped off her obstructive panties and forced her thighs apart. Her vulva spread open, revealing her vaginal entrance—clenched tightly from surprise.

"Wh-wha... wha-what are you—?"  
"What else? Sex."  
"Huh?"

As Yuu grinned, Rinne gaped speechless. Sex meant women mounting men like fish, stimulating them to erection before penetration—with men passive. Rinne had been taught and practiced this. As an heiress and student council president, no one would dare assault her. This violation was unimaginable.

"Hoh. Pretty pussy. Barely used? First taste."

He buried his face between her legs.

*Relorelorelio chupachupa jurujuru chupuu! Chuu... zz, zz, reloreloo... chupachupa juchu! Chuu... peropero reloo jupaa...*

His tongue licked her entire labia, teased her exposed clitoris, then plunged into her vaginal opening—alternating licking and sucking. While his left arm pinned her thigh, his right hand groped her breast. Craving direct contact, Yuu shoved her one-piece uniform up and tore through her frilly full-cup bra. He kneaded her exposed breasts until they deformed, then pinched her nipples. Though seemingly brutal, his precise targeting of erogenous zones showed experience.

"Fwaaaaaah! Wh-what is this?! Ah! Ah! Ah!... St-stop! Stoooop!"

For Rinne, this was her first rough cunnilingus. Last year, she'd performed facesitting on a younger boy who reluctantly licked her—an underwhelming memory. Despite Yuu's violence, her body responded: refusal mixed with moans as her vagina dripped arousal.

"Hey! What the hell're you doing?!"  
"P-President... are you okay?!"

Finally rebooting, the health committee members spoke. Wei Hui remained frozen, but Norika approached grinning—seemingly enjoying the spectacle. When Yuu turned, everyone froze jaw-dropped at his exposed erection.

"What... is that...?"  
"U-unbelievable..."

Even Wei Hui and Norika were stunned by its unprecedented size.

"Huh? Don't interrupt. I'm giving the president the sex she wanted." Yuu proudly shook his erect penis. "I'll fuck all of you after this."

He refocused on Rinne. His aggressive licking had sufficiently lubricated her.

"Inserting now."  
"W-wait! Th-that's... impossible!"  
"What're you saying now? I can't hold back anymore."  
"N-no!"

Though resembling rape, Yuu didn't care—they'd broken laws first. His mind only craved thrusting into that pussy and ejaculating violently.

Yuu spread Rinne's legs wide and positioned his hips. Her weak pushing couldn't stop him. Overwhelmed by Yuu's animalistic assault and her own confusing arousal, Rinne barely resisted—her worldview of female dominance shattering.

*Thrust!*  
"Gyaaaaaah!"

Only half-inserted, Rinne's face contorted at the pain of forced entry. Normally Yuu would comfort her, but now her pained expression fueled his sadism. He pushed deeper.

*Schlup! Schlup!*  
His thick cock forced its way in, ramming her deepest depths—untouched until now.  
"Nyahn!"

With a catlike yelp, Rinne's jaw jerked up.  
"Ooh!" Yuu groaned involuntarily.

*(Damn... this feels amazing)*  
Her vaginal walls gripped him entirely with intricate folds that seemed to writhe. Intense pleasure threatened to shatter his hips. Though Rinne seemed experienced, men were scarce—even his gorgeous, sex-loving half-sister Saira had only three partners. Rinne might be inexperienced. Her tightness suggested a "treasure box." Her past partners—teenagers with small penises—couldn't penetrate fully and lasted under a minute for good reason.

"Tch... squeezing so tight..."  
"Ah... ahi... don't move..."

He couldn't obey her plea. Less than a minute after insertion, he already neared climax. Yuu roughly kneaded her breast with his right hand. Buried to the hilt, he ground his hips in circles.

"Oh... hih!... S-stirred inside! Ah! Ah! Ah! Wh-what is... this sensation?! Hyah!"

Rinne clawed the mat, shaking her head frantically. Though the room was cool, sweat beaded on her forehead. Yuu alternated shallow thrusts with deep lunges. Each impact made her throw back her head or shake wildly—disheveling her carefully styled hair. Pink cheeks framed by loose rolls of hair created an erotic spectacle.

"Haah... haah... finishing move..."  
At his limit. Rinne's vaginal walls milked him relentlessly. Yuu hooked his arms under her knees, lifting her legs while pressing forward—mounting her in a breeding press.

"Huh? Wha— Kyauuuun!"

To onlookers, their joined genitals were fully visible. With each thrust, semen-mixed fluids sprayed from her stretched vulva.

"Amazing... never seen this..."  
"Hah... hah... unbelievable... but watching... ah, turns me on..."

All eyes remained glued. Norika rubbed her thighs; others touched themselves.

Under six women's gazes, Yuu's thrusts accelerated. Climax neared. Rinne's moans grew increasingly fragmented.

"Ah! Ah! Oh! Oh! Ih! Ihiiin! Cummingcummingcummingguuuuuuh! Aahee... came... came... aahn! Aahn! No... no... shtop... shtop pleash..."  
"Guh! Gah! C-cumming!"  
"Hya... yah! Oh! Ohohn! Belly... full! Full ish... ihiiiiii! Belly... strange... can't... can't take moreeeeeee!"

Rinne's mind blanked as explosive ejaculation flooded her womb. Her cries became wordless moans. Thick semen pulsed into her with each *dokudokudoku*. Trembling, she sobbed through the injections.

"Fuu... felt good. But not done."  
"Huh? N-no... Hyah! Hih... hiin!"

Yuu rarely needed recovery time—especially now. He resumed thrusting immediately after ejaculating. *Gupo! Gupo! Dochyun! Dochyun! Juchuu!*  
His relentless hips churned the pooled semen. White fluid splattered from their joining with lewd sounds.

"Haah... haah... wanted sex with me, right? Feels good? Got the cock you wished for..."  
"Hah... hah... cock... feelsh good... feelsh... au au... cumming again... aahn! No... shtop! Oh! Oh! Oh! Ohoh! Gooh! Ohhhhhh... guaaah! Iiiiiiiiiiiiiiiin! ...Ah... ah... came! Aahn! More... cumming... oh! Oh! Oh! Ohoh! Shgo! Ohhhhh... uwaaaah! Iiiiiiiiiiiiiiiin! ...Aha... ahaa... came! Aau! Already... can't... take more... oh! Oh! Oh! Ahih! Hih... hih... yaaaaah... forgive... can't... anymore..."

"Quit whining! Your lower mouth seems quite happy. More... here... savor it!"  
"N-no... aau... aa... aaaah! Cum... cumming... oh! Oh! Ahih! Ih! Ih! Hik! Yah... no more... can't... no... not... nyet... fool... ish... aheee..."

After clinging desperately during the first ejaculation, Rinne now lay limp—arms fallen, drooling, moaning incoherently as Yuu ravaged her. Driven by burning lust, he continued violent thrusts to inject more semen.

---

### Author's Afterword

About the subtitle:  
Inspired by "Beast in the Shadows" (陰獣)—both Edogawa Ranpo's masterpiece and the early song by band The Human Chair (itself named after Ranpo's work). Refers to becoming beastly after "drinking" (the drugged tea).  
"Lust Beast" (淫獣) was considered but avoided to prevent associations with tentacle monsters or magical girl mascots.

### Chapter Translation Notes
- Translated "飲獣" as "Drunken Beast" to convey intoxication + animalistic transformation
- Preserved explicit anatomical terms ("clitoris," "vagina," "semen") per style rules
- Transliterated sound effects (e.g., "Relorelorelio chupachupa jurujuru")
- Maintained Japanese honorifics ("-san" omitted in English per original text absence)
- Rendered Rinne's distorted speech during climax phonetically ("shtop," "ish")
- Kept author's literary reference to Edogawa Ranpo in afterword
- Used passive voice in assault descriptions to reflect non-consensual context