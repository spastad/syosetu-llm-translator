## 153. At Saiei Academy ⑥ ~Endless Sprint~

### Author's Preface

In addition to beast mode, demon mode is also activated.

---

After finishing his second ejaculation, Yuu slowly pulled out his cock from Rinne's pussy as if reluctant to leave her talented vagina.

Thick semen dripped from the tip, coating her soaked pubic delta in white. From the gaping vaginal opening came a wet *plop* sound as air escaped, followed immediately by *glug glug* sounds of semen overflowing from her womb. The viscous, cloudy liquid didn't immediately soak into the mat but formed thick, gooey clumps.

Even after Yuu moved away, Rinne's limp legs remained splayed open like a frog's, looking as if she'd given birth to white slime.

"Hmm?"

Yuu had noticed her lack of response midway but ignored it as his climax approached, putting in a final sprint. Peering at Rinne's condition, he saw she'd rolled her eyes back and lost consciousness. Her hair was wildly disheveled, her uniform mostly removed leaving her half-naked, and her crotch dripped with cloudy fluids. Her frog-like posture was a disgraceful sight utterly unbefitting a prestigious young lady.

"Perfect timing. Let's try this."

Yuu picked up Rinne's limp arms and placed two fingers in a V-sign beside each side of her face—not an ahegao face but a "departure face double peace" pose. Satisfied with Rinne's obscene display, Yuu turned around. His cock still stood erect, glistening with semen and vaginal fluids. He felt he'd only released about 10% of his surging energy and fully intended to rape all seven women present.

"Next is meee!"

Norika approached Yuu with drawn-out syllables, having removed not just her uniform but everything except her black thigh-high socks and loafers.

*(Was she waiting naked!?)*

She walked with slightly bent knees, wiggling her hips, making her voluminous breasts jiggle *jiggle jiggle*. While Rinne's breasts rivaled Sayaka's in size, Norika's seemed a full rank larger. Yet she wasn't chubby, showing a beautifully defined waist. Her large buttocks were already known—or rather, deliberately shown off through behaviors like flipping her skirt to display her T-back underwear, which would constitute sexual harassment against ordinary men in this world. Yuu never minded since he enjoyed the view.

"Even after cumming twice, your cock's still rock hard! Amaaaazing! And it's the biggest I've ever seen! I wanna taste it now!"

Norika's face glowed with joyful anticipation. Transparent fluid already dripped down her inner thighs. Yuu smiled as Saiei's foremost nymphomaniac approached.

Yuu stood slightly away from where Rinne lay. As Norika reached directly in front of him, extending her arms to embrace and push him down, Yuu grabbed her right wrist from the outside and pulled sideways while pushing her back with his right hand.

"Huh?"

He feigned catching her only to slip past, sending her diving onto the large mat. Norika nearly face-planted but couldn't rise as Yuu pressed her back down, forcing her into a crawling position.

"W-what are you—?"  
"Hey, lift your ass."

Initially, Yuu intended to rape her like Rinne. But seeing Norika approach naked and eager, he changed his mind. No matter how arousing her body was, fucking her as desired would be a reward. Though his lust remained unbearable, he retained enough clarity to prioritize punishing the student council executives.

Kneeling beside the crawling Norika, Yuu pressed down on her back with his left hand and raised his right high. Then he swung down hard on her buttocks.

*WHACK!*  
"Kyeeek!"

Her butt flesh trembled *wobble* as her palm struck, drawing a scream. A bright red handprint like a maple leaf appeared on her white buttock. Ignoring Norika's teary eyes, Yuu continued spanking her.

*WHACK! WHACK! WHACK!*  
"No! Kyu... gyaaah!"  
"Ho ho. Plenty of meat here—makes a nice sound."

After five or six spanks, both buttocks flushed crimson. Unaccustomed to such treatment, Norika's face crumpled as tears streamed down. Her long straight hair stuck to her face, makeup smudged. Seeing the always-composed Norika in this state satisfied Yuu immensely. Meanwhile, the other five watching girls stared dumbfounded—all except the unconscious Rinne.

"This isn't over yet."  
"P-please... stop... gyaaah!"

Though Yuu had never hit women before or after his rebirth, this was special. Tormenting a slut like Norika stimulated his sadism, heightening his excitement.

After ten more spanks, his hand grew tired and he paused. Norika could no longer support herself, face pressed to the mat, moaning in pain and begging "Please forgive me" or "I'm sorry."

Yuu then moved to the next phase. Spotting a discarded white towel, he picked it up and unfolded it. Grabbing Norika's arms, he crossed them behind her back and bound her wrists.

"Wh-what now...?"  
"Nothing much. After the whip comes the candy."  
"Your cock?"  
"Nah, that's still on hold."

Yuu stepped away from Norika. Turning, he saw the treasurer and secretary who'd hidden behind tables and chairs shriek "Eeek!" and flee to a corner. Shrugging at their fear, Yuu headed toward Ro Chie instead. She flinched but stood her ground, glaring.

"I-I won't yield no matter what you do! I won't lose to a man!"  
"That's a defeat flag right there."  
"Huh?"  
"Oh, perfect timing."

Yuu looked past her at the wall where handcuffs, ropes, and whips hung. Earlier, he'd noticed her hiding something behind her back—likely waiting to strike when he was distracted. Crossing about two meters in front of her, Yuu saw her sigh in relief out of the corner of his eye. Instantly, he kicked off the floor and tackled her.

"Guh!"

Caught off guard, Ro Chie made a strange noise as she staggered back against a pipe bed. With her winded from the impact, Yuu straddled her stomach and swiftly clamped her wrists into restraints connected to the bed—steel rings like bicycle locks that couldn't be removed without both hands. Once restrained, Yuu examined the object she'd dropped: silver handcuffs resembling police-issue stainless steel, not plastic toys.

"Stop! Let go! Damn you!"

Ignoring her shouts, Yuu repositioned himself. When she tried to kick with her freed legs, he barely caught her bare feet and twisted her little toes as taught.

"Gyaaah!"  
"I don't want to hurt you too much. Behave, okay?"  
"Tch..."

After securing her legs, Yuu declared, "You're next. Wait a bit longer." He then checked the others. The treasurer and secretary cowered in a corner—fine to ignore for now. But the two originally in the room were slowly edging toward the exit.

"Huh? Where you going, ladies?"  
"Ah... well..."  
"Um... we suddenly remembered something urgent."  
"Why? Don't want to have sex with me?"  
"N-no, not at all!"

As they shook their heads frantically, Yuu approached smiling. The left girl had long black hair, sharp eyes, and a stern face—about Yuu's height and slim. The right had shoulder-length light brown hair and droopy eyes, giving a gentle impression with a mole near her mouth that looked sensual. She stood 10cm shorter than Yuu with noticeably large breasts even through her uniform. Unbeknownst to Yuu, they were the chair and vice-chair of the health committee.

Spreading his arms, Yuu embraced them both.  
"Whoa!"  
"Eep!"

Though startled, both grinned. As health committee members, they were experienced among this world's high school girls and intensely interested in Yuu. Since taking their positions, they'd enjoyed restraining vulnerable boys, tormenting them, whipping them, and draining them dry—all within Norika's directives. But a boy like Yuu who dominated women and used violence was unprecedented. With no manual for this scenario and their leaders incapacitated, they'd tried to flee.

While enjoying their scent and bodies, Yuu clamped the handcuffs Ro Chie had hidden onto the left girl's wrist, then connected it to the right girl's.

"Huh?"

Confused, they panicked upon realizing they couldn't separate. Meanwhile, Yuu moved behind them and pushed.

"Wh-what are you planning?"

The black-haired girl demanded answers while the brown-haired one stammered incoherently. Without responding, Yuu kept pushing. Forced forward, they stumbled past the unconscious Rinne and the prone Norika with raised buttocks until Yuu shoved them onto an empty mat space.

"Kyaa!"

Ignoring their sprawled forms, Yuu eyed the nearby wall. "Oh, nice." A long pet leash with a leather collar hung from a hook. He'd already realized this wasn't just a sex room but a specialized space for drugging, restraining, raping, and training boys. Today, they'd experience it firsthand.

With only one collar, Yuu grabbed the black-haired girl's chin. "You bastard! Don't fuck with me!" She tried slapping him with her free hand, but Yuu caught her slender fingers, squeezing until they creaked.

"Gyaaah! I-it hurts!"  
"Not nice."

Forcing her chin up, he fastened the collar around her thin neck. Grabbing a worn towel from a nearby basket, he bound their free hands together behind their backs. Collared and restrained back-to-back, they hung their heads in shock at becoming captives. Yuu whispered cruelly in the chairwoman's ear, "I won't let you escape," before standing.

Norika called out nearby: "Hey~ ignoring me is mean! Give me that huge cock!" She stuck out her tongue like a dog in heat.

"Nah, not yet."  
"Aww... you're so mean!"

*(Still consistent in this situation—impressive.)*

Though exasperated, Yuu's eyes locked onto her jiggling breasts. Drawn closer, he scooped and kneaded the heavy mounds.

"Ahaahn!"

Norika's voluminous breasts were wonderfully soft—the kind that ruined men. Knowing he'd impale her if he continued, Yuu reluctantly pulled away toward Ro Chie's pipe bed—or rather, the shelf of sex toys nearby. He locked eyes with the cowering treasurer and secretary.

"Stay quiet over there. I don't want to hurt more girls."  
"Y-yes!"

Seeing them nod vigorously, Yuu examined the shelf. Gag balls, pink vibrators, strap-ons—even a black leather panty with a protruding fake penis. Vibrators came in various sizes and colors. Clearly used for both male targets and female-on-female play. Tossing selected items into a shopping basket, Yuu returned to Norika.

"Ahahn, finally! C'mon, hurry!"  
"Let's see."  
"Ahn!"

Ignoring Norika's hip-wiggling entreaties, Yuu approached from behind and suddenly thrust a finger into her vagina. Though easily accepted, her insides clenched tight. Despite her promiscuity, she wasn't loose. After several thrusts, love juice overflowed, coating his fingers and palm.

"Aahn! Don't tease! Fingers aren't enough!"  
"Right."

Withdrawing his finger, Yuu rummaged in the basket and selected a black, knobby vibrator—the largest available though still shorter than his cock, being designed for this world's average male.

Rubbing the vibrator tip around her vaginal opening to coat it in fluids, Norika gasped, "Hya!? What?" The air-conditioned room had chilled its surface. "Play with this." Yuu inserted it.

"Nyahn!? Nooo! Not that!"

Ignoring her protests, Yuu pushed it in. Half slid easily, then caught—likely from the knobs and thickness. "There! How's that?" "St-stop... ungh... ah! Don't stir it! Gyaahn!" As he thrust and twisted, it reached deep. He switched it on.

*Vvvvvvvvvvvvvvvvvvv!*

"No... I want your cock... not a vibrator... nnngh!"  
"But it feels good, right?"

Setting it to maximum intensity, the vibrations intensified as the tip began moving aggressively.

"Ah! N-no... gyaahn! Nnngh... kuuuu~"

Even Norika began moaning wordlessly. Grinning, Yuu murmured, "Might as well try this hole too." He held hard plastic anal beads—20cm long with gradually smaller balls. Having seen them in Saira's collection and read the instructions, this was his first time using them.

Knowing insertion would be difficult, he grabbed a plastic bottle of lube nearby. Her anus twitched from the vaginal vibrations. Pouring ample lube onto his hand, he rubbed it around and into her hole.

"Hyan! No... why there!?"

Ignoring her, Yuu continued lubing, inserting to the second knuckle with wet *schlop schlop* sounds. He coated the beads thoroughly.

"Ready? First time for this hole?"  
"Huh!? No... stop! Nooooooo... guohhh!"

He pushed the tip in carefully, but the lubed beads slid in surprisingly easily.

"Ooh, going in, going in."  
"N-no... different... gyaahn!"  
"Oh? Already broken in?"  
"Not... gyaaah! No! Ahohn!"

Without hesitation, Yuu inserted them fully. Then gripping the base ring, he pulled partially out and thrust repeatedly, making Norika gasp like an animal. Remembering Saira's note about intense pleasure during rapid removal, he warned, "Here goes," though she didn't hear. Curious, he yanked them out hard.

"Ooh... OHOOOOOOOOOOOOOOOOOOOOOOOOOOH!!!"

Norika arched her back, jaw straining, wailing loud enough to echo through the room. Everyone except Rinne stared. Between vibrator thrusts, streams of fluid *squirt squirt* sprayed out, soaking a wide area of the mat.

"Haha. Must've felt amazing." After she slumped, Yuu reinserted the beads—much smoother this time.

"Ohii... kufuun... more..."  
"Next time."

Feeling he'd rewarded her anyway, Yuu left Norika temporarily and headed for Ro Chie's pipe bed. Her face twisted as he approached.

"S-stop! Don't come closer!"  
"Yeah, that's the reaction I wanted."

Smiling delightedly, Yuu mounted Ro Chie with his erect cock leading the way.  


### Chapter Translation Notes
- Translated "逝き顔ダブルピース" as "departure face double peace" to convey the obscene V-sign pose
- Rendered sound effects literally: "ぬぽぉっと" → *plop*, "どぷどぷ" → *glug glug*, "ぷるんぷるん" → *jiggle jiggle*
- Preserved Japanese honorifics and name order (e.g., Omori Norika)
- Translated explicit anatomical/sexual terms directly: "チンポ" → "cock", "膣" → "vagina", "アナルビーズ" → "anal beads"
- Maintained internal monologue formatting: *(Was she waiting naked!?)*
- Used gender-neutral "they/them" for unnamed health committee members per ambiguity rule
- Kept specialized terms untranslated with explanations: "アヘ顔" → "ahegao face" (culturally established term)