## 154. At Saiei Academy ⑦ ~5 Seconds Before Rape in Earnest~

"Hey! Seriously stop! If you do this... it won't... gyah! Ugh... d-damn it! You... Japanese devils! Cock! Ugh... ah... what? I-it hurts! Kyiiiiiiii!"

Li Wei Hui screamed, even using unfamiliar words, but with both hands and feet restrained and her legs spread, she couldn't resist Yuu's actions.

Wei Hui had narrow eyes and couldn't be called beautiful. Though tall, she was skinny with almost no breasts. Despite this, Yuu had maintained his erection after ejaculating inside Rinne, enduring while tormenting the voluptuous Norika. His pent-up lust was now directed at Wei Hui.

Yuu pressed his hard cock against her plain white cotton panties from the crotch gap, too lazy to remove them. Her unprepared entrance was ill-equipped to receive Yuu's massive member, but he forced his way in anyway. This rape without proper foreplay was something Yuu would never normally do, but the student council's earlier conversation flashed through his mind as he pushed forward in anger.

"Ah, gah... it's going... inininiin... hiiiiiiin..."  
"Ugh... tight... was this your first time?"

Wei Hui had no capacity to answer Yuu's question, only moaning as sweat beaded across her body. The forced penetration made slurping sounds as the cock was swallowed. Though no hymen blood appeared, her vagina felt virginally tight. Yuu grabbed her desperately clenched thighs and forced them wider, beginning shallow thrusts while only partially inserted.

*Zubu, zubu* - he gradually pushed deeper. Her vaginal walls, forcibly stretched by the hard cock, secreted lubricant against her will and accepted the intrusion. Finally, after considerable time, he slammed against her cervix.

"Gyaah!"  
"Aghh!"

At that moment, an electric surge of pleasure ran through Yuu's body - so intense he nearly ejaculated.

"Ooh... feels good..."  
"Gwaa... ah... this... this male thing... inside me... gyah!? S-stop! Don't move... ah... aaaun!"  
"Can't exactly stop when you tell me not to."

Shifting from holding her thighs, Yuu leaned forward to fully cover her body. He groped her breasts through the sailor dress but felt almost no swell. Yet when he buried his face in her neck, he caught a floral scent mixed with sweat. Her vaginal walls clenched tightly as if expelling the intruder. Unlike Rinne or Norika, Wei Hui had shown little interest in Yuu, using masculine speech with a low voice and lacking feminine charm. Yuu might have found her unappealing normally, but now his male instincts drove him. He desperately wanted to pour his seed inside this woman.

Grabbing Wei Hui's shoulders, Yuu ground his hips, gouging her vaginal depths. As his cock acclimated, he transitioned to rhythmic thrusts - not to pleasure her, but to ejaculate inside her.

"Oh, ooh... damn, my hips are moving on their own..."  
"Bwaa... wai... ah! Ah! Aaun!"

At first, it felt like being impaled by a thick cone. But as Yuu kept thrusting, Wei Hui felt unfamiliar sensations spreading from her lower abdomen. Though she tried to stop him, restrained limbs couldn't halt Yuu's frantic hips. His movements visibly accelerated. The weight that initially felt uncomfortable now went unnoticed; each hot breath against her made her head feverish and mind blank.

"Kuh! Squeezing so tight... can't hold back, gonna cum!"  
"Hyaa! St...stop... so... rough... oh! Oh! Oh! M-my body... feels weird! Aah!"  
"Gonna cum inside you now!"  
"Don't... don't! No no... aah!"

In truth, Wei Hui had always been the aggressor with both women and men, having played with male genitals using hands or feet, but this was her first time allowing full penetration. She knew what an internal ejaculation meant.

Verbal protests were futile while restrained and pinned. Wei Hui shook her head in refusal, but Yuu only thrust harder. *Bashin, bashin, bashiiin!* Amidst the rhythmic slapping sounds, Yuu's cock reached its limit inside her.

"Hey! Li... listen! Gwaah! Don't... thrust so hard! Aaun! St...st...ah! Ah! Feels... weird! A...hiiiii... ah! Ah! Aaun! Really... I-I'm begging... if you're gonna cum... outside..."  
"Can't stop, cumming! Ugh..."  
"Ngah!?"

"Ooh... coming... I'm cumming..."  
"...! Hih! Aga... ah... ah... being filled... stop... faa... uuun..."

The moment she received his seed, Wei Hui felt unprecedented heat in her lower abdomen as her vision went white. Shocked speechless, more semen flooded her womb. *Pyuru pyuru* - her body convulsed involuntarily with each spurt. The pleasure that pierced her body when Yuu came inside far surpassed the earlier pain, leaving her only able to moan incoherently.

Yuu basked in the intense pleasure of ejaculation, but even after three releases, his lust showed no sign of abating. When he tried moving again like with Rinne, he noticed Wei Hui's expressionless face staring blankly upward, her eyes devoid of focus, mouth agape. An idea struck him - he'd use not just her lower mouth, but her upper one too. Having come this far, he intended to thoroughly violate her.

Her restrained hands limited mobility. Yuu sat beside her head, grabbed her unresponsive face, turned it sideways, pried her mouth open with his fingers, and shoved his still-erect cock inside.

"Mmph... oh!?"  
"Ooh... not bad inside the mouth. Don't bite, got it?"

Grabbing her disheveled hair, Yuu pushed his thick cock deep into her throat.

"Ohe... guh, muh... uuuuh"

He forced it deeper than normal fellatio would allow. Wei Hui couldn't even gag properly, only emitting short moans as tears streamed down her cheeks. Yuu began moving his hips for more pleasure.

"Hah, hah, hah..."  
"Muh... nn, nnh... rah! Gweh"

Wei Hui became little more than a mouth fleshlight, helpless against Yuu's actions. Though her teeth occasionally scraped him, Yuu converted even that into pleasure without stopping. Since she wasn't performing willingly, it felt less satisfying than vaginal sex. But violating her mouth gave him a strange thrill. The friction against her narrow throat felt unexpectedly good.

*Kucha kucha* - the sound of mixed saliva and pre-cum echoed inside. As ejaculation approached, Yuu held Wei Hui's head and jaw with both hands while thrusting.

"Kaha, better than expected. Oh... ooh... Wei Hui's mouth pussy feels great!"  
"Aaheee... guh... hih!"

Yuu couldn't gauge time accurately, but he thrust as frantically as he had earlier. Wei Hui's moans weakened until she barely moved. Just as Yuu freely continued the face-fucking, he abruptly felt the surge.

"Oh... nn! Cumming now! Drink it all!"  
"Oeh?"

Perhaps sensing the cock swelling before ejaculation, Wei Hui's half-closed eyes flew open. She seemed to plead with her eyes while mumbling, but Yuu didn't stop.

"Ah! Cumming! Kuha!"  
"Ya... rah!?"

*Dopu dopu dopu* - an unbelievable volume of semen for a fourth ejaculation flooded Wei Hui's mouth and throat. "Buhoh!" Having no experience with fellatio, she couldn't swallow, spraying cloudy fluid between her lips and the cock. But with Yuu still ejaculating and not pulling out, she was forced to swallow some.

"Nng, nng... ugo... geh"

Emotions likely affected perception - girls who genuinely adored Yuu reportedly found it delicious, but to Wei Hui, the raw smell and bitterness made her grimace through unstoppable tears. Yuu not only forced her to swallow but pulled out midway and pressed the tip against her face. Instantly, Wei Hui's tear-streaked face became coated in white fluid. Gasping for air, she couldn't form words. Her mouth opened and closed as she breathed, filled with the smell of semen. With the still-hot meat pressed against her face and unable to resist, Wei Hui was crushed by defeat.

Satisfied, Yuu looked at the motionless, semen-coated Wei Hui before walking to the area with round tables and chairs. He plopped down on a chair with a backrest - right beside the secretary and accountant.

"Ah... thirsty"  
Perhaps reacting to Yuu's muttering, the secretary girl opened a nearby mini-fridge, took out a can, and handed it to him.

"Huh? For me?"  
"Y-yes"  
"Thanks"

The shyly offered can had blue-and-white packaging resembling a sports drink. Though Yuu doubted it was tampered with, he *kashu*-ed open the pull-tab and handed it back to her. "You drink first"  
"Eh?"  
She tilted her head but obediently drank.

Seeing no suspicious reaction, Yuu took the partially drunk can and gulped it down vigorously. Over an hour had likely passed since arriving - his throat was drier than expected. The Pocari Sweat/Aquarius-like liquid seemed to soak into his body as he drank. He didn't finish the entire 350ml can.

The secretary girl stared blankly at Yuu's drinking form, especially his bobbing Adam's apple. Yuu offered her the half-finished can. "Want some?"  
"Ah... thank you. Ehehe"

She visibly brightened and drank the remainder.

"Phew. Hot, huh?"  
"Eh!?"  
"Nnguh!? Geho geho!"

Though bottomless, Yuu realized he was sweating in his white polo shirt and began removing it. The nearby pair reacted - the accountant girl looked enviously at the indirect kiss while the secretary girl choked mid-drink.

"Hey, you okay? Uh... secretary... Zusho Miyuki... right?"  
"Koh... hy-hy"  
"And you're the accountant... Aizawa Keiko, right?"  
"Yes"

They'd met Saiei student council members multiple times since first encountering them at Sairei's student council room. But with the too-strong personalities of the president and vice presidents, and these two being quiet and rarely speaking, they'd made little impression.

Yuu recalled both were second-years like Emi, but they felt nothing like seniors. Both had similar short haircuts and average-but-not-bad features, appearing plain compared to Rinne and Norika's full makeup. Keiko had neatly trimmed bangs and red-framed glasses; Miyuki had longer bangs parted with a light-blue hairpin pinning one side to reveal her forehead.

"Since we're here, you two strip too"  
"Eh..."

Keiko and Miyuki exchanged glances. Having witnessed Yuu's actions, they likely judged compliance wisest and undressed without hesitation.

Under their uniforms, both wore matching underwear sets. Keiko had white with blue polka dots; Miyuki had white with pink floral patterns. While Rinne and Norika were at least mid-160cm tall and Wei Hui over 180cm, these two were similarly short at mid-150cm. With their modest underwear, they looked like ordinary high school girls.

"Come here"  
"Huh?"  
"Eh?"

Yuu beckoned the now-naked Keiko and Miyuki. While they undressed, he'd moved chairs closer together. His anger had subsided after punishing the president and vice presidents. Though part of the student council, these two rarely interacted directly with Yuu and seemed uninvolved in the scheme, so he felt no urge for brutality. But his lingering lust remained. Their modest breasts and underdeveloped bodies lacked feminine allure compared to even Norika, let alone Rinne. Yet seeing two naked girls up close made his crotch react sensitively.

"Here"  
"Ah, okay"  
"Excuse us"

The moment Keiko (left) and Miyuki (right) drew near, Yuu spread his arms and embraced them. "Kyahn!"  
"Anh!"  
He licked Miyuki's neck while both hands groped their breasts.

"I've got questions for you two. Answer honestly, and I'll let you freely use my cock."

As Yuu gently kneaded their palm-sized breasts and alternated licking their ears and necks, they began panting lightly. Already blushing pink, both glanced between Yuu's face and crotch before nodding in unison.  


### Chapter Translation Notes
- Translated Chinese insults: "日本鬼子" as "Japanese devils" (historical derogatory term) and "鸡巴" as "cock" (direct anatomical translation)
- Transliterated sound effects: "ずぶ、ずぶ" → "zubu, zubu" (penetration sounds), "ばしん、ばしん、ばしぃん！" → "bashin, bashin, bashiiin!" (skin-slapping sounds)
- Preserved explicit terminology: "チンポ" → "cock", "膣内" → "vagina", "射精" → "ejaculate" per Fixed Style rules
- Maintained original name order: "李 衛惠" → "Li Wei Hui", "図書 美由記" → "Zusho Miyuki", "会澤 景子" → "Aizawa Keiko"
- Translated brand references contextually: "ポカリスエット/アクエリアス" → "Pocari Sweat/Aquarius-like" for cultural recognition
- Rendered internal physiological descriptions literally: "破瓜の血" → "hymen blood", "精液" → "semen"
- Preserved Japanese undergarment terms: "パンティ" → "panties", "下着" → "underwear"