## 155. At Saiei Academy ⑧ ~Two Silences~

At Saiei Academy's student council, there exists a significant disparity between the top three third-year members (President and Vice-Presidents) and the second-year Secretary and Treasurer.  

The Secretary and Treasurer handle only the official outward-facing duties of the student council.  
Meanwhile, the top three each command their own direct committees with access to unofficial budgets and personnel.  
One reason for the student council's strong influence at Saiei Academy is their practice of breaking and taming boys by exploiting their weaknesses, then offering them to ordinary students.  
Overseeing this is Norika, with direct involvement from the Health Committee.  
The two restrained by Yuu are its chair and vice-chair. From Keiko and Miyuki, we learned the tall one with long black hair is Chairperson Nagata Miho, while the shorter one with tea-colored tousled hair is Vice-Chairperson Soejima Takeno.  

As Yuu predicted, this room is used for training boys brought here and assigning them to ordinary students who apply through student council connections.  
The Secretary and Treasurer duo normally don't enter this room.  
However, they're occasionally called as recording staff for photography when first bringing in boys. They're merely permitted to observe.  
Thus, they've never had sexual intercourse with the boys kept by the student council.  
When training occurs, Norika and the Health Committee members monopolize it.  

Their explanations might contain elements of self-defense that Yuu shouldn't hear.  
But since he doesn't know other schools' circumstances, suspicion would be endless.  
Having already delivered punitive treatment to Rinne and the top three, Yuu judged it better to treat the initially compliant duo with sunshine rather than the north wind approach.  

Remembering he'd been too focused on violating Rinne and Wei Hui to kiss anyone, Yuu immediately seized the lips of Keiko who leaned against his right side.  
Keiko's eyes widened in surprise, but as he stroked her hair, her expression melted into a daze.  
After savoring her small, soft lips for about a minute, it was Miyuki's turn on the left.  
Having witnessed Keiko's kiss, Miyuki flusteredly opened and closed her mouth when her eyes met Yuu's.  

"Is this your first time?"  
"Um... well... yes."  

Miyuki nodded, her ears turning bright red under Yuu's gaze. Her claim of never having been with a man seemed credible.  

"Close your eyes."  
The moment Miyuki nodded and closed her eyes, Yuu tilted her face and kissed her while stroking her hair with his left hand.  
After exchanging kisses for about a minute and gently pulling away, tears trickled from her eyes.  

"Wh-what's wrong?"  
"Ah... th-th-this is! Well... I've admired you as wonderful since we first met..."  
"Me too!"  
The moment she heard Miyuki's confession, Keiko agreed while hugging him.  
"Each time we met, these feelings kept growing, but I gave up thinking it was an impossible wish."  
"So getting to kiss you like this makes me so happy!"  
"Really! It feels like a dream, my chest's all warm!"  

*Is Saiei's student council abnormal except for these two ordinary students?*  
Yuu couldn't quite say.  
Fundamentally, Sairei girls receive ladylike education that values men.  
Other women range from best to worst.  
Recall that among delinquents, there were groups like Ichimatsu High who attacked during Newcomer Welcome Orienteering (※Ch.39-40), but also pure women like Saiou Red Scorpions members with no male immunity (Ch.47).  

Earlier, ordinary-looking women in town wouldn't immediately assault men, but once their restraints came off, that changed.  
Personalities vary, but changing according to circumstances might be the same for both genders.  

Having no particular grudge against the two before him—Keiko and Miyuki—Yuu decided to treat them like Sairei girls.  
First, he had Keiko and Miyuki sitting pressed against his sides straddle his spread thighs.  
The moment their crotches touched his thighs, he felt they were wet.  

"My my, already wet?"  
"Ehehe. Well yeah..."  
"Somehow, my body's been hot since earlier..."  

Grabbing the chin of Miyuki who smiled shyly, Yuu pressed his lips and immediately invaded with his tongue.  
"Fweh!? Nnkk... ah... ahn"  
Miyuki closed her eyes and accepted Yuu, but perhaps feeling something in the mucosal contact, she began whimpering.  
While their tongues tangled with wet sounds, Yuu's hands kneaded both their breasts.  
Now focusing on nipple stimulation.  
As he pinched and rolled them between two fingers, they stiffened fully.  

"Nngahh... ahn... amu, lero, lero, nleroo... chupa... hafu... nn-chu, chupaleroo..."  
"Nnnn! Yahh... haahn! I-it feels... better than doing it myself!"  
Unconsciously gripping Yuu's shoulders, the two intermittently moaned.  

After enjoying oral pleasure with Miyuki for 2-3 minutes until drool strings hung from their mouths, Yuu turned to Keiko.  
Keiko was already waiting with narrowed eyes, mouth open and small tongue out.  
Smiling, Yuu stuck out his tongue, their tips touching lightly.  
"Hah, hah, hafu... ero, hyafu... haa... ann!"  
As mutual excitement built through shared breath, Yuu suddenly mashed their lips together, his tongue ravaging her small mouth.  

"...! Hya... nmo... ooh, ahh... ahe... nmuu... nn, nn, nnn!"  
Combined with skilled nipple play, Keiko trembled violently, feeling her brain might go numb from the sensations.  

As Yuu alternated kisses and nipple play, their dripping love juices visibly overflowed.  
Judging the timing right, Yuu instructed Keiko and Miyuki to keep straddling him while planting their feet and lifting their hips.  

"Want to touch my cock?"  
They looked incredulous, but Yuu knew they'd been stealing glances.  
Internally, they must be dying to touch.  

"I-is it okay?"  
"Sure. Let's touch each other."  
"Th-then... mufufu"  
"It's delicate, so start gently."  
""Yes""  

As they timidly reached for the cock, Yuu touched both their pussies.  
""Aahh!""  
Just fingertip contact revealed their slickness, love juices clinging to his fingers.  
Spreading their labia with finger pads produced wet squelches.  
After playing with their soft, wet labia using two fingers, he withdrew to find the nub.  

"Ah... there!"  
"Hii!"  

Both stopped stroking the cock and jerked violently.  

"What's wrong? Your hands stopped."  
"B-because... a-ahn! It feels... too good!"  
"Th-there's sensitive! Yah... if you play with it like that... nnn!"  

Starting with feather-light touches, Yuu gradually rubbed their clits boldly with finger pads.  
Keiko and Miyuki moved their hands mechanically while gripping Yuu's shoulders and moaning.  
Hearing moans from both sides, Yuu noticed their voices differed despite similar appearances.  

Miyuki whimpered with a nasal, sweet voice while Keiko was more restrained but occasionally let out high-pitched cries.  
Miyuki was honest about pleasure; Keiko showed more shyness.  
Simultaneously handling both revealed personalities—one of the joys.  

With wet squelches, Yuu continued fingering them simultaneously until Miyuki's hips began shuddering first.  

"Hyaaan! I-I-I'm! I'm cummming! Ah, ahn! There... aaaaaaaaahhhhhhhh... noooooo... I'm, I'm cummiiiiiiiiiiiiing!!!"  

Spurting foamy juices, Miyuki came and slumped her face onto Yuu's left shoulder.  

Next was Keiko.  
Her cock-stroking hand stopped as if resisting, but her squirting from clitoral torture showed she was near limit.  
Sticking out her tongue pleadingly toward Yuu, a wave suddenly hit.  

"Ahii... I-I can't... a, a, a, ah... not like... this... ahh! Ge... n... kai... Cumming! Ahhh!"  
Unlike Miyuki burying her face in his left shoulder, Keiko pressed her cheek to Yuu's without fixing her askew glasses as she came.  
It was the happiest moment of her 17 years.  

"Th-this okay?"  
"Yeah yeah. Lick it well like that."  
"Nn... Clear liquid's dripping from the tip."  
"Ah, feels great being licked by you two."  
"Ufu"  

After making them cum with fingering, it was Yuu's turn for fellatio.  
With Yuu seated and legs spread, the two pressed close between them, using hands and mouths to caress his cock.  

Though virgins, they'd seen real male genitals several times—a student council privilege—but never touched.  
Yet what stood erect in Yuu's crotch was another matter entirely. Child versus adult difference.  
Certainly overwhelmed by its masculine menace, Keiko and Miyuki fumbled at first but soon became entranced, continuing fellatio with faces Yuu instructed.  

Chu, chu—using entire lips and tongues to suck from glans to coronal ridge to shaft.  
One hand lightly stroking up and down.  
Gently massaging the balls.  
Now with ecstatic faces unthinkable for virgins, they sucked obsessively.  

"Ahh, feels good..."  
"Ahaa, I'm glad."  
"Yu... Yuu-kun's pleasured face is wonderful too."  

Stealing upward glances at Yuu while diligently continuing, they felt supremely happy and excited at this unexpected luck to pleasure his magnificent cock.  
Their free hands began fingering their own pussies with squelching sounds.  

Yuu too felt elated being enthusiastically double-sucked by seemingly docile, cute high school girls.  
When he stroked both their heads, they looked even happier.  

"Right. Miyuki, keep sucking the tip while licking inside your mouth.  
Keiko, focus on licking the belly side."  
"Ufu. A~m... chupa"  
"Ahh... it's throbbing. Amazing. Leroo"  
"Y-yes, good job. Ahh, nice..."  

Seeing Yuu's reactions accelerated their hand and tongue movements.  
Though fingered more pleasurably than ever before, masturbating while sucking cock was exceptional.  

"Nn, nn, amuchupalerolero... hah, fu, nna! C-cum juice, delicious!"  
"Ham... nn~~~ lerobuchuu! Nnn! Afu... lerooron"  
"Kuh, aah! D-dangerous... almost..."  

Initially clumsy, their tongue and hand skills rapidly improved—whether from practice, passion, or observing Yuu's reactions.  
Consequently, Yuu's ejaculation approached rapidly.  
Both seemed highly aroused from masturbation too, emitting constant muffled moans.  

"About to cum. Both lick the tip while stroking."  
"Fai... I'm close too."  
"Ahn! M-me too."  

As instructed, Keiko and Miyuki stuck out tongues like licking soft-serve, lapping broadly.  
Overlapping hands stroked rapidly while their other hands squelched inside pussies.  

"Guh! Ah! C-cumming! Ugh!"  
Since Yuu's hands rested on their heads, both faced him open-mouthed when it happened.  
His cock throbbed and spurted semen powerfully—dopyu dopyu dopyu.  
""Aaan!""  
Semen flew into mouths and splattered cheeks and noses.  
As they took facial ejaculation, Keiko and Miyuki came too, spreading puddles on the floor.  

"Fuuh. Came. Felt amazing.  
Now, lick it all clean."  

Swallowing the semen, both dazed from orgasm, they competitively licked cum still spurting from the glans as ordered.  

"Nn. That's enough. Thanks."  

With his cock cleaned by their tag-team fellatio, Yuu nodded satisfied, gently stroked their heads, and stood.  

His eyes turned to the two Health Committee members present from the start.  
Centered around Norika, among the boys they "trained" were some just entering middle school.  
Forced to lose virginity by multiple older women.  
Unlike his original world, innocent boys raised here must have been terrified.  
What treatment suited these two who enjoyed using boys as toys?  

Watching Yuu's back as he slowly walked toward the large mat, Keiko and Miyuki silently exchanged nods.  

Their words to Yuu contained no lies.  
But they'd omitted some things intentionally.  
Specifically, their strong resentment toward Norika and the Health Committee.  
Monopolizing boys under the pretext of responsibility.  
After-school boy assignments were mostly decided by the top three, excluding them.  
Burdensome daily tasks limited to official duties—no boy privileges at all.  
Such cruel disparity within the same student council bred resentment.  

Today brought continuous shocks.  
Seeing President Rinne violently raped, Vice-President Norika spanked, and Vice-President Wei Hui easily restrained, they chose the opposite action of the fleeing Health Committee members.  
Namely, keep observing Yuu, feign obedience, and seize any chance to win favor.  

Keiko and Miyuki won their gamble.  
Failing to lose their virginity in the momentum was regrettable, but they'd received considerable pleasure.  
Undoubtedly, they alone gained Yuu's favor in the student council.  
They wished for him to take their virginity next time.  
Shoulders pressed together, smiles rose on Keiko and Miyuki's lips.  
They were far more cunning than Yuu imagined.  

---

### Author's Afterword

I wanted to have the Secretary (Miyuki) and Treasurer (Keiko) graduate from virginity, but there wasn't enough space (excuse).  

The next chapter will be this year's final post, neatly concluding the Saiei Academy arc.

### Chapter Translation Notes
- Translated "二人静" as "Two Silences" to convey the dual meaning of quiet observation and the chapter's focus on two characters
- Preserved Japanese honorifics (-kun for Yuu) and name order (Nagata Miho)
- Translated explicit anatomical/sexual terms directly ("clit", "semen", "fellatio")
- Transliterated sound effects (e.g., "dopyu" for どぴゅ)
- Maintained italics for internal monologue *(Is Saiei's student council...)*
- Used double quotes for simultaneous speech (""Yes"") when both characters respond together
- Translated "調教" as "training" in sexual context to match explicit terminology rules