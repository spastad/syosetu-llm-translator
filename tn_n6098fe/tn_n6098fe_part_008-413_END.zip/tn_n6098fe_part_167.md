## 156. At Saiei Academy ⑨ ~Wailing~

"Kuh, this is humiliating."  
"Auuuu... It hurts..."

The two leaders of Saiei Academy's unique Health Committee organization - Nagata Miho and Soejima Takeno - had been stripped naked by Yuu and forced onto all fours with their buttocks exposed.

Nagata Miho had straight black hair reaching mid-back. Standing slightly over 170cm with a slender build, her somewhat sharp eyes still met this world's standards of a "fine woman." A leather collar with a long lead like those used for pets was fastened around her neck. She wore cat ears on a headband, and a fluffy black tail curved upward from her buttocks. Of course, since this wasn't a fantasy world with beastfolk, the tail's base was inserted into her anus.

The other was Vice-Chairwoman Soejima Takeno. Though not collared, she wore a headband with cat ears and a long white cat tail. Being on all fours caused her E-F cup breasts to hang heavily, their tips nearly touching the mat, while her perfectly round buttocks looked ideal for childbirth with ample flesh. Incidentally, the handcuffs connecting Miho's right hand to Takeno's left hand remained in place.

During their resistance using both words and body, Yuu had employed a riding crop against them. Though resembling a fly swatter, the black leather implement with its dull sheen made loud noises without easily leaving marks or causing welts. Yet despite being less likely to mark, repeated spankings had turned both buttocks bright red. Their will to resist seemed broken - Takeno wept with choked sobs while Miho glared at Yuu through tear-filled eyes.

***

Rewinding time slightly...  
After the double fellatio with Keiko and Miyuki, Yuu headed toward the giant mat to deal with the Health Committee members, pondering as he walked. Would merely having sex just end up pleasing them?

He'd heard how these committee members "trained" and toyed with defenseless men here. Had Yuu fallen unconscious, he'd undoubtedly have suffered the same fate - these two had been waiting in this room precisely for that purpose.

Therefore, making them experience the position of being toyed with seemed fitting. With that thought, Yuu changed direction toward the shelves lining the wall stocked with adult toys. Though he'd casually tossed some into a shopping basket while tormenting Norika, plenty remained.

The pet cosplay sets for dogs and cats immediately made him grin, though he reconsidered whether they were meant for men instead of women here. When he asked Keiko and Miyuki to confirm, they smoothly explained that yes - the Health Committee women particularly enjoyed making junior high boys dress as dogs and cats, even pretending to walk them or play "butter dog."

***

"Being made to dress as a dog or cat yourself... How do you feel now?"  
*Whap! Crack!*  
"Kyauu!"  
"Hiiin! Stop it already!"

Facing the two with their bright red, trembling buttocks and exposed pussies, Yuu's crotch hardened into a rigid pillar pointing skyward.

"Well, I'm not a demon. If you ladies reflect on your past actions and change your ways, I'd like to offer candy instead of the whip."

"Huh...?"  
"Haa? What are you saying!?"

Takeno looked at Yuu with clinging hope while Miho continued glaring fiercely.

Yuu spread his hands apart, pulling their buttocks together until they touched. Then he slowly began fingering both their vaginas.

"Ah... no..."  
"Nnnn..."

Knowing they were nearly dry from only spanking - especially Takeno - Yuu didn't thrust in abruptly but started with delicate touches. Surprisingly, Miho was already moist.

"Oh ho? Well now."  
"W-what!? Ah, ahn!"

Soon wet squelching sounds came from Miho's vagina. Yuu then thrust his erect cock between their buttocks.

"Ah..."  
"Eh!?"

Takeno blushed when feeling Yuu's giant cock against her skin for the first time since entering the room. Enjoying the double assjob, Yuu declared:

"From now on, you'll add 'wan' or 'nyan' to your sentences. For example, if you say 'I want your cock wan,' I'll insert it?"  
"Wha-"  
"........"  
"Well? Don't you want it?"

He stroked their vaginal openings with his fingers until properly wet, then inserted his middle fingers.  
"「Aahh!」"  
Though undoubtedly well-used, both vaginas tightly clenched the newly inserted fingers. As he slowly pumped, transparent fluid coated his fingers.

"Feeling good soon? But my cock's thicker and feels better than fingers?"  
"Haa! Kuh... don't mock me. Why should I... let a man take... ah! Don't stir it up!"  
"Nnn, nnn, kufuun"

The wet sounds from their vaginas grew louder under Yuu's fingering. Clearly aroused yet gripping the mat tightly while sobbing in resistance was Miho. Takeno occasionally brushed aside her hanging bangs, her face flushed pink like she was drunk, breathing heavily. Several times her moistened eyes glanced at the cock pressed against her buttocks. Finally unable to endure, she spoke:

"A, a, umm..."  
"What is it?"  
"I... can't hold back... anymore. I... want your... cock... nyan?"  
"Ta, Takeno!?"  
"Couldn't hear well. Once more!"  
"I... want your cock nyan! Put it in my pussy, nyaaaaaan!"  
"Here."

Yuu pulled his right middle finger out and grabbed a buttock with his wet hand. After pulling his hips back slightly, he thrust into Takeno without hesitation.

"Gah! Haooooon! S-so big... hya, hya, hanyaan! Afueeeee... d-deep... so deep nyaaaaaan!"

The cock plunged deep, momentarily blocked by vaginal walls before forcing through. When the tip struck her cervix, Takeno arched her back sharply and screamed. Milky fluid sprayed from their joining point as her upper body shook violently.

"Aheee... I came just from insertion... Th-this is... my first time..."  
"Came just from insertion? What a slutty pussy. But hey, the main event starts now."  
"Ahn! Ahn! Aha, amazing! My uterus being gouged... ah... feh... I didn't know... a man's cock could feel... this good... ahhn! More..."

"Usoo..." Miho watched in disbelief as Takeno, having already surrendered to the cock, began lowering her hips to meet Yuu's thrusts. Meanwhile, Yuu's finger remained inside Miho's vagina, forcing moans from her with each deep thrust matching Takeno's movements.

***

"Fu. Came, came. Didn't expect this much left."  
"Afueee... no more... cock too... amazing... I'll die..."

Takeno lay face down on the mat with her buttocks raised, drooling and moaning - apparently her first time coming so many times consecutively. When Yuu pulled his cock out moments later, milky fluid overflowed from her womb and dripped down.

"Still got some left. Who next?"  
"Eh..."

Having been brought near climax when Yuu removed his finger while watching Takeno writhe beside her, Miho felt sexually frustrated. Thinking her turn had come, Yuu ignored her completely as he turned away. Though desperately wanting penetration now, she couldn't bring herself to beg honestly.

"Hey! Give me your cock already!"  
"Wah!"

It was Norika crawling forward with lust-glazed eyes. Though still bound hands-behind-back, she'd somehow gotten close, panting like a dog with red tongue out, looking ready to bite his crotch. This provoked Miho.

"W-wait! Please!"  
"Hmm?"

Unable to move while restrained, Miho desperately called out. Yuu turned with a relaxed smile.

"I... want it... your cock."  
"Say what?"  
"So... do me?"

Miho flushed crimson and shook her buttocks seductively. For her - who'd freely toyed with boys until now - this was her first time pleading. But Yuu mocked:

"The dog's saying something, but I can't understand."  
"Then it's my turn! I'll make you feel good with my well-trained hips!"  
"Fuuun"

Though Norika wriggled her body, Yuu seemed unmoved. Miho grew frantic. Restrained by collar and handcuffs, she watched as Norika crawled closer, looking ready to pounce.

"Th-that fat slut's loose pussy won't feel good!"  
"Wha, wha, what did you say!?"  
"M-my pussy is... better... please put it in... wan?"  
"Oh? Say that again?"

With a face red as boiled octopus, Miho raised her buttocks high and spread her legs, pleading in the pose of a bitch in heat.

"U... um, I want your magnificent cock... in my bitch pussy... wan... Thrust hard like you did with Takeno... wan!"

Hearing her shout the last part, Yuu turned and approached Miho. Seeing this, Norika collapsed with a despairing expression.

"Keeping my promise. I'm a man of my word."  
"Aah... happy... wan"

Just Yuu kneeling behind her and gripping her buttocks made Miho look overcome with emotion - a stark contrast to when first restrained. Spreading her buttocks with both hands, he pressed his hips forward. Merely touching her vaginal opening with his glans revealed it was wet and perfectly soft.

*Schlup.*  
"Ahe! Hoh... so... thick and hard!"

Just swallowing the glans made her spray fluids like joyful drool. Seeing no need for further teasing, Yuu thrust deep in one motion, *thudding* against her cervix.

"Gah... gah... gahha... not this... ohhiiiiii! C-cumming! Cummingcummingcumming! AAAAAAAAAAAAAHHHHHHHHHH!!!"

***

Miho eventually collapsed face down, unable to support herself, putting Yuu in a prone position. With each thrust from Yuu covering her back, *squelch splat* sounds of flesh echoed. Having ejaculated multiple times already, this session with Takeno and Miho took longer. Miho shuddered and moaned with each cervix-pounding thrust, having lost count of her orgasms. Drooling and gasping, overwhelmed by Yuu's rough breath and body heat amidst continuous climaxes, her mind and body reached their limit.

"Gah! Gah! GAAAAAAAAAAAHHHHHHHHHH... hahi, hahi... Cumming! Cumming! Oh... oh... cock too... amazing... no more... surren... der... submit."  
"That's it! That's it! Nn? Had enough cock?"  
"Cock feels too good... but... can't... anymore... surren... der."  
"Then do you regret toying with all those boys?"

Yuu ground his cock deep inside her cervix. Instantly Miho gasped with tongue out and chin raised.

"Ahyee! No grinding! Stop! Gah! Gah! Gah! Cumming! Cumming again! Cumming ahhhhhhh! I-I regret it! Miho was... a bad girl! Ugh... sorry! Sooorrrryyyyy!"  
"Good girl. Perfect timing. Finishing now! Guh... gonna cum... inside!"  
"Gyaa!?"

Burying his face in her nape beneath disheveled black hair, Yuu accelerated his thrusts. Face down, Miho met her end with muffled moans. When the hot semen filled her womb, her mind went blank - going limp and urinating, further soaking the already stained mat.

***

"Shit!"

The prolonged thrusting before ejaculation left even Yuu feeling weary. Resting atop motionless Miho without withdrawing, he suddenly noticed the wall clock showed past 4 PM and panicked. Over two hours had passed since entering this room - truly a frenzy of debauchery. The tour ended at 4:30, with parking lot assembly at 4:45. Yuu needed to return to the third floor to reunite with Sayaka and the others.

Yuu hastily pulled out his cock and stood. He faintly heard Norika saying something but deliberately ignored her.

Noticing Yuu wiping his crotch and dressing, Keiko and Miyuki brought his discarded polo shirt and a new drink.

"Nn. Thanks. You're thoughtful."  
"Ehehe."  
"Um... will we meet again? Just us two, without student council business?"  
"Hmm, well..."

Yuu regretted not taking Keiko and Miyuki's virginity due to time constraints. While he'd need to reconsider student council relations, meeting these two separately would be fine. After dressing and chugging the drink, Yuu patted their heads and kissed their chins. The unexpected kisses left them both dazed.

"Parting for now, but we might meet again. Next time we'll finish properly."  
"We did it!"  
"Looking forward to it!"

The room stayed quiet except for Norika's resentful groans. Seeing them off to the elevator, Yuu waved goodbye to the enthusiastically waving pair and returned to the third floor.

---

### Author's Afterword

With the departure from the basement, the Saiei Academy arc concludes. Next chapter reunites with Sayaka and returns to school.

Due to busy year-end schedules, Wednesday updates will pause. New Year updates resume January 3rd (Friday).

### Chapter Translation Notes
- Translated "慟哭" as "Wailing" to convey intense emotional distress
- Translated "尻尾の根元は肛門に刺さっている" literally as "tail's base was inserted into her anus"
- Preserved Japanese honorifics (-san for characters)
- Transliterated sound effects (e.g., "ばちゅん" → "squelch splat")
- Translated explicit anatomical/sexual terms directly ("膣" → "vagina", "精液" → "semen")
- Maintained original name order (e.g., "長田 美保" → "Nagata Miho")
- Used gender-neutral "they" when plural gender unclear