## 157. Return, and... ~CAN YOU CELEBRATE?~

### Author's Preface

Happy New Year.

The first story of 2020 begins with Yuu returning to the student council room on the third floor after the debauchery in the Saiei Academy student council building's basement.

I look forward to your continued support for *Reborn in a Chastity Reversal World* this year.

Regarding update pace: Maintaining three updates per week has become difficult, so I considered reducing to two. However, I'll strive to maintain the current pace until Chapter 5 concludes.

---

After getting off the elevator on the third floor, Yuu passed through a corporate-style office space and entered the student council room filled with aristocratic flair. The two people Yuu had knocked out were already gone, and just as when he left, three people lay face-down asleep on the table.

Perhaps noticing the door sound, Emi was the first to wake up. Still dazed, she sat up and looked around blankly.

"Huh...? Ah, Yuu-kun!"

"Emi, good. You're awake."

Yuu felt relieved that Emi had woken naturally, though he didn't know how potent the sleeping drug in the tea had been. Next, Riko woke up. Sayaka didn't wake immediately, but finally opened her eyes after Riko shook her.

"We were asleep, weren't we?"

"What's the meaning of this? Not a single Saiei student council member is here."

"Yuu-kun, do you know something?"

"Sorry. No time for details now."

When they checked the clock showing 4:20 PM, everyone panicked. "Wait. Before that—" Yuu walked deeper into the room and entered the kitchen. There sat Amir, trembling violently while prostrating himself.

"Sorry sorry sorry sorry......"

"Um......"

"What's going on?"

Sayaka and the others following Yuu looked suspiciously puzzled. Only Yuu, who roughly understood the situation, knelt and placed a hand on Amir's shoulder.

"It wasn't your independent decision, was it? Given your position, you couldn't refuse orders, right? So you don't need to apologize anymore."

"Uu......"

"I don't know your circumstances so I can't judge. But if you have evidence of what was put in the tea, I'd like it."

".........Yes."

Yuu obtained three opened packets and one unopened powder packet. Though silent, Amir apparently hadn't put anything in Yuu's cup. Probably instructed to drug Yuu too, Amir had independently refrained. Yuu imagined something else might have been added instead but chose not to interrogate further—partly because overwhelming fatigue and lethargy were setting in.

"Shall we go?"

"Don't really understand... but time is short, true."

"Yeah. Let's go."

***

On the return bus, Masaya and Rei immediately tried discussing the day's events, but Yuu only managed a few responses before falling asleep. He slept soundly until being woken upon arriving at school. The backlash from his temporary excited state and consecutive sexual acts seemed to have hit. Even after waking, his mind felt sluggish—though the near 30-minute nap proved fortunate.

After parting with Masaya and Rei at the second building entrance as they boarded their bus, Yuu lightly stretched and drank black coffee from a vending machine to clear his head.

Though already around 5:30 PM, early August meant daylight and heat nearly matching noon. Students from today's tour had all headed home, leaving campus deserted. Sayaka and the others, who'd been with same-grade girls, might have disbanded and left already. Cicadas filled the tree-lined backyard with noisy chirping. Wiping sweat that seeped out regardless, Yuu headed to the student council room.

***

"I. WON'T. FORGIVE! I'll go home now and get Mashin—"

"Better to have my lawyer friend prepare a lawsuit—"

"If we gather Yuu-kun's fan club, we can get over 100 people to raid—"

The moment Yuu entered, the three confronted him fiercely. He explained what happened at the student council room, mixing in speculation. He naturally omitted basement details. Learning Yuu had been taken alone after they were drugged, Sayaka and the others showed unprecedented fury, escalating to concrete revenge plans. (Yuu first learned he had a fan club.)

"Wait, wait! I personally disciplined the three executives and those Health Committee members there. The president was still unconscious, Vice President Li was crying from pain, and Vice President Omori looked utterly despairing after over a dozen spankings."

"Disciplined?"

"Unconscious? Spankings? Despair?"

"Wh-what did you do, Yuu-kun?"

"Well, various things. If we meet again, I'll make them apologize properly. More importantly—didn't you three have something to tell me today?"

Hearing this, Sayaka and the others exchanged looks. They'd been ready to storm Saiei immediately if Yuu seemed hurt, but since he insisted he was fine, they calmed somewhat and switched gears. Nodding, they sat down—in the same positions as when Yuu first visited in April, all three facing him. Sayaka spoke first as representative.

"Um... since July I've gradually felt worse—nausea, dizziness... Could barely eat. Lost about 3kg since April measurements. Though awkward to say to a boy like you, Yuu-kun... my period stopped too. The discomfort peaked around the quiz championship. Next day, following Riko's advice, I got examined at OB-GYN."

By now Yuu could guess. He gazed straight at Sayaka, awaiting her words.

"I was pregnant. 11 weeks. Meaning three months."

"!"

Yuu stood up so abruptly his chair scraped loudly. Various emotions flooded him. Less than half a year since rebirth. The child he'd so desperately wanted with a loved one in his past life. Obtained so easily left him momentarily unable to process it. But they'd done it without contraception—the OB-GYN diagnosis was certain.

Joy slowly welled in Yuu's chest. Though they were high schoolers, fortunately in this world natural pregnancy during student years was praised as honorable. Support systems seemed reliable too. Boy or girl—either was fine. He thrilled at imagining what child would be born.

Yuu slowly rounded the table and approached Sayaka. "Yuu-kun?" He took her hands and helped her up. Her expression held slight anxiety. Facing each other nose-to-nose, they locked eyes.

"Ah, how to say this... Anyway, I'm incredibly happy. Sayaka, thank you."

"Ah!" He gently hugged her, careful not to squeeze her belly. "Yu, Yuu-kun... Ah!" Sayaka hugged back, arms wrapping around him. Yuu noticed tears overflowing and trailing down her cheeks. "Huh? Why crying? Isn't this celebratory?"

"Ah... I suppose I'm overwhelmed."

"Sayaka is crying from happiness knowing Yuu-kun is genuinely pleased."

Riko and Emi too looked tearful. For women in this world, getting pregnant through sex itself brought great happiness—but reactions differed by the man's attitude. Men viewing insemination as mere duty might act coldly upon pregnancy. Since pregnancy didn't equal marriage, some even ended relationships to avoid hassle. Psychologically, women felt heavenly joy simply from their man happily receiving the pregnancy news.

"Though hate to interrupt, time to stop?"

"Ah, sorry."

Riko and Emi stood and approached Yuu. "Huh? Don't tell me—" "Us too." "We're pregnant!" "Whoa!"

Apparently after Sayaka's pregnancy discovery, Riko and Emi—having similar suspicions—got examined at the same OB-GYN. Their pregnancy weeks were nearly identical. Meaning implantation and pregnancy occurred days apart in May. One pregnancy alone was celebratory—but all three at once swelled Yuu's joy.

"Ah, but morning sickness...?"

"Sayaka had the worst and longest symptoms there."

"I barely had any!"

Riko had noticed aversion to spicy smells and reduced appetite but felt otherwise fine—evident when dining together recently. Emi reported no symptoms at all. While most pregnant women experience morning sickness, it varies individually—some don't realize they're pregnant for a while. Though typically lasting 3-5 months, Sayaka might endure longer.

Yuu spread his arms and embraced Riko and Emi as they approached, hugging all three simultaneously. Feeling their wonderful scent and softness directly—plus knowing new life grew within them—made them ever more precious.

"Ah, how blessed I am. My beloved girls all carrying my child together."

"Yuu-kun!?"

"Gosh, I might cry..."

"Me too."

Even ever-energetic Emi and cool-headed Riko looked moved. Apparently they'd felt slight anxiety before confessing.

"Sayaka, Riko, Emi."

"Hm?"

"Yes?"

"What?"

Calling each name while meeting their eyes, Yuu smiled slightly sheepishly.

"Not sure if this phrasing fits... but as a man I want responsibility. Meaning—let me formally date you with marriage in mind."

"!!!"

Their shock manifested differently: Emi beamed with pure joy; Riko showed similar happiness while glancing at Sayaka; only Sayaka looked conflicted despite clear happiness. Yuu then remembered—she had an arranged fiancé.

Sayaka looked down briefly before meeting Yuu's eyes with resolve. "One more thing I must tell you, Yuu-kun." "Yeah. Listening." "My parents know about the pregnancy. Naturally that you're the father too. Though against proper etiquette... my parents wish to meet and speak with you first." "...!"

Here, Yuu's 40-year past life spawned bad premonitions—vividly imagining a father enraged not just at his engaged daughter being "defiled" but impregnated. Noticing Yuu's stiff expression and darting eyes, Sayaka soothingly stroked his cheek.

"Probably nothing for Yuu-kun to worry about." "Eh, but..." "Rather, this might formally engage you to me." "Huh?" "True. By Komatsu family tradition, Yuu-kun suits better." "Eh, really?"

Only Sayaka and Riko seemed to know Komatsu family affairs. Yuu and Emi looked puzzled.

"Likely they just want to know your character, so it shouldn't take long. Thus—apologies for the suddenness—could you spare time tomorrow afternoon?" "Ah, yeah. Should be fine." "Great. I'll contact time tonight."

Though abrupt, Yuu—freshly confessed to about pregnancies—would meet Sayaka's family tomorrow.

***

### Author's Afterword

Previously in comments, concerns arose about sleeping drugs' effects on pregnant women. After finishing today's chapter, I remembered and considered adding clarification somewhere, but it disrupted the flow so I refrained. Will address another time.  


### Chapter Translation Notes
- Translated chapter title "帰還、そして…　～CAN YOU CELEBRATE？～" as "Return, and... ~CAN YOU CELEBRATE?~" preserving the English song reference
- Maintained Japanese name order (e.g., Komatsu Sayaka) and honorifics (-kun) per style rules
- Translated "悪阻" as "morning sickness" using standard medical terminology
- Rendered internal thoughts in italics (e.g., *This is concerning*)
- Transliterated sound effects: "がたっと" → "gata to", "ぽーっと" → "dazedly"
- Translated explicit terms directly: "種付け" → "insemination", "身籠もる" → "get pregnant"
- Preserved cultural terms like "土下座" → "prostrating" with contextual clarity
- Kept specialized terms untranslated when established (e.g., OB-GYN, Health Committee)
- Applied dialogue formatting rules: new paragraphs for each speaker, simultaneous quotes with double quotes