## 158. Visiting the Komatsu Family ① ~Calling~

According to Sayaka, the Komatsu family lineage dates back to the Edo period, originating from a samurai family serving a hereditary domain in northern Musashi Province.

Their social standing was low, living rather modest lives.

However, after becoming a disciple of a renowned swordsman and receiving full mastery certification, they opened a dojo in the castle town, accepting disciples from lower-ranking samurai and townspeople.

Though slightly earlier than the Meiji Restoration in Yuu's memory, in this world too the Edo Shogunate fell and a new government was established, abolishing the samurai class.

Under these circumstances, those who could continue working as officials were fortunate, while many former samurai struggled to make ends meet.

In so-called "samurai commerce," they often accumulated pointless debt and fell into poverty worse than commoners.

The Komatsu family continued their dojo modestly, but as the age of swords ended, they took up occupations like soldiers and police officers like other former samurai.

Later, Hanako (Sayaka's great-grandmother), born as the eldest daughter of the Komatsu family, was an eccentric who from childhood was fascinated by machinery, obsessed with cars and motorcycles that had recently become available to the public.

Growing up to become an engineer, she honed her skills at a then-rare automobile repair shop and eventually became independent.

It was around this time she met the male prostitute who would become her husband.

Despite economic fluctuations, after founding the company Komatsu Technical Research Institute (commonly known as Komatsu), the business expanded.

Blessed with one son and three daughters, the growing Komatsu family settled in Wakou City, Saitama Prefecture, adjacent to Tokyo's Itabashi and Nerima wards.

***

After lunch in the early afternoon, Yuu rode in a car from his condominium, taking about 50 minutes via the Kan-Etsu Expressway to reach Sayaka's family home.

Incidentally, Riko, who attended the same middle school as Sayaka and deliberately entered the same high school, reportedly commutes for 1 hour 30 minutes by train and bus. Quite a hardship.

One could understand why she'd want to stay over at Sayaka's condominium.

Located quite far from the station's urban area and near the Arakawa River embankment, Sayaka's family home stood in an area with more greenery than buildings.

After getting out of the car parked in the spacious gravel parking lot apparently for visitors, about 50 meters ahead stood an impressive wooden gate with tiled roofing, with equally tiled white-walled gate fences extending endlessly.

"W-what a magnificent residence."  
"Samurai mansion?"  
"Hmm, first time seeing one, but it feels like the estate of a truly distinguished family."

Unlike ordinary homes, one could tell there was distance between the gate and the main house. Within visible range alone, beautifully shaped tall pine trees were planted along the walls. The garden was likely enormous.

Sandwiched between protection officers Kanako and Touko, Yuu gazed in admiration for a moment, but with the appointed time approaching, he moved toward the gate.

After ringing the bell beside the gate, there was an immediate response, and it opened without much wait.

Greeting them was a woman about 20 years old, roughly 10cm taller than Yuu.

She wore a white upper garment and black hakama pants. Her shoulder-length hair was tied back, with minimal makeup but clearly well-defined features.

After Yuu introduced himself, she smiled brightly, "We've been expecting you." Then she made eye contact with the protection officers.

"Mu, she's skilled."  
"Yeah."

Yuu could hear the two whispering quietly behind him.

Not only was she physically fit, but her subtle movements and bearing suggested martial arts experience. Yuu recalled hearing from Sayaka that they ran a dojo at home.

Naturally, this woman before him was likely one of the disciples entrusted with greeting guests.

"Ooh! This garden is magnificent!"  
"Fufu. The president would be delighted to hear that."  
"Um, the president would be... if I recall correctly?"  
"Reika-sama, Sayaka-sama's grandmother."  
"Is the president doing the maintenance herself?"  
"Yes. Though only in recent years. Mostly we leave it to professionals."

Led by the woman along a gently curving path toward the main house, white gravel resembling white sand covered the ground beneath their feet as they walked on flat stones laid like stepping stones.

Along both sides of the path were perfectly round or oval-shaped shrubs - likely azaleas and satsuki past their flowering season. Then maples recognizable by leaf shape, and tall ones that might be kinmokusei (fragrant olive trees).

That was about all Yuu could identify. Mostly trees suitable for Japanese gardens were planted.

Though it was a clear summer day with strong sunlight, the path they walked on was pleasantly shaded by trees, offering some coolness.

*(Gardens like this must require tremendous upkeep)*

Enjoyable to see, but maintaining them requires regularly calling professionals. Only possible for those with sufficient financial means, truly the privilege of the wealthy.

Ahead lay what appeared to be the main house. Finally approaching the entrance, it was a residence distinctly reminiscent of traditional Japanese architecture.

Technically two-storied, but the first floor seemed unusually spacious while the second appeared less than half that size.

Its width could easily fit three ordinary houses, resembling important cultural properties Yuu had seen during trips to rural areas.

Likely built over half a century ago, it felt sufficiently historic yet less extravagant than expected for a major corporation president's home.

When the entire main house came into view, a new garage with shutters down was visible to the left. Its size suggested space for about three cars. The area before it was paved, likely connecting to a vehicle entrance.

Across the paved road, five cars of various sizes lined up along the wall - fitting for an automobile manufacturer's founding family.

To the right stood a single-story wooden building catching the eye. Slightly worn but sturdy and simple in box-like construction. More like a community center or assembly hall than a residence.

Before the building lay a flat, bare-earth open area like a square, with rows of tall sunflowers blooming with large flowers visible in the distance.

"That's the dojo," the woman explained, noticing Yuu's gaze.

Whether due to a break or the holiday, no voices came from inside, completely silent.

"Since it's Saturday, elementary students come at 4pm. Evenings are for middle and high schoolers. Adults come on Sundays."  
"Come to think of it, Sayaka said she trained at the family dojo until middle school. The instructor is..."  
"Ritsuka-sama, Sayaka-sama's great-aunt, serves as head instructor. A former police officer, she's somewhat gentler now after retirement, but was famously strict during her active years..."

She seemed to recall significant experiences, gazing distantly.

The open area ahead was apparently also used for training. Barefoot even in midwinter, of course. From spring to summer, dojo students were also mobilized for weeding.

Her grandmother had been an employee since Komatsu Technical Research Institute's founding, with family connections continuing to this day. She'd practiced kendo here since childhood. Even now as a physical education university student, she came for Saturday training.

And she'd known Sayaka since childhood.

"Partly due to lineage, but she was extremely competitive and hardworking. Hence her swordsmanship stood out even among same-aged children. Careless, and even someone two years older like me could be defeated. But outside the dojo, she was very approachable and adorable. And her character - helping the weak and crushing the strong, fair and upright. You could say she showed signs of leadership even in elementary school."

Yuu only knew Sayaka since entering Sairei Academy. But hearing such stories made him want to know the younger Sayaka.

***

"The guest has arrived."  
"Yuu-kun!"  
"Whoa... Sayaka?"

Immediately after the sliding door opened at the entrance, Sayaka's voice rang out. She'd apparently been waiting seated formally on the wide entrance step.

Despite midsummer, she wore a long-sleeved white blouse buttoned to the neck with a red ribbon hanging down. Below, a long black skirt. Her trademark glossy long black hair was down as usual, but with sides neatly pulled back, apparently half-up style.

Truly the image of a pure young lady.  
*(How beautiful)*

He didn't say it aloud with others present, but Yuu found himself captivated anew.

Guided by the woman who brought them, the two protection officers went to wait in another room while Yuu followed Sayaka to a spacious tatami room of about 20 mats facing the garden.

Windows facing the engawa veranda were wide open, allowing breezes through the garden trees and over what appeared to be an elongated pond resembling a stream.

Suddenly, a crisp *kakon* sound echoed. Looking toward the garden, Yuu realized it was a shishi-odoshi bamboo fountain making the sound by the pond's flowing water.

Having seen it only in movies and dramas but never in real life, Yuu felt strangely moved.

And now, seated formally beside Sayaka, Yuu was wrapped in unprecedented tension.

Across a thick table made from a single slab of giant timber sat Sayaka's parents on the left and grandparents on the right.

"Pleased to meet you. I'm Hirose Yuu. I'm delighted to meet Sayaka... san's family members today."

When Yuu spoke first with a bow, all four showed slight surprise.

"How polite. I'm Tomoka, Sayaka's mother. This is my husband Hikaru."

According to what Yuu heard earlier from Sayaka, mother Tomoka served as marketing department head at Komatsu headquarters.

Her neat short hair and full makeup, combined with black formal wear despite midsummer, suggested impeccable professionalism - the very image of a capable career woman. Yet her sharply defined features resembled Sayaka's beauty.

Both parents appeared around 40. Though contemporaries with Yuu's previous life self, both seemed youthful.

While Tomoka radiated dazzling strength and beauty, Hikaru was questionably handsome but had a gentle smile and calm, kind demeanor. Clearly not someone who'd shout "I won't give you my daughter!" - Yuu felt relieved.

"Grandmother Reika. And this is her husband Yoshioki."

Reika, with her magnificently gathered white hair, wore a white-based kimono with silver obi sash. Likely around 60, but with straight posture, sharp eyes, and dignified bearing fitting Sayaka's grandmother. Her small stature contrasted with an aura of formidable presence - surely the pressure of leading a major corporation.

Beside her, grandfather Yoshioki appeared 5-6 years older, completely bald and the very image of a kindly old man.

Thus, while father and grandfather smiled amiably to ease the atmosphere, mother and grandmother maintained calm expressions but watched Yuu with appraising eyes.

They didn't immediately address the main topic, first chatting casually about the increasingly hot weather, then Yuu and Sayaka's student council work and school matters.

When Yuu complimented the garden he'd walked through, Reika began expounding on gardening knowledge until Yoshioki stopped her when it grew lengthy.

A maid in cooking attire served cold tea. After refreshing their throats, the room quieted naturally, shifting to the main topic.

"Sayaka told us. She's pregnant, I hear. With you as the father."  
"Yes. That's correct."

Yuu nodded immediately at Tomoka's words. It's finally come, he thought. This is the crucial moment.

Tomoka nodded, her mouth relaxing. Seeing no one present condemning the pregnancy, Yuu felt relieved.

"In this world where women struggle to meet and bond with men, well done. Sending her to a co-ed school proved worthwhile. We'd heard she was popular with girls but completely uninterested in boys. Though younger, perhaps you two were compatible?"  
"Mother..."

Actually, Yuu had heard from Riko that boys did admire Sayaka, but none approached her like Yuu did. So far, the welcoming tone seemed promising.

After a pause, Tomoka produced what appeared to be a sheet of paper. Upon closer look, it seemed several pages bound together. Sayaka tilted her head seeing it - apparently unaware.

Tomoka spoke in an utterly serious tone:

"Regardless of gender, this at least ensures the Komatsu main lineage continues uninterrupted. The child will eventually be raised as Sayaka's child with whomever she marries. Of course, we'll provide sufficient compensation for you to live comfortably without working."

What Tomoka presented was a contract stipulating Yuu's relinquishment of parental rights to the unborn child, and acceptance of compensation with an amount featuring so many zeros it was immediately incomprehensible.

---

### Author's Afterword

If you share thoughts about this chapter, my response will likely come after the next installment. I might accidentally spoil things otherwise.

2020/1/6

There's a part where Yuu thinks "recognizable by leaf shape as momiji (maple)" while viewing the garden. Generally, "momiji" refers collectively to autumn foliage. For identifying tree types in summer, "kaede" (maple) would be more appropriate. However, since this is from Yuu's mistaken perspective, I've left it as is. Thank you for pointing this out in the comments.

### Chapter Translation Notes
- Translated "上がり框" as "entrance step" to convey traditional Japanese architecture feature
- Preserved Japanese terms like "shishi-odoshi" (deer scarer) with explanation
- Maintained "hakama" without translation as culturally specific attire
- Translated "質素な生活" as "modest lives" to reflect social status nuance
- Rendered "武士の商法" as "samurai commerce" to preserve historical context
- Kept Japanese measurement "20畳" as "20 mats" with approximate Western equivalent
- Preserved honorific "-sama" for family members during formal address
- Translated "嫡流" as "main lineage" to reflect aristocratic inheritance concept
- Used "relinquish parental rights" for precise legal terminology