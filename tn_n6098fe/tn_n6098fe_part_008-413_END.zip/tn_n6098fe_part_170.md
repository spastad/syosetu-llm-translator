## 159. Visiting the Komatsu Family ② ~There will be love there~

### Author's Preface

Thank you for all your comments on the previous chapter.

I'll reply to them sequentially after posting.

---

"The child will be raised as Komatsu Sayaka's child with the man she marries.  
Of course, we'll provide Hirose Yuu-sama with enough compensation money to live comfortably for life without working, so please rest assured."

For a moment, I couldn't comprehend what she was saying, but gradually the meaning sank in.  
Indeed, Sayaka had a predetermined fiancé.  
Moreover, Sayaka would give birth in about six months.  
They were saying that child would be raised as the child of her fiancé who would marry into the family.  

From my pre-reincarnation common sense, this was incomprehensible, but in this world, natural pregnancy was considered a blessing. So apparently, it wasn't unusual to maintain the engagement that connected families while raising another man's child.  

I couldn't utter a word and froze, but Sayaka broke the silence.  

"Mother! I—"  
"You stay quiet. You understand you're engaged, don't you?"  
"Kuh!"  
"To avoid misunderstanding, let me clarify that we do celebrate your pregnancy itself.  
However, as the heir to the Komatsu family, you're already set to marry the son of the Osugi family."  
"Uu... b-but, I..."  

As Sayaka struggled for words, Tomoka turned toward me.  

"Yuu-sama, we're grateful you were Sayaka's partner, even if it was just a fleeting whim.  
But you're only 16, aren't you? You'll have plenty of other women as partners.  
Please consider this the end with Sayaka and continue fulfilling your duties as a man with other women."  

The contract with a pen attached was pushed toward me.  
Sayaka's father Hikaru didn't even look at me, his gaze turned away.  
Grandparents Reika and Yoshioki sat silently with closed eyes.  
Tomoka was clearly leading this matter.  

Tomoka's intense stare while speaking brought back unpleasant memories from my past life.  
The client representative who demanded unreasonable price cuts.  
The boss who forced excessive work on me while knowing it exceeded capacity, then went drinking.  
All of them showed arrogant attitudes knowing their position made refusal impossible.  

If I were struggling financially, I might have been tempted by the money.  
But that wasn't important.  
This was the life created between me and Sayaka—the first woman I'd genuinely fallen for since my rebirth.  
The dream I'd desperately wanted but couldn't achieve before being reborn.  
Even if they called me unreasonable, I couldn't accept this.  

Under everyone's gaze, I lifted my face after bowing my head briefly.  
Then I spoke.  

"N... no... I refuse."  
"Huh?"  
"I... I love Sayaka!  
From the moment we first met, she captured my heart. The more time we spent together, the stronger my desire to be with her forever grew.  
The life we created together belongs to me and Sayaka. No amount of money could make me give it up!"  
"Yuu... kun!"  

Tears overflowed from Sayaka's eyes as she looked at me.  
Tomoka maintained her expressionless mask, but Hikaru, Reika, and Yoshioki's gazes seemed more impressed than hostile—or was that my imagination?  

"Are you seriously saying that at your age, you'll marry Sayaka and raise the child?"  
"Yes, that's exactly what I'm saying. I decided when I heard Sayaka was pregnant.  
I heard her relationship with her fiancé hasn't progressed at all because he's completely uninterested.  
I'm more confident than him that I can make Sayaka happy!"  

Before being reborn, I couldn't make even one woman happy, but now was different.  
I'd shared intimacy with many women.  
Among them, Sayaka, Riko, and Emi were women I wanted to keep spending time with.  
I admit it's greedy, but in this world with a 1:30 gender ratio,  
Sayaka was the foremost among my thirty.  
I had no intention of yielding her.  

"I see... I understand your passion, Yuu-sama.  
What does Sayaka think?"  

Sayaka wiped her tear-streaked cheeks with her fingers, smiled sweetly at me, and spoke.  

"I love Yuu-kun too. This isn't a temporary feeling.  
Through our student council activities together, he became special to me.  
I'm always thinking about Yuu-kun. It's the first time I've felt this way about a boy."  

Sayaka blushed like a shy maiden.  
Tomoka remained expressionless, but I could see the other three smiling affectionately.  

"When I suddenly felt unwell in mid-July, I was confused since I'd never experienced that before. But when the OB-GYN told me I was pregnant, with Riko supporting me, immense joy welled up inside.  
Even morning sickness stopped being painful once I knew the reason.  
Because inside me was the life Yuu-kun gave me.  
If possible, I want Yuu-kun to be the first to hold this child when they're born."  

I squeezed Sayaka's hand as she looked at me.  
"Nothing would make me happier."  
Sayaka nodded and continued.  
"Besides, my ideal marriage is like my parents' and grandparents'.  
I believe Yuu-kun and I can have that too."  
"Maa!?"  
"Haha, that's embarrassing to hear."  

Reika and Yoshioki exchanged smiles while Hikaru looked bashful.  

"As heir to the Komatsu family, I declare:  
Yuu-kun isn't just handsome—he's creative, mentally strong, and deeply compassionate.  
I can't imagine any other man surpassing him."  

Blushing from the excessive praise, I turned to Sayaka and clasped both her hands.  

"I feel the same. I'm overjoyed to have met a strong, beautiful, wonderful woman like you, Sayaka.  
And I want to stay by your side forever."  
"Yuu-kun..."  

"Fuuu..."  

Tomoka sighed as she watched us, placing a hand on her chest.  
Yuu and I didn't understand the gesture's meaning.  
She seemed to nod at something Hikaru whispered beside her.  

Tomoka pulled the contract toward her and raised a long wooden object she'd been holding.  
The sheath slid off to reveal a gleaming silver blade—a kaidachi dagger.  
"M-Mother?"  

Ignoring our shock, Tomoka maintained her serious expression as she lifted the contract and swiftly slashed the dagger through it—*shu shu*!  
Though it seemed like light sideways swings, the contract shredded into pieces that scattered across the table.  
She sheathed the dagger, straightened, and stepped back.  

"We've confirmed your genuine feelings, Yuu-sama and Sayaka.  
I apologize for the deliberately harsh approach to test you both."  
Tomoka bowed deeply.  

"No. I'm the one at fault. I suggested inviting Yuu-sama with this fake contract demanding parental rights surrender, forcing Tomoka into this unpleasant role.  
I'm truly sorry to you both."  
"Honestly, I did have slight doubts before meeting you, but Yuu-kun—the man Sayaka chose—is splendid. I apologize for doubting my own granddaughter."  

Reika and Yoshioki, and apparently Hikaru who'd been briefed beforehand, all bowed together.  
"P-please raise your heads!"  
"W-well... I was shocked, but I understand now!"  

At our flustered words, the four lifted their heads, exchanged glances, and smiled.  
Suddenly, a question occurred to me.  

"Um, what about the fiancé?"  
"Ah, we need to discuss that too."  
"Right."  

Tomoka and Hikaru nodded.  
Sayaka remained silent, listening.  

"Strengthening ties with the Osugi family—owners of a major electronics manufacturer—certainly benefited the Komatsu family.  
But we never intended to force marriage against Sayaka's feelings.  
Originally, the other party initiated this, so we agreed to observe until high school graduation.  
Ultimately, it depended on you two, Sayaka."  
"But..."  

"Exactly, I know. You tried awkwardly to get close.  
But while the mother was enthusiastic, the son himself was completely uninterested.  
Even if we forced marriage, I doubt it would've worked..."  
"Depending on Sayaka's feelings, we thought it might be better to cancel the engagement after graduation and let her seek new relationships.  
Now that Sayaka has found a suitable partner, we can completely nullify the engagement with the Osugi heir. Rather, we insist on it."  

Yuu and Sayaka felt relieved that their parents weren't rigid enough to decide marriages solely based on family or company interests.  

"And Yuu-sama."  
"Yes."  
"After hearing about you from Sayaka—though we had little time—we investigated.  
Your mother works at a newspaper company.  
And your father was the late Toyoda Sakuya."  
"Eh!? W-w-wait, you mean that..."  
"Sorry, I hadn't told Sayaka. Though I only learned about my father fairly recently myself."  

Sayaka was only 1-2 years old when Sakuya died.  
But she knew about him since he remained famous enough for regular TV and magazine features.  

Common knowledge:  
- Officially had 20 wives, countless lovers and casual partners  
- Accepted foreigners without hesitation  
- Fathered over 100 children (possibly 200+), though number of sons remains classified  
- Idolized by women since adolescence  
- Actively promoted gender interaction  
- Died after being accidentally stabbed while mediating a fight between wives  

"Yuu-kun's father... is that Toyoda Sakuya..."  

Seeing him in person and recalling Yuu's traits, Sayaka easily understood he'd inherited that bloodline.  

"Marriage isn't just about the couple's feelings—it's also about family connections.  
In that sense, voices still revere Sakuya among middle-aged to young elites in political and financial circles."  
"Yes, from that perspective, the Komatsu family welcomes rather than rejects ties with Yuu-sama."  

Reika and Tomoka looked at Yuu.  
Their expressions now clearly showed welcome, unlike before.  
Yuu was internally surprised his father's name came up again.  
Having never met him, he didn't know how to feel.  
But it was true that certain generations treated him as an idol or legend.  
If that benefited him now, he'd welcome it.  

"Um... anyway, you'll permit my relationship with Sayaka?"  
"Yes, of course. Please take good care of Sayaka."  
"Yes! I'll make her happy!"  
"Yuu-kun!"  

My affection only grew as Sayaka clung to my arm.  
I wanted to keep holding her, but it felt improper before family.  

"This brings back memories. Wasn't it around your second year of university, Tomoka?"  
"Eh!?"  
"Indeed. You suddenly brought Hikaru-kun, declaring 'I'm marrying this man!'  
Since you'd shown no interest in men before, it was truly a bolt from the blue."  
"Right. Your belly started swelling six months later."  
"Wa-wa-wa, stop talking about me!"  
"But I was the one who confessed. At first, I thought you were not just beautiful but quick-witted, dignified, and cool... but you were incredibly cute when we were alone."  
"Y-you!"  

Even Tomoka seemed embarrassed when their pre-marriage story came up.  
Her face flushed crimson as she lightly punched Hikaru to stop him—though it looked more like flirting.  

"Grandfather and Grandmother, how did you meet and marry?"  
"For us? Actually, we were childhood neighbors."  
"Childhood friends!?"  
"Then what happened?"  
"While we're at it, how did Mother and Father meet too!"  

When Sayaka suddenly asked, Reika stiffened trying to silence her husband, but too late.  
Yoshioki smiled and began talking while Yuu, Sayaka, and even Tomoka—glad for the topic shift—listened intently.  

"Since elementary school, I studied kendo at the Komatsu dojo despite being a boy.  
Sadly, I wasn't very skilled and quit after graduation.  
Then a girl—one of the top two kendo practitioners in the lower grades—told me:  
'I'll protect you, big brother. So please rest assured.'"  
"Ooh!"  
"St-stop it..."  

This time Reika flushed crimson and lowered her eyes.  

"Back then, except for some wealthy families, boys didn't have escorts to/from middle school—at most, mothers with free time accompanied them.  
This area was sparsely populated then, pitch-black at night and dangerous. So Reika went out of her way to accompany me daily. Her younger sister Ritsuka joined the next year.  
They actually fought off an adult stalker near our house once.  
How could I not adore such reliable, adorable childhood friends?  
After years together, we fell deeply in love. When Reika turned 18 and Ritsuka 17, I proposed to both."  
"Ufufu. Grandmothers, you..."  
"W-what?"  
"Are truly wonderful!"  
"I agree."  

In the suddenly warm atmosphere, Yuu recalled what he'd heard recently:  
"According to Komatsu family tradition, Yuu-kun is more suitable."  
Riko had said.  
Meaning the Komatsu family had generations of couples marrying young for love before having children.  

Holding Sayaka's shoulder, I whispered:  
"I truly want to become family with such wonderful people."  
"Yuu-kun... thank you."  
Sayaka closed her eyes, overcome with emotion, and rested her head on my shoulder.  

---

### Author's Afterword

About marriage in this world:  
In this female-centered society where women inherit households, wealthy families have the primary wife take a husband who adopts her surname.  
Second wives onward either live together or separately with the husband visiting on rotation.  
Sister marriage—where sisters both become wives—is also possible.  
Since one man has multiple wives, separate surnames for couples become common.  

Sayaka's mother, grandmother, and great-grandmother all took husbands.  
We haven't decided yet about surnames or living arrangements when Yuu marries the three women.  

2020/1/11  
Revised inconsistent pronouns for Sayaka's father and grandparents in the text.  
Also changed when Tomoka introduced Hikaru to her parents from first year to second year of university.

### Chapter Translation Notes
- Translated "婿に入れる" as "marry into the family" to convey the matrilineal marriage system
- Rendered "懐刀" as "kaidachi dagger" with transliteration since it's a culturally specific blade type
- Preserved Japanese honorifics (-sama, -kun) per translation rules
- Translated "大杉家" as "Osugi family" using standard Japanese surname romanization
- Maintained original name order (Komatsu Sayaka) throughout as required
- Translated "悪阻" as "morning sickness" for natural readability while retaining medical accuracy
- Kept "OB-GYN" as direct translation of "産科" since it's a precise medical term
- Translated "水を向ける" idiom as "brought up the subject" for natural English flow
- Rendered sound effects "シュッシュッ" as "*shu shu*" through transliteration
- Used "gender interaction" for "男女交流" to match established terminology in Fixed Terms