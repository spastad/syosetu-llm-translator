## 160. Visiting the Komatsu Family ③ ~Room and Dress Shirt and I~

After a while of pleasant conversation, it was decided to set a date for the engagement meeting involving Yuu and Sayaka, along with Riko and Emi, including all four sets of parents.  

The scheduled date was Sunday, August 12.  

Yuu could have asked Martina, but since Sayaka's mother Tomoka would serve as coordinator and wanted to discuss it first as part of the greeting, he decided to leave it to her.  

Incidentally, Tomoka seemed to already know about Riko and Emi.  

It felt strange to be praised with "As expected of Sakuya-san's son" for having three fiancées at age 16.  

In this world, it's not unheard of for underage boys (under 18) to have pre-marital relationships, but it's extremely rare to have impregnated three partners already.  

Even they said they only knew of Sakuya and Yuu who had done such a thing.  

If it became known that Yuu had sown his seed with many more than three, it wouldn't be surprising for him to be called Sakuya's reincarnation.  

The conversation settled around nearly 4 PM.  

Seizing the opportunity, they were invited to dinner.  

Yuu thought to decline, but when Sayaka joined in urging him, it became hard to refuse, and he ultimately accepted.  

However, Reika apparently had work engagements to attend.  

Normally, having a meal with her family right after meeting them would be tense, but perhaps because they'd talked for about two hours, he felt they'd grown quite close.  

Though Yuu himself wasn't originally skilled at communication, the fact they'd grown this close was largely due to Sayaka's father and grandfather being very approachable people.  

When Yuu was asked to call them "Mom" and "Dad," Hikaru and Tomoka rejoiced as if they'd gained a son.  

So he also began calling Reika and Yoshioki "Grandma" and "Grandpa."  

In return, Yuu requested they stop using formal honorifics and polite language that created distance.  

During the time before dinner preparations, Yuu expressed his desire to spend time in Sayaka's old room.  

Though he'd formed deep relationships with many women, Sayaka was the only one whose room he'd visited.  

In a world where boys can't casually visit girls' rooms, that was only natural.  

Therefore, he wanted to see her childhood room too.  

The second floor seemed to be a later addition, with brighter interior decor than the first floor, and the hallway, walls, and window frames gave a newer impression.  

Viewed from outside, the second floor seemed more compact compared to the first, but upon going up, it appeared much more spacious than an average home.  

Along the hallway immediately after ascending the stairs, three doors were visible, and more seemed to continue beyond the turn.  

"This is the room I used until middle school."  
"Th-then... I'll be intruding."  

The first impression of the 8-tatami mat room was that it was almost unnaturally tidy.  

Cleaning seemed thorough—not a single hair or speck of dust on the mats.  

With few belongings and no decorations, it felt devoid of lived-in atmosphere.  

That might be unavoidable.  

It had been two and a half years since she moved her base to the condo in Saito City.  

Since bedding was stored in the closet rather than having a bed, it felt even more spacious.  

The most noticeable items were an old, sturdy Japanese chest of drawers and the study desk she'd used until middle school.  

The navy blazer and skirt hanging on the wall hook were probably her middle school uniform.  

A framed certificate displayed on the lintel hinted at her glory days as kendo team captain, including prefectural tournament victories.  

"How is it? I imagine it's not very interesting."  
"No, not at all."  

Indeed, it was far from Yuu's image of a girl's room.  

But Yuu imagined it.  

The days young Sayaka spent in this room during elementary and middle school.  

Surely she was more serious and studious than Yuu, diligently training her body—a model student excelling in both academics and sports.  

But around puberty, she must have had various worries too.  

On the neatly organized desk shelf were several well-used dictionaries.  

Along with middle school atlases, reference books, and study guides apparently used for exams.  

The desktop was completely tidied and clean, but upon closer inspection, there were traces of peeled-off stickers.  

On the wall beside the desk hung a framed group photo of girls in kendo uniforms.  

A slightly more innocent-looking Sayaka sat in the center, holding a trophy with a smile.  

A small fox plushie dangling from a string below the fluorescent light.  

A section of tatami mat worn from friction.  

A mark on a pillar that seemed made by bumping something.  

Each detail seemed to testify to Sayaka's life here, filling him with deep emotion.  

Watching Yuu move around the room, sometimes touching things or gazing intently, Sayaka felt the same embarrassment as during her first experience.  

After Yuu had circled halfway through the room, he turned and looked at Sayaka.  

His expression overflowed with affection for his beloved.  

Despite the two-year age difference that should feel significant during teens, for some reason Sayaka felt enveloped by the sensation of being gazed upon by a much older man.  

"Yu, Yuu-kun?"  
"Sayaka, thank you. I'm glad I came."  
"Ah..."  

Yuu embraced Sayaka from the front.  

Feeling her overall toned yet characteristically soft feminine limbs while a wonderful fragrance tickled his nostrils.  

Her smooth, glossy hair made him want to stroke it forever.  

Her breasts swelling against his chest through her blouse felt wonderful.  

Thanks to the AC turned on when they entered, the room was comfortably cool, but feeling each other's body heat, they gradually grew warmer.  

For a while, they caressed each other's bodies with hands on backs, cheeks pressed together, but eventually they faced each other.  

Gazing at each other so closely that Yuu's face reflected in Sayaka's large black eyes, her fair skin flushed faintly pink.  

"Sayaka, I love you."  
"Yuu-kun, me too."  

Their lips drew together as if pulled, emotions surging as their embracing arms tightened.  

While kissing repeatedly, changing angles, Yuu's right hand combed through Sayaka's long black hair, fingertips stroking her nape through the strands.  

His left hand moved from her slender waist to her buttocks, kneading with moderate pressure.  

"Haaahn!"  

Sayaka, who'd been caressing Yuu's head, back, and buttocks, couldn't help but let out a sensual sigh.  

Just from this, her private parts were already growing hot and moist.  

Sayaka and Yuu looked at each other through half-lidded eyes.  

"How's the morning sickness today?"  
"U, un. It finally settled down after August started. My appetite still isn't great, but I have fewer anemia episodes... Especially today, maybe because I got to see Yuu-kun. I'm feeling good."  
"That's good. Seeing you unwell since last month had me worried sick."  
"Sorry for making you worry."  
"Don't mind it. I just care deeply about you."  
"Ann!"  

Yuu's right hand reached Sayaka's chest, cupping and gently kneading a soft mound.  

Simultaneously, Yuu's tongue pried open Sayaka's lips, invading her mouth.  

When their tongues touched, Sayaka closed her eyes and entwined hers in return.  

Then, putting strength into the left arm around her waist, he gradually lowered her.  

With almost no height difference, the long-trained Sayaka would likely be stronger if they wrestled.  

But once things reached this point, Sayaka yielded to Yuu's lead.  

"Amu...n...chupa...hafu...nna...ann! Yu, Yuu-kun...the family might hear..."  
"That might be true, but I haven't been with Sayaka for so long. I don't think I can hold back, sorry."  
"That...I feel the same...so...nchu, chu, chupaa...ahh, Yuu-kun!"  
"Sayaka!"  

In a position almost like facing intercourse, Sayaka straddled him, clinging to Yuu's head, burning with even more passion as she desired him.  

While Sayaka covered Yuu's forehead, nose, cheeks—his entire face—with kisses, Yuu's right hand deftly undid the second and third buttons of her blouse and slipped inside.  

"Ann!"  

Fingertips touching smooth, moist skin slipped between the bra cups, directly savoring the softness of her breast before touching her nipple.  

"Your nipple's erect."  
"Nfuu...Yu, Yuu-kun's cock is...hardening too..."  
"Well of course. I'm with such a wonderful woman."  
"Ahh...I can feel it...there. Haaan..."  

When straddling him, Sayaka had spread her skirt to press her panty-covered crotch against him, but now her female instincts drove her to begin grinding her hips back and forth.  

In return, she began undoing the buttons of Yuu's white dress shirt one by one.  

From pecking kisses to tongues poking at each other like animals greeting, then developing into deep kisses with lewd wet sounds as Yuu's tongue stretched out to fill her mouth.  

While mutually touching each other's bare chests and engrossed in exchanging saliva, Yuu and Sayaka suddenly stopped moving at a clattering sound.  

"What was that?"  
"......Could you wait a moment?"  

Though she'd seemed feverish moments ago, Sayaka suddenly turned calm, lifting her hips away.  

Yuu felt lonely at the loss of warmth, but Sayaka seemed preoccupied as she silently slid to the door and abruptly flung it open.  

"Kiyoka!"  
"Ah!"  
"A-and Mother...Great-aunt too!?"  
"My my, we've been caught."  
"Hmm. In place of my sister who went out, I thought I'd witness how close you two were."  
"Wh, wha..."  
"Well then, let me see the face of Sayaka's new fiancé."  
"Eh, wait!"  

Unseen from Yuu's position, three generations of women had apparently been eavesdropping right outside the door.  

The men seemed absent, as expected.  

Women apparently have stronger curiosity at such times.  

Stepping in past Sayaka was an elderly woman with completely white hair tied back—or rather, a dignified presence like an ancient samurai.  

Since he'd heard Sayaka say "Great-aunt," this must be Ritsuka, younger sister of Sayaka's grandmother Reika and a dojo instructor.  

Yuu straightened his posture and bowed, and she grinned.  

"Oh my, what a fine man. Reminds me of Yoshioki-san in his youth."  
"I, is that so..."  

Tomoka apparently hesitated to show herself and left.  

Meanwhile, Kiyoka popped her face in and beamed a radiant smile.  

"Yuu-sama!"  
"Hey, Kiyoka-chan. Long time no see."  
"Waha!"  

Before Sayaka could stop her, Kiyoka scurried over and immediately climbed onto the kneeling Yuu's lap, hugging him.  

"Ufu. Yuu-sama's scent."  
"Ki, Kiyoka!"  

Kiyoka in her pure white dress buried her face in Yuu's exposed chest and began sniffing his skin.  

While most boys her age would recoil at such behavior, Yuu welcomed it.  

Rather, feeling her small-animal-like adorableness, Yuu smiled and stroked her glossy black hair like her sister's.  

"Hohou. Kiyoka already adores him? Then perhaps you'll have a sister marriage like us in the future."  
"...Even so, isn't it too soon?"  
"We started seeing Yoshioki-san as a man and liking him around 12 or 13, so it's not too early."  
"Is...that so. Well, true."  

Kiyoka had lost her virginity to Yuu during the late-night visit at Sayaka's condo during the birthday party in mid-June.  

The likelihood of Kiyoka meeting a man more attractive than Yuu and developing a relationship was low—she might continue loving her first man forever.  

Sayaka herself knew this firsthand.  

Since sister marriages like her grandfather, grandmother, and great-aunt were perfectly normal, she wasn't unwilling to accept it—but having her long-awaited intimate time with Yuu interrupted left her with complicated feelings.  

"Why hesitate?"  
"Great-aunt?"  

Sayaka was suddenly slapped on the back.  

"Fighting too much and troubling men is unacceptable, but otherwise, no need to hold back. Sisters should love and be loved by a man together."  
"Ye, yes. Great-aunt...no, Instructor!"  

Ritsuka smiled as she watched Sayaka head toward Yuu, then closed the door.  

"Yuu-kun!"  
"Sayaka, I've been waiting."  

When Yuu raised his left hand, Kiyoka moved aside to his right.  

Sayaka threw herself into Yuu's embrace there.  

Yuu was in heaven being hugged by the beautiful sisters.  

Though Kiyoka's physique made her look more like a fifth or sixth grader than a middle schooler, her shoulder-baring dress emitted a pure sensuality.  

Perhaps that was because Yuu had made her a "woman."  

Though flat-chested, pressed tightly against him, something bubbled hotly inside Yuu.  

But as the door closed with a bang, it was Sayaka who touched Yuu's cheek and claimed his lips.  

Not only did she invade his mouth with her tongue as if continuing where they left off, but her other hand reached for his crotch, stimulating his manhood that was hardening again.  

"Ann, not just my sister...I want to too."  
"Nmu...chupurelo...npa. Ahh, Kiyoka-chan, let's kiss too."  
"Yes!"  

Yuu kissed Kiyoka alternately with Sayaka as she brought her face close.  

Both hands gently stroked their hair.  

Realizing where her sister was touching, Kiyoka also reached for his crotch—his cock, rubbed by both, became fully erect to the point of straining his pants.  

Suddenly, the door was knocked.  
"Who now...?"  

Even Sayaka seemed displeased at the interruption.  

But this time, it apparently wasn't family.  
"Miss Sayaka, there's a call from Sairei Academy's administrative office."  

What could it be at a time like this?  

Suspicious but straightening her clothes, Sayaka slid open the door and took the cordless phone from a maid-like woman.  

"I've taken the call. This is Komatsu Sayaka.  
Yes. Yes. Ha............Eh, really!?"  

Seeing usually composed Sayaka change color, Yuu wondered what could be happening.  

After hanging up, Sayaka turned to Yuu.  

"Saiei Academy's student council president, Mitsuse Rinne, has reportedly purchased the rights of the first and third place winners in the quiz championship individual division and wishes to meet you, Yuu-kun."  

---

### Author's Afterword

Sayaka's sister Kiyoka made her first appearance in a long time.  
It's been since the latter part of Chapter 3 - Birthday Party Arc (Chapters 97-100).  
Unfortunately, it didn't lead to a threesome...

### Chapter Translation Notes
- Translated "Yシャツ" as "dress shirt" to match formal context
- Preserved Japanese honorifics (-kun, -sama, -san) per style rules
- Translated explicit anatomical/sexual terms directly ("cock", "pussy")
- Maintained Japanese name order (Komatsu Sayaka)
- Transliterated sound effects (e.g., "Ann!" for あんっ)
- Italicized internal monologues per style guide
- Used ""..."" formatting for simultaneous dialogue attribution