## 161. The Young Lady Falls ① ~Stealing Love, Binding the Body~

The special open campus event held by Saiei Academy to invite Sairei male students.

The morning featured performances by music department students. Afternoon included department/course and club observations.

Thanks to thorough advance warnings and security - plus Sairei bringing five times more female students and guards than males - no male students got caught in trouble, ending safely.

Saiei Academy apparently aimed to make male-invitation events regular, taking care to avoid stumbling in the first attempt.

That was the official outcome.

Yuu and others invited to the student council room likely had sleeping drugs mixed in their drinks. Sayaka and the other three girls fell asleep, but Yuu alone became extremely excited.

Perhaps they intended to restrain Yuu after making him sleep, rape him as they pleased, and train him to obey henceforth.

But in the basement they took him to, Yuu ended up raping them repeatedly instead.

Essentially, he broke through the prepared trap.

Just before leaving, Yuu received an apology from Amir and obtained the empty wrapper and drug itself, but evidence linking to the student council president would likely never surface.

Even if legal recourse was difficult, Yuu wondered if he could make their student council reflect and extract apologies for Sayaka and others.

But for Yuu, the fact of Sayaka and others' pregnancies was more important, pushing the Saiei student council matter aside.

Then came a sudden summons.

Yuu wondered what expression Rinne would show when meeting him.

The location Rinne specified through Sairei Academy's administration office turned out connected to the Mitsuse family's hotel group. After consulting Sayaka's mother and grandmother, they changed it to a hotel in Kawagoe City belonging to a corporate group where Komatsu is a major shareholder.

Time-wise it seemed intended for dinner, but Yuu thought it better to get straight to business, requesting an early afternoon meeting instead of evening. Additionally, only Rinne would come. Yuu replied he wanted to meet just the two of them.

Then, Yuu and Sayaka began detailed preparations for the day.

***

Around 1:30 PM on Tuesday, August 7, after the week began.

The car carrying Yuu arrived at the hotel's underground parking lot.

As soon as Yuu got out, Kanako and Touko flanked him left and right.

Colleague protection officers who seemed to have been waiting after receiving notice approached and spoke.

"Checking the guest register showed no suspicious group bookings, and no suspicious persons in the lobby etc. As precaution, we're stationed on the relevant floor keeping watch."

"Thank you. That's reassuring. Your continued assistance is appreciated."

When Yuu smiled gratefully, the tough-looking protection officer's expression softened.

Thanks to lax personal information protection regarding women, they could investigate beforehand. Reika personally arranged flexibility with the manager here.

It wouldn't be surprising if Rinne tried trapping Yuu again. Though caught off-guard at Saiei's student council room, better safe than sorry this time. Yuu promptly leveraged his fiancée's connections.

"Are you truly alright? Perhaps we should inspect the room just in case..."

"No, just to the entrance is fine. I changed the time and place on condition we meet alone. After that..."

Front desk staff and other hotel employees confirmed Rinne got out of a car alone, checked in, and entered the room. No signs of anyone joining later.

Then Yuu only needed to enter the room where Rinne waited as agreed. After asking Kanako to relay one message, Yuu knocked.

"What is this room!? I entered thinking it was the highest grade... Had I known, Sunshine Hotel's royal suite would've been infinitely more comfortable!"

Rinne immediately snapped upon entry.

Though Yuu had tasted some luxury since rebirth, his commoner sensibilities remained stronger. This deluxe double room seemed priced for special occasions by general economic standards. But Rinne, being an ojou-sama, appeared quite dissatisfied.

Pouting angrily, Rinne returned inside, arms crossed as she stood by the window. Her attire today was a crimson knit dress. Had it been dinner as originally planned, she might have dressed up in formal wear. But since meals were unnecessary, simpler clothing. Still, the bodycon minidress accentuated Rinne's figure. While her bust size rivaled Sayaka's, Rinne's slimmer frame made her chest and buttocks stand out more in the tight wine-red dress. Bare thighs and long slender legs. Wearing high-heeled pumps, her gorgeous legs threatened to draw the eye.

Her usual back-length hair had a coppery beige tint with fluffy waves from midway down, while the front-hanging sections had vertical rolls - resembling hairstyles common among female college students and office ladies before Yuu's rebirth. Heavy eyeshadow made long eyelashes stand out, emphasizing her wide eyes. Lips were a vivid deep pink. Overall exuding a sensuality unbecoming of a high schooler.

Though tempted to keep gazing, Yuu feigned nonchalance and sat on the provided sofa. Seeing this, Rinne stopped complaining and sat opposite, crossing her legs elegantly. When her thighs parted dangerously, Yuu recalled pinning her down for creampie after creampie until she lost consciousness. Rinne's vaginal depths had felt exquisite then. His crotch threatened to react. Coughing to disguise it, Yuu stared at Rinne - still with arms crossed, back arched to emphasize her chest - and spoke.

"So, what's today's business?"

"......"

At Yuu's blunt question without preamble, Rinne furrowed her brow and scowled. Yuu had many things to say but knew it'd be endless, so he wanted to hear her business first. Rinne averted her eyes instead of answering immediately.

"Shan't we have drinks first? Let's see, the room service menu..."

"Nah, I'm good. I'll pick something casually. Wouldn't want anything slipped in while distracted."

"Wha-!?"

Smirking faintly as he cautioned, Yuu opened the room's refrigerator. Once opened, items couldn't be returned, and he lacked skills to reseal bottles or cans perfectly. Still checking methodically, Yuu took out a bottled oolong tea. Rinne reluctantly nodded when asked, so he got the same. But when he tried handing it, she wouldn't take it. After brief thought, Yuu uncapped it, poured into a glass, placed it on the table, and finally Rinne nodded satisfied.

While Rinne drank elegantly without sound, Yuu gulped oolong tea straight from the bottle. After moistening his throat, Rinne looked at Yuu and spoke.

"I shall state directly. I, Mitsuse Rinne, shall make Hirose Yuu... m-my engagement candidate. Feel honored. Oh-hohohohoho..."

Somehow posing with her right hand raised near her mouth, palm inward, Rinne laughed loudly. But her eyes weren't smiling.

"But I refuse."

"Hohoho-... huh?"

When Yuu said the line he'd always wanted to utter, Rinne's laughter stopped.

"Wha-wha-what did you say!? I-I... granddaughter of the Nikko Group CEO, a conglomerate representing Japan... am personally making you my engagement candidate!"

"Conversely, why make me your candidate? I'm curious about your reasons."

"W-well..."

When Yuu pressed, Rinne flushed and fell silent. Yuu placed his bottle on the table, leaned forward, and raked his eyes over Rinne's body from head to toe.

"Shall I make one prediction?"

"Huh..."

"Sex."

"Ugh."

"Creampie."

"Ahh!"

Writhing as if refusing, Rinne shook her head sideways but glared defiantly at Yuu.

"Y-yes! That time's... s-sexual act - too vulgar to call it that - beast-like coupling... ghh, but... since then I... couldn't get it out of my head, my lower belly aches whenever I remember... Your... hot... hot semen flooding my womb... pleasure so intense I lost consciousness... Ahh, what a terrible gentleman..."

Rinne placed both hands on the table and slumped forward. Then, barely audibly, she murmured.

"Because of you, our student council is in shambles. Wei Hui won't respond to summons, shut in her room. Norika's words and actions turned strange, plus she's on bad terms with her health committee subordinates. Even the secretary and accountant girls stopped obeying..."

"But I think that's all the result of your scheming."

"Th-that is..."

"Well, sex with Rinne did feel amazing. I rarely ejaculate continuously without pulling out."

"Ah..."

Casually, Yuu extended his right hand to stroke Rinne's cheek, ear, and neck. "Fah... ah... hah... un..." For Rinne, being touched by a male like this was unprecedented. Merely having fingertips caress her skin made Rinne shiver pleasantly, letting out sensual moans as she squirmed.

"Ne... eh..."

Eyes moist, Rinne closed her eyes and leaned her face closer. But Yuu didn't respond, standing up smoothly instead.

"Want it?"

"Ghh... y-yes! Forget formalities or the future, I don't care anymore. Do me... like that time again."

"Then strip. Everything."

"Huh?"

Males Rinne dealt with before were obedient - naturally, since prepped by mothers/grandmothers - behaving as she wished, trying to satisfy selfish lusts, disappointing her.

But Yuu kept disrupting her pace since earlier. Today differed from his gentle, accepting impression during Sairei visit. Moreover, she just realized: he called her without honorifics. Strangely, it felt pleasant.

Standing smoothly, Rinne began stripping her dress before Yuu without hesitation. Underneath was white silk lingerie with lavish frills - clearly high-end. Last time was white too, perhaps her preference. Leaning slightly forward, she unhooked the full-cup bra, letting ample breasts spill free. Immediately sliding panties down, revealing a neatly trimmed delta zone. Fully nude, Rinne straightened her back, making breasts jiggle. While women in this world tend to feel ashamed of large breasts, Rinne seemed exempt, arching her back to provocatively thrust them forward.

"Now, I'm undressed. Your turn. Hah, hah."

"Mm. But first."

Alone in the room. Yuu stood close enough to touch, Rinne breathing heavily as if unable to contain rising desire. Yet Yuu remained calm. During her striptease, he opened his shoulder bag and retrieved something, holding it behind his back as he approached. When Rinne spread arms to embrace him, Yuu dodged, taking her back, surprising her.

"Wh-what are- GYAH!"

"Now then, let's have you behave."

What Yuu prepared was the red SM rope Saira brought previously for Elena. Having practiced on his sister, Yuu swiftly bound Rinne's hands behind her back.

"Nooo! Hey... why this...?"

Ignoring protests, Yuu wrapped rope around her breasts above and below the bound arms, completing a reverse tie. Fortunately, Rinne didn't struggle much after initial restraint, though avoiding tangling her long hair proved troublesome.

"Upper body's done."

"D-do you think this is forgivable!?"

"Don't be like that. It's part of play. Know about SM?"

"Hah!? Agh!"

Yuu momentarily released the rope, embraced from behind, and roughly groped both breasts.

"GYAH... nnn! Ah... ahi... hyan... un... uun..."

"Fufu. Now then..."

Seeing Rinne moan as he kneaded, Yuu smirked and entangled his legs to bend her knees. Simultaneously pressing down on her shoulder, he gradually lowered her butt to the floor. Knees bent, legs slanted together.

"Wh-what more...?"

Rinne's flushed face showed not refusal but mingled terror of the unknown and anticipation of pleasure. Without answering, Yuu moved her upper body against the sofa back to prevent falling. With rope length to spare from arm binding, he loosely tied it to the sofa leg. Taking two new ropes from his bag, Yuu knelt before Rinne.

"Spread your legs wide."

"......"

"C'mon, spread them!"

"Noo!"

At this stage, why the modesty? Yuu grabbed both ankles and forcibly spread them into an M-shape. Spread that wide, her slit naturally parted, revealing a beautiful salmon-pink vaginal opening. Yuu's crotch was already hard. He wanted to plunge in and savor that exquisite pussy, but for now, he must achieve his goal.

"Oww... st-stop please..."

Perhaps Yuu's hands grew rough restraining his lust. Rinne let out a weak voice. Undeterred, Yuu bound her calves and thighs tightly together at two points - near knees and calves.

"Such... humiliation for me... agh! Hah, hah, nnn!"

"Mm, this should do."

Kneeling on one knee, Yuu observed Rinne's lewd state. Teary-eyed Rinne glared resentfully, but as the ropes dug into her fair skin, tightening her restraints, she began emitting lustful whimpers. Perhaps she had masochistic tendencies?

Arm binding was manageable, but leg binding was less practiced. Fortunately, the SM primer Elena bought had simple methods. Now Rinne was helpless, legs spread, ready to be ravished. Testing leg movement, they wouldn't loosen soon.

"Great position. Wonderful."

"Ghh! If we're having sex anyway, why this trouble?"

"Ah, but there is."

Yuu pushed apart Rinne's trying-to-close legs, kneeling between them, and reached out.

"AGHUN!"

He kneaded breasts emphasized by the horizontal ropes. Not just kneading - pinching nipples between fingers to pull, teasing with fingertips. Yuu brought his face close, kissing and caressing from collarbone to neck.

"Bound people can feel it too. How's this? Nchurerorero."

"Th-this can't... make me... hyaun!"

"Your nipples hardened already. Sensitive, Rinne?"

"N-no... ahhn!"

Enjoying Rinne's perfume, Yuu licked up her neck with wet sounds, sucking her earlobe whole. Tongue boldly licking the entire ear. Simultaneously, as fingers twisted, kneaded, and pulled nipples, Rinne's moans intensified. She never thought herself particularly sensitive despite strong libido - past partners were inexperienced, passive, and unskilled, so she never knew true caresses.

"No no, quite sensitive. With such an erotic body, crying out so nicely. Unbearable."

"Ah... ahh... hah... n."

Stared at by the slightly risen Yuu, Rinne felt unprecedented shyness, cheeks reddening. Smirking, Yuu opened his mouth and sucked on the trembling nipple.

"HYAUN! Ah... ahhaa... nipple... gooood... hya... AGHN!"

Schlup schlup lero churun - loud sucking sounds as he sucked and pulled the nipple. Simultaneously, Yuu's right hand slid down, reaching the lower abdomen, but only slowly traced around the crucial area - labia majora, groin, inner thighs.

"Ah... ahh... don't tease... there... touch meee... ahh..."

As if drooling from her lower mouth, love juice overflowed from her vagina, staining the carpet. While sucking and nibbling nipples, Yuu shifted gaze downward. Rinne writhed her hips as if yearning for him. Casually placing his right middle finger at her slit center, he wiggled slightly.

"HAAAHN!"

Instantly, love juice coated his entire finger. Stimulating the clitoris with squelching fingertip movements, Rinne threw her head back, moaning.

"Ah, ah, good! Feels good! Ah, there... hii... n, n, afu... ah, ah, ah, AAH!"

Despite not taking much time, Rinne rapidly heightened under Yuu's caresses. While the previous rough sex gave intense shock, being caressed like this to blossom in feminine pleasure was also new, and she seemed quite delighted.

Meanwhile, Yuu continued caresses while calmly observing Rinne. "Ah, ah, ahn! Good, good, already... I-I... I'm... cu... CUMMING... huh?"

At the brink of climax, Yuu withdrew his hand. Rinne stared blankly.

"Why... did you stop...?"

"After all, this is just the prelude. Can't let you cum yet."

"Eh... why?"

Without answering, Yuu stood and walked away, vanishing from Rinne's sight. Then came the clatter of a door opening. Still confused, Rinne saw Yuu return before her. Not just Yuu. Following behind appeared Sayaka.

***

### Author's Afterword

The subtitle totally spoils future developments...

### Chapter Translation Notes
- Translated "ニットワンピース" as "knit dress" maintaining fabric specificity
- Rendered "ボディコン" as "bodycon" following fashion terminology conventions
- Preserved aristocratic speech patterns ("ですわ"/"ですの") in Rinne's dialogue
- Translated "縦ロール" as "vertical rolls" describing hairstyle accurately
- Used explicit anatomical terms ("clitoris", "labia majora") per style rules
- Transliterated sound effects: "ゴクゴク" → "gulp gulp", "ちゅぱちゅぱ" → "schlup schlup"
- Maintained Japanese name order: "Mitsuse Rinne" throughout
- Italicized internal monologues per formatting rules
- Applied simultaneous dialogue formatting ""..."" for overlapping speech