## 162. The Young Lady Falls ② ~Two Are Lovers~

Rinne's expression when Sayaka appeared was truly priceless.

Her mouth hung open in a dumbfounded gape that wouldn't close.

"Wh-why? Weren't you supposed to meet alone!?"

"We did meet alone. But I never said no one would join later."

"That's unfair!"

One could call it sophistry, but Yuu would've been fine inviting the entire Sairei student council. Though admittedly, Sayaka was the only one available today.

Sayaka wore a blue sleeveless blouse with a beige long pencil skirt featuring a tantalizing slit above the knees, paired with light blue pumps. Her long black hair was tied with a white scrunchie and draped forward over her shoulder - a hairstyle similar to Riko's usual look. The summery colors accentuated her figure, making her outfit as stylish and mature as Rinne's.

After approaching Yuu, Sayaka glanced sideways at Rinne who was splayed obscenely with legs spread wide and declared:

"After receiving such 'hospitality' the other day, you left without a word. I've come representing the Sairei student council to voice our complaint."

"Kuh...uu..."

Rinne clearly had thoughts about this. She averted her eyes and struggled, but bound hand and foot, she could do nothing. Yuu extended his right hand around Sayaka's shoulder as Rinne watched. Sayaka smiled happily, resting her head against him while wrapping her left arm around his waist.

"Let me introduce my fiancée Sayaka. We've decided she'll become my first wife in the near future."

"Ufufu~"

"Haaah!?"

Rinne lifted her head and gasped at the intimate pair. Though only verbal approval had been given by Sayaka's family without formal documents, Yuu saw no need to explain that.

"B-but...your engagement with the Osugi family-"

"Mother declined that engagement and arranged my new engagement with Yuu-kun instead."

"Indeed. We're officially recognized by both families now. We'll likely formally marry after Sayaka graduates."

"Wha..."

Polygamy was permitted, but this still shocked Rinne. Four days ago, she'd tried to claim Yuu only to be overpowered and violated. Today she'd planned to bond with Yuu at her own pace.

"I brought Sayaka here for a purpose. Regarding the student council room incident - I want Rinne, as Saiei Academy's president, to apologize to Sayaka and the others."

Rinne immediately turned her face away with a pout. She clearly didn't want this topic raised.

"After drinking tea that day, I suddenly felt drowsy and have no memory until Yuu-kun woke me."

"You drugged it, didn't you? Before leaving, I confronted Amir and obtained physical evidence. This constitutes a clear crime."

"Wh-what nonsense! Are you framing me? The Mitsuse family won't tolerate this!"

Actually, Amir had confessed voluntarily, but Yuu claimed he'd extracted the confession to protect the boy. There was likely no evidence directly linking to Rinne. In Yuu's original 21st century, phone records could've confirmed it, but here only internal calls existed - Amir didn't even know who gave the order. Sensing this, Rinne arrogantly lifted her chin.

"Admittedly, it's circumstantial without direct proof."

"Then-!"

"But your reaction when only I remained conscious, and the Health Committee members' words when we descended - it's obvious you three masterminded the plan to drug us all and take us underground."

"Guh..."

Sayaka's arm tightened around Yuu's waist. Had Rinne succeeded, who knows what might've happened? Though restraining herself for Yuu's sake, Sayaka was undoubtedly seething.

"Without evidence, I won't involve police. But as representatives of our student councils, I want Rinne to sincerely apologize to Sayaka."

When Yuu looked at Sayaka, she nodded slightly. She had much to say to Rinne, but female arguments risked escalating to violence. Hence she deferred to Yuu.

Rinne mumbled protests but eventually fell silent under their combined gaze, stubborn pride preventing apology. Yuu sighed - he'd hoped facing Sayaka might elicit remorse.

"Sayaka, shall we continue from last time? That bed looks conveniently placed."

"Yu-Yuu-kun?"

Yuu turned to face Sayaka directly, playing with the hair draped over her shoulder before cupping her cheek. As he leaned toward her faintly blushing lips, Sayaka closed her eyes and embraced him tightly, seeking his kiss.

After prolonged kissing with repeated angle changes, their lips parted to reveal Sayaka's flushed cheeks.

"Better late than never - are you feeling alright physically?"

"Mhm... Strangely, I feel fine when with Yuu-kun."

"Good to hear."

"B-but I'm sweaty, I should shower-"

"No. I can't wait."

"Ahn~"

Still embracing, they stumbled toward the bed in a tangled embrace.

"Uu... So cruel..."

Rinne bit her lip resentfully watching them depart, but Yuu and Sayaka had already entered their own world.

***

"Here, let me undress you before your clothes wrinkle."

"Yu-Yuu-kun, I can undress myse- hyah!? Not there... Ah, sweat... Ah... Nnnn!"

"Nnfu, I actually like your sweat's scent."

Seated side-by-side on the bed's edge deliberately within Rinne's view, they kissed passionately while embracing. Yuu raised Sayaka's left arm, licking her neatly groomed armpit as he unbuttoned her blouse.

Beyond licking, he began sucking, revealing a white-and-light-blue striped bra. Though Yuu always took time with foreplay, having her armpit licked was new - even Sayaka flushed crimson from both shame and unexpected pleasure.

"Yuu-kun!"

"Nn!"

Now Sayaka buried her face in Yuu's neck, licking while hiking up his polo shirt.

"Mufuu... Smelling your skin makes me dizzy... I feel like losing myself. Ah... Nn, chu~"

"Haha, that tickles!"

Most girls Yuu slept with grew aroused smelling him - something he hadn't experienced in his previous life with fewer partners. Perhaps women naturally had this tendency, amplified in this chastity-reversed world where females objectified males sexually.

That said, Yuu adored girls' scents too. After unbuttoning the blouse, he unhooked her bra. As the cups released, shapely voluptuous breasts tumbled free. Yuu buried his face between them - the milky scent brought comfort, making him want to linger. He shifted to suckle a nipple like an infant.

"Anh! Stop, Yuu-kun, you're preventing me from undressing you. Lift your arms."

"Whoops!"

"Arms up!"

"Haha, arms up!"

Though Sayaka had pulled the shirt to chest-level, Yuu's suckling prevented removal. When he released her breast, she swiftly removed his polo shirt. Then Sayaka began sucking Yuu's nipple.

Amid such playful intimacy, they undressed each other. Both topless, they embraced again, aroused by skin contact, kissing passionately while competing to caress each other's bodies. Without Riko or Emi, this was their first private intimacy in ages - a thorough mutual rediscovery.

Unable to watch, Rinne averted her eyes, but Yuu's pleasured moans at Sayaka's touch drew her gaze back, making her body ache. This cycle repeated constantly.

"Fufufu, your panties are soaked. What's happening down there?"

"Nnn! Ah, ahfuhn... Yuu-kun's cock is so hard too. Nn, nchu... Lero~"

Yuu traced the wet stain on Sayaka's crotch while her palm rubbed the tented bulge in his pants, precum forming a spreading circle.

"Let's remove them together."

"Ah, together."

"On three."

When Yuu pulled down Sayaka's panties, a transparent thread stretched from vagina to crotch. As Sayaka stretched his waistband, his cock sprang free.

"Aah..."

Though 2 meters away, Rinne stared directly at the erect penis with a sigh. But it was Sayaka who touched it, bringing her face close to sniff.

Deliberately visible to Rinne, they sat side-by-side on the bed's edge with legs spread, fondling each other's genitals while deep kissing.

"Nn... nchu... chupaa... Ah, aahn! Wh-why? I'm so sensitive... Hauuuu, th-there... No! Ah! Feels... too good!"

"Haa, haa. I want to make you feel more, Sayaka. Making up for lost time... Uk! Ah, Sayaka!"

"Yu, Yuu-kun... M-more than that... Ah! Ah! Aah!"

While tongues flickered and lips pressed wetly, their mutual fondling continued uninterrupted. Intermittent squelching sounds came from Sayaka's pussy as juices stained the sheets, while Yuu's cock made lewd squishing noises with each stroke of Sayaka's hand.

"Hah... Aah... Nn! Nn! I-I'm cumming... Cumming! Ah... Yuu-kun!"  
"It's okay. Cum, Sayaka."

Having shifted focus from vaginal opening to clitoris, Yuu rubbed insistently until Sayaka neared climax first. He pulled her trembling shoulders against his chest.

"Fah... Ah! Nkuu! I-I'm... Ah, cumming... Ah... Cumming! Ah! Aahhaaaaahn!"

***

"Haa, haa... T-too... good... I almost... lost consciousness..."

"Hmm, maybe because you're pregnant?"

"Not sure. Maybe it's because it's been so long... and the relief of being able to love Yuu-kun without reservations..."

Smiling, Sayaka wrapped her arms around Yuu's head, hugging him to her chest.

"An unusually strong desire is welling up inside me now."

"What is it? Tell me anything."

"Okay, no holding back then. I want Yuu-kun's cock. I can't wait any longer to feel it inside me. I can't hold back anymore."

While stroking Yuu's head, Sayaka whispered with refreshing directness, pushing him down while clinging to him. Yuu naturally didn't refuse, smiling as he replied.

"Understood. You take the lead first. But tell me if it gets too much."

"Fu, fu, fu. Don't worry. I'm in perfect condition today, and unusually excited."

Indeed, such overt aggressiveness was rare for Sayaka. Breathing heavily as she gazed at Yuu, she'd transformed into pure lust. She immediately positioned herself to align his cock with her entrance. The gap between Sayaka's usually dignified demeanor and this wanton desperation was intensely arousing. With ample time today, Yuu planned to indulge her fully - and it perfectly served to torment Rinne.

Though Yuu couldn't see from his supine position, Rinne had a clear view of the imminent penetration, unable to look away.

### Chapter Translation Notes
- Translated "痴態を晒している" as "splayed obscenely" to convey the explicit nature of Rinne's bound position
- Rendered sexual sounds literally: "くちゅくちゅ" → "squelching", "ぬちゃぬちゃ" → "lewd squishing noises"
- Preserved Japanese honorifics (-kun) and name order (Komatsu Sayaka)
- Translated explicit anatomical terms directly: "膣口" → "vaginal opening", "クリトリス" → "clitoris"
- Maintained original dialogue formatting with new paragraphs for each speaker
- Italicized internal thoughts: "（ち、近い！）" → *C-close!* (though none present in this segment)
- Transliterated sound effects: "ぷぃっと" → "with a pout", "ぽろり" → "tumbled free"