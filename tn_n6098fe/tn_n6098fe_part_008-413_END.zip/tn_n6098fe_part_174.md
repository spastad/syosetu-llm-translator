## 163. The Young Lady Falls ③ ~Boundary Line~

### Author's Preface

The first half is mainly from Rinne's perspective.

---

To ordinary people it would seem sufficiently luxurious, but to Rinne—a wealthy young lady—the deluxe double room didn't feel particularly spacious.  

Bound tightly with both hands behind her back against the sofa and legs spread open in a frogtie position, Rinne was forced to watch from her humiliating naked position as Sayaka straddled Yuu on the opposite bed, enthusiastically rocking her hips.  

The moment she was fully penetrated, Sayaka came lightly and trembled *purupuru* before covering Yuu and showering him with fierce kisses.  
Yuu responded in kind, and soon they were moving together in synchronized thrusts.  
They looked exactly like passionate lovers perfectly in tune, radiating an atmosphere of mutual pleasure.  

Now Sayaka's moans intensified again as she reached climax while holding Yuu's hands in a lover's clasp.  
Tilting her head back, she repeatedly cried Yuu's name before collapsing onto his chest.  
But Yuu seemed far from finished, wrapping his hands around Sayaka's waist as he slowly thrust upward.  
From their joined parts, his thick, sturdy cock stretched her labia wide with each movement, glistening wetly.  
Even from her position, Rinne could see the slightly cloudy fluid splattering around them.  

Rinne could only stare at this scene.  
This should have been *her* riding Yuu, not Sayaka... How had things come to this?  

*(Ever since my first heartbreak...)*  

After her first love ended badly, Rinne had repeated arranged encounters with boys at birthday parties.  
But without exception, she'd been disappointed after just one sexual encounter and discarded them.  
Influenced by novels and manga she'd secretly read since childhood, Rinne preferred boys in their early to mid-teens.  
But in reality, boys that age had little sexual experience, were emotionally fragile and selfish. During sex they remained passive, never considering their partner's pleasure.  

Finding someone who could satisfy Rinne both physically and skillfully was like searching for one in a million.  
Lately, nearing adulthood, Rinne had focused on nurturing beautiful boys just entering their teens—specifically seeking boys from impoverished refugee families who'd feel indebted to her.  
Amir from the student council room clearly felt gratitude and loyalty toward her.  
The problem was Norika openly targeting Amir's virginity.  
While Rinne allowed indirect touching through clothes, direct skin contact or kissing was forbidden—the right to claim that nurtured fruit belonged solely to its owner.  

Then Rinne met Yuu.  
For the first time in years, she desperately wanted someone.  
She'd planned to invite him to her student council room, drug him, then slowly train and enjoy him while he was helpless...  

But through some miscalculation, the sex had started against her will.  
When Yuu pinned her to the mat and revealed an aggressively masculine cock mismatched with his sweet face, Rinne's mind went blank.  
Unable to resist, she was stripped of her uniform and underwear, tossed about by rough caresses as her body began responding against her will.  
Then Yuu mounted her, thrusting his thick, hard cock deep into places no one had ever reached.  
Realizing *she* was the one being violated—that she'd been reduced to a mere female—Rinne completely surrendered.  

Crushed under Yuu's weight, his rough breathing and sweaty scent intoxicated her.  
As he brutally hammered her womb, unbelievable pleasure shot from her lower abdomen to her brain.  
Being dominated and violated by a man—a situation Rinne would normally never accept—felt inevitable in that moment.  
Without realizing it, she arched her back and wept.  

Her first vaginal orgasm came shockingly fast.  
After being made to cum two or three times consecutively, Rinne began feeling fear.  
*What's happening to my body?*  

The climax came with Yuu's ejaculation.  
The moment that magma-like heat flooded her womb, Rinne's mind went blank.  
She remembered screaming while clutching Yuu's arms.  
But that wasn't the end...  

Having never experienced such intensity before, Rinne lost consciousness.  
When the secretary and accountant woke her, she was alone in the basement.  
They explained what Yuu had done while she was unconscious—how he'd kept going even after ejaculating inside her twice.  
What bothered Rinne was how they praised rather than criticized Yuu.  

After everything ended, Rinne first freed the bound Chie, who ran off sobbing.  
Norika had been viciously arguing with the two health committee members until they retaliated fiercely—slapping Norika twice until she fled crying.  
Since then, Norika and the health committee members had avoided each other in tense silence.  

Rinne alone couldn't forget that time.  
No—as she'd passionately confessed earlier, she was desperately infatuated.  
It felt like an indelible obscene mark had been carved into her. Alone in bed, she'd pleasured herself while replaying their union.  

"Ugh... heh... ugghh..."  

Tears streamed down Rinne's face as she watched the passionate sex.  
She envied Sayaka unbearably.  
She wanted to be the one straddling Yuu, impaled on his hard, hot cock, writhing in pleasure while rocking her hips wildly.  
No—she wanted to be *ravaged* by Yuu.  
Not treated like a fragile noble lady, but subjected to bestial mating—like a male conquering a female.  
*Haa, haa...* Rinne's exposed pussy dripped arousal onto the floor without any stimulation.  

Her mind grew foggy, consumed by one thought: *How can I make Yuu want me?*  
She vaguely understood her usual haughty attitude wouldn't work.  
That left only begging.  
But her pride obstructed the decision, letting precious time slip away.  

"Ahh... AAAAAAAH! Yu... Yuu-kun! I-I'm... cumming again... ah! Already... nn! Ah!"  
"I... guh! I'm... at my limit!"  

As another climax approached, Sayaka hugged Yuu's head and rubbed cheeks.  
Sweat glistened on her body, her loosely tied hair swaying *yusa-yusa* with each movement.  
Adoring this disheveled Sayaka, Yuu held her tightly while thrusting vigorously toward the finish.  

"T-together... nnnaah! I-I'm cumming! Cumming cumming! Yuu-kunn!"  
"Ahh, together... Sayaka! I'm... ejaculating!"  
"AAAAAAAAAAAAAAAAAAAH—————!!!"  

When hot semen pulsed *dokudokudoku* inside her, Sayaka arched back with a scream that echoed through the room before collapsing onto Yuu's chest.  

"Haa, haa, haa... As expected, Yuu-kun is... too amazing for words."  
"I was crazy excited too. Feels so good inside you... oh, still coming."  
"Anh! *Fufu*. I'm happy to hear that, Yuu-kun. *Chu*."  

Sayaka rained kisses all over Yuu's face.  
Yuu gently stroked her disheveled hair and back.  
After licking the sweat from his chest, Sayaka gazed at him with still-fiery eyes, her slightly parted lips revealing a red tongue.  

"Yuu-kun... I want more of you."  
"Okay. We're just getting started."  

Yuu gripped Sayaka's butt with his right hand while savoring her smooth skin with his left.  
He opened his mouth to accept her kiss.  
After a deep, wet *pichapicha* kiss, Yuu wrapped his hands around Sayaka's waist and lifted her.  

"Hyaa!?"  
"Let's do it while holding you this time."  
"Nn... I like that too."  

Thinking Sayaka must be tired from riding him, and that missionary position might strain her barely visible baby bump, Yuu chose her favorite seated position.  
He sat up while lifting her limp body.  
Their embrace made his cock thrust deep into her with gravity's pull.  

"Haaun! D-deep... Yuu-kun's cock... ooh... kkuu... c-can't... move..."  
"It's fine. I'll move."  
"Ahh! W-wait... Yuu... kuh... aaaah! No! I'm cumming already!"  
"Ooh... squeezing... inside! But you just came... aah!"  
"Yuu-kunn!"  

As Yuu began slow thrusts, Sayaka clung to him like a koala.  
Her voluptuous breasts crushed against his chest as they swayed.  
Despite her pregnancy, Sayaka's vagina tightly squeezed his cock as if milking him dry—stirring Yuu's passion instead of calming it.  
Their joined lower halves made sticky *guchogucho* sounds as his thrusts gradually accelerated.  

Rinne watched helplessly as Yuu and Sayaka began round two while still connected.  
Though two meters away, their lewd sounds and smells reached her unmistakably.  
Her lower abdomen throbbed while dizziness and frustration grew.  
*Will I just be teased while watching them have sex?*  
Those two meters felt like an impassable boundary separating her from Yuu and Sayaka's bed.  

"Uuu... I-I too... please... show me mercy..."  

Rinne's usual arrogance vanished as tearful sobs escaped.  
Noticing this, Yuu—still thrusting into Sayaka—locked eyes with her.  
His gaze held none of the tenderness he showed Sayaka—only accusation for her earlier refusal to apologize.  

*Shouldn't I discard my pride and beg?*  
Rinne had never bowed to anyone except her mother and grandmother, always getting whatever she wanted.  
But for Yuu, she felt willing to lower her head—acknowledging his worth and her genuine attraction.  

◇ ◆ ◇ ◆ ◇ ◆  

Yesterday, Yuu had taken Sayaka to the OB-GYN.  
First, to check if the hypnotic drug from Saiei Academy's student council room affected her body.  
He'd also given them the unopened packet from Amir.  

The doctor said regular use could harm the fetus, but one dose posed no issues.  
This brought great relief.  

The second concern was post-pregnancy sex.  
Yuu recalled that in his original world, sex was avoided outside the "safe period"—generally after 16 weeks (5 months).  
A close colleague had mentioned restricting himself to oral sex after his wife's pregnancy confirmation.  

But when Sayaka asked, the doctor clearly stated sex during pregnancy was generally safe.  
The fetus is protected by amniotic fluid, so intercourse itself isn't harmful—except in cases of bleeding, abdominal pain, threatened premature birth, placenta previa, or pregnancy-induced hypertension.  

Though Yuu had heard pregnancy could lower libido, this world seemed different—perhaps due to advanced research on post-pregnancy marital relations.  
Since Sayaka felt well and eager today, Yuu saw no need to hold back.  

"Kuh... uwaaah! No more... I'm cumming! Cumming, Sayakaaah!"  
"Haa-kun! It's... it's okay, Yuu...kun! Don't hold back... fill me... with your cum!"  
"Ahh... Sayaka, I love you! Ugh!"  
"Yuu-kun! M-me too... ooh, amazing! Your cock inside... ah! Yu...u...ku...n... aah... aah... aah..."  

Despite being their second round, a massive ejaculation erupted against Sayaka's cervix.  
Gasping wordlessly, she stared blankly upward while clinging to Yuu's chest.  

"Haa-fuu. That was incredible, Sayaka."  
"*Ufuun*... I feel... incredible too... Ah, my body's still trembling."  

After catching their breath, they exchanged multiple soft kisses, savoring the afterglow.  

"*Fuu*. Though I feel like I've ascended to heaven, if I spent a whole night alone with Yuu-kun, my body might break.  
That makes me think having three people like in the student council waiting room might be ideal..."  
"Well... I do have excessive stamina—focusing on one person might overwhelm them."  
"Men must marry at least three women, so women must learn compromise—that's what school teaches.  
But compromise might be unnecessary with you, Yuu-kun. *Fufufu*.  
You'll surely keep sowing your seed in many women, won't you?"  

Though Yuu hadn't specified numbers, Sayaka easily imagined it—without jealousy, only acceptance.  
What a convenient world for virile men.  
Yuu gently bumped foreheads with her.  

"I'll likely bed dozens more women.  
My wives will surely exceed three.  
But as I've said before—you'll always be my first and favorite.  
That won't change. Okay, my beloved head wife?"  
"Ah... Yu, Yuu-kun!"  
"Sayaka!"  

Yuu held the tearful Sayaka in a fierce embrace.  
Her trained body pressed soft curves against him, reigniting his desire.  

Reluctantly pulling away, Yuu glanced at Rinne—wearing a desperate expression.  
He addressed her:  

"Well? Do you have something to say?"

### Chapter Translation Notes
- Translated "デラックスダブル" as "deluxe double" to maintain hotel terminology
- Rendered explicit anatomical terms directly ("cock", "labia", "ejaculation")
- Preserved Japanese honorifics (-kun) and name order (Mitsuse Rinne)
- Transliterated sound effects (e.g., "purupuru" for ぷるぷる)
- Translated internal monologues in italics with contextual phrasing
- Maintained explicit sexual terminology per translation style guidelines
- Kept specialized terms like "OB-GYN" for medical accuracy