## 164. The Young Lady Falls ④ ~Dropping the Heart~

"Ah... uu... I-I... that is... the other day, I... Yu-Yu-Yuu...sama..."

Rinne finally opened her heavy mouth to speak something. Having finished cleaning up with tissues, Yuu and Sayaka sat side by side on the edge of the bed, listening directly. Perhaps feeling awkward under their gazes, Rinne's words remained halting as they patiently waited.

That day, after returning to her alma mater's student council room and hearing Yuu's explanation, Sayaka's anger had been considerable. Though Yuu had personally disciplined Rinne and felt satisfied, the revelation that all three girls were nearly simultaneously pregnant had delayed settling accounts with Saiei Academy's student council.

Thus, Yuu and Sayaka had thoroughly discussed how to handle Rinne beforehand. Though Riko and Emi wanted to participate, family circumstances made it impossible, leaving it to Sayaka.

Making Rinne apologize here was non-negotiable. However, with no direct evidence linking to her personally, the prideful Rinne would never apologize willingly. Hence their scheme.

Moreover, a mere verbal apology wouldn't suffice - they needed to prevent larger-scale schemes. Yet cornering her too much risked provoking backlash. In automotive market share, Komatsu and Nikko - chaired by Sayaka and Rinne's grandmothers respectively - were rivals. But on a consolidated basis, the zaibatsu-scale Nikko Group ranked among Japan's largest, surpassing Komatsu. They had to avoid this student quarrel escalating to family interference.

Conversely, if they could win over Rinne - heiress to a major corporation - she might become a powerful ally for Yuu, though navigating this would be tricky. If Rinne became obsessed and demanded marriage, that would create new problems since Yuu prioritized Sayaka's trio. Concerns remained about the Mitsuse family's reaction too. Ideally, Yuu would establish a physical relationship while maintaining dominance. Rinne's apology method was crucial.

"*I... no, we of the student council... admit... that we harbored... impure thoughts toward Yuu-sama... and plotted... wicked schemes... in the student council room.*"

With a pained expression, Rinne squeezed out the words like wringing water from cloth. Finally taking this step, Yuu hid his inner relief and watched with a composed smile.

"Not just to me, but to Sayaka too."  
"Ah..."  
"Imagine if positions were reversed - how infuriating it would be. Yet Sayaka suppresses her emotions for my sake. As Sairei student council representative and my fiancée, I want your apology to her too."  
"Ugh..."

Rinne awkwardly glanced at Sayaka before lowering her eyes. But under Sayaka's intense stare, Rinne bit her lip and spoke while still looking down.

"Um... I also think... I did wrong... to Sayaka-san and the others."  
"Hmph. That's it? No 'I'm sorry'?"  
"Eh..."

Yuu pressed further - Sayaka wouldn't accept this half-hearted apology. After all, this was illegal activity. With only circumstantial evidence, council president Rinne needed to take responsibility.

When Rinne finally managed to speak but hesitated at the apology demand, Yuu stood and looked down at her.

"Weren't you taught to bow and say 'I'm sorry' when you've done wrong?"  
"Hah?"

Even as he said it, Yuu reconsidered - a young lady like Rinne probably never received such teachings. Then he must teach her here.

Yuu lowered himself to eye level with Rinne and placed a hand on her head.

"If you weren't taught, I'll teach you. If you feel sorry for wrongdoing, bow and say 'I'm sorry'. That's basic human courtesy."  
"U... ah..."

Rinne looked at Yuu with pleading eyes, but hesitation remained. She seemed conflicted - having never apologized for faults before, always being served by others outside family, this was a high hurdle. But Yuu wasn't done.

"Also, though abstractly mentioned before - weren't you the instigator pressuring the newspaper where my mother works?"  
"Eh, no, that's—"

Seeing Rinne's evasive eyes, Yuu continued.

"A top executive's single decision can alter many employees' lives, even leaving some jobless and destitute. Executives bear responsibility for steering companies. But toying with hardworking people's lives over a high schooler's whim is inexcusable. Apologize sincerely and swear to atone."

Struck by Yuu's harsh words from his salaryman experience, Rinne hung her head. Kneeling beside her, Yuu straightened her upper body. Her legs remained spread with buttocks flat on the floor, torso upright.

"Empty words won't convey sincerity. There's a saying about 'naked honesty'. Since we're already naked here, we need no pretenses. Discard thoughts of family or status - show sincerity. If you bow and apologize from the heart, Sayaka and I will accept it."  
"Yuu...sama..."

Hearing this, Rinne seemed to resolve herself. After looking at both Yuu and Sayaka, she nodded slightly. Then she straightened her back stiffly.

"I, Mitsuse Rinne... reflect on... my past actions...! I apologize... to Yuu-sama... and Komatsu Sayaka-sama! Simultaneously... I swear... to rectify... my attempt... to ruin... my mother's company... to obtain Yuu-sama!"

Rinne bowed her head. But bound hand and foot, she couldn't control her momentum and fell face-first onto the floor before Yuu could stop her. *Thud!* A dull sound echoed as Rinne collapsed.

"Auooo... I'm sorry... sooorrrryyyyy...!"

For Rinne - a wealthy heiress - to expose herself in such an undignified pose was likely unprecedented. Between pain and humiliation, she tearfully repeated apologies.

"Yuu-kun, I think that's enough."  
"Yeah, understood."

Sayaka herself had much to say given past events. But fearing that pushing Rinne further might backfire, she restrained herself. Nodding, Yuu first untied the rope binding Rinne to the sofa leg, then freed her hands and feet. With rope marks painfully visible on her freed limbs, Rinne seemed unable to rise, possibly from numbness. Yuu lifted her body.

"Well done, Rinne. Good girl."  
"Yu... Yuu-samaaa..."

Yuu praised her like a child who'd properly apologized, stroking her head. Merely uttering unfamiliar apologies made Rinne's heart pound and sweat from tension. After harshness, gentle words brought strange relief - Yuu recalled detectives using this interrogation technique in his past life. Indeed, Rinne's face showed genuine peace as Yuu stroked her head.

"Good."

Yuu glanced at Rinne's naked body and nodded. He wrapped his right arm around her shoulders/back to face her upward, sliding his left arm under her knees.

"Wh-what are... kyaaah!"

At the sudden floating sensation, Rinne let out a small scream, instinctively clinging to Yuu's shoulders and back. Realizing her face and breasts pressed against Yuu's chest made her heart pound differently now. Looking up at Yuu's smiling face, her cheeks flushed crimson. This princess carry - her first since early childhood memories - being carried by a younger male felt unbelievable.

"To the bed."  
"Y-yes."

Face flushed crimson, Rinne nodded obediently. Carrying Rinne princess-style, Yuu slowly headed toward the bed. Meeting Sayaka's eyes, he saw complex emotions - perhaps jealousy at Rinne's sudden attitude change and seeing another girl receive this first-time treatment. By chance, he'd never princess-carried any Sairei student council members despite their longer acquaintance. Reaching the bed, Yuu spoke, noticing Sayaka's jealousy.

"I'll give Rinne her reward now - wait a bit. After that, should we... do it together with you?"  
"Ah, no, that—"

Though Rinne's handling was Yuu's responsibility, Sayaka felt ashamed that her jealousy showed when Yuu treated Rinne kindly. Despite being older, she'd made him worry. To remain Yuu's primary fiancée, she couldn't stay emotionally immature. As Yuu climbed onto the bed carrying Rinne, Sayaka spoke.

"C-can I help with something?"  
"Hmm... let's see..."

While laying Rinne supine, Yuu pondered. "Reward..." Having overheard, Rinne murmured softly while lying obediently, gazing at Yuu with moist eyes like a maiden awaiting her first time.

"Got it. Thought of something good."

Looking at both Rinne and Sayaka, Yuu showed a mischievous smile. Spreading Rinne's legs and positioning himself between them, he whispered something to Sayaka. Though briefly shy, Sayaka nodded obediently, remembering earlier events.

"Yu... Yuu-samaaa... haa, haa..."

Already seeing Yuu's fully erect penis, Rinne wore a dazed smile, drool nearly dripping as she spread her legs wider to expose her privates. Yuu brought his hips close, pressing his cock against her glistening, dripping slit without penetration. *Squelch* - warm fluids overflowed, coating the shaft.

"Ahhaahn! Ha... hiiiee! Yes! Yes! Yeeessss! Fah... haa, haa, haa. ...I'll... do it! Sex friend! Lover! From today, I'm Yuu-sama's lover! Ahn! So... please... inside... put it inside me!"

Without penetration, just cock-rubbing made Rinne climax. As hunger is the best spice, Rinne's prolonged denial left her body unbearably aroused - now desperate for Yuu's cock, agreeing to anything.

"What do you want?"  
"Y-your cock... Yuu...sama's cock! Quickly... please... put it in... my shameless pussy! Aahn, like that time... thrust... with that hard cock... deep inside... make me cum crazy..."  
"Okay. As you wish."

At Rinne - legs spread wide, panting like a dog with tongue out - Yuu smiled wryly and leaned over her. Pulling his hips back slightly to adjust the angle, his cock slid deep into her vagina. "Ooh! Oofuun!" With just the glans swallowed, Rinne's jaw dropped slack. As the cock pushed deeper, unlike before, her vaginal walls smoothly opened then tightly wrapped around him.

"Kuu... ah, ah... feels good..."  
Unconsciously, delicate folds entangled him inside - like countless wriggling earthworms - making Yuu murmur. Having ejaculated twice already today helped; starting with penetration might have ended quickly. Feeling tingling pleasure spread from his hips, Yuu completed the thrust, hitting deep.

Receiving the longed-for cock deep inside, Rinne opened her mouth wide and screamed at that instant.

"Ooh! Ohii! Aah... AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH!!!"

The volume seemed audible outside the room. Watching nearby, Sayaka stared, wondering if Rinne's sanity had shattered. Her status as ancient noble family heiress, top conglomerate daughter, or student council president - all vanished. Merely receiving Yuu's cock - deeply desired - wrapped Rinne's heart and body in euphoria, giving her an unprecedentedly prolonged climax.

---

### Author's Afterword

This chapter was truly difficult to write. Some might think Rinne's treatment was too lenient. However, as stated in-story, we wanted to avoid pushing Rinne too far - preventing her family's intervention if she acted strangely at home. Also, considering her potential usefulness, this outcome seemed optimal. With Saiei Academy's student council destabilized, depending on the two vice presidents' departure and Rinne's repentance, their approach to males may change.

### Chapter Translation Notes
- Translated "セフレ" as "sex friend" with in-text explanation of the term
- Preserved Japanese honorifics (-sama, -san) per style guidelines
- Used explicit anatomical terms ("penis", "pussy", "vagina") consistently
- Transliterated sound effects (e.g., "Gon!" for ゴンっと, "Squelch" for くちゅり)
- Maintained original name order (Mitsuse Rinne, Komatsu Sayaka)
- Rendered internal monologues in italics without markers
- Translated corporate terms formally (Nikko Group, Komatsu Group)
- Kept relationship terms literal ("sex friend", "lover")