## 165. The Young Lady Falls ⑤ ~You Are Everything~

"O-o-ffo! Aah... Cumming cumming cumming! I'm cumming! Ann! I-I'm cumming! Aaahhhhaaaan! Ihiiin!  
Haah, haah, nooo... Yuu-sama's cock... is... the... best... shuwa. Aaaaaaah, ann!"

Before the climax from insertion could fade, Yuu began moving his hips, making Rinne seem to cum continuously. She rocked her hips in time with Yuu's slow thrusts. Though clumsy, it seemed the work of female instinct craving more pleasure. She might lose consciousness before Yuu ejaculated. Wanting to do something before that, Yuu stopped moving.

"A... ahee? Wh-why... did you stop?"

"Actually, I have a request for you, Rinne. Need to tell you before you faint like last time."

"Yuu-sama's request... if it's something I can do, anything at all? And... hurry with the continuation..."

What a sudden change in attitude. Between the shock of first sex and today's long denial, she seemed completely hooked.

"Good. Then, Sayaka."

"Un."

Yuu called Sayaka who was waiting beside him. Rinne looked puzzled.

"When I have sex, it's not always with one person - often multiple partners. I want you girls to stop quarreling during those times. Sayaka is my fiancée. And Rinne is my new lover. I absolutely forbid you two to fight from now on. Ah, I'm not saying you need to be friends daily due to family positions. But when we're together, I want cooperation. Understood?"

Yuu stroked Sayaka's head with his right hand and Rinne's with his left. Sayaka spoke first.

"Given our history, becoming friends immediately might be difficult. But for Yuu-kun's sake... I promise not to feud in front of him."

"Un. Thank you, Sayaka."

Yuu pulled Sayaka close for a *chu* kiss. Seeing this, Rinne had no choice.

"I-I... honestly envied Sayaka-san until now. But... being held by Yuu-sama like this. As your lover, I swear I won't do anything to displease you!"

Though still dazed from penetration, Rinne pleaded with sincere eyes. Yuu smiled happily and covered her.

"Glad to hear that. Then I'll kiss you."

"Mmh! Nmmu... u... nn... ufunn"

Come to think of it, this was their first kiss. Rinne had never been kissed by a man during sex before - only taking initiative herself. Just their lips touching made her face turn red enough to emit steam. When Yuu's tongue entered after the sudden lip contact, Rinne's eyes glazed over, her mind turning rose-colored and thoughtless.

"Nmu, nn, nn, churupa... afu... aae... lero, lero, juru... fa... Yuu... hyama... anmu... leroo, chu, chupaa..."

Rinne released her legs and wrapped her arms around Yuu's back, stroking lovingly while desperately tangling tongues. Pleasure chemicals seemed to flood her brain. The most pleasurable kiss she'd ever experienced - man or woman - made her squirt *pushu pushu* from her joined area.

After enjoying the kiss, Yuu pulled away, a string of saliva dripping from their tongues. Rinne swallowed it with wide-open mouth.

"Ohii... delicious shuwaa."

"Haha. Good. Now for that request."

Yuu sat up and signaled Sayaka. Blushing slightly, Sayaka approached Rinne's face.

"Huh?"

"Lick Sayaka's pussy. You won't refuse now, right?"

"Kyann!"

Yuu pulled his hips back slightly and gave a light thrust. Rinne couldn't resist. Having more experience with women than men, she had no aversion to licking.

"I-it's fine. Witness my tongue techni... hahiin!"

"Looking forward to it. I'll match my efforts to Sayaka's pleasure. Go ahead."

"U-un. Excuse me then."

Sayaka straddled Rinne's face and lowered her hips. Milky fluid dripped near Rinne's mouth - Yuu's semen leaking out after two creampies.

"Ahaa... Yuu-sama's seeeemen, shuwa!"

"Faa!?"

Without waiting for Sayaka to descend, Rinne grabbed her thighs and pulled her close, actively sucking.

"Anmu... chupurerorerujururururu! Muha! More. Nchu, chuuuujuruchupa!"  
"Aaaaahhh! S-sudden... nn, nnn! Aaann!"

Sayaka moaned at the sucking intensity rivaling Yuu's cunnilingus, clinging to him. Yuu kept slow movements so Rinne could focus, his left hand massaging Rinne's perfectly rounded breasts, his right lifting Sayaka's alluring breasts from below. Both required full palms to grasp, boasting volume, shape, firmness and elasticity.

Sayaka - pure Japanese beauty practicing martial arts. Rinne - proud young lady exuding mature charm. Opposite personalities sharing equally stunning bodies. Satisfied by this threesome, Yuu's excitement grew.

"Aah, ah, ahiiin! Yu-Yuu-kun! I-I!"  
"Sayaka."

Sucked intensely enough to draw out vaginal semen, Sayaka gazed at Yuu with teary, sensual eyes before pulling him into a deep kiss, tongues tangling. Though enjoying Rinne with slow thrusts, Yuu's cock tightened inside her while tasting Sayaka with mouth and tongue, making restraint impossible.

"Puhhaa... ann, ann! R-Rinne... au! N-noo... like that... aaann!"  
"Amchu... nna! Ya, hii... iiiin! Nmuuuuujururepa, nn, o, ohii! Vuun!"

While receiving rhythmic thrusts pushing against her womb, Rinne kept sucking Sayaka's vagina - or rather, her female instinct demanded Yuu's semen through both mouth and vagina, her body moving autonomously.

Tan! Tan! Tan! Guchu! Jupo, nucha, nucha, jupo!  
Ju... zuzuzuzuzukuchuruchuruu...

At their joined area, light flesh-slapping sounds mixed with endless love juice and sweat. Rinne audibly sucked without hesitation - residual semen and Sayaka's fluids included.

""Fwaaaaaaaaahhhhhhhh!!""

Amidst the lewd harmony from two wet sounds, Sayaka and Rinne moaned simultaneously like a chorus.

"Yu... u... fuunnnnnnnnnnnkuu!"  
"Ra! Hia! Aheeeeeeeee"

Sayaka buried her face in Yuu's neck while Rinne pressed against Sayaka's soaked vagina, climaxing together.

"Guh! I'm... reaching my limit too!"

Yuu pulled the limp Sayaka close with his right arm while gripping Rinne's waist firmly with his left, thrusting vigorously without restraint. Pan! Pan! Pan! Louder flesh impacts echoed as Rinne's moans intensified with ecstasy.

"Nhaa! Ann! This... coming! Aah! Yuu-sama's cock... deep inside... hauh! Sho... goo... ii! Au, au... can't... even think... ahyun!"

Her consciousness nearly fading, Rinne's chin jerked up, red tongue protruding.

"O, o, ooh! Yuu-sama... no more... can't shuwa... ah! Ah! Ah! Cumming! Cumming! Cumming shuwa... again! Aaohn!"  
"Guh! Me too... cumming. Rinne's pussy... feels amazing! Gonna... cum a lot! Vuuh!"  
"A... he... retaa... Yuu... sama... full of... your... cum... I'm... happy... shuwaa"

Feeling Yuu's swollen cock press against her cervix and hot semen flood her womb, Rinne murmured fragmented words like delirium before closing her eyes.

***

Yuu could've continued with Sayaka, but noticing all three had messy lower bodies from various fluids plus full-body sweat, he decided to hydrate and shower first.

"W-would it be alright if I joined you?"

Rinne hadn't fainted - just basking in post-orgasmic bliss. She responded immediately but seemed unprepared to bathe with a man. Yuu smiled.

"Let's enjoy it together. Okay, Sayaka?"  
"Ah, since we're becoming intimate with Yuu-kun naked, it's good for her to get used to such opportunities."

Sayaka had experienced harem baths during Yuu's birthday at her condo. As primary fiancée, she seemed resolved to treat Rinne as a comrade, her voice unwavering.

Yuu watched them tie up their long hair to avoid inconvenience. Sayaka used a high ponytail - Yuu's favorite since he mentioned it. Rinne gathered her back-length hair with a barrette, leaving her side drills hanging.

Yuu loved watching girls tie their hair from behind. Though unsure about other men in this world, the nape unexpectedly thrilled him.

"Sorry to keep you. Shall we go?"  
"Ee. ...Yuu-sama?"  
"...Ah, ah"

Dazzled by their backs, Yuu reacted late. Standing between them, he embraced their waists.

"Ah!"  
"Kya!"  
"Fufu. Nice. Bathing together."  
"Yuu-kun... you're already hard."  
"Well, with such beauties."  
"Really..."  
"..."

Though bashful, Sayaka seemed happy, leaning against Yuu. Rinne felt warm-chested from the praise and touch, cheeks flushed though unable to be openly affectionate like Sayaka.

***

Post-sex baths followed the usual pattern: mutual washing escalating into sweet moans. Sandwiched between Sayaka (front) and Rinne (back), Yuu enjoyed soapy body rubbing. Kissing Sayaka repeatedly made Rinne crave kisses too, so Yuu turned and hugged both sideways. Alternating kisses while groping breasts with both hands, his rock-hard cock received four-handed caresses from tip to balls. Despite three ejaculations, the slippery soapiness heightened arousal. Hoarsely, Yuu spoke:

"Hey, I have a request for you two."  
"Fufu, knowing you, I can guess. Say it."  
"Ahfunn... I-I'll... fulfill anything Yuu-sama says shuwaa!"

Sayaka smiled expectantly. Rinne seemed feverish despite not entering the bath yet - fresh experiences like intimate contact while aroused overwhelmed her, making her completely Yuu's captive.

"Then... I want you both to sandwich my cock with your breasts and stroke it. Let this double play literally wash away your grudges."

Sayaka and Rinne exchanged glances. Both E-cups could perform paizuri. Yuu wanted to realize his dream of double paizuri.

"Th-this okay... ah..."  
"Nn... feels weird when hot cock touches between breasts... but... feels good shuwa... hau"

Kneeling before seated Yuu at tub's edge, they faced each other, supporting breasts to sandwich his erect cock. Similar heights made their nipples touch. Their faces neared dangerously close - a direct look might make lips meet. Sayaka avoided Rinne's ecstatic face, focusing on the cock. Rinne, though experienced with women, seemed intoxicated by first-time cock-sandwiching.

Yuu felt supreme joy being double-paizuri'd by these beauties - especially rival student council presidents. Days ago, this combination was unimaginable.

"Ah, amazing. Breast-jobs feel uniquely special."  
"Come to think, you're oddly fond of girls' breasts for a guy."  
"Ah... true. You've groped them repeatedly today. But... being touched by Yuu-sama feels indescribably good... shuwa."  
"Both your breasts are equally magnificent. Now please - lick my cock while stroking with breasts."  
"Fufufu, leave it to me."  
"Aha! We'll pamper Yuu-sama's cock thoroughly shuwa!"

Initially uncoordinated, they interlocked arms under armpits and synchronized. Sandwiched completely between soft yet firm breasts made slick by soap, intense pleasure surged. Moreover, the visual of two beauties performing paizuri brought deep satisfaction and excitement.

"Kwaaaaah! Feels incredible!"

Hearing Yuu's strained voice, they smiled happily and began licking his glans. Tongue-tip licks from both sides soon competed to catch precum, tongues nearly touching.

"Leroleroon... ufuu, so much overflowing."  
"Chupachu... Yuu-sama, like this shuwa?"  
"Ah... that's good... nn!"

Rinne kissed and sucked the glans. Sayaka meticulously licked the coronal ridge. Breast strokes made *nyupu nyupuu* sounds while two tongues created *nichu nichu* sticky noises. When Rinne *churun*-sucked, Sayaka swallowed the glans whole. "No fair hogging!" Rinne protested, sucking from the ridge. They ended up licking half each.

Yuu stroked their napes, shoulders and backs, sensing imminent ejaculation.

"Damn... coming sooner than expected... kuh."  
"Nchureroo... chu, chu, chupa! Yuu-kun, cum whenever you want."  
"Amuu... Yuu-sama, cum for us shuwa."

*Nucchu nucchu* breast strokes accelerated. They focused tongues on the urethral opening, mouths open. Yuu couldn't hold back, gripping their shoulders.

"Guu... at my limit! S-Sayaka, Rinne, c-cumming! Vuuh!"  
"Aah!"  
"Hyah!"

The tip trembled *buru buru* before semen *dopyuu*-spurted. Despite being his fourth, copious semen flew through the air, dripping *pota pota* onto their upturned faces.

"Aah! This much... nnamu"  
"Hyau! A, a, a, afui... seeemen"

They licked semen around their mouths, but seeing more ooze from the cock, competitively began licking.

"Ah, felt great. Thank you both."  
Sayaka nodded at Yuu's words, but Rinne kept licking the cock obsessively with glazed eyes. For her, first-time paizuri/fellatio brought fresh joy in serving Yuu alongside her own arousal. Her love juice on the bathroom floor exceeded Sayaka's.

Post-shower, Sayaka and Rinne toweled Yuu together. His cock, temporarily subdued, rose vigorously. Rinne's eyes widened in shock - unbelievable recovery after so much ejaculation.

Returning the favor by toweling Sayaka, Yuu wrapped Rinne too:  
"Can go another round each. Let's hurry to bed?"  
Both nodded, cheeks flushed. Body and soul now Yuu's captives, Rinne wanted to fulfill his every desire. Truly fallen - yet she was starting to love this new self.  


### Chapter Translation Notes
- Translated "おチンポ" as "cock" per explicit terminology rule
- Preserved Japanese honorifics (-sama, -kun) throughout
- Transliterated sound effects (e.g., "Pan! Pan! Pan!" for ぱんっ、ぱんっ、ぱんっ)
- Maintained original name order (Mitsuse Rinne, Komatsu Sayaka)
- Rendered explicit anatomical/sexual terms directly (e.g., "cunnilingus" for おマンコを舐める)
- Formatted simultaneous dialogue with double quotes (""Fwaaaaaaaaahhhhhhhh!!"")
- Translated internal sensations as italicized descriptions where applicable
- Used "paizuri" as established term for breast job/frottage
- Kept Japanese culinary term "nyotaimori" untranslated as culturally specific