## Interlude 5: The Misfortune of a Careless Woman

A young woman ran desperately through the silent, hushed residential neighborhood at night.

She appeared to be in her mid-twenties. Not particularly tall, with a slim build though her chest seemed to have enough volume to sway.

It was that time of year when the sultry heat lingered even at night.

Her entire body was drenched in sweat as she ran with a desperate expression, her makeup completely smeared off.

Since casual attire was permitted for commuting, she was fortunately dressed in easy-to-move culotte skirt and sneakers today. But even so, she was nearing her physical limits.

There were no passersby at this hour approaching 10 PM. But multiple footsteps had been chasing her from about 50 meters behind, keeping her constantly on the run.

*(Why... am I going through this...?)*

Tears welled in her eyes as she kept running, questioning herself but finding no answer. Yet the cause lay in her own careless remark - she herself had boastfully revealed something that should never be spoken of in public where anyone could hear.

Thus, we rewind about three hours...

***

Even in August, Monday meant the start of the workweek for most working adults. But that cheap izakaya known for generous portions and good taste was nearly full with women seemingly stopping for a drink after work.

She was drinking with two junior college classmates she hadn't seen in a while. Social connections from student days tend to fade after entering the workforce, but these three had maintained a habit of meeting several times a year since they all worked in Tokyo. Of course, the biggest commonality was that all three remained unmarried without steady partners nearly five years after graduation.

Not that they had problematic looks - they took pride in being above average - but the world wasn't so kind that looks alone guaranteed male companionship. First and foremost, opportunities to connect with boys were scarce.

During junior college, they'd attended drinking parties where the school's only three male students participated, but surrounded by their female entourage, she couldn't even approach them, just watching from afar. They'd even paid above-market participation fees for this - three times over two years.

After graduation, one friend escaped harsh reality by zealously donating to male idol groups as a devoted fan. Another had made it her habit in recent years to pour half-year bonuses into brothels, venting pent-up sexual frustration on male prostitutes.

As for her, she had slightly wavy, unmanageable fluffy light-brown hair grown to shoulder-length. Yet she didn't look like a former delinquent because of her adorable features - round eyes, small nose and mouth giving a small-animal-like cuteness that made her appear younger than her actual age. In a world with equal gender ratios, her appearance alone would likely have attracted swarms of men if she just smiled quietly.

But her personality was problematic. Those who knew her described her as: airheaded, childish speech/behavior, socially clueless, extremely clumsy, excessively scatterbrained... etc. In short, the type you'd avoid working with.

She belonged to the PR department of a toy company, demonstrating products to children at department store events - a role assigned because she was deemed mentally on par with young kids. Her colleagues tasked with supporting her suffered endlessly.

Though she never confessed this to her luckless friends, she'd actually been relatively fortunate. Through her mother's connections, she'd dated men twice before. In another worldline, men might have found her "clumsy, airheaded" nature cute. Combined with her childlike cuteness, it would've been perfect. But in this world, it was fatal. Both times, the men broke up with her within a month, leaving her a virgin graduate.

But now she was about to grasp her first luck in four years. She hadn't been told the man's name or address, and was forbidden from mentioning their meetings. Yet as the day approached, her rising excitement became uncontrollable. At work, her fantasies ran wild, making her grin creepily and unsettling colleagues. Even she managed not to tell anyone... but alcohol loosened lips...

About an hour into drinking. After mutual work complaints and classmate gossip, conversation shifted to personal interests. As one praised her favorite idol with dreamy expressions, and the other boasted - with heavy embellishment - about sexual experiences with her regular male prostitute (30s) at last month's brothel visit, she accidentally let slip:

"Actually, I have a date with a guy this Wednesday."

""Huh?""

At their four-person table, the two friends seated across from her reacted in unison as if saying "What's this idiot saying?" But she continued unfazed.

"A~nd! Guess how old he is?"  
"Haa... 40 or something?"  
"About 50?"

They knew her well. A same-age man was impossible. They arbitrarily assumed it must be an older man who could tolerate her problematic personality. But her answer was the complete opposite.

"Mufufu~ No way!  
He's... a 16-year-old high school boy! V-sign!"

"Scam."  
"You mean 46, right?"  
"How mean!"

As she made a V-sign, their immediate retorts angered her.

"It's true! He really is a 16-year-old high school boy! I hear he's super handsome too. We're meeting at a hotel in Komiya City, Saitama during daytime! Of course I took paid leave!"

Her protest in an unprofessional, childish tone. Perhaps stubborn after being dismissed, she even revealed all she knew. But her friends weren't convinced. A 16-year-old high school boy was typically inexperienced with women. Why would he meet a woman ten years older at a hotel?

The argument continued, their voices growing louder. The heated trio completely failed to notice women at nearby tables eavesdropping.

***

Having work tomorrow, the pleasantly drunk trio left the izakaya around 9 PM. While heading to the station, they loudly exchanged goodbyes for no reason and split up. Two friends took JR trains; she alone took the subway.

A 30-minute ride to her nearest station, then a 12-13 minute walk to the apartment she shared with her mother. Though often teased, this occasional fun time with friends she'd kept since graduation was over. Just one workday tomorrow, then the biggest event of her life awaited!

She believed this without doubt until she disembarked at her station, passed the ticket gate, and began walking home.

***

What was going on?  
She wondered this about five minutes into her walk, after entering the quiet residential area. Multiple footsteps had been following closely behind her since leaving the station.

After three turns at corners with no one ahead but persistent footsteps behind, she looked back at the second and third turns and spotted about three figures in the evening gloom. Why were they following her? Robbery? Kidnapping? Targeting a low-earning 20-something woman made no sense.

Unnerved without understanding why, she naturally sped up, but the footsteps matched her pace.

"Eek!"

Seeing the silent figures still following when she looked back, fear drove her to break into a run.

"She's running!"  
"Hey wait!"

The relatively young voices finally reached her. Regardless, she was clearly being targeted. What would happen if caught? Would she be brutally killed!? When her biggest lucky chance awaited the day after tomorrow!

Her thoughts spiraled to extremes.

This was her neighborhood. Calm thinking would've directed her to the convenience store she often visited or the busy street with night traffic. But panicked, she kept running blindly through the maze-like residential area.

Thus we return to the beginning. After over ten minutes of running pursuit, she reached a T-junction and nearly screamed at the sight of high black shadows looming ahead - but then remembered.

Though off her usual route, this was the large park about 7-8 minutes from her apartment. The tall shadows were trees planted there. Half the oblong park grounds had elevated embankments planted with dozens of cherry trees, creating spectacular views during full bloom that drew crowds yearly.

Spotting the park entrance right ahead, she entered without hesitation. Encouraged by familiar territory, she wasn't afraid of the dimly lit darkness. She resolved to lose her pursuers here.

"Shit! Where'd she go?"  
"We had her cornered just now!"  
"Search!"

Hiding behind a long slide along the embankment slope after running in, her plan seemed successful. The pursuers - still three from their shadows - appeared frustrated at losing sight of her and split up to search different directions.

She then slowly climbed the slope, planning to cross the embankment, descend the opposite slope, and exit the park. Her uncharacteristically quick thinking seemed to work... until she stepped on a twig in the dark midway up the slope. The *crack* echoed surprisingly loud in the silent park.

*(Oh crap!)*  
"Found her!"  
"Over there!?"  
"Fucking bitch! Get back here!"

One pursuer must have been near the slide. They immediately scrambled up the slope after her.

*(Hiiiiii! I-I'll be killed!)*

She managed to crawl to the ridge and started running along the path, but spotting another climbing stairs ahead, terror struck. These must be the "Female Hunters" recently making news.

Jealousy and envy tend to be stronger between same genders. Women who'd lived without male connections age-for-age would pick fights with women who'd just broken up after dates, or who boasted about relationships or sex with men - violence cases coincidentally highlighted on TV news. Dubbed "Female Hunting" by someone, from females attacking other females paired with males. Attackers spanned ages but often involved middle-aged women without male luck targeting younger, prettier women.

But now, her attackers seemed young women based on physical ability. She'd be cornered. Judging this instantly, she abandoned the path and decided to descend the steep slope opposite her ascent.

*(S-scary!)*  
Descending a steep slope in darkness with unsure footing required courage even in daylight.  
"Stop right there, bitch!"  
*(Must escape!)*  
The threatening voice right behind pushed her forward.

She ran down the concrete-reinforced slope. Her pursuers hesitated at her bold move, but one quickly pulled out a flashlight, spotted stairs nearby, and headed down.

Summoning courage paid off as she reached the fence separating park from street first. But her momentum was too strong, and darkness distorted depth perception - she couldn't stop before the waist-high fence, hitting her stomach hard.

"Guh!"

With a frog-like croak on impact, she tumbled over the fence like a horizontal bar flip, rolling onto the road. Timing couldn't be worse. A taxi that had just dropped off passengers at a nearby house was approaching.

"Ouch ouch ouch... huh?" Crouched on the road, she froze at the sudden blinding light.

Screeeech... THUD!  
"Gyah!"

Though not speeding, the panicked driver's brakes couldn't prevent impact. She was sent flying meters by the front grille.

"Hey! You okay!? ...Huh?"  
The middle-aged female driver jumped out as multiple figures ran from the park toward the fallen woman. Normally, they'd rush to help the victim. But they snatched her shoulder bag from the helpless woman and fled.

"Wha...!? You bastards!"  
Chasing bag-snatchers mattered less than the injured woman's condition. Bleeding from limbs and immobile but conscious, she faintly responded to calls.

"Haa... goddammit."  
Having started evening shift without completing half her daily quota, the driver sighed heavily. Prime earning time ruined by police investigations ahead. She ran back to her cab to call her company for ambulance and police via radio.

***

### Author's Afterword

While the half-sisters who met Yuu were very fortunate, this interlude shows there were also people like this. Originally planned as half a chapter in the main story, it grew longer than expected so became an interlude. How this incident affects the main story will be revealed in future chapters.

### Chapter Translation Notes
- Translated "メス狩り" as "Female Hunting" per fixed terminology
- Translated "男娼" as "male prostitute" maintaining explicit terminology
- Preserved Japanese cultural terms like "izakaya" and "furoshiki"
- Transliterated sound effects (e.g., "バキっ" → "crack", "キキィィィィィ" → "Screeeech")
- Maintained Japanese name order convention for all characters
- Used italics for internal monologues per style guidelines