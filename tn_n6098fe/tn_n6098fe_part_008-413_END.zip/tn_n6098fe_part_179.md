## 167. Accident ② ~Long Time No See~

### Author's Preface

Thank you as always for reporting typos.

It seems there were more typos than usual in the last chapter, causing you trouble.

---

"Ugh, mmph... *cough* *cough*... M-my apologies, but please allow me to clear my throat. There was more than expected, and it's sticky... clogging my throat."

I first met Rumiko during Yuu's first sperm donation experience (Chapter 62). Back then, Rumiko immediately approached Yuu right after his donation without hesitation, traced his cock with her finger, and took the semen into her mouth.

Today, after giving a full fellatio session, she swallowed every last drop directly from the source. And this was just the first load - a substantial amount. The mood broke, but it couldn't be helped.

Rumiko took a bottle from the refrigerator and began drinking while standing completely naked, hand on her hip, gulping it down. That classic pose of drinking coffee milk fresh from the bathhouse. But when a woman with Rumiko's exceptional proportions does it, Yuu found it mesmerizing enough to stare. Though she'd passed thirty, her voluminous breasts and ass pointed upward without sagging, complemented by a slim waist and beautiful legs - she looked more like a model than the female teacher image from their first encounter.

With Kanako and Touko pressed against him on both sides, Yuu kept watching Rumiko.

"My, what is it?"

Feeling Yuu's intense gaze, Rumiko smiled bashfully.

"Ah... I was just thinking how truly gorgeous you are, Rumiko-san."  
"My... Yuu-sama, you're such a flatterer."  
"No, I mean every word."

As Rumiko's gaze shifted to Yuu's crotch, his erect member stood towering toward the sky despite having just ejaculated. Seeing this, Rumiko licked her wet lips with her tongue. Placing the bottle on the desk, she climbed onto the bed and approached. Her expression resembled a panther locking onto prey.

Crawling on all fours until right before Yuu, she seemed about to embrace him but paused to glance left and right before speaking.

"Judging by this, have you two protection officers already... with Yuu-sama?"  
"Ah... well, yes. Thanks to him."

Kanako clearly answered as Touko nodded repeatedly. A hint of shame and guilt was visible.

"No, I'm not interrogating. It's occasionally heard of for protection officers bonded by trust to become intimate with their male charge."  
"Exactly. I was the one who approached them wanting to get closer since they always take such good care of me. Right?"  
"Yuu-sama..."  
"Yuu-sama! Love you!"

Yuu made eye contact with Kanako and Touko as he pulled them close with both arms, exchanging light *chu chu* kisses. Then Rumiko joined in, capturing Yuu when he faced forward.

As if being devoured, she pressed her lips against his with a *buchu* sound, her slimy tongue invading Yuu's mouth.

"Mmph... nk!"  
"Anm... lero lero chu... n... mf... nna!"

Yuu wasn't passive with Rumiko either. He actively extended his tongue, ravaging her mouth in a crisscross motion. Rumiko's cheeks flushed pink as she quickly became aroused. While stroking Yuu's head with her right hand, Rumiko's left hand reached for his crotch. Kanako and Touko on either side also held Yuu with one hand each and joined in. His still-wet, glistening cock was thoroughly caressed by three hands.

After enjoying deep kissing for a while, a string of drool stretched between their lips when they separated. Meeting Rumiko's dazed eyes fixed on him, Yuu asked something that had been on his mind.

"Rumiko-san, you seem experienced. Are you married...?"

He knew married couples in this world also wore rings on their left ring fingers, but Rumiko wore a ruby ring on her right index finger. Stroking Yuu's head and cheek affectionately with her ring-adorned right hand, she smiled.

"Fufu. I actually had a fiancé once - we dated for about a year. But... during an experimental uterine examination for women in their twenties in Tokyo - which included screenings for cervical cancer and fibroids - they found an abnormality in my uterus. Adenomyosis - benign tumors. Roughly speaking, it makes pregnancy extremely difficult, and even surgery can't easily remove it. Of course, I can live a perfectly healthy life despite the difficulty conceiving. But I withdrew since I thought there was no point marrying a woman who can't have children. Especially since many women already adored him."

Yuu thought if they loved each other, she didn't need to withdraw. In this world where men marry three or more women, wouldn't it suffice if someone else bore his child? But considering the wife's position, being the only one unable to conceive might have been awkward. This time, Yuu kissed Rumiko first, licking the moist part of her lips before speaking.

"But it's not completely impossible, right?"  
"Th-that's... true, but"  
"Do you want children, Rumiko-san?"  
"Eh...?"

Rumiko's confusion was understandable. The examination clearly stated pregnancy was difficult - only a few percent chance with normal marital relations. But Yuu smiled and pressed on.

"I believe my semen was rated Special A-rank. Wouldn't that increase the probability somewhat?"  
"Ah..."  
"So I want to give my first load today to you. Okay?"  
"As Yuu-sama wishes."  
"I'll yield the first round to her."  
"Thank you."

Kanako and Touko slightly distanced themselves from Yuu's body. Though they said they'd yield, completely separating was difficult.

"Now, Rumiko-san. Come here."  
"Ufu. I'm so happy. Since breaking up with him, I've focused solely on work - I never imagined I'd have male companionship after turning thirty... But now my body craves feminine pleasure uncontrollably... Haah, haah... B-but is this alright? With three partners... Ah!"

Before Rumiko could embrace him, Yuu wrapped both arms around her waist and lifted her. Feeling unexpected masculine strength, Rumiko was overcome. Her womanly parts, teased to near-orgasm earlier, craved his cock and were fully prepared to receive it.

Burying his face in Rumiko's ample breasts, savoring their softness and scent, Yuu supported her plump buttocks from below and brought her closer to his crotch. When their lower abdomens touched, Rumiko guided his cock into position with one hand. The tip plunged deep into Rumiko's vagina.

"I'm used to multiple partners."  
"My... a-as expected of Yuu-sa... Ah... Ahaaah! S-so big! Ngaah!"  
"Ooh... Rumiko-san's inside is hot and creamy... squeezing tight!"  
"Haaan! Nn... eh? St...still... coming in...!? Aa... o... kuu!"

Rumiko's weight made it slide deeper inside. Though aware of its size, the sensation of this rigid meat rod invading her was beyond ordinary. When it finally thrust deep into her vaginal depths after taking time, what felt like an electric shock ran through Rumiko's entire body. Overwhelmed by unprecedented pleasure, she stuck out her tongue and moaned.

"Aa... aa... aa... kufuuuuuuun! I... iiiihhiiiiiiin!!!"

Yuu's face was buried so tightly in her large breasts that breathing became difficult. Still, the feminine sweat and milky scent seeping from her skin was a reward. He rather enjoyed licking and sucking all over.

"Ah... haa... I came just from insertion. Th-this feels... so good... first time."

As Rumiko's hot breath hit him when her jaw dropped, Yuu lifted his face to meet her gaze.  
"But we're just getting started."  
"Ah... hi! Yu-Yuu-sama? ...Aauun!"

Holding Rumiko firmly in a face-to-face seated position, Yuu began thrusting upward.

*Thump! Thump! Thump!*  
"Aa... aa... akuuuu... hyaun! Ag...again... aaaaaaaaaah! Cumming... I'm cumm... uun!"

Rumiko's moans echoed with the sound of flesh slapping together. Accompanying it was the *guchu guchu* of sticky wet noises from their joining area. The sheets beneath them were already stained, but Yuu showed no sign of stopping. Each time Rumiko came, kiss marks multiplied on Yuu's face. Seeing this up close, Kanako and Touko were so intoxicated by the lewd atmosphere they began fingering themselves.

"Hah, hah... hah... More than I imagined... Amazing...! Yuu-sama... any woman he embraces... becomes enslaved body and soul... ann!"  
"Rumiko-san's... inside... feels amazing too..."  
"Fufu, I'm glad. Even an old woman like me... recognized as a woman... happy... mmph!?"

Yuu grabbed the back of Rumiko's head as his tongue ravaged her mouth. After thoroughly savoring her upper mouth like the lower one, he whispered in her ear.

"Don't call yourself old. You're a fine woman I approve of. Ah... but I'm close. Last spurt, okay?"  
"Ha... hii! So... rough!"

Her hair, previously tied at the back, had long since come undone from the repeated motion, with several strands hanging loose. This only accentuated Rumiko's allure. Moreover, her hip movements after one climax were so skillful they showed no rust, bringing Yuu close to his limit. Though not as tight as a teenage virgin, her folds massaged his entire cock with varying pressure, trying to milk his essence.

Meanwhile, for Rumiko, positions that never reached her vaginal depths with her ex now had Yuu digging deep. The ridge of his glans catching on withdrawal brought indescribable pleasure. Though Rumiko fought well, Yuu's overwhelming experience meant the more she moved, the more she was dominated. With both arms around Yuu's back and even her long legs wrapped around his waist, they became one heading toward climax.

"Hah, hah... hi, i... it's... cumming... Cumming cumming! So... intense! Can't... take it! Yuu-sama! Aaun!"  
"Nn, gu... Ru-Rumiko-san! My limit too... ah, feels... too good! I'll give you... plenty... get pregnant... with this!"  
"Hiiin! Dee... deep... my... womb... co... coming... ryuuuuu!"

At the last moment, Yuu changed to a digging motion while buried deep inside - perhaps consciously trying to ensure impregnation. The movement seemed to push upward against her descending uterus, making Rumiko involuntarily tilt her head back.

"Kaha! C-cumming!"  
"Ah... don't stop... aheeeeeeeeeee..."

As if his first ejaculation meant nothing, a torrent of semen surged through Rumiko's womb. Feeling the movement in her lower abdomen, Rumiko stared blankly upward, mouth opening and closing wordlessly. An unprecedented climax shook her so violently she closed her eyes and abandoned thought.  


### Chapter Translation Notes
- Translated "お久しぶりね" as "Long Time No See" in chapter title to convey Rumiko's reconnection with sexual intimacy
- Preserved explicit anatomical terms: "チンポ" → "cock", "精液" → "semen", "膣" → "vagina"
- Transliterated sound effects: "ぐっちゅぐっちゅ" → "guchu guchu", "たんっ" → "thump"
- Translated medical term "子宮腺筋症" as "adenomyosis" with explanatory description
- Maintained Japanese name order: "Inui Rumiko" (乾 留美子) throughout
- Italicized internal monologue: "*(This is concerning.)*" for "（これはまずい）"
- Preserved honorifics: "-san" for Rumiko, Kanako, Touko; "-sama" for Yuu
- Rendered sexual acts without euphemisms: "フェラ" → "fellatio", "精飲" → "swallowed"
- Used explicit terminology for intercourse: "肉棒が侵入" → "meat rod invading", "結合部" → "joining area"