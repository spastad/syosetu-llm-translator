## 168. Accident ③ ~Breath Net~

"H-ho, is this really alright?"  
"Yeah. It's fine. Don't hold back. Since you waited for me, I'll make you feel good."  
"Th...then, excuse me."

Kanako slowly lowered her hips astride Yuu's face as he lay on his back. For most women, face-sitting on a beautiful boy like Yuu existed only in lewd fantasies. Even Kanako knew this was a staple scenario in erotic media for women, not just Touko.

Though their relationship had become physical after self-defense training, Kanako never imagined she'd experience this "impossible" scenario in reality. Her expression contorted uncontrollably with excitement. Fortunately for her, facing away meant Yuu couldn't see her face.

Touko could see Kanako's expression from her position facing her, but she was too preoccupied. After winning rock-paper-scissors to determine who'd go first, Touko now rode Yuu eagerly, grinding her crotch against his erect penis in sumata. This was at Yuu's request - timed to coincide with Kanako's cunnilingus.

"Nn, nnn...ufuu...Yu-sama's cock...rubbing like this feels so good...nha! That sensitive spot...hitting it...yes! So...good!"

The ridged hardness rubbing against her open labia felt incredible, and leaning forward to grind made the glans strike her clitoris with supreme pleasure. In this world, sumata was a coveted act for women, often fantasized about in forbidden scenarios like family relations or teacher-student dynamics. Touko herself had masturbated to such fantasies countless times - her dream had become reality. Her pussy was already dripping wet, making squelching sounds with each hip movement.

Yuu waited as Kanako's large buttocks approached his face. Though the close proximity cast shadows that obscured details, her spread legs revealed glistening wetness. Catching the musky feminine scent, Yuu spread her labia wide with both hands. Drops of love juice splashed onto his cheeks.

"Now, let's begin! *Munch*, *lick*, *slurp*! *Schlooorp*!"  
"Hii! Yu...sa...aaaaaah! Suddenly like that...ahiiin!"

Seeing how wet she was, Yuu greedily sucked and thrust his tongue deep into her vagina. Kanako couldn't help but stick out her tongue and moan wildly. Seeing this, Touko swallowed Yuu's rock-hard cock into her ready pussy.

"Nnggh!"  
"Gwaah...i-it's...in! Ah, ah, Yu...sama, your cock...haon! Kuhuuuuu!"

Though dripping enough to wet the sheets, Yuu's thick cock stretched Touko's tight entrance painfully. Sweat beaded on her furrowed brow, yet her whole body thrilled at being connected to Yuu. When fully sheathed, Touko nearly climaxed from the overwhelming sensation - only her experience with Yuu helped her endure. Ironically, Kanako was losing composure faster under Yuu's intense oral ministrations.

*(Kuuuu...Touko-chan's inside feels amazing too!)*  
Her petite frame meant her vagina was narrow, leaving part of Yuu's shaft exposed, but the engulfed portion squeezed and massaged him with countless folds. But Yuu had masculine pride - he wanted to make both women climax first. Enduring near-paralyzing pleasure, he focused on the cunnilingus.

After cleaning up with tissues, Rumiko sat drinking her oolong tea while watching the trio with admiration. She knew cases of male-protection officers becoming intimate with their charges, but usually with older men. Pairing a young boy like Yuu with both a veteran and young officer like Touko was unprecedented. Yet it worked - their intimacy was evident as they shared this intense sex with Rumiko.

As a woman who'd focused on studies and work for nearly a decade since her broken engagement, Rumiko felt her dried-up instincts awakening. The earlier passionate intercourse where she'd climaxed repeatedly from Yuu's thrusts and been filled with his hot semen had awakened primal desires. She couldn't help sighing heatedly, at least sliding her right hand to her lower abdomen.

"Fah...aah, ahiiin! I-I'm coming...ahhhh!"  
"Ngggh! Me too...guh!"

Touko desperately thrust her hips near climax, burying her face in Kanako's ample breasts. Kanako, who'd climaxed twice from Yuu's cunnilingus, held Touko while breathing heavily. Yuu's face was soaked with fluids, but he thrust upward to meet Touko's movements, approaching ejaculation.

"Uggh...Ickuuu...ahh!"  
"Nnnnnn~~~~~!!!  
Ooh, ooh, ohhiiin! Feh...I'm...Yu...sha...ma...love you...ahfuun..."

Yuu ejaculated while pressing against her cervix just as Touko climaxed. The earlier intensity vanished as Touko lay quietly in Kanako's embrace, savoring the afterglow.

"Sorry, Kanako-san. You ended up last."  
"Ahf...th-there's no...nne...eed...ahn! To worry..."

After Touko moved aside, Yuu embraced Kanako from behind as she sat on the bed, kneading her full breasts. Though last in line, she'd already climaxed twice from face-sitting cunnilingus - more than satisfied. She felt only gratitude toward Yuu for his consideration.

Despite three ejaculations, Yuu's erection pressed insistently against Kanako's back as he enjoyed her athletic body. He licked her neck while kneading her breasts - her skin surprisingly smooth for her muscular frame, likely from disciplined living and training.

"Ah, aahn...Yu...sama..."  
"Kanako-san."

Always reliable and dignified, Kanako now looked back at Yuu with a lovestruck expression. Yuu kissed her deeply before whispering:

"Sometimes I want you like this from behind."  
"Hae...?"

Before Kanako could process this, Yuu pushed her forward while maintaining their embrace. Gripping her firm, elastic buttocks, Yuu pressed his rigid cock against her dripping entrance. Her pussy welcomed him with a wet sound, wrapping tightly around his shaft.

"Aahh!"  
"Kufuun! Ah...ah...Yu-sama's...coming in!"  
"Good! Kanako-san's inside...feels incredible. Oh, squeezing tight..."  
"Me too...ahii...filled with Yu-sama's cock...aaaaaaaah!!!"

When Yuu thrust deep and struck her cervix, Kanako threw her head back, trembling violently as she climaxed instantly. Yuu felt the same overwhelming pleasure but endured thanks to his earlier releases.

*Heh. How is it, Kanako-san? First time like this, but feels good?*  
Though feigning calm, Kanako's vaginal muscles massaged his cock with numbing pleasure. Moreover, taking a large woman doggy-style gave Yuu a conqueror's thrill. Kanako gripped the sheets, barely managing to respond:

"Hah...hahi, Yu...sama's cock...hitting different spots...ah, ah, aahn! There...feels...so good...ahhn!"  
"Glad to hear. Your insides feel...irresistible!"  
"An! So rough! I-I'm coming again. Yu...sama! Aaahn!"

Yuu preferred slender women from behind, but Kanako's trained physique had its own beauty. Sweat glistened on her back as Yuu covered her, one hand on her voluminous breast, the other on her toned abs. When Yuu thrust deep enough to pry her depths, Kanako moaned but smiled deliriously at his closeness.

*Pah! Pah! Pah!*  
Unlike with Touko, Yuu thrust nearly to the hilt, making flesh slap loudly.

"An! An! Aahn! Hah...i-in! So good! Yu...sama, sorry, I'm...coming again!"  
"It's fine, Kanako-san. Come as much as you want. Your pleasure makes me happy."

Yuu's breath on her nape made her shiver with ecstasy. Being penetrated so deeply, his words pushed her over. She arched back, arms outstretched, mouth wide.

"Ah! Hi, i-i, I'm comi...shu...hya, ah...aaahn! Ikuuuuuu!!!"  
"Kuh! Squeezing!"

Usually they did missionary, cowgirl, or facing seated positions. The different sensations affected Yuu too. Kanako's climaxing contractions sent electric pleasure through him.

Repeated sex with the same partner usually dulls sensation, but vaginal feel varies wildly by position and situation. Going bareback amplified everything. Kanako's deep vagina provided broad stimulation, and her trained pelvic muscles squeezed rhythmically.

"Hah...ah, ah, already...st...op..."  
"It's fine, Kanako-san, just lie down."  
"Ye...s..."

Yuu laid Kanako face-down while still joined. Touko took her outstretched hand, gazing moistly at Yuu.

"Kuh! Last spurt...here I go!"  
"Hahi! D-deep! Gwaa...cock grinding...aaun!"

Yuu held Kanako's left hand and right shoulder in mating press position, hips pistoning fiercely.

*Bap! Bap!*  
After barely three minutes, Yuu's climax peaked.

"Ah...kaha...I'm coming, Kanako-san. Uggh, guh, cumming!"  
"Hah, hah, hahii...Yu...sa...aaaaaaaah! Me too...ooh, ooh, ooh, Ikuu...i, a, aaan!"

Yuu's fourth ejaculation that day brought full-body ecstasy. Kanako couldn't withstand it either - fresh waves of pleasure overwriting her previous climax. Yuu slowed his hips post-ejaculation, lying atop Kanako while basking in the afterglow.

Compared to six months prior, Yuu's stamina had greatly improved under Kanako and Touko's training. Yet four consecutive ejaculations - three with active thrusting - left even young Yuu fatigued. As he lay curled between the limp Kanako and clinging Touko, Rumiko approached with an open bottle.

"Good work."  
"Th-thank you."

The chilled oolong tea cooled Yuu's heated body, and he drained it instantly. Taking the empty bottle, Rumiko retrieved an A6-sized envelope from her handbag.

"There's another reason we moved here." She handed Yuu the envelope. Puzzled, he saw only "Invitation" written in block letters - no names.

"Invitation?"  
"Yes. Since it's summer break, young people naturally want to visit mountains or beaches. But safe leisure spots for young men are limited. Thus, the Toyoda Sakuya Memorial Foundation invites you to its members-only hot spring resort in Hakone."  
"Huh, Hakone."

The famous hot spring destination felt nostalgic - Yuu remembered visiting post-marriage. But "members-only resort" sounded exclusive.

"Only foundation members and guest members may use the resort. Regular members include Sakuya's wives, children, and recognized lovers/their offspring. Of course, the Hirose family automatically qualifies. Though Martina-sama kept distance from the foundation, now that you're involved, we hope you'll connect with your half-siblings."  
"Half-siblings..."  
"Yes. Instead of meeting individually, you'll meet several brothers and sisters together at the facility."

Rumiko smiled warmly.  


### Chapter Translation Notes
- Translated "スマタ" as "sumata" (non-penetrative genital grinding) with contextual explanation
- Preserved Japanese honorifics (-sama, -san) per style guide
- Translated explicit anatomical terms directly ("チンポ" → "cock", "ワレメ" → "labia")
- Rendered sexual acts without euphemisms ("クンニ" → "cunnilingus")
- Transliterated sound effects ("ぱんっ" → "*Pah!*", "ぬっちゃぬっちゃ" → "squelching")
- Maintained Japanese name order (Hirose Yuu, Kitamura Kanako, etc.)
- Italicized internal monologues per formatting rules
- Translated "顔面騎乗" as "face-sitting" to convey the specific sexual position
- Used "members-only resort" for "会員制リゾート施設" to maintain exclusivity nuance
- Preserved institutional names per Fixed Terms (Toyoda Sakuya Memorial Foundation)