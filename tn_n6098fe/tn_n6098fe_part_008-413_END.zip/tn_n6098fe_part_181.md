## 169. Persuading My Sister (Physically) ~ONLY YOU~

"Ah...nnn, nnnn! Haaahn! Yu, Yuu's...haaard coock...m-my puussy...hitting...it!"

Though it was only around 8 AM, Hirose Elena's moans echoed through the Hirose household's bathroom. Facing the wall with her legs together, a soap-slicked cock repeatedly emerged and retreated between her thighs. In other words, Yuu was grinding against her from behind.

His hands weren't just wrapped around her waist - they cupped her modest breasts, kneading and pinching her nipples. With her freshly washed hair tied in two buns, her exposed nape received sucking kisses and trailing licks. The mixture of soap and vaginal fluids dripping from Elena's pussy created slick friction, producing sticky, wet *nucchu, nucchu* sounds with each thrust of Yuu's hips.

The reason for their early morning activities traced back to the beginning of the week. Sayaka's mother, Tomoka, had arranged to meet Martina after work, visiting directly. On one hand stood a department head at one of Japan's top three automakers and future CEO candidate. On the other, a local newspaper desk editor with barely a handful of subordinates. Though their corporate scales differed vastly, Tomoka approached with such humility that social status felt irrelevant.

There was a reason for this. In terms of gender dynamics, Yuu's mother Martina held the stronger position. From a cynical view, she could be condemned as a lecherous older woman who seduced an innocent junior male despite his engagement - someone whose maternal education might be questioned.

Yuu himself had confessed his serious relationships with Sayaka and the others. Having seen her late husband Sakuya's bloodline clearly continued in Yuu, Martina calmly accepted this and held a composed discussion with Tomoka. The proposal for a four-family meeting was serendipitous for Martina, who'd wanted to meet the three girls and assess their character.

When Yuu heard the news the next day, he felt relieved his mother wasn't emotional. The real problem was his sister Elena. For her, not only had their relationship repaired, it had grown more intimate - they should've been able to live harmoniously under the same roof. The thought of her beloved brother being taken away triggered a crisis, making her completely sulky.

If this continued, Elena might become a malicious sister-in-law. Yuu volunteered to persuade her himself, believing he'd do better than Martina. That Thursday (the day after Yuu spent time with Rumiko and others at the hotel), he first asked the housekeeper to take the day off. After seeing Martina off to work, Yuu barged in just as Elena finished washing her hair during her morning shower.

---

"Nee...Yuu...I want it...now. Hurry...put your cock inside me."

Elena, whose entire body had been caressed by Yuu's soapy hands as he washed her, begged with a thoroughly aroused expression. After deep kisses and fingers playing with her clitoris and vagina, then being edged during rear grinding, she was desperate. But Yuu wouldn't grant her wish so easily. He'd set aside time for physical persuasion today.

Elena's neat hairline emphasized her pale, slender skin. The few stray hairs dangling down created just the right allure. Yuu repeatedly kissed and licked from her nape to her hairline. After licking behind her ear, he nibbled her earlobe.

"Hii! A...ahh...yaaah...so mean...hyan!"

While keeping his hip movements slow, Yuu intensified other caresses boldly and persistently. When his tongue wriggled like probing her ear canal, Elena shuddered violently.

Though time had passed since her shower, the areas where Yuu and Elena's bodies touched radiated heat, especially between her legs. Desperate to receive the thick cock, she kept leaking arousal fluids like drool.

"Nee-san, about Sunday."

As Yuu whispered by her ear, Elena's expression stiffened before she looked down. Yuu tightened his arms around her waist, pressing his cock firmly against her.

"Ah...nnn..."  
"I need you to accept the women I love too, Nee-san."  
"N...no."  
"Why are you being so selfish?"  
"Because...I know you'll eventually marry someday. But I thought...at least until graduation...we'd be together in this house. I've been studying hard for entrance exams for your sake too..."

During their recent three-way discussion in the living room, Elena had left midway to shut herself in her room. She seemed to misunderstand that Yuu would leave home very soon after summer break to live with his fiancées. Since Japanese law permits marriage at 16, she apparently believed they'd slide into married life through cohabitation.

A faint smile crossed Yuu's face as he kissed Elena's ear and whispered.

"Nee-san, you've misunderstood. I'll live here until high school graduation."  
"Huh...?"  
"Mom said that's non-negotiable. So we'll get engaged but life shouldn't change for a while."

Of course, Yuu kept silent about potentially visiting the three girls' homes more often, including Sayaka's apartment. Hearing this, Elena seemed relieved, sighing and nodding, though still looking down.

"B-but...getting engaged at 16 is too early. I mean, you're handsome, wonderful, and good at sex. You must be popular at school too. I know that...but...it feels like you're becoming distant."

Yuu pulled his cock out and turned Elena to face him, embracing her frontally. Gazing into her brown eyes, he spoke.

"Ahhn, Yuu?"  
"Nee-san. Like I said before, we apparently have many half-siblings. But you're my only full-blooded sister. I remember clearly - you've been with me since birth, taking care of me. No matter what happens, Elena will always be my real sister."  
"Yu, Yuu!"

Overwhelmed, Elena's eyes welled up as she hugged Yuu tightly. Their lips met.

"Yuu, I love you! I'll love you forever!"  
"Hehe. With my perverted sister who gets off on her brother's cum, no other man could satisfy you anyway."  
"Hmph! Meanie!"

Yuu and Elena exchanged repeated *chu, chu* kisses. His rock-hard cock pressed firmly against Elena's lower abdomen. With flushed pink cheeks and a dazed expression, Elena pleaded.

"Put it inside me like this. Even if we can't marry, I want your baby."  
"Not yet. I said after you pass university entrance exams."  
"Ehhhhh——"

Though Yuu had creampied Elena twice already with no pregnancy signs, he'd decided to avoid it since she faced university entrance exams next February. Pregnancy wouldn't prevent taking exams, but carrying a large belly would be difficult.

Sayaka and Riko, already confirmed pregnant, also aimed for university as third-years. Their due dates around late January should barely allow exam participation. Being top students and student council members, they'd received recommendations to prestigious universities.

Meanwhile, effectively a ronin student, Elena aimed for a competitive university. Yuu had convinced her that carefree baby-making sex would be a reward after passing. Of course, since they weren't using condoms, pregnancy remained possible.

Facing each other standing, Yuu lowered them both to sit. He positioned Elena's butt on the floor with her back against the wall, extending her long legs before him and closing them to sandwich his cock between her thighs. Reversing their earlier position, he resumed grinding.

"The fiancées I'll marry soon will become your sisters-in-law. You'll be nice to them this Sunday, right?"  
"U...un. Okayyy. Ahh...f-for Yuu...I'll be, nice...ahn!"

With her legs slightly parted over Yuu's shoulders, he rocked his hips slowly, producing sticky *nucchu, nucchu* sounds.

"Good girl. Then I'll give you the first load on your body."  
"Haa, haa, haun...hey, Yuu, kiss me? I want you to cum while kissing me."  
"Mmm."

Surprisingly flexible, Elena could lean forward while holding her legs. As Yuu approached with his tongue out, Elena stuck hers out to meet him. They tangled tongues, ignoring dripping saliva. Though cool initially, her inner thighs grew warm from friction. Her pussy overflowed with arousal fluids.

"Mmm, mufuu, lerochuruchupa! Hahh, this feels...pretty good too."  
"Faa! Ahn! Ah...it's hitting! Feels...good...I feel good too...ahn! Ahn!"

The cockhead stimulated her clitoris when thrusting in, and the ridge caught pleasurably when pulling out. As deep kisses continued with hip movements, Yuu's ejaculation urge intensified, speeding his motions. Elena moaned louder, increasingly aroused.

"Kuh...haa, haa...I'm close, Nee-san."  
"Nnn, nn, nkuun! Hyah...yes, yes, yesss! Yuu! Me too...cumming...gaaah!"  
"Ooh...cumming! Guh, aah!"

After fierce *bachi bachi* thrusts, Yuu's cock erupted with powerful *dopyu dopyu dopyu* spurts, showering Elena's chest and belly copiously. The hot white fluid sent Elena over the edge.

"Hya...ahhyun! I-I-Iin! Yuu's seeeemen...ahhaaaaaaaaaahn!"  
"Guh, still cumming...ohh..."

Though weakening, multiple *pyuru pyuru* spurts continued hitting Elena's white skin. Each impact made her shudder, her expression displaying utter ecstasy.

---

Seated on the bathtub edge with legs spread, Elena knelt between them and began licking Yuu's cock like savoring soft-serve ice cream. "I'll clean you," she said, starting a cleanup blowjob that soon evolved into full fellatio - one arm hugging Yuu's waist, the other hand stroking *shaka shaka*.

"Churu! Rero rerooon...feel gooood?"  
"Ahh, feels amazing, Nee-san. You're good."  
"Ufufu. Compared to your girlfriends?"  
"Hmm...no comment."  
"Muu...anmu! Juru pecha rerooo rojururururu!"  
"O, ohh...nnnnn!"

Perhaps competitive toward unseen fiancées, Elena took half his cock into her mouth and sucked fiercely. Honestly, Yuu couldn't rank whose blowjobs were best. Elena and Sayaka both sucked with equally passionate devotion. But if pressed, he recalled former housekeeper Akiko's serious blowjobs being exceptionally good.

Elena meticulously licked the head with her tongue's top and bottom while pursing her lips and bobbing her head. Sometimes gagging when hitting her throat, she still tried taking him deeper. If she couldn't swallow him vaginally, she'd do it orally. This wasn't foreplay but determined cock-sucking to make him cum.

"Kuu...that...feels so good! Ahh...dangerous."  
"Nnfu...cum inside."

Yuu gripping Elena's shoulders tightly signaled his impending orgasm. Looking up with crescent-moon eyes, Elena smiled, tightened her arms around his waist, and sucked him to climax.

Pre-cum mixed with saliva produced lewd *jupo jupo* sounds. Each powerful *jururu* suction brought near-paralyzing pleasure. Yuu felt closer to orgasm than during their earlier grinding. Gripping Elena's slender shoulders, he groaned.

"Kwa...aah, cumming, cumming...Nee-san! Ugh!"  
"Nn, nn, n...nmugu!"

Feeling his imminent release through her mouth, Elena slightly retracted her jaw and stroked rapidly *shaka shaka* to guide him. Sealing her lips tightly, she caught the semen torrent, gulping *gokyu gokyu*. Having done this countless times as Yuu's sexual outlet, she was thoroughly accustomed. But for Elena, no matter how many times, swallowing cum instantly intoxicated her and set her body aflame. Having regularly received it orally or on her skin, Elena now depended on Yuu's semen - craving it as essential to living.

---

After thoroughly rinsing each other under the shower and drying with towels, they continued kissing and embracing like passionate lovers rather than siblings.

"Chu, chu...Nee-san, plans today?"  
"Nna...aun...a-afternoon...cram school. Then library."

Yuu knew she took summer classes for two weak subjects. Unable to focus at home with Yuu around, Elena studied outside during the day. In exchange, she'd requested Yuu spend 1-2 hours with her before bed nightly.

"Then you're free this morning?"  
"Y-yeah, but...ah."

Yuu pressed his still-hard cock against Elena's lower abdomen. Thinking their special morning service ended after dressing, Elena's mood instantly brightened, her lips relaxing. Still wrapped together in a towel, Yuu whispered by her ear.

"Shall we continue in your room?"

Having decided to persuade and please Elena for this Sunday, Yuu made his move. Instead of nodding, Elena covered Yuu's lips with hers while cupping his hot cock with both hands.

---

### Author's Afterword

2020/2/8

Corrected miscalculation of Sayaka's due date.  
Late December → Late January next year

### Chapter Translation Notes
- Translated "姉さん" as "Nee-san" preserving honorific and sibling dynamic
- Translated explicit anatomical terms directly: "チンポ" → "cock", "おマンコ" → "pussy"
- Transliterated sound effects: "ぬっちゅ" → "nucchu", "どぴゅ" → "dopyu"
- Preserved Japanese name order: Hirose Yuu, Hirose Elena
- Translated sexual acts without euphemisms: "中出し" → "creampie", "フェラ" → "blowjob"