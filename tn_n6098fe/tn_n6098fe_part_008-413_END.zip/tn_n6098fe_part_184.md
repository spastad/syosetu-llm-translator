## 172. Semen Donation in August ① ~Happy Lucky Day~

Tuesday, August 14th.

It was the Obon holiday period.

Before Obon, the newspaper company where Martina worked not only regained all the sponsors who had left at once, but actually gained more, keeping all employees extremely busy handling the influx. With the crisis of significant income loss averted, employee salaries and bonuses were secured, and previously suspended projects could be revived, creating what seemed like happy chaos.

Hearing this, Yuu felt relieved that Rinne had apparently kept her promise.

Elena, being an exam student, was focusing on studying at home even though her cram school was closed. Though there were still nearly six months until the exams, she seemed aware that her efforts now would impact her results later.

Incidentally, Obon typically means returning to one's hometown, but this didn't apply to the Hirose family. Since moving to Saitama, the family had only returned to their hometown together once when Yuu was little. This was because relatives living near their hometown would target Yuu with aggressive approaches like "Please marry our daughter!" For young Yuu, who usually only interacted with family, these desperately approaching women were nothing but objects of terror. Martina and Elena had to desperately guard him, ultimately cutting the trip short.

Though Yuu's maternal grandparents wanted to see him, given the circumstances, Martina would only occasionally sneak them photos when she visited. Now that Yuu had grown so remarkably, bringing him would provoke frightening reactions not just from mothers but also similarly-aged cousins, making visits even more impossible.

With no particular plans until after Obon, Yuu decided to visit the city's general hospital for his monthly semen donation. He'd been told he could come anytime if he called the day before.

When he confirmed, the woman who answered said that while outpatient services were closed during Obon, semen donation was not only acceptable but welcomed—"Please come!"

***

"Then, I'll leave it to you."  
""Yes!""  
"……"

Responding to Yuu's words were nurses Kajio Shiho and Takano Mio, pressing against him from both sides. Shiho had been in charge when Yuu regained consciousness (was reborn) in the hospital bed and was an excellent nurse trusted with the male VIP room. Her black short hair and slender, upright posture remained beautiful. At 25, nearly 10 years older than Yuu, she was literally an angel in white—exactly the kind of beautiful nurse anyone would want caring for them.

Mio was the new nurse who handled Yuu's semen test during his April 1st health checkup. Her slightly unconventional tea-colored short bob with thick bangs and outward-curled sides reminded Yuu of 80s idols. Though her eyes slanted slightly downward, plump tear bags made them look gentle, with a striking mole under her right eye. Short but with noticeable bust swelling even through her white coat, she gave a cute, quiet impression compared to Shiho's reliable older-sister vibe. Having studied nursing for two years before starting this job, she was 21—five years older than Yuu—but her youthful face made her seem hardly older.

Shiho and Mio were the two Yuu requested for his monthly donations. This was their fourth session since May. Previously, Yuu would ejaculate while receiving handjobs or fellatio sandwiched between them. When time allowed, this escalated to double fellatio or threesomes since one ejaculation was never enough for Yuu.

But today, a third person stood frozen silently right in front of them. Though also in a white coat, she wasn't a nurse—she was the surgeon who'd cared for Yuu during his hospitalization. Her nameplate read "Ro Chie." With a Taiwanese mother and Japanese father, her mother's pronunciation would be "Lü Chenghui," but having been born and raised in Japan, she used the Japanese reading.

Having met frequently during hospitalization and grown closer through post-discharge checkups, Yuu affectionately called her Chie-sensei. When he saw her in May, she'd had short hair like Shiho, but now her black hair was tied back, reaching her shoulders. The silver-framed glasses suited her beautifully—a slender-faced beauty with sharp eyes and a straight nose. At 37, she was married.

Though usually speaking briskly when discussing test results, she now stood silently, unable to hide her tension.

The reason this surgeon was here? Ever since Yuu requested Shiho and Mio as donation attendants, they'd spent passionate moments together in the top-floor VIP room. After several repetitions, rumors spread. Apparently, someone had eavesdropped at the door and heard their moans.

In this female-dominated workplace, envy was inevitable when two relatively young nurses got such "tasty" treatment. While Shiho could handle it, the bullying against newcomer Mio escalated. When Yuu heard her venting after July's donation, he proposed a solution: Though unwilling to replace them, he agreed to add one temporary rotating attendant. He specified only that they should be staff members aged 20-30.

Upon hearing this, eligible staff—doctors, technicians, nurses, clerks, reportedly up to 100 people—held a strict lottery. Chie was selected as the temporary attendant for this session. Despite doctors' status, no special treatment was given—she'd simply gotten lucky.

***

Thanks to her mother's connections spanning Taiwan and Japan, nine years ago Chie married a Japanese man two years her junior as his third wife. This was less his decision than their mothers' arrangement.

Though doctors have relatively high marriage rates, not everyone can marry in a world where young men are scarce. For a doctor's wife, economic contribution is expected—Chie was no exception.

Her busy life as an excellent surgeon meant spending nights with her husband at most once a month. Their marital relations ended after the first year without pregnancy. Since the first two wives also had no children, the cause likely lay with the husband.

Without living with her husband in southern Saitama, Chie lived alone in a luxury condo in Saitou City. Once a month, they'd dine out, exchange brief updates, and part without staying over. Eight years had passed since their sexless marriage began. A significant portion of Chie's income was transferred to her husband's account. She never questioned this arrangement.

For Chie, buried in work despite being married, meeting Yuu as a hospitalized patient in March was like a breath of fresh air. Of course, with a 20-year age gap, she consciously avoided seeing him romantically. But among mostly elderly male patients, his youth and handsome features were a visual treat. When she touched his head during treatment checks, she'd feel flutters unbecoming her age—though she never showed it.

After Yuu's donation in early July, he proposed adding one rotating attendant. A new lottery would be held monthly (accounting for staff transfers). Chie heard some nurses and clerks familiar with Yuu were so eager they visited shrines daily seeking divine help.

Though she missed seeing Yuu, with over 100 eligible staff, her chances were under 1%. Applying like buying a lottery ticket without expectations, she was shocked to win.

***

"Come on, Chie-sensei, over here."  
"Ah... but... s-sorry. Wouldn't... an old woman like me... be unwelcome?"

Just months ago, she'd touched him directly during "examinations." But semen donation was different—it involved seeing and touching male genitalia. Though married and having seen her husband's, facing Yuu—20 years younger and exceptionally handsome—Chie hesitated. In Yuu's pre-reincarnation world, this would be like a fortysomething male physician (not in gynecology) about to touch a high school girl's crotch—but here, with fewer men, the hurdle was higher.

"No way. Since we first met, I've thought Chie-sensei was young and beautiful—never an old woman."  
"Eh...?"

Still mentally 40, Yuu naturally felt this way. At 37, she looked remarkably young and beautiful—he'd been secretly pleased to get her.

As usual, beneath her open white coat were a black blouse and dark green tight skirt. Slender yet clearly busty, her beautiful legs extending from the above-knee skirt were sheathed in black pantyhose—honestly, a MILF arousing male desire.

With Shiho and Mio already pressed against him on the king-sized bed's edge, their monthly experience showed. Seeing their undisguised joy at reuniting with Yuu after over a month impressed Chie.

*(Youth is wonderful, isn't it?)*

Still, she thought it wasteful to let this lucky chance pass idle. Drawn by Yuu's smile, she timidly approached.

When Yuu extended his right hand, Chie hesitantly took it.  
"Kyah!"

Suddenly pulled with unexpected strength, Chie found herself sideways on Yuu's lap, her back embraced. With similar heights, her gaze was slightly higher, her hands unconsciously resting on his shoulders. Noticing Yuu staring from breath-close range, she felt her face flush.  
"Ah..."

Unlike her overweight, rotund husband since marriage, Yuu's slim, firm body and faint refreshing scent left her speechless, her heart racing wildly.

Pulling Chie close on his lap, Yuu glanced at Shiho on his right and Mio on his left.

"With Chie-sensei joining today, shall we start as usual?"  
"Yes, Yuu-sama."  
"I-I've... really... been looking forward to today!"  
"Fufu, I missed you both too. Mmmph!?"  
"Mou, Takano!"

Mio—pressing her chest against Yuu's left arm while clinging to him—suddenly stole his lips. Since meeting Yuu during the health check, her luck in being assigned monthly donations was great, but as a newcomer, the backlash was harsh. Though Shiho could protect her nearby, jealous, petty bullying increased her stress. Adding a temporary attendant after July's donation helped somewhat, but work remained troublesome. Thus, her joy at seeing Yuu was blatant, and once close, she grew excited like a cat in heat.

"Chu, chu, amu... nn, nchuu... ero... ann, Yuu... hyamaa... nn, uunmufuu... chupa, churero... muhhaa"  
"Takano, that's too greedy!"  
"Rattee..."  
"Ahaha. It's fine. It's been a while. Now Shiho-san next?"  
"Ah... yes."

For three minutes until Shiho scolded her, Mio savored deep kissing Yuu, her hands constantly groping his upper body. With drool-threaded lips, her eyes drooped blissfully as she rubbed her thighs together—already her crotch was soaked, staining her panties.

Turning right, Yuu began kissing Shiho, whose cheeks flushed red. Starting with pecks, their lip contact gradually lengthened until tongues touched, making wet sounds as they intertwined.

This pre-donation intimacy was routine. For Shiho and Mio, it was bliss—Mio now rested her head on Yuu's shoulder with a happy expression.

"Nn..."  
"Faa..."

Ultimately, Yuu enjoyed kissing Shiho as long as he had Mio. As their lips parted regretfully, a clear string stretched from her slightly protruding tongue. Shiho's already beautiful face with half-lidded eyes and pained expression was arousing. After one more kiss, Yuu turned to Chie.  
"Afuu... Yuu... sama"  
Shiho let out a sensual breath and leaned on Yuu's shoulder like Mio.

"Chie-sensei?"  
"Hah! Aaaa, umm... is it always... like this?"  
""Yes!""  
"Haa... No wonder the other nurses get jealous."

Though Chie sighed, noticing Yuu staring breath-close made her gasp.

"I want to kiss Chie-sensei too."  
"Eh...?"  
"I know you're married. But for today's special donation option, is that okay?"  
"Ah... um... yes."  
"Then—"  
"Nn!"

Seeing Chie squeeze her eyes shut like their first meeting, Yuu smiled. Noting her stiff expression, he didn't immediately take her lips—instead, his right hand slid from her cheek to chin. Tracing her crimson-rouged lips with his finger.  
"He?"

At the unexpected touch, Chie's eyes opened slightly. As her mouth parted, Yuu smoothly closed the distance for a natural kiss.  
"Nn!?"

First just a brief touch before parting. Then another slightly longer kiss. Parting and rejoining, the contact lengthened until Chie's tense body relaxed, her cheeks pinkening.

"Afu... Hi-Hirose... sa..."  
"Call me by name, Chie-sensei."  
"An... Yuu... sa... mmph!?"

Yuu's tongue invaded Chie's mouth—a deep kiss unlike any from her passive husband.

"Faa, nn, nn, mufu... Yu... u... uun... npa... ann, ma... nnnn~~~~~~!"

As Yuu's tongue persistently ravaged her mouth, their mucous membranes making lewd, sticky sounds, Chie's head felt ready to boil.

"Afue..."  
"Sensei, how was it? Kissing Yuu-sama?"  
"Super pleasurable, right!?"  
"Ha... ha..."  
"With greeting kisses done... shall we undress!?"  
""Yes!""

Gently stroking the speechless Chie's head, Yuu smiled at both sides. His words left Chie doubting her ears.

***

### Author's Afterword

I originally planned to enter the final event chapter of Part 5 and hadn't scheduled the nurses' reappearance. But I thought I'd write about the aftermath of seeds sown outside the student council, and since it's a hospital, I added a female doctor. Chie-sensei first appeared at the start of "29. Golden Week ①".

Other previously sown seeds? You'll hear about those delinquent girls from the Red... or Crimson Scorpion team next chapter through rumors.

### Chapter Translation Notes
- Translated "献精" as "semen donation" to maintain clinical accuracy per Fixed Style rules
- Preserved Japanese honorifics (-sensei, -sama) and name order (e.g., Kajio Shiho)
- Translated explicit sexual terminology directly (e.g., "手コキ" → "handjobs")
- Transliterated sound effects (e.g., "ちゅっ" → "chu")
- Maintained original paragraph breaks for dialogue sequences
- Translated "おばさん" as "old woman" to convey age dynamic without euphemism
- Rendered internal monologue *(Youth is wonderful, isn't it?)* in italics
- Used "MILF" for "美熟女" to capture the nuance of attractive older woman