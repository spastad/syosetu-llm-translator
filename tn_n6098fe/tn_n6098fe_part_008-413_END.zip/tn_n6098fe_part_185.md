## 173. Semen Donation in August ② ~Three People~

Yuu thought women looked hottest when partially undressed in uniforms or costumes, just enough to reveal their underwear. 

As a man, he certainly wanted to see women naked, but stripping off the entire uniform defeated the purpose. Practically, clothes might wrinkle or get stained, yet the classic approach remained starting intercourse while half-dressed.

Thus, at Yuu's request, Shiho and Mio pulled their one-piece white coats down to their abdomens. Normally they'd wear inner layers to prevent underwear visibility, but in this world, almost no men besides Yuu appreciated see-through lingerie. In summer, they wore bras or camisoles directly under their coats. Though white tights or stockings were common, both went barefoot today since "they'd remove them anyway."

"Come on, take off your bras too! Show me your breasts!"  
"Ahn! Yuu-sama, your pants look tight too!"  
"Yes yes! We can tell it's already big!"  
"Yeah, because you're both so captivating. I'm getting excited."  
""Yuu-sama!""

Mio unhooked her own bra, making her soft-looking G-cup breasts sway. Yuu immediately cupped and kneaded them with his left hand. While sucking Shiho's collarbone, he unhooked her bra with his right hand. Though Shiho had modest B-cup breasts, her large nipples were sensitive. When Yuu lowered the cup and sucked her nipple, Shiho moaned and arched her back. Both nurses lifted Yuu's polo shirt hem to grope his chest and back.

"Will Chie-sensei undress too?"  
"Hah... yes."

The trio's open intimacy had captivated Chie. Until now, she'd suppressed gender awareness due to their doctor-patient relationship and 20-year age gap. But sitting on Yuu's lap, feeling his breath, and especially their earlier intense kiss, had awakened her feminine instincts.

*(I want to... do the same thing too)*

Startled, she withdrew her hand from Yuu's shoulder and frantically unbuttoned her black blouse. Once all buttons were open, her slim upper body—free of excess fat—was exposed. Her black half-cup lace bra supported decently voluminous breasts. Without prompting, she unhooked it, revealing upright, bowl-shaped breasts neither too large nor small, with cherry-like nipples showing minimal pigmentation for her age.

"Chie-sensei's breasts are so beautiful and delicious-looking."  
"Eh... th-thank... kyaun!"

Before the bra fully came off, Yuu latched onto her right breast. Chie gasped as electric tingles shot through her.

"Haa, haa... Yuu-sama kneading my breasts... feels sooo good. Ah, fuhn... Only Yuu-sama makes me feel this way..."  
"Nn, nnn~~~~... ah! Ann! No, Yuu...sama! Don't tease like that... ann!"  
"Hah! Ha, a, a, ahkun! Yu, Yuu-sha... hyaan! Don't... suck so... ahh!"

Yuu kneaded Mio's breast with his left hand, Shiho's with his right, while his mouth devotedly sucked Chie's nipple—simultaneously enjoying small, medium, and large breasts. His hands didn't just squeeze; he pinched nipples with fingertips and squeezed them between fingers. His tongue licked meticulously, even giving gentle bites. Shiho and Mio's soaked pussies left love-juice stains on the sheets as they sat spread-legged.

"Hahh. Now the left."  
"He... ma, Yuu...sa... aahn! Hah, hah... that side too... i, ah... feels... so good!"  
"Fufu. Good. I want to please Chie-sensei more."

After savoring the right breast until drool-covered, Yuu turned leftward. Gazing up at Chie's face, he opened wide and sucked. Though married, Chie's sex life had been barren. She'd never received such breast stimulation—after all, women obsessed over male bodies here, not vice versa. Without physical contact, mere proximity or nudity made women spontaneously aroused. Men's "delicate" bodies required careful caressing—that was common sense. But after the kiss and relentless sucking, pleasure dwarfing her marital experiences surged through her. She'd been moaning uncharacteristically loud.

Yuu reveled in the trio's intense reactions, his mouth and hands moving busily. His left palm softly kneaded Mio's large breasts without rough squeezing. 

"Ah, ahfuhn... Just having my breasts kneaded... by Yuu-sama... hah, nn! Feels sooo good."  
Mio rested her head on Yuu's shoulder, breasts jiggling, expression blissful.

Meanwhile, Shiho—her nipples persistently teased—lifted her hips and rubbed her pussy over her panties.  
"Nn, nnn! Ann! Yuu-sama! Yuu-sama! Ahh! Good!"

Their hands slipped under Yuu's polo shirt, first playing with his nipples, then descending downward.  
"Ah, Yuu-sama's..."  
"Chin-sama... so haaard."  
"Ufufu. Magnificent."  
"Oohf."

Mio's left hand and Shiho's right now stroked his bulging crotch, making Yuu gasp. But he hadn't forgotten his purpose. He let them touch him while focusing on Chie's breasts.

At the right moment, Yuu detached from her breast with a "chupon" sound.  
"Shall we begin?"  
"Ye...yes...nn..."  
"Yuu-sama! Haan!"

Yuu kissed Shiho's feverish gaze. Mio—elated by the long-awaited touch—kept eyes and hands on his crotch, so Yuu kneaded her breasts more.  
"Mio, prepare the equipment. Shiho-san and Chie-sensei—undress me?"  
""Yes!""  
"Eh...?"  
"Can't donate without undressing."  
"R-r-right. Ahahahaha."

The semen-donation container—resembling a large black thermos—sat bedside. Mio reluctantly left his crotch to prepare it. Shiho unbuttoned Yuu's jeans. When he lifted his hips, they slid off. Now only in trunks, his erection tented obviously. Chie gaped, hand over mouth.

"Now, Chie-sensei? The underwear please."  
"Hah! Yes!"

The nurses moved efficiently despite earlier moaning. Chie hurried off Yuu's lap and crouched to grip his waistband.  
"It's fully erect—don't snag it. Stretch the front open while pulling down."  
"O...kay. Like this."  
"Ugh!"  
"Ahh! S-sorry!"

The elastic caught on the tip—longer than Chie expected.  
"Wow! Th-this is... unreal?"  
"Sensei, amazing right? Yuu-sama's penis."  
"We were shocked too first time! Ufufu."  
Shiho and Mio smiled. Though she'd seen the bulge through his trunks, it dwarfed her husband's. Chie stared speechless at the thick, long penis.

Yuu patted her head.  
"Take it all off?"  
"Ah... r-right."

Shiho neatly folded the trunks and jeans. She returned to Yuu's right side while Chie and Mio swapped places—Chie now on his left. Mio knelt between his spread legs, holding the rubber cup attached to the container's hose.

"Erm, we'll begin Yuu-sama's semen donation."  
"Yes, please."

Shiho prompted Chie to join her—their hands overlapping on Yuu's shaft for a handjob.  
"Ufu. Beloved Chin-sama... chu."  
Mio kissed the glans, then deepthroated it when precum dripped out, swirling her tongue inside.  
"Kuh, oh... good."

With beautiful nurse and doctor attending him, Yuu spread his arms, pulling Shiho and Chie close. Shiho rested her head happily, Chie shyly, both stroking while watching his crotch. Chie—who'd used thumb-and-forefinger circles on her husband—learned Yuu's huge penis required her whole palm.

"Yuu-sama, tell us when close."  
"Yeah... still okay. Chu."  
"Nn... nfuh."

Shiho jerked him "shiko shiko" while speaking; Yuu answered by kissing her.  
"Ah, a penis... so hard and hot."  
Chie gazed dazedly at the heat and hardness. Seeing Yuu kiss Shiho, she leaned in wanting the same. When Yuu noticed, he whispered "Chie-sensei too" and kissed her, stoking her desire. She rubbed her thighs together.

"Nchu, churu re roo... haa, haa, Chin-sama, wonderful... Shape, hardness... I've dreamed of this. Just seeing/smelling it... makes me dizzy... nn~~~ chu! Chupa! Amure ro rereron hafuhn!"  
"Ah, ah, Yuu-sama, I... just this... haun!"

Unnoticed, Mio and Shiho used free hands to finger themselves. Sticky sounds from Yuu's crotch—precum and saliva mixing—now blended with their fingering noises. Yuu lowered his hands from their waists, hiking their coats to grope their asses. His finger slipping into Shiho's panties felt her anus soaked.  
"Ah... nn, hah... ann!"

Pressed against Yuu, Chie couldn't stay unaroused. Since her late twenties, work left no masturbation time—sleep mattered more. But hiking her tight skirt, she touched her panties—wetter than expected. Rubbing slowly felt so good she moaned. When Yuu's hand touched her sensitive spot, she jerked.  
"Chie-sensei's feeling it too. Good."  
"Haaaaaa... Yuu-sama!"

Seeing Yuu smile at her, affection overwhelmed Chie. She kissed him fiercely, handjob speeding up.

The trio's devoted attention—plus two days of abstinence—made Yuu's climax surge.  
"Ah, ah... I'm close..."  
"Fai, hyou hi ta hi mashita!"

Mio—deepthroating—saw Yuu's pained expression and grinned. She pulled off, capping his glans with the rubber cup.  
"Ann, ann! Yuu-sama, Yuu...sama! Ahh!"  
"Fah! Ahh! Ann! Good! I... it's goood!"

Shiho and Chie—faces buried in Yuu's chest—seemed near climax too.  
"Guh, ahh!"  
"Ready?"

Mio stayed duty-focused but drooled at Yuu's expression. Seeing him nod, she hit the container's yellow button.  
"Ugh! Ohh..."

A vacuum-cleaner-like roar sounded. Yuu groaned as his penis got violently sucked—semen forcibly extracted. He hadn't felt this in a month. Though impersonal, he feared getting addicted.

Simultaneously, Shiho and Chie climaxed, slumping against Yuu. Mio checked the semen volume through the side window. Smiling, she set storage mode, then licked Yuu's still-dripping penis.

---

### Author's Afterword

After such pleasure, he gets 50,000 yen monthly too (from "62. Semen Donation ①"). 

WHO states average semen volume is 1.5ml (Yuu likely has double).  
1990 gold prices were ~2000 yen/gram.  
Though semen density vs. water is unknown, preventing direct comparison, Yuu's semen seems more valuable than gold here.

### Chapter Translation Notes
- Translated "献精" as "Semen Donation" to match previous chapter terminology
- Preserved Japanese honorifics (-sama, -sensei) and name order (e.g., Kajio Shiho)
- Used explicit anatomical terms ("penis," "breasts," "precum") per style rules
- Transliterated sound effects (e.g., "chupon," "shiko shiko")
- Formatted internal monologues in italics
- Maintained dialogue structure: new paragraphs for speaker changes, except with attributions
- Translated sexual acts without euphemisms ("handjob," "deepthroating")