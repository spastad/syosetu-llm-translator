## 174. Semen Donation in August ③ ~If Wishes Could Come True~

"Yuu-sama, may I have a moment?"  
"Eh? Ah, sure."  

After the semen donation, they would usually proceed to a threesome. But with Chie present today, as Yuu was contemplating their next move, Shiho requested to speak with him. Their disheveled clothing remained unchanged, and Yuu's lower body was still exposed.  

Yuu sat near the center of the bed with Shiho and Mio on either side. Chie sat slightly apart.  

"Um, actually... that is..."  
"Hm?"  

Shiho and Mio exchanged glances but seemed hesitant to speak. Though intimately familiar with each other's bodies, they now only met during monthly semen donations. Perhaps they felt reserved because of this.  

"What is it? Don't hesitate."  
"W-well... It's hard to say it to your face..."  
"......"  

Yuu noticed Mio unconsciously rubbing her abdomen. Not the gesture of someone full after a meal, but an absentminded movement. Their first unprotected intercourse had been around late April - three months prior.  

"Could it be... you're pregnant?"  
"...!"  
"Ahaha... Exactly! Both senior and I are three months along!"  

Mio responded cheerfully while Shiho remained bowed, unable to meet Yuu's eyes - perhaps still influenced by her VIP room attendant habits.  

"I see, I thought so."  
"Ah... Yuu-sama, is this troublesome?"  
"Troublesome? What are you saying? I'm delighted. And both at the same time! Nothing could be more blessed."  
"Eh...?"  
"Does that mean...?"  
"You'll give birth, right?"  
""Yes! Of course!""  

In this world, women clearly felt anxiety when announcing pregnancies to men. Though 16-year-old Yuu could legally marry, neither woman seemed to expect that. They only requested his signature on a cognition certificate at birth, which Yuu gladly promised.  

The cognition certificate proves a child shares the man's bloodline. When women bear children through rape or undisclosed encounters where paternity is denied/unconfirmed, the child is considered illegitimate. Signing imposes no legal obligations on men, but societal treatment differs drastically between acknowledged and illegitimate children. While modern policies improve conditions for illegitimates due to population decline, historical neglect created psychological significance for mothers seeking acknowledgment.  

Yuu expressed genuine joy at his fourth/fifth pregnancy among intimate partners. Smiling, he pulled both women into an embrace.  

""Yuu-sama?""  
"Shiho-san, Mio. Thank you for carrying my child. Please take care of yourselves and deliver healthy babies."  
"Ahh... Yuu-sama"  
"Ehehe... I'll work hard to deliver Yuu-sama's baby!"  

Mio declared brightly while Shiho wept silently with emotion. The three embraced tightly.  

As Yuu stroked their heads, he noticed Chie gazing wistfully out the window.  

"Chie-sensei, do you have children...?"  
"Eh? Ah..."  

Turning with a strained smile, Chie shook her head.  

"None."  
"I see..."  

Reproductive matters between spouses were delicate. Yuu hesitated to probe further, but Chie continued unprompted.  

"We've been sexless since our second year of marriage... Since none of his three wives conceived, the issue likely lies with my husband."  

Mandatory annual semen screenings meant men's fertility was documented. Rumors even claimed completely infertile men avoided marriage but were forced into sex work. Chie's husband likely had severely low sperm count.  

Preoccupied with work, 37-year-old Chie hadn't considered wanting children until now. Hearing the pregnancies announced before her, the emptiness of her marriage - childless yet financially supporting her husband - surged within her.  

"Chie-sensei?"  
"Na... kyaa!"  
"Want to try making a baby with me?"  

Chie gasped as Yuu suddenly appeared before her, taking her hands. From Sayaka's experience, Yuu knew women faced no condemnation for bearing children outside marriage here. Why not provide the sperm himself?  

"Th-that's... What are you saying to a 21-years-older woman...?"  
"I told you earlier - to me, Chie-sensei is young and beautiful. Frankly, I want to have sex with you."  
"Fue... Yuu-sama? Aah"  

Chie recoiled as Yuu embraced her, stopping her fall by pulling her close and claiming her lips.  

"Let's make a wager?  
As today's special arrangement, we'll have sex just once.  
Whether you conceive... we'll leave to fate."  
"Ah..."  

Yuu recalled that late-30s pregnancies carried higher miscarriage and congenital defect risks. He didn't insist on conception at all costs. But Chie's lonely expression mirrored his past self - congratulating colleagues' newborns while hiding envy. Normally, single unprotected intercourse had low success rates, but Yuu's "Special A" graded semen might improve the odds.  

Chie couldn't deny her feminine excitement at Yuu's proposition. The thought of sex with this beautiful boy stirred guilt yet undeniable arousal - a first in 37 years. Earlier, she'd dripped arousal fluid uncontrollably.  

"Yu, Yuu-sama"  
"Yes, Chie-sensei?"  
"P-please... take care of me"  
"Likewise. Shall we undress?"  
"Hya!?"  

Chie gasped as Yuu immediately rolled up his polo shirt. Compared to her husband, his toned musculature captivated her. More astonishingly, though he'd just ejaculated, his penis stood fully erect. Just how extraordinary was this boy?  

"If Yuu-sama is involved, Chie-sensei surely..."  
"After all, it's Special A grade!"  

Shiho and Mio made space at the bed's center as Yuu moved there naked. Chie undressed hastily, blushing when noticing transparent strands stretching from her vulva as panties came off. Yet seeing Yuu's erection ignited a throbbing in her lower abdomen.  
*(Ah, that... Yuu-sama's penis... I want it)*  
Awakening to unprecedented desire, Chie crawled toward Yuu on all fours.  

***

"Haah, haah, it's... going in! Heeh? St, still? Aaah! So big!"  
"Only halfway. Kuh! Chie-sensei's vagina is tight!"  

In a face-to-face seated position, Chie lowered herself onto Yuu's lap. Her vaginal readiness skipped foreplay. Contrary to expectations of age-related laxity, her childless vagina remained exceptionally tight. Combined with an 8-year abstinence and only experiencing smaller penises, the penetration felt virginal. Yuu finally thrust fully by bracing her shoulders and hips.  

"Kyauu! Vaa... ha, hi... it's... in... D-deep inside... ah, s-something hard... grinding... aaah!"  
"Ooh... Chie-sensei, it feels too good... I can't hold back"  
"Aah! Ahi... st-stop... moving... aaahn! D-deep! Yan! Stop! I'll go crazy! I-I've never... felt this aaaah!"  
"Can't stop even if you say so. Ahh, feels amazing... How about you, Chie-sensei?"  
"Nn, nn... Aaahn! I-It feels good! Yuu-sama's penis feels so good! An! An! An! Amazing! Something... amazing!"  

Initially gentle with kisses and breast caresses, Yuu accelerated as Chie's lubrication eased entry while maintaining improbable tightness.  

Unlike her impotent husband, being held by Yuu's sturdy frame while penetrated from below made Chie - now knowing true sex - drown in pleasure. She clung to his back desperately. The cool, intellectual doctor vanished, replaced by a panting female animal.  

"It's amazing... Yuu-sama's sex... Ahh, just watching makes me so... horny..."  
"Y-yes... I understand... aahn..."  

Shiho and Mio watched while clutching themselves, hands straying to nipples and vulvas Yuu had touched earlier. They longed to be held like that too. The passionate sex unfolding before them compelled such thoughts.  

***

"Aah, aah, akuu... I... can't... anymore... I... Yuu... sa... ma! Hauu! Nnn!"  
"Chie-sensei. Are you close? It's fine. Don't hold back, cum."  
"Hyaii! Ah, hiiin! Yuu sha... penis... amaz... ooh, ooh! Amaz... ing! Aaaahhhhhaaaaaaaah!!! I'm cummiiiiing!!!"  

Chie experienced her first vaginal orgasm - unknown with her husband. Yuu's thrusts tossed her in tidal waves of pleasure until climax overwhelmed her. Her vision whitened in euphoric release. But Yuu's hips kept pounding.  

"Fuaa! Yu, Yuu... sa... ma!"  
"Chie... sensei!"  

Chie pulled Yuu's head to hers, tongues tangling fiercely as he continued thrusting. Wet slaps echoed alongside sticky fluid sounds from their junction. Amidst passionate kisses, Chie suddenly jerked her chin up.  

"Hiaa! Aah! Aah! Aaah! Ag... again... Cumming! A... hi! C-c-cumming!"  
"It's fine, Chie-sensei, cum as much as you want?"  

Yuu's whisper while licking her sweaty neck triggered a second vaginal orgasm. Chie clung limply to him afterward, cheek pressed to his. But Yuu neared his limit, thrusts intensifying.  

"Hya! Yu, Yuu-sama!? St, stop... I just... came... aahn! T-too rough!"  
"Sorry, Chie... sensei! I... I'm... ugh... close too!"  
"Ah, hi, ag... again... Cumming! Aah... ah... ah... nooo!"  

His rhythmic thrusts shook Chie's hair and breasts, sweat glistening on her skin. Overwhelmed despite climaxing, she could only gasp incoherently.  

"I'm cumming... Chie-sensei, I'll fill you inside. Get pregnant!  
Aah! Kuha! C-cumming!"  
"Aah! Ooh! Iiih! N-no... ehh... aah... kunn! Yu, yu... sa... aaaaaaaaah!!!"  

Whether Chie heard his pre-ejaculate warning was unclear. But she certainly felt the scalding flood in her womb - and the unparalleled ecstasy that followed. This was true mating. She might truly conceive. Screaming louder than ever, this conviction flashed through her mind.  

After laying exhausted Chie down, Shiho and Mio immediately clung to Yuu. With a wry smile, he received double fellatio before servicing them consecutively.  

***

◇ ◆ ◇ ◆ ◇ ◆  

***

The following is an epilogue.  

That single encounter proved remarkably effective. Three months later, Chie's pregnancy was confirmed. She safely delivered a girl the following spring.  

She informed her husband about the pregnancy and different paternity. He showed no reaction, having acquired a fourth wife ten years younger - Chie's value now reduced to financial provision.  

But upon the birth, her mother-in-law intervened. Though not biologically related, she demanded to raise the child as the husband's heir. Chie's fury ignited. How dare they mock her? This child was her treasure from Yuu. Though restraining immediate outbursts, Chie - now awakened as a mother - acted decisively.  

She hired a lawyer prioritizing wives' rights in divorce. Citing the husband's failure to reciprocate her financial support, she demanded a no-alimony divorce.  

Wives rarely initiated divorce. The husband resisted, demanding substantial alimony - confirming his financial motives. The case reached family court. With no cohabitation, the court ruled Chie wasn't obligated to continue the marriage. No alimony was granted. Regarding parental rights, the husband had no claim after eight sexless years and different paternity.  

Meanwhile, the girl named Yurie (祐里恵) thrived. Colleagues remarked she'd grow beautiful, resembling either or both parents. Holding sleeping Yurie, Chie reflected. Being chosen as Yuu's temporary donation supervisor felt like life's greatest luck then. But true fortune was meeting this child who colored her once-empty married life.  

### Chapter Translation Notes
- Translated "認知証明書" as "cognition certificate" per Fixed Terms
- Preserved "-sama" honorific for Yuu consistently
- Translated "チンポ" as "penis" following explicit terminology rule
- Used "vulva" for "アソコ" as anatomically precise term
- Maintained Japanese name order (Ro Chie) per style guide
- Italicized internal monologue *(Ah, that... Yuu-sama's penis... I want it)*
- Transliterated sound effects ("Hyaii!", "Kunn")
- Translated "膣内" as "vagina/vaginal" with contextual precision
- Rendered sexual acts without euphemisms ("vaginal intercourse", "ejaculated")
- Applied dialogue formatting rules (new paragraphs for each speaker)