## 179. Dream Hot Spring Resort! ⑤ ~Steamy Love Talk~

After returning to their room once, Satsuki came to pick them up, and Yuu, Mana, and Rina decided to go to the large bathhouse.

Although their room had a unit bath, it would be a waste not to try the hot springs while here.

I heard it's a mixed-gender bath.

In his previous world, the reality of mixed baths was that there were either no women present, or only wrinkled old ladies if any were there.

But here, most were in their 20s. At most, mid-30s, so from Yuu's mental age perspective, they were all younger.

When asked just in case, Yuu immediately answered "I'll go."

Shampoo, conditioner, soap, and towels were provided, so they only needed to bring a change of clothes.

But only Yuu was given a dark opaque bag by Satsuki when leaving the room.

When he held it, it felt soft like clothing.

"This is...?"

"Something for men to wear in the bath."

"Oh... I see..."

Satsuki and the other women walked without carrying anything like that.

Come to think of it, in his previous life, he remembered hearing that mixed baths provided yumegi robes like dresses for women who didn't want to be seen naked.

In this world, it wasn't women but men who covered their skin, making him realize this reality.

Surprisingly few people were heading to the large bathhouse.

They probably finished while Yuu was taking time receiving business cards instead of exchanging them.

More people seemed to be coming out, and on the way, they passed Takuya and Tohru surrounded by five or six women.

"Ah, Yuu's just going now? Let's bathe together tomorrow! I'll wash your back!"

"Ah, well... if the timing works out..."

Wanting to avoid skin contact with men as much as possible, Yuu vaguely dodged the invitation.

"The large bath here is more spacious than ordinary hotels and inns, frankly it's a facility to be proud of. There are several separate baths - could probably accommodate about 50 people comfortably."

"Wow, looking forward to it."

"Peak time has passed so we can relax. Too bad it's underground so no view though."

"I-I'm nervous bathing with a boy, sis."  
"It's fine. You'll wear a bathrobe... But actually, that's even sexier. The skin peeking through the gaps... ugh, imagining it makes me want to nosebleed."  
"Sis?"

While Yuu and Satsuki walked side by side, Mana and Rina whispered furtively behind them.

And Yuu and Satsuki, engrossed in conversation, didn't notice. Several women who had just bathed and passed by stopped, thought for a moment, then turned back to follow behind Yuu's group.

"Whoa, it's huge..."

The changing room seemed more spacious than Nagadoro's Shiromine-kaku bathhouse, easily twice the size.

Of course, the men's bath Yuu previously used was designed for maybe 20 men at most.

In comparison, this was mixed-gender and designed for over 50 people, so its size was expected.

And right now, there were four or five women either undressing to enter or just coming out completely naked in plain view.

They noticed Yuu entering too but showed no shame in hiding their skin.

Rather, women about to enter slowed their movements while showing delight, and those who just came out said things like "Well, since we're here, maybe I'll soak a bit longer" while making obvious U-turns.

"Now, Yuu can change over there. There are simple instructions inside so you should understand."

Guided by Satsuki, Yuu changed in a partitioned corner section for men.

Frankly, he wanted to enter naked, but surrounded by overwhelmingly more women, he obeyed thinking it might be dangerous if they became beastially aroused.

"Like this... whoa!"  
"Wow!"  
"Eek!"

When Yuu changed into the bathrobe and came out, Satsuki and the others were just finishing undressing.

The beige bathrobe hung from a thick neck strap - a sleeveless apron-like garment covering down to above the knees.

The back was completely exposed, tied at the waist with a string to cover the buttocks.

The fabric was stiff and thick, seemingly opaque even when wet.

*(This is just like a nude apron!)*

That was Yuu's actual impression upon wearing it.

Only Yuu thought "Who wants a male nude apron?" - the women's reactions were pronounced.

"So nice. Very sexy."  
"The glimpse of the armpit has such destructive power..."  
"......"

Women watching from lockers further away couldn't help murmuring.

Somehow when Yuu changed and came out, the changing room had doubled to about ten women.

Including latecomers and those who saw Yuu and decided to bathe again.

Yuu himself felt his chest grow hot seeing the completely naked women making no attempt to cover themselves.

Satsuki's well-proportioned figure exceeded expectations.

Her long hair was tied up, revealing her slender neck.

Her large breasts swayed slightly with movement but didn't sag, pointing straight forward.

The curve from her cinched waist to hips was artistic.

Despite being in her thirties, her skin was fine without a single blemish - smooth and moistly fair.

Mana showed a distinctly athletic build with well-defined muscles on sturdy shoulders.

Her breasts seemed small clothed but developed pectorals supported well-shaped mounds.

Her perky upturned buttocks and beautiful athlete's legs. The lingering tan lines were enticing.

In contrast, Rina had sloping shoulders and was slightly plump, but her most striking features were her fair skin and huge breasts. She seemed to unconsciously hide her stomach with both arms, only emphasizing her breasts more without realizing.

Rina seemed concerned about being fat, but she didn't have much excess fat, and her large buttocks rather aroused male desire.

Her thighs were indeed fleshy and thick, but below the knees were slender.

She seemed like a woman whose body would feel good to hold.

With her hair tied up, her apple-red cheeks were clearly visible.

*(Satsuki nee is probably E-cup? Mana nee C-cup and Rina nee seems G-cup or larger.)*

Incidentally, Satsuki had a neatly trimmed inverted triangle pubic area. Mana's was sparse, Rina's thick.

Just looking made him want to touch, and his lower body reacted.

His cock swelled and hardened like a raised cobra head, bulging at the crotch.

"L-let's go."  
"Y-yes! Let's hurry."

Hiding their mutual arousal, they headed to the bathing area.

When Yuu followed Satsuki through the sliding door, cheers of "Whoa!" rose.

The spacious bathing area had at least four baths - large and small.

The women scattered at washing stations and baths - two or three each - couldn't take their eyes off Yuu in the new group.

Yuu too almost smiled seeing naked women everywhere he looked.

Less mixed bathing than one man sneaking into a women's bath. Truly paradise.

"F-first we should wash."  
"This side's free. Let's go."  
"Ah, okay."

Entering, washing stations with showers lined both walls. Satsuki led to the empty side.

Yuu started walking after tearing his eyes from several pairs of breasts watching from the baths, only for his gaze to be drawn to Satsuki's pertly swaying buttocks walking ahead.

"Yuu, want me to wash your back?"  
"Really? Please."  
"Then I'll wash your arms! Rina, you take the other side."  
"Ah... okay."

After washing his hair, Mana immediately jumped at Satsuki's offer.

When they entered, about ten women besides Yuu's group were in the bath, but now it had doubled.

However, only Satsuki's trio were close enough to touch Yuu.

The other women stared intently at Yuu's body with heated gazes.

"Ahh... so nice, a young boy's body."  
"Hmm, agreed."  
"......"

It wasn't anything lewd being done.

Just lathering soap on washcloths or palms to wash him.

But being served by three naked beauties, Yuu felt indescribable pleasure.

Perhaps because of this, Yuu got carried away.

"Hey, I'd rather you wash me with your bodies."  
"Huh?"  
"Wha?"

Mana froze while Rina tilted her head uncomprehendingly.

Only Satsuki seemed to understand, smiling.

Without a word, she lathered soap on her chest and hugged him tightly from behind, moving her body.

"How is it? Yuu, feel good?"  
"Ooh... Satsuki nee's breasts rubbing... feels amazing."  
"Glad to hear it."

The softness of breasts against his back combined with soapy slickness felt heavenly.

Next, Yuu stretched his arms straight down and appealed to Mana on his right with his eyes.

"Got it. Here, Rina too."  
"Huh!? Ah, um... excuse me."

Mana and Rina hugged him from both sides, took his arms, and began washing with their breasts.

"Ahh, I'm so happy..."  
"Haa, haa... I feel kinda strange."  
"Y-Yuu... nngh."

Mana and Rina pressed against him, breathing heavily with pink cheeks.

"So nice, so nice. I want to touch too."  
"Grr, jealous..."  
"Isn't this borderline criminal?"  
"Don't care, want in."

Women who'd been washing or just entering watched with envious eyes.

Meanwhile, Satsuki looking over Yuu's shoulder noticed immediately.

"Yuu, you got hard."  
"Well yeah. Can't help it. Being touched by pretty sisters like this."  
"Yuu really says the sweetest things. Ah~ so cute... mmph!?"

When Yuu turned toward Satsuki who'd brought her cheek close, seeing her alluring lips so near, he impulsively pressed his lips to hers.

Just a light lip touch.

He'd kissed Mana and Rina too, but sibling kisses felt special.

Yuu and Satsuki stayed still, eyes closed, savoring each other's lips.

Bliss spread through their minds.

"Ahh, Yuu!"  
"Satsuki nee!"

Satsuki's face melted as she hugged him tightly, sealing their lips.

"H-hey, you two!"  
"Uu... I want to too!"

Mana tried to stop them, but when Satsuki pulled away, Rina stole Yuu's lips next.

Seeing that, she couldn't just watch.

After Rina, Mana took Yuu's lips.

Yuu's hands hung straight down at Mana and Rina's crotches - a slight stretch would touch their privates. Where his fingers brushed wasn't shower water but love juice seeping from within.

But the women just watching grew beyond envy to anger.

One woman soaking in a bath splashed out noisily, strode over, and shouted.

"Enough already! Everyone's watching in the bath!"  
"Ahh!"

Finally feeling ashamed, Satsuki, Mana, and Rina all pulled away.

Yuu looked up at the imposing woman.

Around 30 years old, tall, busty, and glamorous.

Yuu stood and approached.

Thinking she might have angered Yuu, she awkwardly looked down, but lowering her gaze, she noticed the thick thing jutting from his crotch.

Before she could process it, Yuu suddenly hugged her tightly.

"You're Mitsuba Michiko-san from Mitsuba Construction, right? Sorry, forgive me with this."  
"Mmph!?"

Fully aroused, Yuu enjoyed a slow kiss with the glamorous beauty before him.

Not just that - he pressed his cock against her while stroking her back and buttocks.

After kissing repeatedly while changing angles, Michiko's expression was completely melted when their lips parted.

"Un. Forgiben."  
"Thank you."

What followed was chaos.

Women swarmed "Me too! Me too!" but Satsuki stopped them, saying Yuu would catch cold so they should wash and enter the bath first.

"Wh-when did so many gather?"

When Yuu entered the bath, Mana and Rina were on his sides with Satsuki right behind.

Over twenty women gathered facing them about 1 meter away.

They were packed like dumplings in the largest bath.

Mana couldn't help sounding exasperated.

"Well, this is fine too."

For Yuu, wherever he looked were breasts - as a man, he couldn't be happier.

Moreover, whether intentional or not, Satsuki's breasts pressed against his back.

Just then, the string tied at his waist loosened, and the cloth hiding his crotch floated up.

"Ahh!"

The bathwater was clear, not cloudy.

Though slightly distorted through water, Yuu's erect giant cock became visible.

"Ah, this is annoying. Whatever. It's weird being the only one not naked."  
"W-wait!"

Before Mana's voice stopped him, Yuu stood with knees bent and took off the bathrobe, hanging it on the bath edge.

Yuu's upper body to waist was exposed, his cock jutting from the water like a periscope.

"Eeeeh!?"  
"Waaah!"  
"Guh!"

Reactions were pronounced.

First-timers found it grotesque yet couldn't look away.

Women who'd seen male genitals before were shocked despite their joy, whispering "Never seen anything like that" and "Too big for such a cute face."

Some got nosebleeds, hurriedly pinching their noses.

"Really, Yuu... how bold."  
"Th-th-th-thiiiiis is aaaaaah!"  
"Rina, calm down. But Yuu's cock... ah, amazing."

Everyone stared hotly at Yuu's crotch.

Some looked as if seeing a rare beast, others gulped.

Just being stared at.

But by over twenty young women - it was exciting.

Yuu somewhat understood exhibitionists now.

At this point, any man would want to ejaculate.

Yuu whispered to Mana and Rina on his sides and Satsuki directly behind.

"Hey, touch it."  
"But..."  
"I-is it okay?"

Unlike hesitant Mana, Rina's curiosity won as she gingerly extended a fingertip to touch the glans.

Satsuki behind Yuu, unable to contain excitement, wrapped her left arm around his stomach and lightly grasped the shaft with her right hand.

"Wow! It's rock hard!"  
"Ufufu, hot and hard... per-fect."  
"I-I want to touch too!"  
"Me too!"

Women who'd kept distance could no longer restrain themselves and swarmed.

"Un. You can touch. But be gentle."  
"Got it. Y-yes, gently... ah, so stiff and manly."  
"Truly. Never seen such a thick, curved cock before."  
"The balls are big and heavy too."  
"Ahh, feels good... ugh!"

Every single naked woman showed open excitement as they mobbed Yuu.

Only six or seven including Satsuki's trio directly touched his cock. Others within reach desperately stroked Yuu's buttocks, stomach, and chest.

Those blocked by the crowd looked frustrated, but when Yuu made pained sounds, their lower abdomens clenched and they began comforting themselves.

Unlike handjobs for ejaculation, over ten hands touched every part of him just to feel.

He wouldn't ejaculate immediately, but excitement built, bringing Yuu a creeping pleasure.

Mana expertly rubbed the glans with her fingertips while Satsuki stroked the coronal ridge - techniques of experience.

"Most boys would hate being groped by so many women. But Yuu's enjoying it? So much clear fluid's been dripping since earlier."  
"Ah! Ah! I-I'm actually happy... with this... nngh! Feels... so good!"  
"My, what a naughty boy. But sis loves you. Here, want to cum already?"  
"Ahh! S-Satsuki nee... w-want to cum... yes. Gah, gonna... cum!"

When Satsuki whispered in his ear while pressing her breasts, Yuu panted in response.

Seeing this, several women kept one hand on Yuu's skin while fingering themselves with the other, leaking hot breaths.

Some nearly fainted from excitement rather than heatstroke but refused to leave.

Soon Yuu approached his limit.

Leaning back against Satsuki while kneeling, he tightly gripped Mana and Rina's shoulders.

"C-c-cumming! Ugh! Ah! Cumming!"  
Dopyuruu!  
"Hyah!?"

The first ejaculation shot powerfully over two women facing him, splattering on Michiko's lips as she masturbated while watching behind them.

Successive spurts hit several faces and chests.

Shocked by the sticky semen coating her, Michiko scooped the thick liquid with her finger and swallowed without hesitation.

"Nn, am... gulp! Ahh... th-this is a man's... semen... ah... ahhn!"

Having won her company's design competition to come here for the first time, she'd been work-focused until now - Yuu was her first time seeing a naked man, even her first kiss.

Yuu, over ten years younger, was intensely stimulating, and her fingers moved uncontrollably with unprecedented excitement.

Having not just been showered with precious semen but tasted it, she came with a blissful expression.

---

### Author's Afterword

Unlike open-air baths, indoor baths don't produce much steam due to ventilation.

Also, in this world, chances of encountering young women in mixed baths are low, but a young man bathing mixed is virtually impossible in this chastity reversal world with so few men.

That's why I thought this could only be written in such a special facility.

### Chapter Translation Notes
- Translated "湯浴み着" as "bathrobe" to refer to the specific garment worn by men in mixed baths in this world. It is described as a front-covering garment similar to a "nude apron"
- Transliterated sound effects (e.g., "garari" for ガラリ, "dopyuruu" for どぴゅるぅっ)
- Preserved Japanese honorifics (e.g., "Satsuki nee" for 沙月姉)
- Explicit terms: Used direct translations for sexual anatomy and acts (e.g., "cock" for チンポ, "semen" for 精液)
- Maintained Japanese name order throughout (e.g., "Mitsuba Michiko" instead of Western order)
- The term "男の裸エプロン" was translated as "male nude apron" to reflect the comparison made by Yuu