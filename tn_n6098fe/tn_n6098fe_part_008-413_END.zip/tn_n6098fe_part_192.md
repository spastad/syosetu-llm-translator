## 180. Dream Hot Spring Resort! ⑥ ~Hold Me TONIGHT~

After the commotion in the large bath, Yuu managed to return to his room guarded by Satsuki, Mana, and Rina.

Among the women present, the first-time guest members were driven by lust and wouldn't leave Yuu's side.

However, his half-sisters seemed relatively calm, perhaps accustomed to such situations. Knowing that Mana and Rina assigned to the same room had priority rights, they skillfully handled the situation.

Having rushed out, Satsuki and Rina with long hair were drying their hair with the room's dryer, while Mana had bought drinks along the way to quench their thirst as they relaxed.

The time was past 10 PM.  
It was early to sleep, but considering the household chores assigned for tomorrow morning, it was just the right time to begin the night's activities.

"Shall we go to bed now?"  
"Huh?"  
"Eh? Together?"  
"Of course."

Having rushed out and with their bodies still flushed, both were wearing only panties without bras. As Yuu approached and took their hands, he looked at Satsuki who remained seated on the sofa, waving cheerfully.

"Don't mind me, go ahead~"  
"Satsuki neé, are you sure?"  
"It was decided from the beginning that Mana and Rina would be Yuu's first night partners. I'll properly witness how you three love each other."  
"Hmm"

Having heard about it beforehand from Hiromi, Satsuki intended to gauge Yuu's capabilities as a man. Yuu himself wanted to have sex with Satsuki too. But first, he needed to satisfy his sisters.

"Come on, let's get undressed!"  
"W-wait, I can undress myself! Aahn... Yuu, you!"  
"Geez, Yuu, you undress too!"  
"Waha!"

As they playfully undressed each other and got on the bed, Mana seemed to switch modes. Rolling up Yuu's T-shirt, she began groping his upper body. Rina's long T-shirt hem was being slowly rolled up too, but Yuu grew impatient and rolled it up to her chest at once, causing her plump breasts to spill out. As Yuu kneaded them with his full palms, she immediately began moaning, while Rina herself reached for Yuu's body.

"Yuu, let's kiss..."  
"Mmm"  
"Amu... mfuu... Kissing Yuu feels so good. I-I might get addicted."  
"M-me too... I want to."  
"Yeah, Rina neé. Let's?"  
"Mmm!"

On the bed, with Yuu in the middle and Mana and Rina sandwiching him on both sides, their excitement rose as they touched each other while exchanging kisses.

"Yuuu..."  
"Mana neé"

The two locked eyes, opened their mouths, stuck out their tongues, and immediately began intertwining them. Excited, Mana embraced Yuu's head and covered his lips, greedily sucking his saliva as if drinking it. After enjoying the kiss with their tongues crossed for a while, they separated with a *tsutsu~* sound as a string of drool stretched between them. Mana's face was already flushed pink. Smiling, Yuu licked Mana's lips clean before asking.

"Mana neé, you seem experienced?"  
"Nn... just twice. Here. Usually, I don't have a specific partner."  
"I see. What a waste. You're beautiful with such a great body."

Yuu's left hand, which had been carefully stroking Mana's toned back down to her buttocks, moved forward and reached between her legs to her private parts. It was already soaking wet.

"Ahn! Y-you say things like that... Even if it's flattery... I'm happy!"  
"It's not flattery."  
"Hyau! W-why... today I'm feeling it so much! A, a, ah... st-stop, if you play with it like that..."  
"What happens if I play with this?"  
"I-I'll cum! Aah! N-nooo..."  
"It's fine. As payback for earlier, I'll make you feel really good."

As he inserted his finger up to the second knuckle into her vagina, it made lewd squelching sounds. Mana could only cling to Yuu and moan.

In Mana's experience, even when coming to Hesperis, women could spend the night with men only about once every two or three times. Still, Sakuya's sons were kinder to women and had stronger sexual stamina than average men, which was a major advantage. Among them, Yuu's proactiveness toward women was exceptional. Particularly noticeable was his erect penis standing proudly.

While Yuu and Mana were deep kissing, Rina seemed to be staring at the penis, hesitating whether to touch it or not. Though she was getting excited from kissing Yuu and having her breasts fondled, being a virgin, she couldn't quite judge whether it was okay to touch his genitals without permission.

"Rina neé, want to touch it?"  
"Yu-Yuu. Sorry. Um, it's my first time seeing a man's penis in real life..."  
"So I'll be Rina neé's first, huh?"  
"Ah!"

Despite having kissed and touched each other until now, Rina suddenly became self-conscious, her face turning red as she looked down. Finding such innocence adorable, Yuu pulled Rina close and pressed his lips against hers. Then, he inserted his tongue.

"Mfeh!?"

Rina's eyes widened in surprise, but the contact between tongues seemed to give her brain intense pleasure, as her eyes became dazed and she surrendered to Yuu. While kissing, Yuu brought his right hand forward and guided Rina's hand to touch his penis.

"Mpa! A-amazing! I-it's so hard... and hot!"  
"Rina neé, Mana neé, I'm excited from doing naughty things with both of you."  
"O-oh, men get excited too..."  
"Of course. Let me touch Rina neé's pussy too."  
"Eh? Ah, wait... mmmnn!"

Forcing his hand between her thighs as she tried to close them, he could tell she was already wet even before touching the crucial spot.

"I'm glad. Rina neé is feeling it too?"  
"Ah... u... kuu... ah, ah... there..."  
"Here?"

When he extended his middle finger to the center of her slit, love juice immediately clung to it. Then, as he teased with a hooked fingertip, squelching sounds became audible. Gradually opening her slit as if peeling it back, when his finger caught on a small protrusion, Rina's body jerked and her huge breasts jiggled *pururun*.

With Yuu in the middle, all three were playing with each other's genitals. For the virgin Rina, he touched her as if handling fragile goods. For the experienced Mana, he rubbed her clitoris thoroughly before repeatedly thrusting his middle finger deep inside. He'd also let Mana touch his penis, but she seemed to have no such composure. She was moaning uncontrollably, leaking foamy white fluid from her vagina.

"Yu, Yuu... ah, ah, ah... n-nooo! Don't do that so much... ahn!"  
"What shouldn't I do?"

Smiling mischievously, Yuu not only quickened his finger movements but also sucked on Mana's nipple as she arched her back, rolling it with his tongue.

"Hiiin! M-my nipple... I-I can feel it! Ah, ah, ahe... I'm gonna... ahn, ahn! Yuu... I'm cumming!"  
"Hoooe, I'm cummiiing!"  
"I-I-I'm cummiiiiiiiiiiing!"

As if triggered by Yuu's words while licking her nipple, Mana came while pressing Yuu's face against her breasts.

***

"Then, I'll put it in?"  
"U, un."  
"Haha. Don't tense up so nervously."  
"Yan!"

Perhaps satisfied from cumming by Yuu's fingers, or perhaps that was the plan from the start, Mana requested that Yuu take care of Rina first. So with Rina lying on her back and spreading her legs, Yuu pressed his hips against her and was about to insert. Meanwhile, Rina looked up at Yuu with a face flushed pink in places, showing an expression mixed with anticipation and tension. The place he was about to enter glistened with wetness from the foreplay, but being her first time, seeing how tense she was, Yuu extended both hands and flicked her nipples. Rina let out a cute, little-girl-like "Kyan!" and flinched, causing her hill-like breasts to jiggle like jelly. Without inserting yet, keeping his penis pressed against her, Yuu leaned over her and began sucking her nipples while kneading her huge breasts. They were so large they couldn't be contained even in his spread palms, changing shape freely with his hand movements.

"Ahn! That... sucking won't make milk come out."  
"Mfu. Who knows? Maybe if I keep sucking it will. Amu... chuu!"  
"Ahii! N-no... why... when Yuu sucks, it feels weird... ah, ahn!"

With her adorable, childlike voice and voluptuous body that aroused his manhood, Yuu's excitement skyrocketed. His penis was rock hard, dripping pre-cum. Moving his hips slowly like in sumo, pressing his penis against her while savoring Rina's huge breasts like a baby, Yuu noticed Rina had completely relaxed from the breast stimulation. He pulled his hips back slightly and attempted insertion, carefully placing one hand for support.

"Vuoh! T-tight!"  
"Ih! Aaaah... aah, giii... iiiih, it hurts!"  
"Sorry. Bear with it a little."  
"Un. I'm sorry for screaming."

Hugging Rina close, Yuu brought his lips to hers, and Rina hugged him back, wrapping both arms around his back as her cheeks grew wet.

Rina endured the pain of losing her virginity while Yuu showed consideration. Whether Rina heard it or not, Mana and Satsuki were congratulating her on graduating from virginity. Especially for Mana, it reminded her of her own virginity graduation night four years ago. At the same age of 19, her partner had been a half-brother three years older. Though not as experienced as Yuu, he had gently guided the nervous Mana, making it an unforgettable memory. She never imagined Yuu, though younger, would be so skilled, but she couldn't wish for a better partner for her sister's first time.

After exchanging kisses multiple times, Yuu moved his hips in small motions while watching Rina's condition. Meanwhile, he used his mouth on her sweaty neck and chest, and with one hand caressed her nipples, doing everything to distract her from the pain. The tightly closed vaginal walls were gradually pried open as the penis slowly pushed deeper. Finally, the tip *kotun* bumped against the back of her vagina.

"Hah, it's in. Rina neé."  
"Fah... Yuu, Yuu's penis... is all the way inside me."  
"Is the pain okay?"  
"Still... but it's okay. Thank you, Yuu."  
"Haha, you're welcome. I'll move now, here."  
"Ahn!"

Truthfully, Yuu didn't have much leeway. A virgin's vagina was incredibly tight with a powerful grip. The moment it hit the back, he almost came but managed to endure. Probably because he'd ejaculated earlier in the large bath.

Though she said it was okay, Rina was frowning with greasy sweat on her forehead, but as time passed, she began feeling pleasure along with the pain in her lower abdomen. The love juice seeping from her vagina acted as lubricant, making the thrusting smoother, but simultaneously, Yuu's urge to ejaculate surged intensely.

"Haa, haa, R, Rina... neé, kuha! Rina neé's inside feels... amazing!"  
"Hah, hah, hakuu! Yuu, Yuu! Ahn! Good! I-it feels good!"

With pleasure now completely overriding the pain, Rina moaned in a sweet anime-like voice that reached Yuu's ears, making his penis rage even more wildly like a beast. Sensing ejaculation was near, Yuu kissed Rina's pink-flushed cheek and whispered.

"Sorry. I'm about to cum first. I'll... ejaculate inside you like this."  
"Haaun... come. Yuu! Ahn! Give it to me... inside me!"  
"Vu... oh! Rina! I'm cumming!"  
"Aaah... ah... ah... iiiih! Aaaaaaaaahhhhhhn!"

Hugging tightly, becoming one, Yuu reached his limit and released his seed grandly into Rina's womb.

"Haa! Yu... u... amazing... so much... coming... afuun... I'm happy..."

Receiving the ongoing ejacution that didn't stop at just one, Rina closed her eyes with a blissful expression.

***

"Ah, ah, ah, aaahn! Good! It's good! My hips... won't stop!  
Hau! Yu, Yuu's penis... all the way to the deepest... amazing... iiiih... ah, kuun! No, don't thrust up like that... aun! I-I'm... cumming again! I'm cumming again!"  
"Mana neé seems sensitive, that's good. Then you can cum as many times as you want?"

On top of Yuu lying on his back, Mana was frantically shaking her hips. Being former athletic club, she was well-toned, but just watching Yuu have sex with Rina had gotten her ready, and the moment he inserted, she began thrusting wildly while moaning. At first, she came immediately after just a few thrusts against her vaginal wall. This time, when Yuu thrust upward too, she was about to reach climax again. Having ejaculated before making Rina cum, Yuu felt remorseful, but since Mana was already fully prepared, he could make her cum almost continuously, even smiling.

Given her sales role, Mana gave the impression of a capable, mature woman. But now, with a penis thrust deep inside her vagina, she'd become nothing but a moaning female. Staring at Yuu with a pained expression, then when about to cum, she'd stick out her tongue and lift her chin. Though Mana usually spoke with a slightly husky voice, now she moaned in a high-pitched, lust-filled voice. Drool dripped from her half-open mouth, *pota pota* falling onto Yuu's chest. Yuu gripped her firm buttocks tightly with his left hand, grabbed her bouncing breasts with his right, and watched Mana's frenzied state.

"Aah......... aaaaaaaaaaaaaaaaaaahhhhhhhh! I-I'm cummiiiiiiiiing!!!"

Mana arched her body back and screamed long as she came, then collapsed onto Yuu. Breathing heavily, she whispered in his ear.

"Haa, haa, haa, s-sorry... I... I'm the only one... feeling good..."  
"Mana neé"

Yuu turned sideways and sealed Mana's lips before responding.

"Just seeing Mana neé feeling so much makes me feel good."  
"B-but"  
"Then let's change positions."  
"Huh?"

Yuu wrapped both arms around Mana's waist and hugged tightly, then sat up.

"Hyan! Wai... ah, ih, the penis... ahi, this... feels so goooood!"  
"I'm moving."  
"Eh... ah, ah, aiiiih! St-sto, aaaaaaahhhh! Yuu, amaz... ing!"

Now in a seated facing position, with the penis still deep inside, when Yuu thrust upward, Mana couldn't help but moan with her tongue out. Their joined parts made even lewder squelching sounds than before, spreading stains on the sheets.

In the seated facing position, moving actively increased Yuu's pleasure, but he was still full of energy to continue. Though Mana's toned body was drenched in sweat, Yuu hugged her tightly without care, kissing her sweaty chest. Already approaching climax again, Mana clung desperately, wrapping not just her arms but her legs around him too. As Yuu's hip movements intensified, the *bachun bachun* sounds of flesh slapping and Mana's moans grew louder.

"Ahn, ahn, ahn! Yu, Yuu, really, amazing! Ah, ah, I'm... cu-cumming again... vuah! Aah! Hiin! Yuu, Yuu! Cumming cumming cumming! Aaaaaaaaaaahhhhhhhh!"  
"Vu, ooh! Ma, Mana neé, I-I'm... cumming too!  
Like this... inside... I'll ejaculate, so take it all! Vu! Gu... cumming!"

After thrusting upward repeatedly, Yuu pressed the tip against her cervix and ejaculated. With Mana, it was almost foreplay-less penetration from the start, intense intercourse. In that short but dense time, Mana came multiple times, and Yuu felt incredibly good too. Having received his seed, Mana lifted her chin and mumbled something, seemingly in a dreamlike, incoherent state. Perhaps because they were half-siblings sharing blood, their bodies were compatible, Yuu vaguely thought as he released his semen.  


### Chapter Translation Notes
- Translated "抱きしめてTONIGHT" as "Hold Me TONIGHT" to preserve the bilingual wordplay
- Used explicit anatomical terms ("penis", "vagina", "ejaculation") per translation style rules
- Preserved Japanese honorifics (-neé) for sisters as per character relationships
- Transliterated sound effects: "くちゅくちゅ" → "squelch", "ぷるるん" → "jiggle", "ばちゅん" → "slap"
- Maintained original name order: "Hirose Yuu", "Toyoda Satsuki", etc.
- Translated sexual acts without euphemisms per explicit content requirement
- Italicized internal monologues: *(This is concerning.)*