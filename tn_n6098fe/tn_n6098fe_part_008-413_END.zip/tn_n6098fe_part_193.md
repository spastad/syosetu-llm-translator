## 181. Dream Hot Spring Resort! ⑦ ~Memories Overflowing~

### Author's Preface

While rereading before posting, I noticed contradictions with previous chapters and unnatural points.

Details in the afterword.

---

"Haaah"  
"Good work"

Leaving Mana and Rina on the bed, Yuu walked over to the sofa and plopped down heavily.  
Nearly half a year had passed since he started training his body through self-directed workouts.  
Thanks to his increased stamina, he wasn't completely exhausted, but taking on two partners consecutively naturally brought some fatigue and lethargy.  
At that moment, Satsuki handed him a canned drink with blue and white packaging which he accepted and drank.

"Aahhhh—delicious!"

Yuu gulped down about half in one go.  
It resembled the sports drinks he often consumed before his rebirth, soothing his parched throat and sweaty body.

Though the room had a refrigerator, it wasn't stocked like a hotel.  
He'd been informed each floor had vending machines.  
This was one of the drinks Mana bought and chilled after they left the bath.

After catching his breath, Yuu shifted his gaze to Satsuki sitting beside him on the left side of the sofa, who was staring at him.  
Her hair was swept up in an intricate updo, revealing her beautiful nape in an incredibly alluring way.  
Her black camisole exposed her shoulders, with cleavage showing a valley between breasts that asserted themselves prominently forward. Being braless, their shape was clearly visible, nipples distinctly protruding at the tips.  
Below, she wore only black lace panties, crossing her long legs to showcase their shapely lines.

"Ara... U-uh oh"

Yuu had been captivated by his sister's disheveled appearance, but naturally Satsuki was also casting heated glances at her young brother's naked body.  
The moment her eyes recognized the erect object at his crotch, they widened in surprise and she covered her mouth with her hand.  
After moistening his throat, Yuu set down the can and moved closer to Satsuki.

"Hey, Satsuki-neé..."  
"Y-Yuu?"

Just pressing their bodies together released a wonderful fragrance that tickled his nostrils.  
Satsuki's black eyes, now looking at Yuu instead of his crotch, were clouded with lust, and her skin felt feverish to the touch.  
Though Yuu wanted to start with Satsuki immediately, he restrained himself to intertwining their fingers and asked what had been on his mind.

"I have something I want to ask"  
"Ara, what is it?"

Hearing Yuu's words, Satsuki seemed to temporarily suppress her desire.  
This showed her maturity and composure.  
She tilted her head, resting the hand not holding Yuu's against her cheek.  
Even that gesture was adorable.

"Even though we're half-siblings, you all seem to have no resistance to having sex with blood-related brothers and sisters?"

"Ah, that. I'd forgotten since it's been so long since a teenage brother visited"

Yuu's physical relationships with Elena and Martina stemmed more from seeing them as attractive women than as blood relatives.  
The same went for his half-sisters Saira, Miku, and Kiyoko—since they didn't live together, they felt more like older "sisters" than family.  
In that sense, Mana, Rina, and Satsuki were similar.

In this world, the shortage of men meant affection that couldn't be found elsewhere often turned toward male relatives.  
Hence the low aversion to incest.  
Yuu had rationalized that developing sexual feelings for a young, handsome half-brother was normal.

Still, he wondered if it wasn't too open.  
Even if this were a secret gathering limited to Sakuya's children, the guest members also accepted Yuu having physical relationships with his half-sisters.  
Socially, wasn't incest supposed to be taboo?

"Could you indulge me in a little story from the past?"  
Saying this, Satsuki took a sip from her canned coffee, apparently bought for herself.  
"Sure. Tell me"  
Yuu kept their bodies pressed together as he listened to Satsuki's story.

---

Sakuya's wives started with four middle school classmates and increased over the years.  
As children were born, the family grew.  
They initially rented an ordinary house but soon outgrew it. By Satsuki's memory at age five, they lived in a large, old-fashioned mansion lent by one wife's family—Sakuya with eight wives and ten children (two boys, eight girls), nineteen people total.

Though mothers differed, living together made them feel like true siblings.  
Satsuki recalled only happy memories—a large yard with plenty of playmates.  
However, she remembered feeling sorry for the boys who couldn't roam freely like girls, strictly forbidden from going out.

Wives continued increasing at about one per year. By elementary school, wives exceeded ten, including foreigners.  
Considering lifestyles, wives lived in separate groups with Sakuya rotating visits.  
From then on, children interacted only with siblings in their living group.  
Though children kept increasing yearly, Satsuki couldn't grasp how many siblings there were.  
Especially boys born in other groups—she didn't know about them then.  
She only grew close to siblings she lived with.  
Being young, their relationships were like ordinary siblings.

The turning point was Sakuya's death.  
As a figure known domestically and internationally, intense media attention on the bereaved family was anticipated.  
After the funeral, wives dispersed to hotel living. They resolved:  
They absolutely had to prevent media ambushes shoving cameras and microphones at the children before their grief healed.  
They must unite and cooperate now.

Thus, only the first four wives remained in Tokyo as representatives for interviews.  
Over 100 others—wives, mistresses, children—temporarily evacuated to a hot spring resort facility newly built in Hakone.  
Satsuki was shocked to see so many unfamiliar younger siblings below elementary age.  
Some wives like Martina, who discovered pregnancies, didn't accompany them, taking independent actions or returning to their parents' homes.

Though some joined later or left midway, life at Hesperis lasted up to a year until things settled.  
Initially, mothers grieved, and children grew mentally unstable—suddenly losing their father while confined.  
Older siblings like Satsuki and Masaki became leaders, encouraging each other, playing in groups, and teaching from textbooks to distract themselves.  
Some wives and mistresses were active teachers or graduate students, so they formed cross-grade classes for studies.

However, "older" meant middle schoolers—still a difficult age.  
They fought sometimes, and attempts to escape ended in fear in the deserted mountains, forcing returns.

For pubescent boys and girls in group living, comforting each other on sleepless nights naturally led to relationships transcending sibling barriers, ascending to adulthood.  
With fewer boys, one boy often had multiple girls, but they deepened bonds while minimizing conflicts.  
These relationships continued after leaving Hesperis. Even living apart, they gathered at Hesperis several times yearly, cooperating and enjoying time together like before.  
Thus, at Hesperis, blood relations were implicitly disregarded, and guest members accepted this.

---

"I had my child at sixteen, so I was already in middle school"  
"Eh!? S-such a big child exists?"  
"Yes. As for the father... it's unclear"  
"Then, that child?"  
"I left it to Masaki-kun, my first partner!"

Satsuki said cheerfully.  
Fifteen-sixteen years ago, beautiful middle schoolers resembling their parents lived here in group free-sex conditions.  
They apparently drew a line: no intercourse under fourteen.  
For Yuu, this meant if Elena got pregnant and gave birth, she'd raise the child alongside Sayaka's.

"Speaking of which, was Kiyo-neé... Takahata Kiyoko there?"  
"Takahata... Did her mother revert to her maiden name?  
Hmm... Ah! Could it be Kiyoko-chan?"  
"I think she said she's twenty-eight"  
"Then definitely Kiyoko-chan! I remember playing with her until elementary school. She was tall, shy, and quiet...  
Yes, Kiyoko-chan's mother had poor health. Around Father's death, I think she was recuperating in Tohoku, so she wasn't with us"

That explained it.  
When Yuu first met her in Sairei Academy's Special Male-Female Interaction Room, she said she'd had no male connections and remained a virgin until that age.  
As Yuu recalled Kiyoko, he noticed Satsuki gazing meaningfully.

"Yuu, you met Kiyoko-chan? Was she well?"  
"Yeah. Well, she was fine"

He couldn't say his first impression was "chaste-like".

"Good. And... did you?"  
"U... yes"  
"Araa, she beat me to it"

Satsuki slid her hand over Yuu's bare chest and flicked his nipple.  
Yuu reciprocated by cupping her breast with his right hand.

"Ahhn... But after two partners, are you okay?  
Fufu, that part seems lively though"  
Satsuki glanced at Yuu's crotch and chuckled.  
"Yeah. Seeing sexy Satsuki-neé made me horny"  
"Really? I'm happy~ Women always feel happy hearing that, no matter their age"

Satsuki uncrossed her legs and turned fully toward Yuu, straddling him.  
She stroked Yuu's head while bringing her face closer.  
Her plump, thick lips glistened as they approached.  
Her expression was incredibly erotic beyond just her figure, making Yuu's heart pound despite this being his third partner tonight.  
When her lower abdomen pressed against his erect cock and her breasts against his chest, Satsuki sealed his lips, and her slippery tongue invaded his mouth.

"Mmphu, chu, chu, afuun... Yuu, kissing... feels so good. Hey, more"  
"I-I feel it too. Nn, mmu..."  
"Aahn, I'm getting excited! Nn-chu, churerorooon"

Straddling Yuu on the sofa, Satsuki desperately pressed her breasts against him while devouring his mouth.  
Yuu tangled his tongue with hers but mostly accepted her advances.  
She apparently undid her neatly tied hair during the kiss.  
Soft ends cascaded down, brushing his cheeks and shoulders, releasing conditioner fragrance.

After briefly parting lips, a string of saliva stretched between them, which Satsuki licked away before pressing her protruding tongue against his lips again.  
Yuu wrapped both arms around Satsuki—one hand slipping inside her camisole, the other stroking her released hair.

"Afuu. Sorry... I meant to just watch and endure, but I couldn't help it...  
Because Yuu was way more amazing than I expected. I wanted that too..."

Satsuki gazed at Yuu with moist eyes, sliding her stroking hand from his head to his cheek.  
Her other hand danced across his chest.  
Unconsciously perhaps, she pressed her lower abdomen harder against his hot erection—as if demanding it.

"Satsuki-neé?"  
"Nn? What?"

Yuu lowered his left hand from her back and firmly grabbed her buttock.  
His right hand stroked from cheek to chin.  
Just that made Satsuki release heated breaths.  
By now, it was clear. Though unspoken, she desperately wanted penetration.  
Naturally, Yuu was fully willing—his cock had been rock-hard since earlier.

"I intended to do it with Satsuki-neé from the start"  
"Aah! I'm happy! You know, I dreamed of doing it with a teenage brother so much younger!"  
"I'd welcome a sexy older sister like Satsuki-neé anytime"  
"Aahn, Yuu, I love you... nn-chu!"

While pressing her lips, Satsuki slightly lifted her hips.  
As if unwilling to separate, she merely shifted her panties' crotch aside and inserted him.  
His glans was instantly enveloped by her wet, warm vaginal entrance before being swallowed deep inside.  
Immediately, his cock felt tightly gripped by vaginal folds.

"Gyaaah! Aah~~~~nng!"  
"A, oh... S-Satsuki-neé, ah, so warm and feels so goo... ugh!?"

Satsuki clung tightly to Yuu, but their height difference meant his face got sandwiched between her voluptuous breasts.  
As a man, that made him happy too.  
Moreover, Satsuki's vaginal interior felt perfect after penetration.  
But Satsuki herself was beyond caring.

"Hya... gyaah, aah! W-wai... deep! A-amazing! Nng! Ah, ah, ah... I'm cumming! Putting it in... I'll cum right away! Aah! Yuu's cock... feels too good... already... can't... AAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHH!!!!"

Less than a minute after full insertion, Satsuki reached climax.

---

"An indecent sister-pussy that selfishly cums alone feels good gets this! This this!"  
"Ah... ahh... ah! S-stop, grindinggg, nooo... gyaah, gyuun! Y-Yuu... your cock... amazing! Not fair... I'm cumming! Nngah... raah... nooo! Hiiin!"

Changing positions, Yuu sat Satsuki shallowly on the sofa, hooked his arms under her knees to spread her legs, and vigorously thrusted.  
Roles reversed from before—with each of Yuu's thrusts, Satsuki could only moan while shaking her abundant breasts and wavy hair.  
Squelching wet sounds echoed from their joined parts alongside flesh-slapping sounds.  
Squirting fluids flew out with each thrust, and love juices dripped from sofa to floor, forming large stains.  
Satsuki's body remained taut despite childbirth—vaginal walls included.  
Her vaginal folds continuously stimulated Yuu's cock, his pleasure mounting uncontrollably as he thrusted wildly.  
But Satsuki seemed more ravaged by the deep penetration.

"Ahhn, ahn, ah... ahh... CUMMING uuuuuuuuuuuuuuuuuhhhhhhhhhh!!!!"

Satsuki reached climax again, tightly hugging Yuu's back.  
He managed to brush aside the hair covering her face and kissed her.  
Their tongues tangled immediately.

"Amu... mmphuu... lero, leroo, lerochupaa... Afuu, Yuu, you were... way more amazing than I expected"  
"What are you saying? We're just getting started?"  
"Fue... aahn! Y-Yuu... your cock... incredible! Not fair... I'm cumming! Ngah... raah... nooo! Hiiin!"  
"Satsuki-neé, let's make another child"  
"Huh!? ... Gyuun! Ah, ah, ahh! So intense!"

With climax approaching from the intense thrusting, Yuu began his final sprint, thrusting even harder.  
Slap, slap, slap—flesh impacts joined by sticky, wet sounds from their union.  
Mana and Rina had woken up and watched Yuu and Satsuki's intercourse, fidgeting while rubbing their thighs together.

Ultimately, after ejaculating copiously inside Satsuki, Yuu returned to bed and enjoyed the night with his sisters through double blowjobs from Mana and Rina.

---

### Author's Afterword

In the latter part of "(Interlude 1) Martina - Part 1", Martina believed there were no boys born between Sakuya and his wives, and that Yuu was the first.  
But with older brothers appearing like this, it's unnatural for Martina not to know.  
So I changed it to: girls were common, but Sakuya was especially happy when boys were born.

Anyway, the first day has finally ended.  
From the second day onward, I want to focus on erotic content and progress smoothly...

☆First day's conquests  
Half-sister Yamazaki Mana (23)... Sports manufacturer sales  
Half-sister Yamazaki Rina (19)... Vocational student ※Virgin  
Half-sister Toyoda Satsuki (30)... Foundation staff  

2020/3/9  
Corrected Yuu's line near the end from "Let's make another little brother or sister" to "Let's make a child".

### Chapter Translation Notes
- Translated "姉マンコ" as "sister-pussy" to maintain explicit terminology while preserving familial context
- Rendered "おチンポ" as "your cock" to balance explicit anatomical terms with natural English dialogue
- Preserved "-neé" honorific in "Satsuki-neé" to maintain relationship nuance
- Transliterated sound effects: "どかっと" → "plopped down heavily", "ゴクゴク" → "gulped"
- Translated "慰め合う" as "comforting each other" to convey emotional nuance of the refuge period
- Maintained Japanese name order: "Takahata Kiyoko" instead of Western order