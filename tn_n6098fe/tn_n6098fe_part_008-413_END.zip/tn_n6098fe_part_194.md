## 182. Dream Hot Spring Resort! ⑧ ~The Town Where He Swims~

### Author's Preface

Following masks, tissue paper (including pocket tissues) is now in short supply...

For those suffering from hay fever, days of hardship continue, but let's endure.

---

"Good morning."

""""""Good morning, Yuu!""""""

"My, my, you look sleepy?"

"You seemed to have enjoyed yourself last night."

"Didn't Mana and Rina drain you dry?"

"Um..."

"Well, you see, Yuu was amazing... I was overwhelmed. Right, Rina?"

"Huh!? Ah, yeah..."

"Ehh, I'm jealous!"

"Next time, do it with me, Yuu."

"Your big sisters will pamper you lots, okay?"

""""""Me too, me too!""""

"Hmm, well, I'll think about it."

Having visited the dining hall for breakfast with Satsuki, Mana, and Rina, Yuu exchanged greetings with a group of five sisters, including Loretta, who had arrived earlier.

*What a conversation to have first thing in the morning,* Yuu thought, but the sisters were remarkably nonchalant.

Rina's face turned bright red, perhaps remembering last night, but Mana spoke confidently.

Satsuki, who had unexpectedly received some "leftovers," merely smiled without saying anything.

The sisters invited Yuu, but without any persistence—it was all in a lighthearted tone.

From his conversation with Satsuki the previous night, it seemed an unspoken rule that women would promote themselves to the scarce men but never force anything.

That was a relief for Yuu.

Who he would spend the night with was entirely his choice.

He could pick and choose from among the beautiful women. Frankly, he wanted to be with every single one of them.

It seemed likely that tonight would be another night without rest for his cock, and his cheeks naturally relaxed into a smile.

Breakfast was self-service.

This morning, it was Japanese-style: each person entered the kitchen with a tray, scooped rice from a commercial rice cooker, and served miso soup from a large pot.

In addition to the already prepared natto, pickled plums, tsukudani, raw eggs, seasoned seaweed, and furikake, they could also take leftovers from last night's side dishes.

Yuu sat next to the sisters who had arrived earlier, along with Satsuki and the others, and a lively breakfast began.

Perhaps because he had worked hard last night, his appetite was so hearty that he went for seconds of rice twice.

The women around him watched Yuu eat heartily with warm smiles.

---

After breakfast, they returned to their room for a short break before heading to their assigned chores.

Yuu was assigned to the laundry team, not his first choice of the meal team.

According to Mana, the laundry team was relatively easy, so it was probably assigned to Yuu and Rina as first-timers.

In contrast, Mana was assigned to the cleaning team, which was said to be the toughest, and she was dismayed.

They used vacuum cleaners to clean each floor of the basement daily, and even with over ten people dividing the work, it was time-consuming because of the large area.

Yuu decided to gather in the laundry room on the second basement floor to hear about the work.

---

"With that, we'll divide the work and go around, so please cooperate!"

""""""Yes!""""""

Among the laundry team members, one of the older full members was chosen as the leader for the day.

She gave instructions, and Yuu and the others began to move.

Compared to the full members who moved briskly, the guest members looked sleepy or seemed to be moving reluctantly.

But the half-sister who became the leader urged them on with strict commands.

Rina was caught by the older sisters as soon as she arrived and was being asked about last night's events.

Yuu avoided getting involved and slipped away to join his half-brothers.

"Alright! Let's finish quickly and go swimming in the pool, Yuu!"

"Ahaha. You're energetic first thing in the morning."

"Kousaku is always like this. But hey, going outside should be after lunch. Your body won't hold up otherwise."

Joining his half-brothers Kousaku and Takuya in the same team, Yuu chatted lightly with them as they took the elevator down to the fourth basement floor.

They would go around ten Western-style rooms with a cart like those found in home centers—but without a separate top and bottom, it was a single unit—and collect the laundry.

The rule was to place laundry nets with the room number written on them by the door when going to breakfast.

However, if everyone—there were nearly 60 people last night, but it could be up to 100—put out all their laundry, it would be overwhelming.

Therefore, there was a limit of four items per person, such as underwear, undergarments, and socks.

Jackets, sweaters, blouses, skirts... and other items requiring special care when washing were to be washed by the individuals themselves or taken home.

Kousaku pushed the cart while Yuu and Takuya collected the laundry nets from ten rooms.

Through the translucent laundry nets, they could see underwear of various colors, sizes, and types.

If Yuu were still in his teens from his previous life, he would have wanted to examine them closely.

But now, he wasn't particularly interested.

After all, at home on his days off, he was in charge of laundry and had inevitably seen and handled Martina and Elena's underwear, so he was used to it.

The person inside the clothes and underwear was more important than the garments themselves.

While collecting the laundry, Takuya spoke to Yuu with some hesitation.

"Um... were you okay last night?"

"Huh?"

"Well, wasn't it too much to handle two at once?"

"No, I was completely fine. In fact, I enjoyed it with four people (・・)."

"Eh? Four?"

"Yeah, Mana-neé, Rina-neé, and Satsuki-neé."

"Sa... Satsuki barged in too!?"

"Yeah. I asked her to."

"Sigh... Well, if you asked for it."

"Amazing, Yuu! That's youth for you!"

"Ahaha. Well, yeah. I'm used to it from school."

"I-is that so..."

Takuya seemed to be concerned about Yuu, who was spending his first night here.

About 15 or 16 years ago, when they lived together, Kousaku and Takuya were elementary school students, but they knew the atmosphere of that time.

Probably only Masaki and Satsuki knew about Yuu through Hiromi of the foundation and had assigned Mana and Rina to him.

However, Kousaku and Takuya, unaware of this, thought it might be too much for 16-year-old Yuu to handle two half-sisters on his first night, but they were surprised by Yuu's reaction.

As for Yuu, since he was invited here, he was fully prepared to be with as many sisters as possible.

Putting aside the night's events, the three of them finished collecting while talking about Yuu's impressions of Hesperis and the facilities, then returned to the laundry room and started two of the six washing machines simultaneously.

The other teams did the same, and about ten people gathered in the laundry room, all women except for Yuu and his two brothers.

The towels from the large bath were more troublesome than the guests' laundry due to the quantity.

Then there were the rental swimsuits discarded in the pool changing room, the dishcloths and aprons used in the kitchen and dining hall, and the hand towels used in the restrooms—there were no disposable paper towels or hand dryers commonly seen in the 21st century.

Incidentally, the sheets and pillowcases from the guest rooms were regularly sent to a commercial laundry, but if they were heavily soiled, like in the room where Yuu stayed, they might be washed on-site.

Once the washing machines were running, they could watch TV or read magazines in the next room until they finished.

But Yuu ended up surrounded by women, especially those targeting him, and spent the time talking.

Here too, it was clear that the guest members, who had gotten a rare opportunity to come, were more starved for men than the half-sisters. They pressed forward aggressively.

But now, having Kousaku and Takuya with him was reassuring.

With a wry smile, Yuu managed to handle the conversations with the women.

After running the washing machines twice and hanging the laundry in the designated area on the first floor, time flew by.

Starting around 9 a.m. and taking breaks, they finished everything by 11:30 a.m.

It was a bit early, but the laundry team decided to go for lunch.

Lunch at Hesperis consisted of boxed lunches ordered in bulk during breakfast.

They were delivered by a vendor to the manager's office on the front side (the resort condominium side), and the meal team members picked them up to eat in the dining hall.

They had been warned that if they overslept, they would miss both breakfast and lunch, which would be miserable.

In that case, they had to make do with cup noodles or retort-packed food stocked in the kitchen.

Surrounded by Kousaku, Takuya, and the women from the laundry team, Yuu ate lunch and then decided to go to the pool.

Takuya said he was going to the library, so they parted ways.

---

"After all, this kind of thing..."

"If the size fits, you can choose whichever one you like."

"Can I just wear the trunks?"

"Huh?"

In front of the rental men's swimsuits lined up in the men's changing room, Yuu muttered, and Kousaku made a face as if to say, "What are you talking about?"

The swimsuit Kousaku wore yesterday during the tour and the one he was holding now was a bikini-like two-piece.

Without exception, the swimsuits lined up before him were matching sets.

There were even wetsuit-like ones that surfers wear, and swimsuits that combined a T-shirt and shorts—probably for playing by the water rather than swimming.

In other words, in this world, it was natural for men to cover their chests just like women.

If he tried to swim in just trunks, it would be like a high school girl appearing topless at a public pool in his previous world.

Reluctantly, Yuu decided to choose the same type of swimsuit as Kousaku.

To swim in the water, he needed to go through steps.

In the world before his rebirth, everyone did this in elementary school swimming lessons.

But in this world, boys were exempt from swimming lessons in elementary school, and as adults, they rarely swam in pools or the sea, so apparently, there were quite a few non-swimmers.

Before his consciousness switched, Yuu had taken regular lessons until he was ten, so he wasn't afraid of water and knew he could swim a little.

Also, the Yuu before his rebirth could swim as well as anyone and had been to pools and the sea.

But that was only during his student days, so it had been nearly 20 years since he last swam.

"Whoa! Yuu, you're good! Yeah, that's the way!"

Now, in the 25m pool, Yuu was swimming with a kickboard firmly in his hands, doing the flutter kick, under Kousaku's watchful eye.

It was a bit embarrassing, but he didn't want to try swimming without getting the feel and end up drowning.

"Your legs tend to sink a bit, so try to focus on keeping your body straight."

"Mm... got it."

When he started swimming, he didn't do well at first and touched the bottom with his feet midway, but gradually, he was able to increase the distance.

By the time he swam 25m, his body seemed to have adjusted, and he could even put his face in the water and breathe.

""""""Wow, you did it!""""""

As Yuu reached the 25m mark and lifted his face, cheers and applause reached his ears.

Surprised, he looked at the poolside to see about ten women in swimsuits crowded together.

Before swimming, he knew that about three women had followed him and Kousaku, but they seemed to have increased in number without him noticing because he was focused on swimming.

"Damn, this is embarrassing."

"If you care about that, you won't be able to swim!"

"Well, that's true, but..."

"Now, what next? Should I teach you the crawl or breaststroke?"

It would be fine if he could swim as well as Kousaku, but it was embarrassing to be watched while still practicing.

Right now, Yuu prioritized learning to swim over admiring the women's swimsuits.

Under Kousaku's guidance, Yuu continued practicing swimming.

Though Takuya had described him as muscle-brained, Kousaku was a good teacher, as expected of a current teacher.

As a result, Yuu, who already had knowledge about swimming and good athletic ability, became able to swim 25m in both breaststroke and crawl.

Though he felt somewhat tired, Yuu was happy about his progress in swimming and still wanted to swim more.

But since more than an hour had passed since he entered the pool, he decided to take a break as Kousaku suggested.

""""""Good job!""""

"You got better at swimming so quickly! As expected of Yuu!"

"You looked cool swimming!"

"R-really?"

As soon as Yuu got out of the pool, he was surrounded by the women.

He had been concentrating on swimming and deliberately avoiding looking, but the variety of swimsuits was dazzling, and he couldn't help but stare.

There were sexy black bikinis, and bikinis with vivid floral patterns.

There were modest white or cute pink one-pieces, and so-called high-cut suits with sharp slits.

Moreover, though breast sizes varied, all the women had well-proportioned figures.

It reminded him of idol swimming competitions he had seen in the past.

"Your throat must be dry? Here you go."

"Thank you... Huh? Yesterday... hmm?"

Unable to remember the name of the woman who approached him first and handed him a cup with a straw, Yuu pondered.

Perhaps because she was going into the pool, her permed dark brown hair was tied up.

The hairpin ornament on the side was shaped like a large hibiscus flower, making it look as if she had a single flower in her hair.

Her eyes were distinctly double-lidded, slightly droopy.

Her nose bridge was high and well-defined, and her lips, coated in deep pink rouge, were glossy.

She was slightly shorter than Yuu, with a slender, almost fragile-looking waist, but her pink tube-top bikini breasts were so full they created cleavage.

It was a miraculous figure. She looked about 20 years old.

With such beauty, he shouldn't have forgotten her...

"Ah, I arrived late last night, so this is our first meeting."

"I see. That explains it... But I feel like I've seen you somewhere...?"

"Really?"

"Hmm. I can't remember. Why is that?"

"Fufufu. Well, try to remember."

The woman before him smiled mischievously.

Her smile seemed to hold both an angel and a little devil, and her charm was so captivating it felt like he could be drawn in.

The other women seemed to know and put their fingers to their lips, saying, "Don't tell."

"Then, a hint."

"Okay."

She beckoned to one of the women behind her.

The two standing side by side were a striking contrast.

The other woman was tall, about 175 cm.

Her black hair was so short it could be mistaken for a man's, and her oblong face gave a dignified impression. She was the so-called "trap" type who would look good in male attire.

Yet, her almond-shaped eyes exuded a startling sensuality, but perhaps because she was nervous in front of Yuu, she quickly averted her gaze.

Her swimsuit was a glossy cobalt blue one-piece. The mesh at the waist was transparent and sexy.

But her chest was almost flat, close to a washboard.

She was slim but not fragile; she had a well-toned, muscular build.

"Well?"

"Ah!"

The two stood side by side, struck a pose with their backs to each other, one hand on their hip as if holding a microphone, then after some choreography, they faced each other in an embrace like lovers.

Yuu remembered seeing this on a music TV program a few days before coming here.

"You seem to remember. We are—"

"Wish's Mizuki Aoi and—"

"Hidaka Akane... that's us!"

Wish was a duo that had been releasing hit songs one after another and rapidly rising in popularity since last year.

In this world's entertainment industry, having a good appearance or being good at singing wasn't enough to gain popularity.

One had to satisfy both and possess a unique character.

In that regard, Wish performed with Aoi playing the male role and Akane the female role while singing.

Moreover, it wasn't just a typical duet; Wish portrayed various relationship dynamics through song and dance: sometimes friends on the verge of becoming lovers, sometimes lovers in a rut, sometimes a neglected girlfriend whose popular boyfriend ignores her... They expressed the interplay between men and women through various love stories.

"Wow, you're real celebrities. I'm surprised."

"Fufu. But we're here completely privately. We finished last night's recording and have three days off!"

Her expressive body language was befitting a singer.

While Akane was bubbly, Aoi remained silent, merely nodding.

"But since it's our time off, we'd like to be called by our real names. My real name is Akemi. I'm your sister. Nice to meet you, Yuu."

"I see, nice to meet you, Akemi-neé. Then..."

"Her stage name is written differently, but her real name is Aoi with the hollyhock kanji. She's a guest member to come with me."

Akemi introduced Aoi, who remained silent.

"I see. Nice to meet you, Aoi-san."

"Ah... eh..."

Yuu extended his hand for a handshake after Akemi, but Aoi flinched and couldn't bring herself to offer her hand.

That reaction was rare, and Yuu found it somewhat delightful.

He took her hand forcefully and gazed at her closely, causing her to tremble and say, "Hawa wa wa," completely shattering her dignified image.

"Aoi may look like this, but she has no immunity to men at all. You should get used to it with Yuu."

"B-but still..."

Akemi waved her hands as if to say, "Oh well," while Aoi only grew more nervous.

"Hey, you're done with swimming practice, right? Want to play in that pool over there?"

"Hey, hey! Don't forget about us!"

"Yeah. I want to play with Yuu too!"

""""""Yuu!""""

"Ahahaha. Okay. Let's all go together."

In an instant, Yuu was surrounded by ten women in swimsuits, but when he looked at Kousaku, he waved as if to say, "Go ahead."

Then, with a splash, Kousaku dove into the pool and started swimming at an incredible speed.

---

### Author's Afterword

For the image of Wish, for those who know music from the late 80s to early 90s, it's like a cross between Wink and the Barbie Boys.

As for Akane (Akemi)'s image, it's more like Shoko Suzuki than Kyoko Koizumi.

### Chapter Translation Notes
- Translated "紅音" as "Akane" (stage name) and "朱美" as "Akemi" (real name) for Hidaka Akemi per character introduction context
- Translated "水樹 蒼依" as "Mizuki Aoi" (stage name) and "葵" as "Aoi" (real name) with note on kanji discrepancy (水樹 vs fixed list's 水木)
- Preserved Japanese honorifics (-neé) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "splash" for ざぶん)
- Rendered internal monologues in italics (e.g., Yuu's thoughts about morning conversation)
- Used double quotes for simultaneous dialogue from multiple speakers (""""""Good morning!"""""")
- Translated explicit swimsuit terminology directly (bikini, one-piece, high-cut)
- Maintained original Japanese terms for culturally specific items (natto, tsukudani, furikake)
- Translated "姉たち" as "sisters" with contextual understanding of half-sibling relationships
- Handled dialogue attributions without paragraph breaks when attached to speech