## 183. Dream Hot Spring Resort! ⑨ ~The Noisy Tropical Fish~

The destination where Yuu moved while surrounded by ten women including Akemi and Aoi was the wave-lapped area called Sazanami Pool.  
By the time they arrived, four more women had joined them.  

Mana and Rina, who knew Yuu was going to the pool, had come silently after finishing lunch without telling those around them.  
Mana looked great in a sporty blue-based swimsuit with fluorescent lines like those worn in competitive swimming, while Rina wore a cute pink floral one-piece with a frilled skirt that looked suitable for wearing outside.  
Of course, their prominently protruding breasts inevitably caught the eye.  

Furthermore, two guest members who'd been working up a sweat at the gym spotted Yuu and rushed over.  
One was Michiko, who'd kissed Yuu when she came to scold him for fooling around with his sisters in the large bath.  
Standing over 180cm tall with large breasts and buttocks, her voluptuous figure was evident despite the minimal coverage of her black triangle bikini.  

"Ah! Michiko-san. Hello!"  
"H-hello..."  

When facing Yuu directly, Michiko smiled shyly with slight embarrassment.  
Though a glamorous beauty who seemed competent at work, she clearly wasn't accustomed to men.  

"Um, and you're... Miyako-san from Mitsuba Electric, right?"  
"Gufu... I'm happy you remember me.  
Ahhaa~, getting to see a young man in swimwear... His skin is so smooth and beautiful. Haah, haah, I'm getting excited already. Can I touch you?"  
"Hey now!"  

Numerous companies from the Mitsuba Group conglomerate - including Mitsuba Construction, Mitsuba Electric, and Tokyo Mitsuba Bank - were involved in Hesperis's construction and ongoing operations.  
Though other guest members came from the Mitsuba Group, Yuu remembered these two because their names both started with "Mi" like their company.  

That said, while Michiko showed innocence, Miyako had been spewing passionate remarks toward Yuu since their first meeting, making her unforgettable.  
Even now, as Miyako reached out to touch Yuu, Michiko scolded her.  
Both Michiko and Miyako appeared around 30 and seemed to have known each other for some time.  
Miyako was short, likely under 160cm, but her breast and buttock size rivaled Michiko's. Her deep red halter-neck bikini barely contained her overflowing, prominently rounded breasts.  

"It's more crowded than I expected.  
Shall we play a game then?"  
""""""A game?""""""  
"You all want to play with Yuu in the pool, right?"  
"Well, obviously"  
"Being able to play in a pool with a man is an experience only possible here"  
"Plus a current high school boy in real swimwear! Haah, haah, dangerous. Precious!"  
"Hey hey calm down. Well, it's a scene only seen in fiction so can't be helped"  
"Exactly why only those who win the game earn the right to cling to Yuu while playing.  
That works, right? Yuu"  
"Ah, I'm dying to play with everyone but only have one body. As long as no fights break out. I'll leave it to you"  
"Alright!"  

Fourteen women had gathered at Sazanami Pool's shoreline targeting Yuu.  
Seeing this situation, Akemi's suggestion led to starting a game.  
Due to the large number, they split into two groups of seven, forming circles in the water to hit a ball around.  
Dropping the ball or sending it outside the circle meant disqualification.  
The last two remaining in each circle would be winners.  
They decided to use an oval float large enough for one adult to lie supine with Yuu and three others.  
Meaning they could cling closely with Yuu sandwiched between them.  
Hearing Akemi's proposal, all participants' eyes instantly lit up with determination.  

Yuu recalled his student days from his previous life.  
Having lacked female companionship during his youth, he unfortunately had no memories of playing at pools or beaches with a girlfriend or female friends.  

During university.  
He'd gone out with friends intending to pick up girls at the beach.  
Upon actually arriving at the sandy shore, he lost nerve and couldn't approach anyone, but thinking they'd come all this way, they split up to try approaching at least once.  
But reality proved brutal.  
After being repeatedly ignored when trying to talk to what seemed like female students or office workers in pairs, he became dejected and gave up.  
His friend faced the same situation, so they ended up swimming furiously and building sandcastles together in frustration.  

He later heard pickup success rarely happens in just a few attempts.  
The "spray and pray" method required persistently approaching 100-200 people for any payoff.  
Even seemingly experienced, flashy guys apparently had zero-result days too.  
The key was needing mental fortitude to not get discouraged no matter how harshly rejected or ignored.  

"Take that!"  
"Toooh!"  
"Danger!"  
"Taryaaah!"  
"Kuh! What the!"  

Before Yuu, two circles of swimsuit-clad women enthusiastically played ball... no, competed seriously.  
Initially expecting a beach ball suitable for the waterside, they'd brought a volleyball from somewhere instead.  
Moreover, when a chance ball came, they smashed spikes without hesitation while others desperately returned them.  
Women truly showed no mercy to each other.  
Though starting with cute, restrained voices, their intensity grew as they exerted themselves.  

That so many women would compete fiercely over a young man was an impossible scene in Yuu's pre-reincarnation world.  
Truly befitting an alternate world.  

While Yuu wanted to join the fun, their seriousness frightened him into spectating.  
That said, spectating had its perks.  
He could openly watch the colorful swimsuit-clad beauties with exposed skin moving earnestly in the water.  
One could say it resembled watching tropical fish swim elegantly.  
Plus their breasts shook dramatically with each jump. Especially bikinis nearly indistinguishable from underwear were marvelous.  
Though some lacked enough bust to shake.  
Aoi, representing that group, now looked lively unlike before.  
Likely having volleyball experience, her receives were skillful and spikes powerful.  
Another victim just fell.  

"Sei!"  
"Gyah!"  
"Ah dropped it! Too bad, disqualified!"  
"Ugugu... bitter disappointment!"  

Watching the ball she failed to receive roll away, Miyako slumped dejectedly.  
But immediately raising her face and seeing Yuu, she came dashing over energetically.  

"Yuukuuun, comfort meee~"  
"Whoa there!"  

Yuu spread his arms to catch Miyako.  
Feeling voluptuous breasts squish against his chest, he patted her bob-cut styled head.  

"There there. Too bad, Miyako-san"  
"Mufu. Male skin... unbearable. Haaah~~~ sniff sniff. Smells great~"  
"Hey, that tickles!"  

Miyako wrapped both arms around Yuu's back hugging him tightly while burying her nose against his neck and chest.  
Moreover, she subtly moved her hips, seemingly trying to savor the sensation of Yuu's crotch against her lower abdomen.  
Whether naturally flirtatious or just excited upon seeing Yuu here remained unclear.  

"Hey, enough! Don't get carried away!"  
"Kuh... I-I'm not jealous! Obviously winning and staying is better!"  

Seeing Yuu embracing Miyako, the remaining competitors exchanged conflicted words.  
This situation had a reason.  
When the first dropout appeared, Yuu sympathetically hugged her as a consolation prize for her extreme dejection.  
Thus, each disqualification meant one hug.  
Yuu enjoyed hugging swimsuit beauties while they treasured unexpected closeness with Yuu.  
Truly a win-win relationship.  

As Yuu comforted dropouts one by one, time passed until winners emerged.  
In one circle remained the Wish duo Akemi and Aoi.  
As the proposer, Akemi herself had good athletic ability, overwhelming the other five with Aoi's cooperation.  

The other circle saw Mana leveraging her former athletic club skills, cooperating with one of Yuu's half-sisters after her sister Rina's early elimination.  

"Then we'll go first!"  
"15-minute shifts. Fine"  
"Yuu, how about it? Me or Aoi - who do you want front and back?"  
"Hmm..."  

Before the large float Akemi and Aoi jointly held after winning rock-paper-scissors, Yuu pondered slightly.  
The oval float barely fit three people inside.  
Yuu occupying the center was predetermined.  

"Uwa... wh-what? Something touching...?"  
"Sorry Aoi-san. My dick got hard"  
"Ehh~ let me see... seriously? Yuu's is..."  

Originally a two-person float, squeezing in Aoi, Yuu, and Akemi meant close contact.  
Entering the pool in this formation and gradually walking deeper, Yuu's crotch had become fully erect midway.  
After all, hugging ten women consecutively left him semi-erect.  
Though androgynous-looking, Aoi had beautiful skin, pleasant scent, and characteristically feminine soft buttocks - his crotch couldn't help reacting where it pressed against her vulva.  
Additionally, Akemi pressed her breasts against his back from behind while breathing on his neck and kissing him.  
Truly a happy sandwich.  

Other women including the two awaiting their turn stayed at the shoreline.  
No point watching nearby and feeling jealous.  
They seemed to play ball without competition or discuss what to do with Yuu next.  

Sazanami Pool's deepest point was only 1.2m.  
Though possible to enjoy the waves while standing, Yuu decided to lift his feet and entrust himself to the float.  
Now sufficiently distant from shore, reservations vanished.  

"Aoi-san, your eyes are beautiful with long lashes - truly handsome. I'm enchanted. Chuu, chuu"  
"Fah! St...st-stop rubbing, no good!"  
"Ah. Unlike when singing, your voice is quite cute. Want to hear more. Haa~mmph!"  
"Hyan!"  

Exploiting Aoi's inability to escape while pressed against him, Yuu kissed and licked from her nape upward before biting her earlobe.  
His hands had been around her abdomen but now reached her chest.  
Though flat-chested with barely any swell, pressing near her nipples with his fingers made her twitch violently. Perhaps surprisingly sensitive.  

Meanwhile, Yuu continuously received Akemi's caresses from behind.  
Like Yuu, she used lips and tongue meticulously tasting his skin from shoulders to nape.  
After blowing hot breath in his ear, her tongue entered, sending shivers down his spine.  
Her fingers also traced his crotch pressed against Aoi's buttocks, exploring its shape.  

"Yuu, amazing. Such a long, thick penis - my first time. Ufufu, rock hard isn't it?"  
"Oh fu. W-well, being pressed together like this..."  
"Yuu's actually quite the pervert"  
"Y-yeah. I like women. Especially beauties like Akemi-nee and Aoi-san"  
"So happy~. Then big sis will pamper you... mo~re!"  
"Ah!"  
"Ah, nnn! Yuu... no good. Th-there... aah!"  

As Yuu slipped fingers under Aoi's swimsuit side to directly toy with her nipple, his other hand reached her crotch stimulating through the fabric.  
Meanwhile, Akemi inserted both hands inside Yuu's swimwear from behind.  
Her fingertips directly played with Yuu's nipples and glans.  
Clearly targeting a man's sensitive spots.  
Caressing Aoi while simultaneously receiving Akemi's caresses, Yuu grew unexpectedly excited, moaning against Aoi's nape.  

"Time's limited too. Yuu, want me to make you cum?"  
"Ah... yeah, wanna... cum"  
"Nnfu. Got it. Then like this"  
"Wawa, wait!?"  

Aoi voiced the last protest.  
After pulling down Yuu's swim trunks with their inner supporter to expose his penis, she further shifted Aoi's swimsuit so it pressed directly against her vulva.  

"Ooh... Aoi-san's pussy feels. Soft and warm"  
"Ngeh!? No way... th-this is, ah..."  

Though complete insertion proved impossible due to incomplete swimsuit removal and angles, his glans rubbed near her vaginal opening like sumata (non-penetrative genital rubbing), feeling slippery.  
Meanwhile, Akemi's hand jerked his shaft shaka-shaka.  

"Ah, ah, good... f-feels good!  
Kuu... ah, Aoi-san... look... here!"  
"Nn... hyum?"  

Turning as instructed over her shoulder, Aoi met Yuu's gaze with trembling eyes and a sidelong glance before he seized her lips.  

"Anh, Yuu, big sis too~"  
"Kuha! Ah, Akemi-nee... eh... I'm close..."  
"Then... cum while kissing?"  

Akemi's hand playing with Yuu's chest moved up to grasp his chin, sealing his lips.  
Her tongue invaded too.  

"Aeh... ehh, ahh, ifuu... nmo... uhh!"  
"Ahhaa, your penis~, twitching"  
"Pyah! Wh-what!? Something hot!?"  

With his glans pressed against Aoi's vaginal opening and Akemi's accelerated handjob, Yuu ejaculated.  
Though lacking usual force underwater, thick semen globs oozed out.  
While over half leaked away, some semen seemed to have entered Aoi's vagina.  
A non-penetrative handjob creampie without proper insertion.  
Though subtle compared to actual sex, it felt pleasurable enough that his hips seemed to move involuntarily.  
Until called by Mana and others when time ran out, Yuu continued deep kissing Akemi while tightly embracing Aoi.  


### Chapter Translation Notes
- Translated "姦しい熱帯魚" as "The Noisy Tropical Fish" to convey the metaphorical comparison of lively women to vibrant fish
- Translated "スマタ" as "non-penetrative genital rubbing" per explicit terminology requirement
- Preserved Japanese honorifics (-san, -nee) throughout dialogue
- Translated "浮き輪" as "float" instead of "inner tube" for accuracy regarding pool equipment
- Used "sumata" transliteration with explanation in parentheses for sexual act clarity
- Maintained original name order (e.g., Mitsuba Miyako) per style guidelines
- Translated "蛍光色" as "fluorescent" for technical accuracy
- Preserved sound effects like "ぐふ" as "Gufu" and "シャカシャカ" as "shaka-shaka"