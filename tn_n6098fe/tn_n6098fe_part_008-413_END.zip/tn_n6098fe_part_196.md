## 184. Dream Hot Spring Resort! ⑩ ~The Impertinent Ones~

Having played wildly with 14 women at Sazanami Pool, Yuu began to feel tired and decided to leave the pool to change clothes.

Before entering the changing room, he checked the time—nearly 5:00 PM.  
He had been in the pool for over four hours.

With some time before dinner, Yuu decided to go to the 3rd-floor basement café & bar.  
Naturally, the women who had played with him in the pool accompanied him.  
The group moved en masse from the passageway to the elevator, making them quite conspicuous.  
Though four women assigned to today's meal duty reluctantly parted ways, three others joined along the way, resulting in 13 women surrounding Yuu.

At Sazanami Pool, Yuu had not only intimately played with winners Akemi and Aoi but also deliberately touched breasts and buttocks repeatedly during water fights and underwater chases.  
Conversely, when women touched him, Yuu never showed displeasure—instead smiling happily.  
The guest-member women, including those who'd never had male connections before (besides half-sisters), were overjoyed by this attention and grew increasingly obsessed with Yuu.

Tonight's room companions would be chosen at Yuu's discretion.  
(To ensure fairness, Mana, Rina, and Satsuki were excluded as first-night partners.)  
Among over 50 women, those he'd grown close to would be easier choices.  
Naturally, the women hoped to follow him to his room with their current momentum.

*(First candidates would be Akemi-nee and Aoi-san. They're my first celebrities.  
Three would be better than two. For balance, maybe add another guest-member sister? Michiko-san or Miyako-san? Their bodies are irresistibly erotic.  
Hmm... tough choice. But taking everyone is impossible...)*

Shortly after showering post-pool, with damp hair still emitting shampoo fragrance and wearing light clothing, the women took turns flanking Yuu.  
Thus, Yuu walked with arms around waists on both sides—truly a "flower in each hand."  
Feeling their soft bodies against him, Yuu smiled while imagining tonight's pleasures.

The basement café & bar operated as a café from 7:00 AM to 6:00 PM, switching to bar service until midnight.  
However, it was self-service—simply allowing alcohol after 6:00 PM.  
Men used it free, while women were billed later based on usage frequency—bar hours naturally costing more.

"Akemi, making coffee?"  
"Ah, you'll brew it? Then please—black."  
"Hmm, so adult of you?"  
*Fufu*, well... Ah, I'll get cups ready."  
"Thanks."

While Akemi and Mana prepared drip coffee, Yuu retrieved cups from the cupboard for coffee drinkers.  
Others prepared tea or cold drinks from the refrigerator themselves.  
The women watched Yuu's helpfulness with surprise and approval—unlike most spoiled men raised by maids or parents.  
To Yuu, this was merely an extension of household chores done at home or the student council room.  
Such exceptions were rare—limited to Yuu and other sons sired by Sakuya.

"Miyako-san, what work do you usually do?"  
"Fweh? M-me?"

When Yuu moved between Michiko and Miyako, placing a hand on her shoulder as he asked, she seemed startled.

"U-um... I-I'm... in the SCM department at headquarters."  
"Sorry, what's SCM stand for?"  
"Ah... S-Supply Chain Management. Literally 'supply chain'—referring to production/logistics processes from raw material procurement to consumer delivery...  
A recently adopted term... you know, with organizations preferring Western terms over kanji for a 'new era' feel..."  
"Uh-huh. And?"  
"W-well... my department links material flows with information, sharing it company-wide to optimize business activities..."

Suddenly asked about work, Miyako switched from her poolside harassing demeanor to stiff formality.  
Perhaps she was strictly professional at work.

"I see! Can't say I fully understand, but I see it's crucial work. So Miyako-san excels at a corporate nerve center? Impressive!"  
"Wehehe. Th-thank you. Happy you praised me."

Seated in two groups of six or seven, conversation partners were limited unless Yuu moved.  
So Yuu decided to ask each woman about their daily lives.  
Guest members here were elites from renowned corporations, national civil servants, or politicians' secretaries.  
Though reborn from a low-ranking salaryman, Yuu hid those feelings.  
He praised their work through a student's lens—some knowledge felt outdated due to era/gender reversal differences, but he masked this well.

After all, unlike school, most women here were professionals. Even Tokyo-based, transfers might separate them forever—a once-in-a-lifetime encounter.  
Yuu hoped to leave them good memories.  
Plus, by the time he started working, these women would hold higher positions—networking now was strategic.  
Conversely, women delighted in face-time with Yuu and being asked about themselves.  
Being noticed by a young handsome man was precious.  
Thus, Yuu's actions made them preen like salarymen flattered by hostesses.

"And this is the café & bar—alcohol available after 6:00 PM. Age-wise, you're fine regardless.  
Self-service either way—prepare everything yourselves."  
"Hmm. Interior's decent but unimpressive."  
"Quite so, indeed."  
"Ugh, making our own meals? Annoying! Why not invest more in F&B?"  
"Well... unavoidable. Not labor costs—confidentiality reasons."

While Yuu's group chatted animatedly, Satsuki arrived guiding three newcomers.  
The small space carried their voices—Yuu found them oddly impertinent.  
Other women frowned similarly.  
In Yuu's view from the rear seats entered Satsuki followed by three unfamiliar figures.  
The leader stood notably short—head barely reaching Satsuki's chest.

*(Huh? Elementary schooler?)*

All three appeared early-teens at best.  
The foremost girl—hands on hips, chest puffed arrogantly—looked about ten.  
Her outfit: white long-sleeved blouse with abundant frills, red-and-navy checkered pleated skirt like a uniform.  
Hair: milk-tea beige in short twin-tails (shoulder-length) with curled permed ends.  
Though now bored-looking with half-lidded eyes, her slightly upturned large double-lidded eyes recalled a cat, with overall refined features.

The two behind seemed slightly older.  
One slim, the other not quite fat but plump.  
The slim one stood a few centimeters taller than the first.  
Oval face with upturned narrow eyes. Straight black hair in a one-length cut covered half her face, nearly reaching her buttocks.  
A long white dress completed her horror-movie aura.

The last appeared shorter than Yuu but adult-height.  
A loose hoodie and baggy cargo pants emphasized her sturdy build.  
The open hoodie revealed prominently protruding breasts.  
Her rounded features and bob cut made her seem childlike despite her body—perhaps 13-14.  
Her black, acorn-shaped eyes stared curiously at drink cabinets behind the counter.

Yuu vaguely imagined a cat, fox, and tanuki trio.

*(Brought by guest-member parents?)*

As Yuu wondered, the leader girl spotted him while scanning rear-seated women.  
Her lips curled like a predator finding prey.  
She marched straight to Yuu and stood imposingly before him.

"H-hi, I'm—"  
"Decided!"

Women grew irritated as she interrupted Yuu's greeting, pointing rudely.

"Where's your room?"  
"Huh? Room 10, but—"  
"Wait there after my bath!"  
""""""Haaah?""""""

Protest erupted naturally at this sudden intrusion—everyone had restrained themselves from imposing on Yuu.

"Wait! No cutting in line!"  
"Spending the night with Yuu is for us adult women!"  
"What're you? Hags aren't welcome!"  
"B... what ill-bred brat!"  
"Ha! Kids should sleep with mommy!"  
"The hell you say?!"

Blue veins bulged on the girl's forehead, lips twisting to reveal double fangs.  
Outnumbered by adults, she showed no fear—glaring back fiercely.  
Clearly strong-willed.

"W-wait!"  
"Stand down!"

As Yuu rose amid escalating tension, the two followers emerged like attendants from diagonal rear positions.

"Know you not who this is?! The honorable Minatomo Shizuka—granddaughter of Minatomo Tazu, secretary-general of the ruling Liberal People's Party!"  
"Lower your heads!"

Yuu thought it sounded like a *Mito Komon* seal-revealing scene—but the effect was immediate.

"The Party's..."  
"Secretary-General Minatomo...?"  
"Bad news. Too influential. Wrong opponent."

Instantly, women averted their eyes awkwardly.  
Satisfied, Shizuka addressed Yuu:  
"Told you. Don't forget."  
She turned heel to leave, attendants scrambling after her.

"What was that about?"  
"Sorry, everyone."

After the trio stormed out, Satsuki approached Yuu apologetically.  
"Need to talk privately. A moment?"  
Sensing gravity, Yuu nodded.  
Noticing the women's dejection, he bid farewell with "Let's play again later."

Minatomo Tazu (69).  
From a political dynasty in Ibaraki Prefecture, her mother was the late Minatomo Shizuko—prime minister for 12 years.  
Though never PM herself, Tazu served multiple terms as construction minister—don of construction policy tribes.  
As leader of the largest faction, she held covert political influence.  
Her daughter Setsuko (48) was also a Diet member, leading young legislators in the Liberal People's Party.

Having studied this world through TV/news, Yuu recognized the name—though not the granddaughter.

Led by Satsuki to a basement room, Yuu faced her across a table. She wore a deeply troubled expression.

"Some guest members... hard to refuse when connected to power."  
"Ah... well, companies, ministries, and ruling parties involved in Hesperis' establishment/maintenance. Guest slots go to groups close to Father since his lifetime—mutual back-scratching."  
"Really?"  
"From a woman's view, our brothers are handsomer and better with women than average men.  
Spending time with them builds connections—some even became wives.  
For guest members, it's a far better environment than outside."

Guest-member women had eyed Yuu ambitiously but never forced themselves—joining only with his consent when encountering his group.  
They likely knew this unspoken rule.  
But these girls were exceptions.

"Heard Shizuka is Setsuko's late-life child—doted upon. Secretary-General Tazu's first granddaughter too—utterly spoiled."  
"Ah, that..."

Political dynasties carried weight. Ideally, politicians should work tirelessly for supporters—regardless of sincerity.  
Adults might separate public/private faces, but a child spoiled by grandmother and mother would inevitably grow arrogant.

"So... Yuu must host those three tonight."  
"But... except one, they look like elementary schoolers?"  
"Ah, understandable, but Shizuka is 13—a middle-schooler."  
"Eh?!"

"Note: 'small and cute' is taboo—she's sensitive about it."

The attendants:  
Horikawa Sumie—same age as Shizuka, local notable family (grandmother/great-grandmother were mayors). Watery "desu wa" speech. Family friends with Minatomo.  
Gouda Tamaki—plump, 14. Grandmother is president of Gomart supermarket chain and Minatomo support group chair.

"Have a request, Yuu."  
"Request?"

Satsuki's expression suggested plotting. Leaning across the table, she gripped Yuu's hands.

"Since you're hosting them anyway... use your skills and that cock to discipline them into submission!"

---

### Author's Afterword

Reached Part 10 by evening of Day 2.  
The hot spring resort arc finally hits its midpoint.

### Chapter Translation Notes
- Translated "生意気" as "The Impertinent Ones" to capture the girls' arrogant behavior
- Preserved Japanese honorifics (-san, -nee) and name order (Minatomo Shizuka)
- Translated "供給連鎖" literally as "supply chain" per academic term requirement
- Used explicit terminology for sexual content ("cock", "submission")
- Transliterated sound effects ("Fweh", "Wehehe")
- Maintained italics for internal monologues
- Applied double quotes for simultaneous group reactions (""""""Haaah?""""""")