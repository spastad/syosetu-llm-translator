## 187. Dream Hot Spring Resort! ⑬ ~Holding Me Close...~

"Foh! Ooh, oh, ohho! Raw cock, so good! This is... way better than any vibrator! Ahhh—unbearableeeeee... ooh, ooh, damn... so, so good! M-my hips... can't stop! Aaunngh! I-I-Ihi... already... cumming, cummiiiiiiing!"

Tamaki straddled Yuu, her ample breasts bouncing wildly as she frantically rocked her hips. Already close to orgasm, her cheeks flushed pink with drool dripping from her mouth - a complete slut face.

Yuu had been enjoying the afterglow of ejaculating inside Shizuka when he noticed Tamaki, who'd been watching bedside, had reached her limit.

"I want it, I want it too... I need cock too... I can't hold back anymore!"

She scrambled onto the bed and crawled toward him on all fours. Flustered, Yuu carefully laid the barely conscious Shizuka at the edge of the bed before attending to Tamaki. He realized over an hour had passed since he started with Shizuka. During that time, Tamaki had been masturbating continuously, but seeing Shizuka orgasm had become unbearable.

Since he'd just been with Shizuka, Yuu lay on his back and let Tamaki mount him in cowgirl position. She grimaced momentarily at the initial penetration, but pleasure quickly overcame her as she felt his cock reach deep inside. She immediately began rocking her hips with moans, but her movements were so wild he almost slipped out. Yuu supported her by gripping her buttocks.

Now leaning forward, Tamaki firmly grasped Yuu's shoulders while violently thrusting her hips. Nuccha, nuccha—the sticky wet sounds echoed from their joining area. Though Tamaki's virgin pussy felt amazing with its hot folds tightly squeezing, Yuu still had stamina after his recent ejaculation. As he kneaded her vigorously swaying breasts, he glanced at the other girl.

"Come over here."  
"Huh?"

Yuu called out to Sumie who was rubbing her thighs together some distance away. She looked puzzled.

"Straddle my face. I'll lick your pussy."  
"Eh!? R-really?"

When Yuu beckoned near his face, she finally understood. Her usually aloof expression instantly melted.

"O-on a gentleman's... face... de, hehehe... *ahem*"

Sumie's lewd expression lasted only a moment before returning to her prim face, but she eagerly approached Yuu. Even this young lady couldn't hide her lust—truly a girl of this world.

Positioning her butt toward the panting Tamaki, Sumie straddled Yuu's face. From below, her slender legs appeared thin with little flesh, though her chest showed gentle curves—slightly more feminine than Shizuka. As she swept her long black hair back and looked down at Yuu, her mouth relaxed. She probably felt similar to a virgin boy receiving his first blowjob.

Unlike Tamaki who'd soaked her thighs during mounting, Sumie's area didn't appear very wet. But as her spread labia drew near, Yuu could see the glistening moisture inside.

"Haa, haa... this is... like a dream. P-please take care of me."  
"Sure, leave it to me. Hmm, a pretty pussy."

Even when her center reached his nose, it was odorless. Yuu spread her open with his fingertips and gave a long lick.

"Hyauu!"  
"Whoa, don't pull away."

When Sumie's body jerked, he wrapped his left arm around her waist to hold her in place. Then he licked around the center of her spread pussy with his tongue.

"Ah, hi... nn, nn, nnnnnnnnnn~nhaa! W-what is this!? Aaah! Th-this... unknown! Nnaaaaaaaaah!"

Sumie had mentioned being hard to arouse earlier, but after over an hour of watching Yuu with Shizuka while touching herself, and now receiving cunnilingus, she'd become sensitive. The more he licked, the more nectar flowed.

*(Who'd have thought I'd taste two immature middle schoolers' pussies in a row?)*

Even Yuu marveled as he continued. Sumie's developing pussy, with its slight pubic hair, was slightly larger than Shizuka's child-sized one, but still an untouched fruit. He doubted it could take his cock. Since they'd made a bet, cunnilingus seemed more likely to make her cum than penetration.

"Ahhi! St...stop... ann, ann! Good, so good! Better than... when I do it myself!"  
"Hoka, hoka—you like here?"  
"Hyaaaaaiii... y-yes! M-more, nn, kufuun!"  
"Hah, hah, hah... cock, cock feels good! Ooh, ooh, ohho... coming! Again... something amazing... comiiiiing!"

While fingering her vaginal opening with guchu guchu sounds, Yuu flicked her clitoris with his tongue. Sumie arched back, completely lost in the sensation. Tamaki resumed riding him after her break, so their moans overlapped above Yuu.

*(Ugh... Tamaki's hip movements are amazing for a virgin. And that virgin pussy grip... tight!)*

Tamaki's hips slapped against him with bachun, bachun sounds with each thrust. Her movements were wild and selfish without technique, but combined with her increasing wetness, Yuu's pleasure intensified.

*(Focus on Sumie for now.)*

He might cum inside Tamaki at this rate. Since Tamaki was hugging Sumie from behind, the trembling Sumie couldn't escape.

Yuu alternated between flicking with his tongue tip and licking broadly with the flat of his tongue. Occasionally changing position, he thrust his tongue into her vaginal opening while rubbing her clitoris with his fingertip or pinching it.

"Ah... ahe... hi, uu, uhi... wh-what is... this sensation... aoh! Hoh! St-stop... no more! Ah, ah, I can't take it... h-hey, I'm becoming strange!"  
"Ooh, ooh... I... I'm cumming again... cumming cumming cumming!"

Realizing both were nearing climax, Yuu knew this was the critical moment. While attacking Sumie's clitoris with his tongue, he simultaneously thrust upward.

"Ooooiin! N...ha... stooop... guh·en·kai! Aheee... no mooore... cu... guh... nnooooooooooh!"  
"Aanngh! Nn, nnnnnnnnnnnnnnnnnnnnnnnnnnnnnn~n!"

Tamaki and Sumie reached simultaneous climax, freezing motionless before collapsing limply. As Sumie slumped forward, her lower abdomen completely covered Yuu's eyes and nose. He panicked—and didn't immediately notice Tamaki had also lost consciousness and collapsed with her.

---

"Straight to business—I'm inserting it now."  
"Haii!"

Having failed to cum inside Tamaki, Yuu pulled out his cock and rolled the unconscious girl toward Shizuka. Still aroused, he pushed Sumie down, spread her legs wide, and pressed his rock-hard cock against her. Still dazed from her cunnilingus orgasm, Sumie offered no resistance.

*Schlurp.*

Yuu somewhat forcibly pushed his cock into Sumie's developing vagina. He wanted to conquer another virgin pussy. He wanted to ejaculate quickly. Such thoughts dominated Yuu's mind—unusually, he lacked consideration for his virgin partner. Mid-insertion, he felt something *snap*.

"Ii... higiii! It hurts, aaaaaaaaaaah!"

Unlike Shizuka and Tamaki, Sumie apparently still had her hymen. But Yuu had little restraint left.

"Sorry! It hurts, right Sumie? Bear with me like this."  
"Y-yes! P-please... don't mind me... give me your cock. Ug... I want... you to make me a woman!"

Gripping the sheets tightly, Sumie held back tears as she declared this. Since she'd already cum from cunnilingus, Yuu had technically won the bet. But for her, graduating from virginity through sex with Yuu mattered more.

Though she looked like a typical villainess sidekick with a mean personality, that was separate. Though slightly taller than Shizuka, she was still petite and slender to Yuu—she disappeared beneath him when he covered her. Her fox-like eyes weren't beautiful, but Yuu felt desire welling up. Slowly but surely, he pushed through her vaginal walls.

"Ahh... inside Sumie... feels amazing. Guh... just a bit more."  
"Ha... hai. Ahkuu! I-it's... entering! Inside me... Yuu-sama's cock... oooh, nnk... aaaah!"

When he thrust deep into her vaginal depths, tingling pleasure shot through Yuu's body, making him kiss Sumie. Her eyes widened momentarily before closing as she savored the kiss. Tears streamed down Sumie's cheeks—not just from pain—as she experienced her first kiss simultaneously with losing her virginity.

---

"Hah, hah, uoh! Damn, about to cum!"  
"Nn, nn, nnaah! Haa... fine! Inside me..."

After just minutes of penetration, Yuu sensed his limit approaching. He couldn't possibly impregnate this 13-year-old girl.

"Sorry, baby-making comes later. I'll pull out."  
"Nn! I-is that... so? Disappointing... but if Yuu-sama says so... ann!"

Though pain likely remained, Sumie didn't look distressed—perhaps because Yuu held her tightly.

"Ugh... cumming, Sumie!"  
"Yu, Yuu-sama... aaaah! Fine... by me..."

Sumie looked up at Yuu with flushed cheeks and closed eyes. Keeping their lips locked, Yuu increased his thrusting speed for the final sprint.

"Nmuu! Iiuu!"  
"Nnaah... ooh... uunngh!"

Pulling out at the last moment, Yuu rubbed against Sumie's lower abdomen and ejaculated—dopyu dopyu dopyu—sending streams of semen flying onto her stomach and flat chest. Though he couldn't make her cum internally, Sumie sighed at the hot sensation on her body.

---

"Um... Yuu? S-sorry."

After a while, Shizuka got off the bed, knelt formally on the floor, and bowed to Yuu. Sumie and Tamaki followed suit.

"What's this all of a sudden? Oh, the bet?"  
"Th-that too, but... well... we want to apologize properly for breaking the rules here and forcing ourselves on you."  
"W-we also apologize for joining in the coercion!"  
"M-me too."  
"Sumie and Tamaki aren't to blame! They always try to stop me when I charge ahead! This is entirely my responsibility!"  
"Shizuka-san..."

Hearing this exchange, Yuu reassessed them. They could reflect and apologize for misbehavior. They didn't blame others. Though spoiled, they weren't fundamentally bad kids. Of course, an ordinary man might not have achieved this outcome—only Yuu could sexually discipline them this way. Regardless, Yuu wasn't particularly angry.

"I don't mind. More importantly—you lost the bet. Can you apologize before everyone at dinner tomorrow?"  
"Y-yeah."  
"Naked dogeza style."  
"Uu..."  
"Kidding."  
"But... a woman's... word is..."  
"Adults can convey sincerity with a normal bow."  
"R-right?"

Their expressions visibly relaxed. Making them perform naked dogeza before everyone would be awkward for all, so Yuu never seriously intended it.

"That matter's settled. More importantly..."

The three looked puzzled at Yuu's smile. Then they noticed they were still naked. Their gazes gathered at Yuu's crotch—even flaccid, it was visibly larger than average.

"Don't you think it's too early to sleep?"  
"U... un."

When Shizuka responded, Sumie and Tamaki nodded too. About two hours had passed since entering the room, but midnight hadn't come. Yuu got off the bed and retrieved chilled drinks from the fridge for all. After rehydrating, he urged them back onto the bed.

With Shizuka facing him cross-legged, Sumie on his right and Tamaki on his left encircling him, Yuu began kissing them starting with Shizuka. Simultaneously stroking their heads and playing with their nipples.

"Ahh! Kissing Yuu makes... my chest feel tight! Like heartache!"  
"M-me too! And having my head stroked feels wonderful..."  
"Yu, Yuu's hands are magical... big and warm. Touch me more!"

All three pressed against Yuu, competing for kisses and caresses. Though Tamaki was a year older, Shizuka and Sumie had been elementary students just half a year ago. Yet even with these young girls, skin-to-skin contact aroused him.

"Ah! Your cock is... no way?"  
"Yep. Got hard again."  
"Eh... but books say men need time after ejaculating..."  
"Already came twice though."  
"Huh?"  
"Inside Shizuka and on Sumie's stomach."  
"Eeeeh!"  
"Amazing!"  
"I passed out and missed it!"  
"Then why not touch it? Look closely."

Yuu leaned back with hands on the bed behind him for better viewing. After exchanging glances, they slowly lowered their faces toward his crotch.

"S-so hard... and rugged. More impressive than in books!"  
"Ahh, such a big cock... entered me somehow!"  
"Ah, it twitched!"

Initially hesitant, they soon grew curious and explored every inch with their palms. Though not a handjob, having three girls' hands roaming from tip to base felt increasingly pleasurable.

"Feeling really good now. Rather than just touching, I want you to lick it."  
"R-really?"  
"Yeah. Like I licked your pussies, take good care of my cock."  
"W-will do!"  
"Un, want to lick cock!"  
"Me too!"

Suddenly motivated, they began competitively licking his cock—Shizuka licking the glans while Sumie and Tamaki licked along the shaft. A triple blowjob from three middle schoolers. Yuu smiled at this improbable scenario.

"Ooh, good. Feels great. Yeah, lightly grip it and stroke."  
"Amuehoro... like this?"  
"Lero, lero... clear fluid came out. Chupa."  
"Nfuh. Licking cock gets me horny. Nnaa... pero, kufu."

Shizuka seriously took the glans into her mouth, licking and sucking precum like savoring it—her cheeks puffed like a squirrel storing food. Her right hand stroked near the base. Sumie focused on his balls, carefully touching one while sucking the other. Tamaki explored the veiny ridges and rough underside with tongue and fingers while fingering herself. As pleasure built, Yuu took turns stroking their heads.

Though it took time, he eventually ejaculated from their blowjob and let them clean every drop. But Yuu's sexual discipline showed no signs of ending yet.

---

### Author's Afterword

The second day finally ended. The third day starting next chapter will likely be the last long day.

☆Second day conquests:  
Guest member Minatomo Shizuka (13) - Granddaughter of Liberal People's Party Secretary General ※Virgin  
Guest member Horikawa Sumie (13) - Shizuka's follower 1 ※Virgin  
Guest member Gouda Tamaki (14) - Shizuka's follower 2 ※Virgin  


### Chapter Translation Notes
- Translated "メス顔" as "slut face" to convey the explicit sexual expression
- Preserved Japanese honorifics (-sama) and name order (Minatomo Shizuka)
- Transliterated sound effects: "ぬっちゃ" → "nuccha", "びくん" → "bikun"
- Translated explicit anatomical terms directly: "チンポ" → "cock", "おマンコ" → "pussy"
- Rendered sexual acts without euphemisms: "クンニ" → "cunnilingus"
- Maintained internal monologue formatting: *(Who'd have thought...)*
- Translated "素直に I'm Sorry" as "Holding Me Close..." to capture emotional nuance while preserving original phrasing
- Used gender-neutral "they/them" for collective references to the girls when appropriate
- Preserved cultural terms: "土下座" → "dogeza" with explanation in context
- Kept honorifics in dialogue: "祐様" → "Yuu-sama"