## 189. Dream Hot Spring Resort! ⑮ ~BREATHLESS LOVE~

Approaching the enormous bookshelf that covered half the wall, Takako slid the front section. 

The bookshelf had three rows of document files, but otherwise stood noticeably empty. The back section also remained mostly unfilled. Frankly, it seemed like wasted space.

Crouching down, Takako pulled out an encyclopedia from the bottom shelf. As she reached into the empty space, a *clack* sounded like something disengaging. Then, with just a light pull, the back bookshelf slid aside, revealing a space wide enough for a person to pass through.

"Come, this way."  
"Whoa..."

It was indeed a secret hidden room. Heart racing at this mechanism that stirred masculine excitement, Yuu followed Takako inside. She apparently operated something immediately, as lights illuminated the dark room. Simultaneously, the bookshelf silently returned to its original position after Yuu entered.

The room appeared stark and plain with white walls, floor, and ceiling except for the left side. About 8 tatami mats in size, it contained no furniture. A door at the far end suggested further spaces beyond.

"What is this place...?"  
"Beyond here is a secret passage for evacuating men during emergencies like major earthquakes or hostile intrusions. There's one on each floor, known only to directors and leaders like Satsuki."

"I see."  
"And its other purpose is... step aside for a moment."

At Takako's gesture, Yuu moved near the right wall. She manipulated something at the left wall edge, blocked from Yuu's view by her body. With a light *click*, the lower half of the wall detached and lowered like a mattress - about single-bed sized. Behind the protruding mat, a gap contained transparent boxes stocked with tissues, vibrators and other adult toys, plus unidentifiable containers.

The secret room was clearly a sex room. Smiling at Yuu's astonishment, Takako asked:

"Lights... stay like this?"  
"Ah... yeah."

Without waiting for confirmation, Takako smoothly removed her dress. Seeing her black lace lingerie, Yuu stared speechlessly, captivated.

*A beautiful woman's back view is alluring too.* From this angle, her skin looked smooth and flawless. A striking inverted triangle back clearly showed shoulder blades. After unhooking her bra behind her back, she slowly removed it while angled diagonally - teasingly conscious of Yuu's gaze. This position revealed glimpses of breast tips from the side, incredibly erotic.

After removing the bra, she slowly slid down her panties using both hands. A perfectly rounded, plump buttocks came into view. Despite her slender limbs, her butt was voluptuously full, making him tremble with desire. Standing like a flamingo on one leg to remove her panties, Takako turned to face Yuu.

"My? You're not undressed yet?"  
"Gah! S-sorry. I'll strip now."

Unable to admit he'd been staring transfixed, Yuu hurriedly began removing his clothes.

"Wow! Magnificent."

Now Takako directed a heated gaze at Yuu's naked body. Her eyes traveled down his toned young physique before locking onto his crotch. Seeing her undress had caused an erection so firm his cock pointed skyward.

Displaying it openly, Yuu stepped onto the mat. Takako sat near the center with straightened posture that emphasized her breasts while arching her back. Though she appeared slender, her forward-facing breasts formed perfect bowl-shaped beauties with ideal volume. Her age-defying physique at over thirty was truly actress-caliber.

Yuu approached until within touching distance. When their eyes met, he noticed faint blushing on Takako's cheeks. She averted her gaze slightly, looking down.

"How embarrassing. I'm more nervous than during actual filming. Maybe because it's been so long?"

Though exuding seductiveness while undressing, Takako now showed shyness upon seeing Yuu naked. Whether acting or genuine, it intensely stirred him as a man.

Smiling, Yuu reached out to stroke Takako's nape.

"Actually I'm nervous too."  
"Liar. You've bedded so many young girls, you must be used to it by now?"

She glared slightly and poked his chest.

"Haha. Used to it? Maybe that's true. But I'm always nervous with new partners. Especially with such a beauty. Takako, you're incredibly gorgeous."  
"Yuu... hehe. Such a good boy."  
"Hey now. Don't treat me like a kid. Look what you've done to me?"

Yuu lifted his hips to thrust them forward. Blushing while staring, Takako looked up and caressed his cheek.

"True. You're a fine man, Yuu. Then call me just 'Takako'."  
"Okay. T-Takako."  
"Mhm, Yuu. Kiss... me?"

Instead of answering, Yuu captured Takako's beautiful face in his vision as their lips met, his arm encircling her shoulders to pull her close. His nervousness wasn't fake - his heart had been pounding since earlier. But the moment their soft, moist lips connected, his body ignited as if his temperature skyrocketed.

"*Chu... mmph... nn... ah... T-Takako!*"  
"*Nchu... fah... nn! Yuu!*"

Like newly united lovers, Yuu and Takako's passion surged violently. They embraced tightly, exchanging kiss after kiss. Each kiss increased their arousal. Who started first? Maybe simultaneously. They opened mouths, tongues entwining wetly. While kissing deeply, they kept full body contact, exploring each other's heads and backs with caressing hands.

Yuu sealed her lips while swirling his tongue broadly inside Takako's mouth. Simultaneously, his right hand slid down her slick back to trace her waistline before firmly grasping her rounded buttocks.

"*Fah!*"

Takako broke the kiss involuntarily. A string of drool stretched from her half-open mouth. Her half-lidded, lustful expression made Yuu burn hotter. His left hand stroked from her neck to collarbone before gently cupping her left breast - surprisingly soft and slightly too large for one hand. Suppressing the urge to squeeze hard, he maintained a soft touch.

"*Aahn!*"

As she moaned cutely, Yuu reclaimed her mouth. This time Takako initiated tongue play while her hands gently stroked Yuu's head and back.

"*Nfuu... chupa chu, chu, chu... nn! Lero, lero, leroo... faa... aahn... Yu... u... ah! Kuun!*"  
"*Nn! Nku... T-Taka... ko... nmoo... nn!*"

When Yuu teased her nipple with fingertips, Takako retaliated by tracing his glans. Not just that - placing a palm on his chest, she rubbed with subtle motions before simultaneously stimulating both his glans and nipple. Throughout, their deep kissing continued uninterrupted, mutual breaths mingling. Unable to restrain themselves, they kept licking each other's tongues while caressing sensitive areas.

"*Kuh... ya... hyau! Yuu!*"  
"You're already wet."  
"Yuu's tip is... dripping too."  
"Because I'm incredibly aroused."  
"What a coincidence. Me too. Ah... hey now!"  
"I want to suck your breasts too."  
"Wai... Yu... aahn!*"

Yuu's right hand moved from her buttocks past her anus to trace her slit - already soaking wet. Meanwhile, he lowered his head to latch onto a breast, playing with the nipple in his mouth. Her nipple, rubbed against his chest earlier, had plumped up stiffly. But Takako retaliated by lightly grasping his cock and stroking *shako shako*. With each pump, precum made sticky, clinging sounds.

"*Haaun! Aah, aah, I knew it... feels good! I'm so sensitive! Ann... there... nhyi! Ii... aa... good! A... AAAAAAAAAAAHHHHH... hah, hafuu, Yuu... you're good...*"

Yuu reached between her legs from the front for easier access, placing fingers at her slit entrance with *kuchu kuchu* sounds before rubbing her clitoris. That alone seemed to make Takako climax lightly. She ruffled his hair and lifted his face with her other hand, showering his forehead, nose, cheeks and lips with kisses before pleading:

"It's been... so long since I've felt this horny. So... let me suck your cock?"  
"Huh?"  
"*Neeeeh... pleeease!*"

She mashed their lips together while thrusting her tongue in, simultaneously lowering one hand to pinch his glans with multiple fingers.

"*Pah... nhi... o... ku... nupu! O-okay, I get it!*"  
"*Kufu*"  
"But I want to lick Takako's pussy too."  
"Nn?"

Yuu whispered to Takako:  
"Let's do sixty-nine?"

Takako nodded without hesitation. Apparently she knew the act itself.

***

"*Kuooh! Wai... ahh!*"  
"*Mufuu... n~~~ ohhiin... nmoo, juru jupaa... nn, nn, nero, ero, nfuu...*"

In the sixty-nine position, Yuu lay supine while Takako straddled above. Immediately grabbing his cock, she licked the glans thoroughly before taking half its length into her mouth. While savoring it orally with full-tongue caresses, she occasionally pursed her cheeks to *chuu chuu* suck the glans.

"*...kuh... aa... d-dammit... me too*"

Spreading her slit wide with fingers, overflowing love juice dripped onto Yuu's face. Like Yuu's raging erection, Takako seemed highly aroused - emitting the scent of a female in heat. Yuu narrowed his tongue and sucked directly onto her slit's center.

*Bero bero juru chupu jucchuu—jurun! Chupa chupa juu—pecha pecha perochi ruuuu!*

"*KyaaaAAAAAAAHHHHHHHH! Naah! Ii... shooore, juruiiiiiiiiiiii... haa, haa, I won't... lose... a~nmu! Nmu! Nn, nn, nfuun*"  
"*Kuooh! Nyaa! Kuu~~... f-feels good!*"

Not to be outdone by Yuu's cunnilingus, Takako took him deep into her throat and began earnest sucking while shaking her head. Simultaneously, she gently kneaded his balls with her palm. As his entire cock felt incredible and ejaculation approached, Yuu inserted two fingers into her vagina while lowering his chin to flick her clitoris with his tongue tip.

"*Nfoo~~~~ ooh, nn, nkuu! Fa... ann! Nkuu... n—mu! Nn, nn, nmu!*"  
"*Aah... nkuuu~ nero, chup, nyaa!*"

Both Yuu and Takako moaned through mounting pleasure while continuing their ministrations, seemingly competing to climax first.

***

"*Kyaaaah! St... stop... iyaah! Aah, aaah! Im... possible! Cumming... a... a... AAAAAAAAAAAHHHHHH—Yu, Yuu! Cumming, I'm cummiiiiiiiiiiiiing!!!*"

As Yuu pumped two fingers in and out, Takako's lower body trembled violently before cloudy female ejaculation overflowed. Seemingly climaxing, she rubbed her cheek against his saliva-slicked cock. But Takako proved formidable - without lingering in afterglow, she resumed sucking immediately. Having made Takako cum first, Yuu couldn't resist in his relaxed state.

"*Vuah! That's... no! Cumming, I'm cumming!*"

Whether hearing him or not, Takako pinned his bucking hips firmly with her left arm while stroking from the base with her right hand, sucking relentlessly. Yuu reached his limit shortly.

"*Ku... hah! Cumming! Vu!*"

Thick, powerful spurts of semen shot into Takako's mouth. Smiling contentedly at the hot torrent hitting her throat, she audibly gulped *goku goku* while swallowing every drop.

---

### Author's Afterword

I love the trope of important people having secret sex rooms in their offices. In a normal setting, this would typically involve executives and secretaries, or perhaps pillow business arrangements.  


### Chapter Translation Notes
- Translated "シックスナイン" as "sixty-nine" using the numerical form per explicit terminology requirement
- Preserved Japanese honorifics (none used in this chapter)
- Maintained original name order: "Tsutsui Takako" throughout
- Transliterated sound effects (e.g., "chupa chupa" for ちゅぱちゅぱ)
- Italicized internal monologue: "*(A beautiful woman's back view...)*"
- Translated sexual anatomy/acts explicitly: "ワレメ"→"slit", "チンポ"→"cock", "しゃぶる"→"suck"
- Used gender-neutral "person" for "人" in evacuation context
- Formatted simultaneous quotes with double quotes when characters vocalize together during sex
- Translated "三十路" as "over thirty" for natural English flow while preserving meaning
- Rendered "我慢汁" as "precum" per explicit terminology rules
- Kept cultural term "tatami mats" with explanation implied through context