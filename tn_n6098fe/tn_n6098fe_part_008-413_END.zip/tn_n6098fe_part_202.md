## 190. Dream Hot Spring Resort! ⑯ ~Mistress~

### Author's Preface

The first half is from Takako's perspective.

---

Most men are said to lose their heat immediately after ejaculation.

I'd heard that leaving them alone after the act was key to harmonious relationships since men dislike prolonged clinging. Though women psychologically crave skin contact after lovemaking, we restrain ourselves to avoid displeasing men.

But now, having abandoned all restraint, I kept sucking Yuu's cock even after swallowing every last drop, refusing to release him. Despite the time passed since his ejaculation, its heat and hardness showed no signs of diminishing.

I took the entire glans into my mouth, licking it thoroughly with both sides of my tongue. When kissing the urethral opening, I sucked the transparent fluid that seeped out as if rejoicing. Upon releasing the glans, saliva-mixed cloudy fluid formed strings. Tucking back stray strands of hair, I sucked sideways from the base this time. Then sliding like playing a flute while teasing with my tongue tip. I meticulously licked the rough underside area said to be highly sensitive for men.

Chu, chu, chupa... nk, amu... nfuu~~ lero lero o, lero on... jururi.

"Ah, your cock... oh, it's so good..."  
"Ah... Ta-Takako... ahh!"

I looked at Yuu lying on his back. *(How adorable)*

Overflowing passion surged within me. Keeping my left arm around his waist, I stroked from his taut abdomen to chest with my right hand while continuing the blowjob. Despite having ejaculated once, I rejoiced he remained sensitive. His twitching cock felt too precious to release. My long-dormant female instincts had awakened, craving a male with primal intensity. My face must have been utterly lust-drunk.

---

At sixteen, I stood at a crossroads: continue acting or live as an ordinary girl after transitioning from child roles. That's when I met Sakuya-san at a TV station after he called out to me, beginning our brief yet intense affair. After receiving his love, I pushed work aside to be with him whenever possible - though his busy schedule limited us to weekly meetings. Sakuya-san never showed annoyance at this young girl clinging to him despite being just one of his many wives and mistresses. I took advantage of his generosity. While I was merely a newcomer among his women, he was my idol, the overflowing source of love I never received from a father - my mother bought sperm without knowing the donor.

But happiness proved fleeting. His sudden death brought overwhelming grief, followed by pregnancy. While raising my child at my mother's home, I recalled Sakuya-san's words: "The choice is yours, but giving up means the end. Live without regrets." So when my daughter entered elementary school, I returned to acting. Abandoning my child-star pride, I learned from veterans and took any role - even minor or degrading ones. Over time, work increased. Though typecast as villains rather than the glamorous leads I'd dreamed of, I accepted it. I'd gained recognition.

As my fame grew, I met industry men, some becoming close through co-starring. But I never competed with other women pursuing actors. Through the Toyoda Sakuya Memorial Foundation, I connected with Sakuya-san's wives and children, including Masaki who resembled him enough to stir my heart. Still, I never considered other men romantically - Sakuya-san remained my only love and my child's father.

I learned of Yuu's existence years later. Unlike girls, boys' identities are concealed longer for safety. Back then, I saw him as just another son among many.

Around June's end... The foundation has four women called the "First 4" - Sakuya-san's original wives. They hold significant influence, with Haruka-san serving as permanent director for years.

One day, Haruka-san summoned me with special requests: become a non-standing director starting July 1st, and use that position to approach Yuu and know him intimately. Essentially, I was chosen as the youngest and most beautiful among Sakuya-san's women - one who could attract even a younger man while being trustworthy.

Seeing Yuu's actions since April, he reportedly resembles Sakuya-san in his youth. After brief consideration, I accepted, deciding to cancel some minor jobs. After signing the appointment documents, I learned shocking secrets about Sakuya-san and that Yuu not only received Special A Class semen rating but was sexually involved with multiple women including half-sisters - unthinkable behavior for a normal 16-year-old, suggesting something extraordinary about him.

I scheduled my Hesperis invitation for Yuu's third day to observe his activities. Learning from Satsuki how he spent his first two days strengthened my conviction. All that remained was meeting him personally and confirming things... if possible on the spot.

◇ ◆ ◇ ◆ ◇ ◆

"Ah! That much... kuhhh... I-I can't hold back anymore!"  
"Anh! Yuu... what's wrong?"  
"This time... inside you, Takako."  
"Fufu. Yes. I want to become one with you too. Then, let me take you in."  
"Huh?"

As Yuu raised his upper body, Takako straddled him again. Words were unnecessary now. Placing one hand on Yuu's shoulder and guiding his cock to her vaginal entrance with the other, she took him in with a *kuchuri* sound.

"Ahh!"  
"Ahh!"

They cried out simultaneously, experiencing identical indescribable pleasure. Though prepared, Takako's vaginal walls tightly clenched the thick, hard cock after so long, making her grip Yuu's shoulder. Milky love juice dripped from her stretched pussy, soaking the mat.

Despite being a thirty-something mother, Takako's heated, slick interior rivaled any teenager's in tightness. Yuu grew frustrated when her hips stopped mid-descent - he wanted her entirety, to reach deep and taste her cervix. Gripping Takako's shoulder and waist firmly, Yuu made his intention clear.

"Haah, haah... Yu-Yuu? W-wait"  
"No. Can't wait."

*Zun!*

"Aghh! St...ah...stop..."  
"Here I go!"  
"Hic!"

Having been sucked relentlessly even after ejaculation, Yuu easily maneuvered into position. Holding Takako down, he thrust upward in retaliation.

*Tan! Tan! Tan!*

Rhythmic slapping sounds echoed as their genitals collided with each thrust.

"Anh! Anh! Ah...nnh! Ah...hi...iih! Deeep! Stooop...ahh! Ah! Ah! Ah...I'm cumming! Stop I'm cummiing! Haaaah ah, kufuuu...nnnh!"  
Clutching Yuu tightly, Takako came easily - but Yuu didn't stop.

"You came already?"  
"Ah...nh...I-I did..."  
"Good. Cum as much as you want. I'll make you feel amazing."  
"Yu...u...?"

Sweat plastered Takako's bangs to her forehead, her hair framing flushed cheeks in disarray, her expression utterly debauched. Seeing such beauty lost in ecstasy only excited Yuu more.

Hugging Takako's slender body to enjoy her breasts, Yuu sealed her drooling lips. Takako desperately clung to his head, kissing back passionately.

"Nmuu...nchu, chu, chuuuu...paah. Aahn! Yuu, amazing! If you do this...I-I'll go cr-crazy!"  
"Uah! I-I feel...amazing too!"

Though overwhelmed since joining, Takako now matched Yuu's thrusts. Whether conscious or not, her powerful clenching when he plunged deep sent electric shivers up his spine. Of course, this intensified Takako's pleasure, pushing her toward another climax.

"Ooh! Ooh! Oooh! Your cock...incredible! Ahhh! Cumming! Cumming again! Yu...u...ahhhhhhhhhhhhhhhh!"  
"Kuh! I-I'm...cumming too! Takako...ah, can't stop!"  
"Sto-stop! Yu-Yuu! Kya...nooo...just came...nmuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuun!"

At the brink of ejaculation, Yuu pressed his glans against her cervix in a grinding motion. Without recovery time, Takako buried her face in Yuu's neck with a long moan.

"I'm...cumming! Ooh! Ejaculating! Ahhh!"  
"Nmooh!? Ooh...ah...ooh...nh, uhn!"

Takako nearly lost consciousness from the pleasure of Yuu's thick semen filling her womb but endured by gripping his body hard enough to leave marks. Dazed yet blissful, she clung to Yuu until his ejaculation ended, wanting to feel every moment.

"Hahh...that felt incredible, Takako."  
"Ahheee...me too."

Honestly, Takako had expected greatness. Most 16-year-olds are virgins, but Yuu reportedly enthralled multiple older half-sisters. The reality exceeded expectations.

"Yuu...you were amazing... And you gave me so much. I might get pregnant. Fufu. *Chu*"

As Takako kissed him happily, Yuu stroked her messy hair.

"Hm? Want another?"  
"Ah... Not that I normally think about it... But if sex leads to pregnancy, I wouldn't mind. I still have energy, and savings enough for a break..."  
"Let me be blunt. Will you bear my child?"  
"Huh?"

Yuu's bluntness might stem from possessiveness toward Sakuya's former mistress - or simply male instinct to impregnate desirable women. After all, Yuu's arousal hadn't diminished.

Hearing this, Takako nodded dazedly. Accepting this, Yuu slowly pushed her down while still inside, carefully cushioning her head.

"Kya... Yu-Yuu? What?"  
"We're not done yet."  
"Eh? Ahh! No way..."

Maintaining penetration while covering her, Yuu shifted forward. Slipping his arms under her knees, he spread her wide and lifted her hips into breeding press position - sealing her vagina with his cock to pour in fresh seed.

"Yu...u...ahh! W-wait...like that...deep...ah, ah, ahhh!"  
"Hah, hah, hah... I'll definitely...get you pregnant...with my seed!"  
"Nkuh! Yu...u...in-incredible! Wha...fah!? Nooooo! Au au...my head...flying away! Cumming! Anh, Yuu, Yuuuuuu! I'm cummiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiing!!!"

Takako lost control of her cries. Yuu pounded into her with *do-chun, do-chun* thrusts as she desperately clung to his back, legs locked around his waist.

*(I'll surely get pregnant...today. A girl? Or boy? I'd prefer a boy. Nana would be happy to have a little brother...)*

Such thoughts flashed through Takako's climax-drenched mind before the next peak overwhelmed her, leaving only screams of Yuu's name.

### Chapter Translation Notes
- Translated "愛人" as "Mistress" to maintain thematic consistency with the chapter's focus on Takako's role as Toyoda Sakuya's lover
- Preserved explicit anatomical terms: "おチンポ" → "cock", "亀頭" → "glans", "膣" → "vagina"
- Transliterated sound effects: "ちゅ" → "chu", "じゅるり" → "jururi"
- Maintained Japanese name order: "Toyoda Haruka" (豊田 晴花)
- Translated "ファースト4" as "First 4" with explanation in chapter notes
- Rendered sexual acts without euphemisms: "種付けプレスの体勢" → "breeding press position"