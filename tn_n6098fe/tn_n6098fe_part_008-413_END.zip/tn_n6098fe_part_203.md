## 191. Dream Hot Spring Resort! ⑰ ~At a Loss for Words... Summer~

### Author's Preface

This is the second consecutive chapter focused on conversations with Takako, and it was quite difficult to write.

I hope you'll understand why when you read the content.

Additionally, I've added the name of the permanent director (Haruka) who requested Takako to approach Yuu after she agreed to become a non-permanent director in the previous chapter.

---

After releasing his third load, Yuu lay on his back with Takako clinging to him immediately beside him. Even Yuu felt tired, breathing heavily, but the exhaustion like finishing a marathon combined with the warmth of Takako's skin felt so comfortable that he wanted to fall asleep right there. Takako was too drained to even speak, yet she lovingly ran her palm over Yuu's rising and falling chest.

About ten minutes passed in that state when suddenly an announcement echoed through the building. Apparently there was a speaker in an inconspicuous location in this room too.

*"It is now 12 o'clock. Those who ordered lunch boxes, please gather in the dining hall."*

"Ara."

"Already that time..."

They had come to the director's office at 10 AM, so two hours had passed. They hadn't noticed while being absorbed - truly like arrows of lust.

"Yuu, did you order lunch?"

"Ah, yeah."

"Then let's have them bring it here. I want to talk while we eat together."

Without waiting for Yuu's reply, Takako stood up and tried to walk naked, but perhaps due to exhaustion, she staggered. Yuu immediately caught her from behind.

"Ah, thank you. You're so kind."

"Huh? I just did what anyone would."

"Maa."

Supporting Takako who was nodding to herself, Yuu stood. Even though they'd just had such intense sex, looking at the beautiful line from her nape to shoulder while their bodies touched made his crotch react again. Unintentionally, he wrapped his arms around her from the front and hugged her tightly.

"Takako, you're truly a wonderful woman."

"Ara, I'm happy."

They kissed as Takako turned around, but at the worst timing, a "guuuuu~~" sound came from their stomachs, making both laugh. It wasn't just Yuu's stomach - Takako's had growled too.

"I'll contact them. Yuu, go take a shower. It's through the door to the left in the hallway."

"Mm, got it."

Opening the inner door as instructed, a dimly lit corridor stretched straight ahead with stairs visible at the end. That must be the emergency exit.

After showering in a narrow room like those at beaches, Yuu dried himself with the provided towel and returned. When he reentered the director's office dressed, Takako had changed clothes too, and two lunch boxes were already on the table. The lunch was always the standard makunouchi bento - pickles, rolled omelet, and simmered dishes remained constant, while grilled fish and fried items changed daily. These bentos delivered by a side dish supplier were quite delicious, unlike convenience store versions.

"What should we do? I can wait if you want to shower."

"I'm too hungry. But if you say I smell sweaty, I'll go shower."

"Nah. Not smelly at all. Actually, you smelled nice."

"Yada!"

Probably remembering being hugged from behind earlier, Takako blushed faintly and hurried to the adjacent water-heating room. She seemed to be preparing tea.

---

"Then while washing off in the bath, I got horny and was hugging and cuddling with Satsuki and the others when a woman got mad at us. But she was nice, so when I hugged and kissed her, she forgave me. Then when we soaked in the tub, I couldn't stop getting hard, so they all gave me handjobs."

"I was worried if I could swim properly, but Kousaku-nii taught me, and I managed to learn. After that, I went to the Sazanami Pool with Akemi-nee and Aoi-san..."

"Shizuka and the others really surprised me. I thought they were so rude at first meeting. So when they came to my room, I made a bet. What we bet was......"

Though Yuu often watched news on TV, he rarely saw dramas except when accompanying Martina. He was somewhat curious about the entertainment industry from someone actually in it - not that he idolized celebrities, but opportunities to talk with an active actress were rare.

But Takako herself had entered high school but barely attended due to pregnancy, childbirth, and childcare, so she didn't know high school life and wanted to hear Yuu's stories. Moreover, she wanted to know how Yuu had spent his time at Hesperis. At first he considered omitting specific acts, but swept along by Takako's skillful listening, he found himself describing exactly what he'd done.

"So Yuu really loves women, huh?"

"Ahahaha. Well, I admit I'm lewd and have strong sexual urges."

"And you don't care about age or blood relations either? You don't mind even if a woman reeks of virginity or has strong sexual desires."

"Hmm. My personal standards are: not too big an age gap, and as long as looks or personality aren't extremely bad, I welcome them."

"What if a woman you just met demanded 'I want sex!'?"

"That depends on the person. I wouldn't refuse outright."

"I see."

They had already finished eating and were drinking tea. Hearing Yuu's answer, Takako seemed lost in thought.

After a period of silence, Takako stared intently at Yuu. Her gaze felt probing, making Yuu unconsciously avert his eyes. Smiling faintly, Takako reapplied her lipstick and spoke.

"I want to discuss something important now. Do you have time?"

"Umm..."

Today he was assigned to the meal preparation team. Normally it started at 5 PM, but he'd heard Sundays began 30 minutes early. There seemed to be something after dinner. Yuu had planned to spend the afternoon at the pool or game room flirting with women, but he felt he should properly hear Takako out. It was just past 1 PM, with plenty of time before dinner prep.

"Sure. It's fine."

"Good. Then let's get more tea first."

Instead of starting immediately, Takako stood up as if to create a pause, leaving Yuu somewhat deflated.

After drinking a second cup of tea to reset, Takako savored the tea but didn't start talking immediately, wearing a pensive expression. Perhaps she was organizing what to tell Yuu.

"Hey, Yuu?"

"Yeah?"

"Umm..."

She seemed about to broach the subject but looked hesitant.

"Do you believe in... 'rebirth' or 'reincarnation'?"

"Huh?"

"You know how TV and magazines sometimes feature specials? People who remember their past lives? Not time slips or time leaps where you go back to your own past. Being reborn as a completely different person across worldlines. Whether you're born with memories and a solid sense of self, or suddenly remember one day - it probably varies."

Ignoring Yuu's stunned silence, Takako rattled on rapidly. For Yuu, it wasn't about belief - he was living it. But he wasn't in a position to answer frankly yet.

"So, what do you think?"

"Ahh, well... I think most supernatural stories featured on TV or magazines are probably lies."

"Why do you think that?"

"Because normally people would keep it secret, right?"

No one would easily believe you if you said you remembered a past life. At worst, you'd be seen as a weirdo. In fact, Yuu hadn't even considered telling his family about his rebirth.

The stories featured on TV and magazines were probably just entertainment gimmicks like psychics, UFOs, or ghost stories. Though Yuu himself had enjoyed such mysterious tales once - before internet became widespread.

"Hmm. That's the normal reaction. I couldn't believe it immediately when I first heard it either."

Nodding to herself, Takako murmured. Suddenly, Yuu wondered - did that mean Takako now believed?

"Why do you think I, busy with my acting career, became a non-permanent director at such an odd time?"

"Huh? Now that you mention it..."

As a popular, top-rated actress, if Takako was cast in a movie or TV series, she'd be tied up for days filming. Yuu could easily imagine she'd have no spare resources for other work.

"That was around late June. Haruka-san... ah, one of Sakuya-san's first wives and a permanent director of the foundation... told me various things I hadn't known about Sakuya-san before marriage. It was shocking, but in the end, it strangely made sense."

Saying this, Takako gazed into the distance. Yuu remained silent, listening without interrupting.

"When his first child was born and he held it in his arms, Sakuya-san apparently shed tears in emotion and let slip: 'Is this my child? I never got to see one in my previous life. I'm so moved.'"

"Pre... vious life?"

Yuu felt shock like being punched in the head. Sakuya's first child must have been when he was 15 or 16. It seemed unlikely for a boy that age to cry over having a child. But Yuu remembered his own emotion when hearing Sayaka was pregnant. If he'd died without having children and had his first child after being reborn, wouldn't the emotion be overwhelming?

"Then that means...?"

"After calming down, he apparently confessed only to his four wives at the time: 'I died once and was reborn.'"

According to what she heard, this world's Sakuya was in a car accident at age 11 that killed both parents and his grandmother - his grandfather had already died. When Sakuya regained consciousness after surviving with serious injuries, he remembered his previous life - one where he died at 31. In the previous life Sakuya described, the gender ratio was nearly 1:1. Polygamy was prohibited except in rare cases, and one-on-one dating was normal. Men had stronger sexual desires, adult content overwhelmingly targeted men, and sexual crime victims were mostly women. In other words, a world just like before Yuu was reborn.

"Sakuya-san apparently said during his lifetime that in his previous life, he'd lived as a scoundrel - deceiving women, exploiting them, forcing abortions even after impregnating them. And right before dying, he thought: This must be punishment for my past. He didn't elaborate, but apparently it wasn't a proper death. So in this reborn world, he resolved to change his ways and be as kind as possible to women. In this distorted gender ratio world, too many women go unrewarded. So I want to do whatever I can for them."

Before Sakuya became famous, there were men who'd impregnated over ten women with strong sexual drive. But no man had taken so many wives or exchanged affection with women who desired him, rarely refusing unless age or looks were extremely mismatched. Sakuya was too anomalous for this world's men. The reason was his life in a world with completely different chastity values as his backbone. Of course, he also possessed the strong sexual drive and stamina to fulfill his and the women's desires. Just like Yuu now.

"At first I couldn't believe it. But what I knew about Sakuya-san was only a fraction. His long-time wives are truly amazing. When they taught me various things about Sakuya-san unknown to the public, I started to understand. That he was someone reborn from a world with completely different values."

"I... see..."

"Sakuya-san's achievements are famous, so you probably know to some extent, Yuu. But apparently he nearly gave up many times."

"Why?"

"Though he had help from many women, what one man can do alone in today's world is limited. He wanted to restore the distorted gender ratio to normal, but even if successful, it might take decades - no, over a century. So he wanted cooperative men. Preferably someone sharing similar values. He wondered if there might be another man reborn from another world like him."

Hearing Takako's words, Yuu couldn't easily say "Actually, me too." Or rather, he was somewhat confused.

Was it coincidence that only Sakuya and Yuu were reborn into this world after dying in their previous lives? Because Sakuya and Yuu were blood relatives? What about his other brothers? Did Sakuya have blood ties to Yuu in the previous life? No, apparently he hadn't had children, so probably not. Either way, with Sakuya dead, there was no way to confirm. As if answering Yuu's first question, Takako continued.

"Sakuya-san apparently searched for other male reincarnators like himself. But given the nature of things, he couldn't move openly and found no candidates."

"So in the end, only Father was?"

"Yes. He directly questioned people claiming past-life memories on TV shows, but none seemed genuine. The foundation's hidden purpose after Sakuya-san's death was to search for men reborn from other worlds like him."

Saying this, Takako leaned forward, peering intently at Yuu.

"Yuu, on your way back from middle school graduation this March, you were chased by girls from the same school, fell off a pedestrian bridge, and suffered a head injury requiring stitches, right?"

"Y-yeah."

"And you regained consciousness three days later. Your semen test showed Special A Class - rarely given. I heard nurses at the hospital praised you highly. After entering high school, you unusually joined the student council as a first-year boy, became very active, and your popularity among female students skyrocketed across grades."

"W-well, I've been blessed with encounters..."

"You accept sperm donation monthly, which young guys usually hate, and don't mind procreative sex with much older half-sisters. You're simultaneously dating all three student council officers and recently got engaged, I hear?"

"Eh? Even that far..."

Yuu felt completely exposed.

"No, I don't know exactly how many women you're involved with. But I can definitely say you love girls and are aware of your strong sexual urges... right?"

"W-well... I won't deny it."

"You understand what I'm implying now, don't you?"

She grabbed the hands resting on his knees.

"What kind of world were you reborn from?"

### Chapter Translation Notes
- Translated "荒淫矢の如し" as "arrows of lust" to preserve the metaphorical meaning of uncontrollable sexual desire
- Rendered "ぐぅ～～～" as "guuuuu~~" for stomach growl sound effect
- Translated "特A判定" as "Special A Class" per Fixed Reference terminology
- Preserved Japanese honorifics (-san, -nii, -nee) throughout
- Used explicit terms like "ejaculation," "semen," and "procreative sex" per style guidelines
- Maintained original name order (e.g., "Toyoda Sakuya" not "Sakuya Toyoda")
- Italicized internal thoughts like *"This is concerning"* per formatting rules