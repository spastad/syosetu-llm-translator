## 193. Dream Hot Spring Resort! ⑲ ~I LOVE YOU~

The hall on the second basement floor was divided into a stage and seating (300 seats).

It wasn't as large as the concert hall at Saiei Academy that Yuu and the others had been invited to at the beginning of the month, but it was spacious enough to remind one of a large university lecture hall or auditorium. The sound equipment was reasonably well-equipped.

In the center of the stage was a standing microphone. At both ends, there were a stand piano and an organ.

Also, on the left side of the stage, a long vertical sheet of paper hung from a wooden stand, with the performers and their acts written in large letters. It was the so-called "flip chart."

Today's performers were 12 acts by self-recommendation or others' recommendation. Among them, three were males, including Yuu.

Yuu had been given a thick booklet of songs recorded in karaoke beforehand and flipped through it, but he only remembered the choruses of songs he'd heard in commercials or dramas.

So, Yuu decided to go for it.

He would sing a song from his previous world that he still remembered, a cappella.

After careful consideration, he chose a song by a certain male artist he had liked in his teens.

The artist's songs expressed the conflicts and inner cries of young people in society and school. Additionally, his death at the young age of 26 had a huge social impact, and he was hailed as a charismatic figure among the youth.

Although the lyrics were often noted for their radical content, it could be said that they were characterized by their straightforward expression of dreams, love, and the meaning of life.

Thinking that a ballad would be suitable for a cappella, Yuu chose a song from the first album that was later released as a single and wrote down the lyrics.

Yuu wasn't particularly good at singing, but he didn't think he was tone-deaf either.

He thought it would be fine if he sang with all his heart.

While he was practicing by singing repeatedly in the waiting room, Tohru came to see him, worried, so he had him listen once...

As soon as he finished listening, Tohru hugged him, startling Yuu and making him freeze. Then, Tohru whispered in his ear:

"Ah, words alone aren't enough to express these feelings. How should I put it? I just wanted to hug you!"

"N-no... that, I..."

"Sorry for startling you. It just means I was that moved."

"O-oh, if that's the case, then it's fine. Anyway, p-please let go."

"But, you know, I'm scared of how the women will react when they actually hear it~"

After that little episode, when Yuu and Tohru entered the hall a bit late, the fun party had already started, hosted by Masaki and Satsuki.

The first four acts were solo singers performing passionately with karaoke. The fifth act was a soprano solo accompanied by piano.

Even Yuu, who had only been reborn in this world for half a year, recognized them as famous songs that everyone knew.

Though an amateur, Yuu clearly realized: they were much better than him, and he felt nothing but admiration.

When they finished singing, everyone gave them enthusiastic applause.

And then, the highlight of the first half was the duo Wish—Mizuki Aoi (also known as Aoi) and Hidaka Akiko (also known as Akemi).

They seemed to have changed into stage costumes: Aoi wore a navy suit with a light blue tie, and her hair was slicked back in splendid male attire.

In contrast, Akemi was dressed in a deep red long dress that exposed her shoulders, wearing a wide-brimmed hat with feather decorations in the same color scheme. She also had pink gloves on.

They looked exactly like a gentleman and a lady attending a soiree.

Given the chance to see the popular duo perform live, the hall was understandably filled with excitement.

They were apparently going to perform two songs as a special treat.

The first song was the one that had sparked their breakthrough last year, starting with an upbeat intro and lively dance from the very beginning.

The lyrics seemed to be about a man and woman who were truly in love with each other, but the aggressive woman pushed forward while the indecisive man couldn't show a clear attitude.

Thus, the dance expressed how the more Akemi pushed, the more Aoi pulled back, which was also visually entertaining.

It was exactly like a common love story in this world.

At the end, the woman, who couldn't make her strong feelings understood, showed her sadness, and the man, flustered by her stepping back, hugged her tightly. The woman smiled slyly in the man's arms, leading to a happy ending.

The second song was a ballad released this spring, a complete change of pace.

It was themed around a couple parting due to circumstances that would take them far apart.

"*You'll be fine no matter where you go. You'll surely find a woman to support you.*"

"*But I'll keep thinking of you for the rest of my life. Even if this body decays.*"

Yuu wondered if he was the only one who felt a somewhat heavy emotional weight in the woman's words.

Among the women listening, some were seen with tears in their eyes, having empathized too much.

After Wish performed two songs and left the stage to thunderous applause, there was a break of about ten minutes.

"This is bad. I'm getting nervous."

"Huh? Even Yuu gets nervous?"

"Well, yeah. Especially since everyone was so good."

"Relax, relax. Um... someone said to imagine that the audience is just a bunch of vegetables."

"Huh?"

Tohru, who had been coming here every year since high school to perform magic, was probably fine.

Yuu himself had gotten used to just talking in front of women by now.

But after the first five acts, who were near-professional level, and then Wish, who were actual professionals, he worried that his singing might fall flat and bore everyone.

The start of the second half was an impersonation act.

Moreover, it was an impersonation that exaggerated characteristics to get laughs, so some were even tearing up from laughter.

The guest member who performed wasn't a professional, but after being well-received at workplace parties, they had apparently honed their act.

The next three acts were one-shot gags and magic tricks.

The third act was Tohru.

He called for volunteers, and many hands went up; three people came on stage.

A magic trick where a coin thrown into a handkerchief held by a woman disappeared.

Another trick where, despite having his wrists tightly bound, they came undone the moment Tohru gave the signal.

Finally, a classic magic trick where he guessed a card drawn without him seeing.

There must have been tricks and gimmicks, but they weren't visible to the audience, making it look like real magic, which was impressive.

By the time Tohru's turn ended, Yuu headed to the wings of the stage.

After the duet by Masaki and Satsuki. And of all things, he was the grand finale.

They sang about the exchanges of a couple in a rut in a light tone, and their perfect timing with hand and facial expressions elicited spontaneous laughter from the audience.

It truly reminded one of a married couple who had been together for about ten years.

As the two disappeared into the wings of the stage to applause, it was Yuu's turn.

Satsuki, still holding the microphone, introduced him.

"Now, finally, the moment you've all been waiting for: Yuu's turn.

He'll be singing a cappella without accompaniment. The song is—"

"「「「「Kyaaaaaaah!」」」」"

"「「「「Yuuuuu!」」」」"

Before Satsuki could finish the introduction, yellow screams erupted.

Though on a different scale, it felt like being a bit of an idol.

"Calm down. I'm sure Yuu will sing well."

"Y-yeah."

Tohru must have noticed that Yuu was clearly nervous.

After replying, Yuu was lightly patted on the shoulder by Masaki and then took slow, deep breaths.

By the way, he was still dressed in a white T-shirt and blue jeans.

He thought that for this song, it was more fitting to be simple without any adornment.

"Alright. Here I go!"

"Good luck!"

When Yuu stepped out and appeared, the yellow screams grew even louder.

But when he stood at the center of the stage under a white spotlight, the hall fell silent.

Probably so as not to miss his voice from the start, since he was singing a cappella.

However, several women clutched their chests as if their hearts had been shot when they saw Yuu's shy smile.

Yuu looked around the seats.

The seats, which had been scattered at the start, were now concentrated in the front rows.

In the center were the sisters Mana and Rina, along with Loretta.

Akemi and Aoi, who had shown splendid singing and dancing in the first half, were watching from the side in their stage costumes.

On the opposite front row were Shizuka, Sumie, and Tamaki. Behind them, Michiko and Miyako were also visible.

A bit further back sat Kosaku and Takuya.

Takuya had said he wasn't interested in the fun party, but it seemed he had come to listen.

Next to him, waving, was Tohru.

Looking further back, Takako was also seated.

Next to her seemed to be Hiromi, the foundation staff member in charge of sound.

Since there was no need to play music, she apparently decided to listen from the audience.

Everyone was staring at Yuu with expectant faces.

Strangely, Yuu realized he was calm.

It's okay. It should go well.

Just as he convinced himself of that, the piano intro began playing in his head.

The intro was short, and he started singing after about 15 seconds.

"I love you..."

It was from the perspective of a boy about Yuu's age.

He and his girlfriend were in love, but their relationship wasn't understood by parents and others around them.

Their feelings for each other were second to none, but reality wasn't sweet enough for them to cling to each other and live on just that.

Still, they held each other tightly.

Thinking that feeling each other's warmth was the greatest happiness for now.

Yuu sang without missing the melody in his head, pouring in as much emotion as he could.

Mentally, he was an old man, but listening to this song brought back the unadorned, straightforward feelings of his youth.

At the start of the song, the image of a female classmate he had a crush on in high school came to mind.

But as he sang, what surfaced in his mind were the various expressions of Sayaka, whom he had genuinely come to love since being reborn in this world.

Recalling the live footage of the male artist he had seen over 20 years ago, Yuu sang to the end.

After a moment of lingering emotion, he bowed and said, "Thank you very much."

But the hall remained silent, with no reaction.

Yuu feared that his singing was too poor for an audience and had fallen flat, but then he noticed that many women in the front row had tears streaming down their cheeks.

And then, cheers louder than before he started singing erupted.

"「「「「「Kyaaaaaaaaaaahhhhhhhhhhhh!!!」」」」」"

"「「「Yuuuu!」」」"

"It's wonderful!"

"I love you!"

"I'll hold you tight! On a creaking bed!"

"This is the first time I've felt such heartache... Could this be love?"

"It was as if the scene clearly appeared in my mind..."

Except for a few who were still immersed in the world of the song Yuu sang, tears streaming down, most of the women were standing up.

Not only that, but they were approaching the stage, almost as if they were about to climb up.

"Th-thank you.

Thank you so much for listening!"

Relieved, Yuu smiled and shook hands with each of the women reaching out to him.

He thought it was the only way to calm them down.

"I was so moved. But it's a song I've never heard before. Could it be... Yuu's original?"

"Um..."

Cornered by Akemi's question, Yuu was at a loss for how to respond, but with women coming at him one after another, he had no choice but to evade with vague words.

"Um, sorry to interrupt the excitement, but it's time to wrap up!"

Satsuki called out through the microphone, but the excitement of the women surrounding Yuu on stage didn't stop.

Suddenly, an ear-piercing "Kiiiiiiiiiiiiiiiiiiiiin!" echoed, and the hall fell silent in an instant.

Before anyone knew it, Takako had taken the microphone and come on stage, causing feedback next to Satsuki.

"I'm Takako Tsutsui, a director. I'd like to take this opportunity to tell you something.

Tonight is Yuu's last night staying here. I'm sure you're all reluctant to part.

Therefore, using my authority as a director, I'd like to let Yuu use the special room on the fourth basement floor."

"「「「The special room!?」」」"

"Huh? The special room...?"

Apparently, only a few of the older brothers and sisters, including Masaki and Satsuki, knew what the special room was, and most didn't.

After all, it had been a sealed room for nearly 20 years.

"The special room... is spacious enough for 10 people to stay comfortably."

"Does that mean Yuu will have to handle that many...?"

Once again, everyone turned their gaze to Yuu.

Meanwhile, Takako approached Yuu.

"Your song has captivated this many women. You understand, right?"

She didn't say it explicitly, but essentially, she was telling him to take responsibility.

Yuu looked around at the women surrounding him.

Beautiful women and girls with flushed cheeks from expectation, their eyes moist as they gazed at him.

A man couldn't back down from this.

He couldn't decide who to invite and who not to.

Yuu nodded firmly and declared:

"Fine. I'll take on as many as you want. Until I reach my limit."

---

### Author's Afterword

The climax of the hot spring resort arc is finally approaching.

### Chapter Translation Notes
- Translated "アカペラ" as "a cappella" to maintain musical terminology accuracy
- Translated "めくり" as "flip chart" to convey the traditional Japanese performance schedule display
- Translated "一発芸" as "one-shot gags" to preserve the comedic performance style
- Translated "男装" as "male attire" for Mizuki Aoi's cross-dressing stage costume
- Preserved original pronunciation "アイ ラーヴュー" as "I love you" in lyrics to reflect artistic style
- Transliterated sound effect "キイィィィィィーーーーーン" as "Kiiiiiiiiiiiiiiiiiiin"
- Translated "黄色い歓声" as "yellow screams" to retain Japanese idiom for high-pitched female excitement
- Translated "理事" as "director" for Tsutsui Takako's foundation role per professional title rules
- Maintained Japanese name order (e.g., "Mizuki Aoi") and preserved honorifics throughout
- Italicized internal monologues per style rules (e.g., *It's okay. It should go well.*)
- Used simultaneous quotes formatting ""..."" for overlapping dialogue from multiple characters