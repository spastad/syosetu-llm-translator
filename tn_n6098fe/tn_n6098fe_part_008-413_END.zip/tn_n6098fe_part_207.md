## 195. Dream Hot Spring Resort! ㉑ ~After All, She's an Idol~

"Aah...ahh...kwaa! Th...this is...amazing...Yuu...your penis...so big!"

"Woah...Akemi-neé's pussy...damn, feels too good!"

Akemi placed her right hand on the penis, guiding it into her vagina. She'd lost her virginity three years ago when she first entered showbiz, spending one night with a male idol. Even compared to that experience, she knew this was longer and thicker, but upon insertion, it exceeded her expectations. As she slowly lowered her hips to take it in, she stopped midway. For Yuu, this teasing was unbearable. Just as he tried to move his hips, Akemi pleaded.

"W-wait...I'll...do it...all the way...oah...nnn!"  
"Akemi-neé, are you okay?"  
"Yeah...fine. It's bigger than I thought, so it's tough...ah, it's going in...deep!"  
"Ooh"  
"Nnaaaaaaah! M-ma, uuuuuuuu!"

When it finally went all the way in, Akemi placed both hands on Yuu's chest, trembling violently. She seemed to have a light orgasm. After a moment, she gazed at Yuu with a dazed expression.

Her naturally drooping eyes were lowered, her hazel pupils clouded with lust, cheeks flushed pink. Though her lipstick had mostly rubbed off during the blowjob, her lips remained red and wet. Witnessing Akemi's bewitching charm—rarely seen on TV—Yuu couldn't help but get excited. Moreover, just staying still made her vaginal folds tighten around his penis.

"Ahh, Akemi-neé, you're so beautiful. And your pussy feels damn good too."  
"Yuu...you're wonderful too...your penis...tingles deep in my womb. Ahh...I want more of you...mmchu!"

Saying this, Akemi brought her face close and kissed Yuu deeply before slowly starting to rock her hips. Her breasts, squeezed between her arms, faced Yuu and swayed. Without thinking, Yuu reached out with his left hand, grabbing and kneading a breast while tweaking the nipple with his fingertips.

"Anh! Good...good...feels good! My hips...can't stop...Yuu's penis...is the best!"

Seeing this, the surrounding women couldn't bear it—rubbing their inner thighs together or slipping hands between their legs to touch themselves. Yuu regretted that with eleven naked beauties present, he could only attend to one at a time, but he resolved to do his best.

"Aoi-san"  
"Yes!?"

Yuu called out to Aoi, who was sitting slightly apart, watching Akemi's frenzied movements with surprise. She hadn't expected to be called. Startled, Aoi looked at Yuu with moist eyes but shyly averted her gaze. To Yuu, this gesture looked especially adorable.

"Straddle my face"  
"Huh?"

Aoi seemed not to understand, but several women grasped the meaning and looked at her enviously. Yuu didn't think much of it since he'd done this often, but for women in this world, being straddled by a younger pretty boy was a coveted yet rarely achievable scenario.

"Come quickly"  
"Aoi-san. Opportunities like this are rare. Savor it thoroughly."  
"Yeah, yeah"

Urged by both Yuu and the surrounding women, Aoi steeled herself and straddled Yuu with her long legs. At Yuu's request, she faced away from the vigorously hip-thrusting Akemi, looking down at Yuu as she lowered herself. Though popular with women, she'd been reserved with men and never imagined experiencing this. But looking down at Yuu's handsome face while spreading her legs and lowering her hips gave her a sinful thrill, making her unusually aroused.

"Haa, haa, haa...like this?"  
"Yeah, just like that. Ah, Aoi-san's pussy looks so delicious. I want to lick it soon."  
"Nn...ah...kyun!"

Aoi's body jerked when Yuu gave her vagina a bold deep kiss. Yuu instantly wrapped his left arm around her waist to hold her down. Then he vigorously used his tongue, licking from clitoris to vaginal opening.

"Hyah! Ah, ah, wait...I've never...known...this! Aahn! No...nn, au...I'm going crazy~~~~"  
"Hah, hah, hah...ahh! Yuu's penis...is poking...deep inside! Anh! I'm...already..."

While Aoi arched her back, Akemi hugged her from behind, rocking her hips and panting. Though Aoi had never felt sexual excitement toward men before, tonight was special—she was soaking wet, letting out adorable moans as Yuu ate her out. On Yuu's supine body, the two Wish members seemed to dance lewdly while singing of sexual pleasure.

Meanwhile, two women who'd been near Yuu's lower body had climbed onto his thighs, rubbing their crotches against him. Yuu casually extended his free right hand. Loretta—who'd been kissing Yuu but temporarily moved away when Aoi straddled him—noticed first. Seeing Yuu extend his middle finger, she quickly took his right hand and guided it to her vaginal opening.

"Anh! Yuu's finger...feels good...ohh...more...play with me!"

As Yuu's rough male finger thrust in and out of her vagina, Loretta cried out joyfully. Her soaked pussy dripped so much love juice it covered his palm. When one finger felt comfortable, Yuu scraped inside with two fingers—index and middle—making Loretta throw back her head and moan.

Meanwhile, Akemi approached her limit and rocked her hips even more violently, and Aoi—having her pussy probed by Yuu's tongue—seemed about to lose herself in unprecedented pleasure.

*(Kuuuu...I'm close too. But I want to make them both cum!)*

Though he couldn't say it aloud, Yuu realized his limit was near. He'd ejaculated three times with Takako that morning, but with ample rest, his sensitivity had returned. With Akemi's vagina tightening around him, he desperately wanted to cum inside. While diligently licking Aoi's overflowing love juice, Yuu thrust upward in sync with Akemi's movements.

"Kwaa! Aaaah...ahhin! I'm...cumming! Ge-n-kai...cumming! Cumming cumming cuuuuming!"  
"Fua...ah, nn, nn...nnnnnnnnnnnnnnnnn!  
Ranka...my body...doesn't feel like my own...ahh! Yu...u!"  
"Aoi-han, ihe..."

Yuu sucked and nibbled Aoi's swollen, engorged clitoris while thrusting upward.

"Aaaaaaaaaaahhhhhhhhhh—!"  
"Cumminggggggggggg—!!!"  
"Nmo! Oemo!"

When Aoi arched back intensely and Akemi hugged her tightly from behind while grinding to climax, Yuu also reached his limit. Thick spurts of semen poured forcefully into Akemi's womb through her cervix. Unable to withstand this hot torrent, Akemi cried out.

"Haa, haa, haa...ahhn! J-just...I just...came...oh...oh...amazing...so much...semen...coming...ahhaa...happy..."

Though he'd drunk the special beverage earlier, Yuu's sexual desire didn't diminish after ejaculating—if anything, his inner lust burned fiercer. Noticing this, the surrounding women moved the limp Akemi aside, laying her on a nearby mat. Meanwhile, Yuu sat up and tried to shift Aoi to a face-to-face sitting position. His right hand continued fingering Loretta.

"Yuu! Yuu! Oh!....Yes! Yes! I’m come on! Come on! Ah...love you! Ohoooooooooooooooo! ! Come ooooooooooooooooooooon!!!"

Loretta—red hair disheveled—shouted in English, clearly close to orgasm.

"Loretta, let's kiss. Cum while kissing."  
"Un...Yuu...Feel good...nnaaah! O, o, nnnnnnnnnnnnnnnnn—!!!"

Satisfied to see Loretta cum while squirting, Yuu looked at Aoi, whom he still held.

"Next is Aoi-san"  
"Hweh?"

Fresh from her first orgasm and mentally absent, Aoi didn't process the words. Her barely-there breasts were at Yuu's eye level due to her height. He took the small red buds—like early spring buds peeking through snow—into his mouth, sucking them while wrapping an arm around her waist to lower her.

"Hii! Anh! Yu, Yuu...there...I'm sensitive...ah, ah, nooo"  
"Hehe, Aoi-san seems sensitive. How about your lower mouth?"  
"Eh!? Eeeeeeeeeeh—!"

Apparently, Aoi hadn't been thinking straight, believing they were just embracing. Startled to feel Yuu's penis poking her crotch.

"I'll insert it like this, okay?"  
"W-with someone like me?"  
"Yeah. I want Aoi-san's virginity."  
"Ah...unbelievable"

Though she looked sharp and dignified on TV in male attire, Aoi now gazed at Yuu with an intensely seductive expression. Yuu remembered her toned, lean body from playing ball at Sazanami Pool. But as he stroked her back and buttocks, he found them supple yet soft—a different charm from Akemi's.

"I can't wait anymore. I'm putting it in."  
"Eh...ah...m-my mental preparation..."

Ignoring Aoi's fluster, Yuu positioned his penis at her vaginal entrance. Upon contact, he felt warmth and wetness with a squishy sound, but entry was immediately blocked. Aoi's tightness alone couldn't take it in, so when Yuu pushed with the hands on her back and hips, he felt the hymen tear. But immediately, hard vaginal walls blocked further entry while tightening around him.

"Ku...tight..."  
"Vuwa...higi...it hurts...auuuuuu"  
"Sorry. Bear with it a little."  
"I-it's okay. Fine. Come..."  
"Aoi-san!"

When Yuu looked up, Aoi met his gaze with tear-filled eyes. Captivated anew by her beauty, Yuu pulled her close for a kiss. Wide-eyed with surprise, Aoi seemed intoxicated by her first kiss—her furrowed brow smoothed, replaced by a blissful expression. While repeatedly changing angles during the kiss, Yuu continued small thrusts.

"Nmu! Vo!"  
"Vwa! I...kuaaaaah"

Occasionally moaning and breaking the kiss, they immediately rejoined lips, even tangling tongues. Meanwhile, Yuu's penis successfully invaded Aoi's depths with a deep thrust.

"Ooh...Aoi-san's inside...so tight...but...feels amazing!"  
"Hahi, hahi...th-this deep...inside me...u...guu..."

The vagina accepting a man for the first time tightly squeezed Yuu's penis. But it wasn't just tightness. Though not overtly expressed, as if channeling Aoi's feelings for Yuu, her vaginal folds rippled and stroked him. Virginity always brought supreme pleasure no matter how many he experienced. Though he'd just ejaculated with Akemi, Yuu already felt another orgasm building.

"U, moving now?"  
"W-wait a sec"  
"Not okay?"  
"It's...not that"  
"Then why?"

Aoi shyly averted her eyes. Though she must feel pain from losing her virginity, stronger emotions seemed to sway her.

"I want to feel Aoi-san more"  
"B-but, more than this...that is..."  
"Tell me?"  
"I'm scared...of what might happen"  
"Hehe. Once the pain fades, it'll feel good, right? Don't worry, leave it to me"  
"Yu, Yuu? Aahn! W-wait...nnaah! Inside...something big...u, moving!"

Yuu looked up at her with concern while moving slowly. Aoi smiled down at him. Instead of answering, she lovingly hugged Yuu's head and sealed his lips with her tongue.

""""""Haaa~~~~~""""""

The surrounding women (except Akemi) sighed enviously. They'd witnessed a dreamlike virginity loss scene. Simultaneously, anxiety grew. Though Yuu declared he'd satisfy everyone, time was limited. Several women edged closer from behind and beside Yuu.

"Ah, ah, ah...nn...kuu..."

Yuu felt relieved hearing Aoi's intermittent, modest moans. But he also noticed the surrounding crowd.

"I want...Yuu soon too"  
""""Me too me too!""""  
"Everyone..."  
"Sorry. Seeing Akemi and Aoi looking so blissful, I couldn't help it"

Yuu realized: His usual one-on-one approach wouldn't work with over forty women waiting. He wanted to use his penis on everyone, especially the inexperienced.

"Okay, got it. Wait a bit longer. Aoi-san, sorry, but I'm going harder"  
"Hweh? Wai...aaaah! Yu...u...hard! Kuaaaaaaaaaah!"

Holding Aoi's waist firmly with his left arm, Yuu increased his thrusting pace. Unable to bear it, Aoi clung to him. Perfect timing—as Aoi started feeling pleasure inside, sweat, love juice, and precum mixed at their joining point, making sticky schlup-schlup sounds. Meanwhile, Yuu extended his right hand to kiss one woman, making others clamor for his lips or press against his nape and back.

"Gu...ao, Aoi-san! I'm...cumming! Ahh!"  
"Vu, o, ahhiiiiii...ra! Rani...ranka, amazing! Penis, amazingiiiiii"

Without taking much time, Yuu approached his limit—after all, he was enjoying a virgin's supreme tightness. As his climax neared and he thrust faster, Aoi moaned incoherently. Simultaneously, her deep vaginal walls rippled tightly as if unconsciously milking him. He couldn't withstand it.

"No...can't...Aoi-san...Aoi! Cumming! Inside...I'll cum!"  
"Hyai! Yuu, Yuu...aae...shorerame...rankakihyau! O...hii...n..."  
"Vu! Ooooh...ejaculating!"

When paralyzing pleasure shot through his body, Yuu reached his limit. Semen poured into Aoi's womb with force rivaling Akemi's climax. Receiving this throbbing essence inside her, Aoi clung to Yuu, chin lifted, mouth gaping wordlessly at the ceiling. Overwhelmed by unprecedented pleasure while being filled, she seemed unable to think.

*(Both Akemi-neé and Aoi-san were equally amazing...Wait. If either or both get pregnant and Wish goes on hiatus, that'd be bad...)*

But it was too late for such thoughts. It would work out somehow. For now, Yuu decided to savor being inside Aoi until his ejaculation fully subsided.

---

### Author's Afterword

The two Wish members received special treatment—consecutive creampies were the planned route.  


### Chapter Translation Notes
- Translated "チンポ" as "penis" following explicit terminology rule
- Translated "おマンコ" as "pussy" to maintain explicit sexual terminology
- Preserved honorific "-neé" for Hidaka Akemi as "Akemi-neé"
- Transliterated sound effects: "くぁっ" → "kwaa!", "ぷるぷる" → "trembling violently"
- Maintained Japanese name order: "Hidaka Akemi", "Mizuki Aoi"
- Italicized internal monologue: *(Kuuuu...I'm close too...)*
- Translated "処女卒業" literally as "lost her virginity" per euphemism rule
- Used "creampies" in afterword for "中出し" following explicit terminology rule