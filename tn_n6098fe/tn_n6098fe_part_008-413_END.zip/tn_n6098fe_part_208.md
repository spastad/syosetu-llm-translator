## 196. Dream Hot Spring Resort! ㉒ ~Unstoppable Ha~Ha~

Nearly an hour had passed since Yuu ejaculated inside Akemi and Aoi. With just over an hour left to service the remaining nine women, he had only about seven minutes per person. To proceed systematically, he had the women lie on their backs around him at the head of the bed in age order. Despite the large bed, it couldn't accommodate all nine at once, so they started with five.

"Alright, first is Moeka-neé."  
"Y-yes..."

Moeka was born from a woman Sakuya met during a trip to Tohoku. At 27, she was the oldest present but still a virgin. Clearly nervous, Yuu gently stroked her head while carefully covering her body without putting weight on her. Blushing like a maiden about to lose her virginity, Moeka looked up at Yuu with anxious eyes but seemed to relax slightly at his touch before hesitantly speaking.

"Um, Yuu?"  
"Yeah? Say anything."  
"Thank you. Well... I have a request."  
"A request?"  
"Could you... call me... your l-little..."

Moeka seemed conflicted, starting then stopping her sentence. Though pressed for time, Yuu waited silently rather than rush her.

"Please... pretend to be my older brother!"  
"Huh?"  
"Listen! My first love was a boy two years older I met at a friend's house in sixth grade. After that, I kept visiting just to see him... I'd spot him sometimes but could never speak to him. Hearing your song brought all those feelings rushing back... it made me so emotional, I just..."

"I totally get that!"  
"Me too! My eyes just teared up."  
"I remembered the boy I had a crush on all through high school."

Several women listening chimed in with similar sentiments. Encouraged, Moeka looked directly at Yuu.

"I always envied girls with brothers and wished I could lose my virginity to someone like an older brother. Hehe. Weird for a 27-year-old, right?"  
"Not weird at all!"  
"Huh...?"  
"I think it's wonderful."

First loves often remain unrequited, becoming idealized memories. Even knowing this, adults still feel pangs of nostalgia when recalling them. Yuu himself had often felt bittersweet emotions hearing songs from his teens after reincarnation. Though fortunate to have become engaged to Sayaka - his first true love in this world - he knew most women here would never see their first loves fulfilled. He was touched they'd connected with his song and wanted to grant this small wish.

"Okay. I'll play Moeka-neé's brother and take your virginity."  
"R-really? Truly?"  
"Truly. Ready? Close your eyes with me and we'll start after three seconds."  
"Ah... yes!"

Yuu sat up and took Moeka's hand. Her eyes shining at the unexpected development, Moeka nodded eagerly and closed her eyes.

"Moeka!"  
"B-big brother?!"

Though eleven years Yuu's senior, Moeka's short bob and cherubic face made her seem younger. Now playing an older brother unable to suppress his lust for his biological sister after pinning her to the bed, Yuu embraced the role.

"I... I've... loved you for so long!"  
"Eeh? B-but... we're siblings!"  
"I know. Since Mom and Dad were always away, we were so close growing up. I cherished you as a sister. But somewhere along the way... I started loving you not as a sister, but as a woman! I can't... hold back these feelings anymore!"  
"Ahhn!"

Feeling Yuu's warmth covering her, Moeka's cheeks relaxed as she nearly broke character. Her heart raced, cheeks flushed, and eyes grew moist. She wanted to voice the confession she'd locked away but struggled to form the words.

"A-ah... I'm... so happy... I-I feel the same! I love you! I've always loved you, big brotherrrrrrraaaaaaahhhhn!"  
"Moeka... I'm glad. Our feelings are mutual."

Yuu gently stroked the sobbing Moeka's head, smiled, and licked the tears trailing down her cheeks. They kissed - repeatedly. When Yuu slipped his tongue in during a deep kiss, Moeka flinched but accepted it, tangling her tongue with his.

A string of saliva stretched between their lips when they parted, retracting into Moeka's open mouth. Yuu gazed at the soft breasts pressing against him - ample F-cup mounds that jiggled voluptuously with Moeka's slightest movement. He grabbed and kneaded one.

"Ahhn! B-big brother?"  
"Seeing this sexy body every day... I can't let anyone else have you. I want you to be mine alone..."  
"Okay... losing my virginity to big brother... I've always dreamed of it. Please, big brother... make me a woman!"  
"Of course. Oh my... already this wet? What a naughty sister."  
"Tease! It's because I love you so much!"

Her pussy was already dripping wet just from Yuu positioning his cock against it. With no time for foreplay, Yuu pushed inside.

"Guh! Moeka's pussy... so tight!"  
"Ugh... big brother's cock... so big!"  
"Does it hurt?"  
"Just a little. But I'm okay! Come on, big brother!"

With no time to ease her in, Yuu thrust forcefully into the 27-year-old virgin pussy. Fortunately, her hymen was already broken. He pumped against the tight vaginal walls, the intense friction making him approach climax faster than expected. Struggling to hold back, he continued thrusting until hitting her cervix.

"Aaaun! Big brother's cock... reached deeeep inside..."  
"Ahh... feels amazing inside Moeka!"  
"Feeling big brother's huge cock inside me... I'm overwhelmed... ahhn, so happy!"

Moeka squirted with a *pishi pishi* sound, crying out in ecstasy. Relieved her pleasure outweighed the pain, Yuu began moving slowly.

But glancing at the clock, Yuu realized five minutes had already passed. Trying not to alert Moeka, he held her with his left arm while thrusting shallowly with his hips. Meanwhile, he noticed the woman to his right watching enviously while rubbing her thighs together. Like Moeka, the three guest members in their late twenties were all virgins. Yuu slid his hand along her thigh toward her inner thigh, and her expression brightened when she noticed.

"Ah."  
"Hehe, already this wet? Just wait a little longer."  
"Okay, got it."

"Ah... ahhn! I-it feels... so good... ahhn! Big brother's cock... feels amazing!"

Moeka seemed fully immersed in the sibling roleplay, wrapping both arms around Yuu's back. Her expression looked genuinely happy. Though feeling guilty, Yuu remembered the next woman waiting and whispered in Moeka's ear.

"Sorry. Time's up."  
"Ah..."

Moeka briefly looked disappointed but pulled Yuu's head down for a kiss, then smiled.

"Thank you, Yuu-oniichan, for being my first."  
"You're welcome."

When Yuu slowly pulled his cock out, thick fluid stretched between his shaft and her pussy as if reluctant to part.

The brother-sister roleplay with Moeka had clearly sparked envy. The remaining eight women eagerly requested roleplays of their own. Yuu gladly agreed - this was far more engaging than mechanical sex.

The next guest member requested a sister-brother scenario, secretly jealous of how close Yuu was with his sisters. Yuu lasted seven minutes with the second woman, but when taking the third guest member Naoko's (26) virginity, an electric shock of pleasure shot through his lower body, making restraint impossible.

"Kuh... hah... can't... hold back... gonna cum! Aaah! Naoko-neéchan's... inside feels too good! I can't hold on... ugh, sorry..."

Though he'd just entered her, Naoko wasn't upset. If anything, she was thrilled to see Yuu's desperate expression. With so many women present, getting creampied was lucky. As Yuu accelerated his thrusts for release, Naoko hugged him lovingly, moaning in response.

"Hah, hah, it's... okay. Cum... inside me! Ah, ah, so rough... feels good! Yuu... I'll... take it all!"  
"But... you might get pregnant..."  
"Ahhn, ahhn! It's fine! Don't worry, cum inside meeeee... ahhn! I... ahhn! Want... Yuu's baby... inside meeeeeee!"  
"Guh! Naoko... neéé... aaah!"

Amid rhythmic *pashin pashin* slapping sounds, Yuu neared climax. Staring at Naoko - hair disheveled, forehead glistening with sweat, back arching - he kissed her while whispering and released his seed. Having endured three virgin pussies, his third ejaculation was copious. Naoko screamed in ecstatic pleasure as wave after wave of spasms pushed her over the edge.

Yuu continued with various improvisational scenarios: step-siblings reuniting as classmates, cohabiting siblings consummating their feelings. Since Yuu was on top, most scenarios involved him playing a younger boy seducing an older girl. Finally, it was Loretta's turn - the youngest. Having run over time, only about two minutes remained. Breathing heavily, Yuu sat on the adjacent mat rather than the bed when Loretta approached with lust-glazed eyes, having pleasured herself while waiting.

"Waited so long, Yuu."  
"Sorry for making you wait."  
"It's fine. Stay like that. Nn..."

Loretta straddled Yuu as he leaned against the bed frame, gently stroking his head while kissing him. Lifting her hips, she guided his still-erect cock to her entrance.

"By the way, what scenario do you want?"  
"Fufu. Like this... I want you... *chu-paa*!"  
"Nn... oh! Uoh!"

As Loretta's tongue invaded Yuu's mouth, his cock penetrated her. Though not their first time, Yuu's size seemed to exceed Loretta's expectations, requiring slow insertion.

"Ngaaah! Th-this... ahhn! Oh... bigcock!"  
"Kuuu! Don't... squeeze so hard... dangerous... nn!? Nmo!"

When Yuu hit her deepest point, Loretta instinctively hugged him tightly. Yuu's face buried in her large breasts - blissful but muffling his moan.

"Nn, nchu... chu, chu-paa... ah, ah, ahhn! Unm... lero, leroleroo... juu! Chu, nn~~~ Yuu, Love you... oh! Oh! Noh!"  
*(S-she's milking me dry...)*

Though she'd already orgasmed once from fingering, Loretta unleashed an hour's pent-up desire. She alternated between kissing Yuu deeply, showering his face with kisses, and licking everywhere while vigorously riding him - like a bitch in heat.

Her wavy red hair whipped wildly with each hip movement. Yuu occasionally combed it with his hand while groping and kneading her bouncing breasts with the other.

"Puhah! Aaah! L-Loretta's pussy feels... amazing too! Kuuaah!"  
"Aah, aaaaaaaaahhhhhhhhhhh! I'm commiiing... oh! Oh! Ohhn! Oh my god... I don't know such fuck... hiiiiiiiiin!"  
"Loretta... I'm close too... let's cum together?"

Loretta's fierce riding and milking contractions made Yuu's climax surge rapidly. Looking up at her desperate face, he saw Loretta - tongue out, panting - gazing back with intoxicated eyes. She too was on the verge.

"Aah~~ Yu... uu... Oh yes! Yes! Yeeeeeeeeees! Great! Excellent! I'm coming Comiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiing!!!"  
"Guh! Aah, aah, aah! I'm cummming! Uuuuh!"

Clutching each other tightly, Yuu released his fourth load of the night into Loretta. With one final upward thrust timed to her climax, they came simultaneously.

---

### Author's Afterword

I guess it's natural for one's native language to come out when excited. I wrote this based on memories of a foreign AV I saw long ago and by looking up dirty words online. Compared to Japanese, the vocabulary seems limited - probably just my lack of knowledge.

### Chapter Translation Notes
- Translated "お兄ちゃん" as "big brother" and "お姉ちゃん" as "big sister" to preserve roleplay context
- Rendered explicit terms literally: "チンポ" → "cock", "おマンコ" → "pussy", "射精" → "ejaculate"
- Preserved Japanese honorific "-neé" for older sister figures
- Translated Loretta's mixed Japanese-English dialogue fully, correcting "Oh my good" to "Oh my god"
- Transliterated sound effects (e.g., "pishi pishi" for ぷしぷし)
- Maintained original name order for Japanese characters (e.g., Mitane Moeka)