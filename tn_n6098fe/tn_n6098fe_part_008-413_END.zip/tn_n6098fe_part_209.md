## 197. Dream Hot Spring Resort! ㉓ ~Unchanging Love Anytime~

With each group scheduled for 2 hours including 15-minute breaks, the next 11 women arrived precisely at 1:15 AM as the date changed, opening the door.

They carried great expectations while simultaneously fearing Yuu might have collapsed, but their predictions were betrayed in another sense.

The first thing they felt upon entering was the mwaah of women's sweat and body odor, mixed with the chestnut blossom-like scent of semen. Women lay collapsed with blissful expressions, some masturbating in the aroused atmosphere, others like Akemi and Aoi embracing and kissing each other. But most gazes concentrated on one point: Yuu and Loretta locked in embrace.

"Ah! It's already this late!"

Comparing the newly arrived women with the clock, Yuu panicked. Persuading Loretta who clung to him, he pulled out his cock as he separated from her body, a white, sticky drip-drip of fluid stretching out.

"Come on! Everyone, evacuate!"

While the newly arrived women stood frozen with stunned expressions, eyes glued to Yuu's cock in silent suspension, Moeka's voice prompted the first group to scramble into action.

"Sorry. Just 10 minutes rest. Though delayed, I'll properly take 2 hours."

Yuu smiled at the new group as he spoke. The thing at his groin glistened wetly after being pulled from the vagina, still standing erect without weakening. Women whose eyes darted frantically between Yuu's face and groin could only nod gokun gokun without uttering words.

Yuu hurriedly drank fluids while naked, downing his second special drink. After using the toilet, he wiped his body roughly with a damp towel. During this, the first group's women waved goodbye to Yuu and left. Though he'd ejaculated 4 times in the first 2 hours, his stamina and virility still seemed ample. Intending to fully enjoy the next women at this pace, Yuu approached the women standing idly near the bed.

The second group consisted mostly of guest members including Michiko and Miyako who played together in the pool, and Riyoko the meal team leader - two-thirds were guests. Moreover, over half were in their late 20s to early 30s, a slightly older age group. Reflecting on the uneven time distribution with the first group, Yuu made a certain request to treat them fairly this time. Though confused by his intent, when Yuu declared he wanted sex with all of them, they obeyed with hopeful expectations.

---

Women knelt surrounding the wide king-size bed, hands on its edge. Hips, hips, hips, hips, hips lined up from near the left pillow in age order. Some had plump, childbearing hips while others had pert, well-shaped bottoms pointing upward. As Yuu instructed, everyone reached to touch their private parts, already making squelch squelch wet sounds. Some were so aroused their love juices dripped down their thighs.

"Aaah! Ah, ah, youuuuuuu! Your cooock's amazing! I'm... cumming, cummiiing! Oh, ooh! I-I'm cumming!"  
"Orie's weak here, right? No need to hold back, just cum. There there!"  
"Aah, oh... cumming, cumming... with your cock... I'm cummiiiiiiiiiiiiiiiiing!!!"

Within 5 minutes of Yuu starting piston thrusts with bachun bachun sounds against the large hips, Orie (34) climaxed early. Her request was to recreate marital intimacy moments with her ex-husband who divorced her 3 years prior.

After Orie came, Yuu covered her back, slowly scooping deep in circular motions while reaching his left hand forward to grab and knead her heavy breasts. The stray hairs dangling from her pinned-up black hair at the nape were incredibly alluring. Kissing her neck, Yuu whispered love while praising her charm. Overwhelmed, Orie turned with tearful eyes and exchanged kisses with Yuu until time ran out.

Pulling his cock from Orie's vagina, Yuu shifted right. Miyako already faced Yuu, face flushed with expectation, breathing heavily. While enjoying Orie's vagina, Yuu had reached to touch Miyako - her pussy was thoroughly drenched.

"So, Miyako-san, what scenario do you want?"

The second group was told to request preferred scenarios. Though limited by Yuu's doggy-style position.

"De... degrade me!"  
"Huh?"  
"Call me... sow or slutty pig! And spank my ass please!"  
"O-okay..."

In his previous life, Yuu heard people in strict professions like teachers or legal workers often had abnormal fetishes. Miyako probably revealed her hidden tastes here since she played the serious elite at company. Her sexual harassment toward Yuu was stage one - masochism being stage two. Though he'd mimicked spanking when taken to Saiei Academy's basement, he had no real experience. Drawing from erotic media memories of his bachelor days, he decided to act it out.

Miyako's plump, round hips shook left and right enticingly. Yuu grabbed both buttocks firmly and pulled them apart forcefully. Her pussy glistened wetly after masturbating while watching Yuu and Orie next to her.

"What a shameless pussy. Dripping like this without anything done yet. Like cow or pig drool, isn't it?"  
"Ha, hahi. I-I'm shameless... shorry..."  
"Getting like this just seeing cock? Is Miyako a slutty sow?"  
"...! Hyahii! M-Miyako is... slutty sow! M-master's big, haaard cock... j-just seeing it makes me horny, hopeless... pig! Shorry!"

Her responses were already slurred. Miyako seemed genuinely aroused by being called a pig. Her eyes darting glances at Yuu were clouded with lust, cheeks flushed with anticipation. Drool seemed ready to drip from her slack mouth. Despite being over thirty, her vaginal area was lightly pigmented, the spread-open interior vivid salmon pink. But transparent fluid overflowed endlessly from the wriggling love hole, streaming down her thighs.

"Totally troublesome sow. Want cock that badly?"  
"Aun! W-want it! Master's... cock... haa, haa... please punish this shameless sow."

When Yuu poked her ass with his rock-hard cock, Miyako writhed and pleaded. Rubbing the tip against her vaginal entrance made a nupoo sound, immediately coated with love juices.

"Hah, hah, hah... m-master... cock... cock... cooock!"  
"Only cock on your mind? Brain dyed pink, you sow!"  
"Hyaa! Cock hoohii... ughii!"

With just a slight forward thrust, the glans slid in effortlessly. Though immediately blocked by a firm barrier inside, Yuu forced through and continued insertion.

"Oooooooh! Raah!? Iiaah! Aah, aah... cock, entering... kuryu! Ohoh! This is... master's... cock... u, happy... nyau! Amazing! Deeep... pyahhhhhh... uun! Noh!"  
"Kuh! Shameless... for a sow... tightening inside (inside)!"

Miyako's virgin vagina tightly constricted Yuu's cock. He stopped moving and instead swung his hand to spank her ass.

Whack! Whack! Whackiiin!  
"Gyaah! Aahn! Hiiin!"

Arching back, Miyako cried out more in pleasure than pain. Simultaneously, she squirted pishaaa extravagantly. As a long-time virgin, this must have been her wish. Though barely moved after insertion, she seemed near climax.

Glancing right, Yuu saw Michiko and others watching his doggy-style penetration while fingering themselves squelch squelch. He grabbed Michiko's ass with his right hand, making her moan happily. While fingering the thoroughly wet Michiko, he slowly began moving his hips.

---

Naturally, with 4 ejaculations already, the time until next climax lengthened. Normally he couldn't last with virgins, but the 10-minute time limit made him endure despite making Orie and Miyako climax consecutively. But upon penetrating Michiko and reaching deep, Yuu was hit by hip-trembling pleasure and nearly came.

"Kuh... oh... ch-chief's p-pussy... dangerously good..."  
"H-Hirose-kun's cock... so... b-big... d-deep inside... ah, ah... amazing, this is sex... aaah, like a dream"

Michiko requested a same-company female boss and male new employee scenario. Though rare for men to be assigned to female-dominated workplaces, she must have fantasized about it. The situation involved two people becoming intimate during late-night overtime at the office.

"I... can't hold back! Ahh! Feels good!"  
"Nngh! I-I always teach you, right? Impatience is... n-no good... ahhn! M-must... carefully... fulfill client... requests... aaahn!"

Yuu reached his right hand to grope another guest member's ass while gradually inserting fingers, his left hand crawling up Michiko's beautiful back. Not wanting to climax immediately and disappoint her, he stopped moving. Michiko's deep vagina wrapped around Yuu's cock near the base, her flesh folds stimulating him. Even without movement, pleasure intensified. So while enjoying the thirty-year-old virgin's vagina, Yuu used his left hand to caress her. After tracing her nape covered by short black hair, he moved forward to knead her voluminous breasts.

"Ahh... happy to connect with chief like this. I'll move now."  
"Y-yes... c-come... ah... Hirose-kun... I'll... r-receive... everything... ahn! Give it... aaahn! Akuu! So... amazing!"

Each thrust definitely heightened his ejaculation urge. Already counting down to the limit, Yuu decided to release inside Michiko. Sensing Yuu's impending climax, her moans heightened with each hip thrust, hair disheveled in ecstasy.

"I... can't hold back! I'll ejaculate like this... and impregnate chief!"  
"I-it's ok. Ahn! Give me your seeeemen! Ah... aaaaaah! I'm cumming too..."  
"Guh... hah... c-cumming!"

Yuu finished wildly, thrusting bachun bachun while clutching Michiko's breasts. His 5th ejaculation unexpectedly produced copious semen flooding her womb. At age thirty, her first sex and creampie. Climaxing simultaneously, Michiko exposed her ahegao face without caring about being watched across the bed, overwhelmed with bliss.

---

Yuu penetrated from behind the women surrounding the bed, mating with each in rotation. As 2 hours approached when he ejaculated into the 11th woman, Yuu was gasping for breath. Panicked women nursed him, though his expression showed complete satisfaction.

---

After downing his third drink, Yuu still felt lingering fatigue when welcoming the third group of 11 women. He'd probably overexerted early on - 7 ejaculations while servicing 22 women in one night was superhuman. Yet libido and virility remained. Surrounded by naked women on bed taking turns kissing and pressing against him, his cock swelled mukumuku.

So Yuu lay supine, setting time per woman and letting them take charge - essentially reverse gangbang play.

While one rode him, Yuu simultaneously pleasured three others with hands and mouth. For 2 hours uninterrupted, multiple moans echoed continuously.

### Chapter Translation Notes
- Translated "栗の花" as "chestnut blossom" to accurately convey the distinct semen smell descriptor
- Preserved Japanese roleplay terms like "ご主人様" as "master" to maintain degradation context
- Translated "アヘ顔" as "ahegao face" retaining the ecstatic facial expression trope
- Used explicit anatomical terms ("pussy," "cock," "cum") per style guidelines
- Transliterated sound effects (e.g., "bachun bachun" for ばちゅんばちゅん)
- Maintained Japanese name order and honorifics (-san) throughout
- Rendered internal monologues in italics without attribution markers