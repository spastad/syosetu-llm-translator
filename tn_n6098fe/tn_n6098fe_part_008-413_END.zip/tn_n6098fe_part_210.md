## 198. Dream Hot Spring Resort! ㉔ ~NEVER CHANGE~

### Author's Preface

This long night is finally coming to an end. Even Yuu has reached his limit. And then, Yuu's first anal experience...

---

Yuu seemed to have lost consciousness for a while.

When he came to, he was surrounded by women just like when he last ejaculated, but the members had changed. It was the final group including Takako and Satsuki.

Mana and Rina were looking at him worriedly. Shizuka and her two friends were also there. That everyone was still dressed was probably because they had rushed over, concerned about Yuu lying motionless on his back on the bed.

He vaguely remembered exchanging farewells with the previous group, but it wasn't clear in his memory - he seemed to have fallen asleep without realizing it.

"Ah...re...?"

"You seem to have come to."

"Yuu, good work."

"...! Sorry! I..."

"It's fine. You pushed yourself all alone."

As Takako and Satsuki gently stroked his head and cheeks from both sides, Yuu felt like melting into their care. But when he tried to move his body, it felt heavy as if filled with lead.

Understanding his intention, Satsuki and Takako not only helped him sit up but also placed a pillow around his waist for comfort.

"Muu... Feels like I'm being nursed."

"I don't mind at all with you, Yuu."

"That's right. I'm happy to take care of you. Fufu."

"Yeah. Being cared for by beauties is nice too."

Over half of the final group were women Yuu had already been with by the third day. Fujiki Hiromi, a foundation employee, was also included at Yuu's request.

The remaining three had arrived late last night, hence being placed in the final group. So he hadn't even conversed much with them.

"I want to be with Hiromi-san too."

""""Eh!?"""

"Please don't push yourself. I'm just honored to be called by Yu-sama."

"No. I genuinely want to have sex. I might look like this but I'm greedy - being on the same bed with attractive women and not touching them feels wrong."

"Ah...th-that is..."

According to what he'd heard, 26-year-old Hiromi had been married for only about a year. When Yuu first met her, she gave the impression of a cool, capable adult woman. She was a slender-faced beauty with long black hair reaching mid-back that suited her well.

Through several meetings over nearly three months as the foundation's contact person, she'd grown familiar, leaving a deep impression as a kind, caring older sister. However, until now she had prioritized foundation work and maintained some distance from Yuu.

But the middle-aged man within Yuu was drawn to the term "newlywed," and seeing her in a revealing negligee up close made his heart race.

The remaining three were all young women around 20 years old. Having just arrived, they'd had almost no chance to interact with Yuu. But having fallen for him at first sight when hearing him sing, they undoubtedly wanted to be with him too.

"Come to think of it, I haven't drunk anything since finishing. Hey, I have a favor to ask."

No woman could refuse when Yuu asked like that.

"Yes. Here you go."

"Mm, thank you."

"Say... I want you to feed me. Directly."

"Huh?"

It was a sports drink can brought from the refrigerator, but before taking it, Yuu smiled mischievously. Unlike Hiromi who didn't immediately understand, Satsuki demonstrated by taking the can and opening it.

Placing a hand on Yuu's shoulder, she took a sip and without swallowing, kissed Yuu directly on the mouth - a mouth-to-mouth transfer.

After swallowing with a gulp, Yuu extended his tongue into Satsuki's mouth to savor the taste.

"*Lecho...churu, chupuu... Ahh, delicious!*"

"*Nfu. I'm glad. Now, Hiromi-san, you feed him too.*"

Feeding a man mouth-to-mouth was an event that would hardly ever happen in reality - at most seen in adult videos or erotic manga. Probably because men would dislike it. Even married Hiromi had never done such a thing with her husband and was frozen wide-eyed.

"Still not enough. Won't Hiromi-san feed me?"

"N-no! Th-th-that kind of thing..."

After Satsuki stepped aside, when Yuu spoke with a slight pout, Hiromi flusteredly responded. Handed the can, Hiromi hesitated with wavering eyes but resolved herself saying "Th-then" and leaned in.

Placing a hand on naked Yuu's shoulder, she took a sip of the sports drink. Yuu waited with his mouth slightly open.

"*Nn...*"

Their lips met, and the liquid flowed into Yuu's mouth. Though a little spilled from the corner, Yuu managed to raise his heavy-feeling right hand and reached around Hiromi's back as she successfully fed him mouth-to-mouth.

While savoring the remaining liquid in Hiromi's mouth with his tongue, he intertwined their tongues.

"*Nfe!? V...amu...ero, lerooo...nmuaa...afu*"

Before long, Hiromi's hands also wrapped around Yuu's back, and they embraced passionately while deeply kissing. When their lips parted, a string of drool stretched between them.

"Thank you. It was delicious."

"Hy-hyai. Ah, um...y-you're...welcome."

Suddenly sharing an intense deep kiss with Yuu, married Hiromi showed a maidenly shyness that Yuu found adorable.

Afterwards, he had the remaining three feed him mouth-to-mouth in succession. Finally, he downed the special drink handed by Takako in one gulp.

Hiromi and the other four remained flushed as if feverish, snuggling close to Yuu. Everyone smelled nice after bathing, and their light clothing exposed large areas of skin.

So his crotch stirred in response, his cock rising like a rearing snake.

"Araa, splendidly revived, isn't it?"

"Well. Surrounded by beauties like this."

""""......""""

Satsuki happily pointed it out and Yuu smiled bashfully. Meanwhile, Hiromi and the others seemed speechless watching the cock gradually enlarge.

"Umm, by any chance, is this your first time seeing a man's cock, except Hiromi-san?"

"Y-yes."

"Mm..."

"Only in magazines or videos."

"Me too."

"W-wait! I didn't know they could be this big!"

The three virgins were astonished, but even experienced Hiromi seemed surprised by the unexpected size, covering her mouth with her hand while staring intently.

"Then, why not touch it since we're here?"

"Is it okay?"

"Of course!"

At Yuu's words, they split into two on each side and timidly reached out their hands.

"I-it's amazing! Does it really get this big?"

"The tip is smooth, but the middle is rough... plus it's so hot and hard."

"*Fufu. Yuu's is special.*"

"Exactly. Having this inserted down there feels so gooood."

"I've lost count of how many times I came."

"I even lost consciousness."

While Hiromi and the other four touched and stroked with unskilled fingers, Satsuki, Takako, Mana, Rina, and even Shizuka joined in, freely discussing its merits. Satsuki and Takako even advised on stroking techniques.

Thanks to that, Yuu's pleasure intensified. In return, Yuu extended his hands left and right to touch their buttocks and thighs repeatedly. Whether due to the special drink's effect, Yuu's recovered libido showed no signs of waning.

"Ahh, I can't hold back anymore. I-I want sex!"

""""Se...sex!?"""

"Yuu has regained his energy too, so perfect timing. I think taking turns would be fine."

The experienced Satsuki and others yielded to Hiromi's group of four, deciding they would take turns riding Yuu.

---

"Haa, haa...a-as expected...it's tough..."

"Really, Yuu, you're pushing too hard."

"That's right. The special drink maintaining your libido and stamina backfired."

"B-but...everyone's cute and it felt...good."

Putting aside married Hiromi, the other three were virgins, and Yuu genuinely wanted to support them. Their vaginal tightness due to virginity made things frustrating with their awkward movements. But seeing them overcome the pain while visibly moved by being connected to him, Yuu felt motivated as a man to try harder.

So Yuu mustered his strength to thrust upward. As a result, after ejaculating twice for the four women, he was left gasping for breath. Even getting erect was painful now, yet Yuu persisted - driven by the male instinct to penetrate the virgins he'd joined with for the first time, to make them "women," and to release his seed.

The price was that Yuu's hips finally gave out completely. Satsuki, Takako, Mana, and Rina carried him into the attached bathroom.

After servicing 37 women over three rounds with two-hour breaks - wiping himself during the first two breaks - he was drenched in sweat, drool, and love juice. Though the women never showed discomfort, he certainly smelled.

The four soaped him up all over - Satsuki in front, Takako behind, Mana on the right, Rina on the left.

"How is it? Yuu, feeling good?"

"Yeah. Feels really good, Satsuki-nee."

"I'll massage you while washing to loosen you up."

"*Hyaa!* T-ticklish, Takako!"

"Ahh, washing a boy's body like this makes my heart race, doesn't it, Rina?"

"U...un."

Satsuki washed from his toes to thighs. Takako washed his back while massaging his shoulders and waist. Mana and Rina handled both arms up to the shoulders and neck. Without moving a hand himself, Yuu was being diligently washed by four naked beauties - like royalty of ancient times. Normally, Yuu's male part would react immediately but...

"Has he finally run out of seed?"

"His cock is staying quiet."

As Satsuki observed his unsoaped crotch and Takako peeked from behind, it remained docile.

"Uun, it definitely feels amazing though..."

"Yuu, how many times did you ejaculate tonight?"

"Umm, over ten times. Eleven just now, I think."

At Mana's question, Yuu answered after brief thought. It was his first time exceeding ten times in one night. Hearing this, the four rapidly shifted expressions between surprise, disbelief, and amazement.

Only Takako brought her mouth close to Yuu's ear and whispered softly.

"You surpassed Father."

"R-really..."

"Surely you can't manage once more?"

"W-well, maybe?"

As Takako pressed her breasts against his back, she ran fingers over Yuu's chest and kissed his nape. Seeing this, Satsuki grinned and began caressing his inner thighs up to the groin with both hands. Mana signaled Rina with her eyes, and the sisters sandwiched Yuu's arms between their breasts, rubbing up and down.

Without touching his crotch, their body caresses drew an involuntary sigh from Yuu.

"*Ohh...* Amazing, feels good. Like I'm in heaven."

"Glad you think so. We're happy too. Hey, Yuu..."

Mana smiled, bringing her face close, hair tied back from her forehead. Having had no contact with Yuu since the first night, she seemed delighted by the luck of sharing a bath at the end.

While being caressed from all sides, Yuu kissed Mana. Immediately their tongues intertwined noisily.

"*Aahn, not just Onee-chan, me too!*"

Rina, who could barely converse at their first meeting, now openly expressed desire after joining bodies once, pleading with Yuu.

After deep kissing Mana for about a minute, Yuu turned to Rina. With long black hair tied up and fair skin flushed pink, Rina exuded innocent sensuality. Moreover, his left arm was buried deep in her ample cleavage, conveying their softness.

"Rina-nee... stick out your tongue."

"*Fai...nn*"

As Yuu deeply kissed his half-sisters consecutively, the embers of desire within him flared up intensely. But whether having spent all his seed, his lower body remained unresponsive.

"Then, how about stimulating this?"

Takako murmured as if to herself, positioning Yuu's hips backward with both hands around his waist. Feeling her hands crawl down his back toward his buttocks, Yuu had a bad premonition. But before he could voice his question, his mouth was covered by Satsuki.

"*Aee... stop...*"

"Yuu, relax. You three, make Yuu feel even better."

""""Haaai!""""

While Satsuki and the others intensified their body caresses, Takako meticulously loosened the area around Yuu's anus using soap. Crouching for a better view, she slowly inserted her straightened index finger, knuckle up.

"*Vaa!*"

Held firmly front and sides with no strength to resist, Yuu accepted his first anal penetration at Takako's mercy. He felt almost no pain - rather a pleasure similar to defecating. But when Takako inserted past the second knuckle and bent it toward his abdomen - toward the prostate - an unknown pleasure shot through him from his buttocks rather than crotch. With a crumbling sensation in his hips, Yuu's mind went blank.

"*Ngaaa! Aa, aa, what is... this!? Hyuu! O, o, oou!*"

Tilting his chin up, Yuu moaned in a girlish voice. Hearing this up close, Rina trembled with ecstatic shivers, coming while rubbing Yuu's arm with her breasts. Meanwhile, Satsuki felt something hard and hot pressing against her lower abdomen.

"He's hard! *Aahn*, incredible!"

"Ahh... Yuu!"

Mana immediately reached out with her right hand. Rina, still trembling from orgasm, also reached out with her left. Of course, Satsuki was first to lovingly stroke it with both hands. Takako continued prostate stimulation, her finger still inserted, going "*ton ton*".

"*Kwaaaaaa!* No! *Au...* I can't hold back!"

His soap-lathered cock leaked precum, wetting Satsuki's lower abdomen under three pairs of hands. Combined with the stimulation from behind and slippery sensation, it brought Yuu tremendous pleasure.

"Yuu's cock... twitching!"

"*Aha.* Yuu, cute. *Chu.*"

"You can come. *Nchu.*"

"*Ikuu... I...ku... vaa! Aa!*"

Kissed from both sides by Mana and Rina, Yuu screamed as he reached his limit. Liquid shot out powerfully, drenching Satsuki's chest positioned in front.

"*Ahhaan!*"

More transparent than white now, Satsuki let out a heated sigh as the forceful semen hit her several times.

Afterward, Yuu remained dazed as they rinsed him under the shower. Upon exiting, Shizuka and her two friends waited with towels for the handover. While Tamaki firmly supported Yuu's body, Shizuka and Sumie wiped him thoroughly before leading him to bed. Yuu's memory lasted only until there - surrounded by Hiromi and the other four he'd been with on the bed, exchanging kisses until he lost consciousness.

---

### Author's Afterword

☆Third Day's Results

Tsutsui Takako (33)... Director. Actress. Sakuya's last lover. Has child.  
Hidaka Akemi (21)... Half-sister. Popular duo Hidaka Akane.  
Mizuki Aoi (21)... Guest member. Popular duo Mizuki Aoi. ※Virgin  
Moeka (27)... Half-sister. ※Virgin  
Naoko (26)... Guest member. ※Virgin  
Loretta (18)... Half-sister. High school student from San Francisco.  
Orie (34)... Guest member. Divorced.  
Michiko (30)... Guest member. Employee of Mitsuba Construction. ※Virgin  
Miyako (30)... Guest member. Employee of Mitsuba Electric. ※Virgin  
Riyoko (27)... Guest member. Employee of Mitsuba Products. ※Virgin  
Fujiki Hiromi (26)... Foundation staff. Married.  
Others  
Total: 44 women.  


### Chapter Translation Notes
- Translated "口移し" as "mouth-to-mouth transfer" to convey the intimate feeding method while maintaining erotic nuance
- Rendered explicit sexual terminology directly: "チンポ" → "cock", "アナル" → "anal", "前立腺" → "prostate"
- Preserved Japanese honorifics: "-san", "-nee" (for elder sisters), "-sama" (honorific)
- Maintained original name order: "Fujiki Hiromi" (藤木 宏美) instead of Western order
- Transliterated sound effects: "れちょ…ちゅるっ" → "*Lecho...churu*", "ちゅぷぅ" → "*chupuu*"
- Italicized internal monologues: "（ち、近い！）" → *C-close!*
- Translated anatomical terms precisely: "お尻" → "buttocks", "膣内" → "vaginal"
- Used explicit descriptions for sexual acts per style guidelines
- Preserved cultural terms: "特製ドリンク" → "special drink" (context explains effects)
- Formatted simultaneous dialogue with double quotes: `「「…」」` → `""...""`