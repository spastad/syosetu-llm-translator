## 199. Dream Hot Spring Resort! 25 ~Summer Farewell~

"Nn... Etto... Huh? Where is everyone?"

Yuu woke up but his mind was fuzzy as he stared blankly at the ceiling.  
The daylight-colored lighting had covers, so it wasn't blinding to look at directly.  
Lately, someone had always been beside him when going to bed and waking up, so being alone now felt lonely.  

"Ah, last night was..."  

After a while, memories of last night gradually returned.  
Eleven women at a time, divided into four groups, had passionately joined him in the Special Room.  
Their flushed skin, warmth and scent, moans and sighs, the feel of soft breasts and buttocks, the pleasure of penetrating their drenched vaginas and ejaculating inside - all came back vividly.  

"Forty-four people... What an incredible night."  

As Yuu murmured to himself, he sensed someone nearby.  

"You've finally awakened."  
"After all that effort, it's only natural."  
"Ah... Touko-san? Satsuki-nee?"  

Both were already dressed properly, not in the negligees from last night.  
Touko wore a white blouse with a gray tight skirt, Satsuki a long pale purple dress - both looking completely presentable.  

"Fwaaaaa... I still feel sleepy, but what time is it?"  
"Almost noon."  
"Huh?!"  

Apparently, the last group of eleven had watched Yuu's sleeping face before drifting off one by last night.  
They left around 8 AM for breakfast. Though they'd only slept about two hours, they seemed satisfied having spent time with Yuu.  
Touko and Satsuki had periodically checked on Yuu as he continued sleeping deeply.  

"Come to think of it, I'm hungry. Should get up."  

Having slept about six hours, his mind was still foggy and fatigue lingered, but feeling hungry, Yuu sat up and threw off the towel blanket.  

"My!"  
"My, how youthful!"  
"Huh?"  

Despite last night's multiple ejaculations, their gazes fixed on Yuu's impressively erect cock.  

"Nah, this is morning wood. Physiological reaction."  
"Fufufu"  
"I can't help but be mesmerized every time I see Yuu's magnificent cock!"  

As Yuu moved to the edge of the bed, he found himself flanked by the two beauties.  
Resigned, Yuu breathed in their pleasant fragrance while reaching out to pull their waists close.  
Touko and Satsuki smiled happily, wrapping their arms around Yuu's back.  

"Satsuki-nee, Touko-san"  
""Yuu!""  

After exchanging morning greetings (kisses), their attention returned to the erect cock.  

""May we touch it?""  
"Of course"  

Though dry penises are surprisingly delicate, the two gently ran their fingers along it knowingly.  

"Ah... Nmm"  

As they touched him from glans to shaft, base, and scrotum, Yuu moaned with deep emotion.  
Touko and Satsuki took turns covering his mouth with kisses, then whispered in his ears:  

"Shall we suck it for you?"  
"You want to cum, don't you?"  
"P-please..."  

When Yuu answered breathlessly, they buried their faces in his crotch and began using their tongues.  
While their supple fingers caressed his fully erect cock, precum began dripping steadily. They competed to lick it up, unconcerned about their tongues touching.  

"Ah... Ahh, feels good"  
"Chupuu... Lero, leroo, more... Feel even better"  
"Aahn, just licking your cock makes me wet"  

Yuu stroked their backs as they rubbed their inner thighs together. He lifted their hems to reveal their panties - black for Touko, purple for Satsuki.  
Yuu slipped fingers from inner thighs to crotches, finding them already slick with moisture.  

"Ah... Noo, Yuu"  
"Right, right. We're supposed to make Yuu feel good"  

Glancing up at Yuu with mischievous smiles, Satsuki deep-throated the glans while Touko stroked the shaft and took one testicle into her mouth. Both began licking eagerly.  

"Nfuh. Aa-mu, nchuu, jupo! Jupo!"  
"Amu leroo, lero leroo... Chupa, chuu!"  
"Kwa! That's... good!"  

Their synchronized double blowjob enveloped Yuu in the sensation of semen rising powerfully from his balls.  
Though ejaculation had taken longer with each round last night, after a night's rest, his cock's sensitivity seemed restored.  
Within five minutes of their skilled, heartfelt double blowjob, Yuu sensed his limit approaching.  

"Ah, ahh! So... good! Feels... good! Kaha... Can't... I'm gonna cum"  
"Cum as much as you want!"  
"Lots, give us lots!"  
"Gu... Uuu! I'm... ejaculating!"  

Pleasure shot through Yuu from waist to back. Just as his hips seemed about to buck, thick cum gushed out. The viscous fluid struck the back of Satsuki's throat as she swallowed the glans.  

"Puhah..."  
"Kuh! Still cumming"  

The first ejaculation's force was so strong Satsuki couldn't contain the continuing flow in her mouth, dripping down the shaft.  
But Touko, waiting, thoroughly licked it up.  
Sticking out her tongue to lick every drop, she kissed the urethral opening when Satsuki pulled away to swallow the flood in her mouth, then clamped her lips to suck out the remaining semen.  

* * *  

Yuu's stomach growled loudly during the meticulous cleaning blowjob, prompting hurried preparations.  
Touko mentioned they'd saved his portion of lunch.  
After eating with Touko in the director's office, Yuu decided to bid farewell to everyone at his own request.  

First stop was Masaki and Satsuki.  
He'd heard they'd return to Tokyo once their replacements arrived.  

"Ah... Yuu! Time to say goodbye. I'm sad."  
"Tokyo and Saitama aren't far. We can meet anytime."  

Masaki patted Satsuki's shoulder as she teared up, smiling as he shook Yuu's hand. Brothers handled partings more briskly.  

"Satsuki-nee, let's meet again."  

Yuu took Satsuki's hand, but she hugged him tightly instead.  
Being taller, when she cradled his head, his face pressed against her chest. Floral sweetness enveloped him as soft, elastic mounds pushed against him.  

*(Just like when we first met)*  

Right after this thought, Yuu felt softness on his lips.  

"Yuu, we'll definitely meet again. Promise!"  

Winking, Satsuki lightly touched her abdomen.  
Working at the foundation in Tokyo, they'd have chances to meet.  
*Maybe she'll be pregnant next time*, Yuu thought.  

Next, Yuu went aboveground to bid farewell to Kousaku swimming in the pool as usual.  

"Listen, Yuu! Train your body! Muscles never betray you!"  

In this world with many tall, well-built women, embracing them would require muscles as Kousaku said.  
Plus, Yuu wanted stamina to fuck all night.  

"Muscles... Yeah. Need to train more."  
"Umu! Good attitude!"  

Yuu bumped fists with Kousaku, who'd removed his goggles after climbing out.  
Though their approaches might differ, they exchanged strong handshakes with smiles.  

* * *  

Heading to Sazanami Pool next, Yuu found Wish duo (Akemi and Aoi), half-sisters Mana and Rina, and about ten others playing energetically.  
When Yuu waved, they rushed over.  
Noticing Yuu approaching, Michiko and Miyako ran over from the gym too.  

"You came specially to say goodbye."  
"Seemed right."  
"Ah, thank you... Yuu"  

Akemi smiled cheerfully while Aoi thanked him shyly. Yuu felt happy seeing Aoi show familiarity now, unlike their first awkward meeting. He took their hands.  

"I'll be cheering for you two."  
"Fufu, happy to hear. Ah, right! Hey, Aoi?"  
"Hmm?"  

After whispering secretly, blushing Aoi told Yuu in a small voice:  
"W-would you... accept our autographed photo boards?"  
"Eh, really?"  
"Yes. We'd be happy if a boy accepted them..."  

Photo boards with popular idols' autographs were rare treasures, yet they asked if he'd accept them personally.  
Beaming, Yuu nodded.  

"Of course. I'll treasure them."  
"We did it!"  
"Glad... We'll send them through the foundation."  

Next, not just Mana and Rina but the other half-sisters and guest members present surrounded Yuu.  

"So glad I met Yuu!"  
"Memories with Yuu... my lifetime treasure!"  
"Me too!"  
"Me too, me too!"  

Surveying them, Yuu smiled.  
"I'm the one who'll never forget meeting everyone, spending nights together."  

As he shook hands saying goodbye individually, some even teared up.  

* * *  

After bidding farewell to the dozen at the pool, Yuu went underground.  
He found Shizuka and her two friends playing in the game room.  

"Ah, um... Yuu. That is..."  
"What's up?"  

Usually direct, Shizuka grew fidgety and hesitant knowing this was goodbye.  

"Here!"  
"O-oh"  

What she handed him wasn't a love letter but a memo with contact information.  

"If any trouble comes, contact me anytime. I'll use the Minatomo family's power."  
"Speaking so lightly will anger Grandmother Tazuru."  
"Muu. B-but... Yuu made me a 'woman'! I must repay this debt or I'm no woman!"  
"Th-that's... understood but"  
"Yeah! I want to repay Yuu too!"  

Yuu smiled wryly and flicked Shizuka's forehead lightly.  

"Kyau!"  
"Don't worry about that!"  
"Kya?"  

Then he crouched, wrapped both arms around Shizuka's waist, and lifted her up.  

"D-don't treat me like a child!"  
"Shizuka's a cute girl."  

Though protesting, her expression showed no displeasure. Rather, being carried and called "cute" seemed welcome.  

"Don't worry about debts. I had great times too, so we're even."  
"Un... r-right"  
"Exactly"  
"But... Yuu, I feel lonely."  

As Shizuka looked down, her twin tails drooped too. Despite everything, parting with Yuu pained her.  

"Shizuka"  
"Hmm?"  

When she looked up, Yuu kissed her lightly, their lips barely touching.  

"Goodbye isn't farewell but a promise to meet again."  
"A promise to meet again... I like that."  
"Right?"  
"Un!"  

This time Shizuka kissed him back. Pulling away smiling, she looked angelic to Yuu.  

Next, Yuu gently stroked Sumie's long hair while hugging her. She looked up at him and closed her eyes.  
When he softly kissed her thin lips, her arms tightened around his back.  
With Tamaki, he savored her voluptuous body as they kissed.  

After parting with Shizuka's group, Yuu visited the cafe & bar and other spots to say goodbye.  
Among his brothers, he met Toru but missed Takuya who'd left that morning.  
Similarly, women originally scheduled to leave yesterday had departed early.  

At 2:50 PM, Yuu headed for the B1 exit leading to the parking lot.  
Though Masaki and Satsuki were supposed to see him off, they were handing over duties to replacements.  
Touko volunteered to accompany him instead.  

Arm-in-arm like lovers, they walked slowly down the corridor.  
Touko pressed her whole body against him, the soft sensation feeling pleasant.  
Wanting to say so much but unable, Yuu glanced at her frustratedly. Meeting his eyes, she smiled.  
Her slightly upturned eyes glistened moistly - clearly she too regretted parting.  

So when the exit came into view, Yuu stopped, turned to Touko, and embraced her.  

"Yuu?"  
"Touko"  

Holding her well-shaped chin, he pressed his lips to hers.  
They kissed repeatedly - chu, chu - hugging each other tightly.  

"Touko... I want to meet again."  
"Fufu, with this age gap?"  
"Age doesn't matter. Besides, you know I'm mentally middle-aged, right?"  
"True. But if society finds out, they'll say I seduced a young boy."  
"Uun..."  

Earlier, he'd learned she was his father's last lover, and that malicious articles had accused the faded child star of forcing herself on him for fame.  
Now they might write that a famous actress was using wealth to keep a young lover.  

"But juggling acting and directing keeps me too busy for leisurely meetings."  
"Th-that's... disappointing."  
"Instead, when school starts, be nice to my daughter if you meet her."  
"Nana-chan, right? Got it."  

After one final tight hug, Touko went to the door they'd entered four days ago, held her nameplate to a sensor, and disabled the security.  

"Well then, goodbye, Yuu."  
"Un. Stay well, Touko."  

Exchanging farewells, Yuu opened the door to find Kanako and Touko waiting.  
They'd apparently arrived before the 3 PM appointment.  

"Such intense four days..."  

Muttering softly as he got in the car with the protection officers, Yuu headed home.  
His soft voice and underground tunnel noise apparently prevented Kanako and Touko from hearing.  
Touko clung to Yuu and chattered nonstop, venting frustration from three days apart.  
Kanako scolded her but kept glancing at Yuu concernedly.  
Enjoying their conversation, Yuu gradually grew drowsy and fell asleep.  

* * *  

* * *  

* * *  

* * *  

---

### Author's Afterword

Before I knew it, the hot spring resort arc reached 25 chapters.  
This concludes the main part of Chapter 5.  
After two bonus/interlude chapters, we'll move to Chapter 6.

### Chapter Translation Notes
- Translated "朝勃ち" as "morning erection" per explicit terminology rule
- Preserved Japanese honorifics (-nee, -san) and name order (Toyoda Satsuki)
- Transliterated sound effects (e.g., "ぐーっと" → "guu", "ぽーっと" → "poo")
- Translated explicit sexual terms directly ("チンポ" → "cock", "射精" → "ejaculation")
- Maintained original dialogue formatting with new paragraphs per speaker
- Italicized internal monologues like *(Just like when we first met)*
- Translated culturally specific term "色紙" as "photo boards" with contextual explanation