## 2xx. Dream Hot Spring Resort! Epilogue (Tentative)

### Author's Preface

This time, as a special epilogue, we are featuring several individuals who appeared in the hot spring resort arc.

The (Tentative) designation is because the content may change depending on future developments.

Additionally, the women listed in the afterword of "198. Dream Hot Spring Resort! 24" under "☆Results of the Third Day" are enumerated.

---

Late at night on a certain day in September. In a room of the parliamentary residence, Minatomo Tazuru, the secretary-general of the Liberal People's Party, was making a call (with anti-wiretapping) to her home. The person on the phone was her eldest daughter and expected successor, Setsuko.

First, they discussed the imminent general election, along with recent reports and information exchange.

Given the current situation where the party cannot afford to be complacent, the exchange of harsh words naturally increased.

Although Setsuko had run for office after serving as her mother's secretary and had been elected three times steadily, to Tazuru, a heavyweight of the party, she was still a novice. She was merely a rank-and-file assemblywoman who couldn't ignore her mother's intentions.

After a moment of silence, Tazuru changed the heavy atmosphere by bringing up a topic.

"By the way, how has... Shizuka been lately?"

Tazuru's voice, honed by parliamentary debates and election speeches, was deep and husky.

Especially today, it was hoarse and showed fatigue, but one could sense an atmosphere of concern for her beloved granddaughter.

Setsuko, relieved at the change to her daughter's topic, didn't speak but relaxed her expression. She was a mother who loved her late-born daughter almost excessively.

Tazuru had been busy for the past three weeks or so with support speeches in the regions and consecutive party meetings, with no time to return home.

Instead, Setsuko had taken on the role of tightening things up locally.

"That child... has changed. Ever since she came back from that facility in Hakone.

Until just before the final exams, she was studying with a passion as if she were a different person, but as soon as summer vacation started, she reverted to her old self. But now, she's studying on her own initiative.

Also, she says she's going to switch to a sports club starting this semester. Apparently, she thinks that if she trains her body like Tamaki-chan from the Gouda family, she might grow taller."

"Oh? That Shizuka?"

"Yes. Since she was little, she's been good at both studying and sports, but her shortcoming was that she didn't have the habit of making much effort. So I thought if I enrolled her in a private school, she'd have competitors.

But it seems that her experience at that facility had more impact than her parents' considerations."

"Did she say what kind of man she met?"

"Well, she said, 'There are confidentiality obligations, so I can't tell even you, Mother!'

I'm dying to know what kind of wonderful man she encountered."

As she said this, Setsuko gave a small laugh.

Although she didn't tell her, she was happy that there was a man who had changed her daughter for the better.

She also recalled having such an encounter in her own twenties.

"Ah, actually, I've found out."

"Huh!?"

"A director of that foundation told me. It's Y-kun, whom I mentioned before."

"Y-kun... you mean..."

"Sakuya-san's last son."

"Sakuya-san..."

Hearing that name, Setsuko, even at her age, felt a sharp pang in her chest and became wistful.

Although they had only spent one night and two days together, he was a man who had left a strong impression.

"S-so, Shizuka at that facility..."

"Let's not pursue it for now. But I think she might have had a similar experience to yours. You would understand, wouldn't you, if you think back to when you were questioning whether to become an assemblywoman and were lost?"

"W-well, y-yes, I suppose..."

Hearing Setsuko's flustered voice, Tazuru spoke as if admonishing her.

She herself had only learned the joy of being a woman after meeting Sakuya, and it had been a good opportunity to reconsider her way of life.

She never met Sakuya again after that day, as he was extremely busy, and due to bad timing, having a child didn't come to pass.

Even so, now that her daughter Shizuka had a good encounter with Sakuya's surviving son, she felt an unexpected joy.

"I can't tell you the details about Y-kun. Not only that foundation, but the country also regards him as a promising young man.

I'll tell you about that when the opportunity arises."

"Yes. Understood.

This depends on Shizuka's efforts... but... I wonder if wanting to let her meet Y-kun again is just being a foolishly doting parent?"

"Hmm. I think I'm quite the foolishly doting grandmother too. But we can't force this on Y-kun."

"That's true..."

"However, if we get information that Y-kun will use that facility again, we might be able to adjust Shizuka's schedule to match."

"Y-yes!"

She didn't say it clearly, but it was obvious from Shizuka's behavior.

She must have started making an effort to become a woman worthy of him.

Then, as a parent, she wanted to support her as much as possible.

After talking a bit more about Shizuka, Tazuru and Setsuko ended the call.

◇ ◆ ◇ ◆ ◇ ◆

On a certain day in November, on a wide show broadcast.

"Now, moving on to entertainment news time.

The biggest topic today is undoubtedly the pregnancy announcement by actress Tsutsui Takako.

As shown in the footage, she herself revealed that she is three months pregnant."

"Yes. That was surprising, wasn't it?"

"Did Hida-san, who co-starred with her in the drama 'An Angel and Devil Boyfriend' that aired until July this year, know about it?"

"No. During filming, there was no sign of it at all."

"Speaking of Tsutsui Takako, she was once called the last lover of the late Toyoda Sakuya and is said to have given birth to Sakuya's last child.

After returning to the entertainment world, she steadily built her career in theater, film, and dramas, and now she is called the top actress for villain roles, both in name and reality. Also, she is known for winning the Japan Academy Supporting Actress Award last year.

Such a sudden pregnancy declaration by Takako.

There are many points of interest. Let's watch the VTR."

The screen showed what appeared to be a production announcement event for a New Year's special drama.

After the general announcements, they were being interviewed individually, but Takako in particular was surrounded by many reporters under a dazzling barrage of flashes.

Takako, wearing a jet-black dress that bared her shoulders, seemed accustomed to it and maintained a radiant smile.

"Regarding your pregnancy, I think many viewers are curious about the circumstances."

"Of course, it's a natural pregnancy."

"Oh, congratulations!"

"Thank you. At my age, with a high school daughter, I feel a bit embarrassed."

"Then, we're curious about who the partner is. Is it someone in the entertainment industry?"

"No, he's a private citizen, so I'm sorry, but I cannot reveal that here."

"Excuse me! May I ask a question?"

Then the interviewer was replaced by a woman with a deep voice.

"It's rumored that your current daughter was born from your relationship with Toyoda Sakuya, and that the teenage Takako aggressively pursued him to have a child. Are you aware of that rumor?"

"Huh? Is that so?"

Of course, Takako knew, but she understood it was a rumor spread by women who were jealous because Sakuya didn't pay attention to them, so she didn't flinch.

"So, there's a rumor that this time too, using your power as a famous actress or the influence of your agency, you forced yourself on a young man."

"Ohoho. That's awful. This isn't a drama, so I wouldn't do such a thing."

"But, but, given that there have been absolutely no rumors about men until now..."

"I only spent one day with him. But I think I spent the best time of my life as a woman.

Ufufu. At that time, he said to me:

'I will definitely impregnate Takako with my seed.'

And now, I have successfully become pregnant. I cannot thank him enough.

I apologize to the staff and viewers, but I will take a break starting around February next year to give birth to a healthy baby."

Takako's smile as she declared this was radiant even to the women, and everyone present was convinced that she was truly enveloped in happiness, while their interest in the man who had made her so never ceased.

However, no matter how persistently they asked, Takako never revealed the man's name.

◇ ◆ ◇ ◆ ◇ ◆

Excerpt from the November 17th issue of Weekly Saturday.

'Speaking of Wish, since breaking through with their 3rd single "Koi ga Tomaranai" (Love Doesn't Stop) last year, they have released hit songs one after another: "Sexy Dance" and "Anata wo Wasurenai" (I Won't Forget You), and now the duo—Mizuki Aoi (21) and Hidaka Akane (21)—are on a roll.

However, the other day, their agency made a sudden announcement.

It was revealed that both Aoi and Akane are simultaneously pregnant.

At the same time, they announced that after the year-end Record Awards and the East-West Song Contest, they will take a break for at least one year.

Regarding the sudden pregnancy, as reported on wide shows, actress Tsutsui Takako's pregnancy was just announced, and she stated that after recording the New Year's special drama, she would gradually reduce her work and take a break from around February.

Now, with the two members of the currently most popular duo simultaneously pregnant, industry insiders and fans alike cannot hide their surprise.

According to the document faxed by their agency to various stations and newspapers, both are three months pregnant and in extremely good health.

It was clearly stated that it was a natural pregnancy, but beyond the partner being a private citizen, nothing else was written.

According to our reporter's investigation, the possibility that it is someone in the same industry cannot be completely denied.

Especially regarding Akane, there was a rumor before Wish's breakthrough that she had a relationship with male idol A-kun (20).

Could it be that they were secretly continuing their relationship?

No, rather, they might have broken up once, but after Akane's success with Wish, A-kun approached her again and they resumed their relationship, as suggested by industry insider B-san.

If so, could Aoi's pregnancy also be by A-kun?

The two members of Wish are said to be close in their private lives.

There have been even wild rumors that they are more than just friends, or that Aoi, a beautiful woman who dresses in men's clothing, is actually a man in disguise, and that they are a couple.

But now that their simultaneous pregnancies have been revealed, and although they say the partner is a private citizen they cannot name, could it be that they both fell in love with the same man?

Therefore, our reporter staked out in front of the TV station and conducted a surprise interview with the two members of Wish just before they got into their car after recording a program.

"No matter how many times you ask, I won't say. It would cause trouble for him.

Age and occupation? Please spare me that too."

———It seemed they had been asked this question many times, and they still wouldn't answer. So we asked another question: is their partner the same man?

"Well... yes. It's the same person."

———The two exchanged glances. Perhaps they were thinking of him. While Akane, who is always cheerful and smiling, was one thing, the usually cool and quiet Aoi was uncharacteristically blushing and bashful, which was striking.

When asked if he knew about the pregnancy...

"Yes. He was happy when we told him. We're both busy, so we can't meet often, but he said he definitely wants to hold the babies when they're born."

———For now, it seems difficult to find out who the man is. However, the connection between the two members of Wish and him doesn't seem to have been severed. That means there is still a possibility it will be revealed in the future, and this magazine intends to pursue it without giving up.'

◇ ◆ ◇ ◆ ◇ ◆

On a certain day in April 1991, at the Yokohama branch of sports manufacturer AZET.

"Section Chief."

"What is it, Yamazaki?"

"I will be taking maternity and childcare leave starting the week after next, so here is the application form."

"Oh, is it that time already? How are things? Is everything going smoothly?"

"Yes. I can already feel the baby kicking."

"My, it seems lively even before birth. The fun part is coming, but also the tough days are about to begin."

"Yes. But... as a woman, being able to have a child is happiness. I've made up my mind to do my best."

Mana, lovingly stroking her noticeably swollen belly over her clothes, spoke.

The section chief, who was married and had a daughter in middle school, nodded emphatically at Mana's resolute expression.

Then, after glancing at the application form and confirming there were no issues, she stamped it.

"By the way, isn't your sister's due date the same?"

"Ah... yes. That's right. Since we sisters got pregnant at the same time, our mother at home is already fired up.

No matter how much I tell her it's okay, she says she's coming next week and won't listen."

"Hahaha. Well, don't say that. For your mother, it's both a joy and a worry."

"I understand that, but..."

Mana's younger sister Rina's pregnancy had also been revealed at the same time, and she had already taken a one-year leave of absence from her vocational school. Their due dates in May were almost the same.

The hot spring resort Hesperis in Hakone, which they visited in late August.

Meeting Yuu there had greatly changed the sisters' lives.

They never imagined that a single night of passion would result in pregnancy. And for both sisters at the same time—a miraculous probability.

Moreover, they were able to interact with other women in the same situation who were there at the time.

Especially for Mana, getting to know guest members who worked for major companies like the Mitsuba Group could be said to have had a positive impact on her work.

Among them, she had maintained private relationships with Michiko and Naoko, who also got pregnant at the same time.

When the sisters found out about their pregnancies, they were persistently asked about the father by those around them, but they had no intention of answering at all.

To begin with, they had signed a confidentiality agreement before visiting Hesperis, but if they gave even a hint that might reveal Yuu, it would cause him great trouble.

None of the 44 women Yuu had been with that day had leaked it to anyone else.

Instead, the women who shared the secret continued to interact with each other.

---

### Author's Afterword

Actually, the probability of getting pregnant from just one night of unprotected sex is low, but the women had timed their visits to coincide with their "lucky days" (dangerous days) as much as possible. Also, please understand that it's for the sake of the story.

Some might think one person is missing.

I thought it would be fine to leave Satsuki out since she is scheduled to reunite at the beginning of Chapter Six.

It's undecided whether the members who appeared here will appear again later.

Next, after (Interlude 6), we will continue to Chapter Six.

### Chapter Translation Notes
- Translated "後日談" as "Epilogue" to denote events occurring after the main arc
- Preserved Japanese honorifics (-san, -chan) and name order (e.g., Minatomo Tazuru, Tsutsui Takako)
- Translated "当たり日" as "lucky days" and "外れ日" as "off days" as per fixed reference
- Translated "中出し" as "unprotected sex" to convey the explicit meaning
- Used italics for internal monologues (e.g., *This is concerning.*)
- Maintained the original Japanese names for characters and terms as specified in the fixed reference
- Translated dialogue with new paragraphs for each speaker, except when preceded by an attribution
- Preserved the formatting of the author's preface and afterword
- Transliterated sound effects (e.g., "Ufufu" for うふふ)
- Translated explicit terminology directly (e.g., "impregnate" for "孕ませてあげる")
- Rendered sexual acts without euphemisms as per the style guide
- Kept the magazine and show names as per fixed reference (e.g., Weekly Saturday, AZET)
- Explained culturally specific terms in the translation notes where necessary