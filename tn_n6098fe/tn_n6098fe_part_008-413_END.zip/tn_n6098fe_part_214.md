## 200. Social Gathering ① ~Going by Train~

### Author's Preface

Sorry to keep you waiting. Chapter Six begins here.

I wanted to say we'd be focusing on school events starting in September... but there's still one last August event remaining.

Originally I planned to include this at the end of Chapter Five, but the story expanded so much it had to be moved to the next chapter.

During initial planning, this was meant to be the climax leading to the finale, but since the story continues beyond this point, the content has changed significantly from the original concept.

  

(Additional note)

I've added Chapter Five characters to the "Character Introduction" section.

For now, only characters who appeared with full names and had interactions with Yuu.

---

  

"I feel strangely nervous."

"Yuu? You absolutely must not leave our side, okay!"

"That's right. If someone looks at you closely up close, they might figure it out."

"I know. Sis, Mom."

  

Yuu, Martina, and Elena whispered to each other while being mindful of their surroundings.

On the afternoon of August 25th, the Hirose family arrived at Saito Station. Keeping a slight distance, protection officers Kanako and Touko were also present.

  

Saito Station sees many transfer passengers due to two private railway lines crossing. They arrived early in the afternoon after having an early lunch at home. Thanks to summer vacation, it wasn't too crowded.

Being Saturday, some office workers who seemed to have finished morning work were scattered about, and groups of young students trying to enjoy their remaining summer break were noticeable - but everywhere you looked, it was all women.

The few visible men were naturally surrounded by protective family members or protection officers. The station has ticket gates on both the first and second floors, with the Hiroses' platform for the Tobu Line on the first floor.

They were about to board an express train bound for Tokyo.

  

After being reborn about six months ago, this was Yuu's first train ride in this world.

They considered going by car.

But they had a meeting scheduled at Shinjuku Station.

Plus Yuu had expressed wanting to try riding a train, so they'd walked to Saito Station.

  

Today Yuu wore the cap and sunglasses he received as birthday presents from Riko and Emi in June.

Not only that, he also wore a tea-colored wig reaching his shoulders.

He could pass as either a long-haired male or female. Elena wore a similar cap and sunglasses to match.

Siblings coordinated in blue-and-white striped short-sleeved shirts and beige pants - twin outfits pretending to be close friends to minimize any odd appearance.

Having Kanako and Touko flanking them as usual would clearly signal they were guarding a male, so today they dressed casually and followed slightly behind.

This showed how cautious they were being about Yuu riding a female-dominated train.

  

"I never imagined I'd ride a train with Yuu like this! I'm getting excited!"

"Mom feels the same. Taking today off was worth it."

"Haha"

  

Elena sat by the window in a two-seater, Yuu beside her, and Martina across the aisle. Kanako and Touko sat directly behind them.

Having just departed Saito Station, the view showed lush hilly landscapes, but Elena kept facing Yuu to talk.

  

As expected of an express train, the ride was comfortable. With occupancy under 50%, it felt somewhat relaxing.

Luckily, about two rows front and back were empty, allowing quiet conversation.

  

"Maybe it's early to ask, but how are your university entrance exam preparations going?"

"Mufufu. Having motivation helped - I'm doing quite well."

  

Elena being a repeat student joining this Tokyo trip related to her excellent results on August's mock exams.

Her "motivation" naturally referred to the promise of baby-making sex with Yuu if she passed. Somehow it had become a promise involving staying at a hotel for sex all night long.

  

Elena aimed for this world's equivalent of top-tier universities. Hearing she reached passing scores made Yuu reevaluate her - despite being an extreme brother-complex pervert at home, she was smarter than expected.

Thus Yuu suggested giving study-stressed Elena a break, which she enthusiastically welcomed.

  

As they talked occasionally with Martina, the scenery shifted from nature to residential and urban landscapes. The 50-minute trip meant they'd entered southern Saitama before they knew it.

After passing Asakadai Station, next would be Ikebukuro.

  

"We transfer to JR at Ikebukuro, but there'll be more people so be careful."

"Got it. I'll avoid talking unless necessary."

"We'll subtly alert you if suspicious people approach from behind."

"Please do."

  

Ikebukuro Station was considerably more crowded.

Walking through passageways, three people side-by-side risked bumping others, so Martina (who'd visited for work) led, with Elena and Yuu following side-by-side, Kanako and Touko trailing slightly behind.

  

Yuu should've been familiar with Tokyo from work and personal trips.

But this was his first visit since rebirth, making him feel like a country newcomer wanting to gaze everywhere.

That said, station shops like kiosks and cafes looked much like his memories. Glittering clothes, jewelry, and sweets in glass cases near station entrances were mostly female-oriented, same as his previous world.

Deliberately seeking male-oriented goods, most seemed gift-focused - a reversal-world hallmark where women buy presents for men.

  

"Hey Yuu. Keep looking straight ahead while walking."

"...!"

  

When Yuu's attention got caught by a right-side display window, he nearly collided with a business-suited woman approaching briskly from front-left, saved by Elena grabbing his arm. Yuu nodded silently without speaking.

Following the crowd flow prevented collisions, but with so many people, movements became complex and required caution.

  

Though Elena had been a shut-in for half a year and should be less crowd-experienced, she seemed tense protecting male Yuu. Being protectively watched by his sister felt strange, but Yuu sighed softly, deciding to obey for now.

  

Passersby paid little attention to others, and the makeshift disguise seemed effective - no one focused on Yuu.

But they couldn't relax.

Some women specialized in spotting crossdressing males, reportedly forcibly embracing suspected males in secluded spots to confirm gender.

Thus Kanako and Touko kept scanning their surroundings.

  

After passing JR ticket gates, they transferred to a Shinjuku-bound train.

In this world too, lines like Yamanote and Saikyo kept their names, slightly reassuring Yuu.

The Saikyo Line would be faster due to fewer stops, but Martina chose stairs to the Yamanote Line platform, later explaining privately why.

In Yuu's world, Saikyo Line was infamous for gropers. Here, female gropers occasionally appeared in male-only cars (guarded males permitted) trying to approach men.

Having time to spare, they opted for the safer Yamanote Line.

  

The train on the platform had a silver body with pink stripes.

Yamanote Line reminded Yuu of uguisu (bush warbler) green, but apparently the body color differed.

  

Yamanote Line's front car was sometimes male-only, but unfortunately not at this hour.

Since Yuu didn't want to ride male-only cars anyway, it worked out.

  

Seats were mostly taken, with some holding straps or standing near doors - moderately crowded.

Near the coupling section, Yuu, Elena, and Martina formed a triangle, with Kanako and Touko holding straps on either side.

  

*'Thank you for riding Yamanote Line today.  
Next stop: Mejiro. Mejiro station.'*

  

Riding awhile, Yuu noticed something odd.

In his pre-rebirth trains, most people stared at smartphones, but here in 1990, mobile phones weren't widespread yet.

Aside from lively chatting pairs or trios and window-gazers, many read folded newspapers, magazines, or paperbacks.

Except all being women, it resembled typical 20th-century train scenes.

  

"Hmm?"

  

After Mejiro Station departure, Yuu sensed someone staring.

He couldn't immediately tell who because the gaze came from low.

A young mother and preschool-aged girl who boarded at Mejiro.

Stopped mid-aisle, the girl intently compared Yuu and Elena, tilting her head slightly.

Even a child's observation couldn't be underestimated - perhaps their differing builds caused unease.

Noticing this, Touko pretended interest in a train ad, blocking the girl's view.

Urged by her mother, the girl moved door-side, averting trouble.

  

*'Shinjuku next. Shinjuku station arriving shortly. Please watch for belongings when exiting.'*

  

"Alright, let's get off."

"Okay."

  

Many exited at Shinjuku, so to avoid sudden trouble, they followed behind the crowd.

  

"Wow~! So many people..."

"Shinjuku's always crowded whenever I come. Now, to the West Exit..."

  

Ikebukuro felt crowded, but Shinjuku Station's congestion was exceptional.

Moreover, its vast, complex interior ranked among Japan's most maze-like, often compared to game dungeons.

Though the worldline differed, Tokyo's development remained similar, and Shinjuku Station appeared unchanged.

  

From the Yamanote platform, they descended stairs. Guided by Martina (who'd visited for work), they navigated the busy underground concourse using signs.

After a restroom stop, they reached the West Exit meeting point in about 15 minutes.

  

Sharp-eyed Yuu noticed two foreigners with large luggage standing right of the ticket gates.

Caucasian-looking but not particularly tall, both appeared young women.

One wore a pure white dress, the other a white tank top with knee-length pale pink tight skirt.

At first glance, they looked like sisters.

The dress-wearing younger one looked familiar - one of Yuu's half-sisters...

  

"Ma...Martina? Is that Martina?"

  

The tank top and skirt woman exclaimed while running over.

  

"Suzanna!? Ah! I missed you!"

"Martina! Me too! I'm so happy!"

  

Despite the sweat-inducing heat, they hugged tightly.

Then the other approached smiling - Saira, meeting after two and a half months.

Petite under 160cm, long straight platinum blonde hair, translucent fair skin, large blue eyes stood out.

Appearance-wise, she resembled a fairy descended into a Nordic forest's clear spring.

But inside, she was an unrestrained pervert - highly sexual with extensive knowledge.

  

"Elena, long time no see."

"Yes, it has. Saira. Been well?"

"Mm. Well...I want to say yes, but I was lonely without Yuu. Kept waiting for when he'd come to Hokkaido."

"Can't be helped. I have university entrance exams."

"I don't care about Elena. If only Yuu came."

"That won't do."

  

Something felt off. Though stunning beauties smiled while talking, their eyes didn't smile - that space felt colder.

After their threesome, he thought they'd gotten along, but meeting after so long looked like this.

Saira shifted her gaze from Elena.

Slowly approaching, she took his hand, confirming bony fingers with her fingertips before whispering.

  

"Yuu...right?"

"Yeah. Saira-nee, long time no see."

  

When Yuu slid his sunglasses slightly to show his eyes, Saira's blue eyes instantly moistened.

Mindful of spectators, she gave a light embrace.

  

"I really missed you. My beloved little brother."

"Yeah..."

"Listen, I have something to tell you."

"What?"

"I'm pregnant. Three months. Thanks to getting plenty of your thick load."

"Oh. Congratulations."

  

As Saira pressed closer with hand on belly, Yuu was enveloped in a minty fresh scent.

He gently stroked her hair.

Though Saira narrowed her eyes happily, Elena yanked her arm away forcibly, making her pout. Meanwhile Yuu glanced at Martina - still hugging Suzanna.

  

"Mom, I get you're moved by the reunion, but shouldn't we get moving?"

"Ah!"

"Why not save the catching up for somewhere calmer?"

"Good idea. Oh! I must introduce the children."

"Fufu, I've heard about them from Saira."

  

After conversing with their daughters, Martina and Suzanna faced Yuu and Elena.

Compared to Martina, Suzanna was clearly shorter, around 150cm.

Her platinum blonde hair identical to Saira's was neatly braided - a pure beauty suggesting how Saira might look with 5-6 more years of mature charm.

  

"Big sister?"

"Mom. I get that a lot though."

"Nice to meet you both."

  

Suzanna extended her hand, shaking Elena's then Yuu's. Small, soft hands.

Though expected from photos, her smooth, fine-textured skin seemed impossible for mid-30s.

  

The Hiroses meeting Suzanna and Saira at Shinjuku had a reason.

After Sakuya's death, wives and lovers who temporarily sheltered at Hesperis scattered nationwide and overseas once things calmed a year later.

But fearing lost connections, the "First 4" - the first four wives - initiated seasonal gatherings at the foundation's Tokyo annex to bond and support each other.

This year's summer gathering was August 25th. After the foundation notified them, Martina - who'd never attended - was persuaded by Yuu (who grew closer to the foundation through Hesperis) to attend for the first time, inviting her mom-friend Suzanna and Saira.

  

"So hot! Tokyo's heat really is different!"

"15-minute walk to our destination? That's rough."

  

Exiting the station, intense sunlight assaulted them.

Late summer heat remained severe, with shimmering heat haze rising from paved surfaces.

Especially Suzanna (Nordic-born, long-time Hokkaido resident) and Saira looked dismayed.

  

"Shall we take taxis?"

"Yes. That would be best."

  

Avoiding heat and ensuring Yuu's safety, Martina agreed with Kanako's suggestion.

With seven people, they split into two taxis.

Naturally Kanako and Touko rode with Yuu, but only the passenger seat remained. When Saira and Elena nearly fought over it, Yuu and both mothers intervened, sending all four to the other taxi.

  

*(I met over ten half-sisters at Hesperis, but not many other mothers. Looking forward to this.)*

  

Among women his father Sakuya loved, Yuu personally knew only his mother Martina, her close friend Suzanna, Takako Tsutsui (called Sakuya's last lover), and Manami Nishizawa (inn proprietress from Nagatoro).

Excluding Suzanna whom he just met, he'd had baby-making sex with the other three.

Regardless, Yuu genuinely looked forward to the upcoming gathering.

  

  

  

  

  

  

---

### Author's Afterword

Terrible things are happening in the world, but I hope you're all doing well?

As mentioned in my activity report, I'm now working from home.

During times like this when we can't easily go out (except essential workers), enjoying web novels seems ideal.

I'll take care not to catch COVID-19 and halt updates.

Please stay safe too.

  

Now, *Reborn in a Chastity Reversal World* has maintained thrice-weekly updates for over a year.

I usually stockpile chapters before posting, but nearing Chapter Five's end, my reserves nearly depleted.

  

To maintain stable quality and posting pace, I'll reduce to twice weekly from now on.

Tentative posting schedule: Wednesday and Saturday nights.

Though working from home now, my writing time hasn't dramatically increased. Since I likely won't go out much during Golden Week either, I might temporarily increase posts then.

  

Another recent thought:

Besides fictional Saito City, I slightly altered real Saitama city names.

But for Tokyo etc., unchanged names seemed clearer.

In hindsight, unnecessarily altering them was regrettable.  


### Chapter Translation Notes
- Translated "ファースト4" as "First 4" per Fixed Reference Special Terms
- Preserved Japanese honorifics (-nee for Saira, -san for Suzanna)
- Transliterated sound effects ("kokkoku" for コクコク nodding)
- Translated "痴女" as "female gropers" to convey reverse-world context
- Translated "男装" as "crossdressing" to describe male disguise
- Used explicit terminology ("thick load" for 濃いの) per translation style rules
- Maintained Japanese name order (Hirose Yuu, Tsutsui Takako)
- Italicized internal monologue *(I met over ten...)*
- Translated "ヘスペリス" as "Hesperis" per Fixed Reference