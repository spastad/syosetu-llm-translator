## 202. Social Gathering ③ ~Beloved Ones~

"Thank you all for taking time from your busy schedules to attend this summer social gathering at Houshoukan."

Standing on the podium to begin the address was Toyoda Haruka.  
One of the four first wives of Sakuya.  

After Sakuya's death, many wives reverted to their maiden names to avoid media scrutiny and public curiosity. Martina, who discovered her pregnancy, was one such case.  

However, Haruka and the other three who officially represented Sakuya's wives continued using the Toyoda surname.  

When Yuu read a magazine feature commemorating the 15th anniversary of Sakuya's death, it described Haruka as the most reliable, sisterly figure among the four.  
In fact, she was the one who encouraged the grieving wives, united them, and established the volunteer group that became the foundation of the Toyoda Sakuya Memorial Foundation.  
This made her the leading figure as permanent director of the foundation.  

Since she was the same age as Sakuya, she would be 46 or 47 now.  
She wore a calm-inducing kimono in young grass green with silver-embroidered floral patterns.  
Her height wasn't particularly tall compared to others.  
But her sharp features and alluring narrow eyes made her seem both physically and mentally beautiful and dependable.  
In fact, many younger wives and lovers admired Haruka despite being the same gender.  
To Yuu observing from a distance, she vaguely reminded him of a "yakuza wife."  

Nine wives attended the summer gathering including Haruka as one of the organizers.  
Seven were Japanese, with two foreigners like Suzanna who came to Tokyo for this occasion (Martina, born in Japan as a second-generation, was treated as Japanese).  
Additionally, six lovers attended - those like Ichinose Hatsumi (Sakuya's elementary school homeroom teacher) who had relationships before marriage, or those like Takako who were recognized as having dated for a certain period.  

Including Satsuki as a foundation staff member on the organizer's side, and children like Yuu and Elena who came with their mothers, there were eight more.  
Thus, attendees connected to Sakuya totaled 23 (including two males: Yuu and another).  

The party venue had four round tables with white cloths set at equal intervals in buffet style.  
Of course, chairs were prepared along the walls for those tired of standing.  
The food consisted mainly of light meals: small-cut sandwiches, pizza, roast beef, chili shrimp, prosciutto, various cheeses, and french fries.  
Drinks included alcohol like wine, champagne, and beer, plus soft drinks.  

Yuu looked for Tsutsui Takako among the gorgeously dressed women but unfortunately couldn't find her.  
She must be busy with her acting career.  

"It wouldn't be good to talk too long, so I'll end here.  
Could everyone please prepare drinks in your glasses?"  

With only a few foundation staff besides Sakuya's relatives at the hall, serving was done proactively by attendees themselves.  
At Haruka's words, those nearby poured drinks for each other.  
Martina held a glass of wine, Elena held champagne, and Yuu took a cola-filled glass.  

"Before the toast, let me introduce first-time gathering participants."  

After the lights dimmed, a spotlight suddenly shone on where Martina and Suzanna stood.  
Simultaneously, a tall, slender woman in kimono who had been standing further back was pushed forward by others, making three in a row. Yuu and his group were slightly apart.  

"From the front: Takahata Youko from Yamagata Prefecture, Hirose Martina residing in Saitama Prefecture, and Suzanna Yutilainen who came all the way from Hokkaido via Finland!"  

At Haruka's introduction, everyone gave enthusiastic applause.  
Kiyoko had reunited earlier in the waiting room because she came with her mother.  
Though she married early, she wasn't very healthy and was recuperating at her parents' home when Sakuya died.  
Though tall, she gave a faint, ephemeral impression.  

Yuu later learned Youko decided to attend the gathering after many years because she wanted to meet Yuu - the man her daughter Kiyoko had become intimate with - and express her gratitude.  

After introducing the three, everyone raised their glasses for a toast.  
His family lightly clinked glasses with Suzanna and Saira nearby.  
Yuu noticed the Takahata mother-daughter pair approaching him during the introduction.  

"Thank you so much for taking such good care of Kiyoko back then."  

Youko, wearing a plain light purple kimono with a checkered-pattern obi, first placed her glass on the table, folded both hands in front, and bowed deeply at about 45 degrees.  
Seeing this, Kiyoko also bowed in imitation.  
When Yuu first met Kiyoko, she seemed horror-like or detached from worldly matters, and Youko's bow was similarly flowing and natural. Yuu wondered if they came from an esteemed family.  

"P-please! Both of you, raise your heads!"  

The flustered Yuu couldn't help speaking out.  
Youko and Kiyoko slowly raised their heads and exchanged smiles.  
Then only Kiyoko approached close enough to touch Yuu and whispered softly.  

"You know, Yuu... I couldn't say earlier but... actually, I'm pregnant."  
"...!!"  

With just those words, Yuu understood.  
Two months had passed since their first sexual encounter.  
Depending on the person, this was when pregnancy could be detected.  
Saira, Kiyoko - pregnancies were being revealed one after another by half-sisters Yuu had creampied.  
Come to think of it, there was another. He should have been with (Yanai) Miku in June too - what about her?  
Such questions crossed his mind, but first he focused on Kiyoko who reported quietly, mindful of others.  
Yuu took her slightly lowered hand and clasped it in both of his.  

"That's wonderful. Congratulations."  
"Th-thank you. It's because Yuu... did it so much."  

Kiyoko smiled happily, looking shy.  
This childishness didn't match her age but was adorable.  
Yuu noticed Elena, Saira, and other women watching as he and Kiyoko conversed face-to-face in low voices, but he offered congratulations regardless.  

"Everyone, may I have a moment?"  

Satsuki arrived amid this.  
She seemed to want to take first-time attendees, including Yuu, toward the front.  
Satsuki glanced at Yuu but showed no trace of their passionate night at Hesperis, leading with a straight face.  
They were taken to where Haruka stood.  

"Youko-san!"  
"Haruka-san. It's been too long."  
"And Kiyo-chan has grown so big. I heard you recently moved to Saitama. Are you well?"  
"Yes. Somehow, thanks to you..."  

Three women holding hands.  
Though they lived under one roof for years after marrying Sakuya, this was their first meeting in over a decade.  
The three tearfully caught up on old times.  

Next, Haruka exchanged greetings with Suzanna and Martina.  
Suzanna moved to Hokkaido relying on acquaintances after Sakuya's death due to its similar climate to her homeland; Martina noticed her pregnancy and gave birth in Izu before moving to Chiba then Saitama.  
Unlike Youko, the two hadn't attended foundation gatherings mainly because they were relative newcomers among the wives and felt reserved.  
Haruka politely thanked them for attending for the first time, making Suzanna and Martina feel so honored that Yuu understood why Haruka was so admired.  

As this happened, Satsuki and Yuu's eyes met behind Haruka.  
At Yuu's puzzled look, Satsuki smiled mischievously, pointed at Haruka, and said:  

"Mother."  
"Huh?"  

To Haruka, Saira and Elena were only known as babies, and she affectionately patted their heads as they'd become so adult-like, but her gaze turned toward Yuu.  

"You must be the rumored..."  

Haruka's words trailed off there.  
But her eyes spoke volumes as they stared intensely, making Yuu flustered.  
Recently, Takako had confided various secrets about Sakuya to Haruka before specially coming to meet Yuu.  
With so much she must want to say to him in person - including the reincarnation secret known only to a few (even family wasn't informed yet) - Yuu simply bowed without saying anything unnecessary.  

"Nice to meet you. I'm Yuu."  
"I'm Haruka. I'm happy to meet you today, Yuu."  

Saying this, Haruka suddenly approached Yuu head-on and took his hand in both of hers.  
She was about 10cm shorter than Yuu, with small hands typical of a somewhat slender woman.  
Yet being enveloped in them gave an inexplicable sense of security.  

"Takako-san told me. Someday, I want to hear many things directly from you."  
"Such... it's nothing special..."  
"Even so. Because I want to know about the world where that person might have lived."  
"Um... yes."  

After whispering this exchange, Haruka smiled at Yuu's slightly troubled expression and released his hand.  
Just when he thought she'd step back, she smiled as if remembering something and continued:  

"My child must have been willful and wild - it must have been tough handling her?"  
"Ah... no, not at all. Spending time with such a wonderful woman was the best."  
"Fufu. That part resembles that person."  

Realizing they were talking about her from their gazes, Satsuki shrugged helplessly.  

"Satsuki nee."  
"It's true, isn't it?"  
"It's true."  

When Saira chimed in right beside Satsuki, Yuu couldn't deny it.  
Afterward, conversation continued for about 30 minutes while nibbling food.  
Martina and Suzanna joined the wives' and lovers' circle, sharing memories of Sakuya, so groups naturally split between mothers and children.  
Tōya seemed known to dislike conversation, silently eating alone.  
Meanwhile, Yuu found himself surrounded by Satsuki, Saira, Elena, Kiyoko, and newly-met half-sisters.  

---

### Author's Afterword

Not sure if everyone will appear, but the First 4 all have Toyoda surname with "Haru", "Natsu", "Aki", "Fuyu" in their names.  

This Golden Week I'm basically holed up so I should make progress on stockpiling manuscripts.  
That said, I'm binge-watching anime from new to old on Amazon Prime since it's that time...  
At least for next week, I plan to post three times: Monday, Wednesday, Saturday.

### Chapter Translation Notes
- Translated "姉御肌" as "sisterly figure" to convey leadership qualities among women
- Rendered "極道の妻" as "yakuza wife" to preserve Japanese cultural reference
- Kept "ファースト4" as "First 4" per Fixed Reference capitalization
- Translated "物憂げな表情" as "listless expression" to capture melancholic mood
- Preserved Japanese honorifics (-san, -chan) and name order throughout
- Used "creampied" for explicit sexual terminology consistency
- Transliterated sound effects omitted in this dialogue-heavy chapter