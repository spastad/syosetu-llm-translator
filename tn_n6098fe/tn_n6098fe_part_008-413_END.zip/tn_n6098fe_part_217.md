## 203. Social Gathering ④ ~Women's Bar~

The standing buffet party in the hall was temporarily disbanded, with attendees free to visit the Toyoda Sakuya Memorial Room on the second floor or head to the underground lounge if they wanted more drinks or food.  

Some would tour the memorial room before leaving, but the Hirose family decided to stay overnight—rooms were prepared on the second floor—to accompany Suzanna and her daughter. After the memorial room visit, they would go to the lounge.  

In fact, the three women including Emmanuela from Italy had bonded over their love of alcohol since their marriage days, and Suzanna could apparently hold her liquor quite well despite appearances.  

The memorial room displayed numerous photos used in the slideshow, along with a timeline of Sakuya's life, life-size panels, handwritten letters, and other rich archival materials.  

Especially for first-time visitors Youko, Suzanna, and Martina, they toured carefully while exclaiming over each exhibit.  

Seizing the opportunity, Yuu followed them to look around as well.  

This wasn't open to the public—only foundation affiliates and specially approved applicants could visit. The existence of this memorial room itself reaffirmed how legendary his father was.  

After spending considerable time touring the memorial room, Martina's group cheerfully headed to the lounge. Several half-sisters including Satsuki also seemed headed there.  

Naturally, the underage Yuu had no intention of joining them that far.  
Yuu stayed with Elena, Saira, and secretly Kiyoko—who apparently disliked alcohol—as they explored the building.  

It was already past 8 PM. Looking out the window, night had fully fallen. Below them, the illuminated garden appeared fantastically beautiful.  

""It's beautiful.""  
""Ah, it really is.""  

Saying this, Saira gazed outside to Yuu's right.  
Her beauty could truly be called fairy-like when silent.  
Her long platinum-blonde hair looked soft and silky, shimmering with a silver gleam under the light.  
The slender line from her delicate neck to her shoulders looked so fragile it stirred protective instincts.  

Perhaps noticing Yuu looking at her profile, Saira turned to him and smiled while tilting her head.  

""Saira-neé is beautiful too.""  
""My! Yuu, you... I love you!""  
""Mph!""  

Without concern for onlookers, Saira grabbed Yuu's arm and pressed it against her chest.  
Instantly, Elena grabbed his other arm too.  
But only Saira's chest swell could be felt.  

Sandwiched between them in high spirits, Yuu suggested strolling in the garden with his sisters.  
Elena and Saira hesitated slightly, but Kanako and Touko who had followed strongly opposed it.  
Even surrounded by walls, letting a male go outside where anyone could see was too risky. Kanako's firm opposition related to what Hiromi had told them earlier that day.  

While Yuu's group was distracted, a construction company truck circled the wall toward the back entrance despite the late hour.  
Even if Yuu had seen it, he probably wouldn't have found it suspicious due to the darkness.  

Besides the memorial room, the second floor had a lodging section, with only meeting rooms and small rooms of unknown purpose—nothing particularly noteworthy.  
After gazing at the garden from the corridor windows, Yuu's group went down to the first floor.  
Though late, the gathering's food had been light, so they were getting slightly hungry.  

""Shall we go see where Mom and the others are (the lounge)?""  
""Eh...""  
""Hmm...""  

When Yuu invited them, Elena and Saira both made ambiguous expressions for some reason.  
Descending the wide, gently curved staircase to the entrance, they spotted a kimono-clad woman sitting on a chair by the wall.  

""Mom!""  
""Oh?""  

It was Youko, Kiyoko's mother.  
Her fair cheeks were slightly flushed, but she looked somewhat tired.  

""What's wrong? Are you okay?""  
""I'm fine. Just a little drunk.""  
""Eh... You're weak with alcohol like me.""  
""Only had one glass during the toast, then excused myself early.""  

Though not particularly healthy, Youko seemed emotionally uplifted from reuniting with her fellow wives.  

""Shall we go rest in your room?""  
""Let's do that.""  

But when she stood, Youko staggered.  
Yuu swiftly approached and supported her.  

""Ah... M-my apologies.""  
""You have a room reserved, right? I'll take you there.""  
""That's... I couldn't trouble you—""  
""It's fine. Youko-san is like a mother-in-law to me too.""  
""My.""  

Youko looked down shyly.  
Though slightly taller than Yuu, her build was so slender he barely felt her weight.  

""Yuu, wouldn't the elevator be better?""  
""Yeah. Let's do that.""  

Led by Elena and Saira, they headed for the elevator down the hall.  
He tried walking while lending his shoulder, but Youko's steps remained unsteady.  
He didn't know where in Yamagata her hometown was, but he hadn't heard of any Shinkansen running there.  
Fatigue from the early morning journey probably contributed too.  

""Excuse me for a moment.""  
""Eh... Kyah!""  

Yuu crouched and slowly lifted Youko by putting his arms under her shoulders and knees.  
A princess carry.  
Despite her height, her light build made her surprisingly easy for Yuu to carry short distances.  

""Please hold on tight.""  
""Y-yes!""  

Though slightly flushed from alcohol, her ears turned bright red the moment Yuu carried her.  
Yuu thought he heard several voices mutter ""How enviable"" but carried on walking regardless.  

""Then, rest well.""  
""I'm so sorry for the trouble.""  

Upon reaching the hotel-like room, Yuu set her down on the bed's edge. Youko repeatedly bowed and thanked him until he felt embarrassed.  

""We're family. I don't consider it trouble at all.""  
""How kind. Now I understand why Kiyoko fell so deeply for you.""  
""Mom!""  
""Yes, yes.""  

This time Kiyoko flushed crimson in embarrassment.  
When Yuu patted her shoulder, she shyly looked down, hiding her face behind long hair.  
Yuu brushed aside her bangs and looked at her.  

""Then, Kiyo-neé, see you at school. And please take care of yourself.""  

When Yuu expressed concern about her pregnancy, Kiyoko started, smiled happily, and grasped his hand.  

""Yuu... Thank you for today.""  
""You're welcome. Well then.""  

After parting with Kiyoko who stayed with her mother, Yuu headed downstairs to the lounge as originally planned.  

""And then! Sakuya-san told me when I was a high schooler: 'Have my children!'""  
""Heard that before. More importantly, Sakuya-san was the only one who praised me—ignored by all men—then hugged me tightly and kissed me passionately!""  
""You say that every time too."""

""Uuuuuh... Why did you have to die!? Sakuya-saaan! You promised to take care of me forever!""  
""Me too! You said we'd have many children! I only had one! Fwaaaaaaaaan!""  

""Hey, hear about this? They say there are old men in town who'll let you touch their dicks for money—students and working women who can't get men go hunting every night.""  
""Kids these days are hopeless. Do they just want any man? When I was young...""  

In the subdued lighting, the lounge-bar interior featured calm white and gray decor with brown tables and sofas.  
One corner occupied by drunk women echoed with shrill laughter, tearful laments, and grumbling complaints—extremely lively.  

Less than an hour after Martina's group went ahead to the lounge.  
They seemed thoroughly drunk already.  
Over a dozen women split into two groups, with numerous liquor bottles, glasses, and snacks crammed onto long tables.  

Martina sat beside Suzanna against the wall.  
Haruka and Fuyuno were also visible at the same table.  
Noticing Yuu's entrance, Martina waved vigorously.  

""Yuu-chaaan!""  

At her voice, everyone turned toward Yuu.  
And simultaneously beamed.  

""Yuu's here!""  
""""Yuu""""  
""""Yuu-kun!""""  
""You're still 16, right? Aah, so cute!""  
""Handsome enough to recall Sakuya-san's youth, aren't you?""  
""I wanted a son like that!""  
""Hey hey, come closer! Sit on this big sister's lap!""  
""Let me pat your head!""  
""Let's drink together!""  

Just one step closer, the smell of alcohol became noticeable.  
Entering this drunk crowd sober required courage.  
But having come this far, retreating felt awkward.  
Especially with Martina who adored Yuu, and Haruka who managed Sakuya's wives and lovers as the foundation's executive director.  

Smiling wryly, Yuu told Elena, Saira, Kanako, and Touko behind him:  
""I'll keep them company briefly.""  
""Haa... I had a feeling this would happen.""  
""Can't be helped.""  

Elena's group headed toward Satsuki's group instead of their heavily drunk mothers.  
That group seemed to be adult children reluctantly accompanying their mothers, drinking quietly.  
Touya's figure was also visible further back, silently tilting his glass while nodding to the women beside him.  
After waving at Satsuki's group, Yuu circled behind Haruka seated at the table's end birthday seat and sat beside Martina.  
One seat was empty—probably Youko's.  

""Ahaan, Yuu-chan! So glad you came!""  
""Haha, Mom. Having fun?""  
""Yes! So fun! The alcohol's delicious!""  

Martina leaned against him with a strong alcohol smell.  
An ordinary 16-year-old might grimace, but Yuu's previous life involved countless drinking parties nursing drunk colleagues and bosses.  
Compared to that, this was cute—he showed no displeasure.  
Seeing usually quiet Martina enjoying drinks with her fellow wives, he didn't want to ruin the mood.  
Haruka and others seemed surprised by Yuu's reaction.  

""Sorry, Yuu. Calling you into this drunk crowd.""  
""No. I don't mind at all.""  
""My, what a good boy, Yuu.""  

Before Haruka and Fuyuno opposite Yuu stood a famous Echigo sake bottle, considerably emptied.  
Though their speech remained steady, their flushed faces and fixed eyes suggested intoxication.  

""Whoa!""  
""Lucky Martina! Hey Yuuu, look this way!""  

When Suzanna leaned over from beside Martina, the weight doubled instantly.  

""Suzanna-san drunk too?""  
""I'm nooot~""  

Wine and vodka bottles lined up before Martina and Suzanna.  
Given the empty bottles, they'd drunk considerably but apparently weren't completely wasted.  

""Huh? Can Yuu drink?""  
""Still 16. I'll pass. Just a bit hungry—want something to eat.""  
""Satsuki!""  
""Kanna!""  
""For Yuu...""  
""""Bring food!""""  

Calling their daughters' names in clear voices were Haruka and Koyuki seated beside Fuyuno.  
Koyuki was another wife met today, mid-40s. In wife seniority, she followed Haruka's group.  
Her neat suit reflected her busy life as a company president—a software development company started on Sakuya's advice—who'd joined late due to an unavoidable meeting.  
Her intelligent appearance with silver-framed glasses gave a cold first impression.  
But according to Haruka, her personality had quite a gap—she'd blushed like a schoolgirl when shaking Yuu's hand.  
Yuu concluded she must be tsundere.  

Her daughter Kanna was seen as her mother's successor but currently worked as a regular employee. Resembling her mother, she was a tall, well-proportioned 28-year-old single.  

The two half-sisters were too grown-up to defy their drunk mothers and headed toward the counter with wry smiles.  
Only one middle-aged female master was there, but simple snacks could apparently be self-served.  

Just 15 minutes later, plates arrived before Yuu who'd been entertaining Martina and Haruka.  
Reheated pre-made grilled rice balls, fried chicken, french fries, and even oolong tea for non-drinking Yuu.  

""This is all we could prepare quickly.""  
""Here, Yuu.""  
""Satsuki-neé, Kanna-neé, thank you! Looks delicious!""  
""Please handle the moms.""  
""Must be tough with drunks.""  
""""Aahn!?""""  
""Whew, dodged that.""  
""See you, Yuu.""  

After Satsuki's group quickly retreated, Yuu's eyes sparkled at the steaming plate.  
Chopsticks meant for Youko lay nearby—barely used and clean—so he borrowed them.  
Watching Yuu eat busily, Haruka, Fuyuno, and Koyuki happily pushed leftover snacks toward him as if saying ""Eat this too.""  
Yuu even let them feed him with ""Aaahn""—completely at ease.  
Surrounded by mentally age-close beautiful mature women despite their drunkenness, he didn't mind at all.  

---

### Author's Afterword

Chapter 6 started with four non-erotic episodes in a row, but from the next one, we'll have continuous erotic content.

### Chapter Translation Notes
- Translated "お姫様抱っこ" as "princess carry" to maintain cultural nuance
- Preserved Japanese honorifics (-neé for sisters, -san for adults)
- Translated alcohol-related terms literally (sake, vodka, oolong tea)
- Used explicit anatomical terms ("dicks" for おチンポ)
- Transliterated sound effects ("Fwaaaaaaaaan!" for ふぁああああぁぁぁぁぁん)
- Maintained original name order (e.g., Toyoda Satsuki not Satsuki Toyoda)
- Formatted simultaneous dialogue with quadruple quotes (""""Yuu"""")