## 204. Social Gathering ⑤ ~Affection and Lust~

Not only Martina but all the mothers doted on Yuu as if he were their real son, making interacting with them somewhat enjoyable.  

However, since dealing with drunks could go on endlessly, after about an hour Yuu bid farewell to Haruka and Martina and exited the lounge.  

His destination was the second-floor guest room.  
When he reunited with Kanako and Touko who had been waiting while drinking tea at a separate table, they were startled—likely because his face, starting with his cheeks, was covered with several kiss marks (received from all the mothers when leaving).  

As expected, there was no luxurious bathhouse like at a traditional inn. When he finished showering in the unit bath and checked the clock, it was past 10 PM.  
Just as he thought it was too early to sleep, there was a timely knock at the door.  
Having vaguely anticipated someone might come soon, Yuu silently opened the door.  
There stood Saira looking up at him with a slightly surprised expression.  

"You were the first one, Saira-neé?"  
"Ah... I did it! First to reach Yuu's room!"  
"Well now, that's quite a stimulating outfit you came in."  
"Fufu. I wanted to show you, Yuu."  

Saira must have showered too.  
The ends of her long platinum-blonde hair were still wet, and she wore a sheer negligee with an extremely short hem.  
Not only were her perky C-cup breasts pointed upward, but her white lace panties were visible through the fabric.  

"Finally, we're alone, aren't we?"  
"Whoa."  

Yuu firmly caught Saira as she practically leaped to embrace him.  
Immediately, along with the pleasant scent of shampoo and soap, the soft sensation of breasts pressed against his chest.  
Yuu also hugged Saira tightly, feeling her body through the thin fabric, and stroked her slightly damp hair.  
Then Saira stretched up, not only pressing her lips against his but extending her tongue to pry open his lips and invade.  
During this, the door closed naturally, but a foot got caught just before it shut.  

"Sairaa..."  

It was Elena who had apparently run here, sweating and breathing heavily as she pried the door open.  

"*Nchu... churero, reroo... npaa... Kissing Yuu... feels so good! More!*"  
"Mm... Elena-neé?"  
"Sneaking ahead is cheating!"  
"Oh my, first come first served. I already showered. Elena, you can't come smelling of alcohol and sweat."  
"Guh!"  

Saira, who had been carefully monitoring Yuu's exit from the lounge, had slipped out stealthily to follow him and shower.  
Afterward, Elena finally noticed Yuu and Saira were missing and rushed here in a panic.  

Ignoring Elena, Saira continued kissing Yuu while clinging to him.  
Not only that, she lifted the hem of his T-shirt to enjoy Yuu's hard upper body.  

"*Chu, chu... Oh my, I think you've gained more muscle since last time.*"  
"*Nn... you noticed... huh?*"  
"*I love everything about Yuu... your inside and your body... everything!*"  
"W-well, me too!"  
"Neé, why don't you go shower?"  
"O-okay! Got it! Wait for me, okay!"  
"Fufuu. Yuu... shall we go to the bed?"  

As Elena stripped naked on the spot and rushed through the door to the unit bath, making a clattering commotion, Saira looked up at Yuu with mischievous eyes.  
Her right hand stroked her belly while trying to slip into the elastic waistband of his half-pants.  

"You don't have to rush so much..."  
"Nfu. Your cock is hard, isn't it?"  
"W-well... that's because it's you, Saira-neé."  
"I'm happy. *Chu!*"  

Despite her appearance, Saira was sexually voracious.  
Yuu enjoyed this gap in her personality too.  
Only Yuu could accept everything about her.  
That's why Saira could expose herself without reservation, and she adored Yuu beyond measure.  

Yuu slipped his arms under Saira's armpits and around her buttocks, lifting her with force.  
Saira then wrapped both legs around Yuu's waist to hold on.  
Though not inserted, it was practically the "ekiben position" (standing carry).  
Carrying Saira who kept planting random kisses on his face, Yuu moved to the bed.  

"Guh... Saira-neé... ahh, it's going in..."  
"Ahh! T-this... I wanted Yuu's cock so bad! Oh, ohhhh deep inside! Agh! It's... coming... feels so different from a vibrator! Ughhhn! Good! My insides... are being spread open... it's reaching... deep inside! Ahn! S-so good... *n-chu, chu!*"  
"Ah... as expected, Saira beat me to it..."  

Elena came rushing out completely naked, dripping water without properly drying herself, but slumped in disappointment at the sight.  
Yuu and Saira, seated on the edge of the bed in the carry position, were deeply kissing while touching each other's bodies.  
But Saira couldn't hold back any longer, pulling aside her panty crotch to insert herself.  
Her entrance was already soaking wet, easily swallowing Yuu's cock standing hard enough to hit her lower abdomen.  
Though momentarily blocked by vaginal walls, Saira grabbed Yuu's shoulders and forced it in, letting out a cry of joy.  

"Ahn, ahn, ahn! Good, so good... my vagina remembers Yuu's cock! Haan! It's... because... mmn! From the very start... it feels this amazing... my womb is descending, craving semen!"  
"That's an honor. Indeed, Saira-neé's pussy... keeps tightening like it's trying to squeeze out semen... guuuh!  
Haa, haa... Neé?"  
"Y-Yuu..."  
"Don't just stand there. Come here."  
"U-un!"  

Elena had been watching enviously as Saira began rocking her hips on Yuu, but when called, she happily pressed close from the side.  
Yuu placed his left hand on Saira's buttocks and pulled Elena close with his right, beginning to kiss her.  

"Yuu is so popular with everyone... your big sister worries."  
"Well, I don't refuse anyone who comes. Especially beauties."  
"Really... no chastity. *Chu, chu.* Next time... do it with big sister... okay?"  
"Ah... ahh! Yuu! I'm... cumming... I'm about to cum!"  
"It's okay Saira-neé, cum as many times as you want."  

"Aahn... your cock is amazing. I'm cumming, cumming! Ah, ah, no! Stop! Aaaaaaaaaaahhhhhhhhhhh—!"  

When Yuu thrust upward, Saira threw back her platinum-blonde hair, arched her white naked body, and reached climax.  
In the world before his rebirth, both these sisters would have made anyone turn their heads as peerless beauties walking down the street. Now they were desperately craving Yuu.  
Being able to simultaneously pleasure both sisters in a threesome filled Yuu with masculine happiness and satisfaction.  

"Fahh, ahh—! Yu... uuu... I'm cumming! Cumming! Oh, oh, oh cock! Amazing cock! No more... ahee... can't... I'm cumming!"  
"Agh! Cumming! I'm cumming, Saira... neé!"  

With each thrust between Yuu and Saira in the seated position, *pachun, pachun* sounds accompanied by sticky *guchu, guchu* wet noises.  
As Yuu approached his limit, Saira was about to reach another climax.  
Meanwhile, Elena had positioned herself behind Saira, persistently teasing her nipples and clitoris with both hands—apparently trying to make Saira collapse faster from the long-awaited sex with Yuu.  
Thanks to this combined effect, Saira seemed to be cumming nonstop.  
In fact, leaning against Yuu's shoulder, she drooled with a completely slutty expression.  

Yuu began a final sprint, thrusting his cock as if knocking on her womb.  
Instantly Saira arched back as if repelled, staring at the ceiling.  
A hard *gochin* sound came from Saira's head hitting Elena's nose, but neither Yuu nor Saira had time to notice.  

"Yu, Yuu! Yuuuuuu! Aghn!"  
"Guh! Saira... I'm... cumming!"  

Yuu held Saira's slender waist tightly for one last thrust.  
At that moment, *dopu dopu dopu*—a massive amount of semen was released into Saira's womb.  

"Ahhee... it... came... hah, hah, hah... ahhee, semen... feels so good inside my uterus..."  
"*Fuuh.* Saira-neé, I felt amazing too."  
"Yuu... ahhaan... I love you!"  

Yuu and Saira, having just finished mating like wild beasts, kissed while embracing.  
But Elena wasn't satisfied.  
Holding her reddened nose, she protested to the two.  

"Hey! How long are you going to stay connected? Now it's my turn!"  
"Still cumming inside—"  
"Hahaha. Saira-neé is satisfied now, right? Time to switch."  
"U~n. If Yuu says so, I guess. I'd rather stay connected all night though."  

Saying this, Saira lovingly stroked Yuu's head, back, and waist.  
In her experience, men became aloof after ejaculating and wanted to separate.  
But as a woman, she wanted to feel the warmth while clinging a while longer.  
In that regard, Yuu was unbelievably gentle, making her want to indulge.  

Yuu patted Saira gently as if persuading her, then lifted her body to pull out his cock.  
He laid her sideways on the bed.  
Preparing tissues in anticipation of semen backflow from the unplugged vaginal opening.  
After one last kiss, Saira smiled contentedly.  

"Yuu! Hurry, put it in!"  
"Whoa!"  

Elena mounted him from behind just as Yuu turned around, making him hastily catch her.  
She rubbed her buttocks against his still-hard cock.  

Her normally light brown hair, now wet and appearing dark brown, brushed *fasari* against Yuu's cheek. Simultaneously, the shampoo scent tickled his nostrils.  
It was strange how hair smelling the same shampoo felt so pleasant when drifting from a girl.  
Playfully, Yuu brought his left hand around and covered her modest swell, kneading and twisting her nipple.  

"Aahn! No... it's sensitive... nn, kuun..."  

Elena moaned with a nasal, sweet voice.  
Since frequently being fondled at home, Elena's nipples had become hypersensitive, instantly hardening at the slightest touch.  
When sleeping together at home with Yuu hugging her from behind, persistent teasing could make her climax from that alone.  

When Yuu slid his right hand from her thin belly over the pubic mound with sparse hair toward her crotch, a *nucha* wet sound occurred.  
Groping, he spread the drenched vulva with two fingers and inserted his middle finger *zupuri* into the vaginal opening.  
Moving it in and out to the second knuckle made *kuchu kuchu* sounds as it drooled with joyful saliva.  

"It's not 'put it in,' right? What are you going to do with this? Say it like before."  
"Fai... o-okay."  

Elena twisted around to face Yuu.  
Already looking dazed, she stared at Yuu with half-open lips, cheeks flushed pink—the very face of a female craving a male.  

"I... I'm Yuu's sex relief handler... my pussy... is a little brother-only onahole... hauuuu... please... use the onahole... right now..."  

Saying this, Elena panted like a bitch in heat, pressing her buttocks against him, making Yuu chuckle wryly.  
If anything, Yuu's cock was being used for Elena's sexual relief.  
But thinking it cruel to tease further, he grabbed her shapely buttocks *muni*.  

"Fufu. Sounds good. Maybe I'll use it."  
"Un! Then, right away..."  

As Elena leaned her back against him, Yuu supported her by holding her belly.  
Lifting her hips slightly, he guided his cock to her vaginal opening.  
Though seated and unable to see, she inserted it without using hands—likely from familiarity.  

"Ahh! Hah... hah... it's coming in! Beloved... Yuu's cock! I-in!"  
"Oof!"  

With each *zubuzubu* gulp of the cock, Elena leaked uncontrollable moans.  
For Yuu, the sensation of the tip being enveloped by soft, slippery mucosa then rubbed by vaginal folds was irresistible.  
Despite having ejaculated once, when he hit her vaginal depths, a climax-like pleasure ran through him.  
Three months since becoming intimate with his sister—though he'd used her pussy many times, the physical compatibility of blood relatives felt exceptional.  

"Ahh! Ahn, ahn, good! Yuu's cock... kua! Deep inside, coming deeper... I'm... cumming!"  

In the seated position with Yuu straight-backed and Elena connected from behind, she repeated hip movements with hands on knees.  
Yuu supported her movements with a hand on her hip but mostly let her take charge.  
Already, love juice dripped from their joining point, soaking not just the bed but the floor.  

"An onahole cumming before me?"  
"Hah, hah... b-because... Yuu's cock... nkuu... feels too good... hii... no moreee"  
"Can't be helped. Neé's pussy is too weak."  
"Sorryyy... cumming so fast from... little brother's cock... sorry for having a weak pussyyyy. Ahh! Really cumming! No... can't hold... aghh!"  

As Elena's hip movements accelerated, sticky *zucchu, zucchu* sounds leaked from their joining point.  
The hair shaking violently before Yuu's eyes was drying, while her smooth back glistened with sweat.  

Each *zun, zun* impact against her vaginal depths heightened Elena's moans until she suddenly arched her back and shuddered violently.  

"Kah... hah... agh! Cumming... aghn! Aaaaaaaaaaahhhhhhhhh—!"  
"Ngugh!"  

At that moment, countless vaginal folds tightly squeezed Yuu's cock, making him hug Elena from behind.  
Elena, having climaxed in under ten minutes of insertion, wore a blissful expression as she savored ecstasy.  

*Pan, pan, paa!*  

Still connected, Yuu turned Elena face-down on the bed and continued thrusting from a kneeling position.  

"Agh... agh... agh... Yu... u... ahee... so rough... my pussy... breaking..."  
"Ah... as expected, Saira beat me to it..."  

Elena was about to climax again, gasping for breath.  
Though she preferred this position since Yuu taught her, it also made her cum easily.  
Of course, to Yuu, Elena was full of weak points.  

"Anyway, I'm about to cum too."  
"In... inside... cum inside."  
"No way. You're on probation until you pass. Today I'll cum in neé's mouth. Drink it properly."  
"Agh! Ra! Aghh!"  

As if not allowing argument, Yuu began his final sprint, leaving Elena only able to moan incoherently.  
After continuous thrusting, Yuu pulled out at the last moment and hurriedly brought it to Elena's mouth.  
Though limp, Elena *paku* bit down the moment it touched her half-open lips.  
He came after just a few hip thrusts while holding her head.  

"Ick! Ugh!"  
"Nmo... mufuu... ogh!"  

*Dopun*—a massive amount of sticky semen must have spurted out.  
Elena's eyes widened but soon glazed over as she *goku goku* swallowed while savoring it.  

"Ah~n. Give me some too."  
"Nge!? Mufu—!"  

Revived Saira approached Yuu's crotch.  
As if not letting a drop go to waste, she groped Elena's body while trying to forcibly suck the cock still in Elena's mouth.  
Elena fought back.  
Seeing the sisters compete over his freshly ejaculated cock made Yuu smile wryly—they seemed to be playfully getting along despite everything.  

Elena tried to pull away from the cock to swallow the semen in her mouth, but it was too voluminous and sticky to go down smoothly.  
Suddenly Saira kissed her, trying to pry open her lips with her tongue.  

"*Amuchu... rero, nn, I can taste Yuu.*"  
"*Nna... stop... faa*"  

As Saira extended her tongue to lick the remaining semen, Elena—already made to cum multiple times by Yuu—could barely resist and gradually succumbed.  
But when both saw white fluid emerging from the tip, they began sucking the cock competitively.  
Yuu stroked both their heads, thinking to continue the double blowjob like this.  

---

### Author's Afterword  

And so, today Saira was first and Elena second.  

Characters like Saira—carnivorous and perverted—are relatively easy to write, or rather, they start moving on their own, which is enjoyable.  

### Chapter Translation Notes
- Translated "ネグリジェ" as "negligee" to convey the sheer nightwear
- Preserved Japanese honorifics (e.g., "Saira-neé" for セーラ姉)
- Translated explicit sexual terms literally (e.g., "onahole" for オナホ)
- Transliterated sound effects (e.g., "pachun" for ぱちゅん, "guchu" for ぐっちゅ)
- Maintained original name order (Hirose Yuu) and Japanese naming conventions
- Italicized internal monologues and emphasized sounds (e.g., *Nchu...*)
- Translated anatomical terms directly (e.g., "clitoris" for クリトリス)