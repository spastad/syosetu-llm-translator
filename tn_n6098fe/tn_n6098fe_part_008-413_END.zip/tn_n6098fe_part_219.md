## 205. Social Gathering ⑥ ~Shallow Sleep~

Eventually, after finishing the double fellatio and having Elena and Saira sleep sideways while holding each other, Yuu inserted himself alternately into both of them and completed the third round. He finished inside Saira.

While the two lay limply, Yuu rehydrated and went to the toilet, but during that time, he heard a heavy thudding sound like something falling over from the next room.

The Hirose family had been assigned Room 208. To the right of the hallway was Room 209 for protection officers Kanako and Touko, and the left side where the sound came from was Suzanna and Saira's Room 207.

Suzanna had probably returned, but concerned, Yuu thought he'd go check on her.

Looking toward the bed, Elena and Saira were sleeping quietly while holding each other, just like when he had ejaculated.

So Yuu hurriedly put on his underwear, grabbed his T-shirt and shorts serving as pajamas, quickly dressed, and went out to check.

As soon as he stepped into the hallway and looked toward Room 207, he saw the door was wide open.

"Excuse me..."

Somewhat concerned, he called out softly, but there was no response, and the room was pitch dark.

However, a faint smell of alcohol drifted in, and he sensed someone was there.

While closing the door, he turned on the light and saw Suzanna lying face down, her head turned sideways, collapsed right there.

"Suzanna-san!"

Yuu hurriedly rushed over and brought his face close.

Realizing she was just breathing in sleep, Yuu felt relieved for the moment.

She had been drinking at a high pace since Yuu was present, so she might have barely made it back to her room before collapsing here.

Martina hadn't returned to the room yet - either still drinking or having passed out drunk. He thought she must still be in the lounge.

In any case, he couldn't leave Suzanna sleeping on the floor like this, so he had to take her to bed.

Since she showed no sign of waking despite his calls, he decided to carry her.

"Excuse me."

Since she was face down, Yuu lowered his posture and used both hands to turn Suzanna's body onto her back.

"Uu~n..."

Suzanna let out a moan, but her limbs remained limp and relaxed, showing no sign of waking.

Just like that, he slid his arms under her shoulders and behind her knees, slowly lifting her up.

When carrying someone, the burden differs greatly depending on whether they're conscious or not.

It helps if they cling to you like Kanako did before going to the lounge, but when they have no strength, the burden is heavy.

That said, carrying the petite Suzanna to the nearby bed wasn't a problem.

Rather, her one-piece dress exposed a lot of skin, and seeing it up close like this stimulated his male desires, which was troubling.

Just as he carried Suzanna to the edge of the bed, Yuu realized something.

If he let her sleep like this, her outfit would get terribly wrinkled.

"U-um, I'll take it off...okay?"

He asked the sleeping Suzanna softly.

There was still no response, Suzanna just breathing softly with small sighs, though her originally pure white cheeks were flushed crimson.

Yuu didn't pay it much mind, assuming it was just the lingering effects of alcohol.

"H-how do I take this off...?"

Instead of laying her on the bed, Yuu sat Suzanna on the edge and held her from the front.

Suzanna's limp body leaned against Yuu, her head resting on his shoulder.

Yuu had more opportunities to help Martina and Elena change clothes, so his knowledge of women's clothing had increased.

One-piece types usually have fasteners or zippers in the back.

Suzanna's platinum blonde hair, exactly like Saira's, was braided at the back of her head, and Yuu had to avert his eyes from her mesmerizingly beautiful nape that kept drawing his gaze. Touching her hairline, he found the fastener and zipper.

After unzipping and opening the back, he could slip it off over her head.

That left only a light pink, semi-transparent camisole and panties of the same color.

Even with increased opportunities to see his mother and sister change, undressing another woman with his own hands stimulated his male instincts.

After taking a deep breath, Yuu gently laid Suzanna on the bed.

Then he hung the removed one-piece dress on a hanger.

"Um, pajamas...?"

Yuu looked around the room but didn't see any in an obvious location.

There were two carry-on cases in the corner.

They were probably inside, but he hesitated to rummage through a woman's belongings.

Thinking it might be fine to just cover her with a blanket since she was in underwear, Yuu approached the bed.

Since he'd undressed her and laid her on her back, she was sideways relative to the bed.

Once on the bed, Yuu changed her position to align with the bed while holding her in a princess carry.

"Okay, that's good."  
"Shamui..."  
"...!"

After laying Suzanna on her back, Yuu remained close by, and she clung to him while sleep-talking.

Not just with both arms, but also wrapping one leg around him - a hugging pillow state.

Being Yuu, he couldn't coldly push her away.

Somehow, he'd gotten used to the alcohol smell and it no longer bothered him.

Rather, touching Suzanna's skin directly, her soft limbs and faint sweat scent made him feel dizzy.

"W-well...can't be helped."

She seemed to crave human warmth more than any covering.

Yuu offered his left arm as a pillow and pressed his body close sideways.

His gaze was directed at her exposed shoulders, so he didn't notice her mouth relaxing.

Saira wasn't tall to begin with, but Suzanna was even more petite.

Holding her close, he could really feel how small she was, enough to stir protective instincts.

Her breasts visible through the translucent camisole lacked fullness, and her butt was small too.

Her figure was so slim it was hard to believe she'd borne a child, almost seeming fragile enough to break if hugged tightly.

Her youthful impression, enough to mistake her for Saira's sister at first meeting, remained unchanged even up close.

Her snow-white skin was fine-textured and smooth.

The phrase *(legal loli?)* even floated through Yuu's mind.

"If you cling to me like this...I-I'll do something naughty?"

When a beautiful woman in light clothing clings to you while sleeping together, it's only natural for a man to get aroused.

Of course, there was no response, but the person herself breathed peacefully with contented sleep breaths.

Yuu's right hand was on her waist where the camisole hem had ridden up, stroking her skin as if confirming its feel.

After stroking around her slender waist, he unconsciously moved down and squeezed her pert little butt.

His lips touched her bony shoulder, so he let his lips and tongue creep along to the base of her neck and nape.

"Nn...nnaa..."

A faint moan escaped Suzanna's slightly parted lips, but didn't reach Yuu's ears.

Not only was she clinging tightly, but her lower abdomen was pressed against his crotch, making Yuu react.

"Haa, haa, Suzanna...san"

As he savored her soft skin, he gradually felt desire welling up.

Yuu turned the body he was holding onto its back and gazed at Suzanna's face sleeping with defenseless expression.

Her rouge was mostly worn off, but her pink lips seemed moist and glossy.

"Kiss...just a kiss"

Unable to resist, Yuu pressed his lips there.

At that moment, Suzanna's eyebrow twitched and her eyelids lifted slightly.

But instead of opening her eyes, she just put a little strength into the arm wrapped around Yuu's back.

While stroking her cheek and head within reach of his left arm used as a pillow, Yuu kissed her over and over.

She's Saira's mother. Someone much older he just met today. After already ejaculating three times with his two sisters.

He could feel the brakes failing inside him.

If they'd just been talking normally, he wouldn't have thought of forcing sex like this.

"Ah, Suzanna-san...I'm sorry"

In this gender-reversed world, Yuu probably wouldn't be charged with a crime even if he assaulted her like this.

But feeling guilty about kissing and groping without consent, Yuu apologized.

All of this was because Suzanna had carelessly displayed her cute, charming figure. Having arbitrarily concluded this, Yuu used his right hand to lift up the camisole.

It seemed to have cups, and his fingertips entering the gap touched a modest swell.

Breasts small enough to be fully cupped in his palm.

Gently kneading without too much force, he pinched the nipple with two fingers.

"Fahh"

A sigh escaped Suzanna's mouth.

Yuu paused for a moment, but confirming Suzanna's eyes remained closed, a desire to see directly with his own eyes arose, and he lifted the camisole in one motion.

Breasts like gentle hills, not much different from his sister Elena's.

The areolae were small but the nipples were rather large and plump. Closer to wine red than pink - probably because they'd nursed a child.

Having come this far, there was no reason to hesitate.

Yuu suckled there like a baby.

"Ahn!"

Probably just sleep-talking.

Suzanna cried out in a girlishly cute voice.

Hearing this, Yuu continued caressing.

Licking upward with his tongue, then sucking chu-chu.

"Hah, hah...ahkuu..."

Suppressed moans leaked out.

Getting excited, Yuu moved his tongue broadly, licking all over sloppily, gently biting, and endlessly sucking on the nipple.

Meanwhile, Yuu's right hand descended from her side to her waist, sneaking inside her panties from the butt side.

After directly kneading her buttocks, it circled from her inner thigh to her lower abdomen.

Feeling sparse pubic hair in his palm, when his middle finger reached her private parts, it was soaking wet.

*(Even asleep, she feels it. I'm glad.)*

Feeling encouraged, Yuu sucked her nipple even more intensely while using two fingers to spread her labia, probing for her vaginal opening.

Suzanna's legs didn't close - rather, they spread open in sync with his right hand's movements, but Yuu didn't notice since it seemed natural.

Nuchu, nuchu, chupuu...

"Ah...ah...ahh...nn...afuun...hahyu! Aa...ii...feels...good!"

Suzanna's moans had already surpassed sleep-talking.

Being suckled like a baby by Yuu while being fingered made it hard to endure the pleasure.

Naturally, she stroked all over Yuu's head and back with both hands.

Even if small, breasts are breasts.

Yuu became completely engrossed.

He slowly licked circles around the gentle swell with his tongue, then opened his mouth wide to take the nipple in, making chu-pa chu-pa sounds while sucking.

His right hand repeatedly inserted two fingers deep into her vagina.

It was already squirting pshu-pshu, creating a large wet spot on the bed sheets.

"Ah, ah, ahn! Yu...U...already...ca...can't...nnaah! Iin! I...cummm...hyan!"  
"Suzanna...san?"

Lifting his face from the saliva-smeared breast, Yuu saw Suzanna with flushed cheeks gazing at him with moist blue eyes.

"Sorry. For attacking you while you were sleeping."  
"Yuu? No need...ahn! To apologize...it's...ah, ah, fine...keep going...please...more"  
"Suzanna-san!"  
"Yu...nmm!"

Yuu covered Suzanna's lips and thrust his tongue in with the same momentum.

Their tongues entwined like mating soft-bodied organisms, making wet, squelching sounds.

Meanwhile, Yuu's fingers never stopped moving.

"Nna...ero, leroo...fah...Yu...Uun...fine...uuaa! Ahh! Nnn! Nkuu...heah! Umm! Iiun!"

Each time Yuu's two fingers thrust in and out, the vagina that had been making nuchu, nuchu sounds tightened noticeably, and he felt it quiver biku-biku.

"Ihye, I...came...Yuu's fingers...felt so good. Ufuun"  
"Op!"

This time Suzanna grabbed Yuu's head and kissed him. He felt her small but clingy tongue enter as they tangled tongues relo-relo.

Her other hand reached from his back to his waist, trying to remove his underwear.

Yuu helped with one hand, and Suzanna's entwined legs skillfully slid it down.

"Like this...let's do it?"  
"Un"

Having come this far, few words were needed.

Suzanna's eyes were lust-drenched as Yuu's fully erect, hardened cock pressed against her. Since she didn't refuse, Yuu had no intention of stopping.

She was Saira's mother, whom he'd just met today.

He hadn't thought of having sex with her from the start.

No, perhaps not.

He'd found her attractive at first sight but hadn't thought of actively pursuing it.

But by coincidence, here he was on the same bed, driven by lust with failing brakes.

Careful not to put too much weight on the petite Suzanna, Yuu completely covered her.

As Suzanna's legs spread open in welcome, his cock pressed against her lower abdomen.

Feeling that heat and hardness, Suzanna's expression had already transformed into that of a female in heat.

"Ah...un, co...come...Yuu"  
"Ah, I'll put it in"

Suzanna seemed impatient even about removing her panties, using her own hands to shift the crotch aside to welcome him.

Kuchuri...zuchu! Zubuzubuu...

"Vuoh!"  
"Aaaah! Hu, hugeeeee! Ii, kuaaaaaa!"

At first, his cock was easily swallowed by the wet, soft vaginal entrance, but before halfway, it was blocked by the vaginal walls.

Being a mother who'd given birth, he thought it might go in easily, but contrary to expectations, it was tight.

Yuu put strength into the arms holding Suzanna and began thrusting in small movements.

"Su...Suzanna...ahh! So tight!"  
"Yu...Uuuu...i, it's big...haahn!"

When he finally thrust deep into her vaginal depths, kun, Suzanna's chin lifted.

Her white, slender neck exposed, Yuu couldn't help but suck there.

After a while, Suzanna slowly stroked Yuu's head and shoulders.

"Haa, haa...it's been a while but...'amazing' is the only word..."  
"It's been a while?"

At Yuu's question, Suzanna nodded slightly.

With miraculously youthful looks for her mid-30s that could pass for 20s, Suzanna was a Nordic beauty Japanese loved, yet petite and cute.

In the world before Yuu was reborn, men would have swarmed around her regardless of age difference.

Yet it was unbelievable that since parting with Sakuya through death, she hadn't had physical relations with anyone.

"When Saira came back...and I heard she was pregnant with Yuu's child, as a mother I truly blessed her.  
But when I met Yuu today, I felt envy. How awful. I guess I hadn't fully abandoned being a woman yet."  
"Someone as cute as Suzanna-san shouldn't say she's abandoned being a woman!"  
"Ahn! Moving...c-cute?"

While moving his hips little by little, Yuu hugged the blushing Suzanna tightly.

"Un. Very cute. Enough to make me forget myself and want to pounce."  
"U, happy...nmm...fuun"

Sealing her lips, he gradually increased his thrusting speed.

Suzanna's vaginal interior was narrow, especially the tip part squeezing tightly.

Because of that, it brought Yuu more pleasure than expected.

"Npaa! Ah, ah, ahi! Yuu...so rough! W, wait, I just came..."  
"Haa, haa, Suzanna-san's inside...feels so good..."  
"Kuaaaaaa! Sto, stop grinding...nooo"  
"Aaaaaah...good...Suzanna...san"  
"Yu...Uuuu...ahhiin! I, I'm...already!"

Yuu's thrusts were slow to acclimate to Suzanna's vagina.

But whether pushing or pulling, the internal folds provided strong stimulation.

Sweating, the two hugged each other tightly as if trying to endure the raging pleasure.

Suzanna reached climax first.

"Cumming, cumming, ahh! Yuu, so good! No! Nnn...ah, I'm cummming uuuuuuuuuuuuuuuu!!!"

Looking up at the ceiling and screaming, Suzanna came.

Meanwhile, Yuu wasn't exactly relaxed either.

"I'm about to come too. Can I...come inside?"  
"Hah, hah, hahi...inside, Yuu. Inside me, fill me up, pleaseeeee"  
"Nn!"

Hearing her almost shouting words, Yuu momentarily released the arms holding her and moved them down to her legs.

Grabbing behind her spread knees, he lifted them up while pushing his own body forward.

As both legs were lifted forward, Suzanna's butt also rose while still connected.

In mating press position, Yuu began thrusting slowly.

"Eeh! Wa, wait, Yuu! Th, this...d, deep! So deeeep!"

After all their coupling, Yuu's penis struck directly at the cervix that had descended as if craving seed.

Being thrust into in this position was overwhelming.

Suzanna trembled slightly with fear, tears welling in her eyes. Even as one of Sakuya's wives, she might have never experienced this position, or rarely been taken this way.

Still, her instinctive anticipation as a woman surpassed the unknown fear.

Suzanna's hands were firmly around Yuu's back, and she wrapped both legs tightly around his waist as if never letting go.

If someone had watched from behind, they'd have seen the originally narrow slit stretching gooey-gooey with each movement of Yuu's cock, whitish cloudy liquid dripping down her anus from the slight gap.

Zuchun! Zuchun! Zuchun!

Yuu's hip movements gradually intensified.

Accordingly, the wet sounds from their joining played out loudly.

"Hiuu...ah...he...raa, ah, ah, ah...sho...koo! Ooun!"  
At the overwhelming impact, Suzanna only leaked fragmented, wordless moans.

Yuu too was nearing his limit.

"Ahh! Suzanna...kuu! I'm...cumming!"  
"Yu...U...ki...kee...ahhi, hi...kuu...aoh! Oh! Nfo!"

Dokku, dokun! Dokun!

Yuu, with beaded sweat on his forehead, hugged Suzanna head and all, thrusting wildly as if prying open her cervix, and ejaculated.

Suzanna, having seed poured into her over time, swayed in unprecedented euphoria in Yuu's arms before losing consciousness.

---

### Author's Afterword

If Saira embodies a fairy-like appearance, Suzanna's motif is an elf. The old-fashioned flat-chested kind.

Also, I used as models Finnish beauties found by searching "Finnish beauties," including an incredibly beautiful swimmer.

As for when Suzanna actually woke up and was inwardly going "mufufu," I leave that to your imagination (laughs)

### Chapter Translation Notes
- Translated "合法ロリ" as "legal loli" to preserve the Japanese subculture term
- Rendered explicit anatomical terms directly ("チンポ" → "cock", "膣" → "vagina")
- Preserved Japanese honorifics (-san) and name order (Suzanna Yutilainen)
- Transliterated sound effects: "ぐったり" → "limply", "ずちゅん" → "Squelch!", "ぬちゅ" → "Squelch"
- Italicized internal monologues per style guidelines
- Translated sexual acts without euphemisms ("種付けプレスの体勢" → "mating press position")
- Maintained original dialogue structure with new paragraphs for each speaker