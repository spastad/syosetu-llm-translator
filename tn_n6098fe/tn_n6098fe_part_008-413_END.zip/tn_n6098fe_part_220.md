## 206. Kidnapping Incident ① ~BLOWIN'~

Rewinding time.

Around when Yuu reunited with Haruka, Martina, and others drinking in the lounge, a large truck was attempting to enter through the back gate by circling around the wall, submitting an entry permit to the stationed security guard.

"Ah, for that hole in the wall... Huh? Wasn't the construction supposed to start tomorrow morning?"

"Well, we got an urgent call asking us to seal it up as much as possible tonight."

"Is that so. Must be tough working at this hour."

"Not at all, not at all."

"Alright, you may proceed."

"Thank you~"

The truck advanced slowly with its engine roaring. The guard who saw it off noticed the heavily loaded cargo bed covered with a tarp. She assumed it was probably loaded with equipment and construction materials, not thinking much of it.

"Piece of cake, huh?"

"Don't be stupid. The real work starts now."

"Got it."

Inside the cab with windows closed and three women lined up, the youngest in the middle spoke mockingly, while the woman in her 30s by the window admonished her.

They wore matching beige work uniforms with company logos and hats to appear legitimate, but were actually members of the far-left extremist group calling itself the "Rescue Women Military Council." While no individual members were currently wanted, the group itself was monitored by public security police. Hence, they wore glasses or tea-colored wigs under hats to alter their appearances.

The slowly moving truck stopped near the edge of the employee parking lot at the building's rear, slightly away from the wall. Two of the three who got out began removing the tarp covering the cargo bed. Meanwhile, the woman posing as the supervisor went to call a staff member.

The Toyoda Sakuya Memorial Foundation's main building and annex are adjacent across a road. The annex premises are surrounded by 2-meter-high walls except for the main and back gates. While the front side has decorative elements, the sides and rear are plain concrete block walls. However, near where the truck stopped, a blue tarp flapped noisily with each gust of wind. Under strong floodlights, lifting the tarp revealed a nearly 3-meter-wide section of collapsed wall, creating a space easily stepped over.

"With such a dramatic crash, the driver must've been seriously hurt. What happened?" 

The middle-aged staff member who came to observe spoke in disbelief. Beyond the wall was a T-junction where the road split left and right. According to reports, the collision occurred early morning. Police investigating during daytime speculated a large vehicle had crashed while driving straight, possibly due to drowsy driving. The vehicle involved had left the scene, with police tracking it down.

The accident was caused by another member of the Rescue Women Military Council. The dump truck used was stolen and likely abandoned in some mountain forest by now. They came for "urgent repairs" that same day. Though essentially a false flag operation, they showed no hint of this, expertly examining the damaged wall sections and preparing.

The three had years of field experience, including at the construction company named on the truck, so they could genuinely perform repairs. Given the security risk, the administrative officer had commissioned the work from a contractor after getting an estimate. As the guard said, real workers were scheduled to come tomorrow morning—they'd be surprised to see progress already made. Their true purpose was infiltrating the building, but for now, they had to genuinely work to gain the staff member's trust.

Concrete block wall repairs couldn't be finished overnight. They planned a temporary fix to prevent passage. Unexpectedly, the supervising staff member proved talkative and curious, staying almost constantly except for bathroom breaks or fetching drinks, chatting or muttering to herself while watching. This forced the three to work seriously for nearly two hours.

Around that time, multiple voices and footsteps came from the building.

"Isn't it noisy over there?"  
"Huh?"

The supervising staff member looked toward the voices and saw several uniformed security guards running past under dim lights, responding to something on their transceivers.

"What's going on? I'll go check. Okay, carry on~"  
"Ah, yes."

She handed the permit with her stamped approval to the leader and left. The three exchanged nods, their expressions suggesting everything was going as planned.

They worked diligently for another hour with no staff returning. Concrete debris scattered on both sides of the wall was cleared away. Damaged blocks were removed to straighten the line, and new blocks were stacked two layers high. Reinforcement plywood panels on both sides temporarily prevented entry.

After finishing basic work, they stored materials back on the truck. One approached the cargo bed and called out.

"Come on out."

Sounds came from the tarp-covered section.

"Ah, finally we can get out..."  
"T-toilet... I'm about to burst!"  
"Do it in those bushes over there."

From a space cleared among equipment and plywood near the cab, four women in dark clothing emerged quietly.

With one driver remaining, six would infiltrate the building. They carried disposable cameras and video cameras to document the "shameless banquet," along with weapons like batons, large knives, and imitation guns for emergencies.

"Let's go!"  
""""""Yes!""""""

By the time preparations were complete, it was almost midnight. They assumed the banquet would last all night, but waiting too long risked missing their chance. However, intelligence from their S-team indicated nighttime security patrols, so they moved cautiously while hiding in shadows.

Earlier commotion at the main gate was caused by other members hiring local delinquents to cause disturbance by graffitiing walls. Most security guards were occupied there, allowing the six intruders to easily approach the building's rear unseen.

The woman who acted as supervisor earlier commanded the six. She had a simple floor plan in mind, choosing the kitchen's service entrance as entry point. The front entrance was out of question, and breaking windows might trigger security systems. The service door likely used a common cylinder lock—something one member could pick.

When a small *click* opened the lock, relieved sighs came from the women keeping watch. It took only three minutes, but they'd been anxious about guards appearing. The kitchen was pitch dark with no signs of people.

"Proceed as planned."  
"Yes!"

They split into two teams of three to search first and second floors. Whether successful or not, they'd withdraw in one hour. Documenting ruling party politicians or business leaders in drunken revelry with men would be ideal. Failing that, they'd break into offices to steal documents. They'd avoid detection by staff/guards, but wouldn't hesitate to use violence if discovered. Essentially, improvising.

Having infiltrated as construction workers, they needed to strike the foundation and its supporters.

---

After leaving the sleeping Suzanna in bed, Yuu exited the room. He considered returning to his own room but hesitated, worried about Martina who hadn't returned. He took a few steps toward checking the lounge but stopped. Past experiences taught him it was reckless for a boy to wander alone at night, even in the secure annex. Kitamura or Kujira would surely be awake. As he turned to get them, he heard noises near the staircase ahead.

*(Mom coming back?)*

Suzanna's condition flashed through his mind. Even a heavy drinker might stumble after such revelry. Yuu's concern for his mother overrode his safety. He hurried toward the sound.

He heard noises but no footsteps. Puzzled, he wondered if he'd imagined it. He'd check the staircase and if empty, go back for the protection officers. As he turned the corner where the stairs were—

"Tch!"  
"Huh!?"  
"O-oh, a male!?"

Yuu came face-to-face with someone in dark clothing and a mask—actually three people. Their voices and skin-tight outfits clearly identified them as women.

Yuu was shocked, but so were they. A scantily clad beautiful boy appearing suddenly froze their thoughts. In the 1-2 second standoff after the surprise encounter, the women recovered first. As intruders with basic training—including hostage drills for abducting important figures—they never expected a lone male wandering around.

"......"  
"Mmph! Ugh..."

The woman directly facing Yuu rushed to cover his mouth. Yuu naturally struggled, trying to push her away with his right hand and grab the hand over his mouth with his left. The woman, surprised by his strength, pinned him with full force. In this silent, sudden struggle, Yuu nearly overpowered her—but another attacker joined. A larger woman behind him locked his arms in a full nelson. Sandwiched front and back, Yuu was completely immobilized. Then a third woman pressed something hard against his side.

"Stay quiet if you want to live."

A gun-like black object entered Yuu's downcast vision as she hissed the threat.

*(These are real robbers? Seriously?)*

When Yuu stopped resisting, the gun-wielding woman deftly slid off her backpack with one arm and retrieved something. Quickly, they gagged Yuu with a rope gag and tightly bound his hands in front of him. The women exchanged glances, their mouths curling. Though they hadn't expected much from the second floor, they were delighted with this unexpected prize. Already, they'd forgotten their original mission, raking their eyes lustfully over Yuu's restrained body. Only the older leader hesitated about scouting further down the hall.

Huddled around Yuu, the three whispered:

"Second floor done?"  
"Take him back for interrogation."  
"The others will be pleased."

Yuu caught these words. His legs were free—could he escape or alert someone? He rapidly scanned his surroundings. But in the dead silence, no one approached, and he remained pinned from behind with a gun still pressed to him.

A decision came in under three minutes. The three women chose not to proceed further but to retreat. The large woman pushed Yuu from behind, forcing him to walk. They likely wanted to leave before being discovered. 

*(This is bad. Must alert someone.)*

Prodded from behind, Yuu panicked but saw no opening. One led the way cautiously down the stairs. Another kept the gun at his side. Even Yuu didn't want to die. The woman holding him from behind grew increasingly excited—her ragged breath against his neck felt repulsive now.

---

Meanwhile, the three who went downstairs successfully infiltrated the lounge but were disappointed by the unexpected scene. Some slumped over tables, others sprawled on sofas. Snoring and sleep-talking could be heard. About 8-9 women lay in disheveled drunken states—not a single male. Giving up quickly, they checked other rooms but found no one. They nearly ran into security guards, hiding frantically. With no choice, they broke into a dark office to search desks and lockers.

Given recent suspicious activity around the facility, the foundation wouldn't leave sensitive materials in obvious places.

"Damn! Missed our chance?"

After searching the first floor to no avail, the leader cursed and ordered retreat. Exiting through the kitchen door as they entered, they carefully returned to the truck unseen—noticing the second-floor team had returned with an extra person.

"Hey! That's..."  
"Yes! Seems to be a boy under the foundation's protection. If we take him back and interrogate him, we might get vital information."

Hiding their true motive—lust for this beautiful boy—the leader understood. Though calling themselves revolutionary warriors, they couldn't shed vulgar desires like violence and lust. 

But as leader, while her team achieved little, her subordinates captured a prime target. A boy under foundation protection might know undisclosed information—possibly connected to political heavyweights. Though convenient thinking born from high-stakes operations, her assumptions weren't far off.

Yuu was frantic. He'd be taken away unnoticed, making Martina, Elena, the protection officers, and other women worry desperately. He felt guilty.

Could he leave clues? Escape? As he pondered frantically while walking outside, he spotted something glinting on the ground. Instantly, he deliberately stumbled.

"Wh—!?"  
"Ungh!"

The woman was small—Yuu managed to shove her aside. Instinctively raising his bound hands as if bracing against the truck bed, he secretly extended the flathead screwdriver tip. His target was the lower part of a stacked 18-liter drum. No time to read labels—he hoped it contained colored liquid, not something clear. The screwdriver sank in with a *thud*. Leaving it would risk discovery and plug the hole, so he dropped it on the truck bed after pulling it out.

"What're you doing!?"  
"S-sorry! He suddenly—"  
"Mmph! Nn—mmph!"

Yuu inwardly smiled seeing black liquid seep from the small hole but kept his expression neutral. He shook his head in protest as if blaming the woman beside him.

"Quiet. Just move."  
"Y-yes..."

Yuu was roughly pushed onto the cargo bed. A woman already there pulled him into a narrow plywood-covered space. Originally seating four women snugly, Yuu was squeezed in. Forced face down, he was pinned from shoulders to feet. The engine started, and the truck began moving.

"Guhuhu. Young male."  
"Haa, haa. Smells... lewd."  
"Hey hey. Hold back till we're past the gate."

Three women began groping Yuu's back and thighs until someone scolded them. Yuu hoped his absence would cause commotion and get them stopped at the gate, but the truck passed through easily. Minutes later, as it accelerated onto a main road, the four women began freely molesting him.

---

### Author's Afterword

Yuu has finally been kidnapped. But I promise it won't become a depressing development.

### Chapter Translation Notes
- Translated "救女軍事会議" as "Rescue Women Military Council" per Fixed Terms
- Translated "猿ぐつわ" as "rope gag" for accuracy
- Translated "マイナスドライバー" as "flathead screwdriver"
- Translated "一斗缶" as "18-liter drum" (standard Japanese industrial container)
- Preserved song reference "BLOWIN'" without translation
- Maintained explicit threat dialogue ("Stay quiet if you want to live")
- Used gender-neutral "they/them" for ambiguous group references
- Kept Japanese construction terms like "ベニヤ板" (plywood) and "トロ舟" (mixing tub) with contextual explanations