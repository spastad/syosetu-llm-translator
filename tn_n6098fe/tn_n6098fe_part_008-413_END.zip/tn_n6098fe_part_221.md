## 207. Kidnapping Incident ② ~Holding a Sleepless Night~

""Hey! We're here. Get out""  
""""""What!?""""""

As the truck stopped, the woman who got out from the driver's side called out to those in the cargo bed.

""We've already arrived...""  
""I wanted to enjoy this longer""  
""This guy seems to have lost his voice from terror midway through""  
""Kuku""  
""Fuhihi""

The women who had been mounting Yuu's prone form from shoulders to toes while groping him leered vulgarly. But one closest to his face voiced doubt.

""Hey... could he be... asleep?""  
""""""Huh?"""""

These women lacked immunity to men and were sexually inexperienced. Having no idea how to stimulate a man, they satisfied themselves by groping freely. For Yuu who'd just had intense consecutive intercourse with three women, this felt like a massage. Combined with fatigue and the soothing truck vibrations, he'd fallen asleep.

""H-hey... wake up""  
""Nn... huh? Where is this? Who are you?""  
""Wawa! C-close! D-don't touch weird places!""  
""What are you saying? You were just groping me all over""

Yuu retaliated against the women by roughly squeezing their breasts within reach. But when their leader outside raised her voice, the women hurriedly brought Yuu down.

---

After speeding northwest on the nighttime highway for 40 minutes into Saitama Prefecture, the truck slowed in a rundown area avoiding Wakou City's downtown. It parked behind a building in an abandoned factory complex to avoid visibility. A two-story prefab structure—likely formerly an office—served as their temporary hideout.

The women weren't reckless enough to start gang-raping him. While Yuu was taken to a back room on the first floor, the leader and others went upstairs. From overheard conversations, they'd move to another distant hideout tomorrow, resting here tonight.

No electricity remained, so only camping lanterns lit the room. Windows were sealed with cardboard and duct tape to prevent light leakage. Two walls had tall steel shelves—likely storage—and another had cardboard boxes piled high, all dusty and dilapidated.

The only door was locked, and Yuu's hands were roped to a steel shelf pillar, preventing easy escape. Two junior members in their early 20s sat on pipe chairs guarding him—but stared in disbelief since Yuu had immediately fallen asleep on the center mat despite dust and mildew smells.

Both belonged to the S Squad handling reconnaissance and intelligence. They'd stayed behind during the infiltration since their faces might be recognized. When the team returned with this rare beauty, they were shocked—having devoted their school years to studying before joining political activism at Tokyo universities. Both remained enrolled but lacked graduation credits after four years.

""Gufu. His sleeping face is cute""  
""S-such sexy thighs""  
""Ha!""

Staring at Yuu curled fetus-like, they blurted out and exchanged glances. Their thoughts aligned: Though men appeared in town, guards prevented prolonged staring. But this boy lay exposed in near-underwear like an adult magazine model. His 16-year-old face blended boyishness with emerging masculinity, his lightly tanned limbs lean yet toned. A peerless beauty even among scarce males—a drool-worthy target. As women, how could they resist? Under "guard duty" pretext, they could stare freely without restraint, eyes glittering excitedly.

""C-can't we get closer for a better look?""  
""Huh!?""

The proposal startled her partner, who then relaxed and nodded.

""Y-yeah. To check if he's faking sleep... and doing anything suspicious...""  
""Oooh, calm down!""  
""You too""

Whispering like virgin boys before a barely-dressed sleeping beauty, they rose and crept closer. If he woke to their proximity, he might panic. Noise or struggle would anger superiors. Initially keeping distance, they drank in Yuu's body—but gradually closed in until smelling him at nose-to-skin distance.

""*Sniff sniff*. M-man's scent... Fha, fha, uhyeeeeee""  
""I-ih. How... lewd... so lewd! Keke, outrageous!""

Unaware their words would mark them as perverts, excitement overrode reason. Yuu had just had sex with three women, and sweat amplified his scent.

""Is he... faking sleep? Let's check""  
""Wh-what!? That's... a brilliant idea""  
""Right?""

Unable to resist just looking, they fabricated excuses to touch. When Yuu rolled over, they jumped back—but relaxed seeing it was just movement. They approached again from both sides as he lay supine. With no reaction at near-contact, they tentatively reached out. First lightly touching shoulders over his T-shirt. Feeling male firmness made them smirk. Their eyes darted from Yuu's face to neck, chest, and stomach before choosing different targets: right woman at bare upper arms, left at collarbone. Preferences differed. They sniffed with ragged breath.

""Aha""  
""Mufuu""

Growing bolder, they traced fingers over his T-shirt—chest, stomach. After circling knees exposed below shorts, they stroked thighs and smiled at the supple feel. Noses at his neck and hair, they sniffed euphorically, touching cheeks and hair. Knees pressed together, their own hands drifted to their crotches. But they lacked courage to touch Yuu's bulge—virgins paralyzed by male unfamiliarity.

""Fufu. That tickles""  
""Hyawa!?""  
""Eek!""

When Yuu opened his eyes and spoke, both women leapt back. He'd actually woken when they pressed close but watched amusedly.

---

Initially after kidnapping, Yuu felt anxious. Though valuable males rarely faced physical harm, criminal groups offered no guarantees. Pinned in the truck, he'd tensed—but their groping proved tepid. Brought here with mere guards, not assault, he'd relaxed after napping.

""Itai! Tsuu...""  
""Sorry sorry sorryyyyy!""

The right woman groveled in apology; the left crouched holding her head after hitting a shelf. Yuu felt slightly guilty—their touching tickled more than aroused him.

""Um...""

While the right still groveled, the left peeked at Yuu wincing in pain but averted her eyes when met. Long black hair hid her face.

Yuu hesitated how to treat his captors. Pleading for release was futile—these juniors held no authority. From earlier conversations, they wanted foundation intel, ransom, or sexual relief. Drawing from fiction, he knew his high value.

He couldn't leak foundation secrets. Ransom would burden loved ones. But sexual relief? That depended on the partner—he could counter-attack. These two clearly desired him. Time to manipulate them.

""Hey, I'm not angry or disgusted. Lift your face and come here""  
""Na!?""  
""Bweh?""  
""C'mon, I won't hurt you""

Amid awkwardness, Yuu smiled gently until both faced him.

The groveling right woman had braided pigtails and silver-framed glasses. Narrow eyes and freckled nose gave a plain, studious look. The left brushed aside her center-parted hair when approaching—revealing an oval face with large dark eyes, straight nose, and full lips. Beautiful, but expressionless. Neither wore makeup.

Both wore plain T-shirts (navy/gray) tucked into black sweatpants—unfashionable for twenties. Stains suggested manual labor. Both shorter than Yuu; the beauty was gaunt while the studious one had large breasts/hips with a cinched waist—great proportions. Her tucked shirt revealed bra patterns through fabric.

""I-is this okay? I'll touch you? Don't complain now""  
The beauty approached expressionlessly but nostrils flared—excitement returning. The type who feigned male disinterest while seething inside.

""Dehe... *slurp*... ha!""  
The studious one instantly leered, drool nearly dripping as she eyed Yuu's body. A rebound from her loveless study life—restraint gone before this defenseless beauty.

Both were repressed perverts. Perfect to exploit.

""Fine. Touch freely. Direct skin contact if you want""  
""W-what? Such a pretty face but such a slut...""  
""Aha... like a dream""

As they reached for his hem, Yuu smiled leisurely.

""Let's kiss first?""  
""""K-kiss!?"""""  
""But in exchange... let me touch your bodies too""

Having never touched a man, kissing existed only in fantasies—like pressing lips to male magazine photos. They gaped at Yuu's lips and bound hands.

---

### Author's Afterword

Reverse the genders: Instead of an innocent girl, the prank targets are a genuine slut with triple-digit partners. No matter their age, two virgins can't possibly handle the reins.

P.S. Coincidentally, three consecutive subtitles became 1992 hit songs.

### Chapter Translation Notes
- Translated "愉しんでいたかった" as "wanted to enjoy this longer" to maintain sexual implication
- Preserved sound effects: "ぐふ" → "gufu", "ふひひ" → "Fuhihi"
- Translated "むっつりスケベ" as "repressed perverts" to capture nuance
- Rendered "淫乱" as "slut" per explicit terminology rule
- Maintained Japanese name order: "祐" remains "Yuu"
- Italicized internal monologue: "（ち、近い！）" → *C-close!*
- Used explicit anatomical terms: "股間" → "crotch", "勃起" → "erection"