## 208. Kidnapping Incident ③ ~BOMBER BOY~

Before proceeding further, they thought it would be dull to not even know each other's names, so they exchanged introductions.

To Yuu's right was Wase Tamiko, a studious type with an exceptional figure. To his left was the slender, expressionless beauty Mita Yukiko. Both were 23-year-old university students in their fourth year with one year of extended enrollment.

No matter how lustful they were, they hadn't lost enough rationality to untie the ropes binding Yuu's wrists. So Yuu sat up and raised both hands. Before Tamiko could react to him leaning in, he suddenly lowered his arms - slipping her head through the loop of his hands and pulling her close. He sealed her lips while she was still dumbfounded.

"Muhii! Nn...nn...nfuu..."

Taking advantage of Tamiko's frozen surprise, Yuu pressed against her thin lips, savoring their softness. Seeing her face turn octopus-red upon realizing this was her first kiss, Yuu smiled and licked her lips with a *peron*.

"Faaaaaaaah"  
"Let's do more?"  
"Feh? Nmu!"

*Chu, chu, chu* - after repeating kisses multiple times, Tamiko seemed to grow somewhat accustomed. Her previously stiff expression appeared to melt. Though his hands weren't free, Yuu stroked Tamiko's head with his palm, drawing a pleasured sigh from her. Then Yuu boldly slipped his tongue inside.

"Nmo?!"

Yuu's tongue boldly ravaged Tamiko's oral cavity, prodding and licking the insides of her cheeks and gums before capturing her tongue in a sloppy tangle.

"No...fii...nn, nn, julu...nna...ra, aauuu"

After several minutes of oral pleasure, he pulled away with a string of drool connecting their tongues.

"Want more?"  
"Fai"  
"Open your mouth and stick out your tongue. Say 'ahh'"  
"Ahh"

This time their tongues intertwined just before their lips met. They exchanged a long, wet deep kiss with loud *chupa chupa* sounds before separating. The intense mucosal contact and saliva exchange proved too stimulating. With a dazed expression, Tamiko slumped against Yuu.

"Haa, haa, ranno... My face is hot. My heart's pounding..."

Indeed, Yuu could feel her heartbeat through the large breasts pressed against him. While stroking Tamiko's back with his bound hands, Yuu turned to Yukiko.

"Now it's Yukiko's turn"  
"Ah... no, I... re-really don't..."  
"I want to kiss someone as beautiful as Yukiko. Come on, it's okay?"  
"Hau!"

Yuu deployed his killer line against Yukiko, who desperately wanted it but couldn't be honest. Having barely ever spoken directly to a man, she felt thrown into a sweet romance drama scene, too confused to think straight. With Tamiko still leaning on his shoulder, Yuu lifted his clasped hands to embrace Yukiko's head, forcibly pulling her in to claim her lips.

*Chu, chu, chu! Aaan... Yuuuu, more!*  
"That's unfair! Too much kissing. N-now it's my turn!"  
"Ehh~"  
"Don't fight, take turns. Ahh, I wish I could touch both Tamiko and Yukiko's breasts. If only I could use both hands, I could pleasure you both at once."  
"P-pleasure? Ehehe"

While taking turns kissing Yuu, Tamiko and Yukiko became engrossed in directly stroking his chest, stomach, and back. Young male skin felt extraordinary to them. Already feeling good, they rubbed their inner thighs together. Hearing Yuu's words shocked them - men wanting to touch women was nearly unheard of in reality. But Tamiko, well-read in erotic literature from secret indulgence, grew excited at the idea of fiction becoming reality.

*Washi, momyumomyu.*  
"Anh!"

True to his word, Yuu reached out with both hands and groped Tamiko's ample breasts over her T-shirt.

"Ah, ah... it's okay. A b-boy... a boy is... groping my breasts... Feels... so good! Ahhaa"  
"These are great breasts. I wish I could touch them directly."  
"Uu... I'm jealous... maybe"  
"Yukiko's skin is so white and beautiful. While taking off my T-shirt, why don't you take yours off too?"  
"Ah..."

While continuing to knead Tamiko's breasts, Yuu whispered close to Yukiko's face. Their scales of desire and reason had long tipped toward desire. At this point, Yuu had no intention of escaping or causing a scene - rather, he was fully committed to seducing them. They accepted Yuu's proposal to free one hand while keeping the other tied to the pillar.

"Ahh...nnn...haaaaaah, why... why do my breasts feel... so good? Completely different... from touching them myself... uuun"  
"Fah!? Au au... st-stop sucking so... ha-hard... ah, ah, anh! I... I've never... felt like this... aun!"  
*Fufu. Feels good?*

When they stripped topless, Tamiko and Yukiko were captivated by Yuu's appearance, but soon accepted his lustful advance despite their surprise.

First, Yuu reached out with his right hand and removed Tamiko's plain white bra, revealing her large breasts. Though her shoulders and chest had no excess fat, the breasts themselves were visibly large - probably E-cup volume that couldn't be fully grasped. He squeezed the underside with a *taputapu* motion, then gently touched the small pale pink nipples near the center as if handling fragile objects.

After some practice, he grabbed them firmly from the front with a *gonyu*, sinking his fingers into the soft yet elastic flesh. When he pinched and stroked the nipples with two fingers, they quickly hardened and swelled *pukuu* as Tamiko's moans intensified.

Meanwhile, slender Yukiko's modest bust matched Yuu's expectations - similar to his sister Elena's size. Yuu loved small breasts as much as large ones and devoted equal attention. Enveloping them gently with his left hand, her nipples stiffened *pin* at the slightest touch, showing good sensitivity. Delighted, Yuu brought his face to one breast, licking *peropero* before sucking like a baby. Though Yukiko initially muffled her voice with her hand, she soon trembled *bikubiku*, leaking lewd moans.

"Nn...nfu. I want... my breasts sucked too..."  
"Sure. Tamiko's breasts look delicious too. *Anmu*"  
"Kyaaaaaah! Good! So good! Anh! Feels amazing! I-I could get addicted!"  
"Um... Yuu?"  
"Yeah. Yukiko's cute breasts too."  
"Ah!"

Accustomed to handling two partners, Yuu alternated sucking their nipples as requested. Though Tamiko and Yukiko occasionally touched Yuu's sensitive spots like his nipples while stroking his head and torso, Yuu dominated the interaction 1 vs 2, making them moan from the pleasure of his techniques alone.

After enjoying their breasts, Yuu moved to the next step, stroking their buttocks and thighs with both hands.

"Hey, why not take everything off?"  
"Haa, haa... ev-everything?"  
"Look. My pants are tight too."  
"!!!"

When Yuu thrust his crotch forward for the reclining women to see, Tamiko and Yukiko were left speechless.

They removed their sweatpants and then their plain panties (unfashionable even for middle schoolers). Tamiko had plump buttocks and thick pubic hair, while Yukiko's lower body was slender with sparse pubic hair.

When Yuu asked if they wanted to see him strip or undress him themselves, both said this rare opportunity shouldn't be missed and insisted on undressing him. So Yuu stood up and let them.

*Mufu, mufufufu. A boy's underwear! Underwear! Like this... I'll take them off!*  
"Fu, fu, fu"

It was like virginal male college students lifting a beautiful girl's (16) skirt - neither could hide their excitement. Tamiko's grinning face showed trembling, sweaty hands while Yukiko maintained her expressionless silence but with increasingly rough breathing. Though creepy to an observer, Yuu waited with a wry smile.

Though less noticeable than jeans, Yuu's half-pants clearly showed a massive bulge at his crotch.

As Yuu warned, they lowered his half-pants and trunks while spreading the waistband wide to avoid catching the tip. Finally, his proudly erect penis entered their view.

"Geh... wh-what... is that?"  
"Buh!"

Though they'd seen the bulge over the half-pants, the unexpected size and grotesqueness left Tamiko speechless with a gaping mouth. Yukiko dripped nosebleeds at her first real sight of male genitalia.

Yuu smiled smugly at their shocked faces - a man enjoys such reactions. So he showed off by bringing his bare cock near their noses alternately, even thrusting it against their cheeks. Though dry now, the mingled scents of vaginal fluids and semen from three ejaculations hung thick in the air. Unaware, their own pussies grew moist from the potent sexual aroma.

"Oh my, Tamiko's pussy is already dripping wet and loose?"  
"Ah! St-stop! Uhi, your finger... deep inside... ahhaa, Yuu's finger... feels so good!"  
"Will you cum from just fingers?"  
"Raah, ihii... better than my own fingers... gimoooooo! Ah, ah, ah... I'm gonna... cum... oh... more!"  
"There there, it's okay. Cum."  
"Hyaaaaaaaaaaah!!!"

*Lerolero. Hohou. Yukiko's clitoris is so swollen."  
"Nnaaaaah! Ii... st-stop... there... too sensitive! Nnnn!"  
"By the way, how often do you masturbate, Yukiko?"  
"Th-that's..."  
"Tell me?"  
"Aau! Clit... no! I-I'll talk... um, once every... 3 days"  
"Really?"  
"Hyaa!"  
"Be honest?"  
"Wh-when I'm home... ev-every day"  
"Which feels better? Vagina or clitoris?"  
"Cl-clit"  
"Then as a reward... here"  
"Nyao!"

With Yuu sitting cross-legged, Tamiko and Yukiko faced him from either side, slightly lifting their hips as they played with each other's genitals. Overwhelmed by his cock, they began handjobs while mesmerized by its hardness and heat at Yuu's urging. Yuu alternated deep kisses while kneading their breasts, his hands moving down to their lower abdomens.

Having heard both had broken their hymens from excessive vibrator use during masturbation, Yuu held nothing back. Once proper fingering began, they became too lost in pleasure to focus on his cock, leaning on Yuu's shoulders while moaning constantly. Though inexperienced with men, both were masturbation addicts. Yuu's fingers brought pleasure beyond their imagination.

Tamiko came first from two fingers thrusting deep inside, but Yukiko followed soon after, spraying *pusha pusha* as her clitoris was pinched.

"Haa, haa... I've never felt... this good. Ahhaa~n"  
"Fu, fu, fu... Yuuu... *chu, anmu*"

With both palms soaked in their fluids, Yuu kissed Yukiko's thoroughly melted face, then Tamiko.

"It's unfair you two came already. Now it's my turn."

Yuu smiled as he considered which one to take first.

---

### Author's Afterword

The main event will be in the next chapter.

By the way, the women's names in the "Kidnapping Incident" arc are just playful choices with no special meaning.

### Chapter Translation Notes
- Translated "ガリ勉タイプ" as "studious type" to convey bookish appearance
- Preserved sound effects through transliteration (e.g., "ちゅっ" → "Chu")
- Used explicit anatomical terms as required: "pussy," "clitoris," "semen"
- Maintained Japanese name order: Wase Tamiko, Mita Yukiko
- Translated sexual acts without euphemisms: "fingering," "handjobs," "ejaculation"
- Preserved honorifics and Japanese terms like "onahole" from previous context
- Rendered internal reactions in italics per style guide