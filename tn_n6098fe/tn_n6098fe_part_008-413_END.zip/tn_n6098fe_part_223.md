## 209. Kidnapping Incident ④ ~LOVE'S SELF-DESTRUCT DEVICE~

"Hooh, well now... what a magnificent view."

Though both were thoroughly aroused, neither had proper experience with men.  
Zero multiplied by any number remains zero. They couldn't match Yuu who had triple-digit experience.  
In fact, they learned that letting Yuu take the lead would bring them more pleasure.  
So Wase Tamiko and Mita Yukiko obediently followed his instructions.  

Now on the mat, Tamiko lay on her back while Yukiko lay face-down on top of her, their legs spread wide with lower abdomens pressed together - exactly as Yuu directed. He enjoyed the sight of their freshly orgasmed, dripping pussies stacked vertically before him.  
Bringing his face closer, Yuu used both hands to spread them open and began licking alternately up and down.  

"Hyauu! Nkhuun..."  
"Vuaah! Ah, aah..."  
"Amazing. You're both flooding like crazy."  
"B-because... having a boy lick me there... ahah, my pussy's so happy!"  
"M-my body... becoming like this... ah, i-it's good!"  

Though thoroughly fingered earlier, being licked felt extraordinary. As Yuu's broad tongue swept up and down, love juice overflowed like abundant springs, creating loud picha picha splashing sounds.  

"About time, I'd say."  

Continuing cunnilingus until they came would've been amusing, but Yuu himself couldn't hold back anymore.  
Crouching between their thighs, Yuu rose up and groped Yukiko's ass with his right hand and Tamiko's with his left. Pressing his hips forward, he rubbed his erect cock against them alternately. Immediately, his glans became coated with their love juices.  

"Now then, who should I enter first?"  
"Ah...ah, I w-want it. Yuu's cock. Put it in, put it in, please!"  
"Ugh..."  

For both, this sudden chance to lose their virginity - especially to a beautiful younger boy like Yuu - was a once-in-a-lifetime opportunity. Tamiko begged openly, knowing she might never get another chance.  
Meanwhile, Yukiko stayed silent with a flushed face but finally turned around with desperate determination.  

"Yu...Yuu! I'm begging you... p-put... that magnificent cock... i-inside my pussy... j-just the tip is fine!"  
"Hmm..."  

Yuu wanted both, but knowing someone might interrupt, he felt their desperation. Though misapplied, Yuu was moved by the usually expressionless Yukiko pleading so desperately.  

"I'll give you more than just the tip."  

Saying this, Yuu grabbed Yukiko's petite buttocks with both hands, spread her vaginal opening, pressed the tip against it, and thrust in.  

"Vuaah! Aah! Aah! Ahg! Oooh... too b-biiiiig!"  
"Kufuu... tight indeed... oof, quite the challenge."  

Though the glans was swallowed, Yuu's cock was blocked by vaginal walls before reaching deep. Despite her hymen being broken by vibrators, Yukiko's vagina - unused due to clitoris-focused masturbation - remained virgin-tight. Feeling it squeeze back against the intruder, Yuu involuntarily moaned.  

"Yukiko, relax."  
"Ah... hiiiiii... haaaaaa... aahn!"  

While thrusting shallowly with his left hand gripping her hip, Yuu stroked Yukiko's back with his right hand before reaching around to pinch and pull her nipple. Virgins often tense their lower bodies, so distracting them makes insertion easier.  
As Yukiko began moaning sweetly from her sensitive nipples being teased, Yuu put strength into his hips.  

"Now!"  
Thump!  
"Aaun! I-It's... in!?"  
"Oof. Yukiko's pussy is so tight, squeezing me... feels amazing."  

Though almost too tight to move comfortably, the intense squeezing felt incredible even without thrusting.  
To move easier, Yuu covered Yukiko's back while supporting himself like in a push-up position.  

"Tamiko, am I too heavy?"  
"N...no. Not at all. Hey... I'm waiting, hurry up."  
"Hmm... wait a bit."  

Pacifying Tamiko who was kept waiting, Yuu began moving slowly. He had a plan but needed to acclimate more to Yukiko's vagina first.  

The tightness made movement difficult, so he slowly pulled out. When the glans was nearly out, he slowly pushed back in as if savoring the internal sensations. Repeating this gradually changed Yukiko's vocal tone.  

When pulling out:  
"Ooh, ooh, ouaah! Ahi! Wha... what is... ah! Like I'm being... pulled... ohii!"  

When thrusting in:  
"Hahi, hahi, it's coming! Coming! Inside me... oh cock! Oh cooock! Aah, goooood!"  

Her previously expressionless, quiet demeanor seemed like a lie compared to this disarray. Thankfully, movement gradually smoothed out.  

"Okay. Time for the switch."  

When Yuu suddenly pulled his cock out, Yukiko turned around with a stunned expression.  

"Why... did you pull out?"  
"Figured I'd take turns."  
"Ah"  

As Yuu brought his face close and stuck out his tongue, Yukiko also extended hers, tangling their tips.  
Plop, plop - their mixed saliva dripped onto Tamiko's cheek. Tamiko finally had her turn, her face full of anticipation - especially after watching Yukiko's pleasured expressions.  

"Ah, Yuu... y-your cock! Give it to me!"  
"Yeah. Here goes."  
"Hya... i-it's... ooh! So... so biiig!"  

After waiting so long, Yuu thrust fully into Tamiko's soaking wet entrance. Perhaps because she'd used vibrators, her virgin pussy didn't feel as tight as Yukiko's. Instead, her internal temperature was higher, with folds gripping his cock tightly.  

"Ooh... Tamiko too... kuh... feels amazing! Dangerous."  

Though he'd ejaculated three times before midnight, time had restored his sensitivity. Penetrating virgins consecutively heightened Yuu's own excitement and pleasure. Still, he endured.  
Hugging both Tamiko and Yukiko from above, fully covering Yukiko's back, Yuu paused after penetration before slowly starting to thrust.  

"Aah! Aah! Aaah... oh cock! The cock... bumping deep inside... ahah! My baby room... ahah! That bumping... so intense... I don't know this feeling... oh! Ooh! I'm cumming... Yuu, I'm cummiiing!"  
"Ah... good! Cum then!"  

After enduring ejaculation to acclimate his cock inside Tamiko, Yuu alternated thrusts between their stacked pussies. The advantage was taking intervals during heightened pleasure. He could enjoy their differently textured vaginas.  
Though experienced, making virgins cum first was difficult. But this method successfully brought Tamiko to climax.  
Smiling contentedly, Yuu pulled his cock from Tamiko's pussy, glistening with cloudy genuine juices. He rubbed the tip against Yukiko's slightly open entrance.  

"Ah... no... Yu...u... don't tease... hurry."  
"Want my cock?"  
"Nn... want your cock. I want... to cum... from your cock too."  

As Yukiko spoke, her vaginal entrance tightened around the tip. With such begging, Yuu had to respond.  
Thrusting in fully, he struck deep inside. Increased love juice made it smoother than the first penetration.  

"Ah! Aaaaaaaah... guh!"  
"Guuh!"  

*(Damn... I'm gonna cum. Then... who should I cum in?)*  

Though intervals helped when pulling out, the new pleasure upon re-entry was uniquely virginal. Trying to endure until Yukiko came, Yuu slowed his movements while deciding whose pussy to fill.  

"Aaah! Cumming! Cumming! Yu...u... that cock grinding! Ahe... no more!"  
"Yu...Yukiko... cum!"  

With almost no pain, only incomparable pleasure - unlike masturbation - crashing over her in waves, Yukiko reached her limit while feeling euphoric from Yuu's body heat covering her back.  

"Gooood, cummiiiiiiiiing!!!"  
"Kah! Me too!"  

At that moment, Yuu pulled his cock out completely and forcibly sandwiched it between Tamiko and Yukiko's overlapping pussies.  
Then, he rubbed his hips against the soft flesh crevice.  

"Kuoh! Oh! Cumming... now!"  

With Yuu's cry, cum erupted like a geyser - pyururuu! - powerfully spraying up to their chests through the narrow gap, sticking thickly.  

""Aah!""  

After several bukubuku spurts, Yuu went limp atop them.  

"Fuu~ Both your pussies felt amazing."  
"Thi...this is... semen?"  
"R-real!? This much...?"  

While stroking both heads contentedly, Yuu basked in satisfaction.  
Their lower abdomens still sandwiched his hard cock as they felt the heat of the splattered cum, shocked by the thick white fluid coating them.  

***

After lingering in the afterglow piled together - Yuu, Tamiko, and Yukiko - the locked door shattered the moment.  

"Y-you! Wh-what are you doing!?"  
""Sh-shit!""  

A woman in her late twenties pointed at them, looking ready to faint before turning heel. She'd surely gone to call others.  

Though panicked at being discovered, Yuu remained calm while Tamiko and Yukiko scrambled for underwear and track pants. They stared in shock as Yuu sat calmly naked.  

"It's fine. Leave it to me."  
"H-haa..."  

Soon, several women came running - bang! The door slammed open.  
Silently entering was a large-framed woman in her early thirties with sharp eyes and dangerous expression.  

"Leader! They abandoned guard duty for selfish pleasure!"  
"Unforgivable behavior unbefitting revolutionary warriors!"  
"Organization doctrine states men are communal property!"  
"Low-rankers daring... this requires ""summary""!"  
""""""Summary"""" now!""  

Their accusations seemed driven by jealousy. Tamiko and Yukiko paled - ""summary"" meant lynching here.  

The leader stepped forward. But Yuu stood up, shielding Tamiko and Yukiko.  

"You... your hands?"  
"Still tied, as you see. More importantly... I'm not nearly satisfied. Will you big sisters play with me?"  

Actually, many women outside the open door were already staring hungrily at Yuu's nakedness. Though not fully erect after resting and the interruption, the newcomers marveled at the size.  
His handsome face, slender but toned body, and glistening cock displayed proudly - like an incubus from legends.  

***

### Author's Afterword

In this chastity reversal world, incubi (male succubi) are extremely popular.  
They frequently appear in media, so readers likely superimposed Yuu's naked form onto them.  


### Chapter Translation Notes
- Translated "愛の自爆装置" as "LOVE'S SELF-DESTRUCT DEVICE" maintaining the explosive metaphor from previous chapter titles
- Translated "総括" as ""summary"" with quotes to preserve the disciplinary euphemism
- Rendered explicit anatomical terms directly ("pussy", "cock", "cum")
- Preserved Japanese sexual slang ("おマンコ"→"pussy", "おチンポ"→"cock")
- Transliterated sound effects ("ぴちゃぴちゃ"→"picha picha", "どぴゅるぅ"→"pyururuu")
- Italicized internal monologue per style guidelines
- Used explicit terminology for sexual acts without euphemisms
- Maintained original name order ("Wase Tamiko", "Mita Yukiko")
- Translated "インキュバス" as "incubus" per mythological accuracy
- Applied simultaneous dialogue formatting for group shouts (""""""Summary"""" now!""")