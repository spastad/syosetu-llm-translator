## 210. Kidnapping Incident ⑤ ~Virgin Shock!~

Hongou Kyouko (32 years old).  
Originally a promising wrestler who entered the prestigious Nittou Physical Education University, she had to abandon her athletic career after injuring her back during her second year.  
While idly drifting through life, she was introduced by an upperclassman from another school to an anti-government group advocating complete female supremacy.  
Being fundamentally serious, she not only quickly absorbed their ideology but was recognized for her enthusiastic participation in struggles, eventually being promoted to combat unit executive within the group.  
Through numerous demonstrations involving clashes with riot police, her body became etched with scars - medals of honor in her eyes.  

Later, after joining the large-scale Japan Women's Rescue Alliance and devoting several years to student activism, Kyouko broke away with radical ideological leaders to become a member of the Rescue Women Military Council.  
There too, she commanded struggles nationwide as leader of temporarily assembled combat units.  

Though a college dropout who remained a virgin, Kyouko had participated in several gang rapes (including attempted ones) with comrades during her twenties.  
However, they always avoided well-protected virtuous men, targeting only impoverished middle-aged men who flirted with women in back alleys for pocket money - all of whom managed to escape.  

The August 25th attack on the Toyoda Sakuya Memorial Foundation annex ended in frustration without achieving its primary objective.  
But by chance, members of another unit accomplished the extraordinary feat of kidnapping an unbelievably beautiful boy.  
Though uncertain of his exact importance to the foundation, his value as a hostage was undeniable.  
Perhaps due to her earnest nature, Kyouko never considered using her leader's authority to "sample" him herself.  
After bringing him to a temporary hideout and confining him in a locked room under guard, she planned to rest overnight then transport him to a mountain villa in Tama, leaving decisions about the beautiful boy's utilization to the council chair and executives.  

But after barely two hours of sleep, a displeased Kyouko descended the stairs toward the back room on the first floor without hiding her irritated expression.  

***

"More importantly... I'm still not satisfied at all. Will you play with me, big sis?"  
"Wha... wha... wha..."  
"Hey... isn't that huge?"  
"It shouldn't even be erect yet, right?"  
"Then... what happens when it gets hard?"  
"More importantly, why's he so confident?"  

While Kyouko stood speechless with gaping mouth, her comrades whispered behind her back.  
A young male standing naked with such confidence was completely beyond their expectations.  
Common sense dictated that any male surrounded by so many women under their gaze would be mortified, hiding his privates while curling up.  
But this beautiful boy?  
The supposedly superior numbers left Kyouko's group flustered instead.  
Realizing this wouldn't do, Kyouko steeled herself and stepped forward.  

*(Shit. Seriously handsome. I'm nervous!)*  

Even when facing him directly within arm's reach, rather than showing fear, the boy wore a relaxed smile.  
If anything, Kyouko felt internal pressure.  
Yet she maintained composure - perhaps due to her pride as this situation's leader.  
Her frustration at seeing the two junior members she'd assigned to guard duty now happily embracing each other fueled her determination.  

"F-fuhn. Quite the bravado you're showing.  
Y-you might've charmed those juniors, b-b-but... th-that confidence ends... here!  
H-had you obediently followed our orders, you might've avoided unpleasantness... T-too insolent boys... need disciplining.  
R-regret this?"  
"Leader's amazing! Doesn't matter if he's handsome or young - men are nothing before women!"  
"Show him men can't match women after all!  
With your experience, Leader, you definitely can!"  
""""Leader!""""  
"Leave it to me."  

Despite her words, Kyouko felt uneasy.  
True, she had male experience.  
But only twice had she forced insertion during gang rapes of fifty-something men - semi-erect, pathetic things after ejaculation that ultimately went limp without receiving semen.  
Long ago during drinks with comrades, she'd exaggerated about having more experience than she could count on one hand.  
She'd even boasted she could make any man whimper.  
Having built trust through lies, she couldn't possibly correct them now.  

*(Whatever happens, happens!)*  

Resigned, Kyouko boldly stripped off her skin-tight black tank top, spats, and plain panties (black but bloomer-like and unsexy).  

***

◇ ◆ ◇ ◆ ◇ ◆  

*(Whoa. Amazing body)*  

Yuu gazed admiringly at the leader's fully nude body displayed unashamedly before him.  
Her height was impressive - about 185cm.  
Messily cropped short hair and hawk-like sharp eyes, yet her features were well-proportioned and not unattractive.  
Her chest, arms, and thighs were solidly built, with impressively defined abdominal muscles.  
Not excessively muscular like a bodybuilder, but rather like armor-clad for battle.  
Scars on her shoulders, abdomen, and thighs testified to past struggles.  
Yet her voluminous breasts thrust forward, asserting her femininity.  
To Yuu's eye, her physique rivaled protection officer Kanako's.  

Perhaps instinctual, but men typically prefer women shorter and smaller than themselves.  
Before rebirth, Yuu was like that too.  
But in this gender-role-reversed world, with minimal height differences, many women towered over the 170cm-average Yuu.  
Indeed, many past sexual partners had been taller: family members Martina, Elena; protection officer Kanako; nurse Shiho; half-sisters Kiyoko, Satsuki, Mana; countless schoolmates like Riko, Yoko, Mao, Sati.  
Even if taller, Yuu felt no resistance toward attractive women.  
Rather, he'd come to enjoy sex with tall women.  

Thus, even facing Kyouko who'd intimidate ordinary males, Yuu felt desire.  
Proof: his lower body's male symbol swelled in response to her nudity. As she came within reach, Yuu embraced her.  

"Huh?"  

Before Kyouko could react to male skin contact, Yuu tightly hugged her, his left hand seizing and kneading her breast while his right hand cradled her head, pressing their lips together.  

"Mmmpf!?"  

Startled, Kyouko tried pulling away but was drawn back by unexpected strength for another kiss.  
His left hand pleasurably squeezed the breast's resilience, fingers working the nipple.  

"Mmph... u... ah... nn! Nn! Nnn!?"  

Crimson spread across Kyouko's cheeks as their lips remained joined.  
Somehow, having her head stroked felt good.  
Confused by the hard, hot thing pressing against her lower abdomen yet unable to think straight. She nearly surrendered to the comfort.  

"MMPH!? Ugh... eh... wha... nmoah"  

Amidst the silenced onlookers, the two exchanged passionate embraces and kisses.  
Then Yuu's tongue slid wetly into Kyouko's mouth.  
Her eyes widened at the first-time experience, but mucosal contact seemed to deliver sweet pleasure to her brain, making her narrow her eyes blissfully.  
As fingers continued playing, her nipples stiffened, her upper body trembling slightly with each stimulation.  
In her limited experience, she'd never received male caresses.  
Bombarded by confusion and unknown pleasure, Kyouko couldn't resist, yielding to Yuu's actions.  

"Nmmph... nn, schlurp... ero, lerooo... aahn... kuh... ah... fuu... nnn!"  
"Don't know why, but that's erotic."  
"As expected of Leader. To possess techniques that bewitch even such a beauty."  
"J-just watching makes me..."  

Inexperienced comrades saw only Kyouko's back with Yuu hidden behind, misunderstanding her as the initiator.  
After prolonged deep kissing, Yuu smiled before Kyouko, tongue wetly protruding from his half-open mouth.  

"Tell me your name."  
"Ho... Hongou... K-Kyouko"  
"Kyouko. I'm Yuu."  
"Yu... u..."  
"More kissing?"  
"Y-yes!"  
"Open your mouth. Stick out your tongue."  
"Nn... amoh! Nn, julu... nfuun..."  

While deep-kissing again, Kyouko clung tightly, savoring the male body's feel.  
Neither bony nor flabby - young, firm muscle made her heartbeat quicken, a tingling ache stirring deep in her lower abdomen.  

"Hehe. Kyouko's got an amazing body.  
Now... what about down here?"  

With mouths open, tongues audibly entwining - *chupp*, *chupp* - Yuu's right hand descended southward.  
His left hand, unsatisfied with one breast, now kneaded both, tormenting nipples.  
Fingers traced her thinly-haired mons pubis then unhesitatingly reached the cleft, stroking the labia surface before confirming its wetness and penetrating inside. *Squelch*.  

"Soaking wet already. Ready?"  
"Y-y-yes! Hah... hah... hah... Wanna do it wanna do it wanna do it... OOOOOOOOOOHHHHH... COOOOOOCK!!!"  
"Whoa!"  

Like an excited wild boar, Kyouko lifted Yuu effortlessly with ragged breaths.  
Stunned were not only the comrades behind her but also Tamiko and Yukiko who'd just been in a threesome with Yuu.  
As they scrambled off the mat, Kyouko lowered Yuu while holding him.  

"III'm putting it in!"  
"Ah, ready here too."  

With Yuu's hands behind his back, Kyouko aligned the stiff cockhead with her vaginal opening and lowered her hips.  
The glans sank in deeply but unexpectedly jammed against vaginal walls.  

"Heeeh!?"  
"Oooh..."  
"Aga... wh-what's... s-so hard... and huge!"  

Her vagina had only accepted flaccid members before.  
Kyouko's body weight forced Yuu's cock partway in, bringing pain alongside piercing pleasure as it stretched her.  
Yuu felt the same but grew impatient with the partial insertion. Instinctively, he gripped Kyouko tightly.  

"Not fully in yet? C'mon, more."  
"Wai... AHHH!"  

Burying his face in the valley of her firm, elastic breasts, inhaling female sweat, Yuu strengthened his grip on her shoulders and waist.  

*Thud!*  
"Oof... foh!"  
"Kuh. In. A-amazing tightness."  

While Yuu had some leeway, Kyouko could only gasp wordlessly.  
Past experience involved mere entrance penetration - now a hard shaft forcibly widened her vaginal canal, ramming deep into her womb. Unbearable.  
That instant, sparks seemed to fly in her mind while magma-like sensations surged from her abdomen.  

***

"AHH! Ooh! Ooh! OOAH! FOHUN! Shokoraaameee... IGGH... cumming... can't... cumming! Oh! Oh... Yu... ah... AHH! AAAAAAAAAAAAHHHHHHHHHHHHH!"  

How long had it been since they connected in seated position?  
Tossed about by Yuu's relentless thrusts, Kyouko reached an uncountable climax.  

"Kufuu. Kyouko's pussy feels amazing. Your tits are delicious too. I'll suck them properly next time."  
"Hyuunn! St... ah... ahn!"  

As Yuu *chuu chuu* sucked the swaying breasts before him, Kyouko moaned with girlishly sweet gasps.  
Being suckled like a baby affected her more than expected.  
Each womb-pounding thrust brought relentless heat surges from her lower abdomen - irresistible.  
Thoroughly stimulated in her feminine instincts, Kyouko exposed her female nature through moans.  

*Slap! Slap! Slap!* - flesh-smacking sounds echoed with each lift of Yuu's hips that bounced Kyouko's body.  
By now, who held dominance was obvious.  
None had witnessed such fierce sex where genders clashed bodies and lust. Visually, olfactorily, aurally - their senses were erotically assaulted.  
Some even crouched to peer at the joining point while frantically rubbing their inner thighs for relief.  

"Kuh... almost... my turn...!"  
"Ah... ahi, hahi... w-wait, why... doing... feels too... good... raaah, cumming... OOH! OH! OH!... D-dying! Hyaah! AGH"  

As Yuu entered his final sprint, Kyouko could only gaze skyward with intermittent inarticulate moans.  
Yet she wrapped not just her arms but long legs around Yuu's body - perhaps female instinct seeking male essence.  
Yuu too tightly embraced Kyouko's sturdy form, achieving climax while fused as one.  

"Guu... cumming! Cumming hard! Lots... cumming!"  
"AAAH! I... ih..."  

Kyouko drowned in the day's greatest pleasure wave as semen pulsed powerfully into her womb.  
Throughout the long ejaculation, unable to speak, trembling violently, she finally lost consciousness.  

### Chapter Translation Notes
- Translated "ワレメ" as "labia" to maintain anatomical precision per style rules
- Translated "おチンポ" as "cock" to preserve vulgarity level of original Japanese slang
- Transliterated sound effects: "ぱくぱく" → "gaping", "ずんっ" → "thud", "ぱしん" → "slap"
- Preserved Japanese name order: "Hongou Kyouko" (本郷 京子)
- Italicized internal monologues per style guidelines
- Translated sexual acts explicitly without euphemisms ("penetrated", "ejaculates")