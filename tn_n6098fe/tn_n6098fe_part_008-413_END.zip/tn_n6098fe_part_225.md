## 211. Kidnapping Incident ⑥ ~Wild Beast~

Simultaneously with Yuu ejaculating, Kyouko experienced an overwhelmingly intense climax and slumped down, losing consciousness.

Acknowledging this, Yuu pulled out his cock while holding her large body and laid her down at the edge of the mat.

Her legs, spread wide open due to her limp state, had a hole so gaping that the inside was visible from the vaginal opening, and white, cloudy fluid gushed out in reverse flow.

"Ooooooooooh! I can't hold back anymore! I wanna fuck!"  
"Me too!"  
"I'm first!"  
"No way, I am! Don't get in my way!"

Despite having just ejaculated, Yuu's crotch remained rock-hard and pointing skyward, glistening obscenely with semen and love juices.

The women sending heated gazes toward it competitively stripped off their clothes and rushed forward. Their eyes were bloodshot and glaring, drool nearly dripping from their open mouths. Six women in total, ranging from late 20s to early 30s. Having had no prior involvement with men, most were virgins. Before such women, a supremely handsome boy was exposing himself completely naked. There was no way they wouldn't be aroused.

Objectively, it was a scene of a pitiful male deer surrounded by six hungry bitches. But Yuu was no weak herbivore—he was a beast armed with weapons to send bitches to heaven. Moreover, having experienced the third night at Hesperis, six women posed no hardship for the current Yuu. When their mutual distance shrank to less than 1 meter, Yuu smiled wryly and said:

"Alright, alright. To avoid trouble, come at me together. But insertion will be in order."  
""""""Ooh!""""""

Cheering loudly, the six women swarmed around Yuu who was sitting with legs spread on the mat, pressing their bodies against him. Though pressed together with almost no gaps, Yuu elicited each one's name. He knew these women intended to use him as an outlet for their sexual desires. But Yuu felt the same. After tonight, he'd likely never meet them again. Though he wouldn't develop affection for his kidnappers, he intended to at least engrave the names of the women he joined bodies with into his memory.

"Chu, chuu! Nn, mmuu... Ha, ha, kissing... feels good! M-more!"  
"N-next, I want too!"  
"Haha, got it. Here, turn this way more."  
"Nmu!? Nna... nn, chupa, nku... fumyu..."

Clutching Yuu from left and right, alternately begging for kisses were Akeno Harumi and Hokkyou Masae, both 25 years old. The youngest in this hideout after Tamiko and Yukiko. Often working as a pair, the two resembled each other with short ponytails, narrow eyes, and plain faces—almost like twins. Having worked hard at construction site part-time jobs, their arms and faces were deeply tanned. Both bodies appeared slightly shorter and slimmer than Yuu's but were actually lean-muscled. However, when naked, differences emerged in mole positions, pubic hair thickness, voices, and vibes. While both placed hands on Yuu's chest and groped him, competing to exchange kisses and lick his cheeks, Yuu's left and right hands vigorously kneaded Harumi and Masae's modest breasts. Harumi was more sensitive in her breasts, openly gasping in pleasure when kneaded, while Masae was more engrossed in enjoying Yuu's skin texture and caressing him.

"Foooooooooh! A boy's skin! Smooth and dewy, smells so good! Lick lick lick lick lick lick lick... nchu, chu, chupaa... tasty! Tasty! Unbearable~ Fuhihi. Being able to touch, smell, and lick directly like this is like a dream~"

Clinging tightly to his back like a piggyback monster while frolicking was Ueda Tomoko, 27 years old. Though petite and baby-faced with minimal curves, giving a small-animal-like cuteness, she was the most perverted person present. Apparently obsessed with male backsides, she immediately claimed Yuu's rear, burying her nose in the back of his head, licking and sucking his nape and shoulders, running fingers over bony areas like his spine and shoulder blades. Though Yuu couldn't see and only felt ticklish, she wore a rapturous expression at the sensation of touching a male body for the first time.

Straddling Yuu's spread legs and vigorously shaking their hips were Manaka Rio, 28, and Hitotsubashi Yureka, 29. Their dream had been to masturbate using a male body. Yureka had shoulder-length sandy blonde hair with flashy features and heavy makeup, giving a nightlife worker impression. In contrast, Rio wore thick round glasses with long black hair haphazardly tied back past her shoulders, seeming strait-laced. But both were equally lustful, drooling while directly savoring the feel of Yuu's knees and thighs. Both were about Yuu's height with good proportions, their breasts jiggling violently with each hip swing. Leaning forward, their gazes shifted to his crotch, both extending a hand.

Sitting flat between Yuu's legs was the last one: Noriko Williams, 30, the sub-leader and second oldest after Kyouko, who'd been masturbating while obsessively sniffing the cock's scent. Noriko was born via artificial insemination after her American mother came to Japan seeking men but failed. Her abundant hair, covering most of her back, was closer to brown than black with loose waves. Her skin tone was also brownish, and she stood nearly 180cm tall after Kyouko. Her build could only be described as voluptuous. And now, with her giant breasts emphasized as she sandwiched his cock between her arms.

"Hey, suck it for me."  
"Hah! R-really?"  
"Of course. You can lick it all over with your tongue, take it in your mouth, lick around, suck—whatever feels good for you. Just make Noriko feel good?"  
"Foooooh! I-I'll do it!"

Joy surged in Noriko's heart at being told by a beautiful boy to make him feel good. Once, she'd lavished gifts on a university classmate to finally lose her virginity—though he was like a dead fish. But when money ran out after her mother's business failed, she was coldly discarded. Since then, unable to pay tuition, she dropped out. At rock bottom, she found political activism. Though her longing for men turned to hatred, deep down she yearned for sweet romantic developments like in love stories.

First, she licked the glans with her tongue. Tentatively touching the shaft with her right hand, she felt fresh surprise at the bumpiness from protruding veins and roughness on the belly side. During her first experience, she'd been too frantic to observe carefully. Compared to that first partner, the color, length, thickness, and flare of the glans were far more virile, the heat transferring to her palm... making her lower abdomen twitch tightly.

As excitement grew, she stuck out her tongue boldly and licked all over. The glans, slightly dried from air exposure, now became coated with Noriko's drool. Absorbed in wetly licking, she noticed transparent fluid emerging from the slit.

"Lero, leroo, churu, chupa, nerochuuuuu... Haa, haa... This smell, this taste... my head feels like melting..."  
"Ah, that feels really good, Noriko. Hey! I'd be happy if you sucked it while sandwiching the shaft between those big tits."  
"W-with my tits?"  
"Yeah."

Just sucking his cock improved her mood and made Yuu feel good. If that was the case, she wanted to do anything for him. As instructed, Noriko sandwiched the shaft in the valley of her ample breasts. Then gently took the protruding glans into her mouth.

"Ahh... this is unbearable."  
"Nfu."  
"Ah, let us touch the cock too... p-please?"  
"Such an impressive cock... just watching isn't..."  
"Then you two can take care of the balls."

Rio and Yureka, who'd been wetting Yuu's thighs with their juices, bowed their heads and began sucking the heavy, dangling scrotum from left and right.

"Ah, ah, good! With Yuu's fingers... I'm feeling it!"  
"Afuu... i-inside... fingers... feel so goooood!"  
"Here, Tomoko, face this way and stick out your tongue."  
"Ai. Aaaah... leroleroo... afe... erojuru... anmu! Nnn... ufu... ufuerou"

Harumi and Masae, each being fingered to moans, clung tightly to Yuu. Yuu intertwined tongues with Tomoko who leaned over his shoulder, their drool dripping down.

While deep-kissing Tomoko over his shoulder, Yuu simultaneously fingered Harumi and Masae with left and right hands. His crotch received paizuri from Noriko, while Rio and Yureka on his left and right thighs sucked his balls. This continued for several minutes until Harumi, being finger-fucked deep inside her vagina with two fingers, climaxed first. Then Masae, having her clitoris pinched, convulsed her hips.

"Ai! I-I-I'm! O! Cumming! Cumming! Yuu! Ah... like that... AAAAAAAAAAAAAAAHHHHHHHHHHHHH!!!"  
"Ahi! Sho! Sensitive... pinching... ah, no! I-I'm also... an! Aahn! Cumming! Sho no! AAAAAAAHN! CUMMIIIIIIIIIIIIIIIIIIIIING!"

Yuu looked satisfied at the two who clung tightly, pressing cheeks against his chest as they came. Between his legs, he could see Noriko performing clumsy but earnest paizuri. Though hidden in shadow, he felt both balls being sucked. Unskilled at fellatio, the three hadn't brought him to ejaculation yet, but he felt a steadily building pleasure.

"Hey, I kinda wanna insert it soon."

At those words, Noriko's movements stopped completely. Harumi and Masae had just come from Yuu's hands. Tomoko clung over his back. Before he knew it, even Rio and Yureka looked up, sending heated gazes.

"First is Noriko who worked hard sucking. After that, age order maybe?"  
"Yesss!"  
"N-next after next..."  
"Muu... can't wait..."

Each showed varied expressions, but age order was acceptable. Noriko, revealing a joyful expression, moved forward while kneeling.

"Haa, haa... then, I'll, put it in."  
"Okay."  
"Nn... nue? Na... a! S-so big!"

Though anticipated since taking it in her mouth, when she lowered her hips for insertion, Noriko panicked at the sheer size. Her weight caused the tight vaginal walls to spread open as the cock was swallowed, but it stopped midway. Then Yuu's right hand grabbed her waist.

"Here, there's still more to go?"  
"Wa-wait... AAAAAAAAAAAAAAAH!"

The moment it slid in completely, Noriko's brain felt electrocuted. Her cervix was shoved upward, heat flaring from her lower abdomen. In other words, she came instantly.

*(With such a cute face, what kind of thing does he have... This... impossible. Different from normal men. He's the type to ruin women.)*

Though such thoughts floated in Noriko's mind, her body moved on its own. Grabbing Yuu's sides, she gradually began rocking her hips. She couldn't resist the instinctive impulse to savor the cock inside her, greedily seek more pleasure, and squeeze out his semen.

"Ahi... Yuu... your cock, amazing, amaaazing... o, o, aun! Good! Again... ah... cumming! With your cock... made to cum... many times! Aah!"  
"Good. Cum as many times as you want?"

Watching Noriko's breasts jiggle enormously with each hip swing, Yuu smiled and reached out to grab them. The overwhelming volume of her breasts left room even when his fingers sank deep into them. Pinching the nipples while kneading, Noriko let out a high-pitched cry none of her comrades had ever heard.

The surrounding women were overwhelmed by Noriko's writhing but fidgeted impatiently for their turn. Yureka and Rio, with closer turns, waited behind Noriko, while Tomoko, Harumi, and Masae competed to cling to Yuu and beg for kisses.

---

### Author's Afterword

After the leader fell, the sudden 7P will be split into first and second halves.

In this world, due to the gender ratio, women accustomed to handling men are extremely rare (exceptions in the work are Saira and Satsuki). So if multiple virgins had simultaneous access to a man, they'd likely act selfishly, fighting over the cock. An ordinary man would be overwhelmed by the women, but someone as experienced as Yuu should be able to take control. Though admittedly, this risks making it formulaic.

### Chapter Translation Notes
- Translated "野獣" as "Wild Beast" to convey Yuu's dominant sexual aggression
- Translated "チンポ" consistently as "cock" per explicit terminology rules
- Preserved Japanese name order (e.g., Akeno Harumi, Hokkyou Masae)
- Transliterated sound effects (e.g., "chu" for ちゅ, "lero" for れろ)
- Rendered internal monologue in italics with asterisks
- Used explicit anatomical terms ("vaginal opening", "cervix") per style rules
- Maintained dialogue formatting: new paragraph per speaker except with attribution