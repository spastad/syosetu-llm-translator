## 211. Kidnapping Incident ⑥ ~Beast~

As Yuu ejaculated, Kyoko experienced an overwhelmingly intense climax that caused her to abruptly lose consciousness.

Acknowledging this, Yuu pulled out his penis while holding her large body and laid her down at the edge of the mat.

Her legs, weakened and spread wide, gaped open enough to see inside her vaginal canal where the penis had just exited, with cloudy white fluid gushing back out.

"Ooooooooooh! I can't hold back anymore! I wanna fuck!"  
"Me too!"  
"I'm first!"  
"No, me! Don't get in my way!"

Despite having just ejaculated, Yuu's crotch remained rock-hard and pointing skyward, glistening obscenely with semen and vaginal fluids.

The women sent heated gazes toward it, stripping off their clothes competitively before rushing forward. Their eyes were bloodshot, practically drooling from their open mouths. Six women in total, ranging from late 20s to early 30s. Having had no prior relationships with men, most were virgins. Seeing a supremely handsome boy completely naked before them - excitement was inevitable.

Objectively, it resembled the scene of a pitiful male deer surrounded by six starving female dogs. But Yuu was no weak herbivore - he was a beast armed with weapons to make these bitches ascend to heaven. Moreover, after experiencing the third night at Hesperis, six women posed no challenge to the current Yuu.

When their distance closed to under 1 meter, Yuu smiled wryly and said:

"Alright, alright. To avoid trouble, come at me together. But penetration will be in order."  
""""""Ooh!""""""

The six women cheered and swarmed Yuu who sat with legs spread on the mat. Though pressed together with almost no space between them, Yuu elicited each one's name. He understood they intended to use him as an outlet for their sexual desires - but the feeling was mutual. After tonight, he'd likely never see them again. Though he wouldn't develop affection for kidnappers, he intended to at least etch their names in his memory.

"Chu, chuu! Nn, mmu... hah, hah, kissing... feels good! M-more!"  
"N-next! I want too!"  
"Haha, got it. C'mere, turn this way more"  
"Nmu!? Nna... chu-pa, nku... fmyu..."

Clutching Yuu from both sides and alternately begging for kisses were Akeno Harumi and Hokkyou Masae, both 25. Among those at this hideout, they were the youngest after Tamiko and Yukiko. Often partnered together, they resembled twins with similar short ponytails, narrow eyes, and plain features. Working part-time at construction sites had tanned their arms and faces dark. Both appeared slightly shorter and slimmer than Yuu but were actually lean-muscled. When naked, differences emerged in mole placement, pubic hair density, voices, and mannerisms. While both groped Yuu's chest, Harumi visibly reveled in breast stimulation with pleasured moans, whereas Masae seemed more engrossed in savoring Yuu's skin texture.

"Foooooooooh! A boy's skin! So smooth and dewy, smells amazing! Lick lick lick lick lick lick lick... nchu, chu, chupaa... tasty! So tasty! Can't stand it~ fufufu. Getting to touch, smell, and lick directly like this is like a dream~"

Clinging to Yuu's back like a piggyback monster was Ueda Tomoko, 27. Petite with a childlike face and minimal curves, she possessed small-animal-like cuteness but was the most perverted of the group. Apparently obsessed with male backs, she immediately claimed Yuu's rear - burying her nose in his hair, licking and sucking his nape and shoulders, tracing fingers along his spine and shoulder blades. Though Yuu couldn't see and only felt ticklish, Tomoko wore a rapturous expression while touching a male body for the first time.

Straddling Yuu's spread legs and vigorously rocking their hips were Manaka Rio (28) and Hitotsubashi Yureka (29). Their dream had been masturbating using a male body. Yureka had shoulder-length sandy blonde hair with flashy features and heavy makeup, giving nightlife worker vibes. In contrast, Rio wore thick round glasses with a careless long black ponytail, appearing strait-laced. Both were equally lustful, drooling while savoring the feel of Yuu's knees and thighs against their vulvas. Similar in height to Yuu with good proportions, their breasts jiggled violently with each hip thrust. Leaning forward, their gazes shifted to his crotch as both reached out a hand.

Seated flat between Yuu's legs was the last member: Noriko Williams, 30, the sub-leader who'd been sniffing Yuu's penis while masturbating. Born to an American mother who came to Japan seeking men but conceived via artificial insemination, Noriko had brown-tinted wavy hair covering most of her back. Her skin was similarly brown-toned, standing nearly 180cm tall after Kyoko. Voluptuously built, her enormous breasts were emphasized as she sandwiched Yuu's penis between them.

"Hey, suck it for me"  
"Hah! R-really?"  
"Of course. Lick it all over, take it in your mouth, lick around, suck - whatever feels good for you, Noriko"  
"Foooooh! I'll do it!"

Being told by a beautiful boy to pleasure him made joy surge in Noriko's heart. She'd once paid a college boy continuously to finally lose her virginity (though he was "dead fish" during sex). But when her mother's business failed and money ran out, he discarded her. Since dropping out, she'd hit rock bottom before finding political activism. Though male longing had turned to hatred, deep down she yearned for romantic novel-like intimacy.

First, she tentatively licked the glans with her tongue. Cautiously touching the shaft with her right hand, she marveled at the bumpy veins and rough texture on the underside - sensations she'd been too frantic to notice during her first time. Compared to that partner, the color, length, thickness, and flared ridge felt far more virile... heat radiating into her palm made her abdomen twitch.

As excitement grew, she boldly licked with broad strokes. The glans, slightly dried from air exposure, became coated in her drool. While feverishly licking, Noriko noticed transparent fluid emerging from the urethral opening.

"Lero, leroo, churu, chupa, nerochuuuuu... haa, haa... this smell, this taste... my head feels like melting..."  
"Ahh, feels amazing, Noriko. Hey! Could you suck it while sandwiching the shaft between those big breasts? That'd make me happy"  
"M-my breasts?"  
"Yep"

Just sucking his cock made Noriko feel good, and knowing it pleased Yuu made her want to do anything. Following instructions, she sandwiched the shaft in her deep cleavage and gently took the exposed glans into her mouth.

"Ahh... this is unbearable"  
"Nfufu"  
"Ah, let us touch the cock too..."  
"Such an impressive cock... just watching isn't enough..."  
"Then you two can take care of my balls"

Rio and Yureka, who'd been wetting Yuu's thighs with their arousal, lowered their heads and began sucking the heavy hanging scrotum from both sides.

"Ah, ah, good! Yuu's fingers... I'm feeling it!"  
"Afuu... i-inside... fingers feel so goooood!"  
"Hey Tomoko, face this way and stick out your tongue"  
"Ahyee. Aaaah... leroleroo... afue... ejuru... anmu! Nnn... uf... ufueroh"

Harumi and Masae moaned as Yuu fingered them, clinging tightly. Yuu locked tongues with Tomoko who leaned over his shoulder, their drool dripping down.

While deep-kissing Tomoko over his shoulder and simultaneously fingering Harumi and Masae with both hands, Yuu received paizuri from Noriko at his crotch and testicle-sucking from Rio and Yureka on his thighs. This continued for several minutes until Harumi climaxed first from two fingers thrusting deep inside her. Soon after, Masae came with violent hip spasms when her clitoris was pinched.

"Aiiii! I-I-I'm cumming! Ooh! Cumming! Cumming! Yuu! Ah... like that... AAAAAAAAAAAAAAAHHHHHHHHHHHHHHH!!!"  
"Ahi! Sensi-sensitive! Too sensitive... pinched... ah, stop! Me too... me too... an! Aahn! I'm cumming! Stooop! AAAAAAAAHN! CUMMIIIIIIIIIIIIING!"

Yuu watched the two clinging women with satisfaction as they came, faces buried against his chest. Between his legs, he could see Noriko clumsily but earnestly performing paizuri. Though hidden from view, he felt both testicles being sucked. Unskilled at fellatio, the three hadn't brought him near ejaculation yet, but provided steady pleasure.

"Hey, I wanna insert soon"

At these words, Noriko froze mid-motion. Harumi and Masae had just climaxed by Yuu's hands. Tomoko clung from behind. Rio and Yureka had lifted their heads, sending heated stares.

"First is Noriko who worked hard sucking. Then by age order"  
"Yesss!"  
"N-next after next..."  
"Muu... can't wait..."

Though showing varied expressions, age order seemed acceptable. Noriko revealed an ecstatic expression and moved forward on her knees.

"Haa, haa... then, I'll insert it"  
"Go ahead"  
"Nn... nue? Na... aah! S-so big!"

Though anticipated since taking it in her mouth, when Noriko lowered her hips for penetration, the sheer size made her panic. Her weight forced the tight vaginal walls apart as the cock was swallowed, but stopped midway. Then Yuu's right hand gripped her waist.

"See? More can go in"  
"W-wait... AAAAAAAAAAAEEEEEEEEH!"

The moment it plunged fully inside, electricity seemed to jolt through Noriko's brain. Her cervix was shoved upward, abdomen burning hot - meaning she came instantly.

*(With such a cute face... what kind of monster does he have... This... impossible. Different from normal men. He'll ruin women)*

Though such thoughts crossed Noriko's mind, her body moved independently - grabbing Yuu's sides and slowly beginning to rock her hips. She couldn't resist the instinctive urge to savor the cock inside her, greedily seeking more pleasure to milk out his semen.

"Ahi... Yuu... your cock, amazing, so amazing... oh, oh, aun! Good! Again... ah... cumming! Your cock... making me cum... again and again! Ahh!"  
"Good. Cum as much as you want"

Watching Noriko's massive breasts jiggle violently with each thrust, Yuu smiled and reached out to grab them. Even sinking his fingers deep into the overwhelming volume left plenty overflowing. When he pinched her nipples while kneading, Noriko shrieked in a high-pitched voice none of her comrades had ever heard.

The surrounding women were awed by Noriko's convulsions but fidgeted impatiently for their turns. Yureka and Rio waited behind Noriko as next in line, while Tomoko, Harumi, and Masae competed to cling to Yuu and beg for kisses.

---

### Author's Afterword

After the leader fell, the abrupt 7P will be split into first and second halves.

In this world, due to the gender ratio, women accustomed to handling men are extremely rare (exceptions in the story being Saira and Satsuki). Therefore, if multiple virgins had simultaneous access to a man, they'd likely act selfishly, fighting over the penis. An ordinary man would be overwhelmed, but experienced Yuu should be able to control the pace. Though admittedly, this risks making it formulaic.

### Chapter Translation Notes
- Translated "野獣" as "Beast" to convey Yuu's dominant sexual aggression
- Translated "雌犬" literally as "female dogs" per explicit terminology rule
- Preserved Japanese honorific-free naming convention (e.g., "Noriko Williams")
- Transliterated sound effects (e.g., "chu" for ちゅ, "lero" for れろ)
- Rendered explicit anatomical terms directly ("vaginal canal", "cervix")
- Translated sexual acts without euphemisms ("paizuri", "testicle-sucking")
- Maintained original Japanese name order for new characters
- Italicized internal monologue *(With such a cute face...)*