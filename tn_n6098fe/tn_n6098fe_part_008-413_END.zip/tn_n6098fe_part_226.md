## 212. Kidnapping Incident ⑦ ~Lullaby at Dawn~

After making Noriko Williams climax multiple times, he released his seed inside her just as she collapsed.

Five women remained, trembling with desire to have intercourse with Yuu.

Yet Yuu showed no fear, adopting a confident attitude brimming with intent to fuck them all.

While their mutual desires seemed aligned, the reality differed. Yuu refused to be played with by his kidnappers, insisting on maintaining his own pace without indulging their selfish demands.

First, he had Rio and Yureka suck his cock, which had calmed slightly after three ejaculations. Though nearly thirty, this was their first time directly touching male genitalia, so Yuu instructed them in oral techniques using hands and mouth. Meanwhile, he let Tomoko, Harumi, and Masae freely use his upper body while kissing them in turn. He ordered all five to masturbate with one hand so they'd be ready whenever their turn came - promising penetration if they came from masturbation. Having witnessed Kyoko and Noriko's intense sessions, the women nodded obediently, recognizing Yuu's experience despite being younger.

After taking Yureka and Rio in age order, he rested briefly before lifting the petite Tomoko into a facing position and thrusting relentlessly until she passed out. Dawn began breaking unnoticed. Finally, he made Harumi and Masae line up presenting their buttocks, penetrating them alternately from behind.

"Ah... Aah, ah, aaaah! Ran... this... amazingeeeeee... foh! I'm... cuu... bwaaah! Sho... ko... ngh! Cuuuuuuuuuuuuuuming!"

Harumi arched her back, body stiffening briefly before collapsing limply. Being highly sensitive, she'd climaxed repeatedly after penetration until reaching her limit. Yuu lightly slapped her buttock with his left hand before turning to Masae. Alternating between cock and fingers had left Masae's vagina soaking wet, translucent fluids dripping down her thighs onto the mat. When Yuu withdrew two fingers, his palm was drenched.

"Now, it's Masae's turn."  
"Ah... ahi... Your cock, Yuu's cock... I want it~"

Though more enduring than Harumi, Masae was equally overwhelmed by Yuu's stamina despite multiple ejaculations. Minutes ago, she'd been moaning with a dazed expression from deep thrusts. Though a virgin, she'd been thoroughly taught her pussy's shape, now begging like a bitch in heat with her ass thrust out. Yuu gripped her buttocks firmly as her twitching vaginal opening sought his tip, then plunged in to the hilt.

"Gah-hee! O-ohin... po... ooh... it's... ah... ah, ah... no... more... ra... me..."

Thrust deep inside, Masae trembled on all fours.

"You can lie face down if you want."  
"Hahi"

Her strength drained away as Yuu whispered against her exposed nape (revealed by her ponytail), leaving her prone on the mat - effectively a sleeping doggy position.

"Ah... aaah... this... I liiiiike it... dee... deep... so deeeeeeeeeep!"

Every inch of the mat was soaked with bodily fluids after hours of fucking, but Masae didn't care. Yuu blanketed her back completely, even overlapping his hands over hers - an impossible posture in this world. Overflowing with euphoria, Masae drooled tears and saliva.

"I'm close too... I'll move now?"  
"Ha... hi, co... cum... agh, aahn! Ihhh! Too... too good... can't... think... anymore..."

Though partially riding her, Yuu felt fatigue from hours of sex. He moved slowly with deep thrusts rather than vigorously. Still, each hip movement produced wet slapping sounds. By Yuu's climax, Masae reached orgasm in dreamlike ecstasy, barely breathing.

Having slept only an hour total since being trucked here, Yuu finally let exhaustion overwhelm him after his last ejaculation. Pulling his dripping cock out, he forced himself between Harumi and Masae and closed his eyes.

***

Yuu awoke to commotion beyond the door. Having turned in sleep, he lay supine sandwiched between Harumi and Masae. Kyoko, Noriko and others remained collapsed further away. The original guards, Tamiko and Yukiko, had been sent to keep watch earlier and were absent.

Cardboard-covered windows kept the room dim, but slivers of light confirmed morning.

"Breach!"  
"W-what are you—"  
"Out of the way!"  
"Shit! Warn the leader— guah!"

The scuffle ended instantly as multiple footsteps approached.

"*Good. They made it in time.*"

Yuu murmured. His quick thinking to puncture the drum of black liquid had paid off - the trail likely revealed the truck's path. Had things gone as planned, he'd have been taken much farther. Kyoko's group wouldn't release such a valuable hostage easily, making escape improbable from the start. Being taken remotely would have delayed rescue.

The women began stirring but seemed unable to move immediately, legs unsteady. Some like Harumi and Masae blushed and clung to Yuu upon noticing the naked boy beside them.

The door burst open with a bang. Yuu smiled as a small figure bulleted in followed by a large woman standing imposingly. Yuu was immediately scooped away from the women toward the large woman—Kanako.

"Secured Lord Yuuuuuu—!"  
"Charge, men!"  
""""Waaaaaaaaaah!""  
"Gah!"  
"Shit!"  
"Whoa! Let go! You—!"

The room instantly became hell. Though Kyoko and others stood, they couldn't resist or escape. Naked, they were pinned and bound. Yuu averted his eyes from the women he'd passionately joined with now being restrained. He felt no sympathy - this was inevitable.

"Uuuu... Lord Yuu... sooorry..."  
"Lord Yuu! We'll accept punishment later! First to safety!"  
"Both of you... thank you for coming. Just... sleepy now."

Touko tearfully carried the taller Yuu effortlessly while Kanako knelt bowing. Seeing them, Yuu smiled in genuine relief before pitching forward. Kanako caught him, his face buried in her ample bosom.

***

◇ ◆ ◇ ◆ ◇ ◆

***

"Mm... Where?"

Yuu awoke in a stark white hospital bed smelling faintly of disinfectant. Remembering his rebirth last March, he guessed it was a hospital. The unnecessarily large room had familiar high-end furnishings, but no one else was present. Through lace curtains, the dimming light suggested evening.

As Yuu sat up looking around, the sliding door opened. Hirose Martina entered in casual jeans and a white T-shirt. Seeing Yuu awake, she froze, eyes wide, hand covering her mouth. Tears welled instantly.

"Yu... Yuu-chan!?"  
"Ah, Mom"

Martina dashed to the bed, spreading her arms to crush Yuu in an embrace. His face buried in breasts visible through her bra.

"Wahp!"  
"Yuu... Yuu... Yuuuuuuuuuuuu!"  
"Er... Sorry for worrying you."

Though breathless from the fierce hug, Yuu understood her concern. He looked up and hugged her back.

"Guh... Yuu-chan... disappeared... kidnapped they said... I... worried... so muuuuuuch!"  
"But as you see, I'm fine."  
"Waaaaaaah!"

Martina wept, makeup smearing, clinging as if never letting go. Mothers naturally worry over sons, but doubly so in this male-scarce world. Understanding her feelings, Yuu patted her head.

"Yuu!"  
"Yuu!"

Hearing voices, Elena and Saira rushed in, surrounding Yuu.

"Yuu... you slept so long..."  
"So glad... you're safe..."

Overcome seeing Yuu awake, both shed tears. Yuu freed one hand to wave and smile.

"Sorry for worrying you both too. As you see, I'm fine. By the way... how long has it been?"

Elena and Saira both grabbed his hands and clung to him, delaying his answer.

***

It took time for the three to calm down before details emerged.

Elena and Saira noticed Yuu missing first - likely just after he left Suzanna's room. They emerged into the hallway right after the kidnappers took Yuu. Narrow timing. Though angry at themselves for missing it, Yuu was relieved they hadn't encountered the women and been harmed.

Saira learned from her mother that Yuu had visited the adjacent room but lost track after that. She summoned Kanako and Touko to search. Martina had been passed out drunk in the lounge but turned pale sober upon hearing Yuu was missing.

Chaos ensued. Security and staff were mobilized, along with sobered wives and half-sisters, but Yuu wasn't found. That night, only one contractor's truck had left via the rear gate. Simultaneously, they discovered a trail of dark paint droplets leading outside.

The all-night search began. Police were notified of probable kidnapping, but Martina wouldn't wait idly.

The paint trail intrigued. Security dismissed it as coincidence, but Elena and Saira insisted it was Yuu's clue. Moved by them, Martina and Haruka acted independently.

Leaving police coordination to Haruka, Martina called reinforcements from Kanako's security firm MALSOK. With Elena and Saira, she pursued the trail in a foundation-borrowed car. The droplets led northwest into Saitama's Wakou City before vanishing on a side road.

Where did the kidnappers go? Police set up emergency checkpoints on northbound lanes from Shinjuku overnight but found nothing. The construction company reported: Work was scheduled for morning; that night's crew were imposters who stole a pre-loaded truck; the "workers" didn't exist, though three part-timers had quit days prior.

The trail crossing prefectural borders complicated jurisdiction, causing hours of delay. In Saitama, Martina and Kanako didn't wait. Remembering Wakou City housed Yuu's fiancée Sayaka's family, Martina apologized for the early call but requested Komatsu family aid.

The Komatsus had local connections through their long-established dojo. With members already gathering for morning practice, over fifty local students helped search likely hideouts, pinpointing an abandoned factory. Around 8:30 AM, Kanako, Touko, thirty MALSOK guards and adult dojo members stormed in. The unconscious Yuu was transported to Saito City General Hospital in a Komatsu-provided car. All kidnappers were captured and handed to local police.

Doctors diagnosed Yuu's coma as mere exhaustion with no physical damage. Though relieved, Martina remained anxious until Yuu awoke and spoke, waiting reluctantly until 6 PM when Yuu finally stirred.

---

### Author's Afterword

The latter half of the multiple-partner scene was rushed. I prioritized including the behind-the-scenes developments I thought readers would find interesting over detailing each individual. I plan to use one more chapter to cover the incident's outcome and impact. Just to clarify: Since he's an underage male, Yuu's name won't be reported.

### Chapter Translation Notes
- Translated "精を放った" as "released his seed" to maintain explicit terminology for sexual content
- Preserved Japanese honorifics (-chan for Yuu, -san for adults) per style guidelines
- Transliterated sound effects: "ばちゅん" → "bachun", "ぱたり" → "patari"
- Maintained explicit anatomical terms: "チンポ" → "cock", "膣" → "vagina"
- Used gender-neutral "they" when original Japanese omitted subjects
- Translated "オナニー" as "masturbation" without euphemism
- Rendered simultaneous dialogue with double quotes: """"Waaaaaaaaaah!""""
- Kept Japanese name order: "小松 清華" → "Komatsu Sayaka"