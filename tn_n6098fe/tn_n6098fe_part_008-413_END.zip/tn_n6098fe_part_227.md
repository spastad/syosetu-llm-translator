## 213. Kidnapping Incident ⑧ ~Sin and Punishment~

"Due to our negligence, we allowed criminals to easily take away Yuu-sama and put him in danger. We sincerely... apologize!"  
""""We are deeply sorry!""""

Before Yuu sitting on the hospital room sofa, a legion of women in black suits knelt on the floor. In unison with the representative's apology, they prostrated themselves and bowed their heads.

The management director of the Toyoda Sakuya Memorial Foundation's annex "Houshoukan," the security chief, and even the section chief and department head from MALSOK - the security company where Kanako and Touko worked - had rushed over to bow before Yuu. Except for Kanako and Touko, these were management-level personnel of advanced age. The department head in particular was around 50 years old - older than Yuu in his previous life - with a large, stout build, but now she shrank back timidly.

Martina and Elena beside Yuu observed this scene as if it were perfectly natural. And perhaps it was. Despite their vigilance, Houshoukan had easily allowed fake workers inside and been distracted by the diversionary commotion, resulting in the kidnapping of their important guest Yuu. The security company that dispatched the protection officers had been in the room next to Yuu but failed to notice the intruders until Elena alerted them.

In truth, depending on the protectee, guards sometimes stood watch outside the door, but Yuu himself had refused this level of security. So from Yuu's perspective, at least Kanako and Touko bore no blame - but in this world, that wasn't enough to absolve protection officers of responsibility.

Yet having all these women prostrate before him made Yuu deeply uncomfortable. Though half a year had passed since his rebirth and he'd grown somewhat accustomed to this world, understanding his value as a rare male, his middle-aged salaryman soul couldn't endure this.

"Enough... please stop!"

At Yuu's forceful tone, several women flinched and trembled. They seemed to think he'd raised his voice in anger despite their prostration. Among them, Kanako raised her face with a resolute expression. That look of tragic determination made her already beautiful features appear even more striking.

"Having committed such a blunder, I'm prepared to be fired as a matter of course. I know I have no right to face Yuu-sama, but I couldn't rest without offering my apology..."  
"That's not it!"  
"Eh!?"

Yuu rushed over to Kanako and Touko. He lifted them up as if embracing them.

"Y-Yuu-sama?"  
"Kanako-san and Touko-san did nothing wrong."  
"B-but..."  
"When I went into the hallway, I thought about calling you two first... But when I heard noises, I worried it might be my drunk mother returning and possibly falling down the stairs, so I went alone..."  
"Eh, me?"

Martina looked startled at suddenly being mentioned. Yuu explained the situation in detail.

If only Yuu had called Kanako and gone with them. If only Elena had woken slightly earlier and noticed Yuu in the hallway. If Kanako or Touko had been beside him when he was abducted, then responsibility would be understandable. Though frankly, even if several assailants had attacked Kanako and her partner, it's unlikely they would have been overpowered. Had Yuu known he'd be attacked, he could have shouted or resisted - that's why he'd learned self-defense. It was all just bad timing.

If you said Yuu had been careless, that was true. But with his reason being concern for his mother, no one present could blame him. Instead, their anger and hatred turned toward the kidnappers who'd violated him (as they mistakenly believed).

"B-but Yuu-chan, adults must take responsibility when they fail at their duties."  
"Huh?"

Even if Yuu forgave them, Martina couldn't let it go after her son had been endangered. "Take responsibility" meant firing them - the one outcome Yuu desperately wanted to avoid.

"No!"  
"Eh?"

"I don't want anyone but Kanako-san and Touko-san!"  
"Y-Yuu-sama..."

Uncharacteristically, Yuu directly opposed Martina. Not only that, he embraced the stunned Kanako and Touko with both arms. The section chief stepped forward to speak - a woman in her forties with the tall, sturdy build of a former protection officer.

"Hirose-sama. Judging from past reports, Yuu-sama shares a strong bond of trust with Kitamura and Kujira. Rather than assigning new protection officers, keeping these two would be best for Yuu-sama."  
"We'll... have the entire company provide full support going forward, so please..."

Both the section chief and department head bowed deeply. They too wanted Kanako and Touko to fulfill their duties, and finding replacements would be difficult.

"Mom, please."  
"W-we will redouble our efforts and devote ourselves completely to protection duties!"  
"Please!"  
"Hmm..."

With Yuu and everyone else insisting, Martina had no choice but to relent. However, Yuu couldn't shield the Houshoukan security staff. But further apologies would only make him more uncomfortable. Yuu knelt on one knee before the two Houshoukan representatives.

"Um, I've fully received your sentiments. I accept your apology. After all, I'm perfectly fine after a nap. Just please be more careful going forward."  
"Y-Yuu-sama"  
"Just to be clear - don't make the on-site security guards resign to take responsibility. No replacing heads."  
"Eh?"

The management director looked perplexed, having assumed this was obvious.

"They say 'failure is the mother of success.' I want the security staff to learn from this incident and ensure it never happens again. That's my wish."  
"......"  
"B-but that would set a bad precedent..."

While the security chief remained silent, the management director hesitated. Then someone entering through the sliding door behind them - the hospital room door - spoke up.

"If the victim himself says so, we should settle it here. A pay cut according to regulations would be appropriate. Let's thoroughly review the entire facility's security and emergency protocols going forward."  
""Haruka-san!""  
"Director..."

Haruka's authoritative pronouncement resolved the situation - a display of her commanding presence.

After the four women besides Kanako and Touko left with bowed heads, Haruka approached Yuu. Behind her stood Satsuki, Suzanna, and Saira.

"You came all this way?"  
"Of course. When I heard Yuu had been kidnapped, I was beside myself. Just as Yuu is Martina-san's precious son and Elena's precious brother, he's irreplaceable to us in many ways too."  
"That's right. Seeing you looking so healthy now, I'm truly relieved."

Everyone present nodded deeply at Haruka and Satsuki's words. Though embarrassed by their gazes, Yuu realized he needed to thank them for their efforts. First, he took Kanako and Touko's hands.

"Kanako-san, Touko-san"  
""Y-yes!""  
"Thank you for coming to rescue me. When I saw you two then, I felt truly relieved and let my guard down."  
"Ah... we only did what was expected."  
"I regret not beating them half to death."

Seeing Touko's expression that suggested she might still go to the police station to finish the job, Yuu gently stroked her head while holding Kanako's hand, making her go soft with a dazed expression.

"Mom, Sis, Saira-nee, Suzanna-san. And Haruka-san, Satsuki-nee too - thank you all for doing everything to rescue me. Thanks to you, I returned safely."  
"Yuu-chan!"  
"Yuu!"  
""""Yuu!""""

Surrounded and hugged from all sides, Yuu was thoroughly mobbed.

Just then, feeling hungry, Yuu requested a meal. While waiting, he chatted with the women surrounding him. Though they seemed hesitant out of concern for him, everyone was curious about what happened after the kidnapping. Haruka cut straight to the point.

"I heard that when Kanako-san and the others stormed in, the criminals barely resisted. Did you do something, Yuu?"  
"Well... I did do something, I guess?"  
"What?"  
"Tell us!"

Elena and Saira leaned in eagerly. Only Kanako and Touko knew everyone had been naked at the scene, but they kept silent. Under everyone's gaze, Yuu hesitated briefly before confessing.

"I fucked every last one of them."  
""""......""""  
"And they didn't force themselves on you?"  
"No way - I fucked them one by one. Until their hips gave out and they passed out."  
""""......""""

Hearing this, they showed various expressions - shock, bewilderment, exasperation, understanding. Only Haruka and Saira looked convinced. Haruka muttered quietly, too soft for others to hear.

"While that organization's leaders will face severe punishment, the women who kidnapped Yuu got special treatment."

◇ ◆ ◇ ◆ ◇ ◆

Later, police informed them of the incident's outcome.

Even before interrogating the captured criminals, the secret documents from the second floor revealed hideouts in Tokyo and Okutama. Most of the perpetrators had readily confessed as if possessed.

That same day, police tactical units raided the locations, arresting nearly all Rescue Women Military Council members. Beyond the initial charges of trespassing and kidnapping, numerous additional crimes emerged - theft, arson, property destruction. When Yuu was questioned in his hospital room, he admitted to sexual acts but clarified they weren't forced - he'd initiated them, astonishing the detectives. Thus, no indecent assault charges were filed.

During the Tokyo raid, strong resistance allowed several members including the chairwoman to escape, while some absent executives vanished completely, resulting in arrest warrants.

Investigations revealed the Rescue Women Military Council received funding from Dankyo Party affiliates through paper companies. Suspicious funds of unknown origin were also uncovered.

A political party with parliamentary seats had connections to an extremist group and condoned illegal activities. Worse, that extremist group had trespassed at a Tokyo facility and kidnapped and confined a boy overnight. When reported, this caused an uproar. Though the victim's name wasn't released, public outrage erupted over a 16-year-old boy being kidnapped.

With the general election less than a month away and public attention heightened, media competition intensified. Cameras and reporters swarmed Dankyo Party headquarters, lawmakers' residences, support groups, and affiliated organizations. Party leaders frantically denied everything, claiming a government conspiracy, but only their staunchest supporters believed them.

Daily, Dankyo Party's support plummeted. Though opposition coalition meetings had been frequent until late August when the incident occurred, they naturally dissolved. Other opposition parties' support also began falling in tandem. Desperate to recover, they faced difficulty maintaining current levels, making a change in government impossible.

Among the wanted individuals were executives of dummy companies involved in shady businesses and money laundering through overseas transactions. One was Jane Grimwood, a 34-year-old American woman (naturalized Japanese) listed as representative director. Police visiting her home questioned her high school daughter about Jane's whereabouts. The daughter said she'd been estranged from her mother for about half a year and hadn't seen her for the past month. Jane's location remained unknown.

---

### Author's Afterword

After responding to feedback on the previous chapter, I added that Yuu initiated the sexual acts during captivity. Thus, in this chastity reversal world, what would typically be treated seriously as sexual crimes against males didn't occur here. While Yuu himself feels little victimhood and went easy on the kidnapping group, the organization behind them faced painful consequences.

### Chapter Translation Notes
- "土下座" translated as "prostrated themselves" to convey the deep bow of apology in Japanese culture
- "馘首" translated literally as "fired" (lit. "beheading") to preserve the severity metaphor
- Sexual terminology ("fucked") rendered explicitly per translation style guidelines
- Simultaneous dialogue marked with quadruple quotes """"..."""" per formatting rules
- Japanese honorifics (-sama, -san) preserved throughout