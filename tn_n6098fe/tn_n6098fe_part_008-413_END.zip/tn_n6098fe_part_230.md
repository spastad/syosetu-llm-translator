## Interlude 7: The Troubled Girl

### Author's Preface

This is from Nana's perspective.

In the previous chapter, I included the reason why Nana knew Yuu's face even though Yuu didn't know Nana.

---

My name is Tsutsui Nana. I'm a 16-year-old high school student born on August 1st.

My mother is the now very active actress Tsutsui Takako, appearing in dramas and movies. And my father, though deceased, was probably Japan's most famous man, Toyoda Sakuya.

Though since my father passed away before I was born, I don't have a real sense of him as my father.

According to my mother, my father had not only 20 wives but also numerous lovers, and if you include one-night stands, he had relationships with an incredible number of women.

It's hard to believe, but seeing the occasional special features on TV and in magazines makes it seem true.

He feels like a person from another world, but I carry this man's blood.

And I apparently have dozens, maybe even over a hundred, half-siblings from different mothers, but that's another thing I can't really grasp.

That's because I've lived with just my grandma and my mother since I was born.

When I was about three years old, my mother decided to return to acting.

Around that time, my grandma, who had been suffering from cancer, passed away very quickly, but just before she died, she left a will for my mother, I'm told.

"It's too early to give up on your dream. Even while raising a child, continue acting in whatever form you can."

I remember her apologizing to me, a little girl about to be left at daycare, over and over: "I'm sorry. You'll probably feel lonely, but I'm truly sorry."

Well, in this world, a single mother with one child isn't rare, so I had plenty of companions and made friends quickly, so I wasn't lonely.

However, since I wasn't very active from a young age, I preferred reading picture books quietly by myself rather than playing with friends outside.

I was the kind of child who loved getting lost in the world of stories, not caring about anything around me, traveling to various worlds in my head.

At first, my mother wasn't too busy, with work and non-work days about half and half, so it was fine.

My joy back then was acting out characters from my favorite children's shows with my mother.

Doing that, I felt I could understand the characters' emotions in my own childish way and enjoy it more than just watching.

Through connections from the agency she used to belong to, my mother took on any job she could.

From local TV commercials to extras in movies and dramas, to bit parts that only appeared for seconds. I hear she even took on dubbing for minor foreign films as part of her acting studies.

Her down-to-earth efforts, having discarded her past as a so-called child prodigy actress, paid off, and her acting skills gained recognition.

By the time I was in fourth grade, she started getting offers for roles in fairly famous movies and dramas.

She went from being one of the crowd in a single movie scene to having her name listed in the end credits as an individual actor.

From serious students to swaggering punks. From pitiful crime victims to malicious stalkers targeting men.

My mother, a beauty who could handle any role.

I felt happy to have such a mother.

It was a time when I could still be honestly pleased.

The trigger was when I visited my mother's workplace, a TV station.

One of the child actors scheduled to appear in a commercial for a new toy from a children's anime series suddenly came down with a fever and couldn't make it. Seeing the staff in trouble, my mother suggested me.

Her calculation was that since I had been embodying characters beyond mere imitation to the point of realism in front of the TV, I could probably do it with a little practice.

My performance exceeded expectations for a substitute, and it was very well received by the director and staff.

A few days later, I was surprised to hear that several offers for children's commercials had come through my mother's agency.

I later learned that connections and introductions are important in the entertainment industry.

Of course, there are paths like child actors being chosen through auditions or belonging to a troupe and honing their skills alongside rivals.

In fact, my mother in her childhood had been hailed as a child prodigy actress after walking such a path.

But for an amateur like me to get work, it seems that having my mother as an active actress, even if mid-tier, was a big factor.

Balancing school was difficult, but being able to work with my mother was very joyful for me at that time.

For someone like me who hadn't formally studied acting, they gave me relatively easy roles: one of several children in a commercial, or a supporting role in a school-based show.

When I had time, I would thoroughly read not only the script but also the original work and related materials, expand the image in my head, and when it came time for the actual performance, I would become the character as if flipping a switch.

Acting came as naturally to me as playing did when I was little.

If that's because I inherited my mother's blood, then maybe that was indeed the case.

"Hey, Natsumi-chan might be an even greater genius than your mother!"

Some sponsors even gave me such excessive flattery.

By the way, using the stage name "Natsumi" instead of my real name Nana was my mother's consideration.

I thought it was strange since appearing on TV would get me recognized by friends anyway, but it seems my mother, who had always used her real name, didn't want to cause me unnecessary hardship.

"Your mom's a bad woman, isn't she!"

"Yeah, yeah! A bad woman who tricks men to get what she wants!"

"Huh? What are you talking about? That's obviously acting."

"No way! Being able to play such bad roles so easily must mean her real personality is bad too. That's what my mom said."

"It was written in the weekly magazine my grandma reads."

"I bet the child of a villain is a bad kid too, right?"

"She skips class a lot, so she must be a bad kid."

My mother took on roles that were often shunned: villains, criminals, tainted characters, regardless.

Rather than pure heroines, she seemed to find roles that would make viewers hold negative feelings more worthwhile to play.

It's because of my mother's acting that the lead stands out, the work becomes worth watching, and it becomes a hit.

In that sense, my mother's reputation in the industry rose, and her presence gained weight.

But not all general viewers took it favorably; rather, as the dramas in which my mother played villains gained attention, a negative image became fixed.

Some entertainment weekly magazines also fueled this.

They said that my mother, then 16 and with her career declining, was advised by her agency to aggressively pursue my father for fame, resulting in her getting pregnant.

They said that the reason I started working in the entertainment industry was because my mother pulled strings behind the scenes.

I didn't know it then, being only in sixth grade, but apparently there were some terrible articles based on jealousy and malicious speculation.

I made sure not to miss school more than once a week even when I had unavoidable work, and I tried not to skip school as much as possible.

I didn't neglect my studies either, keeping my grades consistently high.

I wasn't good at making friends since I was little, but acting like a good girl in front of teachers was easy, and I thought I could manage.

There were times when classmates who didn't like me would talk behind my back.

But I kept ignoring them, thinking I shouldn't take such petty malice seriously.

However, as my mother and I got more media exposure, the trouble of them surrounding me in the classroom just to say bad things increased.

Moreover, the instigators were the boss and her followers, who stood out in class in a bad way.

Even if I tried to ignore them as before, they persistently bothered me.

Everyone in class followed the loudest voice, and my already few allies dwindled further.

The age when children hit puberty is complicated.

They easily hold grudges over trivial matters and get ostracized.

Moreover, the fact that I earned a fee beyond a child's allowance and that I had co-starred with boys in commercials, even if just commercials, probably became material for envy.

Though I wasn't subjected to violence, the bullying became insidious: the whole class ignoring me, hiding my things, and so on.

And since they kept badmouthing not just me but my mother too, I got fed up and from the middle of sixth grade until graduation, I increasingly skipped school, pretending to go but hiding in deserted places.

So I absolutely refused to go to the local public middle school and selfishly insisted on taking the entrance exam for a private middle school in Saitama Prefecture instead of Tokyo where we lived.

Fortunately, since I had been serious about my studies, I passed without issue.

In middle school, I made it my goal to act like someone who would be liked by everyone, even if I was called two-faced.

I continued my entertainment career quietly, without standing out too much.

There was talk of co-starring with my mother for publicity, but I declined.

I was "Natsumi," a young actress and model who solidly supported productions with steady performances in supporting roles, though not very memorable to viewers.

After uneventfully finishing middle school, I was able to enter Saiei Academy High School in Sakate City, Saitama Prefecture, on recommendation.

That school, which focuses on culture and the arts, had a small number of students who, like me, had chosen the path of acting since childhood.

Though I couldn't truly open up to classmates who were purely devoted to studying acting for their dreams, I was used to going along with people and getting through school life without making waves from middle school.

I was surprised when, soon after summer vacation started, there was a joint event with our sister school Sairei Academy and an event inviting Sairei students.

Though I had opportunities to work with boys, during work we didn't have to be awkwardly conscious of each other, and privately I had no connection with them at all.

I watched coldly as the girls around me got very excited seeing the boys from Sairei.

I thought it had nothing to do with me.

My mother suddenly brought it up around late August.

It was about taking the transfer exam for Sairei Academy, a co-ed sister school.

I was so surprised by the suddenness that I was speechless, and my mother informed me that she had already applied for the exam.

I protested that it was too forceful, but my mother coolly said:

"But lately, Nana, you haven't been putting your heart into acting, have you? I feel like you're somewhat lost."

"Uh..."

She hit the mark.

Since a certain point in middle school, even when I was offered good jobs, I didn't feel motivated, and after entering high school, the amount of work decreased.

Actually, I was unsure whether I should continue on the path of acting.

It wasn't that I was bothered by my mother's reputation for playing many villainous, hated roles, but rather that I no longer found joy in acting itself...

Or... though I didn't show it, maybe I was rebelling against following the same acting path as my mother because I was entering a rebellious phase.

"Around the same age, I was also unsure whether to continue as an actress. That's when I met Sakuya-san."

"Dad...?"

"Yes. I thought that if you could have a fateful encounter too..."

"That's..."

I've heard that my mother meeting my father wasn't a setup as reported by some media, but truly by chance.

I'm 16 too. Honestly, I am interested in boys.

I know that if I go to a co-ed school, there will be male students.

But wait, I've heard that transfer exams for co-ed schools are quite difficult. Will I be okay?

"I think transferring is much stricter than entering from the start.

But you know, at Sairei, there's a wonderful boy who's your brother, just one month older than you. His name is Yuu. Do your best to get in and become friends with him."

"Huh..."

Though I was confused when first told, when she showed me a photo of Yuu taken just recently, I found myself drawn to him at first sight.

*This person is my brother. He's cool. I want to meet and talk to him.*

*What does his voice sound like? What expression would he make if I talked to him?*

My first time being conscious of a boy as the opposite sex. And that person is my half-brother Yuu.

For some reason, I suddenly felt motivated.

I only had a week to prepare, but I studied frantically for the exam.

It had been a while since I set a goal and worked single-mindedly, and I lost track of time.

I heard there was an interview exam where they would ask about my appearance as a girl and my thoughts on boys, and I would have to demonstrate my strong points.

If you're good at sports, the practical exam is emphasized over the written one, and there's a path to enter the physical education course.

I think I was able to fully showcase the acting skills I've cultivated so far.

Maybe it helped that I carried a photo my mother had enlarged for me as a charm.

I passed the exam splendidly.

I heard that transfer exams are held every month, and for boys, they only have a simple interview and pass unless something extraordinary happens. But for girls, it's always a narrow gate with over 20 times more applicants than spots.

It was decided that from the second term, I would be a first-year at Sairei Academy High School.

Here's the problem.

According to my mother, Yuu has heard that they plan to transfer me in.

Now that the transfer is decided, how should I approach and interact with my brother?

I have no idea how to get close to a boy.

In the limited time, I desperately thought about it. More than for work or studying.

In the end, all I could come up with was to imitate and act like the adorable little sister characters from the romance novels and dramas I've read and seen to make him like me.  


### Chapter Translation Notes
- Translated "ナツミ" as "Natsumi" to preserve the stage name's katakana origin while rendering it naturally in English
- Translated "お祖母ちゃん" as "Grandma" for natural familial reference while maintaining the affectionate nuance
- Preserved Japanese honorifics (-san) and name order (Tsutsui Nana, Toyoda Sakuya) per style guidelines
- Translated "ギャラ" as "fee" to convey acting compensation without financial jargon
- Rendered internal monologues in italics (e.g., *This person is my brother...*)
- Translated "八方美人" as "two-faced" to capture the negative connotation of superficial friendliness
- Used fixed terms "Saiei Academy" and "Sairei Academy" consistently per reference notes
- Translated "姉妹校" as "sister school" as standard academic terminology
- Maintained explicit dialogue formatting with new paragraphs for each speaker change