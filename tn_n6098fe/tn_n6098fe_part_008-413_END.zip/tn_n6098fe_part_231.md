## 216. Beginning of the New Semester ③ ~First Love~

"Ahh! Yuu...kun!"  
"Yu, Yuu...kuun......"

Sailor uniform-clad Yoko and Kazumi energetically embraced Yuu who sat cross-legged on the bed. Yuu affectionately stroked their hair and backs with both hands. Overwhelmed by emotion after a month apart, Kazumi rubbed her tear-streaked cheek against him while inhaling the scent of his exposed neck skin - a refreshing yet primal masculine aroma that made her lower abdomen throb and moisten.

Meanwhile, Yoko reached out to touch Yuu's cheek. When their eyes met, she involuntarily giggled "Ehehe".

"Yoko, that hairstyle really suits you."  
"Ah... th-thank you..."

Her heart raced at the unexpected compliment. Being praised by a handsome boy like Yuu was pure bliss. Even normally talkative Yoko found herself speechless. When Yuu covered her stammering mouth, she melted into the kiss with dazed eyes, unconsciously extending her tongue to savor it.

***

That dreamlike summer night with sixteen classmates felt distant after a month-long separation. Since contacting boys outside school was taboo, meeting was impossible. Instead, the girls threw themselves into club activities - a happy side effect being their rapid improvement to near-starter positions as first-years.

But alone in bed, they'd recall that night and pleasure themselves repeatedly. They longed to embrace Yuu's slender yet toned body, kiss him, lick every inch of him, and feel that magnificent cock again...

Had they never known it, this burning desire might not exist. But experiencing sex with Yuu was transcendent bliss that made them grateful to be born female - an irreplaceable primal thirst.

On this first morning of second semester, Yuu seemed even more wonderful than before. Though no saying exists here about "re-evaluating a boy unseen for three days", their affection had skyrocketed during the separation. Beyond that, many girls felt his already mature aura had gained more warmth and ruggedness, enhancing his charm.

While Sairei Academy boys were generally friendlier to girls than average, Yuu surpassed them all - always smiling, never showing displeasure, and actively engaging in conversations and physical contact. This earned him cross-grade popularity.

Still, Yoko's group took pride in being his first close friends (student council excepted). That Yuu showed special intimacy to Class 5 girls - unlike his treatment of upperclassmen - brought them supreme joy. His whispered promise to meet eight of them after second period meant intimate time in the Special Male-Female Interaction Room.

***

With Nana joining, nine girls now surrounded Yuu. The double bed couldn't hold ten people, so they took turns in pairs embracing and kissing Yuu, starting with Yoko and Kazumi.

Yoko's fluffy bob now showed her ears in a neat short cut that emphasized her liveliness. Kazumi's semi-long black hair, previously in a single braid, now hung in twin ponytails suiting her gentle nature. Most strikingly, both radiated more feminine allure than a month ago - likely from basketball club training during break. Their well-toned yet curvaceous figures seemed even more proportioned than during the dormitory encounter.

Teen girls naturally mature daily, perhaps accelerated by losing their virginity to Yuu. Their expressions and gestures held a sensual maturity beyond first-years. Having two beauties pressing their bodies against him while radiating affection was irresistible for any male.

"Nnmm...churu...ahh...anmmu...eroo...aha, Yuu...kuun, more..."  
"Ah, my turn now."  
"Nn...Kazumi, stick out your tongue."  
"Aah───"  
"Fufu, good girl. Chup."

Yuu alternated deep kisses while groping their bodies. Starting over uniforms, he soon lifted their sailor skirts to touch bare skin. Unhooking their bras, he reached inside to knead their breasts.

"Ah...ann! Yuu-kun's hands...feeling my breasts...feels so good!"  
"Yuu-kun touching me is totally different from doing it myself...ahhaa, more...touch me more..."  
"Gladly. Let's make up for lost time with lots of touching."  
"Yuu...kun!"

Yoko and Kazumi no longer hid their arousal, freely touching Yuu's chest and abdomen under his polo shirt. But just as things heated up, *pipipip* - the timer signaled three minutes.

"Okay, time's up. Switch!"  
"Kuh, already...?"  
"Aahn. Right when it was getting good..."  
"Hurry up, others are waiting!"

The next pair - Mashiro and Yuma - immediately clung to Yuu. Petite Yuma (under 150cm) fit snugly under Yuu's right arm. Though Mashiro showed slight shyness, meeting Yuu's smiling gaze made her press her voluptuous body against him.

"Kufufuu...hap...py..."  
"Ah! Awaa...I might smell sweaty..."

Yuma murmured dreamily while nuzzling Yuu's shoulder. Mashiro kept holding Yuu's arm despite her worry. Though plump, Mashiro fell within Yuu's acceptable range - especially when her obvious bust pressed against him. Yuu stroked Yuma's head while pulling Mashiro close with his left arm, burying his nose in her neck.

"Sniff sniff, you smell wonderful, Mashiro."  
"Ya...ahh really, Yuu-kun...love you...love love you! Chuu"

Mashiro's hair, previously a one-sided updo reaching her shoulders, now hung straight and semi-long down her back. Contrastingly slender and childlike yet adorably proportioned, both girls were fully appealing beauties to Yuu.

After three-minute sessions with Mao/Satilat and Shoko/Kayo - all enjoying passionate kisses and embraces - only the unexpected guest Nana remained. Standing bedside, she froze under the girls' prompting gazes. Having zero non-professional contact with boys, she didn't know how to interact.

Yuu smiled gently. "Want to join, Nana? No pressure."  
"Ah...no, I...um...what should I...do?"

The earlier scenes overwhelmed inexperienced Nana, yet she felt no disgust - only a strange, aching emotion. Would embracing Yuu bring her classmates' happiness? Her swirling thoughts left her flustered. Then Mao and Satilat tapped her shoulder.

"Hesitating before Yuu-kun is too luxurious?"  
"Just jump into his arms instead of thinking?"  
"Th...thanks."

Bolstered, Nana timidly climbed onto the bed.

"Come here."  
"Uu..."  
"Ah, right. Since I just met Nana, I'd like unlimited time to help her adjust. Okay?"

The girls exchanged glances.

"Hmm...if Yuu-kun says so."  
"Fine for the first time."  
"Yuu-kun's different from regular boys after all. Fufu."  
"Welcome to our group, Nana-chan."

No objections. Yuu felt relieved - Nana seemed naturally shy, so her acceptance strengthened him as her brother.

"Mao, Satilat, everyone - thank you! I love you all!"  
"Waha!"  
"Aahn, you're embarrassing me!"  
"I love Yuu-kun too!"  
""""Me too me too!""""

Yoko's group beamed genuinely. Though secretly jealous of Nana's instant closeness through blood relation, their etiquette education taught them such feelings were shameful. They couldn't monopolize special boys like Yuu - just sharing this room with him was immense happiness. Excluding others would risk his displeasure.

But nearing the seated Yuu, Nana froze when their eyes met, plopping down awkwardly. Though she'd acted with boys in commercials, real contact was limited due to industry protections. At eighteen, dating became permissible, but Nana had no experience. She couldn't possibly initiate like the others.

"Want a hug?"  
"Eh...?"

Yuu scooted forward and wrapped his arms around the flustered Nana, lifting her like a child.

"Hyaa!?"

Petite Nana (20cm shorter) fit perfectly against him. Panicked, she placed hands on his shoulders to push away, but Yuu's arms encircling her slender back held firm. Her head rested below Yuu's chin, white ribbon tying the center-parted hair atop her head - what Emi called "twintails" when all hair is split, versus "two-side up" with back hair down.

Her soft, small body and sweet scent filled Yuu's senses - a moment reaffirming girls' wonder. Truthfully, after embracing, deep-kissing, and petting eight girls, Yuu was fully aroused, his erection obvious. The girls noticed but waited. Now Nana sat directly on his groin, feeling something hard, but had no capacity to react.

"Nana?"  
"Hii"  
"Look at me."  
"Yah"

Initially resisting, Nana now clutched Yuu's shoulders and buried her face in his chest when escape proved impossible. Yuu smiled wryly at her silence, then lifted her chin.

"Scared?"  
"N-no..."

Seeing her tearful, crimson face, Yuu felt sudden tenderness. Was this the real Nana? Such innocence was rare. 

"Adorable. You're incredibly adorable, Nana."  
"Ah...nnmu!?"

Unable to resist her downcast lashes and budding femininity - a different allure from her mother Takako - Yuu covered her small lips.

Nana's first kiss - with someone she just met - shocked her stiff.

"Sorry. You were too cute."  
"Au..."

Nana blinked dazedly, overwhelmed but not angry. Yuu gently hugged and stroked her head.

"How do you feel?"  
"Ha..."  
"Nana?"  
"I...don't know"  
"Hmm...I see."

But Nana tightened her grip on his shoulders, shaking her head against his chest like a small animal - making Yuu's heart flutter as if holding a young sister.

"Th-this is my first time...I don't understand...my head's messy...my chest feels hot and pounding...but..."

Though halting and clumsy compared to her acting skills, Yuu patiently listened. When Nana peeked up at him, her cuteness nearly made him groan - proof of his growing experience with women.

"It feels...nice maybe"  
"Nana!"  
"Femu!"

Unable to resist, Yuu kissed her again - firmer and longer. Closing her eyes, Nana offered no resistance. Yuu alternated kisses while stroking her hair and back. But soon, Nana seemed distressed.

"Hey Nana, you don't need to hold your breath. Breathe through your nose."  
"Th-that's how...?"

Nana's ears turned crimson. Stroking her long hair, Yuu whispered: "Yes. Now, let's continue."  
"Wa..."

Tilting his head, Yuu pressed their lips together - a slow kiss savoring Nana's slightly parted mouth. Relaxing slightly, her half-open eyes showed bliss rather than shame. Yuu licked her moist lips.

"Hya!"

Ignoring her gasp, Yuu pushed his tongue inside, entwining with hers.

"Mua...eyu...nnn...n...o...nna...raa...aah...ue...nnn!"

Saliva sounds mixed with cute moans. Continuous stimulation overwhelmed Nana, but she offered no resistance - perhaps yielding to feminine desire.

After minutes of deep kissing, Yuu pulled away, a string of saliva connecting them. Then he noticed: Yoko and others had climbed onto the bed, closing in.

"We tried to watch patiently but..."  
"I...can't hold back anymore..."  
"Haa, haa"  
"I want it too..."  
""""Yuu-kuun...""""

Guilt struck Yuu for neglecting them during Nana's extended session. He looked around.

"Sorry sorry. Let's move to the next stage then."

---

### Author's Afterword

Despite having an older pregnant wife, he has classmates who'll follow him to bed anytime he calls. This depicts a fragment of that enviable high school life.

### Chapter Translation Notes
- Translated "あぐらをかいた" as "sat cross-legged" to maintain physical accuracy
- Preserved Japanese honorifics (-kun) and name order (Hiyama Yoko)
- Translated explicit terms directly: "オチンポ" → "cock", "ペッティング" → "petting"
- Used explicit terminology for sexual acts: "ディープキス" → "deep kiss", "乳房を揉んだ" → "kneaded their breasts"
- Transliterated sound effects: "ぴちゃぺちゃ" → "pichapicha", "ちゅぷ" → "chup"
- Formatted simultaneous dialogue with double quotes: `「「私も私も！」」` → `""Me too me too!""`
- Maintained original Japanese terms for hairstyles (twintails, two-side up) with explanations
- Italicized internal monologues: `（ち、近い！）` → `*(C-close!)*`