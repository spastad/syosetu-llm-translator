## 217. Beginning of the New Semester ④ ~It's All Your Fault~

"My panties are completely soaked~"  
"Same here~"  
"More like, no girl here wouldn't be wet after that"  
""""Exactly~""""

"That bra is cute! Where'd you buy it?"  
"Went to Shibuya with the club during summer break. It's hard finding cute ones in my size."  
"Having big breasts is tough, huh~"

The girls chattered noisily while taking off their uniforms.  
Just hearing their voices, one might think this was a changing room.  
But they were deliberately stripping while making sure Yuu, sitting at the center of the bed, could see them.

Yuu enjoyed undressing girls himself.  
But watching girls undress themselves had its own distinct flavor that was equally enjoyable.  
Since they'd heard him say so, the girls naturally wanted him to watch carefully.  
As they removed their pale purple and pink sailor uniforms and skirts, colorful underwear in white, pink, light blue, and cream came into Yuu's view.  
Most were solid colors, but some had accent points, lace trims, stripes, or polka dots.  
With eight girls, each showed their individuality, but overall they wore underwear overflowing with cute high school girl charm.  
Only Nana hesitated, fidgeting without undressing.

"Come on, Nana-chan too"  
"Hurry and strip"  
"W-wait... uu..."

Prompted by the already underwear-clad girls around her, Nana showed hesitation but eventually nodded and reached for her sailor uniform.  
Perhaps she felt embarrassed by her underdeveloped body for a high schooler.  
But Yuma, who had a similar height and build, carried herself confidently, so Nana seemed to resign herself, thinking she couldn't act shy now that she'd been accepted as one of them.

In her white lace-trimmed underwear, Nana stood revealed.  
Not only was she short, but her breasts had little swell and her hips were small - practically a childlike figure like Yuma's.  
But her skin was fair without sunburn, and her smooth black hair shone beautifully.  
To Yuu, she was a girl who stirred protective instincts.

"Now, Yuu-kun too?"  
"Yeah. Want to take off my pants for me?"  
""""Yes!""""

Instantly, Yoko, Kazumi, Mao, and Sati swarmed around Yuu's lower body.  
Reaching for his waist as he extended his legs from his cross-legged position, they deftly unbuckled his belt and removed his beige chinos.  
Kazumi neatly handled the removed pants, storing them in the closet with the belt.  
Meanwhile, everyone's eyes were drawn to the bulge at his crotch.  
Noticing their gazes, Yuu laughed and said:

"Everyone's underwear looks sexy and cute. I want to see you naked soon"  
"Ugh, I'm happy... Yuu-kun saying that is so kind... I love you!"  
"Th-then... we'll strip now. After we undress, it's Yuu-kun's turn..."

Everyone grew excited as they reached for their underwear.  
What flashed through their minds was what happened at the lodge about a month ago.  
Without any hesitation, they unhooked bras, slipped off shoulder straps, and slid down panties.  
In moments, all eight were stark naked. Seeing this, Nana panicked and removed her underwear too.

The tall Mao, Sati, and Yoko had modest breasts but slender, long-legged model figures.  
In contrast, Yuma and Nana had loli bodies so underdeveloped they didn't look like high schoolers. From a distance, no pubic hair was visible on their lower abdomens.  
Meanwhile, Mashiro (who claimed H-cup) had plump, rarely seen voluminous breasts despite her chubbiness. Shoko also had large breasts around F-cup with her broad shoulders and muscular build.  
Kazumi was about Yuu's height, though he might have outgrown her this summer.  
Her waist looked more defined than before, making her breasts more noticeable.  
Kayo had a petite, slender yet muscular build.

"Whoa"

With nine girls, body types varied.  
To be greedy, preferences might differ.  
But what they shared was that all were beauties who loved Yuu dearly.  
That alone was enough to excite him.

"Fu-fu-fu. Now..."  
"It's Yuu-kun's turn... right?"  
"Ahh, I've been waiting so long for this moment"

The four who were late earlier - Yuma, Mashiro, Shoko, and Kayo - surrounded Yuu and reached for him.  
First, Shoko and Kayo lifted his polo shirt hem, exposing his upper body.

Someone among the watching five swallowed, their throat gulping audibly.  
From both sides of Yuu's waist, Yuma and Mashiro knelt for easier access, their excited expressions clear as they reached for his underwear.

"H-here goes..."  
"G-grand reveal!"

By now, without exception, everyone focused on Yuu's crotch.  
His penis tented the front of his underwear, clearly erect.  
As the underwear slid down, an excessively long, thick penis with deeply grooved glans and prominent veins - almost ominously so - was exposed.

"Hauu... the real thing really is different"  
"Yuu-kun's penis... can only be described as amazing"  
"Haa, haa..."

While everyone made lust-filled faces as if drooling, only Nana went "Hic!" and flinched back.  
But before she knew it, Yuma hugged her from behind, turning her face toward Yuu.

"First time seeing a boy's thing?"  
"Y-yeah"  
"I see. Everyone's surprised seeing Yuu-kun's penis. But once you taste it, you'll never forget it"  
"Eh, eh..."  
"That was around late June..."

Though usually quiet, Yuma seized the moment to recount her first experience.  
Maybe it was pent-up frustration from not being able to talk about it in class, or feeling kinship with similarly-built Nana and wanting to play senior.

While Yuma talked to Nana, she never took her eyes off Yuu's crotch.  
As Yuu lifted each foot alternately, his underwear was removed, leaving Yuu and all nine girls completely naked.  
Moreover, while Yuu's crotch was erect, all eight girls except Nana rubbed their inner thighs together, transparent liquid dripping down.

"Now, Yuu-kun. The signal, please"  
"Sure"

"Wh-what's starting?"  
"You didn't hear?"

Nana, who'd interrupted Yuma's story, asked with a puzzled look.  
Actually, while coming here, Yuu had discussed today's plan with Yoko and others, but Nana at the back hadn't heard.

"Now all girls will masturbate in front of Yuu-kun"  
"Ma-mastur...!"  
"The first to cum gets to do anything with Yuu-kun except intercourse"  
"Huh...?"

Since they had to return to class by fourth period, only about an hour remained.  
Impossible to have intercourse with each individually.  
Within limited time, they proceeded with Yuu's proposal that Yoko and others had approved.

"Here we go. Start!"

At Yuu's call, all eight simultaneously began masturbating.  
At home they might use toys or slowly build fantasies, but now they had perfect material right before them.  
Everyone stared wide-eyed at naked Yuu and started moving both hands.  
Three relatively shorter girls sat on the bed facing Yuu, while three stood on each side.  
Recalling being fondled by Yuu, some kneaded breasts and teased nipples. Kayo opened her mouth, licking two fingers as if sucking his penis.  
Most commonly, they spread their legs and played with their vaginas.  
Already, wet squelching sounds echoed around Yuu.

Watching naked high school girls masturbating around him excited Yuu too.  
Pre-cum already dripped from his erect penis.

"Ah, ah, aah! Masturbating... in front of Yuu-kun... feels so good!"  
"At this rate... I'll cum soon"  
"Yuu-kun, Yuu-kun! Yes! There... ahn!"  
"Yuu-kun's penis... penis... aun! Inside my vagina!"

Everyone kept their eyes firmly on Yuu while vigorously moving both hands.  
Except one girl frozen in panic: Nana.

"Nana's okay with this? You'll be left out"  
"Eh... no, that's... wait, me too!"

Even she, a 16-year-old girl, had normal sexual urges and some masturbation experience, though infrequent during busy days.  
But perhaps due to group psychology.  
Or affected by the room's increasingly lewd atmosphere.  
Her eyes grew moist as she stared at Yuu, feeling hot surges rising from her abdomen.

"Nn...! Ah, kuun"

Just lightly touching her privates revealed how wet she was.  
*(It feels... good... Never felt this before)*

Nana's initially clumsy hand movements gradually sped up, soon making squelching sounds from her vaginal opening.

"Ahh, everyone. You're all so sexy and amazing"

Yuu spread his legs straight forward, supporting himself with hands behind him - a pose showcasing his penis.  
He carefully watched each girl masturbating intently about 1 meter away.  
Directly ahead, Yuma and Kayo crossed legs and spread wide, fingering their vaginas while moaning.  
Nana, behind them, started late but now seemed engrossed in masturbation.

To Yuu's right, tall Mao, Sati, and Yoko each put one knee on the bed edge, masturbating focused on their vaginas.  
He clearly saw love juice dripping from their toned thighs.  
Opposite, closest to Yuu: Kazumi, Mashiro, Shoko.  
These three seemed more intense.  
Love juice sprayed "pyu pyu" from their vaginas, wetting the sheets near Yuu.  
Their whole bodies wriggled, making breasts jiggle "purun purun" - impossible not to stare.

"Yuu... kuun! Yes! There! Aah! Ahn! I-I'm... cumming!"  
"Me too... aaaaaaah! Yuu-kun... Yuu-kun! Love you, love youuuu!"  
"Me too... Yuu-kun... aahn! Amazing! Much better... than usual!"  
"Gwaah! Already... cumming cumming cumming! Aaaaaaaaaaah!"  
"Cum... ahhhn! Cumminggggggggg!"

Though self-reported, none faked orgasms.  
Girls couldn't fool each other, and more importantly, they feared Yuu's disappointment if caught.  
Or rather, no need to fake as Kazumi and Mashiro came almost simultaneously, followed by Shoko.  
Yuu thought female masturbation took longer than male, but only 5 minutes had passed.

"Kazumi, Mashiro, Shoko. You came, right? Come here"  
"Waha!"  
""Yuu-kun!""

Called by Yuu, the three joyfully reached for his crotch and pounced.  
Unmindful of tongues touching, they competitively licked his precum.  
While letting them do as they pleased, Yuu asked:

"You came faster than expected. Do you usually masturbate thinking of me?"  
""""Ugh...""""

All three stopped moving.

"Answer honestly. I won't get mad either way"  
"Um... sorry. Yes"  
"Yeah. Not so much at first, but every day since doing dirty things with Yuu-kun"  
"Feel bad toward Yuu-kun, but can't stop"

Yuu gently patted their drooping heads.

"No need to apologize. Actually I'm happy. That you think of me that much"  
""""Ah...""""

Kazumi and others expected Yuu wouldn't get angry, but not this level of acceptance.  
That made immense joy well up inside.

"Yuu-kun, really love you... love you!"  
"Aha... getting emotional"  
"Ahh, whatever I can do... I'll do anything!"  
"Then lick my penis all you want, and make me cum this time"  
""""Yes!""""

Seeing Yuu with Kazumi and others, the remaining girls grew excited and sped up their hand movements to cum faster.

Ultimately, with 2-3 minutes difference, Yoko and Kayo came consecutively, claiming positions at Yuu's sides, taking turns deep-kissing him while he fingered them.  
Next, Mao and Sati came almost together - Sati taking his back while Mao trailed her tongue over his chest.  
Surprisingly slow Yuma came eighth, burying her face in his stomach.

Now only Nana remained, masturbating desperately.  
Imitating others, her left hand teased nipples while her right index finger pulled back hood and stroked clitoris.  
Her initially soft moans gradually grew louder.

"Ahh, masturbating Nana is... cute, sexy, wonderful. Ugh... kuu!"

While being kissed alternately by Yoko and Kayo at his sides, occasionally by Sati behind, and even fought over by Mao, Yuu stared at Nana spreading her legs before him.  
With Kazumi, Mashiro, and Shoko enthusiastically fellating him with hands and tongues, he neared his limit.

"Ahh... nn! Nnn! Masturbating feels this good... for the first time... aahn! This fast... ah! Cumming!"  
"I'm close too. Nana, let's cum together"  
"Nn... brother"

"Ahh, such a cute little sister, Nana"  
"Nana-chan, come here?"  
"Eh, really?"  
"Sure. We're comrades now"  
"Th-thank you!"

As Mashiro and Shoko straddling Yuu's left leg made space between them, Nana hesitantly entered, nearly skin-to-skin.

"Wow... this is brother's penis... Smells so strong up close"

While Nana lay limp, Yuma joined too. Four tongues thoroughly licked away remaining semen until it shone with saliva.  
Of course, one ejaculation wasn't enough to calm Yuu.

"Hey, doesn't this area make you go 'kyun'?"  
"Eh?"

When Mashiro pointed at her lower abdomen, Nana tilted her head pensively.  
Then nodded firmly.

"Kinda feels like that. Why?"  
"Because it's Yuu-kun's penis"  
"Brother's..."

Nana timidly reached out and touched the penis, surprised by its heat and hardness but unable to stop touching.

With Nana joining last, all eight changed positions and continued until Yuu ejaculated again before time ran out.

---

### Author's Afterword

Though I considered using empty classrooms or school areas since it's been a while since school started, Sairei Academy has rooms prepared where boys and girls can get naked and do dirty things without reservation, so naturally they went there.

### Chapter Translation Notes
- Translated "パンツ" as "panties" to match underwear context
- Preserved Japanese honorifics (-kun, -chan) and name order (Tsutsui Nana)
- Transliterated sound effects (e.g., "guchu guchu" for ぐちゅぐちゅ)
- Used explicit anatomical terms ("penis", "vagina", "clitoris") per style rules
- Rendered sexual acts without euphemisms ("masturbation", "ejaculation")
- Italicized internal monologues (Nana's thoughts)
- Maintained dialogue formatting rules (new paragraph per speaker)