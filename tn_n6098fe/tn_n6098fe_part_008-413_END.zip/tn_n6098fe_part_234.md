## 219. Preparing for the Student Council Election ② ~She Is Blue~

The revised election process decided by Yuu, the student council, and the three election committee members was announced over the school intercom during lunch break two days later on Thursday, and also posted on bulletin boards throughout the school.

Some voices expressed confusion at the sudden announcement.

However, since the conventional election had become impossible due to the flood of female students wanting to join the student council with Yuu, and with the current student council including Yuu directly involved in the selection process, there was no choice but to accept it, and no voices of opposition were heard.

The charisma of Komatsu Sayaka as student council president might have also played a role.

To save effort, the application forms would be used as-is for document screening since they already included sections for motivation and vision for joining the student council.

Although already submitted, resubmissions were allowed until the following Monday, and about 70% of students came to retrieve theirs. The remaining 30% likely either didn't need to rewrite theirs or weren't serious from the beginning.

After school that Saturday (9/15), Yuu boarded the car prepared by the Komatsu family as usual. Normally, it would first head to Yuu's house, but today it stopped at the condo where Sayaka and Riko lived, dropping them off.

"Then, Yuu-kun and Emi, good luck!"  
"Persuade her well, okay?"  
"Mm-hmm"  
"Yesss!"

Since it would take about 40 minutes by car to reach their destination, Yuu and Emi talked while eating sweet breads bought from the school store as lunch.

"I'm getting a little nervous"  
"Mou, it'll be fine! It'll definitely go well since Yuu-kun is coming"  
"You think so?"  
"Yep. Ah, Yuu-kun, you've got cream on your mouth"  
"Huh?"

The sweet breads Emi had chosen were mostly sweet varieties, and while eating a melon pan with custard cream filling, some cream had smeared around Yuu's mouth. Emi scooped it up with her finger and licked it off.

"Ufufu, so sweeet"  
"But Emi, you've got chocolate on your nose"  
"Eh, really!?"

Before Emi could check with her own hand, Yuu's finger reached toward the tip of her nose.

"Just kidding!"

Yuu's finger touched Emi's slightly moist lips instead of her nose, then brought it to his own mouth for a kiss.

"Jeez, Yuu-kun, you're so..."  
"Hahaha"

While joking lightly with Emi like this during their meal, the vague anxiety Yuu had felt earlier disappeared from his chest. However, neither noticed that the two women in the front seats - the driver and bodyguard - were suppressing envious feelings and biting their lips.

***

After it was decided to determine the next student council through selection rather than election, Emi had made a proposal: to recruit the girl who had served as student council treasurer until last December. Her name was Ogawa Mizuki. She was in the same grade as Emi.

In their first year, though in different classes from Emi, they apparently became close through student council activities.

Yuu recalled hearing about her when he first visited the student council room. She had developed feelings for the male vice president who was a year above her, and while her Christmas confession was accepted, things went wrong. Due to having many rivals, her obsession didn't stop. Immediately after winter break began, she invited him to her house to establish a relationship, then essentially confined him.

Even though her parents helped their child, such tactics couldn't lead to a happy ending. He was separated after about a week. The boy transferred to a boys' high school right after the third term began. Mizuki received suspension until the end of the academic year. Though she advanced to the next grade, Emi said she rarely attended school even in the new year. Probably because her actions were far removed from Sairei Academy's education for young ladies, earning her cold stares from others. Emi was the only one maintaining their friendship unchanged.

"Mii-chan is really a good girl at heart. Serious, smart, quiet personality, the type who couldn't even speak to boys on her own"  
"Then how did...?"  
"Through student council activities, Ooyama-senpai was kind to her. I think she must have gotten carried away. But... she was being bullied by the second-years who were dating Ooyama-senpai, having bad experiences. And Mii-chan herself seems to have a personality that broods over things. It ended in an explosion"

Ooyama-senpai was presumably the male vice president who was in the same year as Sayaka and Riko. Handsome and sociable, kind to all the girls - similar to Yuu in that sense. With Riko as trusted vice president, and competent first-year secretary and treasurer, Sayaka's student council seemed full of talent off to a smooth start. But tragedy awaited, it seemed.

The reason they were heading to her house was that Emi requested Mizuki's comeback if she herself remained as secretary. Initially, Sayaka and Riko didn't agree. Did Mizuki even have motivation? Would students who knew about last December's incident accept her?

She deeply regretted what happened. But she'd become reclusive, and if this continued, she might never recover as a proper high school student. It would also be a waste to leave unused Mizuki's skills as treasurer. They wanted to talk thoroughly and see if she had the will to participate in student council activities again. Emi persuaded them that Yuu's cooperation was essential for this, and finally Sayaka and the others agreed.

***

"We've arrived"  
"Ah, really"  
"Eh... here?"

At the driver's words, Yuu looked out the window. The residence surrounded by high walls had an angular design like stacked white and light gray boxes. It felt larger than average homes but not exactly a mansion. However, it seemed newly built within the last decade. The car passed through an automatically opening shutter into a neatly maintained garden.

"I heard her family was wealthy, but..."  
"Mm. Her grandmother started a financial company after quitting the bank, and I think her mother is an executive at the same company"  
"Oh"

As in Yuu's previous life, consumer loan companies thrive during economic downturns. The business Mizuki's grandmother started was new, and while not a major corporation, it had grown to a mid-sized company with dozens of branches mainly in Tokyo and the capital region. Meaning, it seemed to be a three-generation family strong with money.

***

"My! Emi-chan, welcome!"  
"Hello, Ichika-san. Is Mii-chan here...?"

Greeting them was a housekeeper in a white apron, around her late 30s, radiating warmth. She seemed familiar with Emi from her frequent visits. Since her grandmother and mother were often absent due to busy work regardless of the day, she had apparently handled all household affairs for years.

"Huh! A... boy?"

The housekeeper showed surprise upon seeing Yuu behind Emi.

"He's in the same school and helps with student council"  
"Ah, hello. My name is Hirose"  
"My, my, well now"

Though recoiling in surprise initially, seeing Yuu bow politely, the housekeeper quickly recovered and welcomed them with a gentle smile.

"Still, didn't expect to be taken straight to her room"  
"Ahaha. That's how it always is when I come"

Yuu and Emi were in what seemed to be Mizuki's private room - a two-room suite. Its area alone was about the size of a house's living room. Leather sofa seating for five. Large TV with stereo set. Tall bookshelves packed with books. A sturdy wooden desk like executives use. Though curtains and wallpaper used floral lace patterns, overall it didn't look like a high school girl's room at all.

Beyond the door was a bedroom and closet room, where the housekeeper had gone to wake her. Her parents didn't nag about school absences but compensated by hiring tutors for thorough home study. According to the housekeeper, she'd studied late last night, and since no tutor came this Saturday, she was sleeping in.

Though voices could be heard talking, there was no sign of her coming yet. After finishing the tea served by the housekeeper, Yuu stood up and began looking at the bookshelf contents and items on the desk. Examining the spines, accounting and business management books dominated. A thick book with many sticky notes seemed like a textbook for bookkeeping qualifications. Apparently planning to inherit the family business.

Though frequently absent from school, she hadn't neglected self-improvement efforts. Indeed, Mizuki had committed an error by going mad with love. But perhaps her competent, earnest nature that Emi mentioned remained unchanged. Rather, her earnestness might have prevented her from maintaining emotional composure.

"Emi. Sorry to keep you..."  
"Mii-chan!"  
"Fwah!"

The door opened as Mizuki appeared. Reacting quickly to her voice, Emi rushed over and hugged her.

"Mou, you still haven't come to school at all this week. I was lonely"  
"Ah, hah. You're still... the only one who says things like that, Emi"

Yuu, who had been looking at the bookshelf by the wall - exactly where Emi's body created a blind spot - kept his distance to avoid disturbing the hugging pair. Mizuki was about 7-8cm shorter than Emi, who was around 160cm. Yuu recalled seeing a photo displayed in the student council room, taken around last October.

Emi with her usual twin tails and radiant smile. Next to her, a girl with a shy, modest smile was introduced as the treasurer Ogawa Mizuki. Semi-long black hair with one side in a braid, plus large doe eyes and small mouth - a demure beauty. That she could commit the serious act of confining an older boy might be hard to believe for Yuu as a male.

"Ah, right! I have to introduce you to Mii-chan"  
"Eh!?"

Emi pulled away and reached a hand toward Yuu.

"This is Yuu-kun, a first-year who's been helping with student council since April"  
"Hello, nice to meet you"  
"W-w-w-w-wait eeeeeeeeeeeeeeeeh! Nooooooooooo! I-I didn't hear! Ichika-san just said it was student council people, so I thought it was Riko-senpai!"  
"Ehehe, surprise success"

Apparently, on Emi's whim, she hadn't mentioned it was a boy. Instantly, Mizuki's face turned red and she hid behind Emi. Her unexpectedly innocent reaction made Yuu smile wryly.

Though only glimpsed, Mizuki wore pink pajamas of a one-piece dress type with abundant frills, looking very cute. Her hair was longer than in the photo, with ends nearly reaching her waist. She might have combed it, but bedhead was still visible. What caught Yuu's eye most was her large bust, more prominent than Emi's despite her smaller frame. Perhaps the largest in the student council, surpassing even Sayaka.

"Emi, and Mizuki-senpai! Let's sit and talk first?"  
"Right. Come on, Mii-chan, stop being shy!"  
"M-Mizuki... senpai... Calling a boy senpai..."

Still dazed at Yuu's words, Mizuki was led by the hand to the sofa by Emi. The two girls sat on the three-seater while Yuu faced them from the opposite seat. But Mizuki pressed her face tightly against Emi's shoulder, unable to meet Yuu's eyes.

"Aaaaaah... Whyyyy? If I'd known such a handsome boy was coming, I'd have prepared properly. Mou, Emi, you're so mean"

At these words, Emi smiled mischievously and grabbed Mizuki's shoulders to make eye contact.

"Seeing Mii-chan react like this makes me glad I brought Yuu-kun. Have you gotten over Ooyama-senpai now?"  
"Ah... hey, could it be...?"

Mizuki glanced alternately between Emi and Yuu.

"Ah, I've heard most about Mizuki-senpai. Including last year's incident. I came knowing that"  
"Why? You know I'm the worst girl who did that, right? Even after advancing grades, people whisper about me. It's true I wasn't myself back then due to various things, but I really didn't want to let anyone have Ooyama-senpai..."

Mizuki looked down, fidgeting with her hem as she spoke. To Yuu, since she felt guilt and recognized she'd done "the worst thing," there might still be hope.

"You must have really liked the vice president senpai, right? I think I understand the feeling somewhat"  
"Hah? Understand? Don't act like you know, you're younger!"  
"Mii-chan?"  
"Sorry, Emi. Partly because senior girls bullied me back then... but having ugly feelings like wanting Ooyama-senpai all to myself is entirely my fault! I... maybe shouldn't fall in love"

"Taking forceful action was certainly bad, but where is wanting someone all to yourself ugly? Isn't that a normal human feeling?"  
"Eh?"

Not just Mizuki, but Emi too looked at Yuu in surprise.

"I might lack credibility saying this as a guy getting along with many girls. But if Sayaka, Riko, and Emi got close to other boys, I'd get jealous. Might even say 'these girls are mine'"  
"Y-Yuu-kun?"  
"Eh? Eh?"

"Come to think of it, there was that day I first entered the student council room and heard them talking. Hearing Sayaka and the other two say how cool and wonderful the male vice president was made me jealous"  
"Really? First time I'm hearing this"  
"Haha. Too embarrassed to say"

"Sorry, I don't really follow"

Mizuki's expression looked like she had question marks floating above her head.

"Right, right. Haven't explained yet. I'm dating Sayaka, Riko, and Emi. And since they got pregnant, we got engaged last month"  
"Yep. Currently 4 months pregnant. About 16 weeks? Sorry for the late report, Mii-chan"

Emi rubbed her belly. With minimal morning sickness, her pregnancy wasn't showing much yet - her belly bulge wasn't noticeable even without clothes.

"Eh? Eeeeeeeeeeeeeeeeeeeeh!!!"

Mizuki opened her mouth wide and let out the loudest scream of the day.

---

### Author's Afterword

Originally for Chapter 6, I had two ideas about Yuu meeting and developing relationships with upperclassmen who'd experienced heartbreak after the second semester began. With the next student council selection underway, I decided to recruit the former treasurer. Actually, her name was decided long ago.

Regarding Mizuki's predatory romance in December, it was mentioned in "16. High School Enrollment ③" when Yuu was invited to the student council. Rereading it, I adjusted the details for consistency.

Emi hadn't told her close friend Mizuki about the engagement and pregnancy because she considered such topics taboo for her heartbroken friend.

### Chapter Translation Notes
- Translated "ブルー" as "blue" to convey melancholy while preserving cultural nuance
- Translated "パジャマ" as "pajamas" maintaining Western loanword convention
- Preserved Japanese honorifics (-kun for Yuu, -chan for Mizuki)
- Translated "軟禁" as "confined" to accurately reflect the severity of Mizuki's past actions
- Translated "既成事実" as "establish a relationship" to convey the implication of sexual involvement
- Rendered scream "えええええええぇぇぇぇぇぇぇぇぇぇぇぇぇ" as "Eeeeeeeeeeeeeeeeeeeeh!!!" for equivalent impact
- Translated "意地悪" as "bullying" to match school context
- Translated "家庭教師" as "tutor" as standard educational term