## 220. Preparing for the Student Council Election ③ ~Awakening~

The only reason Mizuki avoided expulsion from Sairei Academy after committing a near-criminal act was entirely due to her victim, Oyama-senpai, shielding her. 

Even while confined, he never panicked or uttered a single word of resentment. 

His occasional troubled expression might have anticipated Mizuki's scheme would soon collapse. 

He was simply an exceptionally kind-hearted man—perhaps too good-natured. 

The three-month suspension—overlapping with spring break, effectively less than three months—was more than enough time to cool her head. 

Oyama-senpai transferred to a boys' high school per his parents' wishes, leaving Mizuki no chance to meet him or apologize. 

When Mizuki returned to school for her second year, no one openly condemned her, but no classmates approached her either. 

Mizuki never had wide social circles to begin with and had built walls around herself. 

Only Emi, now in the neighboring class, maintained the same attitude as before. 

In her gray school life, Emi was Mizuki's sole salvation. 

When Mizuki looked gloomy during their private moments, Emi would hug her and stroke her head. 

Having grown up with abundant material possessions but little parental affection or physical contact, love-starved Mizuki felt genuinely warmed by Emi's actions. 

She nearly developed feelings beyond friendship. 

But recognizing her own unexpectedly strong dependency, Mizuki deliberately maintained a cool demeanor to avoid burdening her important friend—though this rarely worked against Emi's sun-like warmth. 

After apologizing to the student council, Mizuki resigned to take responsibility for causing disturbance. 

She was shocked when Sayaka and Riko not only didn't blame her but tried to persuade her to stay. 

However, Mizuki chose to resign, weighing that her continued presence would burden her revered president and vice-president—and Emi—while attracting criticism. 

Her plan was to dedicate her remaining high school life to studying with private tutors, minimally attend school for credits, remain invisible, avoid Sairei's unique gender-exchange events, and need no friends besides Emi. 

*Girls like me who go crazy when in love shouldn't interact with boys.* 

*I'll live unmarried without forming bonds with men.* 

That's what she thought—until Emi brought Yuu. 

The news that Yuu would run for student council president. 

That Emi planned to continue as secretary alongside him. 

That they came today to recruit Mizuki as the next student council accountant. 

Mizuki seemed frozen by the rapid-fire revelations. 

Even with her sharp mind, the utterly unexpected content overwhelmed her into speechlessness. 

"Mi-chan, what do you think? Wanna join us starting October?" 

"You've been studying hard, right? I'd feel reassured with Mizuki-senpai with us." 

Before she knew it, Yuu had circled the table and stood beside Mizuki—sandwiched between Yuu and Emi. 

"W-wait... no." 

""Why?"" 

"First of all, even if I ran, I wouldn't get any votes." 

"It's fine!" 

Already mentally overloaded and flushed bright red, Mizuki barely managed words—only to be easily refuted. 

"Because of me, too many candidates applied. So this time, instead of voting, the current student council will select through documents and interviews. Frankly, who gets in depends entirely on our discretion." 

"Eh..." 

"Mi-chan, please." 

"Mizuki-senpai, let's do student council together?" 

"Auuuuuu..." 

Sandwiched between them, Mizuki turned lobster-red before suddenly standing up. 

"I'm... taking a bath! I sweated yesterday but fell asleep without washing." 

"Eh, but—" 

"Then let's bathe together for old times' sake!" 

Cutting off Yuu, Emi wrapped an arm around Mizuki's shoulder and forcibly led her away. 

Passing Yuu, she whispered softly: 

"Yu-kun. After bath, let's all go to bed?" 

"Hm? Really?" 

"Ufufu." 

Fortunately, Mizuki seemed too flustered to hear. 

Seeing them off through the door, Yuu shrugged. *Emi sure takes forceful approaches even with close friends.* 

But Yuu genuinely found Mizuki attractive at first sight—he had no intention of refusing. 

Assuming girls' baths took time, Yuu returned to the bookshelf, scanning every corner. 

Most were serious books, but on the top shelf—unreachable for Mizuki and barely reachable for Yuu—he found paperbacks. 

Their titles made him smile: all romance novels. 

*So Mizuki's still a girl her age after all.* He felt relieved. 

Over an hour later—not just thirty minutes—Yuu grew engrossed reading unexpectedly explicit love scenes (both heterosexual and lesbian) when voices approached. 

"Emi-chan, stop squeezing my breasts so much!" 

"But Mi-chan's boobs are so fluffy like marshmallows~" 

"They're just lumps of fat!" 

"Tsk, tsk, tsk! Breasts are filled with hope!" 

"Never heard that!" 

"Yu-kun said it!" 

Emi opened the door just as Yuu frantically returned the paperback to its place. 

Both had changed: Emi borrowed Mizuki's elegant floral long T-shirt—braless with visible nipples, covered to her hips but only wearing underwear below. 

Compared to bold Emi, Mizuki was relatively modest in a knee-length black camisole—though her large breasts stretching the fabric drew inevitable attention. 

Both had their long hair in twin buns—adorably cute. 

Yuu nearly hugged them, taking two steps before catching himself. 

"Th-then... I'll borrow the bath too—" 

"Yu-kun's fine as is. Rather, better stay." 

Emi took both their arms, leading them toward the bedroom door. 

Mizuki followed passively. Understanding Emi's intent, Yuu opened the door, ushering all three inside. 

"Chu, chu, chu! Mi-chan's cheeks are so smooth and nice!" 

"Hya... w-wait... nn! Ah, don't... do that so much... ahn!" 

"Emi, my turn now." 

"Ahn, Yu-kun. Chu!" 

On the king-sized bed with Mizuki in the middle, Yuu and Emi exchanged hugs and kisses from both sides. 

Emi with Mizuki. Yuu with Mizuki. Yuu with Emi. 

This cycle repeated endlessly. 

Already undressing each other, all three were down to underwear. 

Yuu and Emi each held Mizuki with one arm while constantly kneading her ample breasts with the other. 

Only Mizuki had her bra removed first, being directly fondled. 

As Emi said, Mizuki's breasts truly felt marshmallow-soft. 

Beautiful conical shapes protruding from her petite frame—Yuu estimated F-cup size. 

Perfect for kneading the heavy weight from below or palming nipple-first from the front. 

Yuu and Emi tirelessly continued, drawing endless sweet moans from Mizuki. 

"Ufufu! Doing this with Yu-kun and Mi-chan is so fun!" 

"Wh-why... ahn...! Aren't you two... bothered?" 

"Eh, not at all." 

"We're used to it." 

"Right, right." 

"Hey, Yu-kun. Let's make Mi-chan feel even better." 

"Good idea. Agreed." 

"Hyan! No, don't play with my nipples... aah! Ah... kuhii... yah... ah... fuumu!? Nn, nn, nkuun..." 

Kneading breasts and pinching nipples from both sides, Emi captured Mizuki's lips with her tongue. 

Yuu moved his hand from her back to her head, tracing his tongue into her small ear. 

"Gwaah! Nnii, nn, mmo... kuuaa... amu, chupaa... haa, haa, haa, E-Emi!" 

"Mi-chan. Feels good even girl-to-girl, right?" 

"Gwaa... aun... yes..." 

Seemingly aroused by Yuu's ear caresses and Emi's deep kiss, Mizuki pulled Emi closer, audibly tangling tongues. 

Meanwhile, Yuu trailed kisses from ear to neck with lips and tongue—shoulders, collarbones, all meticulously attended, occasionally nibbling. 

Her rarely exposed snow-white skin bloomed red marks like flowers wherever Yuu's mouth traveled. 

When Yuu's mouth reached her bud-like pale pink nipple, he took it in. 

"Faaaaaaaah! Ah, ah, ahi!" 

"Ah! I'll suck Mi-chan's boobs too!" 

Drooling a thread of saliva, Emi latched onto the opposite breast. 

Yuu skillfully rolled the nipple in his mouth with his tongue, gently biting. 

Mizuki couldn't endure it. 

"Yah... aee... that's... cheating! Iiiiiin! Ihiiin! Ahn! Ahn! Hiiun!" 

As Mizuki arched back panting, they laid her flat on the bed without stopping. 

Yuu's right hand stroked downward from her belly to waist, then thighs. 

Yuu had noticed earlier: Mizuki's body was slimmer than average—distinct waist, plump thighs but slender below knees—yet disproportionately large breasts that aroused men. 

Yuu signaled Emi with his eyes to spread Mizuki's legs together. 

The white silk panties felt smooth. Yuu's fingers slid down to her crotch, tracing her pubic mound up and down with fingertips—making Mizuki's body jerk. 

"Fufu, she's wet." 

"My, really!" 

"Yaaaaaaah... really, enough... this is too much! Ahn! D-don't toy with me..." 

"Aahn! Mi-chan, so cute!" 

As Yuu and Emi fingered Mizuki's pussy through her panties, she teared up, shaking her head in refusal. 

To Yuu, this only seemed erotically adorable. 

While intermittently kissing and fondling breasts, they kept moving fingers over the soaked panties—now visibly stained, making squelching sounds. 

"Let's take these off." 

"Then we'll strip completely too." 

"Ahaha. Yeah." 

Mizuki seemed to have lightly climaxed from their dual stimulation, lying unresisting as her last garment was removed, exposing her dripping slit. 

She hadn't even seen Yuu remove his underwear. 

Emi lovingly stroked his cock while Yuu's hand went to Emi's crotch. 

His cock was fully erect; Emi—only kissing Yuu otherwise—was also wet. 

While Emi lay over Mizuki, fondling breasts and kissing passionately, Yuu moved to her lower body. 

He parted her closed legs and positioned himself between them. 

He saw love juice already staining the sheets. 

When Yuu grabbed Mizuki's thighs, she briefly resisted—but weakened by Emi's caresses, she yielded. 

Her spread legs opened her labia slightly, revealing her glistening wet vaginal opening. 

Though experienced, her salmon-pink slit looked virginal in its beauty. 

The thoroughly soaked sight excited Yuu intensely. 

Like a summer moth drawn to light, Yuu approached with tongue out. 

"Gmmo! Gwe... nna! Don't... there! Aaaaaiin!" 

"Ah, Yu-kun started licking! Nice, Mi-chan. Yu-kun's amazing at cunnilingus! He's the only boy who licks so enthusiastically!" 

"Ah, ah, so much... noooooo!" 

"Ufufu. I can hear the sounds. Mi-chan, feels good? Gonna cum?" 

"F-feels... faaaaaaah! Ah, ah, ah, ahn! Nooo, really no... aahn!" 

Yuu licked obsessively. 

Though seemingly odorless after bathing, the aroused female scent tickled his nostrils, stimulating male instinct. 

His long tongue probed her vaginal opening like digging, drawing spring-like gushes of love juice. 

When he stimulated her small clit under the hood, she squirted, wetting his face. 

He felt thrilled as a man that his first-time partner felt so intensely. 

Yuu redoubled his efforts. 

"Ah... ahe... gwaah! Th-this... too much... I'm cumming... I'm cummiiiiing... Ei... Mi... gwaaah!" 

"It's okay, Mi-chan. Don't hold back—cum." 

Mizuki climaxed while tightly embracing Emi—an ecstasy warmer than any pleasure she'd known. 

"Chu, chu, Yu-kun." 

"Fufu. Emi's not just cute in face and voice—even her clingy gestures are adorable." 

"Aahn, happy." 

After Mizuki climaxed and quieted, Emi clung to Yuu, repeating hot embraces and kisses. 

They kissed not just lips but cheeks and ears while groping upper bodies. 

Emi wrapped her left arm around Yuu's back, her right hand slowly descending from his chest to cup the tip of his erect cock. 

Her soft, feminine touch raised Yuu's arousal despite her gentleness, making clear fluid seep out. 

Yuu had been kneading Emi's perfect C-cup breasts but soon moved down to her belly, caressing it like fragile porcelain. 

At four months pregnant, some show physical signs—but Emi, without morning sickness, remained as slim as ever. 

Yet the OB-GYN confirmed life grew within. 

So Yuu stroked her belly tenderly. 

"Fufu, that tickles, Yu-kun." 

"Feeling okay?" 

"Totally fine. If anything, my appetite's increased annoyingly." 

"It's fine. You were always slim—just get proper nutrition." 

"Ufu. Then maybe I'll get nutrients from here?" 

"Oh?" 

Emi stroked his shaft before lightly gripping and moving it up-down. 

Facing Yuu, neither noticed Mizuki sit up from her supine position until Yuu spotted her. 

"O...o...o... cock... ehe... my... cock" 

"Huh?" 

Yuu noticed Mizuki looked strange—expression blank, face pale, eyes fixed on his crotch. 

She seemed a different person. 

Muttering while staring at his groin, Mizuki suddenly crawled on all fours before him. 

Pushing Emi aside, she brought her face to his crotch, opened her mouth wide like a crescent moon, and swallowed his cock whole. 

---

### Author's Afterword

2020/7/6

Regarding the final description: I corrected inconsistencies in positioning and movements between Yuu/Emi and Mizuki regarding "sleeping very close" and "slightly distant positions." 

Please imagine Yuu and Emi were near Mizuki's feet as she lay on her back.

### Chapter Translation Notes
- Translated "茹で蛸" as "lobster-red" to convey intense blushing while preserving the cooking metaphor
- Translated "マシュマロ" as "marshmallows" for tactile description of breast texture
- Translated "おマンコ" as "pussy" per explicit terminology requirement
- Preserved Japanese honorifics (-senpai, -kun, -chan) throughout
- Transliterated sound effects (e.g., "chu" for ちゅっ, "gwaah" for ぐわっ)
- Maintained original name order (Ogawa Mizuki, Ishikawa Emi)
- Translated sexual acts directly: "クンニ" as "cunnilingus", "チンポ" as "cock"
- Used explicit anatomical terms: "vaginal opening", "clit", "labia"