## 221. Preparing for the Student Council Election ④ ~Don't Stop the Love~

"Wufo...chu~lulu! Lero lero...jupa jupa un moo...ohhi, ohinpoo...ohfuhiru...ofuhi, ippaai...uhi...remo, ohii, ohinpo, oihiiro...amuchu, n~rerochuumu, juru...jururi! Jupo jupoo!"

Mizuki, who had buried her face in Yuu's crotch while sitting cross-legged, was sucking his cock with single-minded devotion.

Yuu and Emi exchanged wry smiles. Though Emi had been pushed away while lovingly stroking Yuu's cock with her hand, she looked more surprised than displeased. Yuu had been skeptical, but Emi had anticipated this. She'd deliberately provoked Mizuki's true nature - the way people change when sexually involved with men - by somewhat forcibly initiating things.

"Ugh...kuh...amazing..."

Yuu moaned while stroking Emi's head beside him. Mizuki was now completely engrossed in the cock, moving her mouth diligently to suck every inch. Unlike Sayaka and others who prioritized Yuu's pleasure with service-oriented blowjobs, Mizuki moved as if determined to savor every part of the cock. Though it felt good, her rough mouth and hand movements occasionally bordered on painful.

"Anmu!"  
"Guo!"  
"Muuu~hyugoi...fohii...n, n, mo, mo, jururero"

Drooling from her mouth, Mizuki released the glans and meticulously licked down the shaft. With a dazed expression, she noisily sucked on both balls: *chu-chu-chupa-chupa*. After coating both testicles in saliva, she licked back up to the coronal ridge. Then, grinning as she curled her lips, she wrapped one arm around Yuu's waist as if to say "I won't let you escape," opened her small mouth wide, and took him deep inside. She swallowed him so completely that Yuu could feel himself reaching the back of her throat. Where most would gag, Mizuki's eyes gleamed brightly as she pursed her lips and worked her tongue. Then she slowly began bobbing her head up and down.

"Ngk!"  
"Haa~n. This cock...IS. A. MA. ZING! What should I do...I can't decide~"

Mizuki pulled back with a *zuzuzu* sound, licking the urethral opening *chiro chiro* to suck up the pre-cum. Tracing the shaft with her finger while wearing an enamored expression, she murmured while staring intently:

"I wanna drink your semen...but since it's so precious, maybe I should put it inside me instead. Hey, let's do it?"

Mizuki looked up at Yuu as she raised her upper body. Her large, sparkling eyes would have had heart marks floating around them in a manga. Yuu honestly found it cute. Though phrased as a question, her attitude brooked no refusal. As proof, she pushed Yuu down while clinging to his chest. Since the woman-on-top position was standard, she likely assumed this was natural. But if he fell straight back, his head would hit the headboard, so Yuu shifted his hips.

"Noo~, I won't let you escape~"  
"Wait, that's not...mmph!"

Mizuki straddled Yuu's stomach as he lay on his back, firmly grabbing his head and shoulders with both hands before sealing his lips. Her small frame possessed surprising strength. As Mizuki invaded Yuu's mouth with her tongue, he responded in kind. The sensation of her voluptuous breasts pressed against his chest heightened Yuu's arousal, and he actively tangled his tongue with hers. Meanwhile, Mizuki moaned muffled gasps while gradually moving her hips, rubbing her thighs together to savor the sensation of the hard, hot cock.

"Ahh...this feels good too."  
"Uhuhu. Cock...cock...cock...ahn! O...cock...so hard...and hot...I can feel it...haun...love it."

They enjoyed the genital contact just before penetration.

"But...I can't...wait anymore...I want it...want it want it want it want it want it want it want it iiiit! So I'm putting it in?"  
"Gah!"

Without even looking, Mizuki guided the cock pressing against her vaginal opening and took it in. She adjusted the angle and lowered her hips.

"Hae? Gah...gaaaaaaaaah!"  
"Gu...tight!"

Mizuki seemed to try inserting it all at once but couldn't, crying out instead. Despite having sucked it extensively and knowing its size, perhaps her long abstinence had dulled her sense of scale. Or maybe she'd assumed it was the same as her ex. To Yuu, her vaginal tightness felt almost virginal. When the insertion stopped midway, Yuu tried to help, but Mizuki kept a firm grip on his shoulders and forcibly lowered her hips to take him to the hilt.

"Gafe...i-it's amazing...f-feels like...the cock's...piercing deep inside me...my insides...are full. Ah...my pussy...stretched so wide...hooowowow...th-this is...my first time..."

Though they hadn't even moved yet, Mizuki looked up with a deeply moved expression. Drool dripped *tsutsu~* from her half-open mouth. Her shoulders visibly trembled - likely from already orgasming.

After a while, Mizuki looked down at Yuu, opened her mouth crescent-wide, covered him, and *kapu!* sucked hard on his neck. Sucking hard enough to leave a mark, her hips gradually began moving.

*(Feels like I'm literally being devoured here)*

Yuu, currently passive, thought this. He intended to let Mizuki have her way for the first round. That said, he'd been experiencing intense pleasure even before penetration. Having not ejaculated yet today, combined with Mizuki's tight vaginal walls whose folds clung to his cock, provided constant stimulation.

"Kuh...ahh! I-It feels good!"  
"Ahaa...me too...feels so good...ahn! So good! Haah, haah, haah...but hold on...a bit longer...n, n, more...I wanna feel...more of this cock..."

Mizuki's hot breath brushed Yuu's ear. Clinging tightly with her upper body pressed flush against him, only her hips moved *guni guni*. As she regained her rhythm, the stimulation intensified. Beyond simple thrusting, she sometimes drew circles while buried deep inside. The overwhelming pleasure made Yuu's hips twitch involuntarily. His hands unconsciously roamed her back and buttocks.

"A, a, a, ah! Afuun...I'm...c-c-cumming agaiiin! M-my hips...won't stop ooooooh, oh, nha! Shoko! Shokoshokoshoko! Right there...hitting the good spot...bwaaaaaaah! Can't take it! Genka...gaah! Ah! Ah! Ah!"  
"Guuh...moving like that...I-I'm...gonna...!"

Starting slow and quiet. Then rhythmic, searching for more pleasurable spots with fluid movements. After Mizuki came midway, her movements grew fiercer, reaching their peak as Yuu neared ejaculation.

With her upper body raised, Mizuki shook her hips with loud *bachun, bachun, bachun* sounds, making her ample breasts sway *burun, burun*. Their joining area, Yuu's lower abdomen, and even his buttocks were soaked in their mingled fluids.

"A, a, aah! I-I'm cumming! M-Mizuki!"  
"Me too...cumming...cumming cumming cumming! Together...cum inside me...fill me uuuuuup!"  
"Vu! C-cumming! Guah!"

Yuu, who'd endured until now, finally released while tightly embracing Mizuki's body.

Throb, throb, throb!  
"Kyahi! O...hi...nuu...bwa...ahaa..."

The unusually strong, prolonged pulsations against her lower abdomen sent Mizuki into unparalleled ecstasy, pushing her over the edge instantly. Though she opened her mouth, no words came out - only intermittent sobs. Soon, overwhelming satisfaction enveloped her, and she buried her face in Yuu's neck.

After lying limp for a while, Mizuki wasn't unconscious - just basking in the afterglow. Proof being Yuu could feel *chu, chu* kisses against his sweaty chest.

His cock remained hard inside her. Smiling wryly at his own insatiable libido, Yuu tried to sit up while still holding her petite body.

"Hyaau!"

The sensation of his cock thrusting deep as he tensed his abs, combined with realizing he was trying to sit up, made Mizuki shriek. Ignoring her fluster, Yuu sat up while embracing her, shifting to a facing-sitting position.

"Aahn! Eh...? Y-Yuu-kun?"  
"Alright then. The princess isn't fully satisfied yet, is she?"  
"Ah..."  
"I was watching the whole time. Kuhuhu. So different from usual - Mizuki-chan's amazing at times like this. Total carnivore vibe?"  
"Fuwaa?!"

Finally noticing Emi beside her after being so engrossed, Mizuki's face turned beet red like an instant boiler.

"Eh, ah, uh...? I...did it again...I-I'm sorry! E-even though we just met!"  
"It's fine. I kinda expected it. Right, Emi?"  
"Yeah. We deliberately provoked you to show your true feelings."  
"Eh...?"

Mizuki tried to pull away, but still connected and held by Yuu, it was physically impossible. Reluctantly, she looked between Yuu and Emi, her face still red. When she turned to Yuu, he brought his right hand forward and lifted her chin.

"If you're joining the student council, I intend to accept all of you, Mizuki. So no need to hold back."  
"Ah...eh...Yuu...kun?"

Having joined bodies, Yuu now saw her beyond school years - simply as a woman. Mizuki listened to his words in a daze.

"Beyond the abilities Emi told me about...more than that, having met you today, would it be wrong to say I want to date such a cute girl? That I wanted to have sex with you?"

No woman could hear such sweet words up close afterward without being moved. Mizuki's resolve to live apart from men wavered.

"B-but I...seem to have ridiculously strong sexual urges. Even with my senpai...dating was fine at first, but being his third meant waiting my turn. My frustration built up until I went crazy, thinking I had to have him all to myself... So...I'll probably do terrible things to you, Yuu-kun."

Tears overflowed from Mizuki's eyes. The sex after so long felt incredibly good - reaching heights she hadn't experienced even during her sweet week monopolizing her senpai. But wanting this daily would undoubtedly burden Yuu. Knowing he was engaged to three student council members, she strongly wished to avoid conflict with them. As Mizuki lowered her eyes, she felt warmth on her lips and her breasts being firmly grabbed and kneaded.

"Nfue!?"  
"Um...about libido? I think mine's pretty strong too."  
"Eh, lie? But boys..."  
"Mizuki-chan, listen. Yuu-kun's bottomless."  
"Huh?"

Emi grabbed Mizuki's shoulders and leaned in.

"That was back in April - half a year ago now. I knew Yuu-kun was drawn to Sayaka-senpai. But I fell for him right after we met too~"

Emi smiled nostalgically at Yuu. He remembered too - returning from the student council room to the school building. Emi confessing her feelings. Though drawn to Sayaka, finding the Emi before him irresistibly cute, embracing her slender body.

"I struggled a bit back then. But we ended up dating all four of us, including Riko-senpai. I'm really grateful to Yuu-kun."  
"Emi. I'm the one grateful that you, Sayaka, and Riko were in the student council."  
"Yuu-kun..."

Yuu reached out, playing with the ends of Emi's twin tails. Then stroking her cheek, he kissed her as she closed her eyes. Emi, with her clear emotions and straightforward affection, had been adorable and likable from the start. In his previous life, dating even one beauty like Sayaka, Riko, or Emi would have satisfied him. But since being reborn in this world, Yuu's desires seemed endlessly growing.

"Emi...don't you ever want Yuu-kun all to yourself?"  
"Hmm...well...sometimes I wanna be lovey-dovey with Yuu-kun alone. But...since we often have sex with the senpais all three together, I don't really mind..."

Emi blushed bright red.

"Yuu-kun's bottomless. It's tough alone...three is just right..."  
"Really?"  
"Yes! I always get fucked senseless - my body can't take it!"  
"Ugh...sorry about that."  
"Un. It's fine. So...when Yuu-kun forms a new student council, we'll all have sex together, right? I want Mizuki-chan there too."  
"Eh, Emi..."

Mizuki felt ashamed of her past self-centeredness. Seeing her dear friend blush beside her beloved man felt dazzling - and that happiness brought fresh tears to Mizuki's cheeks. But these were tears of joy, unlike before.

"So that's why"  
"Ah!"

Yuu stroked Emi's head with his right hand while pulling Mizuki closer with his left arm.

"Will you join the student council with us starting next month?"

Feeling Yuu's body heat envelop her, Mizuki nodded.

"I-I may be inadequate...but p-please take care of me"  
"Un. I will. Now for round two - my pace this time?"  
"Kyaa!"

Still embracing her, Yuu pushed Mizuki down and began thrusting violently, as if releasing all he'd held back. In the end, Mizuki was fucked unconscious by Yuu.

---

### Author's Afterword

The story will develop into an intense threesome from here, but I'll leave that to your imagination and conclude for now.

Emi and Mizuki will appear again later (toward the end of Chapter 6) when the new student council members are decided.

### Chapter Translation Notes
- Translated explicit sexual terminology literally: "チンポ" → "cock", "おマンコ" → "pussy", "せーえき" → "semen"
- Preserved Japanese honorifics: "-kun" for Yuu, "-chan" for Mizuki
- Transliterated sound effects: "じゅぱじゅぱ" → "jupa jupa", "ばちゅん" → "bachun"
- Maintained original name order: "Ogawa Mizuki" not "Mizuki Ogawa"
- Italicized internal monologue: *(Feels like I'm literally being devoured here)*
- Formatted simultaneous dialogue with double quotes: ""Wufo...chu~lulu!"" 
- Translated "不束者" as "inadequate" reflecting self-deprecating context
- Rendered "第2ラウンド" as "round two" for natural flow
- Translated afterword's "濃厚な3P" as "intense threesome" per explicit terminology rule