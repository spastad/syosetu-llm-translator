## 222. The Legal Wife and the Mistress ① ~IT’S ONLY LOVE~

### Author's Preface

The characters are as per the subtitle.

Although they have been meeting regularly behind the scenes, this combination hasn't appeared in the story for a while.

---

Eventually, the number of applications for the student council election, now changed to a selection process, exceeded 250.

However, upon checking, 10 third-year students who were not originally eligible to run had slipped in by falsifying their grade level, so they were excluded.

In the end, we began the document screening for 246 candidates. We plan to narrow it down to about 1/10 of that. Then, we will conduct interviews of about five minutes per person.

Among the student council members besides Yuu, the secretary position is tentatively set for Emi and the accountant for Mizuki, so only two spots remain.

That said, just as Yuu joined without a position in April, it is possible to increase the number of members.

We will consider that while conducting the interviews.

For Yuu, he looks forward to seeing which female students will come, but at the same time, his busy days have begun.

---

September 16, Sunday.

In the morning, he had training and self-defense instruction with protection officers Kanako and Touko.

Perhaps due to the influence of the kidnapping incident, the two were quite enthusiastic in their instruction.

In return, after it was over, the three spent time showering together and indulging in intimate moments to their heart's content.

Then, in the afternoon, Yuu was driven by car to a hotel in Kawagoe City for a meeting.

---

"Yu, Yuu-kun... Yuu-kun... Ahh! Yuu...kun! Ha...un!"

"Kuuuuu... Sa, Sayaka! I'm about to..."

"It's okay... come... Yuu-kun!"

"T-together... okay, Sayaka"

Facing each other in a seated position, Yuu and Komatsu Sayaka were intertwined.

Though their words were few, the feelings were poured into the names they called each other.

Through their experiences so far, they had come to understand each other's states.

Feeling a slight expansion in the penis thrashing inside her vagina, Sayaka realized the moment of ejaculation was near and tightened her grip on Yuu's back.

Fortunately, she usually kept her nails short, so they wouldn't leave marks.

Sayaka herself seemed close to climax, moving in sync with Yuu.

Just then, the two brought their faces close and their lips met.

Simultaneously, their mouths opened, and their tongues intertwined.

As if they wanted to be deeply connected not only by their genitals but also by their mouths.

In time with their body movements, Sayaka's long ponytail swayed vigorously.

Her perky D-cup breasts also jiggled with a bounce.

Despite the air-conditioned room, the two entwined on the bed were heated and sweaty.

Sayaka's body seemed to have gained more curves since they met during summer vacation, but since she was originally well-toned and fit, it could be said that her feminine allure had increased instead.

Out of consideration for Sayaka's pregnancy, Yuu had been aiming for slow sex in a position that wouldn't put pressure on her belly. However, midway, an impatient Sayaka, unable to hold back, climbed on top and began to move her hips, and Yuu himself couldn't resist anymore.

"Ah, ah, kuuah! I'm at my limit! I'm coming! I'm... ejaculating!"

As Yuu gasped out, Sayaka, who until a moment ago had been distorting her well-defined face and looking ecstatic with rapidly changing expressions, looked at Yuu and smiled.

"Okay... Yuu...kun! Aah! Aah! Aahn! Ku...ru... hyaa! Amazing! I'm also... cumming! Ihyau! Ngaaaaaaaaaaaaaahhhhhhhhhh!!!"

Finally reaching her limit, she released a large amount of semen into Sayaka's womb.

Shaken by the pulsations of the ejaculation transmitted to her lower abdomen and the deep ecstasy, Sayaka continued to let out a long cry while looking up at the ceiling.

Among the three student council members, Sayaka had particularly severe morning sickness, so for about a month and a half, oral sex was more common.

However, after four months of pregnancy and entering the stable period, her morning sickness finally subsided, and passionate sex like before was permitted once again.

As for whether sex with a pregnant woman is possible, it is considered possible as long as there is no severe morning sickness, abdominal tightness or pain, or if she hasn't entered the final month of pregnancy.

That said, Yuu had heard of cases in the past where a woman's libido decreased due to pregnancy, and the husband, not being satisfied, would have an affair.

But so far, Sayaka, Riko, and Emi show no signs of decreased libido; they are as active as before... or rather, since Yuu has become busier and the days they can meet have decreased, they have become even more proactive whenever there is an opportunity to share a bed.

---

"Ah, Sayaka. That was... the best feeling."

"Yuu-kun, me too... *mwah*"

While still embracing, Yuu played with the end of her ponytail with his hand, and Sayaka stroked Yuu's head as they exchanged kisses repeatedly.

Even though she was already pregnant, Sayaka, having received his semen inside her womb, had a dreamy expression.

Yuu's cock remained hard after ejaculation, and even now, feeling Sayaka's body heat, his arousal hadn't diminished. He could have started a second round right away.

But for the person who had been shown this passionate coupling up close, it was unbearable.

"Ha, ha... I... too... nnaa... I also... want it soon..."

Sitting slumped beside Yuu, with her hand busily moving between her legs, was Mitsuse Rinne.

She was the student council president of Saiei Academy, the sister school of Sairei Academy which Yuu attended, and a direct descendant of the founding family of Nikko Group, one of Japan's leading corporate conglomerates.

Her family seemed to advocate female superiority, and at their first meeting, she had shown an extremely haughty young lady attitude.

But she took a liking to Yuu at first sight, and when he was invited to Saiei Academy, there was an incident in the student council basement. After that, they reunited at a hotel, and after twists and turns, she was sexually conquered by Yuu and entered into a mistress contract.

Since their families were rivals in the automobile industry, Rinne and Sayaka had a relationship that sparked fire when they met.

Yuu had managed to mediate and keep things peaceful, but they hadn't built complete trust.

Moreover, regardless of Rinne herself, there was unease about how her family would react upon learning of her relationship with Yuu.

Thus, when meeting Rinne, Yuu would specify the location and have Sayaka join as well.

Noticing that Yuu had turned toward Rinne, Rinne opened her mouth slightly and looked at him with a desirous expression.

Even so, she didn't reach out on her own, which showed that the training so far had taken effect.

He felt pleasure in seeing her, who once thought nothing of men and was haughty, become like a submissive female in front of him.

Sayaka, who had made eye contact with Yuu, gave a wry smile and kissed him one last time before lifting her hips.

With a sticky *nupuu* sound, the cock slowly pulled out of Sayaka's vagina.

Even after it was completely out, a white, cloudy string stretched between them, as if reluctant to part from a well-matched partner.

As Sayaka moved away, Rinne, her cheeks flushed pink with anticipation, timidly drew closer.

Yuu took Rinne's wrist and pulled her in forcefully.

"Kyaah!"

Rinne let out a surprised cry as Yuu scooped her up, but she happily leaned her body against him.

Perhaps she had changed it since they first met, a slightly subdued floral perfume tickled Yuu's nostrils.

At the same time, breasts as voluminous as Sayaka's pressed against his chest, flattening into an oval shape.

Yuu knew that Rinne enjoyed it when he was a little rough with her.

Her long, fluffy copper-beige hair, which she usually wore down, was tied up at the nape of her neck since she was naked.

Yuu placed his hand on her slender nape and the back of her head, looking at her closely.

He had been sleeping with Rinne about twice a month since making the mistress contract in August. Whether she still wasn't used to Yuu's pace, or she was simply happy to be treated as a woman, or both, Rinne looked up at Yuu with upturned eyes.

"Yu, Yuu-sa—"

He sealed her lips as the words escaped from her mouth, painted with deep pink rouge.

With a wet, pressing kiss, Rinne's expression gradually melted.

"*Mwah*, *chu*, *chupa*... fo! *Unmu*... *nrero*, *rero*, *eaa*... *unku*, *upaa*... *afu*... *chupuu*"

After exchanging kisses several times while changing the angle of their faces, Yuu forcibly inserted his tongue and ravaged Rinne's mouth.

Rinne, who had wrapped her arms around Yuu's back and clung tightly, also entwined her tongue in response.

For Rinne, kissing Yuu was the ultimate sweetness.

When she used to do it to younger boys in the past, they were mostly frozen stiff, and it was merely an act of pressing lips.

But kissing Yuu, where they ravaged each other's mouths, brought a pleasure on a completely different level.

After about five minutes of kissing, they parted lips, and a string of drool stretched from the tip of their tongues.

With a small smile at Rinne, who still wore a desirous expression, Yuu chased the drool string and kissed her again. At the same time, he grabbed one of her breasts with his hand and squeezed it.

"*Nmu*... *n*, *n*, *nku*... *fa*... *an*! Yu, Yuu-sha... a, *n*... *nfuun*"  
"Now then, shall I have Rinne suck my cock?"

"Fa, fai... I'll have it, waah"

Though Rinne already had a thoroughly melted expression, at Yuu's words, she happily bent her upper body and looked at his crotch.

Without caring about the drool still dripping from her mouth, she reached out her right hand toward the magnificent, erect form that stood proudly even after ejaculation.

Yuu placed his hand on Rinne's shoulder and said.

"Wait. Since we're at it, why don't we try that with Rinne?"

What was "that"?

As Rinne lifted her face with a puzzled look, Yuu raised the corner of his mouth with a mischievous glint in his eyes.

For some reason, Yuu, though younger, was more knowledgeable about sexual matters than Rinne.

Surely it must be something very pleasurable, Rinne thought, her heart swirling with anticipation.

---

"Haaan... what a magnificent cock... so hard and hot... whenever I see it, I'm captivated by its manliness.

*Nfu*♪ *Aaahm*, *lero lero chu*, *lero chu*, *chupaa*... *hafu*, delicious... oh? Faaaaah!? A, a, aahn! Yu, Yuu-sama!?"

"Fufu, your pussy is flooding, isn't it? With just a little playing, so much is overflowing."

"Hyaa! S, such... playing... a, haaaan! B, being licked with... a, a, a, your tongue... I can't concentrate on the cock! Aahn... no... not allowed... ahi! Th, that spot... is sensitive, you know..."

Rinne was on top, facing the opposite direction to Yuu who was lying on his back.

In other words, it was sixty-nine.

Rinne, with ecstatic eyes, gazed at the cock that remained heroically erect despite being coated with semen and Sayaka's love fluids, and began sucking it eagerly.

But when Yuu spread her labia *kupaa* and began licking, having found her pussy dripping wet and soaked, Rinne involuntarily lifted her chin.

It was worlds apart from when Rinne had made boys lick her—or rather, forced them to—in the past.

Back then, she thought it wasn't bad even if they did it half-heartedly while inwardly hating it, but Yuu was completely different.

After just a few encounters, Yuu had learned Rinne's weak spots and mercilessly attacked them, so she was instantly overwhelmed.

Why was he so skilled at making women drunk with pleasure? Rinne had no idea.

In fact, even though she tried to suck his cock, she was so intoxicated by the pleasure that she could only gasp. Her right hand was barely moving mechanically, stroking it.

But one thing was certain: sex with Yuu brought a supreme feeling she had never experienced with anyone else. That alone was enough.

"Ho there? What about here? Does it feel good?"

"Ha, ha, haiiiiin! Yes... yes! *An*! Your tongue... going in... I'm, *nchu*, *rero rero*... *n amu*... *n*, *n*, *nfu*... *juru*, *npaa*... *hamu*... *n*... hyain! Cl, clitoris! No... aun! I, I, I'm cumming! Ngaaaaaaaaaaaaaahhhhhhhhhh!"

Less than five minutes after starting sixty-nine, Rinne reached climax.

After arching her back sharply and letting out a long cry of ecstasy, Rinne, now collapsed, rubbed her cheek against the cock and began licking it all over with her tongue, determined not to fail this time.

Yuu had been gently caressing her to the extent that Rinne could endure for a while, letting her do as she pleased, but as she sucked, he began to feel a bubbling sensation.

So, while stroking her well-shaped buttocks, he spoke to Rinne.

"Which would you prefer: continue sucking until I ejaculate like this, or have me insert it into your pussy?"

"Haah!"

Rinne had been diligently licking from the glans to the frenulum while stroking with her right hand, but at Yuu's words, she involuntarily pulled her tongue away.

Then, she gave Yuu a truly seductive sidelong glance. At the same time, she wriggled her body as if shaking her hips.

Seeing that expression, Yuu didn't need to hear the answer. He smiled wryly and began to sit up.

### Chapter Translation Notes
- Translated "正妻" as "Legal Wife" and "愛人" as "Mistress" to reflect hierarchical relationship dynamics
- Preserved Japanese honorifics (-kun, -sama) and name order (Komatsu Sayaka, Mitsuse Rinne)
- Translated explicit sexual terminology directly (e.g., "チンポ" → "cock", "マンコ" → "pussy")
- Rendered sound effects phonetically (e.g., "ぬぷぅ" → "nupuu", "くぱぁ" → "kupaa")
- Maintained internal monologues in italics per style guide
- Translated "シックスナイン" as "sixty-nine" for sexual position
- Kept corporate/organization names consistent with Fixed Terms (Nikko Group, Saiei Academy)
- Used "morning sickness" for "悪阻" with contextual explanation
- Preserved subtitle "IT’S ONLY LOVE" as original English phrase