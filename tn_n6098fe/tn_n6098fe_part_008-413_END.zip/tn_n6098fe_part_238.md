## 223. The Legal Wife and the Mistress ② ~Just the Way You Are, I Love You~

"Agh... Aaaaaaahhhh—ha! Hahyu... Cock, cock is... coming... Ogh, ogh... Nnngh~ngh!"

After Rinne came from a single deep thrust in the doggy style, Yuu deliberately repeated slow thrusts.

That is, he slowly pulled out until the glans was just about to slip out, then thoroughly savored the wonderful tightness of the vaginal walls as he pushed back in deep.

For Rinne, it seemed to maintain a high level of pleasure almost unchanged from when she climaxed.

When pulled, she was tugged by the coronal ridge, and when penetrated, her vaginal walls were spread open by the thick glans.

Throughout the repetition, she continued to let out voiceless moans.

Not just moans, but love juice overflowed and trickled down her thighs the entire time the cock was thrusting in and out.

Yuu was doing this partly because he wanted to admire Rinne's figure from behind.

Rinne was originally slender, but after entering high school, her chest and butt grew larger while her slimness remained, and by her second year, she seemed to have developed a fully mature figure.

Rinne's figure from behind was just as splendid as Sayaka's, and Yuu thrust his hips while caressing with his fingertips from her delicate nape down to her artistically curved back and buttocks.

Occasionally, he would reach his left hand forward to roughly grab her heavy breasts, kneading them while flicking her nipples with his fingers, causing Rinne to shake her head as if refusing while letting out seductive moans.

Sometimes, instead of pistoning, he would grind his hips in a circular motion, making her throw her head back and let out intermittent moans.

Just seeing the high-and-mighty young lady Rinne being toyed with by his every move stirred Yuu's masculine emotions and excited him intensely.

"Hya... An... Yu, Yuu... Hyama... A... A... A... M-more..."

Rinne, who had been tightly gripping the sheets with both hands, turned to look back at Yuu.

Her hair, neatly tied up before getting into bed, was now completely disheveled and hanging over her cheeks, which conversely exuded sexiness.

Unaware of the drool dripping from the corner of her mouth, the expression in her sidelong glance was that of a woman completely in heat.

Having been kept on the edge of coming without being allowed to for a while, she seemed to be pleading on her own.

"More? What do you want?"

"S-stronger..."

"Stronger? What?"

"Y-your cock... With Yuu-sama's cock..."

"Cock?"

"M-my... pussy... Deep inside... Th-thrust, thrust, thrust, thrust... Like knocking on the baby's room... I want you to thrust...!"

"You want me to pound you hard?"

"Aahn! Yes!"

Just as Yuu was about to start moving seriously, he felt something soft touch his back as he firmly grabbed Rinne's buttocks with both hands.

"Yuu-kun, I want to join in too."

"Ah, of course, OK."

"Fufu."

"Wah!"

Not only did Sayaka hug him from behind, but she also sucked on his nape while simultaneously beginning to toy with his nipples with both hands.

Having more opportunities to be physically close meant that while Yuu learned Sayaka and the others' weak points, they also learned his weaknesses more often.

Moreover, as ladies of Sairei Academy, they were proactive in devotedly serving Yuu.

"Chu, chu, chuuuuuuuu... Haanmu, n~rero, reroo... Chupa! Ah, Yuu-kun... Yuu-kun... Yuu-kun... Afuu"  
"Fa... Ah, ah, Sa, Sayaka. Like that... Au!"  
"Ufufu. Yuu-kun when he's feeling it is always so cute."

Whether it was Sayaka or Riko, normally they were tormented by Yuu, so when they counterattacked, they were so persistent in targeting his weak spots that it seemed like they had a sadistic streak.

At such times, Yuu couldn't help but let out high-pitched moans.

Before being reborn, Yuu never imagined that being caressed by a girl anywhere other than his cock could feel this good.

"I really like Yuu-kun so much I could eat him up."  
"Hau!"  
"Ahhyin!"

Sayaka gently bit his ear, sending an electric shock through Yuu's body.

It caused a reaction in his lower body, making him thrust his hips forward hard.

The deepest part of Rinne's vagina was forcefully gouged, sparks scattered in her mind, her vision blurred, and her body was enveloped in a floating sensation.

"Heh... Agh, i, I'm cummiiiiing... n..."

Rinne's arms lost strength, bending at the elbows as she collapsed face down on the sheets.

Yuu firmly grabbed the indented part between Rinne's waist and buttocks, which were sticking up, and began thrusting his hips.

"Ah, ah, ah, ugh... Sa... Sayafa..."  
"Nn, chup... Yuu-ku... Ah—"

Sayaka, who had licked even inside Yuu's ear canal with her tongue, turned to kiss him deeply, tangling her tongue with his.

Sayaka's fingertips roamed not only over his chest but also his armpits and lower abdomen, caressing Yuu's sensitive spots.

While savoring Rinne's vaginal walls with his lower body and being caressed by Sayaka while enjoying a deep kiss with his upper body, Yuu felt like his head was about to boil over from the pleasure experienced throughout his entire body, but his hips continued thrusting on instinct.

Pan! Pan! Pan!  
Juppo! Juppo! Juppo!

Along with the rhythmic sound of flesh slapping, a sticky wet sound played from the joining area.

It was thrusting solely for ejaculation, with no regard for pacing or reserve.

Rinne, directly affected by this, buried her face in the sheets, drooling as she moaned, but her voice was becoming intermittent as she neared her limit.

"Agh... Hye... Ha, fu... Aghun! No more, no more... This, beyond... Ogh, ogh, ogh, I'm... cumming... Cock, amazing... Agh! Agh! Aagh!"  
"Puhah! I-I'm... cumming... too... Guh!"  
"Hyai... Yu... u... Hyama... Aghun! Cum... inside... Lots, cum inside... Ah, afuun!"

Naturally, the pace of Yuu's hip thrusts accelerated.

Just when it seemed to ring out like a machine gun—panpanpanpan!—he trembled violently with a "dokun!" and reached his limit.

"C-cumming! Ugh!"  
"Fuaa! Aghaa! Kkuuunaghaaaaaaaaahhhhhhhhh—!!! Agh, i, nnaa! Ah... Haaaaaaaaaahhhhhhh..."

While ejaculating not just once but multiple times in succession, Rinne continued letting out the most seductive moans of the day, and as they ceased, she collapsed face down.

After emptying everything, Yuu pulled out his cock, turned around, and hugged Sayaka, burying his face in her ample twin peaks.

The breasts pressed against his back were sweaty, but he didn't mind at all. Rather, Yuu even found Sayaka's sweat smell pleasant.

"Yuu-kun, good work. After resting a bit... Hyan!"  
"Sayaka's boobs feel a bit bigger."  
"I-is that so?"  
"Let me check thoroughly."  
"Na... Just now... Ann!"

Yuu wrapped his left arm around Sayaka's back, kneading one breast with his right hand while sucking on the other.

He slowly pushed her down.

Rubbing his cock, which had just ejaculated, against Sayaka's thigh felt so good that instead of calming down, it became unstoppable.

"Nn... Nna! Yu, Yuu-kun really... loves boobs... huh... Haun!"  
"Nn—mu! Well, once the baby is born, they'll be taken for a while, right? So I have to savor them plenty now... chup rero"

Yuu rolled her nipple with his tongue or pinched it with two fingers while kneading.

Receiving persistent caresses on her rock-hard nipples, Sayaka moaned and replied.

"Hyah! E-even after birth, you can... suck the boobs... as much as... ah, an... Yuu-kun... wants..."  
"Ah, really? I'd love to drink breast milk too. Like this."  
"Aah! Yu... kun!"

Realistic breastfeeding play, pretending to be a baby.

Before being reborn, the other party might have disliked it, but at least Sayaka didn't seem to mind.

What about Riko or Emi?

He remembered hearing that breast milk was bland and not particularly tasty, but if they didn't refuse, he wanted to try comparing them. That's what Yuu thought.

What started as payback for earlier escalated so much that Sayaka came and kept going until she wanted Yuu's cock.

The hotel they used that day was the same Princess Hotel where he had dined with Riko and Aiko before, one of the higher-grade hotels in Kawagoe City.

Rinne seemed to have wanted to use the highest-class room among the Nikko Group hotels for her rendezvous with Yuu, but Yuu had set it as a condition for the mistress contract, so she reluctantly complied.

The room, called a Deluxe Double, felt sufficiently luxurious to Yuu.

In fact, even the bathroom was spacious enough for three to enter comfortably.

Perhaps it was designed from the start for a man to be with multiple women.

The usual flow was that while Sayaka and Rinne washed each other with Yuu sandwiched between them, it would shift from double handjobs to double paizuri until he ejaculated.

A collaborative effort by Sayaka and Rinne, pressing their breasts together from left and right with Yuu's cock in between.

When licking up the semen, their tongues would even touch each other.

Unthinkable before July, but at least in front of Yuu, the lingering resentment they once held seemed to have vanished.

After thoroughly rinsing their bodies under the shower, the three soaked side by side in an oval bathtub.

Of course, with Yuu in the middle, Rinne on the left and Sayaka on the right.

Although larger than a typical household bathtub, it wasn't wide enough to stretch out their legs, so they bent their knees slightly with their feet touching the bottom.

Soaking slowly in the lukewarm water, Yuu held both of them in his arms.

Sayaka and Rinne both rested their heads on Yuu's shoulders, pressing their bodies tightly against him.

Both were in their natural state, and their expressions showed how happy they were to spend time with their beloved Yuu.

"Haa~n... I feel so happy right now."

With her eyes closed and cheek rubbing against him, Rinne murmured with a completely relaxed expression.

Although she usually wore full makeup, the intense lovemaking had drenched her in sweat, so she had washed it off, leaving her bare-faced now.

Her natural features were well-defined, so Yuu thought she was perfectly beautiful without makeup.

However, she seemed unexpectedly innocent, or rather, younger-looking than Sayaka.

Perhaps her mature makeup was to hide her baby face.

"Yes. In front of Yuu-kun, I can forget about family matters, student council matters, everything and just be a woman."

As Sayaka said this while tracing her fingers over Yuu's chest, Rinne nodded as if she completely agreed.

"Until now, I've never entrusted my body and soul to anyone... Ah, really. I never thought I'd become so clingy!"

As if embarrassed by her own words, Rinne averted her eyes and kissed Yuu's shoulder.

Yuu extended his left arm, which had been holding her side, and stroked from Rinne's waist to her buttocks.

"Nngh!?"

"Rinne, aren't you too tense at school and home?

So at times like this, it's okay to relax and be spoiled by me."  
"Ah... nngh! N-no... I-I'll... become strange again... Fah!"

As the heiress expected to lead one of Japan's representative conglomerates.

As the student council president of Saiei Academy, which has a strong arts focus and attracts colorful students.

Rinne's choice to apply heavy makeup and act like a haughty young lady was likely due to her birth and upbringing.

But continuing such a life would inevitably lead to some distortion.

One of which might have been her preference for younger boys.

Although their first meeting wasn't favorable, Rinne was objectively a woman who stirred men's hearts.

It was also true that Yuu wanted to ravage her mercilessly.

With his inner self being a man with rich life experience, Yuu saw the mistress relationship as a good opportunity to make her rethink her attitude toward men.

"I keep thinking how mysterious Yuu-kun is. But... I'm hopelessly drawn to such Yuu-kun."

While Yuu's left hand was roaming over Rinne's body, Sayaka on the right brought her mouth close and whispered.

Then, as if not to be outdone, Rinne, with flushed cheeks, raised her face and said.

"I-I too... th-that... YuYuYu, Yuu-sama... I-I adore you! Hah!"

As if embarrassed by her own words, Rinne looked down again.

"Hoh. I'm happy. Somehow, unlike when we first met, Rinne has become cuter lately. I like that cute Rinne."  
"Egh... C-cute... l-like!?"

Steam seemed to rise from her head as her face turned bright red, and Rinne lowered her mouth until it submerged in the water, making bubbling sounds.

"Fufu, I might get a little jealous. After all... I'm so smitten with Yuu-kun that I couldn't live without him."

When Yuu looked at Sayaka, she was staring back with moist eyes.

So Yuu also brought his mouth close and whispered softly.

"Don't worry, Sayaka. No matter how many women there are in this world, my favorite type is Sayaka. That's why I fell in love at first sight."  
"Yu... nmu!?"

Without waiting for a verbal response, he sealed her lips.

Sayaka, with her eyes glazed over, pressed her body even closer, immediately developing into a deep kiss with tongues entwined.

"Aahn! I want to kiss Yuu-sama too!  
Uu... Then, this side of Yuu-sama."  
"Nmugh!"

With Yuu sandwiched between two women with splendid figures, and the deep kiss with Sayaka being the final trigger, his cock was already in battle mode. Rinne noticed this and began stroking it with her hand.

"Chupaa... I'll help too."  
"Nkuh!"

At times like this, the perfectly in-sync Sayaka and Rinne not only gave a double handjob together but also ran their tongues over Yuu's shoulders and chest.

"Ah, kuu... W-wait!"  
"Won't wait. I want to repay you more for making me feel so good today."  
"What a coincidence. I share the same opinion as Sayaka-san. I wonder if this feels good for the cock?"  
"Oof!"

While Sayaka's hand stroked from the base, Rinne used her palm to rub the glans.

Then they both began sucking his nipples simultaneously.

Admittedly, it wasn't enough to make him cum immediately, but being double-teamed did gradually increase the pleasure.

"Ah, hey. How about continuing on the bed?"  
"No, I want to repay Yuu-kun right here."  
"Me too."

Only at times like this did the two agree.

"Oh. I have a good idea. Lend me your ear."  
"What is it?"

Sayaka whispered something to Rinne, who looked slightly surprised before smiling.

A mischievous, childlike smile she would never have shown before.

"On three."  
"Wah!"

Yuu's legs were lifted by the two and placed on the edge of the bathtub.

Their other hands supported Yuu's shoulders to prevent his face from sinking into the water.

With only his buttocks floating, his cock emerged from the water like a periscope.

"Now then..."  
"Yes."  
"Bon appétit!"  
"Hau!"

Through loving double fellatio by Sayaka and Rinne, Yuu reached his fifth ejaculation of the day five minutes later.

---

### Author's Afterword

When I was plotting the sixth chapter, I hadn't planned this, but somehow I felt like writing a continuation of "165. The Young Lady Falls."

When I first introduced Rinne, I had decided she would be sexually corrupted by Yuu later, but I never imagined I'd write such a story.

### Chapter Translation Notes
- Translated explicit anatomical terms directly: "おチンポ" as "cock", "おマンコ" as "pussy", "赤ちゃんのお部屋" as "baby's room" (referring to cervix).
- Preserved Japanese honorifics: "祐様" as "Yuu-sama", "清華さん" as "Sayaka-san".
- Transliterated sound effects: "ぱんっ" → "Pan!", "じゅっぽ" → "Juppo", "どくん" → "dokun".
- Maintained original name order: Japanese names remain Last Name First Name when full names appear, but used given names ("清華"→"Sayaka", "凛音"→"Rinne") as in source text.
- Translated culturally specific term "母乳プレイ" as "breastfeeding play" with contextual explanation.
- Rendered sexual acts without euphemisms: "ダブルフェラ" → "double fellatio", "乳首を弄る" → "toy with nipples".
- Used gender-neutral "they/them" for ambiguous plural references to multiple women.