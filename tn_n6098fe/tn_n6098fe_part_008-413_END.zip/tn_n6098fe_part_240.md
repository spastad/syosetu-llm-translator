## 225. Secret Meeting ② ~From Now On~

"Now that introductions are done, shall we begin eating?"  
"That would be good."  
"Yes."  
"Um... Hiro... May I call you Yuu-kun since we're at this point?"  
"Of course, that's fine."

Though they were meeting for the first time and these weren't people he'd encounter often, Yuu felt an odd sense of familiarity due to their connection with his father.

"Yuu-kun, would you like some alcohol...?"  
"No, not yet."  
"I see... You're still a minor. Somehow I didn't get that impression."  
"How strange. I also had the impression he was long past adulthood."

Yuuko and Junko exchanged slightly puzzled looks. Only Haruka, who knew the reason, smiled as she passed Yuu a bottle of cola. Apparently she hadn't revealed his reincarnation.

"Ah! Let me pour for you!"

Yuu hastily rose to his feet. Tazuru seemed to be drinking chilled sake. The others watched in astonishment as Yuu first picked up the sake flask.

"Here, please."  
"Uh... alright."

As Tazuru held her cup at Yuu's prompting, he poured chilled sake to about 80% full. Serving the highest-ranking person first - a habit ingrained from his salaryman days. Judging by age and conversation flow, Yuuko came next. Since she had a medium-sized beer bottle with Ebisu from the Seven Lucky Gods depicted, he poured into her glass cup. She looked extremely pleased.

Junko also had beer, but her hand trembled as she held the cup. Though unsure about the etiquette, Yuu steadened her hand with one of his while pouring with the other. Junko seemed to calm down, but then started stammering with ears reddening as she watched the liquid being poured. Her demeanor seemed far from that of a ministry director, which Yuu found endearing.

"At my age, to have a young man pour drinks for me..."  
"If this were ever known, we'd be the ones facing criticism next time."

Yuu listened to their conversation while pouring beer into Haruka's cup.

"You look puzzled."  
"Well, yes."  
"Normally, it's unthinkable for a man to pour drinks."  
"Huh? Don't they do that at certain establishments?"  
"Establishments?"  
"Bars or clubs?"

Since Tokyo place names seemed mostly unchanged, Yuu thought high-end clubs might exist in Ginza. Though in this world, hosts rather than hostesses would entertain. But according to Haruka's wry smile, most hospitality at drinking gatherings was handled by women in male attire. While some men worked at bars or clubs, they were mostly middle-aged men who'd grown accustomed to luxury, spent excessively, and fallen on hard times. Young men had no need to work since they never lacked women to support them.

"Now that drinks are served, Madam Secretary-General, would you lead the toast?"  
"Very well. Then, to tonight's meeting with Yuu-kun... Cheers!"  
""""Cheers!""""

Yuu, whose throat had dried from nervousness before the conversation, downed the cola Haruka poured in one gulp. Yuuko and Junko immediately refilled it, and as he gulped it down, his stomach growled.

"Go ahead, eat without reservation."  
"Order as much as you want if it's not enough."  
"Then I'll dig in."

He'd pretended not to notice, but the table was covered with lavish dishes worthy of a high-end restaurant. Likely all prepared in advance to avoid interrupting the conversation. At the center sat an imposing boat platter of sashimi, plus a whole sea bream with head, large tempura shrimp, turban shells and whelks baked whole, and neatly cut king crab - all vibrant dishes that whetted Yuu's appetite. The seafood focus suggested direct delivery from the market.

"Mm... delicious!"

The melt-in-your-mouth fatty tuna belly. The rich slices of yellowtail and salmon. The shrimp tempura with crispy batter and thick meat created perfect harmony. The thick crab legs slipped easily from their shells, seasoned enough to eat plain and so delicious they'd make your cheeks fall off.

"Ah, sorry. I got carried away."  
"Don't worry about it."  
"Watching Yuu-kun eat so heartily is pleasing in itself."  
"Indeed."

All four watched Yuu devouring food with chopsticks while smiling. Yuu was aware his teenage body had a ravenous appetite due to metabolism. He could eat heartily without indigestion - a welcome change. Compared to six months ago, any excess fat had turned to muscle. With increased sexual activity, he needed proper nutrition to maintain stamina. His tension eased, so he kept eating freely.

"By the way, Yuu-kun."

After enjoying the food until comfortably full, Tazuru suddenly spoke while pouring her third flask herself. Yuu straightened, guessing they'd finally reach the main topic.

"Do you know this world's total population?"  
"Let's see... about 3 billion, I think?"

Yuu had researched this world's history at the library after his April hospital discharge. The drastic male population decline from Red Death Disease had long-lasting effects, and he remembered being surprised global population growth was slower than expected. Compared to his previous world's 7 billion, this was less than half.

In this world too, population grew after the 19th century due to industrialization and medical advances. But compared to Yuu's world, developed nations like Japan had only 50-60% of the population. Globally, the 20th century population explosion never occurred, and some regions like China decreased due to civil wars. Ironically, environmental pollution wasn't a major issue here since population hadn't exploded.

"Right... roughly correct. What do you think?"  
"Well... few—no, maybe it's fine? Overpopulation causes problems too."  
"Some call 3 billion too many, others too few. But the problem isn't the number... right?"  
"Yes, let me explain."

Junko took over after Tazuru. She adjusted her glasses with a click. As head of the Population Agency - unfamiliar to Yuu - she now exuded capable woman energy, a stark contrast to her earlier innocent maiden demeanor. This was likely her usual self.

"The problem facing us as we approach the 21st century: maintaining current levels is becoming difficult, and population decline is projected."  
"Decline... it will decrease?"  
"Yes. Since the late 20th century, the widening gender gap has reduced global birth rates. Experts consider declining male sperm counts one contributing factor."

Yuu knew from semen test results that he received exceptional treatment, possibly due to these issues.

"In developing nations, depopulation and industrial decline have been critical issues for a quarter century. While hard to notice in peaceful developed countries like Japan, the coming decades seem unlikely to bring a bright future."

Yuu found this convincing. In his 21st century Japan, aging populations and low birth rates were particularly severe. Young generations remained single or childless despite government measures like child allowances and free education/healthcare. Raising children was expensive, societal understanding didn't improve, and elderly-prioritizing systems persisted.

Moreover, in this male-scarce world, low birth rates were accelerating - something he'd heard from Inui Rumiko, a Ministry of Health official. Hence their early 20th century efforts like the 1980 "Male Protection New Law and Related Laws for Countering Low Birthrate."

"Even 30 years ago, Japan debated preparing for population decline."  
"Yes, I knew discussions existed since my student days..."  
"Concrete proposals stalled at discussion due to opposition parties resisting increased public burden."  
"Politicians, bureaucrats, and most citizens always prioritize immediate gains over decades-later futures."

Yuuko and Junko nodded in agreement with Tazuru's sigh.

"Your father changed that flow."  
"Father did?"  
"Indeed."

Sakuya, who'd built solid connections in his twenties, advocated social reform including gender relations to address the stagnant population issue. He passionately argued - sometimes physically - that social distortions from gender imbalance and inevitable industrial decline from aging populations required immediate preparation. His followers included young politicians, bureaucrats, and businesswomen like Setsuko (Tazuru's daughter), Yuuko, and Junko. While receiving his affection (and sometimes sperm) helped, these ambitious young women were moved by his passion. Their achievements included enacting the "Male Protection New Law and Related Laws for Countering Low Birthrate." The law's male protection focus likely reflected the young legislators' love for Sakuya. Relatedly, co-ed schools were actively established nationwide.

Sakuya became the movement's figurehead despite being male, establishing a foundation and energetically campaigning - meeting foreign dignitaries and speaking before women's groups. This brought visible support but also opposition and sabotage attempts.

"I still remember my shock hearing opposition lawmakers stormed Sakuya-kun's office."  
"By next day, they'd completely become Sakuya-san's sympathizers."

Yuu could imagine what happened that night based on his own experiences.

"Social reform takes time. Especially in democracies."  
"Indeed. Population issues show results years or decades later."  
"But Sakuya-kun insisted we must act seriously now."  
"Yet he passed with his work unfinished..."

The cozy atmosphere turned wistful. Yuu understood Sakuya's significance to them.

Haruka broke the silence after time passed.

"As you've gathered from our talk, these three knew Sakuya-san intimately and know all about you, Yuu. For example, about Hesperis in Hakone, and last month's kidnapping incident."

Normally one would be shocked that national leaders knew such personal details, but Yuu somehow accepted it - perhaps numbed by his father's legendary tales. His existence occupied an unexpectedly special position in this world, making an ordinary life impossible.

"Ah, don't worry. We're not saying you must do anything. Not yet."  
"Even temporarily, we shared intimacy with Sakuya-san. We can't help but care about his children, especially sons."

Yuuko and Junko exchanged looks with Haruka, suggesting an understanding beyond wives and mistresses.

"Particularly... we have many concerns about Yuu-kun."  
"That is..."

Even without revealing his reincarnation, his actions would clearly seem extraordinary for this world's men.

"Some say it's premature, but... we want Yuu-kun to eventually take over Sakuya-kun's work."  
"......"

Stared at by Tazuru, Yuu couldn't hide his bewilderment. He recalled Tsutsui Takako saying similar things in Hesperis' director's office. This world's Yuu was just a 16-year-old high schooler. Why such expectations? Probably his reincarnation made him fundamentally different.

"Well, I understand your hesitation. Current Yuu is just a first-year."  
"Indeed."  
"But next month you'll essentially become student council president."

Yuu was surprised they knew, though it wasn't secret information.

"Also, even a month after the kidnapping, media still sniff around the victim boy. We can't risk them discovering Yuu-kun."  
"So... Yuu-kun, would you consider giving an interview?"

Junko, stared at directly, blushed slightly as she spoke.

"The first male student council president in history! This will absolutely make headlines. Nobody would imagine the kidnapping victim and aspiring student council president are the same person!"

Junko spoke with clenched fists. But Yuu voiced a sudden doubt.

"Wait - aren't there boys' schools? What about their student councils?"  
"Huh?"

Not just Junko, but Yuuko looked puzzled. Haruka explained.

"Yuu, boys' schools don't have student councils."  
"None?"  
"Boys' schools have only about one class per grade, and the boys don't participate in extracurriculars. Some study diligently, but most just want their high school diploma. Active boys wanting to enjoy school life or interact with girls go to co-ed schools."  
"Exactly. So until now, high school councils were only in co-ed or girls' schools. Even in co-ed schools, boys might join councils, but voluntarily running for president? Yuu's the first such eccentric."

This was news to Yuu, who'd ignored boys' schools. Then Junko's idea made sense. Yuu becoming president was truly noteworthy.

Creating a major news story could divert attention from one incident. It seemed a good idea - except for putting himself at the center. Seeing Yuuko and Junko's sparkling, expectant eyes, Yuu sighed internally, knowing refusal wasn't an option.

---

### Author's Afterword

Though dialogue-heavy, these last two chapters were challenging to write. While no dramatic changes occur immediately, Yuu can no longer hope for an ordinary life. I wonder how far I should develop this as the author.

As mentioned, the skewed gender ratio limits global population to 3 billion. Historically, this number was reached in 1961. Developed nations have 50-60% of historical populations; Japan avoided war and peaked at 79 million (historically reached in late 1940s). With clearly lower populations, differences emerge in details, but exploring them risks plot holes, so I try following history.

2020/7/26  
Added dialogue continuation about "first male student council president" based on reader feedback. Though retroactive, I believe it fits the worldview naturally.

### Chapter Translation Notes
- Translated "お酌" as "pouring drinks" to convey the ceremonial serving of alcohol
- Preserved Japanese honorifics (-kun, -san) and name order per style guide
- Translated "あわあわ" as "stammering" to capture flustered speech
- Rendered internal monologues in italics (e.g., *refusal wasn't an option*)
- Maintained explicit terminology for sexual references ("sperm," "intimacy")
- Translated bureaucratic titles formally ("Population Agency head")
- Kept specialized terms like "Red Death Disease" and "Male Protection New Law" consistent with Fixed Reference