## 228. New Student Council ③ ~Heart Pounding~

### Author's Preface

As introduced in 226. New Student Council ①, let's review the new officers once more.

・Vice Presidents  
Kawai Kiriko (2nd year): Former hard tennis club member. Touched by Yuu over her bloomers during quiz championship committee work. Masturbated while peeping at Yuu and Emi having sex on the rooftop.  
Hanmura Sayori (1st year): Former student council vice president and Riko's cousin.  

・Accountant  
Ogawa Mizuki (2nd year): Former student council accountant. Fell for a senior boy but ended up confining him at home (collapsed after one week → 3-month suspension). Returned to student council after persuasion (3P with Yuu and Emi) two weeks prior.  

・Secretary  
Ishikawa Emi (2nd year): Yuu's third fiancée, currently 4 months pregnant.  

・Assistants  
Aramaki Yoshie (1st year): Class 1-5 committee member. Had sex with Yuu twice when timing aligned, aside from Yoko and Kazumi in same class.  
Tsutsui Nana (1st year): Daughter of Tsutsui Takako and Yuu's half-sister (one month age difference). Experienced kissing and fellatio with Class 1-5 classmates on transfer day. Stopped acting and shows true self before Yuu.  

---

"Hey, where is everyone going?"  
"Just the new student council members for the after-party."  
"Eh... I was thinking of heading home already."  
"Come on, it's fine."  
"Since we're here, let's go together?"  

Sayori seemed about to leave since Sayaka and Riko had departed, but Yoshie and Nana seized both her arms and forcibly led her away. At the front, Yuu walked flanked by Emi and Mizuki, with Kiriko joining them—all four chatting happily. They'd prearranged with Yuu, Emi, and Mizuki to head to the Special Male-Female Interaction Room since the student council waiting room would be cramped for seven people including Yuu. When they informed Kiriko, Yoshie, and Nana at the last minute, they immediately agreed. Thus, Sayori alone remained unaware of the fate awaiting her, outnumbered and helpless.  

"Whoa! So this is the rumored..."  
"Hey~ it's quite spacious!"  
"As expected, the bed is double-sized!"  

Kiriko, who knew of its existence but entered for the first time, looked around curiously. Though also first-timers, Emi and Mizuki remained calm thanks to prior experience with Yuu.  

"Wait! I-I wasn't told! I-I..."  
"No backing out now that we're here."  
"We're already one body and soul!"  

Sayori, who hadn't even started Special Insurance classes and was entering the building for the first time, found herself dragged underground without understanding. The moment she saw the bed in the assigned room, she tried to protest. But Yoshie and Nana, anticipating this, still held both her arms.  

"Now now. We just came to deepen bonds as new student council members. The waiting room would've worked but it's tight for seven."  
"Even so..."  
"Hm? Sayori, do you know what this place is for?"  
"Huh? N-n-no I don't!"  

Unaware she was now being addressed without honorifics, Sayori turned her face away with a pout.  

"So, Yuu-kun, what do we do here?"  
"I was thinking... maybe even suddenly..."  

Emi clung to Yuu's right side as he sat on the bed edge, bringing her face close. Mizuki sat on his left, no longer hiding her true feelings since Yuu accepted her real self.  

"Hahaha. Suddenly might be too much. How about a little game to have fun together?"  
""A game?""  
"Yes! The King Game!"  

**What is the King Game?**  
Create lots using chopsticks where the "king" gets chosen while others receive numbers. The king commands "Number ○ does ○○" or "Numbers ○ and ○ do ○○". Commands are absolute and must be obeyed. A game popular during mixers when Yuu was in college before his rebirth, though he'd never played and only vaguely remembered rules, so he explained with some adjustments.  

"This envelope has ten papers. Half have pre-written commands we'll follow. The rest are blank for on-the-spot king commands."  
"Commands...?"  
"At the earlier gathering, people without prior acquaintance might've talked a bit. But since we'll work together for a year, I thought becoming closer would be good. So let's limit it to physical contact—any form of touching."  
""""Hooo~~~""""  
"Sounds good!"  
"Let's do it!"  

Cheers rose from Emi, Mizuki, and others. Their minds naturally envisioned physical contact with Yuu. Perhaps reading the enthusiastic atmosphere, the previously quiet Sayori reluctantly agreed to join. They formed a circle on the bed edge: Yuu at the pillow, then clockwise—Emi, Mizuki, Kiriko, Sayori, Yoshie, Nana.  

During mixers, King Games involving romantic topics or light physical contact liven things up. Rumors Yuu heard included naming preferred partners, sharing love stories, hugging, Pocky games, and outright commands like "kiss", "undress", or "fondle". But when same-gender pairs get picked—especially males—it becomes no joke. Here though, Yuu was the only male among six beauties. Whichever way it went, Yuu stood to enjoy himself watching girls make physical contact.  

"Shall we try a practice round?"  
""Yes!""  

Yuu held numbered chopsticks hidden and had each girl pick one. For this trial, Yuu would be king. Everyone checked their numbers.  

"Who are numbers 1 and 6?"  
"Ah, me."  
"Here. Number 6."  

Number 1 was Kiriko, number 6 was Yoshie.  

"Then I command: Start simple. Both come forward and exchange greetings while shaking hands, saying 'Nice to meet you'."  
"That's acceptable?"  
"Since it's the first time."  

Yuu answered Nana's quiet question. Not everyone might grasp it yet, and except for close friends like Emi and Mizuki, shyness remained. Though he'd told Sayori it was for formality, his real goal was starting with light contact to build familiarity.  

Kiriko and Yoshie faced each other kneeling, shaking right hands. Some shyness showed between these two with no prior connection.  

"Um, Kawai-senpai."  
"Ah, no need for formality outside clubs. Why not use first names now?"  
"But—"  
"It's fine."  

While Yoshie maintained serious demeanor, Kiriko—despite her sports club background—didn't mind informality.  

"Then, Kiriko-senpai, pleased to work with you."  
"Yes, likewise. Um... Yoshie-chan?"  
"Yes, Kiriko-senpai!"  
""Hehe""  

Seeing them smile, Yuu deemed it a decent start and decided to begin real rounds with king selection including himself. They also agreed to follow their example and use first names.  

"It's a bit embarrassing, but I want to get along with seniors I'll work with."  
"Well... why not?"  

Yuu overheard Yoshie and Sayori talking after returning. Sayori sat beside her, naturally opening up despite their lack of prior interaction due to different classes. By special rule, papers with black dots in the envelope forced Yuu's participation—ensuring enjoyment for both Yuu and the girls. Yuu's strategy was starting soft like friends, then gradually increasing contact intensity.  

First round:  
Mizuki became flustered king. Yuu handed her the envelope. Since black dots might force Yuu in, she checked contents first.  

"Um, it just says 'follow instruction sheet'."  
"Here, this."  

Yuu produced a separate folded paper. No black dot meant no guaranteed participation—disappointing.  

"Choose from here...?"  
"Yes. Pick one, then say two numbers."  
"Hmm... oh my."  

Mizuki's mouth relaxed after skimming. Though only soft commands were written early on, all involved definite contact.  

"Then from the top. Face each other and hug. Numbers 3 and 5."  
"Come, number 5! Jump into big sis's chest!"  
"Aahn! Onee-sama!"  
""Ooh!""  

When number 3 Emi energetically called, number 5 Nana playfully leaped in. They hugged tightly like adoring seniors. Moreover, Emi gently stroked Nana's head, making Nana nestle closer blissfully.  

Going along enthusiastically rather than awkwardly shy made it fun. Despite being random, bold Emi and skilled actress Nana proved a fortunate start.  

Second round: Free command by Yoshie as king. Kiriko and Mizuki got picked. After hesitation, Yoshie commanded shoulder massages. Tennis club veteran Kiriko massaged busty Mizuki's shoulders with perfect pressure—a very welcome round for Mizuki.  

*(Shouldn't I get picked soon...?)*  

Yuu aimed to be picked by number, not as king. Half the papers had black dots, so his turn should come soon.  

"Ah, this time Yuu-kun participates."  
"Oh, yes!"  
""""......""""  

When Emi became king and picked him, Yuu rejoiced at his turn. Four girls prayed to be picked themselves while one panicked. Ironically, Sayori—who wished anyone else would get picked—was chosen.  

"Then as per instructions, Yuu-kun pats Sayo-chi's head."  
"Huh!? Wait, Sayo-chi?"  
"Okay. Sayori, come forward."  
"No no no, but I—"  
"So enviable."  
"Go on without hesitation."  

Sayori tried refusing in panic but got pushed forward from both sides. She stopped just beyond arm's reach.  

"F-fine. Here. Get it over with quickly."  
"Should I come closer?"  
"Eeh!? Wait!"  

Kneeling forward, Yuu closed the 30cm gap and placed his left hand on her shoulder. Touched, Sayori flinched, looked at Yuu, flusteredly averted her eyes, then looked down. Though her features were fine, her rare smiles gave initial coldness. But seeing her long lashes lowered behind glasses, cheeks faintly flushed up close, made Yuu's heart race. Her mere shyness created gap moe—adorable contrast.  

As cousin Riko said, she lacked male immunity and seemed to avoid recognizing Yuu as male. Maybe she preferred girls like Riko once did. *(Though Riko was Sayaka-exclusive rather than lesbian.)*  

Physical contact games likely weren't her intention. But since they'd work together, Yuu wanted closeness. Above all, serious, stiff, tall, slender glasses beauty Sayori intensely interested him.  

"Your hair is beautiful."  
"Nn... r-really?"  
"Yes. Smooth texture, fingers glide through—feels good touching it. Makes me want to stroke forever."  
"Uu..."  

Yuu didn't just pat Sayori's head but combed through her back-length hair. Unlike quirky Riko, her straight black hair was textbook perfect. Room lights created a halo on her crown, and flowing black hair shone lustrously.  

"Kuu... enough already?"  
"Emi?"  
"Not until the king says so!"  
"Such...!"  

King Emi watched smilingly, not ending it yet. Yuu leaned slightly forward to stroke lower back hair. Thus, forward-facing but downcast Sayori saw Yuu's open chest up close, gasping involuntarily. Never this close to a boy before, her cheeks burned crimson. Shame reached unprecedented levels, yet unexpected comfort and first-time male scent threatened to overload her mind. Perhaps why she suddenly leaned against Yuu's shoulder, consciousness fading.  

"Whoops."  

Lightly embracing the leaning Sayori, Yuu kept stroking her hair. Though taller than Yuu by centimeters, touching revealed a delicate frame and flat chest.  

"Maybe too stimulating for Sayo-chi. Let's end here."  
"Haha. See, Sayori. It's over."  
"Fue... wha!? Yah!"  
"Whoa!"  

Realizing their faces were kiss-close, Sayori frantically pushed Yuu away. Emi and Mizuki immediately caught him as he fell backward, preventing a tumble.  

"Haa~"  
"I get flustering at first male embrace! Especially with a handsome boy like Yuu-kun."  
"No, not that."  
"But you were happy? Heart pounded?"  
"Uu... This feeling is new—I don't know how to describe it. My mind's chaotic, unlike usual me..."  
"Hehe. I felt that too."  

Despite minimal interaction from different classes, Yoshie and Sayori naturally opened up sitting side-by-side. Sayori wanted to protest "no more" and "end this," but deep down, she didn't entirely dislike it—even felt slightly pleasant—yet resisted admitting it.  


### Chapter Translation Notes
- Translated "王様ゲーム" as "King Game" (direct translation of Japanese party game name)
- Preserved Japanese honorifics (-kun, -chan, -senpai) per style rules
- Translated "ブルマー" as "bloomers" (culturally specific gym attire)
- Rendered internal monologues in italics (e.g., *(Shouldn't I get picked soon...?)*)
- Translated "股間にタッチ" as "touched in the crotch area" (explicit anatomical term)
- Used "fiancée" for "婚約者" to maintain gender-specific term
- Translated "スキンシップ" as "physical contact" (contextual accuracy)
- Preserved Japanese name order (e.g., Kawai Kiriko not Kiriko Kawai)
- Transliterated sound effects: "うぅ" → "Uu", "はぁ～" → "Haa~", "くぅ" → "Kuu"
- Translated "ドキドキ" in chapter title as "Heart Pounding" to convey emotional state
- Maintained explicit terminology for sexual acts (e.g., "masturbated", "fellatio", "3P")