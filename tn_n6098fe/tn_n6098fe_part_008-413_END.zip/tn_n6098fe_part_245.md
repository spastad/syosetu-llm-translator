## 230. New Student Council ⑤ ~SHAKE YOUR BODY FOR ME~

"It's Pocky game, huh. Hmm, let's go with numbers 1 and 6."

"Pocky game?"

"Yuu-kun, it's Bocky game, right?"

"Ah... I slipped up. Here it's called Bocky."

This was the 11th round. The first instruction slip added had written on it: Pocky game.

Two people face each other and eat from both ends little by little. The one who lets go of the snack first loses. If both hold on until the end, they have to kiss.

It's a game often played at mixers, just like the King Game.

Of course, Yuu himself had never played it, and he had written it based on his memories from before his reincarnation when he learned about it online.

From this round, Yuu was the King, and the two called by number, Emi and Yoshie, would participate.

What Yuu held in his hand was a snack similar to Pocky that had been served in the student council room. He had brought the whole box since there were still some left inside.

Its name was Bocky, and like Pocky, it was a stick-shaped snack coated in chocolate except for the part held by the fingers, but the tip was slightly swollen.

It had a name and shape that made one think, "They're definitely aiming for that."

Since its release, it had been advertised in commercials by male celebrities, making it an immensely popular snack among women.

Emi knew about it because they had played it during summer vacation when staying at Sayaka's apartment, at Yuu's suggestion.

Although, at that time, not a single person let go midway, so it had just become an item for kissing.

"Then, to show an example, shall I go first?"  
"Y-yes. Please."  
"Give the starting signal, okay?"

Since the Bocky itself was about 13 cm long, Yuu and Emi ended up facing each other at close range.

Yuu's hand was placed on Emi's shoulder, and Emi's hand was wrapped around Yuu's waist to his back.

It was exactly like lovers about to kiss.

Emi put the chocolate-coated tip in her mouth, and Yuu put the non-coated end at the opposite side in his mouth.

"T-then... start!"

The sound of crunching could be heard for only a few seconds. In the blink of an eye, Yuu and Emi's lips were touching, and they began exchanging a passionate kiss.

"Mmm, mmmph... Yuu-fuun... anmu, chu, churu... lerooo... juru... lero, eoo... ah, mmphuun"

Yuu and Emi naturally drew closer and it developed into a deep kiss with their tongues.

A sigh leaked from the surroundings as they watched the two.

"Hey, it's called a game, but is there really winning or losing?"  
"Who knows."  
"They're really hot, aren't they? Just watching makes my heart pound too."

Since it didn't seem like they would stop anytime soon, Mizuki and Kiriko hesitantly called out to them and interrupted.

This time, Yoshie moved to face Yuu.

"My glasses might get in the way, so I'll take them off."

As the class representative of Class 1-5, Yoshie, whom he had met during the sports festival, seemed genuinely earnest and innocent, and he found her gentle personality appealing.

Since Sairei Academy had a relatively high number of cute girls, Yoshie, who wasn't strongly assertive, didn't stand out.

But when a girl who usually wears glasses takes them off, her impression changes.

He knew that with her thin lenses, she originally had big, wide eyes.

Now, Yoshie, taking off her glasses right in front of Yuu and looking at him shyly, was so endearing and cute that he couldn't stand it.

Seeing her up close without glasses, her almond-shaped eyes were moist as if filled with anticipation, and her large, dark pupils were so mysterious they seemed to draw him in.

"Yu, Yuu-kun... if you stare at me like that, I'll get embarrassed."  
"Sorry, sorry. Then, shall we start?"

Yuu, who had been staring intently at Yoshie with the Bocky tip in her mouth, placed his hand on her shoulder as he had with Emi and put the opposite end in his mouth.

He bit down in small, slow increments, more slowly than before.

Yoshie kept her eyes closed, but when they were just a few centimeters from their lips touching, she inadvertently opened her eyes.

Just as Yuu's face, with his eyes slightly open, filled her vision, she bit through the Bocky in her fluster.

"Ugh... mmmph!?"

At that moment, Yuu promptly stole Yoshie's lips.

For Yoshie, even a kiss had been about two months since the last one.

With their lips pressed together and in an embrace, Yoshie, overwhelmed with joy, teared up and tightened her arms around Yuu's back.

"Fah... mmm... mmphuu"

Unlike with Emi, where their tongues had touched immediately, this time the kiss continued slowly, as if savoring the feel of each other's lips, with their faces changing angles several times.

"Yu... u... mmph mo!"

Seeing Yoshie's eyes become moist as if pleading for something, Yuu inserted his tongue.

There was no need to force her teeth apart; Yoshie willingly opened her mouth and welcomed it with her own tongue, actively tangling with his.

"Nna... ah, nne... fea... u, chupa, chupa... mmph, mmph, ahn... mmphuun"

Not only could the onlookers see the tongues tangling between Yuu and Yoshie's mouths, but with each movement, the sound of saliva going "chupa chupa" and moans of pleasure leaked out.

"So... good..."  
"Just from kissing... she looks like she's feeling really good."  
"I want to... too."  
"Sorry to interrupt while you're so into it, but we should wrap it up and move on to the next."

After the deep kiss, Yoshie was so limp that she didn't try to move away. With a wry smile, Yuu let her cling to his side as he drew the next slip and read it aloud.

By the way, they didn't draw lots again.

"Next is licking ears. Numbers 4 and 5."  
"Huh?"

Yuu read the numbers knowing what they meant, but the two in question reacted in contrasting ways.

That is, number 4, Sayori, stood there dumbfounded without moving, while number 5, Nana, quickly approached without a word, turned her back, and slipped right between Yuu's legs as he sat cross-legged.

"Brother, lick as much as you want."

Nana gathered her long black hair with her hand and swept it to the left front.

Then, her small right ear was exposed.

It was so small that the entire ear might fit in his mouth.

"Okay. Then, without holding back."

Yuu gently and softly embraced Nana, the smallest in the student council, and tilted his head to bring his mouth close to her right ear.

"Hyu... fowa! Ah, nn, kuuuuuuuuuuuuuuuuuuuuuuuun!"

From the earlobe to the back, then the inside, even into the hole. Sometimes he used his lips, but mainly he boldly used his tongue to lick all over.

It was only about five minutes, but when Yuu pulled his mouth away, Nana went limp and leaned her back against Yuu.

Yuu reached for a tissue and wiped her ear, which was drenched and glistening with saliva.

"B-bro... ther..."  
"Nana"

Nana looked up at him with dazed eyes, so adorable that Yuu covered her lips.

Then he whispered softly.

"Now the other side?"  
"Ah... n-no. I'll... go crazy..."

Interpreting this "no" as meaning "yes" in this context, Yuu swept her long black hair to the other side and began caressing her left ear.

There are individual differences, but the ear has many nerves connected to pleasure, making it one of the erogenous zones.

In contrast to men, who are more receptive to visual stimuli, women are more sensitive to auditory stimuli, so even having breath blown near their ear or hearing lewd whispers can arouse them.

Moreover, being licked with a tongue can even provide pleasure equivalent to that of the genitals, it is said.

Based on Yuu's experience, girls with long hair that usually hides their ears tend to be more sensitive to stimulation and have more sensitive ears.

He had somewhat expected it, but Nana also became quite aroused from her first ear caress.

While he caressed her left ear for over five minutes as well, her moans wouldn't stop, and after finishing, she didn't even try to move, leaving herself entirely to Yuu.

Moreover, since she was sitting right on Yuu's lower abdomen, he could feel a damp sensation.

It seemed she was wet, as if she had leaked.

Yuu picked up Nana and moved her to Yoshie's side, entrusting her to her.

Yoshie was a reliable class representative at times like this.

Then, he called out to the vice president (1st year), who looked unusually tense.

"Well, next is Sayori."  
"Eek!"

Sayori tried to put distance between herself and the approaching Yuu, but she was caught by Kiriko, who was behind her.

With her athletic background and muscular strength, Kiriko firmly held Sayori's upper body, including both arms, and Sayori's slender arms couldn't break free.

"I'd love to take your place, but it's Sayori-chan's turn now."  
"No, I... didn't join the student council to do this kind of thing..."  
"Huh? But you were chosen for the student council where Yuu-kun is, right? Let's all get along."  
"That's right, that's right."  
"Sayori-chan, is there another boy you like?"  
"Th-that's not it..."  
"Am I not good enough?"

"U..."

Normally, Sayori was eloquent, but in this situation, she seemed at a disadvantage.

She had been in the student council in middle school too, so when it came to student council activities, she had confidence she was second to none.

But she felt something like envy or rivalry toward Yuu, who had suddenly become student council president without an election.

Originally, Sayori had no interest in boys, so she hadn't tried to interact with Yuu, but today she couldn't help but be conscious of him.

As Sayori fidgeted, her eyes darting around, Yuu's face drew near.

Yuu's right hand took her pointed chin, and he stared at her from close range.

Out of embarrassment, Sayori averted her eyes to somewhere else.

"Hmm. As expected of Riko's cousin, Sayori, you're an intelligent beauty just like her."  
"R-Riko nee?"  
"Yes. She's my fiancée, same as Sayaka and Emi."  
"In your first year of high school... and you have three fiancées already, and you say that's not enough?"  
"Ah, I'm greedy. If there's a cute girl, I want to get close. There's no limit, whether it's a few or dozens."  
"Haa... I'm amazed."

"So, I want you too, Sayori. If you don't dislike me, won't you accept me?"  
"Ugh."

Being courted so boldly, even Sayori couldn't feel bad about it.

As proof, she relaxed her arms, looked at Yuu's face for a moment, and then closed her eyes.

Seeing Sayori's expression, Yuu smiled and gently kissed her. It was a light kiss, just a touch.

Even so, Sayori's cheeks flushed as if a red flower had bloomed.

Yuu lightly stroked her head and brought his mouth close to her ear.

He didn't lick it right away; instead, he blew a soft breath.

"Hyan!"  
"Hmm. Such a cute reaction."  
"D-don't tease me."  
"I'm not teasing. Sayori right now is really cute. Fuu."  
"Yan! N-no."  
"How does it feel when I blow like this? Fuu."  
"Hya! I-I don't know. This is my first time... ah, ah... I'm getting... shivers."

Sayori was showing a noticeable reaction even though she hadn't been licked yet, just having breath blown or whispers.

It was certain that her ears were sensitive.

Still, compared to Nana earlier, Sayori still seemed to have some shame and resistance in her heart.

Instead of suddenly sucking, Yuu extended his tongue to be soft.

Then, a voice came from the opposite side.

"Brother, I'll help too."  
"Ehh?"

From Sayori's perspective, Yuu was on her left, but before she knew it, Nana had approached from the right.

Moreover, with a mischievous smile, she hugged Sayori and blew on her ear.

"Hyau!"  
"Great. Then, simultaneous attack from both sides."  
"Okay."  
"Like that... eek... faaaaah!"

First, he traced along the outline of her ear with the tip of his tongue.

After going around once, he traced a bit inward in a spiral, teasingly licking.

Meanwhile, Yuu's other hand stroked Sayori's long black hair to help her relax.

"Ugh, ugh, kufu... fah!"

Nana imitated him, not suddenly digging into the earhole, but being soft.

But with both ears being caressed, Sayori couldn't help but let out a voice.

Yuu pulled his mouth away for a moment and licked the back of her ear instead of the inside.

As he did so, he made deliberate slurping sounds.

"Nn... kufuu... nn, nn, u... ah... un... ya... n... no... more... than this... hyaa! St-stop, ah, afu, fu... hiiiiin!"  
"Hmm? Sayori, doesn't it feel good?"  
"Stopping would be a waste. You must be feeling it. Since a while ago, I've seen abnormal sweating and heart palpitations. And..."  
"Yah!"

Suddenly, Nana thrust her hand under Sayori's skirt.

In that regard, girls are less reserved with each other.

"Brother, this girl is wet."  
"Oh ho."  
"Mou!"

"Then, let's make her feel even better."  
"Okay!"

Yuu and Nana simultaneously inserted their tongues into her ear holes.

"Hya... ah, ah, oh... hyafu! Ummph! N-no more... stop... aeeeeee... nna... i, nn, kufuuuuuuuuuu... y-you... per... verts... yoooooooooo"

"Sayocchi, who was so prim and proper when we first met... is completely disheveled."  
"It feels so good. Ahaha, I want the same done to me too."  
"Mii-chan, I like you too, you know."  
"Ehehe. I love naughty things. Especially if Yuu-kun does them."

Being persistently tormented at both ears by Yuu and Nana, Sayori threw away her usual cool attitude and writhed intensely.

Her cheeks dyed pink, and with her constant moaning, drool dripped from the corner of her perpetually open mouth.

Even if she closed her mouth and tightly shut her eyes to endure, moans would leak out immediately.

Occasionally, her whole body would shake violently, causing her legs to spread slightly, and her light blue panties could be seen under her disordered skirt.

From the front, one could see she was wet along her camel toe, and stains were even appearing on the sheets.

In other words, she was being made to experience brain orgasms multiple times.

After about fifteen minutes of ear licking, they finished.

Sayori was so sensitive that Yuu and Nana might have gotten carried away.

When Yuu looked at Sayori, she was dazed, as if her mind was elsewhere.

"Sayori? Sayori, I say?"  
"U... ah?"

The moment she realized Yuu was holding her shoulders and peering into her face, Sayori remembered what kind of lewd behavior she had been displaying to Yuu and the student council members until just now.

Instantly, her cheeks turned bright red, and she tried to look down, but Yuu gently hugged her.

"Sayori, writhing in pleasure, was so beautiful, and your voice was adorable. I got excited too. I want to see more of you in various ways."  
"Ah...!"

Yuu's lips covered Sayori's.

At that moment, a hot flame burst inside Sayori, and she clung to Yuu on her own, pressing her lips against his in a frenzy.

Yuu gently held her, and they repeated sweet kisses many times. Watching this scene, Nana murmured softly.

"Fallen?"  
"But getting to know the real Yuu-kun starts now?"

It was Mizuki who approached and said that.

"By the way, Nana-chan, how far have you gone with Yuu-kun?"  
"I... haven't done the real thing yet..."  
"Kiriko-san too, right?"  
"Kiriko is fine. I just had my first kiss with Yuu-kun earlier."  
"Then, today, both of you can look forward to graduating from virginity."  
"G-graduate!?"

It would be a lie to say Nana and Kiriko weren't expecting it.

But they never thought the opportunity would come this soon.

"More importantly, I wonder what kind of command Yuu-kun will give Kiriko and me next?"

"What kind of naughty thing will he do?"

"Ufufu. My heart is already pounding, and the pit of my stomach is fluttering nonstop."

Mizuki crossed her arms in front of her, emphasizing her large breasts, and smiled bewitchingly.

That smile was like that of a succubus, something no one had ever seen at school.

### Chapter Translation Notes
- Translated "ポッキーゲーム" as "Pocky game" for the real-world reference, but "ボッキーゲーム" as "Bocky game" for the in-universe snack
- Preserved honorifics: "-kun", "-chan", "-san" as per original
- Transliterated sound effects: e.g., "かりかり" → "crunching", "ちゅぱちゅぱ" → "chupa chupa", "ひゅっ" → "Hyu"
- Translated explicit sexual terms directly: "濡れてる" → "wet", "脳イキ" → "brain orgasms", "マンスジ" → "camel toe"
- Used character nicknames: "さよっち" → "Sayocchi" (Hanmura Sayori), "みーちゃん" → "Mii-chan" (Ogawa Mizuki)
- Translated "本番" as "the real thing" to imply sexual intercourse without euphemism
- Maintained Japanese name order: "Hanmura Sayori" instead of westernized order