## 231. New Student Council ⑥ ~Bloom Wildly, Maidens~

"Hah, nnn... nku... ah, ah, nn! Hafu"  
"Nn, fu, fu... a... ann! Yaan... really, Yuu-kun, you truly... love breasts, don't you?"  
"Ah, I love them. Big ones, small ones - I love all girls' breasts.  
Mizuki's breasts are fluffy and soft like marshmallows, while Kiriko's have perfect firmness and bounce. I want to keep kneading both forever."

The command for the final two - Mizuki and Kiriko - was "Let me squeeze your breasts."

As stated earlier, Yuu loves all breasts regardless of size, big or small.  
That said, with the new student council's top two largest-breasted members before him, refusing to grope them wasn't an option.

Mizuki possessed disproportionately large breasts on her petite, slender frame - likely F-cup.  
In contrast, Kiriko's muscular build made hers less noticeable at first glance, but when revealed, their volume was unmistakable - too much to fully grasp with one hand. Probably D-cup or larger.

Yuu sat with legs spread, positioning Kiriko facing away on his right and Mizuki on his left, both straddling his legs.  
He kept their sailor uniforms on, unhooking only their bras for direct skin contact beneath the fabric. To outside observers, Yuu's hands moved furtively beneath the cloth - a fetishistic scenario made manifest.

Since Kiriko was unaccustomed to fondling, his right hand explored her breasts softly, gauging their texture.  
His left hand jiggled Mizuki's overflowing large breasts with palm-up support.  
Though initially suppressing her voice, Kiriko proved surprisingly sensitive for a first-timer, emitting increasingly high-pitched moans as his right hand moved.  
Mizuki seemed more composed, so when Yuu firmly grasped her entire breast and tweaked the nipple between fingers, she shuddered violently and gasped.

"How is it? Kiriko-san. How does having your breasts touched feel?"  
"A, nn... somehow... it feels nice."  
"Do you touch them yourself?"  
"Um, sometimes... But not much alone..."  
"What if I do this?"  
"Hyauu! Ya, so, there!"

Despite the soft touch, when Yuu kneaded Kiriko's nipple, she reacted with hypersensitive intensity.

"Fufu. Your nipple's hardened."  
"Nn, kufu... why... Yuu-kun's... finger... nn, nnn~~~~~~~ aann!"

As Kiriko reflexively arched backward, Yuu's lips traced her exposed neck, sucking greedily.  
Meanwhile, his left hand kneaded Mizuki's soft breast with measured pressure.  
Occasionally, he'd use his full palm to knead the entire mound, nipple included.

*(Breasts really are the best. And getting to grope two pairs simultaneously? Such luxury.)*

While continuing to knead with both hands, Yuu alternately traced lips and tongue along the napes and necks of the girls leaning against him.  
The girls' sweet scent and dewy skin were irresistible.  
Mizuki's nasal, honeyed moans blended with Kiriko's huskier tones - the dual gasps fueling Yuu's arousal.  
Consequently, the bulge in his chino pants became visibly obvious. Mizuki reached toward it.

"Oh!?"  
"An... incredible... your cock's rock-hard."

Mizuki gazed dreamily at his crotch while stroking the hardened area.  
Kiriko reacted to her words.

"Eh? Yuu-kun's... *gulp*."

The bulge was unmistakable even through fabric.  
Though Kiriko had witnessed Yuu penetrating Emi on the rooftop two months prior, darkness hid the genital details.  
But this swelling exceeded expectations - how had petite Emi taken this into her mouth?  
Imagining it inside herself, Kiriko felt a sudden twinge deep in her lower abdomen.

"Now now. I haven't permitted cock-touching yet?"  
"Aah! Yaa... nn, but... I want to touch it... your cock... love your cock... hyafu! Yuu-kun... so mean... come on, it's okay?"

Yuu tweaked Mizuki's nipple, but she kept fondling his cock despite the stimulation.  
Then Yuu noticed the other girls' heated stares.

"Hey, Yuu-kun?"  
"Yu, Yuu-kun..."  
"Um, brother, me too..."  
"Ah..."

Emi and Yoshie approached from the front.  
Nana from behind.  
Even Sayori, flushed crimson, peered at Yuu from behind Nana.  
All four inched closer - a full encirclement.

Where most boys would panic, Yuu reveled.  
Time for deeper physical intimacy.

First, he addressed the pair at his feet.

"Emi, Yoshie"  
"Unn! Yuu-kun!"  
"Ye, yes..."

To the breast-groping pair, he whispered at their ears.  
(Mizuki's hand remained on his crotch.)

"Mizuki, Kiriko"  
"Yuu... kuun"  
"Fai"

Then he turned backward.

"Nana, Sayori"  
"Yes. Brother."  
"Wh, what? Th-this time... what... are you doing...?"

Nana clung to Yuu's back.  
Sayori watched expectantly just behind him.

"Let's strip."

Hierarchies dissolved now.  
Shedding clothes to become simply man and women.

As if cued, the girls stripped without hesitation, neatly hanging uniforms.

"Yuu-kun, I'll undress you!"  
"Ah, me too."  
"May I... help too?"  
"Please do."

Naked Emi, Kiriko, and Mizuki reached for Yuu's clothes.  
He'd delayed to watch their disrobing.  
Meanwhile, still-underweared Sayori found Yoshie and Nana simultaneously removing her bra and panties.

"Am, amazing... th-this is! Th-the... boy's... cock!?"  
"Ufufu. Haven't seen others', but Yuu-kun's is special. Thicker and longer than normal!"  
"I, is that so?"  
"Juru, jurururu, npa. Hafu... ohii. Chu, chu, churu... ahhaa, I love Yuu-kun's smell."

Cross-legged Yuu had three second-years (Emi, Mizuki, Kiriko) swarming his cock.  
Emi, center-stage, proudly narrated while tracing it. Kiriko watched intently from the left. Mizuki lay face-down, sucking his balls.

"Yoshie's pussy... incredible. Flooding already?"  
"Aahn, because... ah, ah, aah! Yu, Yuu-kun's finger... squelching inside... feels... so good... ahhi! Wh-what is that!? It's, it's, it's too much!"  
"Look, look, about to cum?"  
"Nkuu! Uu... a, a, ah... I'm cumming! Ann! I'm cummiiiiiiiiiiiiing!"

Yoshie's hips jerked with each finger-thrust. She squirted violently.  
Opposite, Yuu focused on Sayori's clitoris with gentle strokes - her first time.  
She moaned intermittently, writhing.

"Sayori's soaked too, look - dripping wet."  
"Auuu... wh, why? Ahhn! Down there... feels weird. Hau... no... it's tingling!"

Yuu withdrew his hand, showing Sayori the juice-drenched finger.  
She stared dumbfounded.  
He licked it clean, kissed her, squeezed her modest breasts, then slid back down.

"Nn... fa... afe... umu, lero... chupa... chupa... nnkuun!"

Fingered while deep-kissing, Sayori's expression melted completely.  
Meanwhile, Nana clung like a cicada to Yuu's nape.

"Lero lero... konrafure, iiro?"  
"Good girl. Lick it lovingly."  
"I won't lose. Aaanmu! Nmunmo"  
"Kuhah! Feels... amazing."

Emi, Kiriko, and Mizuki competitively sucked Yuu's cock - their heads obscuring his view.  
Three tongues crawled over glans, corona, and frenulum while hands stroked his shaft and massaged balls.  
Led by experienced Emi, their gentle ministrations pushed Yuu toward climax.  
Simultaneously, he kissed Nana (now beside him) and rubbed Sayori's clit.

"Hyaa! Aa, uwe... no... like that, suck... no... it's weird... it's getting weird!"

Inexperienced Sayori shook her head in overwhelmed refusal, pulling away.  
Nana pressed closer instead - having gone nude with classmates before.

"Brother, um... even my childish body... will you touch it?"  
"Of course. Show me your chest?"  
"Chest?"

Where Sayori had A-cup mounds, Nana's were barely AA-cup.  
Yuu cupped them reverently, taking a tiny pink bud into his mouth.

"Hyaa! A... a... aku... feels good. First time... licked by brother... shivers! Nn, nn... brother, brother... ah, hi, so, there!?"

He flicked the nipple while his right hand slid from waist to buttocks, then along her cleft.  
Her near-hairless vulva glistened, drenching his finger.

"Nnn~~~~~~~kuu... ah, ah, ah... bro... ther!"

When Yuu's finger brushed her clitoris, Nana convulsed violently.  
Seeing this, regret and envy overwhelmed Sayori.

"Ah, um... Yuu... kun?"  
"Sayori?"  
"Sorry about earlier. I... want it too... please?"  
"What exactly? Be specific."  
"Uu..."

Blushing, Sayori hesitated, then met his gaze squarely.

"Your fingers... touching me... down there."  
"Where?"  
"Where... ugh! My... pussy!"  
"Gladly. I'll touch Sayori's pussy thoroughly."

With Nana and Sayori flanking him breast-to-face, Yuu fingered both simultaneously.  
But the triple blowjob reached its peak - orgasm imminent.  
Emi and Kiriko focused tongues on the glans while Mizuki licked the frenulum and stroked.

"Aah! Shit, I'm... close..."  
"Amu, nmunmu... lerolero"  
"Hafu, hafu. Nn~~muchu! Ahhaa, this smell... wonderful. Just licking makes... down there tingle!"  
"Waha... Yuu-kun's cock... twitching. Wants to cum, right?"  
"Uu... I... need to ejaculate!"

Fingering two virgin pussies while breast-smothered, Yuu groaned.  
Emi's tongue probed his urethra. Kiriko sucked the corona. Mizuki licked the frenulum.  
Their stroking hands accelerated.

"Uu! Kah! Cum... ming!"

After Yuu's cry, semen erupted violently.

"「「「Aah!」」」

Emi (experienced), Mizuki (recently seen), and Kiriko (first witness) wore identical shock.  
Emi and Mizuki happily licked the semen while Kiriko followed suit.  
Meanwhile, Nana and Sayori were beyond noticing.

"Ahha, so much today~"  
"Haa~n. This much... incredible"  
"Wa, wa, waa!?"

The first spurts splattered the waiting Emi and Mizuki - and Kiriko who looked up startled.  
Subsequent shots whitened their faces and hands.  
Nana and Sayori remained consumed by Yuu's fingers.

"Ah, ah, aah! Brother, br... hii! Ya... faaaaaaa"  
"No... more... it's getting weir-hyau! Fuguu... afui! Ah, down there, overflowing... ngiihh!"

Clutched by both girls, Yuu continued stimulating through his afterglow.  
Sayori didn't flee this time.  
He focused on their clitorises rather than virgin vaginas.

"Br, brother... hyan! Aah... cumming! Aann!"  
"No, no, n... ah, ah... what... kuhi... aah! Ngggggggggggggh!"

Nana arched backward in climax. Sayori followed instantly.  
Yuu's hands and elbows dripped with their fluids.  
Their first orgasms left them collapsed - Nana clinging to his chest, Sayori at his nape.

---

### Author's Afterword

Writing group play scenarios that start so naturally is enjoyable yet challenging. With increased participants like this, it's easy to lose track of positions and actions.

### Chapter Translation Notes
- Translated "おっぱい" as "breasts" consistently per explicit terminology requirement
- Preserved Japanese honorifics (-kun/-san) and original name order (Ogawa Mizuki)
- Transliterated sound effects (e.g., "びしょびしょ" → "dripping wet")
- Used explicit anatomical terms: "チンポ" → "cock", "おマンコ" → "pussy"
- Rendered sexual acts without euphemisms: "しゃぶる" → "suck", "イく" → "cum"
- Italicized internal monologues per formatting rules
- Maintained dialogue structure: new paragraphs for each speaker
- Translated chapter title as "Bloom Wildly, Maidens" to capture floral metaphor