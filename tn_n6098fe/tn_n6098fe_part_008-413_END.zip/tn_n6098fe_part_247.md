## 232. New Student Council ⑦ ~Tears Sparkle☆~

### Author's Preface

Finally, we've reached the main event. This and the next chapter focus on the three virgins.

Normally, the unavoidable pain of losing one's virginity poses a question of how much to depict. While Nocturne novels sometimes conveniently downplay (or ignore) this, I think it's fine to have different cases depending on the partner.

So please enjoy each of their first-time scenes.

---

Who would be first to have intercourse with Yuu?

Among the girls, it was unanimously decided to be Kiriko.

It seemed Emi, as his fiancée, led the discussion among the six. They prioritized the three virgins who made up half the group. First, Sayori declined to go first. Nana honestly shared that she'd previously experienced kissing and fellatio with classmates, so she'd go second. Kiriko, who'd had almost no interaction with Yuu before, was forced to confess she'd been thinking about him since the quiz championship. Understanding her feelings, they made her first.

Under the watchful eyes of the other five, Yuu and Kiriko faced each other on the bed. Kiriko blushed and fidgeted, her gaze darting between Yuu's face, chest, and crotch. His erection had remained hard since being cleaned by the three second-years' tongues after ejaculation. Her hand rested on her left breast, perhaps because she was conscious of her pounding heart. Though her most intimate area hadn't been touched yet, she was thoroughly wet and ready. Resolved, Kiriko swallowed hard and spoke.

"Um... well... you see... it's my first time, so I..."

"It's okay. Don't be so nervous. Leave it to me."

"Ah!"

Yuu moved forward and embraced Kiriko. Instantly, her cheeks relaxed. After all, everything since entering this room felt like a dream to her. Moreover, losing her virginity to Yuu was something she'd fantasized about countless times. Before being chosen for the student council, she'd thought it an impossible dream.

Though her ingrained common sense told her women should take the lead, she didn't know what to do when it came down to it. But being held like this filled her with indescribable warmth.

"Eh? Eh?"

Kiriko was pushed down by Yuu. With Yuu supporting her head and back, she was slowly laid on her back. Just as her head touched the pillow, Yuu sealed her lips.

*(As expected, kissing Yuu-kun... feels so good, it makes my head fuzzy...)*

Kiriko wrapped both arms around Yuu's back as he covered her. Until recently, she could only gaze at this beloved back from a distance, never dreaming of touching it. Though somewhat slender, it had firm muscles over bony structure. Just stroking it made her ache with desire. Kiriko caressed his back as if cherishing it. Their lower bodies pressed together, his hard cock pushing against her lower abdomen. Though she'd helped bring him to ejaculation earlier, his penis seemed harder than before, likely because Yuu himself was excited at the prospect of penetration.

"Ah, Yu... kun..."  
"Kiriko, spread your legs."  
"Hauun"

It sounded less like a reply and more like a female moan of desire. Yuu positioned himself between her spread thighs, pulling back slightly to prepare for insertion. Her pubic area appeared dark, the black pubic hair glistening with her own love juices. Without visual confirmation, Yuu pressed his cock against her moist entrance to adjust position. When the tip touched her vaginal opening, a wet *squelch* sounded.

"Here?"  
"Ah... y-yes. Just... come... inside... me..."  
"Here I go. I'll take Kiriko's virginity."  
"Aah! Y-Yuu-kun, I'm hap... nguuaaah!"  
"Guoh!"

Being mindful she was a virgin, Yuu inserted slowly and carefully. The glans slid in *squishily* without hitting the hymen. Simultaneously, he felt an intense tightness.

As he'd heard before, she might have broken it during intense exercise or while masturbating with a thick vibrator. Asking would be tactless, and if it reduced pain, it was convenient. Still, Kiriko's vaginal walls clamped down powerfully on his cock as she accepted a penis for the first time.

Peering at Kiriko's face, her nervousness was obvious. She squeezed her eyes shut and clenched her mouth, perhaps due to some pain. Her arms around Yuu's back were tense.

"Kiriko"  
"Ah... hyai!"  
"Relax your strength"  
"Nn... mmu"

Using one arm as a pillow, Yuu grabbed her mountainous breast with his other hand, trapping the nipple between his fingers as he kneaded it. Then he sealed her lips in a slow kiss.

Though Yuu had been with dozens of virgins, the initial insertion always took time. Prying open tightly closed vaginal walls wasn't easy. Even with vibrator experience, no woman had ever taken a cock as large as Yuu's. Still, getting her to relax was crucial. As they kissed repeatedly, Yuu noticed Kiriko's expression softening. Keeping their lips connected, he began small thrusts.

"Nmmu... nn, nku... Yuu... kun... ah... aaah! Guah! Shugo... oh!"  
"Does it hurt?"  
"Hyakurai... yo... aaah! Yuu... ku... nnnnnnnnnnnnguaaaaaaaah! O... ku... uuuu"  
"O-oh... all the way... in!"

How long had it been since he pushed her down? The moment he felt like prying open a narrow crevasse, his cock plunged deep into her vaginal depths. Finally fully inserted, Yuu caught his breath and looked at Kiriko - tears moistened her cheeks.

"Kiriko?"  
"Ah... hehe. I'm happy. Because I lost my virginity to Yuu-kun, who I love so much. Really, reaching this day... I couldn't contain my emotions."  
"Thank you too. But... this isn't the end?"  
"Aahn!"

Yuu savored Kiriko's tight vaginal grip before slowly beginning to move his hips. He'd pull out almost completely, then slowly push back in deep. He repeated this many times. Though Kiriko had frowned in discomfort at first, as Yuu kissed her neck tenderly, his cock seemed to settle in. Sweat beaded on her skin, and her moans grew sweeter in rhythm with Yuu's movements. With each thrust to her depths, sticky wet sounds came from their joining area as their mixed fluids soaked the sheets.

"Guh... Kiriko! Aah! Inside Kiriko... feels so good! I'm already..."  
"Yu... Yuu-kun... nn! Ah! I... feel good too! Ah, ah, aaah! Hya! Aah... amazing! Hyuun! Yuu... kun! I love... love love love you!"  
"Vuoh!"

Whether because he'd taken time to acclimate her or due to abundant lubrication, his movements became smoother. Simultaneously, Yuu's urge to ejaculate grew. As Yuu moved more vigorously, Kiriko climbed toward heights she'd never reached through masturbation. Continuously impaled deep inside, she threw her head back, moaning while tightening her arms around Yuu's back. Perhaps it was hysterical strength - her tennis-trained arms squeezed powerfully, making Yuu gasp, but he didn't stop. In return, Yuu hugged her tightly and began his final sprint.

"I-I'm close... Kiriko, I'll... ejaculate... inside you"  
"Ki... hee... aaah! Your cock! Amazing! No no no! I'm cumming! Ahhyin! Yuu... kun! Yuu-kun, Yuu... ku... aaaaaaaaaaaaaaaaah!"  
"Ooh! Cumming! Ugh!"

Burying his face in her sweaty chest while thrusting wildly, Yuu finally reached climax. The moment hot torrents filled her womb, Kiriko's vision went white. Experiencing her first orgasm simultaneously with his ejaculation, then receiving continuous spurts, Kiriko's consciousness faded.

She was only out for seconds. When Kiriko came to, Yuu had finished ejaculating and lay with his cheek pressed between her rising and falling breasts.

"Haa, haa, haa... it was amazing, Kiriko"  
"Ah... fa... yes. Me too..."

Overwhelmed, words failed her, but Kiriko's expression radiated supreme happiness as she awkwardly stroked Yuu's head.

---

"Nana, how's the pain?"  
"Uu... still hurts... but... it's okay. Move... aah"  
"Don't push yourself. Here"  
"Ni... hyan... nmu"

Nana was second. Being the smallest in the student council, Yuu tried inserting while holding her in a facing position, but when he broke her hymen, he heard a pained scream and she froze. Though she'd been wet during pre-penetration play, Yuu's cock proved too much. Though unseen, the towel laid out as precaution was likely stained with virginal blood.

Yuu gently held Nana with one arm, stroking her cheek while kissing her. Nana already clung to Yuu. Though she'd grimaced in pain, as Yuu slipped his tongue in and maintained contact, her expression gradually melted.

"Nmmu... nn, nku... ni... hya... ah... um... amu, chupa, churu, neroo, lero... ahfu, onii-san, more"  
"Okay. Nana's so cute"  
"Ehee... chu-... love you... aahn"

Their intensely long deep kiss - enough to astonish onlookers - proved effective. Perhaps because she relaxed, when Yuu loosened his arm, gravity made his cock sink deeper.

"Aah... iih!"  
"Nana, sorry"

What had been nearly closed now felt slightly opened. Yuu continued penetration while holding Nana.

"Higu! Ni... onii-hyan... nnaaah, aaah! Iih! Nnn! I-It's going in... ku... kyaun!"  
"Tight... but... just a bit... oh!"  
"Ha... hi... ya... hyan... onii-san... inside me... so much..."  
"Yeah. You did great, Nana"

Though difficult, Nana successfully lost her virginity. Since first meeting Yuu and losing her heart to him, she'd longed for this moment. Emotions stronger than pain flooded her.

"Hah, hah, hah... Nana's pussy memorized onii-san's cock shape. Nana's body is onii-san's personal breeding pouch. From now on, fill me with your seed, fertilize me, make a baby quickly."  
"Seriously. Where'd you learn lines like that?"

Seeing Nana's impish smile, Yuu smiled wryly. She was probably playing some little sister character again. But her enjoyment wasn't faked. After slow penetration, with her cervix pushed up, pleasure now exceeded pain. Though he'd ejaculated twice already, the tight grip and sensation of his glans being sucked by soft flesh made Yuu feel he wouldn't last long.

*Tan! Tan! Tan!*  
*Zun! Zun! Jucchu! Jucchu!*

"Aah! Nn, naa! Ni... i... hya, vua! Ya, hyun!"  
"Ah, Nana, Nana! Ku! Amazing, squeezing so tight inside Nana... dangerous, I'm already..."  
"Iih! Cum... for me. Onii... hyan, ah! Inside... me..."

Holding each other tightly, Yuu thrust upward. Sweat beaded on his forehead, their skin grew hot and damp. Especially their joined area mixed sweat and fluids, emitting sticky wet sounds. The feeling of having sex with what felt like a real younger sister - even if only half-related - intensely excited Yuu. With every thrust, clinging vaginal folds provided supreme stimulation, bringing Yuu closer to climax than Nana.

Orgasming a virgin with little masturbation experience was difficult. But having been with dozens of virgins, Yuu couldn't yield easily.

"Right. I'll stop for a bit."  
"Huh?"

He stopped moving to take a break, slightly separating their bodies.

"I want to change positions."  
"Nn..."

Nana's petite body was light and easy to lift. When he pulled out, pale pink fluid mixed with virginal blood dripped. He placed Nana's hips on his lower abdomen to change their orientation. Yuu reached for a pillow behind them and positioned it to support her waist.

"Eh? Onii-san?"  
"Inserting now."

Unlike the first time, penetration was relatively smooth. But her vaginal walls clamped down as if trying to expel the invader. After fully inserting, Yuu immediately held still and hugged Nana from behind.

"Kufuu... this is nice too, right? You can lean back completely."  
"Ah... fai... ni, onii-san enveloping me... feels like... I'm full of onii-san... ah, ah, hyu... I'm... iiiih"

Though not moving, Nana moaned adorably. Yuu pressed his cheek against her shoulder, past her long black hair. The mingled scents of her hair and sweat felt like a female's seductive pheromones. Exposed to air, Yuu's cock hardened further.

"Na, na, nyaa! Onii... hyan... noooooo... wa, aah! Aah! No... pleaseee... uwa, aah!"  
"Don't... ah! Aah! No... ohhhh!"

Nana shook her head violently as if refusing, her long black hair swaying. Yuu's left hand had slid down to her enlarged clitoris and pinched it. Ignoring hair in his face, he simultaneously began small thrusts. Since Nana's body wasn't fully developed, he thought her clitoris would be more sensitive than her vagina. The simultaneous stimulation proved tremendously effective.

"Nana feels better this way, right?"  
"Iih, iih, no, good... aahn! Onii-hyan, pervert... hau! Me... aah! Inside... hau!"  
"I want... to cum with Nana"  
"Nnnn! U... iih! In! Ni, onii... hyan! T-together... ooooh..."  
"Aah! Nanaaa!"

While rubbing her clitoris with two fingers, Yuu continued small thrusts. Switching positions had helped, but once he started moving again, his urge to ejaculate surged rapidly. Still, Nana was more undone than during facing intercourse. She placed her hand over Yuu's right hand on her gently swelling chest, and touched his face with her other hand. Seeing Nana's ecstatic face turned back toward him, Yuu sealed her lips and tangled their tongues.

"Nchu... vu, vumyu... fan! Oh... nii... in!"  
"Chu, chupa, n~~~eroo... hafu, na, Nana... cumming..."  
"Aahn! Me... too... aah! Iih! Ihyuu"

Unable to hold back any longer, driven to release the hot surge inside him, Yuu thrust hard while stroking her clitoris.

"Oh... hyuu... ah... cumming... uun"

The moment semen gushed out, Nana's vision blurred as she shook violently. Stronger than when she'd been pleasured earlier with Sayori, intense ecstasy threatened to sweep away her consciousness.

"Hah... hahi... inside? Ahn... amazing... so muuuuch... ah... feeeeeee"

Despite being his third ejaculation that day, Yuu released copious semen into Nana's vagina. Finally reaching orgasm, Nana leaned back against Yuu with a floating consciousness and gently closed her eyes.  


### Chapter Translation Notes
- Translated "処女" as "virgin" and related terms explicitly per style guidelines
- Preserved Japanese honorifics (-kun, -san) and name order (e.g., Kawai Kiriko)
- Transliterated sound effects (e.g., "ぬちゃり" → "squelch", "ずんずん" → "zun zun")
- Used explicit anatomical terms: "penis", "vagina", "clitoris", "ejaculation"
- Maintained internal monologue formatting: *(C-close!)* → *italicized thoughts*
- Translated sexual acts literally: "フェラ" → "fellatio", "挿入" → "insertion/penetration"
- Preserved cultural terms: "King Game" (王様ゲーム) kept as is with capitalization
- Kept Japanese terms for family relations: "onii-san" (お兄さん) with contextual translation