## 233. New Student Council ⑧ ~Sudden Approach~

"Yuu-kun! Here you go"  
"Whoa, thanks. Emi's so thoughtful"  
"H-here, drink this too"  
"Haha. Thanks Mizuki too"

After ejaculating inside Nana, we decided to take a break.  
What Emi brought to Yuu sitting on the edge of the bed was a 350ml canned sports drink.  
Mizuki brought a small bottle of vitality tonic. Not the suspicious kind I drank at Saiei Academy before, but a famous brand with black and gold packaging seen on TV commercials.  
These things come in various grades, but what Mizuki held looked like something that would actually work.  

First, I gulped down the sports drink Emi handed me.  
Emi and Mizuki watched intently as Yuu's Adam's apple moved up and down when he tilted his head back.  
Men and women seem to have different points of arousal about opposite sexes' bodies - just watching the movement of an Adam's apple that girls don't have made both their hearts race.  

"Puhah"  

After chugging more than half in one go, Yuu returned the can to Emi and wiped his wet lips with the back of his hand.  

"Can I have some too?"  
"Huh? Sure"  
"Ehehe"  

Though they'd shared countless direct kisses, she seemed happy just to have an indirect kiss with Yuu.  
While Emi sipped slowly, Yuu took the small bottle of energy drink from Mizuki and opened it.  
A slight alcohol and medicinal smell hit his nose, but he endured and drank it.  
The amount wasn't much, so he finished it quickly.  
But as it went down his throat, his chest burned sharply while his head felt suddenly clear and sharp.  

"Kuhaa... feels like it's working"  
"Glad to hear! Yuu-kun still needs to work hard"  

If things went normally, Mizuki's turn would be after the next.  
Though knowing Yuu had extraordinary stamina, women still desired to have that mighty cock inserted and ejaculated inside them. Especially Mizuki, who hadn't known Yuu's cock long, had strong desires.  

Mizuki started licking the mouth of the empty bottle she'd been given.  
Doing such a thing right in front of him showed how much Mizuki had let her guard down around Yuu.  
Indeed, even when Yuu saw it, he didn't scold or pull away.  

While Yuu took time with Kiriko and Nana, two virgins, the remaining four were watching from a distance at first.  
Eventually, Emi and Mizuki got caught up in the mood and began kissing passionately while groping each other's bodies. Meanwhile, Yoshie and Sayori just fidgeted while watching.  

After mutually stimulating each other's genitals to orgasm, Emi and Mizuki next reached out to their juniors.  
Thus, Yoshie and Sayori lying limply before Yuu had apparently just been pleasured by their seniors.  
Since Yuu couldn't handle multiple partners simultaneously, it was convenient when girls got along.  
Having experienced seniors like Emi and Mizuki take charge was helpful.  

"Next... Sayori?"  
"Ah..."  

Sayori, who'd been sitting on the sofa by the wall, looked up at Yuu when her name was called.  

"Say, it might be strange to say this here, but aren't you uncomfortable with men... or rather sexual things?"  
"Eh...? N-no, not really"  

Seeing Sayori, a beautiful honor student resembling Riko, completely naked naturally aroused Yuu.  
But having given triple fellatio then had sex with two virgins gave him some mental leeway.  
Rather than going with the flow, he wanted to hear Sayori's true feelings.  

"I-it's not that I dislike boys. I just never thought about it before..."  
"I see"  
"I planned to live in this world without getting involved with men. That's all"  
"But you came to co-ed Sairei Academy"  
"Th-that's because Riko-nee was here"  
"Haha. I know"  

Realizing Yuu was teasing her, Sayori pouted slightly before standing up and coming right before Yuu.  
Without hiding her nakedness, she straightened her back and stared at Yuu.  
Yuu looked her over thoroughly from head to toe.  

Standing side by side, she was about 5cm taller than Yuu with a slender build.  
Though her breasts were modest, she had high hips and long, slender model legs.  
Her trademark was her straight, long black hair, now draped over one shoulder reaching her breasts.  
Her stomach had little fat, ribs slightly visible, but not unhealthily thin.  
Sayori's gaze also moved down from Yuu's face to his erect crotch, flushing her cheeks.  

"W-well, since we have this chance... I should properly get to know... no, get to know Yuu-kun who I'll be working with in student council for the next year"  
"Yeah. I want to know more about Sayori too. See various expressions, hear your voice"  

The moment Yuu said that while looking straight at her, Sayori's narrow eyes darted about as she covered her mouth.  

"Stop it... what is this feeling? I feel strange today"  
"You're really interested in Yuu-kun, aren't you? I understand, I was like that too"  

Yoshie, who'd come up behind her without notice, placed a hand on Sayori's shoulder.  

"See, it's Sayori's turn now. Get to know Yuu-kun well"  
"Yoshie... okay. Everything's an experience"  

Though they'd been formal with each other before coming here due to different classes, they'd apparently grown close enough to use first names naturally.  
Pushed by Yoshie, Sayori came right up to Yuu.  
Meanwhile, Emi and Mizuki stepped back.  

"First, let's kiss?"  
"U... un"  

Sayori bent down to match Yuu's seated position and brought her face close.  
Her hanging hair swayed, tips touching Yuu's chest.  
She might have remembered when Yuu gave her a devouring kiss when surrounded by six girls.  
Blushing, Sayori lightly placed her right hand on Yuu's shoulder and brought her closed lips close.  
Yuu stroked Sayori's cheek with his left hand, tilting his chin up as their lips lightly touched.  
She seemed about to pull away, but Yuu's hand went behind her head, keeping their lips firmly together as they continued kissing.  

"Nnffu... amu! Fa... nn~~~~~!"  

When Yuu inserted his tongue, Sayori opened her eyes in surprise but didn't resist.  
Rather, the intense mucous membrane contact made her fidget and bring her legs together, pressing closer.  
Yuu wrapped his right arm around Sayori's waist, straightened his spread legs, and had her sit on him while whispering between kisses.  

"Sayori, touch it"  
"Fa?"  

Yuu grabbed Sayori's left hand and guided it to his cock.  
Sayori flinched upon touching it, but only from surprise at the new sensation, soon starting to touch it obediently. The feel of her slender, supple fingers felt good.  

"I-it's hard... and hot"  
"Nn... be gentle, it's sensitive"  
"Fufu. Okay. Nn, chu, chu"  

At first she timidly touched just with fingertips.  
Gradually understanding, her touch changed to stroking with her open palm.  
Meanwhile, kissing continued.  
When Yuu inserted his tongue, Sayori accepted without resistance and entwined her own tongue.  
By then, Sayori's cheeks had turned pink and lustful breaths escaped.  

Meanwhile, Yuu also got excited having his cock touched by the top academic of their grade while deep kissing.  
Sayori seemed focused on touching his cock, leaving the kissing passive.  
So Yuu greedily explored her mouth. Simultaneously stroking her hair from head to back with his left hand, his right palm cupped and kneaded her breast.  

"Nmo, fo! A, o... nkuu, julu, jureru... amu... chup... nn, lero, lero, lero... nfa"  

When their lips parted, a string of saliva stretched between their tongues.  
After several minutes of enjoying oral pleasure, Sayori's expression looked completely flushed.  

"Hey, can I see your cock up close?"  

Sayori's eyes behind her glasses were moist. No reason to refuse.  
It made him happy that she, who seemed so proper, was getting interested in his cock.  
After another chu kiss, Yuu smiled and replied.  

"Sure. Try sucking it too"  
"Un"  

Rising from his lap, Sayori knelt between Yuu's spread legs.  
While slowly stroking the cock with her right hand as before, she brought her nose close and sniffed.  

"Uun. Unique smell. Strangely raw, animalistic... a lewd smell"  
"Fufu. It's mixed with two people's love juices and semen"  
"I see... mixed male and female secretions. And... seeing this shape and texture in person is completely different from what I knew"  

Sayori carefully examined it from all angles.  
She'd seen diagrams in health class, and girls interested in sex might obtain erotic books or videos.  
But Sayori had lived prioritizing studies without such interests, so seeing such a vivid cock aroused curiosity more than excitement.  

"Now try licking it. See, you touching me made me feel good, and precum came out"  
"Eh? Does it feel good?"  
"Un. Sayori's hand is soft and feels good"  
"R-really?"  

Seeming embarrassed by Yuu's words, Sayori lowered her long eyelashes without meeting his eyes and kissed the glans.  
Without hesitation, she opened her lips and took it in.  

"Uge... bitter"  
"Ooh! Good... feels really good..."  

Sayori frowned after tasting precum.  
But for Yuu, the moment the tip entered a girl's soft, wet lips brought heavenly pleasure.  
Perhaps encouraged by Yuu happily stroking her hair, Sayori began sucking using her tongue without removing her mouth.  

"Nn, nn, haamu... lerochu, chupa... nnn!? Ua... ahi! Hyame... nmo... kufu... a, aaaaaaaaaa! Shoko, yaa!"  

Being her first time, her technique was naturally clumsy.  
But Sayori carefully caressed while checking with Yuu about what she didn't know.  
That showed her serious personality, and Yuu honestly praised her for feeling good and being a quick learner while gently stroking.  
Then Sayori, though embarrassed, eagerly sucked.  

This heartwarming exchange lasted about 5-6 minutes.  
Approaching from behind were the bored Yoshie and the revived Nana.  
The two began playing with Sayori's private parts, immediately breaking her focus on fellatio.  

"Look. She's this wet"  
"Un un. Sucking Yuu-kun's cock makes everyone wet"  
"Even though she acted like 'I'm not interested in men', I'm relieved Sayori's normally pervy too"  
"Hi, hau! Hyame!"  
"President Yuu-kun's charm is truly great"  

Sayori moaned as her clitoris and vaginal opening were freely played with.  
Yet she clung to Yuu, sometimes removing her mouth but continuing fellatio with her tongue out - quite impressive.  
Feeling affection for Sayori desperately sucking while also getting aroused, Yuu placed both hands on her cheeks.  

"I can't hold back anymore. I want to connect with Sayori"  

Sayori's expression showed relief, embarrassment, and being overwhelmed by lust.  
With moist lips slightly parted, she replied "Me too" - looking more erotic and cute than ever.  

"Are you sure about that position?"  
"I'm not that knowledgeable but... women riding men is standard, right? Basics are important. Yuu-kun's too eager for a boy. Just lie back honestly"  

With Yuu lying on his back in bed center, Sayori straddled him.  
Indeed, Yuu had taken initiative with Kiriko and Nana too.  
Having Sayori ride and move would help since he still had four more partners, but he felt uneasy whether she could manage being inexperienced and lacking sexual knowledge.  
But since she didn't seem likely to back down once decided, he let her do as she wished.  

"Like this? Nn... okay. I'm putting it in?"  
"Okay"  

Leaning forward slightly, Sayori guided the cock to her vagina with one hand.  

"Nn... bigger than expected... oggii!? Na... nn... ii! I, itaaaaaaai!"  

As Sayori adjusted the angle and lowered her hips, Yuu felt something soft tear.  
Like Nana, Sayori was a genuine virgin with her hymen intact.  
She trembled in pain with less than half inserted.  

"Sayori?"  
"O...okay. I'll continue... uu"  
"Don't force yourself"  
"Th...this much"  

Even now she seemed stubborn or proud.  
Sweat beading on her face, Sayori completed insertion.  
That was fine, but she seemed to lose strength and started falling forward.  
Yuu caught her upper body.  
Brushing aside the long hair that fell over them, he said:  

"You did well. Leave it to me"  
"Ah, sorr... nnn!? Wait!"  

Yuu started sitting up while holding Sayori.  
Unlike with Nana earlier, he stopped using abdominal muscles before fully upright, placing a pillow behind his lower back.  
An angle like riding position meets missionary.  

Sayori, still clinging to Yuu, blushed shyly and pulled back slightly.  
Being taller, she looked down at Yuu.  
Her long hair hung forward again since she'd been leaning.  
Yuu took it in hand and said:  

"Sayori's hair is truly beautiful"  
"R-really?"  

As a woman, she couldn't not be happy to be called beautiful.  
It distracted from the awkwardness of showing such an embarrassing posture after struggling to insert it despite the pain.  
Yuu's hand playing with her hair reached her cheek.  
Sayori grabbed that hand, brought her face close, and kissed him.  

"S-sex is... quite tough, huh"  
"You'll get used to it. Now let's move together?"  
"Eh? U, uun"  
"Still hurts? You don't have to force it"  
"I-I'm fine! If... if it's together..."  

Having Yuu lead completely might hurt her pride.  
Sex isn't done with just one person's feelings.  
Both feeling good together is obviously better.  
Sayori smiled and nodded at Yuu's words.  

"Ha, ha, haa... nn, ku... nnn! Nn~~~~~~~ aan!"  
"Feeling good?"  
"Nn... good... un! Feels... good... maybe... a, ann! Ann! Yu, Yuu-kun!"  

At first their timing didn't match, frustrating them.  
But experienced Yuu matched Sayori's hip movements.  
The time spent trial-and-error proved good as their movements synchronized, connecting deeply.  
Then love juices acted as lubricant, making movements smoother with loud squelching sounds and Sayori's lustful moans.  

Not rough.  
Just shallow thrusts while hitting deep inside.  
But that was good.  
With long hair disheveled, sweat glistening on soft skin, cheeks pink, Sayori seemed completely aroused, forgetting the pain of losing her virginity.  

Meanwhile, Yuu was losing composure too.  
After all, it was a virgin pussy freshly accepting a man's cock.  
Its tightness and grip matched Kiriko's and Nana's.  
Physically narrower than Kiriko's, yet feeling deeper penetration than petite Nana's.  
So even after three ejaculations, being deeply connected now brought strong pleasure to Yuu with each movement.  

"Sa, Sayori! I'm... almost! Guh!"  
"Hya... a! Yan! Yuu... kun!"  

Until then they'd moved slowly in sync, but as ejaculation neared, Yuu changed to thrusts that gouged deep inside.  
Sayori, who'd been grabbing Yuu's shoulders, clung tightly.  

"Cumming... Cumming, Sayori!"  
"! Un, un! Good... yo... fuwaaaa! Rani? Shu, shugoi! Hyin! A, ahi, ya, kuu... Yuu... ku... shugoi no... aaa!"  

As Yuu entered his final spurt, Sayori could only cling tightly while letting out wordless moans.  

"Guh... o... I'm cumming! Aa!"  
"Ha... hi... uwa... a... aaaaaaaaaaaaaaahhhhhh!"  

As Yuu released semen into Sayori's womb, her consciousness felt shaken by an unprecedented wave of sensation.  
Pleasure signals spread instantly from their connection beyond control.  
Simultaneous with receiving ejaculation, climax made her scream continuously.  


### Chapter Translation Notes
- Translated "我慢汁" as "precum" to maintain explicit terminology
- Preserved Japanese honorifics (-kun, -chan) throughout dialogue
- Translated "膣内" as "pussy" for anatomical accuracy per style rules
- Used "cowgirl position" for "女が男に乗る" sexual position description
- Transliterated sound effects (e.g., "guchu guchu" for ぐっちゅぐっちゅ)
- Maintained original name order (Hanmura Sayori) for Japanese characters
- Translated internal monologues in italics (e.g., *This is concerning*)
- Explicitly rendered sexual acts without euphemisms (e.g., "ejaculating inside")