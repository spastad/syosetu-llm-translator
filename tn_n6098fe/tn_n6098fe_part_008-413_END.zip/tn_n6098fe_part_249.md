## 234. New Student Council ⑨ ~Walking Together~

"Aah, ahh, haaah...nnn! Nnnnnnnnn! Aaah, no...more...I'm cumming again... Yu, Yuu-kun, Yuu-kuuun! Iiiiiiiiiiiii... can't... take it... I can't hold back from cumming... Aaah!"

"It's fine. Cum as many times as you want. Yoshie's yoga-toned face and voice are so sexy and wonderful."

"Haun! Yuu-kun's... cock... deep inside... thrusting deeper... feels too good... ahhaa... already... impossible... Aaahn! Cumming, cumming cumming cumming! Aaaaaaaaahhhhhhhhhhh!"

Yoshie, straddling Yuu and desperately rocking her hips, arched her back as she let out a long moan, reaching what must have been her umpteenth climax of the day. Her long black hair, tied in a half-up style, swayed as she lifted her chin, and the arms supporting her upper body trembled violently.

Thanks to Yoshie squirting multiple times, the area around Yuu's crotch was thoroughly soaked. Lost in her climax, Yoshie's eyes glazed over completely as she licked her drool-slicked lips with a single swipe of her tongue. The sex with Yuu after two months seemed so magnificent it made the serious class representative abandon all pretense of dignity. She had transformed into a female greedily craving semen right before his eyes.

With a lewd smile spreading across her face, Yoshie firmly grabbed Yuu's sides with both hands and began slowly rocking her hips back and forth.

Truth be told, Yuu couldn't see Yoshie very well. Emi and Mizuki, both extremely aroused, took turns kissing him, constantly blocking his view.

"Nchu, chu, chupaa... slurp. Aahn, Yuu-kun, I love you. More, kiss me?"  
"Amu, lero lerooo... chupon. Haa, haa, Yuu-kun's nipple... delicious"

Currently, Emi was greedily entwining her tongue with Yuu's inside his mouth. Mizuki continued caressing Yuu's nipple with her fingers and tongue from the side. Meanwhile, Yuu had his right finger inside Emi's vagina while his left hand kneaded Mizuki's heavy breast from below.

Kiriko, Nana, and Sayori were being treated to one-on-one sessions since it was their first time. The remaining three, being experienced, were handled together.

First was Yoshie, who hadn't been with him in a while. After mounting him herself, she started rocking her hips with tears of joy and came almost immediately. During this, Emi and Mizuki freely used his upper body. Essentially treated like a living dildo, Yuu was perfectly satisfied with this arrangement.

After letting Yoshie move as she pleased for a while, Yuu could no longer hold back.

"Aaaaahhhh... this too... feels so goooood... ufunn... Yu...u...kuun, I love you. Your cock... more"

Perhaps because she'd been too enthusiastic from the start, Yoshie panted roughly as she grabbed Yuu's sides and shifted to slower movements. Despite the leisurely strokes, she seemed to be savoring Yuu's cock thoroughly with her vagina. Each time Yoshie sensuously moved her hips, lewd wet sounds of "pachun, pachun" could be heard.

"Yoshie, I'm about to cum too."  
"Haun... your cock... feels too good... ann, ann, ann! My hips... won't stop ooooooh!"

Yuu tried telling her when Emi momentarily broke their kiss, but Yoshie didn't seem to hear. So Yuu decided to thrust upward on his own.

"Hyaun! Nya, nya... Yu...u...kun! Aaah! So... strong! Iiinn! Nooo... stop! Foh! Ooh!"  
"It's fine. Let's... cum together?"  
"Uwaa... aa, aa, aa... so intense... hii...kuu... together... cummingggggggg"  
"That's it!"

After Sayaka, Riko, and Emi, if pregnancies were to become known at school, it would likely be Yoko, Kazumi, or someone from Class 1-5 including Yoshie. If so, Yuu definitely wanted to impregnate Yoshie among the new student council members too. With that thought, Yuu continued thrusting upward to release his seed.

***

"Really, Yuu-kun went too hard too."  
"Ahaha..."  
"Mufufuu. But feeling the heat and hardness of your cock like this is nice too. Like with Emi, it feels good..."

After ejaculating inside Yoshie, even Yuu felt tired and took a break to hydrate. He recalled reading somewhere that the hip movements during sex were similar to sprinting at full speed. Even in an air-conditioned room while naked, skin-to-skin contact made them drenched in sweat. And since he'd been taking turns with multiple partners, regular hydration was necessary. With Emi and Mizuki clinging to him nonstop now that it was finally their turn, he moistened his throat with the drink Kiriko brought.

Yuu currently sat with legs spread, hands stretched back for support. Emi and Mizuki sat facing each other over Yuu's crotch area, legs crossed. In other words, their vulvas were sandwiching his cock.

They'd been trying various multiple-play patterns Yuu had only seen in eroge before. Double handjobs, double paizuri, having girls lie stacked left-right or top-bottom for alternating penetration. Situations impossible in his previous life, like having two girls sandwich his cock between their pussies - things Yuu wanted to try precisely because he could now.

"Ooh... Emi and Mizuki's pussies, being sandwiched by both feels amazing."  
"Nn, nn, haa... Indeed, this feels good too... ann! Hitting my clit."  
"Uuun... moving myself feels even better. Yuu-kun's... cock... wonderful."

Having his cock sandwiched between thighs for genital rubbing - sukumata - was good on its own. But being sandwiched left and right by two pairs of thoroughly soaked, soft vulvas was exceptional. With every small movement of their three genitals touching, lewd wet sounds of "nuccha, nuccha" played. Double sukumata didn't provide enough stimulation for immediate ejaculation, but watching Emi and Mizuki rub their genitals together while sandwiching his cock was incredibly erotic and made him happy.

After savoring this awhile, Mizuki was the one who couldn't hold back. Her face flushed, breathing roughly as she stared at Yuu's cock.

"Haa, haa, happun... Yuu-kun... Yuu-kun, Yuu-kun, Yuuu-kun! Aahn! Your cock... I love it."

Their love juices already drenched his cock, but Mizuki's especially produced sticky "nuppu nuppu" sounds.

"It's fine. Mii-chan can go first with Yuu-kun."  
"Feh... Eh, Emi, I'm happy you say that... but..."

Though Mizuki's eyes were glazed over, they widened at Emi's smiling words. Emi leaned closer to Mizuki and whispered.

"I want Mii-chan to get pregnant with Yuu-kun's seed."  
"Ah..."  
"You might get mad hearing this, but now I'm glad Mii-chan didn't get pregnant. Because now we can continue student council together while trying for a baby, right?"  
"Emi... I wouldn't get mad at that. Now I think so too. Yuu-kun's seed is reliable. After all, he's already impregnated three people."

Actually, it was far more than three, but Yuu read the room and stayed silent. If Mizuki had gotten pregnant by Ohyama-senpai, she'd be in her final month by now, maybe even given birth. Between childbirth and childcare, she wouldn't have joined student council. Since she likely wouldn't have used contraception, it was coincidence she didn't conceive. Thinking that, perhaps fate meant for Mizuki to do student council with Yuu and Emi. Then Yuu wanted to impregnate Mizuki with his seed. But Yuu also didn't want to neglect Emi, who'd been so considerate today.

"Then let's do it together, all three of us!"  
"Yuu-kun?"  
"Unn! Let's do it!"

***

Yuu chose to have them lie down for alternating penetration. He'd done the pattern with one supine and the other on all fours several times before. What he asked of Emi and Mizuki was to lie sideways embracing each other closely. From Yuu's position behind them, Emi was on the right, Mizuki on the left. Each held one leg high up by the toes. Only flexible girls could manage this wide split - the yoga pose Anantasana (sideways leg raise). Yuu's view showed both their vaginal openings gaping wide, revealing their salmon-pink interiors. Both were so wet their twitching insides seemed to beg for his cock.

"Eh... Emi."  
"Fufu, Mii-chan's so cute. Chu, chu, churuu... lero."

Before Yuu could bring his erect cock closer, the embracing pair started passionately kissing. Emi around 160cm, Mizuki in the low 150s - the minimal height difference made it perfect. Though the upward angle of Yuu's cock made penetration awkward for this position, it wasn't impossible. First, he hooked Mizuki's left leg over his shoulder. Yuu leaned forward.

"Starting with Mizuki."  
"Nn, nfoh... jurepa! Afuun... furee? Yuu...kuun? Aha! Your cock!"

Almost forgotten by Mizuki who was engrossed in kissing Emi, Yuu smiled wryly as he adjusted the angle for penetration.

"Ooh, ug!"  
"Aaahn! Yuu...kun is... coming inside!"

The moment the tip touched her entrance, it made a sticky "nupori" sound. Without even thrusting forward, the glans was swallowed as if sucked in. But before halfway in, her vaginal walls tightly clenched around him with a "michi michi" sound. Despite having ejaculated four times already, a tingling pleasure shot through him. Embracing both their backs with his hands, Yuu endured the pleasure and continued penetration.

***

"Ooh... this is pretty good too... How is it? Mizuki."  
"Aha, Mii-chan, you're about to cum, right?"  
"Hahi, hahii... aaah... hin! So strong! Cumming... aaah, cumming hyaaaaaaaauuuuuuuu!"

While Yuu enjoyed the different angle of stimulation, Mizuki reached her first climax in under three minutes. Having squirted early, his crotch area was soaked again.

Pulling his hips back to withdraw, Yuu inserted into Emi. Like with Mizuki, it went in smoothly at first but soon tightened around his cock with a "kyuu kyuu" grip. Since Emi was pregnant, instead of hard thrusts against her cervix, Yuu tried small circular motions.

"Faaaaaaaaah! Ah, ah, aah! Yuu-kun, Yuu-kuuun! That... feels so goood."  
"Sorry, Emi. You were so considerate today, but you ended up last."  
"Uun. It's fine... ann! Just hearing Yuu-kun... say that... aahn! Right... there... being connected with Yuu-kun like this... makes me happy..."  
"Gu... Inside Emi feels so good."  
"Ha, ha, haan! Yu, Yuu-kun!"

Emi looked up at Yuu by twisting her neck sideways. Finding her adorable, Yuu tried bringing his face closer but the position made it difficult. After lowering Mizuki's leg from his shoulder, he somewhat wedged himself between them to kiss Emi.

Alternating between them like this, when he finally finished inside Mizuki, even Yuu felt fatigue and collapsed between them. Taking time to ejaculate while handling both had taken its toll.

***

"Feels like something's still inside me~"  
"I get it. I felt that way my first time too."  
"Yuu-kun's cock... is big after all."  
"It hurt at first, but once used to it, it felt so good I couldn't stop."  
"At the end, my head went po-waan, couldn't think at all."  
"Anyway, way better than masturbating!"  
"Right!"

Now gathered around Yuu who sat propped against bed pillows, the girls were deep in girl talk. Facing Yuu with Emi between them were second-years Kiriko and Mizuki. Pressed tightly against Yuu's right arm was Nana. Opposite her was Yoshie, positioned diagonally behind Yuu next to Sayori. Of course, everyone was still naked.

Yuu kissed each in turn, enjoying skin contact by stroking hair and kneading breasts between kisses. Naturally, the girls surrounding Yuu touched his skin too, but especially Kiriko and Nana who'd just lost their virginity were enthusiastic. Even Sayori was no exception, timidly reaching out to cling to Yuu's back.

"As much as I hate for this to end, it's about time we need to head back, right?"

Though they'd lost track of time in their absorption, Yuu recalled it must be getting late.

"Umm... No way!? It's already past 6 PM!"  
"Eeeeh!?"

Everyone gasped at Sayori's voice as she checked the bedside clock. Outside, the sun had likely set, but being underground with no windows, they hadn't noticed.

"No time for a shower."  
"But let's at least wipe our bodies."  
"Right."

Yuu had arranged for Komatsu family's car to take him and Emi home as usual. Though they'd informed about staying late unlike regular Saturdays, it was still awkward. Using the provided towels, they hurriedly began wiping down.

***

Thirty minutes later. After everyone changed clothes, Yuu stood before the six girls, making eye contact with each in turn.

"As the new student council, I believe we deepened our bonds today."  
"Ufufu, indeed."  
"Isn't this what they call 'naked camaraderie'?"  
"Ahaha, exactly. So, I hope we'll work well together this coming year. Let's do our best."  
"Unn! Let's work even harder than Saya-senpai and Riko-senpai's term!" said Emi.  
"For Yuu-kun who scouted someone like me, I'll devote my everything!" said Mizuki.  
"I-I too... will do my utmost for Yuu-kun and the school!" said Kiriko.  
"Being with Yuu-kun in student council feels like a dream... Um, I'll work hard to be of some help," said Yoshie.  
"For onii-chan, I'll do anything," said Nana.  
"With this team, I want to create activities that will go down in Sairei Academy's history," said Sayori.

Thus began the activities of the new student council with Yuu as president.

***

---

### Author's Afterword

This concludes Chapter 6 (main story).

After one interlude chapter, Chapter 7 depicting Yuu as student council president will begin.

### Chapter Translation Notes
- Translated "ヨガっている" as "yoga-toned" to convey physical conditioning nuance
- Preserved Japanese honorifics (-kun, -chan) and name usage as per original text
- Translated "肉棒人形" literally as "living dildo" to maintain explicit tone
- Rendered sexual sounds phonetically (e.g., "ぬぽり" → "nupori", "ぱちゅん" → "pachun")
- Translated "アナンターサナ" as "Anantasana" with explanatory note in parentheses
- Maintained explicit anatomical terms ("cock", "pussy", "clit") per translation style rules
- Used ""..."" formatting for simultaneous dialogue by multiple characters