## Interlude 8: Refuge Life

### Author's Preface

(Interlude 8) provides a quick recap of characters who haven't appeared for a while.

  

Kate Grimwood (1st year high school) 

Her mother is Jane Grimwood from America. Since March, they haven't gotten along and barely speak.

Despite being the youngest, she was elevated to leader of the Saiou Red Scorpions. Attends Saiei Academy. Was scouted by student council president Mitsuse Rinne and became a student council member, so she's met Yuu multiple times.

Incidentally, during her first meeting with Yuu, she introduced herself as Kurimori Keiko for some reason.

  

Ryouko (2nd year high school) Typical delinquent girl. Famed throughout the neighborhood for her exceptional fighting skills. ※Repeated a year so she's the oldest in the team

Misa (2nd year high school) More gal-style than delinquent. Characterized by loose, tea-colored permed hair.

Mari (1st year high school) Judo practitioner with sturdy build. Black permed hair.

Ginko (1st year high school) Karate practitioner and tall. Always wears an X-pattern mask. Tea-colored long hair.

  

※For details, see chapters 45-49

  

---

  

The motorcycle turned left onto the single-lane prefectural road, slowing down as it entered a narrow roadway without a center line.

Eventually, it entered a desolate street devoid of vitality, then the engine cut off as the rider pushed the bike into an alleyway.

  

A young woman around the late 160cm range, clad in faded denim jacket and pants.

Though not particularly tall, she pushed the heavy 400cc-class bike effortlessly, her trained movements showing no instability in her core.

She'd removed her half-cap helmet, letting her bleached, bright tea-colored long hair flutter in the wind.

Beneath her open denim jacket was a pure white T-shirt. Her breasts asserted themselves at a pleasing size, her legs were long, and the upward curve of her buttocks was splendid.

In other words, even through her clothes, one could tell she had an exceptional figure.

Vibrant red rouge and purple eyeshadow stood out. Though her makeup was heavy, she likely wasn't over 20.

  

This might have been a somewhat prosperous town in the past.

But now, shutters were down over most visible shops.

Graffiti from spray paint stood out everywhere.

Abandoned, broken scooters and bicycles littered the roadside.

It was twilight, the sun beginning to set. Combined with the many visibly grimy buildings, the rundown alley felt dimly lit.

It seemed completely devoid of people, but shadowy figures exhaling cigarette smoke from inconspicuous spots watched the walking woman with suspicious eyes.

To locals, this wasn't exactly a safe neighborhood.

  

If this were the world Yuu knew?

A young woman walking alone here might be attacked by unsavory men.

But in this world, due to the extreme reduction of males and reversed chastity norms, it was men who couldn't walk alone.

Thus, the woman walked without any fear.

Though, if any troublemakers appeared, they'd likely just get beaten back anyway.

  

The woman pushing her bike entered a vacant lot gaping between buildings.

It seemed to have once been a paved parking lot, but long neglected, cracked everywhere with weeds running rampant.

In one corner sat a bike-shaped object completely covered by a gray tarp.

After pushing her beloved bike next to it and putting down the kickstand, she untied the rubber cord fastened to the rear seat and grabbed her sports bag, then entered the mixed-use building through a service entrance nearby.

  

"Hey, Leader! Been a week. You doing okay?"

"Hmm? Ryouko! You came! Welcome."

  

Ryouko had come to a defunct café tucked away on the first floor.

The door had the café's nameplate painted over garishly with unique characters dancing across it.

Using her spare key, Ryouko entered the dark interior without hesitation and opened the inner door. It seemed to have been an office, about six tatami mats in size.

At the desk right inside sat Kate Grimwood, leader of their team, the Red Scorpions, reading something.

She wore red athletic wear, her long blonde hair casually tied back.

  

Half-used as storage before, it had been buried in junk, but now was considerably tidied.

The back had several beer crates laid flat with a mat over them, apparently serving as a makeshift bed.

Stacked nearby were secondhand comics brought by friends. Some porn magazines had been mixed in, but whether discarded or hidden, they weren't visible.

Behind the chair Kate sat in, textbooks and reference books for high school were piled on the desk.

Meals could be prepared using gas and water in the kitchen behind the café counter, with plenty of seating available, so she likely used that.

In other words, Kate had been living here for a while.

  

"Here. This."

"Mm, thanks as always."

  

Ryouko took items from the sports bag she'd brought and arranged them in the empty space.

Cup noodles, snacks, weekly magazines and comics for killing time.

Among them was an adult comic with a cover illustration of a scantily clad boy in a lewd pose. Kate gave it a sullen look, but Ryouko averted her eyes with an innocent expression.

  

"Huh? What were you reading?"

  

Ryouko's eyes happened to land on the job-hunting magazine Kate had been reading earlier.

  

"Ah, well... Apparently this place is getting demolished by year's end... So I'm looking for a live-in part-time job. Might switch to night school too."

"Meaning... you might move far away?"

"Hmm. That's a possibility."

"No way..."

  

Originally, this mixed-use building belonged to a relative of an early Red Scorpions member who also ran the café.

The member in question started helping at the café after high school graduation and took over the business years later.

Thanks to that connection, they'd been allowed to use it as a hangout for generations.

Even now, after the café owner fell ill and quit, and most tenants left the aging building, it continued.

Kate started living here after leaving home at the end of August—about a month now.

All of it was because of her mother, Jane.

  

The incident from August 25-26, where an extreme-left organization attacked a foundation building and abducted a teenage boy, imprisoning him overnight, drew public attention.

The next morning, foundation personnel and the boy's contracted protection officers located the confinement site and successfully rescued him.

Police announced the victim showed no physical or mental abnormalities and was unharmed.

  

What stirred society was the revelation that the extreme-left organization received funding from the Dankyo Party through a paper company.

As investigations progressed, it emerged that the Dankyo Party had several unofficial subgroups, some involved in criminal activities.

While no lawmakers were directly implicated, some secretaries and office staff were asked to voluntarily accompany police as key witnesses, leading to the party being seen as a criminal group, intensifying media scrutiny.

  

Listed as representative director of the paper company central to the funding network was Jane Grimwood from America. She was suspected of fraud, document forgery, securities forgery, and aiding numerous crimes.

However, before police investigation reached her, she disappeared and remains wanted.

  

As her daughter and only family in Japan—relatives in America hadn't contacted her in nearly 20 years—Kate underwent repeated police questioning.

But since a certain day in March, relations with her mother soured, escalating to physical fights, and they barely spoke.

Though Jane was often away for work, Kate avoided home so much she rarely stayed there.

  

She attended high school seriously—Saiei Academy—where she'd enrolled.

Somehow, the student council president took a liking to her and forcibly recruited her to help with student council work.

After school, trying to minimize time at home, she wandered the streets when she encountered Mari and Ginko.

She stumbled upon them being harassed by a group of over ten delinquents just as a fight was about to start and intervened, becoming friends.

Later, Kate joined the Red Scorpions without really understanding why and was even elevated to leader.

A happy miscalculation for Kate was being able to hang out at the team's hideout. It helped reduce her time at home.

  

So no matter how persistently questioned, Kate couldn't possibly know what her mother was doing or where she went.

Police questioning was one thing, but media onslaught and countless harassments after her home was shown on TV became unbearable.

  

Cold stares and sarcasm from neighbors were still tolerable, but the incessant silent or abusive calls (she soon yanked the phone line out).

It escalated to people making noise outside her house at night, throwing stones and filth inside.

Hearing multiple motorcycle sounds, she thought members of rival gangs opposing the Red Scorpions had joined in.

  

At this point, unable to stay home, Kate got her teammates' permission to live in the café's office—their hideout—as refuge.

When leaving, she took all cash and valuables from home besides personal items.

She hadn't attended school since the second term started and avoided going out except at night to stay unseen.

  

"Terrible, huh. Even though you're family, Leader, you had nothing to do with it."  
"Families of perpetrators—that's how it is. Especially when the main culprit escapes and isn't caught."

  

If minors committed crimes and parents were blamed, that would be understandable. But for a child to be driven from school and home over a parent's crime was excessive.

Ryouko fumed, but Kate murmured resignedly.

  

"But still—"  
"More importantly, tell me about the others. How are Misa and Mari doing?"  
"Ah... yeah. Not bad. They're fine."  
"Good to hear. Haven't seen them in a while. Was worried."  
"Misa's morning sickness hasn't settled, but she says she's used to it now. Mari's appetite increased, and she's worried about gaining weight. But the doctor says everything's progressing well."  
"I see. Hehe. Too bad for you and Ginko, though."  
"W-well... I-I'm fine. Two out of four getting pregnant is pretty good. That guy..."

  

Ryouko blushed suddenly, perhaps recalling when she lost her virginity to Yuu about four months ago.

Usually, her sharp glare made her intimidating delinquent act convincing, but only when Yuu came up did she show a completely different girlish side, making Kate want to tease her.

  

"I see... I don't really get it, but if they're both healthy, that's reassuring. Just need them to deliver healthy babies."  
"Hey..."  
"What?"

  

She seemed to want to say something but hesitated.

Unusual for Ryouko, Kate thought.

  

"Think we should... tell Yuu?"  
"...! Dunno... Can't say for sure."  
"Okay."

  

Getting pregnant from just one sexual encounter.

While rare in this world's common sense, it wasn't impossible.

But whether the pregnant woman sought acknowledgment from the man depended on their prior relationship.

In that sense, the Red Scorpions' five members and Yuu met by chance.

Objectively, it could look like delinquent girls forcing themselves on a male high schooler.

So they kept Yuu a secret among themselves.

  

"Actually..."  
"What?"  
"You wanna see Yuu too, don't you?"  
"Huh!?"

  

Ryouko had said it half-teasingly, but Kate's face turned bright red, showing extreme agitation.

Ryouko was surprised too—first time seeing the leader like this.

  

"Heeey~~~. Leader's full of surprises. Maybe we could arrange something with Yuu, tell him about Misa and the others, and invite him here. You know, since you were left out last time."

  

*Dun!* Kate stood up with a loud noise.

  

"You know what happens if you say more, right?"  
"Uh..."

  

Veins bulging on her forehead, Kate glared with narrowed blue eyes, bringing her face close to Ryouko's.

Her well-defined features made Kate's angry expression genuinely terrifying—even Ryouko cowered.

Desperate to change the subject, she couldn't think of a good topic.

  

"Speaking of Sairei, they're having student council elections, and apparently Yuu's decided to be the next president. Heard from Ginko who came recently."  
"Huh?"

  

Unexpectedly, Kate herself brought up Yuu.

Her anger seemed performative—not serious.

  

"How does Ginko know?"  
"She has a senior friend who's a clerk there, and that senior heard it directly from Yuu."  
"President!? A guy!? Unbelievable."  
"Really? Why?"  
"Well, obviously."

  

To Ryouko, Kate seemed mature beyond her years—calm and smart—but occasionally lacked common sense.

  

"First off, coed schools are rare, so I don't know much, but everywhere—schools included—it's all women. Why would a guy put himself in the spotlight? He'd get targeted."  
"Ah, that. Right."

  

Kate nodded repeatedly as if realizing it made sense.

  

"But Yuu was part of Sairei's student council, so maybe that's why."  
"Actually, Leader, you know a lot about Yuu—"

  

Ryouko almost said it but stopped herself.

  

"Come to think of it, Sairei's student council president was pretty famous. Must be tough succeeding her.  
Like, the president or chairman of Komatsu—who made the bike I ride—her granddaughter or something?"  
"Huh?"  
"Komatsu... what was it... Saya? Sayo?"  
"Komatsu Sayaka, maybe?"  
"Yeah! Huh? You know her, Ryouko?"  
"Ah, yeah. From middle school days. More importantly—"

  

Scratching her cheek, Ryouko averted her eyes when Kate asked.

For Ryouko, that person had more than a little history.

Hearing she was Sairei Academy's student council president gave her an idea, but she couldn't mention it here and switched topics.

  

  

  

After two hours of chatting over dinner, Ryouko decided to leave.

She made sure to emphasize: "If you decide to move, definitely tell me."

Despite being younger, Kate had fulfilled her role as team leader admirably.

Whether moving nearby or out of prefecture, Ryouko strongly wanted to gather all members for a farewell party.

  

With already few members, team activities had been suspended since two pregnancies were confirmed.

Most importantly, because leader Kate was being pursued by media.

So seeing trusted teammates was limited to about twice a week.

Otherwise, Kate spent time alone—a life she'd finally grown accustomed to.

  

"Yuu, huh... Well, maybe I wouldn't mind meeting and talking.  
N-not in a weird way... just, killing time... yeah, just killing time."

  

Recalling the boy whose name came up with Ryouko.

They'd met when Yuu coincidentally visited this café, during Sairei student council meetings, and last at Saiei Academy when invited.

Though she'd kindly given him a motorcycle ride, he suddenly groped her chest, startling Kate into elbowing him.

So when they reunited at Sairei Academy, she was wary, but each meeting made conversation easier.

Maybe influenced by that, when invited to Saiei Academy, sensing the student council executives' scheme, she passed him a warning note. She never learned the outcome.

But since that day, the student council changed completely—was Yuu involved?

Having quit the student council without attending school, Kate didn't know.

  

She wasn't sure if she could call him a friend, but to Kate, he was her only male acquaintance.

Hearing "Hirose Yuu" inevitably made her recall another person from her memories.

  

*(So maybe that's why I'm conscious of him? Me, of a guy? Ah, enough!)*

  

Kate shook her head *buruburu*, then opened the job-hunting magazine she'd been reading before Ryouko came and began studying it intently.

  

  

  

---

### Author's Afterword

This concludes Chapter 6.

This Saturday's update will be skipped, with the next update in one week.

During this time, I'll update the character list.

Chapter 7 will focus on Yuu's daily life as student council president.  


### Chapter Translation Notes
- Translated "避難生活" as "Refuge Life" to convey temporary displacement under duress
- Preserved Japanese nicknames (Ryouko, Misa, Mari, Ginko) as used in original text
- Translated "折り合いが悪い" as "haven't gotten along" to capture relationship deterioration
- Rendered "身籠もった" as "getting pregnant" per explicit terminology rule
- Transliterated sound effects: "ぶるぶる" → *buruburu* (head shaking)
- Maintained original name order for Japanese characters (e.g., Komatsu Sayaka)
- Translated "男共党" as "Dankyo Party" per Fixed Special Terms
- Used "Saiou Red Scorpions" consistently per Fixed Special Terms
- Preserved cultural terms like "喫茶店" as "café" without localization
- Translated internal monologues with asterisks: *(...)* format