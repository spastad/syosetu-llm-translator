## 238. Repercussions ① ~DEPARTURES~

For weekly magazines, the quickest way to boost sales is to feature articles about men.  
Therefore, every issue inevitably includes the names of male celebrities - from trendy idols and actors that appeal to women, to older and younger male entertainers.  

They put effort into features spotlighting fresh idols and models, and sometimes create articles by painstakingly gathering information from unspecified groups of men, like "We asked 50 men in their 20s! What type of woman would they want as a wife?"  

Just having substantial male-related content can sway sales, so producers pour energy into these features.  

Conversely, if the content consists of nothing but fabrications and speculation despite flashy headlines, they immediately face fierce criticism, and sales can plummet in the next issue.  

So, what kind of reaction would occur if a complete amateur - moreover, a minor - appeared in a weekly magazine with their real name and photo?  

Not an entertainer who recognizes that appearing on TV and being chased by fans is part of their job, but an ordinary person.  

With a four-page color spread featuring both the individual and their school.  

Being unprecedented, Weekly Fuji's editorial department held repeated meetings and decided to triple their print run, referencing a past case where they featured an exclusive interview with a young actor selected as the government's PR image character.  

The issue featuring Yuu's exclusive interview went on sale Monday, October 8th.  
Rumors had spread due to posters in major station concourses, train hanging ads, and large billboards in urban areas since the previous Friday.  
To prevent theft, the advertisements used text only with no facial photos.  

Most women who saw these assumed it was exaggerated advertising.  
It's common to use sensational language to boost sales, only for the actual content to be disappointing.  
Moreover, Weekly Fuji wasn't even in the top 10 among photo weeklies and gossip magazines, and its articles had a rather government-aligned, stiff image. It wasn't particularly strong in male-related content.  

Yet many women couldn't suppress a "what if" feeling and anticipated the release.  
This shows how starved women in this world are for information about young men.  

The earliest place to obtain the magazine would be 24-hour convenience stores.  
Depending on delivery timing and when staff unpack shipments, you could buy it as early as 1 AM when the date changes.  
Thus, despite being late at night on the 7th, customers converged on convenience stores nationwide simultaneously.  
Many stores sold out before staff could even stock shelves, with customers demanding copies immediately.  

Next earliest were station kiosks.  
As stations opened, women sprinting to kiosks were seen everywhere, including those who failed to buy at convenience stores.  

Women who secured copies first opened the color photo pages to verify the headline's truth.  
Upon seeing the photo of the smiling beautiful boy - even before reading the article - they'd stare intently in surprise.  
Then they'd suddenly look around. Some who couldn't get copies watched enviously, so they'd carefully tuck away the magazine and quickly leave to read it somewhere calm.  

Such scenes occurred nationwide.  
Some enthusiasts from regions with delayed releases even traveled to major cities to buy copies.  

In some cases, fights broke out over the last copy requiring police intervention,  
or shocked customers lashed out at staff when sold out (many stores had reserved staff copies in advance).  

By 10 AM, the fact that a high school boy - rivaling average celebrities - appeared in the somewhat minor Weekly Fuji with his real name and photo spread through phones, word of mouth, and the computer communications (email, bulletin boards, chat via phone lines) that began proliferating in the late 80s.  
This was exceptionally fast for an era without social media.  

Consequently, even students and workers who normally didn't buy weeklies skipped school/work to hunt remaining copies or lined up outside bookstores before opening.  

Those subscribing to Saito News, a local paper distributed in Saitama Prefecture and some border municipalities, were fortunate.  
They could read nearly identical content to Weekly Fuji's article with color photos on page 3.  

Women who luckily obtained copies and reread it repeatedly became infatuated with Yuu across generations.  
Groups passing around Weekly Fuji during school/work breaks were tame.  
Many abandoned classes/work to hole up at home, obsessively rereading the mere four pages, even masturbating to Yuu's photos.  

Naturally, they learned the school was in Saitama Prefecture's Saito City and wanted to see him, to speak to him.  
Anticipating nationwide recognition of Yuu's name, Sairei Academy and local police coordinated with security companies to prepare thoroughly.  

Roads to Sairei Academy had traffic restrictions starting 1km away from 8 AM. Except for buses, school shuttles, and delivery trucks, all vehicles were turned back.  
Still, they couldn't stop people approaching on foot or bicycle via narrow paths.  

◇ ◆ ◇ ◆ ◇ ◆  

That day, when Yuu descended to the apartment entrance, he wasn't just greeted by Sayaka, Riko, and Emi.  
Two tall women in black suits who looked unmistakably like bodyguards were also there.  

Moreover, Kanako and Touko - who previously only saw him off - followed behind Yuu. Surrounded by seven women, completely shielded from outside view, he entered the car.  
The two new additions plus Kanako and Touko headed toward a black sedan parked in front of Yuu's car.  

Security during transport had actually been strengthened since Yuu became Sairei Academy's student council president on October 1st.  
Keeping Yuu's residence unknown was top priority, but they prepared for potential leaks.  
The two new guards and sedan were funded by the Male-Female Exchange Promotion Association using national subsidies.  

"We got word from school this morning. A crowd's already gathering at the gates."  
"Eh? Already?"  
"Expected. Even with police traffic control, they can't stop everyone."  
"Yuu-kun, the first day is the real test, you know?"  

Sitting between Sayaka, who settled into his lap with her back against him, and Riko and Emi pressed against his sides, Yuu embraced them.  
Though the seating rotated daily, this intimate car arrangement with his three fiancées was routine. But their conversation held tension.  

This related to Weekly Fuji's release today featuring Yuu as the first male high school student council president.  
Nearby residents who read the article or heard rumors were converging to catch a glimpse of him.  
By 7 AM when Sayaka got the school's call, over 200 had already gathered. Nearly an hour later, who knew how many more?  

"It's crowded."  
"We left 10 minutes early, but we might still be late."  
"Normally the road clears here, but..."  

The road outside the apartment was congested with morning commuters. But even after leaving downtown, traffic didn't thin. Unsurprisingly - most vehicles were heading to Sairei Academy from outside the city, including out-of-prefecture plates.  
With traffic restrictions 1km from school, U-turning cars, detours, and roadside parkers walking the rest caused gridlock.  

"This is troublesome."  
"Yuu-kun, maybe you should stay at my apartment for a while."  
"That's a good idea."  
"Agreed!"  

Yuu already stayed at their apartment Mondays and Fridays. He wouldn't mind consecutive stays, but family approval was uncertain. Regardless, reaching school was the immediate concern.  

Eventually, they crawled along until the police barricade. First period was about to start. Yuu almost thought walking would be faster.  
Of course, he knew exiting would cause panic, so he kept that thought to himself.  

"What's... that?"  
"Wow, beyond expectations."  

As the road cleared past the traffic jam and the gates approached, crowds flanking both sides came into view. Not 200 people - twice, no, three times that. To Yuu, it looked like Sairei Academy's entire student body had gathered.  

Chaos erupted as a boys' shuttle bus entered. Police lined the outside with ropes, while extra security guards inside prepared for emergencies. Though crowded, they seemed barely contained.  

In this world, police officers are all women except in special divisions for male victims of sexual crimes. Regrettably for Yuu, no skirt-wearing policewomen were present - all wore navy pantsuits outdoors.  

As the first bus entered slowly, Yuu's vehicle approached next. The two black sedans made waiting women suspicious. Normally, it'd be the principal or education officials. But maybe that beautiful boy from the magazine was inside as a VIP?  

The lead car crept toward the barely open gate. Yuu spoke to the driver.  

"Um, excuse me. Could you stop briefly?"  
"Eh?"  
"Yuu-kun?"  
"I thought I'd open the window and show my face."  
"Yuu-kun, that's a bad idea!"  

Everyone in the car gasped and objected simultaneously. Naturally. Though police held the crowd back, women might swarm if they saw Yuu. But Yuu had a plan.  

"This is my fault, right?  
Isn't it troublesome having people waiting at the gate?  
If I show myself so they know I've entered school, maybe those who achieved their purpose will leave."  
"Umm..."  

To Sayaka and others, Yuu's idea seemed reckless. Young men never risked danger. But they'd witnessed Yuu's unconventional behavior toward women repeatedly. They wanted to protect him yet respect his wishes, torn between agreeing and stopping him.  

"Please, Sayaka."  
"Auuuuh"  

Held tightly with whispers in her ear, Sayaka couldn't refuse. Yuu prevailed. As the car slowly moved, the power window lowered. To avoid complicating things, he asked the girls to duck down.  

"Eh?"  
"Ehh!?"  
"Eeeeeeek!?"  

The rear window's dark tint hid the interior, but women couldn't help staring. None expected the window to lower, revealing the beautiful boy they'd just seen in the magazine. Everyone gaped in shock.  

When the left window fully lowered and Yuu appeared, he made eye contact with front-row women just 2 meters away. Students in uniforms dominated the crowd, but adults in suits and casual wear mixed in. Directly ahead, 5-6 girls wore dark gray sailor uniforms with red scarves - students from Saito Comprehensive High School.  

Yuu leaned out, placed hands on the roof, and exposed his upper body before sitting on the fully lowered window frame - "box riding." Sayaka and Riko firmly held his legs to prevent falling. Women on the opposite side saw him too, causing more commotion.  

"Good morning, everyone!"  

Yuu waved and greeted them. The unexpected response left everyone dumbfounded. Only a few in front reflexively waved back. Seizing the moment, Yuu continued rapidly.  

"It's problematic having everyone at the gate, so please disperse. Thank you."  

"No way, he spoke to women!?"  
"Th-the real thing's handsome too..."  
"That smile... wonderful... I'm smitten!"  

Some remained stunned by Yuu's sudden appearance. Others looked satisfied, mentally replaying the moment. Some snapped back to reality as the car passed, rushing forward only to be stopped by ropes. Reactions varied.  

But only those in front saw Yuu. Those further back didn't understand the commotion. Though less than half reacted, they pushed forward against police restraints. Meanwhile, Yuu's car passed through the gate. Security immediately began closing it. Not all boys' buses had arrived, but they'd be redirected to another gate.  

With the gate closed, over half the crowd gave up. Some might have heeded Yuu's "request."  

"Phew. More than usual, Yuu-kun, what you do is bad for our hearts."  
"Ah! Sorry. All three of you are pregnant, that was careless. Really sorry!"  
"It's fine. Don't worry. We're just glad you're safe."  

Yuu regretted potentially endangering Sayaka and others by exposing himself, while they purely worried for his safety. Their mutual care was touching. Relieved after reaching the second building safely, Yuu instinctively hugged and kissed Sayaka, Riko, and Emi.  
Unfortunately, he forgot one window was fully open, and many students gathered outside witnessed it.  

---

### Author's Afterword

Common sense dictates that men in this world wouldn't take such actions.  
I hesitated having Yuu - who's gradually understanding this world's norms - do this.  
However, since surprising surrounding women and having it received favorably is this work's motif, I deliberately had him take this seemingly reckless action.  
That they entered campus safely was simply good luck.  


### Chapter Translation Notes
- Translated "反響" as "Repercussions" to convey widespread societal impact
- Preserved "DEPARTURES" as cultural reference to travel/transition themes
- Translated "ハコ乗り" as "box riding" to describe car window sitting
- Maintained Japanese honorifics (-kun, -chan) per style rules
- Used explicit term "masturbating" for オナニー as required
- Kept organization names like "Weekly Fuji" untranslated per Fixed Terms
- Transliterated sound effects (e.g., "Eeeeeeek!" for えええぇぇぇぇ)
- Rendered sexual terms directly ("ejaculating" for 射精)
- Italicized internal monologue *(This is concerning.)* per formatting rules
- Preserved Japanese name order (e.g., Komatsu Sayaka) throughout