## 239. Repercussions ② ~The First Step~

### Author's Preface

This subtitle has no relation to a certain boxing manga.

---

A male high school student becoming the first student council president in national history, receiving magazine interviews and being featured with his real name and photo.  
This shocking fact rapidly spread throughout Japan.  
Public broadcasting covered it during both noon and evening news that same day.

After seeing Yuu enter while closing the gate immediately after, about half the crowd at the school gate dispersed.  
However, people flocking to Sairei Academy increased over time, with reports stating over 1,000 had gathered by noon alone.  
Some who learned through word-of-mouth that Yuu had already entered school left immediately, but many others tried peeking inside or attempting illegal entry, unable to give up.  
Thus, the effectiveness of Yuu's actions remained questionable.

TV stations also headed to Sairei Academy that morning seeking interviews, but abandoned vehicle entry due to restrictions.  
At best, a few with handheld cameras managed to walk to the main gate.  
Male students including Yuu had long since entered, making footage impossible.  
The sole achievement was interviewing some remaining women who'd glimpsed Yuu.

Consequently, phones rang nonstop at Sairei Academy since morning, but prior arrangements redirected all inquiries to the public interest corporation: Male-Female Exchange Promotion Association.  
The association—largely staffed by Toyoda Sakuya Memorial Foundation employees—had clear policies:

The Weekly Fuji coverage is substantially factual.  
No responses regarding personal inquiries about Yuu.  
No new interview requests accepted at this time.

Since he's an ordinary male high school student, even persistent media outlets targeting celebrities or politicians had to back down.  
Additionally, announcements that nearly identical content would appear in a special bulletin on the 18th—accepting reservations for just three days—instantly drew thousands of applicants.

Yuu anticipated attention from the magazine feature but never expected this scale of commotion.  
Toyoda Haruka, Satsuki, and Sayaka had predicted this outcome and prepared accordingly, showing some difference in awareness.

Ultimately, all male students only reached classrooms around first period's end.  
Later reports mentioned attempts to scale the 2-meter walls besides the three entrances.  
Police secured the main gate area where crowds concentrated most, while doubled security guards and sports club members voluntarily patrolled other areas, repelling intruders on sight—perhaps demonstrating Sairei girls' resolve to never let anyone lay hands on their male students.  
Hearing this, Yuu decided to thank the sports clubs at their next gathering.

Regardless, Yuu first apologized during first-period break to all classmates for the disruption caused by his interview.  
Next break saw him visiting second and third-year male classrooms to apologize.

This humility despite his privileged rebirth remained characteristic of Yuu.  
In this world, some men born male feel entitled to preferential treatment, displaying arrogance.  
Coed school boys are relatively better; rumors say male high schoolers avoiding women often develop eccentricities.

Thus, when Yuu apologized sincerely, second and third-year boys accepted it magnanimously.  
Some surely thought *"What a nuisance"* internally without voicing it.  
But at least no seniors confronted Yuu directly.  
Rather, third-year Ichijou Koki—who'd befriended Yuu since first semester—expressed concern for his safety.  
Truly, the top handsome (from Yuu's perspective) had looks matching his character.

Finishing lunch early, Yuu visited the faculty room.  
Unceasing phone rings prevented many from eating.  
There, Yuu apologized to remaining faculty—all women—for the trouble.

"Yu... *ahem*, Hirose-kun, it's alright. Don't worry about it."  
"I can't rest easy like this. I'm truly sorry."

Young or middle-aged, acquaintance or stranger, beautiful or not—Yuu circled the room apologizing to each individually. When handshakes delighted them, he shook every hand thoroughly like a politician.  
Facing such treatment, even teachers exhausted since dawn felt their moods lift.  
Some had obtained Weekly Fuji but lacked time to read thoroughly; now they rejoiced at conversing with Yuu himself.  
For Sairei faculty overwhelmed since morning, Yuu's visit felt like a refreshing break.

Later, Yuu visited security with gift sweets to express gratitude.  
Since male students rarely visited guard posts, security wept with moved astonishment.

As someone fundamentally common, Yuu simply expressed natural apologies and gratitude toward everyone affected—students and faculty alike.  
This further boosted Yuu's popularity at school.

After school, Yuu immediately headed to the principal's office.  
He'd requested a meeting through the vice-principal during lunch.  
Informed of an opening right after school, he arrived to find the chairwoman present unexpectedly.  
Her visit wasn't coincidental—she'd come to discuss responses to Yuu's article.  
This suited Yuu's agenda perfectly.

Behind the broad steel desk facing windows hung framed calligraphy reading "Coexistence and Co-prosperity of Men and Women" alongside awards. Glass-doored bookshelves opposite displayed prominent trophies—a typical principal's office.  
Now Yuu faced the two leaders on black leather sofas near the entrance.

He'd spoken once before with Kodama Ayako, chairwoman of school corporation Ayakuni Group—about two months since their quiz championship with Saiei Academy.  
Her sturdy frame wore quality suits, short hair swept back, raptor-like eyes radiating vigilance.  
At first meeting, she seemed less an educator than a shrewd executive.

Perhaps overshadowed by the striking chairwoman, the principal seemed oddly inconspicuous.  
Around mid-50s, medium build with graying hair in a bun and thick-framed glasses, she evoked a veteran female employee from corporate general affairs or accounting.  

Sayaka mentioned she wasn't a career educator but a corporate executive headhunted by the chairwoman.  
Her methods were unflashy but meticulous.  
In this world, coed school management faces unique difficulties, yet she'd served three years as principal without major incident.

Entering, Yuu first bowed to both.  

"My deepest apologies for inconveniencing the school due to my actions today!"

His unexpectedly polite apology—rare for a male—left them stunned.  
The school had been notified beforehand, evident from Sairei's feature in Weekly Fuji.  
Hence teachers and security responded early anticipating today's chaos, and the chairwoman came specially.  

Thus Yuu needed no apology.  
Yet feeling responsible, he apologized—perhaps reflecting Japanese relationship-smoothing tendencies or his past corporate experience.  

"No, Hirose-kun bears no responsibility."  
"But we accept your feelings since you, a male student, took initiative to apologize."  
"Th-thank you."

They chatted amiably about Weekly Fuji's content and today's events.  
Though nervous, Yuu relaxed at the peaceful start.  

"Incidentally, weren't many inquiries about transfers or next-year admissions?"  
"Yes. Exactly."

The principal answered the chairwoman's question solemnly.  

"As a coed school, we get many female transfer applicants—usually 40-50 monthly exam applicants. With acceptance limits, we admit maybe 2-3 monthly."  

Transfer exams are tougher than regular entrance—proving Nana's excellence for passing.  

"Due to Hirose-kun's article, over 1,000 transfer applicants from inside and outside the prefecture arrived just today."  
"Th-thousand!?"  
"Hahaha! We'd struggle with so many at once!"

The article's benefit? Nationwide recognition boosting applicants.  
Nationwide student numbers decline slightly currently.  
Private schools strive to maintain enrollment.  
Yuu's feature might surpass even national club tournament victories in impact.  

"Women aside, what about men?"

At Yuu's question, chairwoman and principal exchanged looks.  
The principal answered.  

"Truthfully, male transfer and admission inquiries increased too. We want to accommodate as much as possible."  
"Hirose-kun's article seems well-received by males too."  
"That's... truly good news."

Yuu anticipated national female attention—idol-level popularity—from the magazine.  
But he worried about same-sex reactions.  
However popular with women, he disliked male rejection.  
Though believing he'd promoted Sairei well, hearing boys held near-admiration for him brought relief.  

"Speaking of, Hirose-kun wanted to discuss something?"

He'd requested the meeting through the principal, asking to see both if possible.  

"Yes. Originally I planned proper arrangements through the principal to meet you, Chairwoman.  
But hearing you'd be here today, I seized the opportunity."

Yuu opened his notebook.  
Since deciding to become student council president, he'd compiled notes from Sayaka and library research about Sairei, Ayakuni Group, and prefectural high schools.  

"So this is still a draft—I intended proper materials."

He showed them later pages with crossed-out sections and marginalia—clearly draft stage.  

""Ayakuni Group Full Coeducation Plan!?""

First came large underlined text.  
Both read it aloud—the principal remained frankly astonished while the chairwoman briefly surprised then read with interest.  

"You held the joint quiz championship with Saiei Academy last July, right?  
I heard you want to include two other sister schools next year."  
"Indeed."  
"Personally I agree, but joint events with three girls' schools—Saihou, Saiai, Saiei—and coed Sairei would be challenging."  
"This year's championship succeeded though."

Yuu knew well that success came from Sairei student council and committee efforts.  
Adding three schools would undoubtedly increase Sairei's burden.  
After all, girls' school students anticipate interaction with Sairei boys—unpredictable compared to coed Sairei girls.  
Saiei's handling caused particular difficulty this year.  

"So you suggest making all three coed?"  
"Yes. Exactly."  
"But how with scarce males? Ah—could increased male applicants help?"  
"No, that's coincidental."

The principal looked at Yuu, but he hadn't predicted the surge either.  

"You mean absorbing Kumagaya Boys' High School?"  
"Yes. Exactly."

When current high schools formed, genders were separated.  
This changed ~20 years ago when the government adopted Toyoda Sakuya's proposal, advancing coeducation through girls'/boys' school mergers.  
Coed schools spread nationwide while boys' schools decreased.  
Saitama Prefecture now has three boys' schools—one in Kumagaya City, northern Saitama's core city.  
But annual enrollment declines left ~20 students per grade.  
Though boys' schools typically have 1-2 small classes, Kumagaya's shrinkage drew attention.  

Yuu first considered drastically increasing Sairei's male students.  
Absorbing Kumagaya Boys' School plus increased applicants could double enrollment.  
Students would spend first year at Sairei, then transfer based on grades/interest to Saihou, Saiai, or Saiei in Year 2.  

Saihou Academy: Top prefectural prep school with high elite-university rates (Kawagoe City, southeast of Saitou).  
Saiai Academy: Trains experts in commerce, industry, agriculture, nursing, welfare, childcare (Ageyo City, east of Saitou).  
Saiei Academy: Half its students specialize in music, art, crafts, calligraphy (Sakate City, south of Saitou).  

All four schools lie within one hour by car.  
Each Ayakuni school has distinct strengths.  
With more males, some might prefer specialized schools over Sairei's general track.  
However, long being girls' schools means overcoming faculty/student mindset shifts and facility expansions.  
But with proper preparations, Yuu believed this achievable.  

"Fufu. Fuhahahaha! Interesting. Truly interesting!"

The chairwoman laughed like a villainous mastermind—not scornfully, but genuinely amused.  

Regaining composure, she leaned forward seriously.  
Her imposing physique made the close-up gaze intimidating, but Yuu met it unflinchingly.  

"What follows is confidential. Absolute discretion."  
"Y-yes!"

"Actually, Kumagaya Boys' merger talks began last year."  
"Is... that so?"  
"Yes. Ayakuni Group applied, but Shibusawa Academy's Kushibiki High is frontrunner due to proximity."

Shibusawa Academy operates private schools in Fukawa City (Kumagaya's neighbor), with Kushibiki High being its girls' school.  
The principal continued.  

"We promoted our 15-year coed experience, but distance slightly disadvantages us versus Kushibiki. Though Hirose-kun might tip scales in our favor."  
"Oh! Then—!"

Naturally excited hearing the chairwoman already pursued this with heightened feasibility.  

"Personally, gender separation in schools feels unnatural."  
""Huh?""  
"Schools should have boys and girls learning together in same buildings and classrooms from elementary through university—increasing interaction opportunities.  
Chairwoman, shouldn't Ayakuni establish elementary schools for integrated coeducation?"

Facing their astonishment, Yuu advocated his vision.  
He understood true gender equality was difficult with current ratios.  
But changing the world step by step remained his resolve.  
Watching him, the chairwoman murmured in amazement.  

"Remarkable. Never expected such proposals from a male student."  
"Frankly, a male student council president alone is unprecedented..."  
"Hmm... Speaking of which... I recall a man saying similar things long ago."  
"Toyoda Sakuya-san, correct?"  
"Exactly."

Hearing this, Yuu panicked slightly.  
He hadn't revealed his paternal relationship with Sakuya to them.  
Confidentiality might permit disclosure—but never his reincarnation secret.  

Fortunately, the chairwoman shifted focus to integrated coeducation, sparing Yuu further pursuit about Sakuya.  

---

### Author's Afterword

Conversations with VIPs are challenging.  
Chapters 224-225 featured government dignitaries too, but more like welcoming parties for Yuu.  
This time involved Yuu's proposals.  
Ending with Sakuya references felt somewhat formulaic, but his generational influence made inclusion unavoidable.  

※Adjusted sister schools' locations closer than initial settings.  
Believe previous references are corrected, but please point out any remaining errors.  


### Chapter Translation Notes
- Translated "お局様" as "veteran female employee" to convey the corporate seniority nuance while maintaining formal tone
- Rendered "恰幅の良い" as "sturdy frame" to describe Kodama Ayako's physique without body-shaming connotations
- Translated "ぎょろりとした目つき" as "raptor-like eyes" to preserve the predatory imagery
- Kept "彩邦グループ" as "Ayakuni Group" per Fixed Terms consistency
- Translated "ナンバー1のイケメン" as "top handsome" to maintain the casual admiration tone
- Preserved Japanese school names (Saihou, Saiai, Saiei) with explanatory translations in parentheses
- Maintained "Kumagaya Boys' High School" and "Kushibiki High School" as established terms
- Translated "小市民的な" as "fundamentally common" to convey Yuu's self-perception accurately