## 241. Student Council President's Work ② ~Harmony of Two~

"Brother, thank you for your hard work."

"The seniors left in such high spirits?"

"Hmm~? I just talked with them normally."

As Ruika left, Nana and Sawa entered the waiting room. Kiriko, who had just returned, saw Ruika off with a beaming smile after noticing her expression. Though Ruika would likely reveal what happened when questioned en route, Yuu didn't mind.

"Ehh, I'm so curious~"  
"Ugh"

Nana clung to Yuu who remained sitting cross-legged, nestling completely into his lap. Truthfully, Yuu's crotch hadn't fully calmed down yet. Though her breasts were like small hills compared to Ruika's mountains, petite Nana clinging to him and rubbing her cheek against his chest stirred something within him. In short, what should have subsided remained erect. Yuu turned toward Sawa, who sat formally seiza-style at a slight distance.

"What's next on the schedule?"

"One more person was scheduled today. But she got suddenly called by a teacher and will be about 30 minutes late."  
"I see. Then..."  
"Brother? Ufufu~"  
"Hmm?"

Nana looked up at Yuu with an innocent smile. She seemed aware of the hard object pressing against her buttocks. Only Sawa tilted her head in confusion. Yuu gently placed a hand on Nana's shoulder and raised his knee.

"I was trying to hold back... but I can't get this erection to subside."

*Clink clink* - he unbuckled his belt, lowering both his sweatpants and boxers together.

"Ah!"  
"Wha-!?"

*Byoon!* His fully erect cock sprang out energetically.

"For a boy... why do you expose your genitals so casually?"  
"Ahhaa... Brother's cock..."

Sawa sighed with a dumbfounded expression. Meanwhile, Nana's face lit up as she drew her face closer until her nose almost touched it, sniffing intently at close range.

"I love Brother's scent..."

Gently stroking Nana's head, Yuu spoke.

"That's why I have a request for both of you."  
"Don't tell me..."  
"I'll do anything for Brother's request."

Yuu smiled at their contrasting reactions.

---

"F-first... let's start with kissing."  
"Okay, please do."

While Nana readily nodded when asked to touch and suck his cock, Sawa hesitated slightly but didn't outright refuse. Rather, she immediately embraced Yuu's head as she approached, bringing her face close before whispering in a small voice - a complete contrast to their first meeting that delighted Yuu. Meanwhile, Nana monopolized his cock, not only stroking the shaft thoroughly with both hands but rubbing her cheeks against it too.

"Nn, nn, nchu, chu, nmu... muaa!? Ehh... uun... mpfaa... mo... u..."  
"Sawa, stick out your tongue too. Like this, say 'ahh'"  
"Uu... ahh"

After tasting her mouth thoroughly during their kiss, Yuu whispered this. Sawa opened her mouth and stuck out her tongue, cheeks still flushed pink. Yuu gently stroked her long black hair while pressing his tongue against hers. As their tongues tangled wetly without their lips touching, Sawa seemed to get aroused too, clinging tightly while writhing and letting out heated breaths.

"Suck my cock."

When Yuu whispered this to Sawa - her mouth half-open with drool, eyes dazed even behind her glasses - she obediently nodded and lowered her hips.

"Now that I see it again... h-how did something this big fit inside me?"  
"Nnfu. Brother's cock is amazing, right? Haa-hiite, nyeoronyero~ licking... See? It twitches like it feels so good~"

Though Sawa had only recently lost her virginity to Yuu and had touched/sucked him before penetration, she still couldn't get used to the imposing sight of his erect cock up close, nor the heat and hardness when touched. Nana had only seen it one more time than Sawa but seemed completely accustomed, lightly stroking the shaft while extending her tongue to lick the glans before pursing her lips to suck on it. When she pulled away, she smirked at Sawa - which Sawa interpreted as a challenge.

"I-I'll do it too!"

Saying this, she competitively grabbed the shaft, stuck out her tongue, and began sucking.

---

"Amu! Churuuuu... chupon! Afuu... lero, erororerooon... nnfu. Brother, it feelsh good, right?"  
"Chupuu... nn, nn, nmo... nnn~~~~~~~nnpaa. Haa, haa, nchu, chu, nhaa... I-I'm better... right? See?"

Nana clung to Yuu's left side while Sawa clung to his right, each wrapping one arm around his waist while using their free hand to stroke his cock - competitively demonstrating their tongue skills or sucking down the entire glans. Though awkward at first, their fellatio improved since Yuu stroked both their heads while requesting what he wanted.

"Ahh, both of you have gotten better than I expected... Feels really good."

Particularly Nana - whether deliberately or not - looked adorably sly when licking upward with her broad tongue or glancing up at Yuu while sucking his glans. Meanwhile, Sawa maintained a serious expression while thoroughly licking from tip to balls with devoted intensity. She might be the devoted type. Though sometimes her glasses bumped against him when too engrossed, the way she occasionally tucked back stray hair with her fingers strangely aroused him.

"Kuh, uwaa... good, so good. Ahh... I'm about to cum."

Hearing Yuu's moan, Nana and Sawa intensified their ministrations. Sawa now took the entire glans in her mouth while wriggling her tongue. Nana dragged her tongue wetly along the underside. Their stroking hands synchronized at increasing speed as drool and pre-cum mixed, making lewd *squelch-squelch* sounds.

Yuu gripped their shoulders as pleasure made his hips tremble, barely holding back until the climax.

"Guh... kuuuuuu... N-Nana! Sawa! I'm cumming! Ahh! Ah, c-cumming!"  
"Umuoo!? Ehh... kyaa!"

After a momentary shudder inside Sawa's mouth, semen burst out violently. Startled by the thick, hot globs, Sawa pulled away - causing the cloudy fluid to splatter across her pretty face, even whitening her glasses.

"W-wha? Why this...?"  
"Ahhn, what a waste."

Before Sawa could react, Nana swallowed Yuu's cock. *Chu-chu* - she audibly sucked down the remaining semen.

---

The next consultation visitor was a strict-seeming 3rd-year senior who was mutual friends with Sayaka and Riko. She'd apparently been dumped by a same-grade boyfriend since May. When Yuu gently spoke to her upon entering, she broke down crying - leading to 30 minutes of him holding her close, stroking her head, and comforting her.

After seeing her off, Yuu entered the student council room to find Emi, Mizuki, Nana, and Sawa still working despite nearing dismissal time. Kiriko and Yoshie had gone to the sports festival committee and would head straight home.

"Yu-kun, thank you for your hard work!"  
"Nah, I'm not tired at all... I hope she'll be okay?"  
"She'll be fine. Yu-kun has healing power. That senior's atmosphere was completely different when leaving."  
"Good then."

Yuu showed relief upon hearing this from Emi and Mizuki who greeted him. After their brief exchange, they returned to their secretary and treasurer duties, determined to finish their tasks. Yuu walked behind Nana and Sawa who sat side-by-side at the opposite long table, sorting request forms for the student council president.

"Dance club performance invitation? No need to specially invite the president. C-rank."  
"Another interview request from the newspaper club. Just you this time, Brother."  
"We already did one as the student council. But we can't ignore the newspaper club... let's tentatively mark it B."  
"And... so many personal consultation requests."  
"Endless. Prioritize 3rd-years with connections to current/former student council. Others depend on content."  
"Understood."

Between them sat a three-tiered document case with sliding transparent drawers labeled A, B, C from top to bottom (priority order A>B>C). Judging by paper thickness, the actual volume was inverse to priority - C alone had over 50 sheets.

"Good work. Are these today's?"  
"No. We're processing yesterday's. Today's will wait until tomorrow. There's this much."  
"Haha... That's rough."  
"Brother, my shoulders are stiff. Pamper me?"  
"Gladly."

Standing behind Nana, Yuu began massaging her shoulders. Her thin, slender back required careful pressure.

"Ahh... ahh, good! Brother, you're good... ahn, th-there... uun... afuun"

After thoroughly kneading both shoulders, he parted her long hair and pressed from her nape to hairline with his fingers. Nana moaned with sounds easily misinterpreted - it felt that good. Yuu had learned this technique online during his past life when desk work caused eyestrain.

"Let me do Sawa too."  
"Eh? I-I'm fine..."  
"Don't be shy."  
"Really, I'm... hyah!"

When Yuu bent behind her and grabbed her shoulders, his breath touched her ear. Just that made Sawa flinch, but Yuu didn't release her. Keeping moderate pressure while massaging, he brought his mouth near her ear.

"I know this work isn't your preference, but you're helping tremendously. Thank you."  
"Ah, hnn... I get it. I get it, so stop breathing on me... hyan!"  
"Haha. But I love your reactions."

"Ahh, I'm tired too! Massage me next!"  
"Me too! My shoulders stiffen easily!"

Emi and Mizuki murmured this while watching Sawa writhe under Yuu's touch. It seemed "pampering staff" might become part of the student council president's duties.

---

While Sawa flushed and panted, Yuu read several sheets from the unsorted pile over Nana's shoulder.

"Huh? This is from the basketball club."  
"What's it say?"  
"Umm... They want me as a guest at their retirement party since the 3rd-years are retiring."  
"Hmm. Basketball club... Yoko and Kazumi are members, right?"  
"Yeah. Probably why they invited me."

The applicant was indeed Hiyama Yoko from Class 1-5.

"Inviting the student council president to a club retirement party seems..."

Sawa peered over, judging it low-priority now that she'd calmed. But Yuu pondered deeply.

"We do have connections with the basketball club."

He recalled captain Shiina Chizuru - a senior who somehow reminded him of protection officer Kanako's student days. Basketball club introductions had also helped him meet Yoko and Kazumi, and he'd bonded with seniors during Newcomer Welcome Orienteering and quiz championships.

Though he thought sports clubs retired during summer break, some continued until fall tournaments. The basketball club's final tournament ran October 6-10 (Health and Sports Day), with the retirement party scheduled after school the next day. Having missed cheering at their fall tournament, Yuu wanted to see Shiina and the others again.

"I'd like to accept this."  
"Ehh..."  
"Listen - sports clubs always help with event security, so we can't dismiss them outright. Though we can't accept everything, if Yu-kun wants this one, why not?"  
"Understood."

With Emi's advice, Sawa accepted. Since the date was specified, Nana added it to this month's schedule. Thus, Yuu would visit the basketball club room after school on the 11th.

### Chapter Translation Notes
- Translated "兄さん" as "Brother" to preserve the intimate yet non-familial address pattern
- Used explicit anatomical terms: "チンポ" → "cock", "精液" → "semen", "射精" → "ejaculate"
- Preserved Japanese honorifics: "-san" for general address, "-kun" for Yuu
- Transliterated sound effects: "びよんっと" → "*Byoon!*", "にっちゃにっちゃ" → "*squelch-squelch*"
- Maintained Japanese name order: "Hiyama Yoko", "Shiina Chizuru"
- Translated "体育の日" as "Health and Sports Day" (real-world Japanese holiday)
- Rendered competitive fellatio scene without euphemisms per style guidelines