## 243. Student Council President's Work ④ ~DIVE INTO YOUR BODY~

"*Chu*, *chuu*... *nchuu*... *Hahh*... Yu... Yuu-kun! Ahh, I can't stop... more!"

"Ch-Chizuru... sen... pai... *nn*... *nmu*"

"Aahn, Chizuru, my turn now!"

In the dim light, Yuu sat on an old mat with Chizuru in front and Connie behind him, sandwiched between them. Before his rebirth, Yuu had preferred petite girls small enough to wrap his arms around. But now, height didn't matter - whether tall or short, slender or plump. He considered every woman's face, personality, and physique as unique expressions of individuality. Though being embraced by these two tall women made him feel somewhat like a shota.

Yuu's upper body was already stripped bare by their hands. At his request, both kept their uniforms on but removed their tight sports bras, exposing their large breasts. With their naked upper bodies pressed against him, their body heat fueled their rising excitement. Chizuru and Connie now competed to kiss Yuu while frantically groping his body with both hands.

After the farewell party, the underclassmen handled cleanup while third-years and Yuu were dismissed. As basketball club members lingered chatting, Yuu whispered something to Chizuru alone.

Chizuru volunteered to escort Yuu back to the student council room, but Connie secretly tailed them. She'd noticed the peculiar tension between Yuu and Chizuru during the party, and had seen Yuu leaning close to whisper right before dismissal. Her feminine intuition screamed suspicion.

Thus, Yuu, Chizuru, and the later-joining Connie found themselves in a prefab warehouse hidden in the school's backwoods. Its secluded location meant few students or staff approached. While the front door was locked, few knew about the hidden back entrance.

Moreover, the warehouse was divided - the larger section stored infrequently used festival equipment, while the smaller area where they entered contained sports gear like scoreboards, ropes, and nets. Most students meant the main gym storage near Field 1 when saying "sports storage," but athletes called this the Second Sports Storage. Though it should've been locked, members kept it accessible for convenience.

"Hahh... Hey, I have a request for both of you."

"Nn?"

Yuu spoke with saliva-smeared lips after deep kissing Connie. Chizuru looked up with dazed eyes, her face buried against his neck.

"I want to be sandwiched between your boobs."

"Eh?!"

In the confined space, embraced by Yuu whispering sweet words, Chizuru and Connie had unleashed their lust. But even they froze in confusion at his request. Yuu alone seriously compared their breasts.

"Whoa! Oh, *muuuu~~*"

Connie's rocket-like breasts engulfed Yuu's face, burying him in their valley. Female sweat and milky scent tickled his nostrils as soft flesh pressed from both sides. From behind, Chizuru enveloped the back of his head with her firm breasts. With their arms wrapped around each other behind Yuu's back, his head was completely oppai-sandwiched.

"Fufu, how silly."  
"Yuu-kun, can you breathe?"  
"Furhifuharaio... *nfuu* Connie-senpai's oppai... supreme!"  
"Heh~. I always thought they were just annoyingly big, but if Yuu's happy, I'm happy."  
"*Fumu*. I'd heard rumors Yuu-kun liked girls' breasts, but it's true."

They stroked Yuu's head and played with his hair as if soothing a child. Being breast-sandwiched like this stirred maternal feelings, making Yuu seem even more precious.

"Hyahn!"

Connie suddenly cried out when Yuu abruptly shifted and latched onto her nipple. After enjoying the cleavage, he now sucked on her pink areola and slightly large nipple like a baby. On impulse, he squeezed both breasts together and sucked both nipples simultaneously.

"Fa... ah! Ah! Ah!... *Kufuu*... S-something feels... good! Ahh!"

Overwhelmed by unexpected pleasure, Connie threw her head back trembling. Seeing this, Chizuru naturally wanted the same.

"Y-Yuu-kun... me too."  
"*Lero*, *leroo*... *chu-*, *chupa*! Nn... wait a sec."

After several minutes of sucking, licking, and nursing Connie's breasts, Yuu turned to Chizuru's chest. Smiling up at her, he said:

"Actually, I've wanted to do this since first meeting you, Chizuru-senpai. Today my dream came true."  
"Huh?"

Before Chizuru could react, Yuu grabbed the breasts before him. Their volume overflowed his palms, their firm elasticity pushing back against his fingers. Yuu's cheeks relaxed at the sensation as he kneaded the massive breasts.

"Hau... ah... *nn*! Y-Yuu-kun? Hyahh!"

Chizuru's nipples and areolas were peach-colored, slightly darker than Connie's. While kneading, Yuu pinched, poked, and pulled her nipples. When they swelled, he licked them. With Chizuru, he toyed with one nipple while voraciously sucking the other.

"Hyah... ah! *Nn*! *Nn*! *Nnn*! Ah... *fu*... *n*... haa... good..."

Chizuru stroked Yuu's head with a motherly expression, face slack with pleasure. Connie could no longer hold back.

"H-hurry, switch! I want Yuu to suck my boobs too!"  
"Ah... *nn*... *ufuu*, n-no way! We just switched... it's fine, Yuu-kun, suck more... *ahn*! Y-Yuu-kun is... my breasts... *ohi*! I-it's fine!"  
"Haa... then I'll do this."

Seeing Chizuru's ecstasy, Connie bent down to rub her cheek against Yuu's back, then had an idea. She'd grope Yuu's chest herself.

Having discarded their shorts and panties, both women's thighs glistened with dripping love juices. Chizuru with jet-black hair, Connie golden-blonde. Both pubes shone wetly, alluringly, while Yuu's cock stood painfully erect.

"*Nnn*!"  
"*Ahn*!"

Just light clitoral rubbing with his fingers produced slick sounds as love juices coated them.

"Chizuru-senpai, Connie-senpai, let's have sex?"  
"Yuu..."  
"Yuu-kun!?"  
"Ahh! Like a dream!"  
"I could die happy here!"  
"Haha, exaggerating. I'm lucky to have two beautiful, well-built senpai as partners."

Embraced from both sides, Yuu was showered with fierce kisses. He played with their ponytails while kissing back.

Space became the issue. While sitting was fine, storage boxes on three sides left no room for three to lie down.

"Got it! Both stand and turn your backs?"

Still virginal, Chizuru and Connie obeyed, facing the back wall where a waist-high shelf stood. Hands on it, they presented their backsides to Yuu - Connie on right, Chizuru left.

*(What a breathtaking view)*

Yuu gasped instantly. Both had large butts, yet more than that - their athlete lower bodies, free of excess fat, were muscle-toned artistic perfection.

Yuu stroked both buttocks before gripping firmly. Beyond-expected firmness and elasticity - like fully inflated volleyballs or soccer balls.

"Ahh... Yuu... kuun."  
"D-don't tease..."

"Sorry. Your butts feel amazing.  
Okay, inserting now."

Snow-white skinned Connie.  
Distinctly tan-lined Chizuru.  
Though tempted to choose, Yuu honored his promise to penetrate Chizuru first. But the height required wider stances. Their wet pussies now spread invitingly. Frantically pulling down pants and underwear, Yuu pressed his raging cock against Chizuru's butt crack.

"Oh! *Ufun*!"  
"Chizuru-senpai first. Connie-senpai, endure with fingers."  
"Eh... Yuu... *hahn*!"

First, Yuu thrust his right middle finger into Connie's vagina. Knowing her hymen was already broken, he pushed deep without hesitation. A *nup* sound as it slid in, then a tight clench. While slowly moving that finger, he positioned for Chizuru. Her earlier squirting had already wet his crotch.

Gripping her butt firmly with his left hand, Yuu adjusted the angle. With a slick sensation, his cock slid in but met vaginal resistance.

"*Gah*... ahh! C-cock! *Hii*!"

Amidst Chizuru's moans mixing agony and joy, Yuu began shallow thrusts.

"Guh! Chizuru... senpai!"  
"Yuu... kun!"

Just as the glans squeezed into the narrow crevice, it suddenly slid deep. Simultaneously, vaginal folds gripped and tightened around his cock like they'd never let go - Chizuru's subconscious refusing to release the long-awaited male organ.

"Ahh... inside senpai feels amazing!"  
"Ha! Ha! Ha! Really... Yuu-kun's cock... inside me... *ohh*, deep... inside... full... *nna*... *ah*! *Ah*! Me... with Yuu-kun... having sex! *Ahn*! I-I'm glad to be alive!"

Chizuru moaned tearfully with joy. Though no hymen pain, taking Yuu's huge cock surely hurt. But the ecstasy of losing her virginity to him overwhelmed it.

*Pan! Pan! Pan!*  
*Juppo! Juppo! Juppo!*  
*Guchu! Guchu! Jupuu!*

With each thrust, flesh-slapping sounds echoed alongside the sticky wet noises from both penetrated pussies.

"*Ah*! *Ah*! *Vah*! Yu... Yuu... kun! *Ahn*! So rough! D-deep... *iin*! Ah! Haa!"  
"Chizuru-senpai, still hurt?"  
"Ah... ahe? *Nn*! To-totally... fine... this is... my first time... but wreck me... more! *Aahn*!"  
"*Nn*! *Nn*! *Ahn*! Yuu? Fingers feel good but... I want cock too...!"

As thrusts accelerated from initial slowness, Chizuru's moans intensified to unbelievable levels for a virgin. Connie too found Yuu's fingering better than masturbating, but watching Chizuru moan beside her bred envy.

"Sorry. Okay, Connie-senpai's turn now."

Yuu withdrew his soaking middle finger and slowly pulled his cock out, moving behind Connie. Drenched in Chizuru's juices, it might slide easier. Inserting two left fingers into Chizuru, he positioned for Connie.

"Ha! Ha! Ha! Yuu, Yuu's cock! I waited... *ah*! *Oh*... *vvhiiiiiiiiiiiiiiiiiiiiiiin*!"

Yuu thrust deep. Connie's larger frame meant exceptionally deep vaginal depth, yet Yuu still struck her cervix. Instantly, Connie threw her head back with a scream between shriek and moan.

After penetrating Chizuru again, Yuu came as she experienced her first vaginal orgasm. Leaving the collapsed Chizuru, he reinserted his still-hard cock into Connie. It slid in smoother now. Clinging like a backpack monster, Yuu kneaded her ample breasts while thrusting fiercely. Each impact against her buttocks produced loud *bachun! bachun!* slaps.

"*Gah*... ah! Yu... Yuu... *oh*! *Oh*! *Nni*! So... rough... *ah*... *vhi*!"

The earlier break helped - Connie seemed past virginity pain now. Her love juice-drenched pussy seemed to accept him more with each thrust. Unseen by Yuu, Connie's face contorted in ecstasy. Her ponytail whipped wildly as she shook her head, sometimes hitting Yuu's face, but he kept pistoning. Despite one ejaculation, Connie's first-time pussy felt irresistible.

"Ahh! Connie! Connie... sen... pai... *uu*! Good! So good! I'll... fill your inside... with cum!"  
"Haeh!? *Ah*! *Hi*! M-more than... before... *oh*! *Oh*! *Oh*! Yu... u! *Nnaa*! Cumming... cumming! *Vah*! Or-gasm!"  
"I-I'm too!"

Near climax, Connie's vaginal folds squirmed around his cock like they'd milk his semen. Pressing deep from behind, Yuu ground and gouged. Connie trembled violently but gripped the shelf, waiting.

"Guh... Connie, cumming... *vah*! Ejaculating!"  
"M-me too... *oh*! *Kufu*... Yuu! Yuu! Yuuuuuu! Cuuuuuuuuuuuuuming!"

Thick spurts of semen flooded Connie's womb. Overwhelmed by pleasure, she went limp. Yuu tried catching her but failed against her size, tumbling backward together. Fortunately, a mat cushioned their fall.

"S-sorry, Yuu."  
"It's fine, really. Don't worry."

Yuu still held Connie, kneading her breasts. His cock had slipped out during the fall, white fluid gushing from her pussy.

"U-um, Yuu-kun?"

Having wiped her crotch with a handkerchief (no tissues available), Chizuru spoke hesitantly.

"Today... thank you. I'll never forget losing my virginity to Yuu-kun—"  
"Chizuru!"  
"Hyah!"

Yuu pulled her close before she finished, now dropping honorifics.

"And Connie."  
"Aahn, Yuu..."

His right arm around Connie's waist, they embraced in a three-way hug, exchanging passionate kisses.

"Sex with both of you was incredible.  
But I'm not satisfied yet. Look."

"Eh... ehh!?"

Kneeling on the mat, Yuu thrust his hips forward. His cock sprang before them. Having calmed briefly, the renewed contact during kissing had it battle-ready again. Still slick with juices, it hadn't dried.

"Hey, wanna suck my cock together?"

Chizuru and Connie had no reason to refuse. Answering by hugging his waist from both sides, they competitively began sucking.

---

### Author's Afterword

Being sandwiched between huge breasts - no, explosive breast-level breasts - is a man's dream. 

As for doubts like "Can players with such large breasts become elite athletes?" - let's conveniently set those aside.

### Chapter Translation Notes
- Translated "おっぱいサンド" as "oppai-sandwiched" to preserve Japanese slang nuance
- Translated "雌顔" literally as "female face" to convey primal sexual expression
- Preserved anatomical terms: "チンポ" → "cock", "おマンコ" → "pussy"
- Transliterated sound effects: "ちゅっ" → "*Chu*", "ぱんっ" → "*Pan*"
- Maintained Japanese name order: "Shiina Chizuru" not "Chizuru Shiina"
- Italicized internal monologue: "（なんという絶景）" → "*(What a breathtaking view)*"
- Used explicit terminology for sexual acts per style guidelines