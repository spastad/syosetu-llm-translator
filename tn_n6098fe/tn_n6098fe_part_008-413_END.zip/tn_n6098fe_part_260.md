## 244. Secret in the Music Room ~That Sound is the Melody of a Virgin

### Author's Preface

The subtitle is so obscure that few will recognize the original song reference.

It's an old Western song that became a huge hit as a cover.

---

Yuu had become close early on with the girls from Class 5 among the first-year girls.

Among them, he spent "touch time" literally touching and interacting with eight girls including Hiyama Yoko and Aki Kazumi two or three times a week during breaks.

Even after entering the second semester, this custom continued.

The place they often used was the music preparation room in the administration building.

Since music, art, and calligraphy were elective subjects with fewer classes, the rooms were often vacant except for club activities after school. Among the three, the music preparation room was the most convenient in terms of size and location.

That day too, Yuu and the eight girls were so intimately engrossed that they lost track of time. They were hurriedly leaving the music preparation room when the warning bell rang.

"Yuu-kun, your next class is modern Japanese, right?"  
"Yeah. But today it's self-study. So I'll head over slowly later."  
"Aww, lucky. If we had self-study too, we could've relaxed a bit longer."

Today, about ten teachers were away for training, so many classes were self-study. For the first-year boys' class, the next modern Japanese class was one of them, but apparently not for Class 5. After confirming no one was in the hallway, Yuu hugged and kissed each girl goodbye as he saw them off.

"Yuu-kun, um..."

When it was Maegashira Yuma's turn, she glanced toward the back of the preparation room before looking up at Yuu as if wanting to say something. But Yuu gently patted her head reassuringly.

"It's okay. I know, so don't worry."  
"Really? Then it's fine."  
"Good girl, Yuma."  
"Hehe... mmm..."

Yuu pulled Yuma's small body close and lifted her up for a kiss.

After seeing off all eight, Yuu would usually wait a moment before leaving, but today was different. After closing the door, he slowly shuffled toward the back without making a sound. His destination was the door leading to the music room.

Both this time and last week when they used the music preparation room, Yuma—being sensitive to presences—had noticed someone's presence. Yuu had also heard a faint clattering sound. He had a good idea who it was.

The door handle lock was vertical, meaning it was unlocked. Yuu grabbed the handle, turned it, and pulled abruptly.

"Huh? Kyah!"  
"Whoa!"

Perhaps because someone had been leaning against the door on the other side, a body came tumbling forward as Yuu pulled. He instinctively caught it. In that instant, an elegant floral perfume gently tickled Yuu's nostrils.

*(This scent... just as I thought)*  
"Are you okay?"  
"Ah... huh? Hyah!"

The slender woman with semi-long black hair quickly pulled away. Her white blouse had frills on the collar, covering up to her neck. Below was a black long flared skirt. At her neck was a silver classical brooch. She perfectly embodied the image of a pure, graceful, and beautiful music teacher—her name was Shirayuki Saori. Even her name had heroine-like qualities. By the way, she was 26 and single. Though not assigned to the boys' classes, Yuu had encountered her several times on his way to the music preparation room and exchanged words.

"Ahem. S-sorry about that."

Taking a step back, she flusteredly straightened her appearance and posture, then tried to return to the music room. Yuu had noticed her slightly flushed cheeks and disheveled skirt hem just before catching her. Moments ago, he'd been taking turns kissing all eight girls and thoroughly touching them through their uniforms. If she'd been right next door, she must have heard their intimate sounds too. It was possible she hadn't just been eavesdropping but doing something unspeakable herself. Yuu stepped into the music room side and closed the door.

"Um, Hirose-kun?"

As Yuu stepped forward, Saori took a step back while keeping her eyes on him. Her eyes darted around, clearly acting suspicious.

"Teacher?"  
"Y-yes?"  
"You were eavesdropping, weren't you?"  
"Huh?"

Though his crotch had been played with extensively during break, he thankfully hadn't ejaculated. Meanwhile, Yuu had been fondling the breasts and butts of all eight girls. So the heat rising from his chest hadn't subsided, and his crotch wasn't calm either. Faced with a beautiful teacher at such a moment, it was only natural his restraint failed.

"Teacher!"  
"Hiro... fah!?"

Closing the distance in one go, Yuu embraced Saori. Feeling her slender neck with its perfume and hair scent, plus her soft body through her clothes against him, only increased his excitement. Saori seemed frozen, unable to comprehend what was happening.

"Ah, um... Hiro...se...kun?"  
"Ever since we first met, I've thought you were a wonderful woman, Saori-sensei."  
"...!?"

With Yuu confessing while staring at her up close, Saori's brain seemed to short-circuit. Her large eyes blinked rapidly, her mouth half-open and unmoving. Without waiting for her reaction, Yuu sealed her lips.

Saori's cheeks instantly flushed crimson as she realized she was being kissed. Noticing Yuu pressed fully against her and his hand gently stroking her hair, her eyes grew heated. Her limp hands slowly rose and timidly reached for Yuu's back. The moment her fingertips confirmed the hard feel of his muscles, she hugged him tightly.

"Mmph... mm, mmph... puh, ah... h-hyohheeeun? Hyam! Ummph... churu, nchu, anmmph... lero, lerooo... afuun"

When his tongue slipped in, Saori's eyes widened in surprise, but as Yuu began ravaging her mouth without hesitation, her expression turned dazed and submissive. She began overlapping her own tongue and letting out sensual moans. They continued deep kissing while pressed together. Yuu's right hand slid down and firmly grabbed her butt while pressing his hardened cock against Saori's lower abdomen and rubbing.

"Fah? Wh-what?"  
"Saori-sensei!"

Pulling his lips away left a string of saliva. Saori's cheeks were pink, her wet lips glistening. Just as Yuu brought his mouth close again to meet Saori's closed lips, multiple girls' voices were heard, and the music room door opened.

"Eh? Princess-sensei?"  
"Really?"  
"I thought you didn't have class?"  
"Ah, ah, it was you all."  
"Teacher, what's wrong? Your face is red."  
"N-n-nothing! J-just a bit hot, or maybe I have a fever... Anyway, what is it?"  
"Um, next period is self-study..."  
"The autumn recital is coming up. Ah, we got permission from the teacher next door!"  
"Honestly... fine."

The four second-year band club members Saori advised had entered. Taking advantage of their next class being self-study, they apparently intended to practice in the music room. They should've been self-studying in their classroom. Saori had instantly headed toward the nearby lectern, opening a textbook that happened to be there to feign researching while standing, but she truly wanted them to leave. However, as their advisor, she was happy about their enthusiasm, and since they hadn't just left class but obtained permission, she couldn't say more.

Incidentally, some students—including band club members—called her "Princess-sensei" due to her long black hair, fair skin, atmosphere reminiscent of a well-bred young lady (though her mother was a civil servant, not particularly rich), and her surname evoking "Snow White." Saori herself found it embarrassing and disliked it, but knowing the students meant it affectionately, she couldn't refuse.

"Teacher is researching, but feel free to practice without worrying."  
"Okay! Understood!"

The students began taking their instruments from locked lockers. Perhaps out of consideration for Saori, they seemed to set up in a corner at a distance. As they prepared, flute and trumpet sounds began playing.

Where was Yuu? He'd hidden under the lectern when the girls entered, and had slipped inside Saori's long skirt. With not just the black skirt but also a gray inner layer, Yuu's view was practically blocked. But he could vaguely make out her fair, slender thighs and the crotch covered by pure white panties beyond. Moreover, an intoxicating feminine scent filled the skirt's interior, incredibly arousing.

Having come this far, a man had to act. Yuu grabbed her thinly fleshed thighs with both hands, savoring their softness as he raised his face. Bringing his face to her crotch, he noticed the panty gusset touching his nose was damp. Instantly, Saori clamped her thighs together, trapping his face. She probably meant to stop Yuu, but for him, it only felt blissfully soft. Yuu's hands crept up her thighs to grab her butt. While kneading her buttocks and rubbing his nose, he extended his tongue through the panties.

"Mmm... mmph! H-Hirose...kun... st-stop... I-I'll... make noise."

Ignoring Saori's voice, Yuu sucked and licked through the pure white panties until they grew transparent, then slid a finger to shift the gusset aside. A lewd vulva scent wafted to his nose, and even without seeing, he knew her vaginal opening was drenched.

"R-really... stop. Any more... ahn... forgive... ngh! Gumph, mmph, fuh, mmmph!"

Saori pleaded while covering her mouth with her hand. Hidden under her skirt and obsessed with her pussy, Yuu couldn't hear her muffled voice. Like a beetle drawn to sap, he extended his tongue to lick her vaginal opening, sucking the overflowing love juices. When he teased up and down with his tongue tip, lewd fluids immediately squirted out, wetting his face. Yuu spread her pussy wide with two fingers and thoroughly licked before thrusting his tongue at the clitoris.

"Nhyiin!"

The lectern rattled. Even the students practicing at a distance noticed the disturbance.

"Princess-sensei, are you really okay? You seem unwell..."  
"Should we go to the nurse's office together?"  
"Hah! I-I'm f-fine! If it's a cold, I might... spread it... so I'll rest... in the preparation room."  
"Really? Then take care."

Seeing the students resume practice, Saori slowly turned. The door to the preparation room was only about 3 meters away. Though distanced from the students, since the music room sloped upward toward the back, they might see Yuu's feet if they intentionally looked down at Saori's feet. Holding her skirt to prevent Yuu from being exposed, Saori walked slowly.

"Ah! Wait! There's something I wanted to ask Princess-sensei—"  
"Eh!?"  
"Hey, she's not feeling well now. Ask later?"  
"Y-yeah. Sorry."  
"I-it's fine. Sorry."

Saori's heart nearly stopped. Unconsciously placing a hand on her chest, she took a deep breath to calm down. Her other hand reached toward her lower half—signaling to start moving.

"Hiiiroooseee-kun"  
"Sorry, sorry, Saori-sensei. As apology, I'll make you feel really good."  
"Eh? W-wait... hyuh! Ahh, uuummmph~~~~~~!"

Seating Saori on a chair with a backrest, Yuu had her hold up her skirt hem. Slipping off her panties, he brought his mouth to her crotch again. Her exposed pussy was a clean salmon pink. Contrary to her words, it glistened wetly, twitching as if inviting Yuu in. His tongue mercilessly wriggled against her spread vaginal opening, making loud squelching sounds.

"Ra... geh! Hyuun! Iiguh, iiguh, aaeh, mmph, mmph, mmguh! Iihyiin! Ra... ah... iih, iiih! Ii... uuuuuuuuuuun!!!"

Starting cunnilingus right there, Saori climaxed in just minutes.

"Haah, haah, chu, chu, chupaa... aahm... mmph, lero, leroo... afuu, so this is... Hirose-kun's cock... haah, amazing."

Yuu stood while Saori, clinging to his waist, sucked his cock. She seemed to be seeing and touching an erect penis for the first time—her hand movements and tongue work were clumsy at best. Seeing her stare and drool upon seeing his bare cock, Yuu let her suck freely. Though sexually inexperienced, Saori might secretly have been a pervert.

Yuu's right hand gently stroked Saori's hair as she continued sucking obliviously. His left hand slipped into her opened blouse collar, fondling her breasts. As imagined through her clothes, her bust was modest. Slipping fingers into her bra cup, he tweaked her nipple.

"Mmph, amchu, eroo... mmph... ann!"  
"Hey, Saori-sensei?"  
"Y-yes?"  
"I'm about to lose control."  
"Eh? Um... sorry. I got so absorbed in your cock... Wh-what should we do?"

At 26, Saori was clearly a virgin with little sexual knowledge. She'd sucked his cock driven by surging desire but didn't know what to do next. So Yuu sat down, faced her directly, leaned in, and whispered.

"Leave it to me. I'll take your virginity."  
"Ah..."

Tears immediately spilled from Saori's eyes upon hearing Yuu's words. The joy of being able to have sex with Yuu—practically the school idol—welled up in her chest.

Having her remove her skirt to avoid soiling it and open her blouse front to expose her breasts, Yuu positioned Saori sitting shallowly on the chair with her legs spread in an M-shape. Crouching, he pressed his hips forward.

Though belatedly, Saori and Yuu were teacher and student. Even if getting caught by other students would be bad, she showed no sign of conscience troubling her, and despite being a virgin, she calmly exposed her genitals in an M-shape. That might be this world's peculiarity. Yuu found it hotter if the pure, graceful woman showed more shyness.

"Here I go, sensei."  
"O... okay!"

Adjusting his cock angle, Yuu slowly inserted it into her drenched vaginal opening. Immediately, he felt a soft membrane pop.

"Hyig... iih... iitaaaaaaaaaaai! Mmph, muguuu..."

Apparently, she hadn't broken her own hymen. The pain of defloration made her cry out loudly. Forgetting students were next door, Saori screamed. She hurriedly covered her mouth, but too late.

"Princess-sensei! We heard a scream! Are you okay?"  
"Trouble!"

Yuu and Saori exchanged looks.

"I-I'm fine! Just hit my pinky on a pillar!"  
"Ehh?"  
"Sorry for the noise. Y-you can keep practicing."  
"Okaaay."

They seemed to back off. Relieved, Yuu kissed Saori to muffle her moans while continuing insertion. Amidst muffled groans, he repeated small thrusts until his cock hit her vaginal depths. Throughout, Saori's hands on his back gripped with painful strength.

"Sorry... making you handle everything, Hirose-kun."  
"Not at all. I wanted this."  
"H-Hirose-kun... mmph"  
"Chu, chu... your inside is so tight and feels amazing."  
"Mmph, chu... your cock is bigger than I imagined. Filling me up completely... ah"  
"How's the pain? Okay?"  
"Mmm... still a little painful... but it's fine, don't worry."  
"Got it. I'll move slowly."

Hugging tightly and exchanging kisses, Yuu carefully moved his hips. Inside Saori, who was receiving a man for the first time, her vagina tightly clenched his cock, sending paralyzing pleasure at the slightest movement. Small thrusts actually suited better.

"Ah... mmph, kuh... uuh... hah, hah, haah! Mmph... mmph... vuun!"

Hugging tightly and kissing repeatedly seemed to distract from the pain. Though suppressing her voice, moans still leaked from Saori. Meanwhile, Yuu was nearing his limit from the virgin's tightness.

"Hyan! Wh-what?"  
"Thought I'd change positions."

Supporting Saori's back and waist with both arms, Yuu stood up. Moving forward, he pinned her against the wall, lifting one leg while still connected. Simultaneously, he latched onto Saori's modest breasts, rolling her nipples with his tongue while thrusting upward.

"Hyau! H-Hirose-kun, deeper than before... aah!"  
"Saori-sensei, suppress your voice. If they get suspicious and come in, we can't explain?"  
"Vuuh... vuuh, aah, mmph, fuh, mmph!"

Yuu's words were mean considering he'd deliberately pinned her near the adjacent room. But Saori had no energy to retort. Clearly, pleasure now overwhelmed pain.

Not just their soaked genitals, but her exposed chest, forehead, and sweat-drenched hair stuck to her skin. The sight of the pure, graceful beauty teacher Saori being thrust into disarray by Yuu was nothing but arousing. Though Yuu fully savored her increasingly slick interior, he couldn't last much longer.

"Saori-sensei, I'm at my limit. I'll cum inside you."  
"Fah... aahn! H-Hirose-kuun... cum, fill teacher's inside, fill me up! Hyah! Aah, aah, iihyiin! Amazinggggmmph"

As Saori's moans peaked, Yuu covered her mouth and began his final sprint. His hip movements accelerated, and the slapping sounds grew louder. Finally, when he gouged her vaginal depths, Yuu's body shuddered upon reaching climax. Having been erect since break, he must have built up a lot. Ejaculation took longer than usual, filling her womb with an unusually large amount of cum.

"Vuah! Aah... cumming... iihyiin... amazing... more... mmphuun..."

Receiving Yuu's ejaculation, Saori's vision went white from her first intense orgasm, her body going limp. But Yuu, having finished ejaculating, continued firmly supporting her.

---

### Author's Afterword

I thought there were surprisingly few interactions with faculty despite the school setting. Only the office worker Gonda Sakiko and math teacher Dei Kazuko in "109. Special Male-Female Negotiation Room ⑤" come to mind.

Though faculty members with feelings for Yuu were definitely increasing, their positions made overt approaches difficult. So, what if a teacher secretly listened to Yuu's intimate time with the eight Class 5 girls, and Yuu's next class was self-study?

Saori-sensei appeared in "102. Changing Students ②" as the teacher he almost bumped into on the outdoor stairs. Since then, they'd exchanged light conversation when meeting. I imagined her background: aspiring to be a pianist since childhood but becoming a music teacher for practicality (arts require heavy financial investment, apparently), coming from an ordinary family (not particularly wealthy).  


### Chapter Translation Notes
- Translated "おマンコ" as "pussy" following explicit terminology rule
- Preserved Japanese honorifics (-kun, -sensei) throughout
- Translated sound effects phonetically (e.g., "kyah" for きゃあっ)
- Maintained original name order (Shirayuki Saori)
- Translated explicit anatomical/sexual terms directly (e.g., "膣内" as "inside", "射精" as "ejaculation")
- Formatted simultaneous dialogue with double quotes per rules
- Italicized internal monologues (e.g., *(This scent... just as I thought)*
- Translated "白雪姫" nickname as "Princess-sensei" to preserve cultural reference to Snow White
- Translated "処女膜" as "hymen" using precise medical term
- Translated "おチンポ" as "cock" per explicit terminology requirement