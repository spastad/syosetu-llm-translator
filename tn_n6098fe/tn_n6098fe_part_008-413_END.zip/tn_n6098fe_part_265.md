## 249. Student Council President's Work? ④ ~Interaction Classroom~

"No matter how sturdy it looks, the penis is delicate. You need to touch it gently like it's something precious."  
"U-um. Like this?"  
"How is it, Yuu-kun?"  
"Mmm... good. Like that. Ah, especially the tip feels good, Asami-san."  
"Glad to hear. But I'd like you to call me by my first name if possible."  
"Okay. Misaki. And Nozomi too please."  
"Ehehe. I'm happy."  
"Hey, that clear fluid keeps dripping out..."  
"Want to taste it?"  
"Can I?"

When Yuu answered, the two girls scooped up the pre-ejaculate fluid with their fingers and licked it. They seemed not to taste much, tilting their heads slightly. But having tasted male bodily fluid for the first time, their heartbeats clearly quickened. With dazed expressions, they brought their noses close while carefully stroking the penis.

Kneeling at the feet of the standing Yuu who maintained his erection, three girls surrounded his crotch including Mizuki. They were the first group in class order. Ogawa Mizuki, who had experience, taught the two beginners while caressing the penis. Asami Misaki, who had declared "I only have eyes for Yuu-kun" before class, was on the right, and Ashino Nozomi on the left. Each clung to Yuu's legs with one hand while stroking the penis with the other. The two friends had matching short haircuts and were under 160cm tall, with modest busts unlike Mizuki.

Three relatively tall girls stood surrounding him from behind, touching his shoulders, back, and arms.

"Haaaaaa... a real boy... and Yuu-kun's bare skin... it's wonderful."  
"So smooth, feels great. I could stroke forever."  
"And such a nice smell too.........nnn......n...ah...fuu..."

At first they touched tentatively with fingertips or palms, but gradually their movements became bolder. Ioka Kayoko held his right arm, Enuma Mana his left arm. Uyama Maya, the tallest of the six, pressed her D-cup breasts against Yuu's back while burying her nose in the back of his head. Rubbing her nipples against his shoulder blades created electric pleasure, so she kept making small movements. Since most eyes were on his crotch, no one noticed her actions behind his back. She bit back moans while gripping his shoulders, but couldn't completely suppress them, pressing her mouth against his nape.

"We can't see the important part!"  
"Uu... understood."

Mizuki had been gazing at the penis from the prime spot while stroking it, but reluctantly lowered her head at the voice from behind.

The ejaculation demonstration - abbreviated as "ejaculation meeting" - had started urgently at Yuu's request to ejaculate. The six girls in Group 1 were learning through direct touch while stimulating him. Meanwhile, Maho and five other teachers sat on chairs about 2 meters from Yuu's platform-like spot, their eyes glued to his crotch since earlier.

As she lowered her head, Mizuki slipped under Yuu's legs, leaving the shaft stimulation to Misaki and Nozomi while reaching for the dangling scrotum and gently massaging it.

"Ah, ahh... being touched by everyone feels good... I'm about to ejaculate soon."

Except for Mizuki, they weren't experienced with men and their technique wasn't skilled. But Yuu's excitement was fully heightened from prolonged erection and being surrounded by six naked high school girls. Having his balls massured by Mizuki added to the sensation urging him toward climax.

"Misaki, Nozomi. Use your hands to stroke it."  
"Mmhmm!"

Yuu stroked the heads of the two girls handjobing him with his free hands. Misaki and Nozomi lightly gripped the shaft with overlapping small hands and began stroking up and down. The dripping pre-ejaculate made lewd squelching sounds in their hands. Under his legs, Mizuki gently massured the scrotum with one hand while sucking on the other, making chupa chupa sounds that quickly intensified Yuu's urge to ejaculate.

From left and right, Kayoko and Mana sandwiched Yuu's arms between their breasts. Unaware themselves, it resembled titty fucking his arms. From behind, Maya pressed her breasts against him with small movements while kissing his nape and licking, sending shivers down his spine.

"Ahk... ah, ah... I'm... ejaculating... guh! C-c-cumming! Haa!"  
"Wah wah!?"

Just as Misaki and Nozomi gradually increased their stroking speed, the penis trembled slightly before shooting out a white viscous stream. The upward-pointing penis launched it in a perfect arc. It landed splat in the cleavage of Maho, who sat front and center among the teachers.

"Hyaa! Ah... this is... s-semen? Amazing... so much... ah, it's hot!"  
"Wah! Over here too!?"  
"Anh!"

The subsequent ejaculations splattered sideways, hitting the stomachs and legs of the art and PE teachers sitting on either side.

"Hey, teacher. Look at that... Hirose-kun's..."  
"...ah...haa..."  
"Teacher! Gendo Maho-sensei!"  
"...hyai!"

Maho, thoroughly coated with Yuu's semen on her skin, wore a dazed expression until the PE teacher beside her shook her violently back to awareness.

On the platform, Mizuki took charge around his crotch. She'd brought a tissue box prepared for this purpose and was cleaning the penis after ejaculation. Mizuki wanted to suck it greedily but restrained herself, only scooping dripping semen with her finger to taste. Seeing this, Misaki and others imitated her, licking and commenting "It's thick" or "Bitterer than I thought." Only Maya remained plastered to Yuu's back, moaning as if masturbating with his back.

The teachers were stunned that Yuu's penis remained erect after ejaculation. Health textbooks stated men need long intervals between erections after ejaculation, recommending only one intercourse per night. For Yuu, the gentle handling by Mizuki's group combined with breasts pressed against his back left no time for arousal to subside. The impatient students waiting their turn - especially Groups 2 and 3 of Class 2 - couldn't contain themselves.

"Hey! Enough already!"  
"It's our turn next!"  
"Hurry up and switch!"  
"Yeah, yeah!"  
"Okay okay, please switch now."

Health teacher Maho stood and clapped her hands, forcing even Mizuki's group to withdraw.

"See you later, Yuu-kun."  
"Yeah. Thanks, Mizuki, and Misaki, Nozomi. Kayoko, Mana, see you. Come on, Maya. The next group is coming, return to your seat."  
"Auuuu. Yuu-kun."

Yuu saw off Group 1 with head pats and shoulder touches before immediately being surrounded by Group 2's six girls.

Maho resumed directing the class. Each group's time was limited to 5 minutes. Complaints arose about the shorter time compared to Group 1, but with 11 groups remaining, it was unavoidable.

Three girls in front and three behind took turns touching every part of Yuu's body - head, neck, shoulders, arms, back, chest, stomach, buttocks, thighs, and especially the crotch - with 12 hands. Yuu didn't just receive touch; he used both hands to touch the girls too, stroking heads and cheeks, necks and backs, and boldly groping breasts and buttocks. He slipped fingers into wet pussies but stopped after one girl trembled and collapsed from clitoral stimulation.

Finally, halfway through (after Class 2), as Class 1 Group 1 began, Yuu approached his limit again. Despite their inexperience, being surrounded by naked girls in 5-minute rotations with constant penis stimulation made it impossible to stay calm after just one ejaculation.

"Haa, haa... ahh, feels so good... au! If you do that..."  
"Nfufu. Yuu-kun!"  
"Your pained face is cute."  
"Does this make you cum?"  
"Please! Let us make you ejaculate!"

Whether planned or competitive with Class 2, the three front girls enveloped the penis from tip to base with their hands and began stroking rapidly. From behind, left and right fingers played with Yuu's nipples while one girl lewdly rubbed his buttocks and began licking his ear.

"Ah, ah, ahh! Already... can't... gonna cum..."

At Yuu's voice, the surrounding girls' eyes glazed over, cheeks flushed, breasts tightened with excitement, and love juices dripped down thighs. The tallest girl pressed against his back from behind, biting his ear while whispering:

"Yuu-kun, I love you. I want to eat every part of you, you're so cute and I love you! Hey, let me see you ejaculate from that big penis!"  
"Ahh!"

Her seductive voice seemed to trigger his limit. The penis being roughly handled by six hands trembled and prepared to release semen. By chance, a gap between fingers near the urethral opening allowed a massive spray to shoot toward a girl's lower abdomen.

Dok! Byukubyuku! Pyurururu!

"Fah! Ahhn! T-this is... ejaculation... haaaaaaa... amazing... so hot... ah... good, good, nfunnn"  
"Ah, lucky! Give me some too!"  
"Me too!"

The girl covered in semen on her lower abdomen had hands reaching for it, but she was beyond caring. The viscous white fluid dripped down toward her delta region, feeling indescribably good. When she rubbed it into her soaked vagina with her own fingers, she came lightly.

"Everyone, we're finished. Hirose-kun, thank you for your hard work."  
"No no. I had a good time too... and learned a lot."

Maho smiled but her eyes unconsciously drifted toward his crotch. After Class 1 Group 1 finished and cleanup, 30 girls from 5 groups had taken turns touching him, so it remained fully erect.

Maho shook her head side to side, looking down as if cutting off her longing, but as she passed by to fetch Yuu's clothes, he took her hand.

"Sensei, I want to ejaculate one last time."  
"No, that's..."  
"If possible, I'd be happy if you gave me fellatio. As a demonstration for the students."

Maho was pulled close face-to-face, then made to touch his erect penis. Feeling the heat and hardness in her hand scattered her intention to end class.

Yuu stood sideways like a statue so students could see the fellatio. Maho knelt before him, lightly gripping the base and bringing her face close. When her nose was centimeters away, the lingering semen smell from two ejaculations made her dizzy.

"Haa~"  
"Fufu. Sensei, you're cute."

Maho sighed unconsciously after sniffing, her face flushed. As she almost nuzzled her cheek against it, Yuu stroking her hair made her snap back to reality.

"Ahem... This is part of a later curriculum, but as a special case today, we'll demonstrate fellatio - a particularly important technique in male stimulation."  
"Yes. Please."

Health classes at Sairei Academy covered mental and physical characteristics of both genders, physiological phenomena, relationship precautions, skin contact techniques like kissing, and ultimately intercourse, pregnancy, and childbirth in detail. Though most students under 18 actively absorbed sexual knowledge from adult media in this world too, school remained a place for balanced, orthodox learning.

As health teacher, Maho remained a virgin with pure private relationships. She'd only touched real penises during training, relying on book knowledge. She'd enthusiastically practiced on various models, but this was her first real penis - and larger than training tools, making her nervous.

"Lero, lero... chu, leroo... nk, nn, nn, nfuu... lero, n... leroo... afu... nnn!"

She licked upward from near the base with her tongue. Unlike smooth dildos, Yuu's penis felt rough and bumpy, making her unsure of her technique. Yuu noticed her inexperience but didn't point it out, gently stroking her head with one hand while groping her ample breasts with the other.

"Maho-sensei, moving your right hand slowly would be good. Yes. And lick the tip with chu, chu sounds. Ahh! That's good, licking like that feels amazing. As expected of sensei, you're skilled."

Yuu guided her with soft requests, overreacting occasionally to encourage her. Maho happily grew more enthusiastic, her right hand stroking nonstop while her tongue grew bolder, licking the glans with wide-open mouth. Saliva coated Yuu's penis until it shone.

Maho's fellatio skills rapidly improved with Yuu's positive reactions. Then Yuu made a request he'd considered from the start.

"You know, there's something I really want you to do."  
"What is it?"  
"Well... I want you to sandwich my penis with your breasts."  
"Huh?"

Paizuri. For Yuu, this ranked high among things he wanted done by busty women. Uncommon in this world where female breasts held less sexual importance, "breast torture" existed as a niche fetish where women restrained men and stimulated them with breasts - including sandwiching penises for ejaculation.

Maho knew the term but never taught it. A male requesting it was unexpected. She hesitated about doing it before students, but Yuu was eager.

"Maho-sensei, try tightening your armpits a bit forward."  
"Hae? Ah, okay."  
"Here we go."

Yuu lowered his hips, pressing his crotch against Maho's breasts as he knelt. Supporting her back so she wouldn't fall, his rigid penis slid between her arms emphasizing her breasts.

"Ooh... good... sensei's breasts are the best."

The soft breasts enveloped it, sinking mooshily until most of the shaft was buried in mammary flesh. Unlike the wet tightness of mouths or vaginas, there was no strong constriction. Instead, the warm human skin wrapping around him gave a comforting sensation. Pressing his crotch against a beauty's breasts with the tip facing her mouth also excited Yuu with a sense of dominating her.

Maho didn't understand but felt happy seeing Yuu so pleased. Seeing the precious male symbol buried in what she'd considered excess fat brought perverse joy.

"Sensei, I'll move slowly, so suck the tip. I want to ejaculate like this."  
"Fai... leave it to me. Aaahn."

Yuu began moving his hips in small motions against her lower breasts. Tapun, tapun, her breasts swayed each time. Saliva and pre-ejaculate provided lubrication. With faint nuppu pu sounds, the penis tip emerged from her cleavage where Maho met it with open mouth.

"Amu... nn, nmu, ero... ufu, chupaa... ufu, ohinpoo... nn, nn, hamureroo... chupu..."  
"Ku... Maho-sensei, that feels good... ahh!"

Maho's dazed face stayed mouth-open as the penis moved in and out. Though only the sensitive tip received stimulation, the wet lips licking and sucking intensely increased Yuu's pleasure.

"Yuu-kun looks so happy."  
"I never knew breasts could be used like that."  
"Could I do it too?"

Students watched the rare paizuri with intense focus, especially bustier ones who happily imagined new possibilities for their bodies, hugging their own breasts.

The class-ending chime had rung, but they continued until Yuu ejaculated. After 5-10 minutes of rhythmic thrusting, Yuu felt tingling pleasure and sped up.

"Sensei... I'm about... hau! G-gonna cum"  
"Nn, nuuun..."  
"I'll ejaculate like this, swallow it!"  
"Vnnn!"

Near climax, Yuu almost stopped moving, keeping the tip inside Maho's mouth while pressing her head down. As she sucked chu-chu on the glans while using her tongue, he finally reached the limit.

"V! Ahh! E-ejaculating!"  
"Nfuu!?"

Yuu unleashed his third load since class began into Maho's mouth. Wide-eyed at the first impact, Maho swallowed with Yuu holding her head. But she couldn't contain the continuous flow, choking as it overflowed and dripped down her cleavage.

---

### Author's Afterword

I really wanted to pick a representative (like Maho) and go all the way to actual intercourse. But for this class, we ended with paizuri ejaculation. If there's a chance later, I'd like to try public breeding sex. As long as Yuu is at this school, it might be possible.

### Chapter Translation Notes
- Translated "我慢汁" as "pre-ejaculate fluid" maintaining explicit terminology
- Transliterated sound effects: "ちゅぱちゅぱ" → "chupa chupa", "びゅるっと" → "splurt"
- Preserved Japanese honorifics (-kun, -sensei) per style rules
- Translated sexual terms explicitly: "パイズリ" → "paizuri", "射精" → "ejaculate"
- Maintained Japanese name order (e.g., "小川 瑞希" → "Ogawa Mizuki")
- Italicized implied internal reactions (e.g., Maho's dazed state)
- Used direct anatomical terms: "チンポ" → "penis", "おっぱい" → "breasts"