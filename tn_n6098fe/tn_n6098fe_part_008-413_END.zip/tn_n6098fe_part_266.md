## 250. Sports Festival ① ~Hope It's Sunny~

### Author's Preface

When it comes to major high school events, the sports festival and cultural festival are indispensable.

Recently, some schools hold their sports festivals in May or June, but Sairei Academy has opted for the conventional October schedule.

Thus, we'll be taking a break from explicit erotic content for a while, but in its place, please enjoy imagining the scenes featuring the many high school girls in bloomers, which have gone extinct in reality.

---

"The past week saw mostly cloudy days with light rain, but today has cleared up beautifully, making perfect weather for the sports festival. This is surely thanks to everyone's daily diligence.

Starting this year, all male students will participate, and I'm truly delighted that we can hold a sports festival that genuinely represents all of Sairei Academy. For this day, the sports festival executive committee has diligently prepared, and students have practiced repeatedly during limited time in PE classes and breaks. Today, let's unite beyond grade levels and demonstrate the fruits of our practice.

The sports festival comes only once a year. Especially for third-years, today is their final high school sports festival. Let's fully enjoy where we should enjoy, fully compete where we should compete, and fully cheer where we should cheer - together creating a wonderful sports festival!"

As Yuu finished his speech as student council president, thunderous applause erupted. The difference compared to the principal's earlier speech was like night and day. The principal herself seemed aware of this, offering a wry smile. Personally, Yuu preferred the relatively concise principal over the long-winded chairperson on such occasions.

After stepping down from the podium, Yuu bowed toward the tents on both sides (where teachers and guests were seated). Both sides returned his greeting. There were two guest tents - the nearer one held older women including directors from the Ayakuni Group (the chairperson herself had unavoidable business and would arrive in the afternoon), prefectural board of education members, and local politicians. Exceptions were the specially invited Toyoda Satsuki, Fujiki Hiromi, and several other staff from the Toyoda Sakuya Memorial Foundation. As Yuu's handlers, they now participate in school-related events.

The adjacent tent held the full student councils from sister schools Saibo Academy, Saiai Academy, and Saiei Academy. Previously at the student council presidents' meeting, Yuu had mentioned considering coeducation in the near future. They were invited today for reference.

Saibo Academy's student council, led by president Aizawa Midori, gave a serious impression - reinforced by their plain hairstyles and over half wearing glasses - and bowed deeply with perfect etiquette.

Saiai Academy's student council, with president Hinuma Shuri herself shouting "Yuu-kun, you're wonderful!", appeared lively and flashy overall. While Saibo represented typical serious girls, Saiai leaned more toward the gal style. Though not extreme with monstrously heavy makeup, they were beautiful gals that Yuu appreciated, starting with Shuri.

The hardest to read was Saiei Academy's student council. Though some had un-Japanese features, unlike the previous generation they remained quiet and didn't make noise. President Mikageishi Mayo waved slightly at Yuu. Her expression remained hard to read behind the long, straight black hair covering half her face. Yuu spotted familiar faces: Zusho Miyuki and Aizawa Keiko, the secretary and accountant who'd been obedient from the start when he was taken to the basement, thus spared from punishment sex. They seemed to have retained their positions since they hadn't sided with the previous president and experienced members were needed. Both clearly looked delighted to see Yuu.

Regarding allowing external spectators at the sports festival? Until last year, even parents were excluded except for special invitees. After thorough discussion between the student council and executive committee, they decided to follow precedent due to security concerns. With Yuu as student council president making the school nationally known, outsiders might flood in - some possibly impersonating parents or school staff. Thus, security was strengthened beyond previous years. In exchange, parents would likely be invited to the cultural festival after advance applications.

Several media outlets had also requested coverage - unusual for a high school sports festival. After discussions with the school and foundation, only Weekly Fuji (which previously conducted Yuu's exclusive interview) and local Saito News were permitted. They agreed to blur faces of male students other than Yuu in photos.

"Next, the sports festival executive committee chair will explain the program. Please refer to the program in your hands."

Rustling paper sounds filled the air as everyone looked at their distributed programs. The committee chair on the podium was the former soccer team captain. The committee was mainly composed of retired third-year club members like her.

"Events marked with ★ at the top of the competition list are class-vs-class events where points are added based on placement. The top class in each grade will receive rewards, so please do your best. Also, events marked with ◎ are joint competitions where PE course and male classes participate. Though no points are awarded, please enjoy them together."

In previous years, there were only scored class competitions and non-scored free events. Naturally, the sports-specialized PE course classes couldn't fairly compete against regular classes, so they were excluded from competitive events. While they provided highlights, over half the participating boys typically lacked motivation, with many PE first and second-years avoiding participation to prevent injuries that might affect club activities.

This year, with mandatory male participation, each boy would participate in 2-3 mixed events. Girls too - third-years from both regular and PE courses must join 2 events, while first and second-years could join 1-2 events - so everyone was highly motivated.

Other free events included club-vs-club races in uniforms and subject-based costume races by teachers.

After radio calisthenics, everyone returned to their assigned class seats except for event staff who took positions on the field. The first events were the 100m and 200m dashes on the straight course before headquarters. Being class competitions, each class sent their fastest runners, and cheers were loud.

Once events began, Yuu had little to do as student council president. He'd only consult with executive committee members if unexpected situations arose. Yuu himself had one event each in the morning and afternoon, but for now he watched from the headquarters tent with the entire student council.

Incidentally, with today's clear skies and rising temperatures, all girls wore short-sleeved gym uniforms with bloomers. Though extinct in his previous life, the bloomers that fit snugly on hips and exposed plump thighs still existed here. When Yuu first saw this sight after enrollment, he felt truly grateful for his rebirth and coeducation. From this VIP seat, he could freely admire the view while being surrounded - leaving Yuu thoroughly satisfied.

All students wore colored headbands representing their classes: Class 1 = red, 2 = blue, 3 = yellow, 4 = green, 5 = pink, 6 = light blue, 7 (PE course) = white, males = black.

As competitions progressed smoothly, Yuu chatted with student council officers like Emi and Kiriko. Then two third-years approached.

""Yuu-kun!""

"Ah, Sayaka, Riko!"

""""Wah! Senpai!""""

Anticipating many girls wanting to visit headquarters because of Yuu, the student council and executive committee had added rules against unnecessary visits. But as former student council members, Sayaka and Riko were exceptions. The third-year executive committee members knew them from student council days, and current members all welcomed them. Of course, they hadn't come just to chat with their fiancé Yuu.

"There was a suspicious van parked on the west road, apparently filming over the fence."

"And there was an intruder near the cultural club building on the north side. Several people subdued them and handed them to external security. I think we should strengthen security there."

Even after retiring from student council, Sayaka remained popular, with friends and juniors sharing information when passing by.

"That's... thank you for the information. Kiriko."

"Right. I'll inform the security team."

Vice president Kiriko ran to the security headquarters tent separate from the main one. With their business concluded, Sayaka and Riko tried to leave but were stopped by Yuu and student council members for some small talk.

"Yuu-kun. Your opening speech was impressive."

"Fufu, has our president already grown into his role?"

"N-no, not at all. Compared to Sayaka, I'm still lacking. Honestly, my hands were shaking from nerves."

Though accustomed to interacting with multiple women, addressing large crowds at school events still made Yuu nervous. In that regard, Sayaka had been much more composed.

"Honestly, I think everyone's going easy on me because I'm male. I wish I could've observed student council president Sayaka up close as a model."

""Yuu-kun"""

However much life experience he possessed, some innate qualities couldn't be matched. Yuu felt Sayaka was far more suited to leadership. That Sayaka heard his quiet moment of vulnerability - something only possible with her - as Yuu maintained his presidential composure daily. Sayaka simply smiled silently and stretched slightly to pat Yuu's head.

"I am myself, and Yuu-kun is Yuu-kun. You don't need to imitate anyone. There are things only you can do as student council president."

"Exactly. Your broad-mindedness in accepting anyone is what's truly precious to us girls."

Riko joined in patting Yuu's head. Though they acted spoiled in bed, they were reliable senpais in student council matters.

"Thank you, Sayaka, Riko."

Yuu pulled both close with his arms. Naturally, both wore short-sleeved gym uniforms and bloomers. Sayaka from the humanities class wore a blue headband with her hair in a ponytail, her dignified appearance polished to give a warrior-like impression. Riko from the science class wore a pink headband, her usual unruly black hair tied around shoulder-length and hanging forward. Her hair had grown since first term, now reaching her chest.

To strangers it might be unnoticeable, but up close their bellies showed slight protrusions at five months pregnant. Yuu almost reached for them but noticed the surrounding stares. Emi grinned knowingly, Yoshie's eyes sparkled as if witnessing something sacred, while Sayori and Nana clearly wanted to join. Not just the student council - nearby executive committee members and even teachers were watching. Yuu, Sayaka, and Riko hastily separated.

"Ahem, so... what events are you participating in, Yuu-kun?"

"Well..."

"Big brother is in the ball-toss this morning and the centipede race this afternoon!"

Before Yuu could answer, Nana replied without looking. Not just Nana - the entire student council knew Yuu's events. Hearing this, Sayaka and Riko's eyes sparkled.

"We're also in the ball-toss."

"Fufu, really? With Yuu-kun... I'm looking forward to it."

"Um... go easy on me..."

Yuu knew this wasn't the typical ball-toss seen at sports festivals, as he'd proposed a special mixed-gender version. Though in stable condition, the pregnant pair weren't participating in class competitions. While sports-averse Riko welcomed this, sports-loving Sayaka seemed disappointed. Thus, knowing they'd join Yuu in the mixed event made them enthusiastic. Yuu sincerely hoped they wouldn't overexert themselves for their babies' sake.

### Chapter Translation Notes
- Translated "体育祭" as "sports festival" to match common Japanese school event terminology
- Preserved Japanese honorifics (-kun, -san) and name order (e.g., Komatsu Sayaka)
- Translated "ブルマー" as "bloomers" to maintain cultural specificity of the gym attire
- Rendered internal monologue in italics (*This is concerning.*)
- Transliterated sound effects (e.g., "bashabasha" for ばさばさ)
- Translated "玉入れ" as "ball-toss" for the traditional festival game
- Translated "ムカデ競争" as "centipede race" for the multi-person race event
- Maintained explicit anatomical terms ("plump thighs") per style guide
- Used gender-neutral "they/them" when original Japanese omitted subjects
- Formally translated professional titles ("prefectural board of education")
- Applied dialogue formatting rules: new paragraph per speaker except with attribution