## 251. Sports Festival ② ~Chasing After Him~

### Author's Preface

Initially, I thought I'd wrap up the sports festival arc quickly, but as I imagined the mixed-gender competitions in this chastity reversal world, I got carried away and ended up writing more than expected.

---

Ball-toss is a popular event at sports festivals.  
A basket is attached to the top of a pole at a certain height, with an attendant holding its base.  
Participants throw beanbag-like balls into it from around the pole.  
They compete to see how many they can land within a set time.  

However, the ball-toss adopted at Sairei Academy's sports festival as a mixed-gender event is unique.  
Boys run around carrying farmwork-style baskets on their backs while groups of girls chase them to throw balls in.  

It's structured as a grade-level competition, starting with six boys selected from the first-year class, chased by seventy-two third-year girls.  
Second-year boys are chased by first-year girls, and third-year boys by second-year girls.  
Essentially, it incorporates tag elements.  

The time limit is two minutes.  
(We tested with Yuu carrying the basket while student council and executive committee members chased. One minute felt too short, while three minutes would exhaust boys besides Yuu, so we compromised.)  
Rules prohibit girls from immobilizing boys by grabbing arms (surrounding from three directions or light touching while moving is permitted).  
Boys cannot face back-to-back or deliberately look down to spill basket contents. Boys must move within the track while carrying baskets.  

"Alright, let's go."  
"O-okay."  
""""""......""""""  

The six basket-carriers selected from Class 1-5 included Yuu and other relatively fast runners.  
Among them was Hosho Haruto from the back row who'd become friendly with Yuu, all unable to hide their nervousness.  
Though a competition, facing pursuit from seventy-two third-year girls—mixed classes judging by headbands, including about ten white-banded PE course students—was intimidating.  
Third-year girls were already positioned around the track perimeter.  
Among them was Sayaka chatting with Riko and others, though to the boys it resembled tactical planning to corner them.  
Heading toward the track center, Yuu lightly patted his classmates' shoulders.  

"Getting balls in your basket is inevitable. Girls outnumber us drastically, and PE course girls are fast too. Let's take it easy."  
"Y-yeah. Take it easy."  

Despite saying this, Yuu intended to struggle against easy scoring.  
He planned to run seriously while suggesting tactics to classmates:  
"Scatter immediately! Don't stay clustered!"  

"Chasing boys to put balls in feels kinda lewd."  
"Good grief... but I get the appeal!"  
"Group-chasing first-year boys seems cruel..."  
"Look! Yuu-kun's there!"  
""""Ooh!""""  

Third-year girls spotting Yuu grew excited, but Sayaka and Riko remained calm.  

"Proceed as planned."  
"Yes. Let's fill all the boys' baskets, not just Yuu-kun's."  

Yuu wasn't the only strategist—Sayaka's group had prepared too. Riko had coordinated a simple plan during entry positioning.  

"First round: First-year boys versus third-year girls.  
Boys, run your hardest. Girls, chase and throw balls in diligently.  
Follow rules and avoid injuries.  
Begin now. Ready..."  

*Bang!*  

At the starting gun, all girls dashed onto the track. They first gathered balls scattered at midfield, then split: some holding one ball per hand heading straight for boys, others gathering armfuls.  

The six boys hadn't moved yet, observing girls' encircling maneuvers. PE course girls in white headbands led the charge like hunting dogs.  

"Now!"  

At Yuu's shout, the boys scattered in different directions.  
Clustering was disadvantageous—they deliberately ran toward approaching girls, brushed past them, and headed outward.  
After that, improvisation: constantly changing direction without full sprinting, avoiding staying put.  

"Ah!"  
"Missed!"  

Some girls threw at passing or turning boys but missed. The boys cleared the first hurdle.  

Next challenge: passing the ball-gatherer/thrower pairs waiting beyond. Blocking paths was allowed, so two girls spread arms to block Yuu. Dodging sideways risked side attacks while PE girls closed in behind. Yuu charged straight at them.  

"Eh?! Yuu-kun's—"  
"Com-coming this way!?"  
"Let me through!"  

Yuu stopped abruptly, grabbed their reaching hands, folded their arms, and slipped through. Stunned by the hand-holding, they missed throwing chances.  

*(Being chased like this without real danger isn't bad.)*  

Moving counterclockwise along the track edge, Yuu enjoyed himself. This was sports, not predation—though he wouldn't mind being mobbed by bloomer-clad girls.  

He'd nearly been surrounded multiple times but escaped with explosive speed. Few balls had likely entered his basket thanks to zigzag running and path selection. Sometimes he cut behind other boys to disrupt throws.  

Though separated, girls executed Riko's plan: six groups of 2-3 fast chasers herding boys toward clusters. Yuu countered by running straight at his white-headband pursuer—ball-less after her first throw.  

But approaching halftime, more girls targeted Yuu specifically. Worse, constant erratic running tired him.  

"Trouble!"  

Chased from behind, Yuu saw 5-6 girls approaching diagonally from both sides—a pincer maneuver leaving the front open for concentrated fire. He instantly reacted.  

As diagonal groups 10m away prepared throws, footsteps closed in 2m behind—a tall (~180cm) slender basketball club third-year (no ball in hand).  

"Eh? Whoa!"  

Yuu's sudden turn made them face each other. She couldn't stop mid-sprint, arms flailing as Yuu caught them—resembling a dance pose. Yuu linked hands and spun 180 degrees just as balls flew, most hitting her back.  

"Tch! Got me."  
"As expected of Yuu-kun."  

"Thanks. *Mwah*."  
"Huh?"  

Amid frustrated and admiring shouts, Yuu kissed the blushing basketball player's cheek before escaping. More approached left—including ponytailed Sayaka. As Yuu pivoted to run, he saw Sayaka trip.  

*(Tch! Make it!)*  

Yuu's mind focused solely on preventing Sayaka's fall. He dashed 5m and slid feet-first, catching her in his arms amid dust clouds.  

"Ah...? Yuu...kun?"  
"Gotta be careful, Sayaka."  
""""Yuu-kun!""""  

Riko and others rushed to Yuu cradling Sayaka mid-slide—then grinned.  

"Here!"  
"Me too!"  
"Chance!"  

*Plop plop*—balls entered his basket.  

"Ahh!"  

Yuu yelled as 5-6 balls scored. The scattered group swarmed him. Panicked, Yuu helped Sayaka up and fled while more balls hit his head/legs.  

"Thank you! Yuu-kun, I love you!"  
"Dammit! Me too, Sayaka!"  

Normally girls protected boys—a boy shielding a falling girl was unthinkable. Sayaka gazed at Yuu's retreating back with renewed admiration.  

"Ouch, stings..."  
"Eek, sorry!"  
"Ah, my fault. It's fine, please continue."  
"Y-yes."  

Yuu's knee was scraped bloody from the slide. Unnoticed during the event, surrounding girls caused commotion. Some offered support or stretchers, but Yuu walked to first-aid tent himself.  

After washing off mud, the wound appeared serious—health teacher Kendo Maho and first-aid students (rotating health committee members) paled.  

They suggested bandages, but Yuu opted for large band-aids.  

"Really sorry, Yuu-kun."  

Sayaka looked guilty. Post-treatment, Yuu patted her shoulder.  

"Totally fine. I'm just glad you're okay, Sayaka."  
"But... Yuu-kun."  

Exercise during pregnancy's stable phase is beneficial, and minor falls rarely cause issues pre-labor. Still, Yuu worried about his first impregnated lover and felt protective.  

Sayaka gripped Yuu's hand on her shoulder. Her moist eyes locked with his. Mesmerized, Yuu intertwined their fingers at close range.  

"Sayaka."  
"Yuu-kun."  

"Ahem."  

Riko cleared her throat. Beyond the tent, dozens of third-year girls—participants worried about Yuu's injury—had gathered.  

"Actually, when Yuu-kun slid to save Sayaka, a photographer captured it. They seemed thrilled about 'getting an amazing shot!'"  
"Eh?! Seriously..."  

The photographer wasn't student staff but a pro—likely from Weekly Fuji or Saito News. Kuki Kumiko (Weekly Fuji interviewer) was present.  

"This is bad."  
"If another cool Yuu-kun photo publishes, chaos might follow."  
"I'll absolutely protect Yuu-kun if it does!"  
"Of course I'll help too."  
"M-me too!" "Me too!" "For Yuu-kun!"  

Surrounded by Sayaka, Riko, and cheering third-years, Yuu smiled genuinely.  

Post-ball-toss results: First-year boys tried hard but third-years dominated later. Final: 3rd place—2nd years, 2nd—1st years, 1st—3rd years.  

When Yuu returned from first-aid to headquarters, the other mixed event—three-legged race (F-M-F arm-linking)—had just ended. Class-vs-class obstacle races and tug-of-war followed before lunch.  

---

### Author's Afterword

※Additional note:  
I've added a simplified diagram of Sairei Academy's layout to the "Worldview & Terminology" section for spatial reference.  
It's a basic Excel chart originally for personal use, so please don't expect much—it's just for imagery.  
It might seem underwhelming for a private school since it's based on my alma mater (prefectural public school).

### Chapter Translation Notes
- Translated "玉入れ" as "ball-toss" to match Fixed Reference terminology
- Translated "ブルマー" as "bloomers" preserving cultural specificity of Japanese gym attire
- Transliterated sound effects: "パァン！" → "*Bang!*", "ぽいぽい" → "*plop plop*"
- Preserved Japanese honorifics (-kun) and name order (e.g., "法正 春人" → "Hosho Haruto")
- Translated "ちゅっ" as "*Mwah*" to represent kiss sound effect
- Maintained original dialogue structure with new paragraphs per speaker
- Italicized internal monologues per style guidelines
- Translated "県立" as "prefectural public school" for cultural context