## 252. Sports Festival ③ ~Dear Friends~

The first event after lunch was the borrowing race.

This was also a mixed-gender event, with 140 girls and 20 boys from all three grades participating.

Though called a race, it relied more on luck and quick thinking than speed.

Thus, it seemed many participants were those not skilled at sports.

  

Eight people (seven girls, one boy) started at a time, drawing a tag at the reception desk.

They had to borrow the item written on the tag and return to the reception for approval. That was all.

However, the tags drawn by girls required borrowing a boy himself or a boy's belonging.

Conversely, boys' tags required borrowing a girl herself or a girl's belonging.

  

The first group started, and almost immediately after reading their tags, some hesitated on the spot while others headed straight for the cheering stands.

Then came girls bowing to borrow something from boys or leading them by hand—when borrowing a person, the rule was to come back holding hands.

One hesitant first-year boy stood before his grade's cheering section and called out with hands cupped like a megaphone.

Several girls responded and came forward, making the boy hesitate before choosing the first to raise her hand.

The two shyly held hands and jogged back to the reception.

Such heartwarming scenes continued.

  

Around the fourth group, two girls who drew tags simultaneously were seen running straight toward headquarters.

Though hairstyles differed, their faces and builds were identical, and their exceptionally large breasts shook "burun burun" violently as they approached.

Their large chests didn't make them fast runners, but upon realizing they were heading the same direction, they swung their arms fiercely, racing each other.

  

"Huh? Rui?"  
"Is that... Randou-san?"

  

Kiriko and Yoshie behind Yuu noticed.

Their destination was the headquarters tent—specifically where the student council sat.

Suspecting what was coming, Yuu stood to step forward.

He was currently the only boy at headquarters.

  

"Haah... haah... I'm... first!"  
"Kuh... I won't lose to sis!"

  

The two (Randou Ruika and Yorika sisters) seemed to intensify their efforts upon seeing Yuu, not slowing even at close range.

  

*This might be bad.*

  

Kiriko and Yoshie moved closer to Yuu.

  

"Hey, both of you—stop, stop!"  
"Yuu-kun, come here!"  
"Yuu-kun, please!"  
"Whoa!"

  

As Yuu spread his arms, the two crashed into him almost like embraces.

Being taller and plumply voluptuous than Yuu, their momentum and weight nearly made him fall backward.

But student council members including Kiriko and Yoshie instantly supported him, preventing disaster.

  

  

  

  

""We're truly sorry!""

"You startled me, but it's fine. Come on, your legs are getting dirty—stand up."

  

After being sternly scolded by student council members, the sisters knelt in seiza on the field to apologize.

Yuu thanked the supporting members before helping the sisters up.

  

"So, am I what you're borrowing?"  
""Yes!""

  

Though a year apart, their identical expressions and synchronized speech made them seem like twins.

Different hair lengths barely distinguished them: Ruika had semi-long hair tied in a ponytail reaching her back, while Yorika had a short bob.

  

They simultaneously showed Yuu their tags.  
Ruika's read: "A wonderful boy my age"  
Yorika's simply said: "Prince"

  

"Bzzt! Sis, Yuu-kun's a first-year. Find a second-year boy!"  
"I haven't had my birthday yet—still 16. Yuu-kun is..."  
"I'm already 16."  
"See? Same age!"  
"Eh..."

  

Yuu wondered what would've happened if he hadn't turned 16 yet.  
Perhaps they'd heard from mutual friends like Kiriko.

Meanwhile, Yorika's "Prince" seemed subjective—anyone she deemed suitable would suffice.  
Yuu couldn't help feeling pleased she considered him worthy.

  

"Is it okay for two to borrow the same person?"  
"Hmm, I wonder?"  
"Well, since points aren't involved, why not all three go together?"  
""Yay!""

  

As a gender-interaction event, rules were lenient. Tags weren't difficult.  
Unless clearly wrong—like bringing a blue headband when red was specified—claims were usually accepted.

  

With Yuu's approval, the competing sisters had no choice.  
Ruika stood left, Yorika right.  
Though Ruika had kissed and fondled Yuu's chest in early October, and Yorika had full sex with him during summer break (as one of sixteen), both kept glancing at Yuu's hands.  
But noticing dirt from kneeling, they tried wiping them—only for Yuu to grasp them unhesitatingly.

  

""Yuu-kun?""

"Come closer."  
"Huh?"  
"Whoa!"

  

Instead of simple hand-holding, Yuu interlaced fingers like lovers.  
He lowered their arms straight down, pressing them close.  
With their upper arms flush against Yuu, Ruika and Yorika instantly flushed.

  

"Shall we go?"  
""Yeah.""

  

Breasts pressing against him from both sides, Yuu walked happily with the sisters.  
All three wanted to prolong this happiness rather than rush.

  

"Ruika, Yorika."  
"Huh?"  
"What is it, Yuu-kun?"  
"Thank you for coming straight to me without glancing elsewhere."

  

The sisters looked deeply moved.  
Originally, Yorika hid her camping-night encounter with Yuu until Ruika discovered it—creating tension.  
Learning Ruika had been alone with Yuu in the student council room worsened things.

  

"Next time, let's meet just us three."  
"Ah..."  
"Yeah! Gladly!"  
"Me too!"

  

The atmosphere suggested their sisterly bond would mend through Yuu.

  

Ultimately, three more girls "borrowed" Yuu:  
"A first-year boy I want as a brother"  
"My ideal first-year boy"  
"A brave hero"

The last was ambiguous, but since no girl objected to calling him brave, it was approved.

  

  

  

  

That afternoon, Yuu headed to the entrance for another mixed event: the centipede race.

Four girls and three boys lined vertically: girl-boy-girl-boy-girl-boy-girl.  
All had adjacent ankles tied, hands on the shoulders ahead, advancing in unison.  
The seven-person centipede circled a cone 50 meters away and returned.  
Though simple, mistimed steps caused group collapses.  
Random groupings made it challenging.

  

Like three-legged races, this involved close contact with near-equal gender numbers.  
Thus, participants were lottery-chosen due to high demand.

  

Held by grade, first-years went first.  
Yuu joined group five.

  

"Ah... I wish time would stop now..."  
"Mmm... fuu... m-me too..."

  

The two sandwiching Yuu said this.  
Positioned fifth to seventh by height, Aki Kazumi was ahead, Hiyama Yoko behind.  
Yuu didn't know about fierce behind-the-scenes competition for these spots.  
Besides Yoshie, Kazumi and Yoko were Yuu's earliest friends in Class 1-5, making their placement uncontested.

Pre-race:  
Kazumi—growing her hair since summer—had it tied, the end draped over her shoulder.  
Her exposed nape captivated Yuu as he massaged her shoulders.  
Though hands rested on the boy ahead, Yuu's fingers massaging her neck drew breathy sighs.  
Yoko pressed fully against Yuu, sniffing his hair while gripping his shoulders.

  

"Ready?"  
""""""Yes!""""""

  

Girls replied energetically; boys seemed shyer.  
Other first-year boys weren't accustomed to touching girls.

  

"On your marks..."

  

The starting gun fired.  
All classes began chanting "One, two, one, two" in sync.  
No immediate collapses occurred.  
But before halfway, groups lost balance like dominoes, accompanied by (delighted) shrieks like "Kyaa!" or surprised shouts.

  

Yuu's group progressed smoothly behind Shimozono Kayo's chants.  
Once moving, all focused on synchronization.  
Nearing the red cone, group five led the pack.  
Though part of Yuu wanted an "accident" to fall between girls, winning felt better now.

  

"Turning left now! Small left steps, big right steps!"  
""""Yes!""""  
""""Ooh!""""

  

Circling counterclockwise from the cone's right.  
Just past halfway, the front faltered—the turn's difficulty tripping others too.

  

"Guh!"

  

As Kazumi nearly fell forward, Yuu braced his feet and strengthened his grip.  
His right arm wrapped around her, reaching her chest.

  

"Ahhn!"  
"Yuu-kun!"

  

When Yuu almost lost balance, Yoko supported him—one hand on his stomach, body pressed close.  
Yuu distinctly felt breasts against his back.  
Already intimate with Yuu, Yoko's unrestrained embrace proved effective.  
Though the front three fell, they avoided a full collapse.

  

Group five quickly recovered and took first.  
They finished without further incident.  
Classmates cheered.  
Yoko tagged the next group's lead girl.  
The first team with three groups finished would win.  
Though non-scoring, placement rivalry energized everyone.

  

"Waah!"  
"Kyaa!"  
"Whoops!"

  

Perhaps relieved after finishing, Yuu's group collapsed forward.  
Chain-reaction stumbling nearly caused domino-falling until Yuu deliberately fell sideways to avoid crushing Kazumi.  
But before hitting ground, his stomach was supported—a hand slapped the earth beside him.

  

"Yuu-kun, okay?"

  

Yoko had protected him.

  

The waiting third group surrounded the fallen seven, untying ankle ropes.

  

"Okay?"  
"Here—grab on."

  

Even reserved first-years helped unreservedly now.  
Kayo—at the bottom—was helped up by classmates.  
Her gym uniform was mud-smeared, but she seemed unhurt.  
Yuu worried about Yoko's right hand—she'd slammed her dominant hand down while supporting him.

  

"Yoko!"  
"Huh?"

  

Yuu turned, handling Yoko's hand like treasure.

  

"Not good—your dominant hand matters for basketball! Hurt?"  
"Ah... no. I didn't train for nothing."  
"Good. But I worried you overexerted."

  

Seeing her flex arm and fingers pain-free, Yuu relaxed.

  

"Ah, but I had to protect Yuu-kun..."  
"Thank you, Yoko. You really saved me."  
"Hey, you two—holding hands forever?"

  

Kazumi's remark made Yuu realize he still held Yoko's hand.  
Unembarrassed, he grasped Kazumi's too.  
Though both blushed, Yuu led them to the first group's waiting area.

  

Initially reserved, cooperation in winning seemed to bond everyone—all smiled, distances shortened.  
Even non-Yuu boys chatted amiably with girls.  
To Yuu, this embodied co-ed ideals.  
His past high school lacked a girlfriend, but event interactions created happy memories.

  

He'd heard boys' schools had few events like this.  
Nearly half the teachers were male; female teachers were over 50.  
Isolated from outsiders, they spent adolescence only with boys.  
Such gray youth felt wrong.  
Boys' school graduates avoided women until state-matched marriages at 25 for childbearing duties—unlike co-ed graduates who dated and chose partners freely.

  

Sandwiched between Kazumi and Yoko, Yuu chatted with them and centipede teammates.  
He reaffirmed his desire to spread this nationwide.

  

  

  

  

---

### Author's Afterword

I wanted to realize a threesome with the Randou sisters (Ruika from Chapter 240 and Yorika from Chapter 136), but lacking immediate opportunity, I featured them in the borrowing race.

  

I once saw an erotic sports festival doujin CG collection where breast-groping was normal and sex happened—it thrilled me.

I restrained myself in the actual story, but an exaggerated version focusing solely on that might be fun.

The challenge is writing it erotically and engagingly in novel form.

### Chapter Translation Notes
- Translated "借り物競争" as "borrowing race" to maintain event clarity
- Transliterated sound effects: "ぶるんぶるん" → "burun burun" (breast movement), "はぁ、はぁ" → "Haah... haah" (heavy breathing)
- Preserved Japanese honorifics (-kun, -san) and name order per style guide
- Translated "恋人繋ぎ" as "interlaced fingers like lovers" for cultural accuracy
- Rendered simultaneous dialogue with double quotes: ""We're truly sorry!""
- Translated "正座" as "kneeled in seiza" with implicit cultural context
- Used explicit anatomical terms ("breasts," "sex") per fixed style rules
- Maintained original paragraph breaks for dialogue and action sequences