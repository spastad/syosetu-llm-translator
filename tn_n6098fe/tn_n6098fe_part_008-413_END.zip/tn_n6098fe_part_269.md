## 253. Sports Festival ④ ~Dangerous Back Alley~

### Author's Preface

This time, Yuu patrols the school grounds.

For reference on the route taken, please see the diagram added in the middle of the "Worldview and Terminology Explanation" section under the entry for Private Sairei Academy High School.

---

"Shall we get going soon?"

"Yeah."

"Ready to go."

"Then, be careful."

It was 2:30 PM, time for the student council patrol.

Since Emi, Mizuki, and Sawa had handled the morning shift, Yuu himself would patrol in the afternoon.

Accompanying him were Kiriko, Yoshie, and Nana.

The route would take them from the headquarters tent set up on the north side of Field 1, south along the eastern edge of the field to the main gate, then clockwise around the school.

They would check on the working conditions of the executive committee members at each station and ensure nothing was amiss. It was expected to take just under an hour.

Meanwhile, events would continue, including club competitions and a costume race by teachers divided by subject, which sounded fun, but patrol was also part of the student council president's duties.

Due to the presence of male student Yuu, a security team from the basketball club accompanied them in case of emergencies.

Six members of the security team, wearing matching happi coats with "Sairei Academy Security Team" written large on the back, were already waiting near the tent.

"Ah, Shiina-senpai. We're counting on you."

"Y-yes... Plea— 'Yuu! Pleasure to meet you!'"

The moment she made eye contact with Yuu, Chizuru blushed and stammered, perhaps remembering their recent intimate encounter, but Connie jumped forward ahead of her.

Her golden ponytail and large breasts jiggled with the motion.

"H-hey!"

"Ufufu. First come, first served."

Not to be outdone by Connie, who had grabbed Yuu's hand first, Chizuru also stepped forward and shook his hand.

Yuu smiled wryly and wrapped both hands around Chizuru's right hand, which seemed to improve her mood.

Not only Chizuru and Connie, but the accompanying security team consisted of four third-years and two second-years from the basketball club's first squad. In other words, they were the same group Yuu had chatted with and repeatedly touched during the recent farewell party.

That made Yuu feel at ease with them.

After shaking hands with everyone, they set off.

"Good work, everyone!"

"Ah, thanks, you too... Whoa?!"

Yuu called out from inside the closed gate, startling the security guards stationed there.

"Any abnormalities?"

"Yes. Things have finally calmed down here. However, we've received reports of suspicious individuals loitering near the fence, so we've increased patrols."

"Understood. Thank you as always. Please continue your good work."

When Yuu bowed his head, the tough-looking security guards broke into smiles.

Even though it was their job, they were happy just to be thanked and appreciated.

The students could enjoy the sports festival safely thanks to the increased security.

Especially this year, with Yuu becoming student council president, the number of women flocking to see him had increased, making their job harder.

Understanding their feelings, Yuu remained polite.

Despite a large sign reading "No Entry by Non-Personnel," many people had apparently demanded entry.

In particular, the media and civic groups with unclear motives—even though the Dankyo Party had declined, radical movements advocating female supremacy hadn't disappeared—had engaged in heated arguments. That's what Emi and the others had reported after their morning patrol.

Most ordinary people seemed to give up and leave upon seeing the closed gate and the guards, but some tried to peek or even climb the fence to break in.

By noon, over 100 such trespassers had been caught—more than during the quiz championship, likely because Yuu and the school's name had become widely known.

Security guards, student security teams, and even students who happened to spot them had restrained the trespassers and handed them over to the police via the guards.

Since it was a Saturday, things had gradually calmed down after peaking around 1 PM.

As they made their way around the field, they called out to and thanked the executive committee members busy carrying equipment or preparing for the next event by drawing lines.

Everyone was surprised to be addressed, but they smiled immediately upon realizing it was Yuu.

For this occasion, Yuu wore a prominent "On Patrol" armband, and the Sairei girls seemed to understand they should look but not call out to him.

After covering a quarter of the perimeter and reaching the west gate, they greeted a security team on patrol and inquired about the situation.

The Field 1 side (south and west) seemed fine, but the east side, surrounded by a thicket that blocked the view and where few students went during the festival, was problematic.

Indeed, nothing happened until they were halfway around.

As they rounded the corner of Building 1 and walked along the back road with the archery range in their peripheral vision, they heard multiple shouts from the thicket.

"Yuu-kun!"

"Hmm."

The tall Kiriko turned her back to Yuu and stepped forward, while Yoshie and Nana moved to his sides.

Chizuru and the others, who had been following closely behind, split into groups of three on each side, surrounding Yuu.

It was a formation designed to protect him.

Yuu couldn't see, but apparently, several women in their 20s and 30s who had climbed over the eastern fence had been subdued by a security team of burly judo club members.

One had tried to escape toward the dormitory but was easily caught.

*(Hmm... This is tough.)*

Security guards patrolled outside—even the police were patrolling this time—and inside, the security teams were working hard to stay vigilant.

But trespassers who slipped through kept trying to break in.

Moreover, covering the entire large campus was difficult.

The physical education department had allocated members to the executive committee, and clubs had organized security teams.

Still, it was the sports festival. Especially for third-years, it was their last one, so they seemed to struggle balancing participation with security duties.

With the intruders taken away, the tension eased, and Yuu's group returned to their positions.

Since seeing Yuu near the fence would be dangerous, they continued along the path behind the building without approaching the fence.

If they took the path between Building 1 and the dormitory/bicycle parking area, they would pass Building 2 (the male students' school building), the pool, the martial arts hall, and reach the tennis courts and outdoor basketball/volleyball courts.

They planned to turn onto the narrow path ahead, emerge onto the road from the main gate, and return to the headquarters tent.

With Yuu leading, the group approached the bicycle parking area.

Turning left there would lead to the east gate, which should be sealed off.

Casually, Yuu glanced toward the bicycle parking area.

As usual, it was mostly filled with students' bicycles.

He thought he saw something moving, hidden behind the bikes.

Suddenly, with a high-pitched "Hyuun!" sound, something flew toward Yuu and the others at high speed.

"Whoa!"

"What was that?"

"Sta—stay alert!"

It didn't hit them directly, but smoke billowed around them, and the smell of gunpowder filled their noses.

They realized someone had shot a rocket firework at them.

Cries of surprise rose, but Chizuru, as squad leader, quickly took charge.

However, several black objects sliding across the ground near Yuu's group emitted thick gray smoke, blocking their view.

A team member who had accidentally inhaled it started coughing.

"Go!"

"Get him—the boy!"

Several small figures leaped out from the bicycle parking area.

*(Children?)*

Realizing something unexpected had happened, Yuu tried to retreat toward Building 1 with Kiriko and the others when he saw them.

They were small girls. Elementary school students, or at most middle schoolers.

"They're just brats!"

One of the unharmed security team members moved to block their path, but the intruders dodged nimbly.

In the poor visibility, catching small, quick children was surprisingly difficult.

Three—no, four children in total—ran straight toward Yuu, holding something in their hands.

"You're not getting through!"

"Guh!"

Connie, the tallest in the group, had long limbs.

Her outstretched foot hooked one intruder's leg, making her fall. Another team member pinned her firmly to the ground.

Chizuru, relatively close to Yuu, grabbed the collar of one who tried to slip past and threw her down.

"There are more!"

"Leave it to me!"

Kiriko stepped in front of Yuu as a shield.

She had been included in the group for this very reason—in case of emergencies.

The one running toward Yuu seemed to be the leader of the four. Though well-built for her age, Kiriko was larger.

"Stop!"

"Get out of my way!"

Kiriko timed her sidestep perfectly to block the intruder completely.

It seemed they would collide head-on.

"Gyah!"

A nasty crackling sound accompanied Kiriko's scream.

With a pained expression, Kiriko collapsed.

The black, rectangular object in the intruder's hand was a stun gun.

"Kiriko!"

Yuu cried out involuntarily.

Simultaneously, he felt anger.

Until now, he had underestimated them because they were children, but they were clearly criminal trespassers.

The leader, who had taken down Kiriko, looked at Yuu with a defiant grin and said:

"If you don't want to get hurt, come quietly... Wha—?!"

For some reason, the leader rolled her eyes and collapsed.

Before Yuu could process what had happened, the last intruder approached him.

"Waaaaaah!"

"Yuu-kun!"

"It's okay. Yoshie, call for help."

The last one was very small, perhaps lower elementary school age.

Her flat chest bore a T-shirt printed with red and gold English letters on a black background. Her twin tails, a mix of red and brown, were disheveled.

Being the smallest and least noticeable, she had avoided capture until now.

But noticing the dark, rectangular object in her right hand, Yuu braced himself without letting his guard down.

He hadn't learned self-defense against children, but he intended to subdue her carefully.

"Let me take pictures!"

"Hmph!"

Yuu lowered his stance and sharply chopped the wrist of her carelessly extended right hand, making her drop the object.

Against a child under ten, he didn't need to fear as long as she had no weapons like knives or stun guns.

He shoulder-tackled the girl, who had stopped from the pain of the chop, and lifted her over his left shoulder.

"Wah wah wah!"

Ignoring the startled girl, Yuu used his right hand to pull down her shorts and underwear together.

Her plump little buttocks were exposed.

"Naughty children get punished!"

He slapped her buttocks hard with his right hand, producing a satisfying "Splat!" sound.

Not just once, but twice, three times in rapid succession.

"Ouch! It hurts!"

"This is what happens when you misbehave!"

Splat! Splat! Splaaat!

With each slap from Yuu's hand, her white buttocks turned red.

"Hyii! I-it huuurts... Stooop... Ah..."

"Still don't get it? Apologize when you do something wrong!"

"Hiiin! So-sorrrrrry!"

When Yoshie returned with a teacher she had found patrolling the building, the scene was chaotic.

Two intruders were pinned to the ground by Chizuru's security team. One was splayed like a frog, while Nana stood over her, kicking her face. The girl on Yuu's shoulder continued to sob and apologize, her bright red buttocks exposed.

"Sorry for showing you such a pathetic sight... and for the trouble."

"Kiriko became my shield. This much is nothing."

After cutting short the patrol, Yuu and the others headed for the first-aid tent via a shortcut.

Yuu supported Kiriko, who had been hit by the stun gun, as they walked.

The electric shock hadn't knocked her out, but the intense pain had immobilized her.

She would recover with time, but they decided it was better to leave the scene quickly and have the first-aid team examine her.

The four child intruders had been restrained by the teachers. They would soon be handed over to the arriving police.

As for the leader who had stunned Kiriko, Nana had apparently kicked her hard in the crotch from behind without a sound.

Though Nana didn't look suited for fighting, she was athletic, and her decisiveness and courage in critical moments might have been inherited from her mother.

Even without testicles, a strong kick to the crotch would hurt.

It was a pain Yuu didn't want to imagine.

The first-aid tent was quiet, with only a few cases like Yuu's scraped and bleeding knee that morning or executive committee members who had accidentally cut their hands while working. There were no serious injuries.

Yuu led Kiriko to a simple examination bed.

"Yuu-kun, I'm fine now."

"It's okay. Don't push yourself. I hope there's no lasting mark."

Yuu carefully helped the taller Kiriko sit on the examination bed, holding her firmly.

The stun gun had hit her side. The area on her gym clothes was visibly blackened.

Touching it would probably hurt, so he only placed his hand on her shoulder.

Though the pain lingered, Kiriko's face flushed bright red from the happiness and embarrassment of being treated so kindly by Yuu.

After entrusting Kiriko to the first-aid team, Yuu returned to the headquarters tent.

Later, they learned that the four women in their 20s and 30s and the children were a mother-child group.

Originally, the mothers were the main actors, and the children were decoys.

The mothers had all carried weapons like knives, stun guns, and what appeared to be police batons, but they were caught immediately after climbing the fence by the burly judo club members guarding the east side.

Left with no choice, the children had hidden and waited for an opportunity. When Yuu's group passed by, they used fireworks to create a distraction and attacked.

Incidentally, only the oldest leader had a small stun gun; the other children carried craft knives, rope, and disposable cameras.

Apparently, they had planned to take Yuu to an inconspicuous spot, strip him naked, and take pictures.

One of the mothers confessed they intended to sell the photos besides keeping them for personal enjoyment.

The mothers insisted they only wanted to take pictures, not rape him.

However, it was a malicious and premeditated crime, and someone had been injured, albeit lightly, so there was no room for leniency.

In fact, the four mothers were from Kumagaya in the northern part of the prefecture and were notorious delinquents locally. They had been arrested before for assault, destruction of property, and even voyeurism and theft targeting men.

After having daughters via artificial insemination, they had lain low for a while but had recently turned to crimes using young children.

Given the severity of their actions, they were deemed irredeemable and would serve long prison sentences.

The oldest child (13) would receive the same sentence as an adult and go to prison. The remaining children, under ten, would be sent to juvenile reformatories.

One more aside.

Mizuki: "The girl Yuu-kun was spanking apparently wet herself right after being put down. She'll definitely awaken to that fetish."

Emi: "The one where pain turns into pleasure? At such a young age?"

Mizuki: "Experiences in childhood are engraved most strongly on the body."

Kiriko: "I get it. That's how you discover masturbation."

Nana: "I want Yuu-nii to spank me. Maybe it feels good to be spanked while everyone watches."

Sawa: "You really are..."

Yoshie: "I'm a little interested too. Yuu-kun is always gentle, but I'd like to be treated roughly sometimes. Don't you feel that way, Sawa?"

Sawa: "W-well, I don't particularly..."

Nana and Yoshie: "Then let's ask Yuu-kun next time. All three of us together."

Sawa: "Wait a minute!"

### Chapter Translation Notes
- Translated "ガキ" as "brats" to convey the derogatory tone in context
- Translated "スタンガン" as "stun gun" for technical accuracy
- Translated "お仕置き" as "punishment" and described spanking explicitly per style guidelines
- Translated "漏らした" as "wet herself" to maintain explicit bodily description
- Preserved Japanese honorifics (-kun, -senpai, -nii) throughout
- Transliterated sound effects (e.g., "Hyuun!" for ヒューン, "Splat!" for ばちん)
- Maintained original name order for Japanese characters (e.g., Shiina Chizuru)
- Used gender-neutral "child" where appropriate for minor intruders
- Translated explicit anatomical terms directly ("buttocks," "crotch")