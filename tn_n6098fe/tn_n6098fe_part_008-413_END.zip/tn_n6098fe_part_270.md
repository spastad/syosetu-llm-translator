## 254. Sports Festival ⑤ ~Fight!~

When Yuu and the others, who had entrusted Kiriko's treatment to others, arrived at the headquarters tent, the class-vs-class cavalry battle on the field had just ended.

Learning this, Yuu felt extremely disappointed and slumped his shoulders.

While points were at stake, it was a cavalry battle where women fought seriously against each other.

The rule about taking opponents' hats to earn points was the same, but there were additional special rules.

Losing one's hat didn't mean disqualification - the battle continued until the rider fell off. Only when the rider fell were they eliminated.

At the end of the time limit, surviving cavalry units earned high points plus the number of hats they captured.

This meant they fought brutally until physically knocking riders off their mounts.

Hair-pulling was commonplace, and they even tore at each other's gym uniforms - bra and panty flashes were normal, and sometimes even boob slips occurred.

Yuu had been looking forward to seeing women bare their fighting spirit in this event, which was so intense that even boys who saw it every year were taken aback.

---

A 20-minute break began due to preparation time needed for the next event.

During this, the security company manager came to Yuu and apologized with such force it seemed like she might prostrate herself, startling him.

The intruders had struck the moment the patrol passed, managing to invade and attack a male student - moreover, Yuu, the nationally famous student council president. As student council members pointed out, had Yuu been injured, it could have become a serious liability issue for the company.

Yuu never intended to blame the security from the start. Security had been increased for the sports festival. He knew they were doing their best amid unexpectedly large crowds.

While he was worried about Kiriko who got injured, it was only minor since they were children. Had the mother-daughter criminal group attacked together or in full force, Yuu himself might not have escaped unscathed.

At any rate, Yuu told them apologies were unnecessary but requested strengthened security going forward. Police and security would share patrol areas with patrol cars deployed, including the eastern side that was targeted, so it seemed secure.

---

Just as Yuu finished his brief talk with the security chief, the next event was about to begin: the newly introduced Mini-Triathlon.

Thirty athletic competitors would participate: one selected from each class across three grades (three from PE courses) plus three PE teachers.

While no class points were awarded, special prizes awaited the top three finishers.

Though not pre-planned, Yuu was called to the announcer's seat for the occasion.

"I'm Hirose, student council president. The Mini-Triathlon is a new event introduced this year. Please be careful to avoid injuries, aim to complete the course, and do your best everyone!"

"Waaah!" Cheers erupted.

The athletes near the start line, who had been warming up, seemed to have their fighting spirits ignited by Yuu's words. Their outfits differed from earlier - most had tied up their half-sleeve gym shirts and wore school swimsuits underneath. Though similar in color to bloomers, these clung more tightly to the skin. Some wore personal bikinis showing their navels, while others competed in just school swimsuits. This was because they had to traverse a pool-like water tank during the course. With more skin exposed than usual, Yuu found it impossible to look away.

---

The headquarters tent offered premium viewing for all events. Wanting to make the most of it, Yuu stood right at the front edge of the tent rather than sitting. Following his lead, all student council officers except Kiriko (still receiving treatment) lined up in front: Emi and Mizuki on his right, Nana, Yoshie, and Sawa on his left.

The starting gun fired, and the athletes took off simultaneously. First was an 800m run around the track. The group quickly split into a top cluster sprinting ahead and a rear group conserving energy. Among them, one athlete immediately surged to the front.

"Who's that!?"  
"Hayakawa-senpai is dominating as expected!"  
"Sairei's Mach isn't just for show!"

※Mach: From the Celtic goddess known for speed. In this world, used to describe exceptionally fast women.

Hayakawa Ayumu. PE Course 2nd year. The only track team member with nationally competitive speed. Though specializing in sprints, she ranked high even in long-distance and jumping events within her club. Petite but monstrously athletic.

Yuu had become acquainted with her during the quiz championship. Since then, he'd been amazed by her super-high-school-level feats. She didn't participate in sprints because her speed made races uncompetitive - this was her only individual event besides mixed-gender competitions.

*(So beautiful)*

By the time Ayumu passed in front of Yuu after half a lap, she led by a huge margin. Her tank top and shorts track uniform clung tightly to her skin, revealing a honed, razor-sharp physique without an ounce of excess fat. Watching her run with perfect form was moving. Her short hair bordered on boyish, but her baby face was cute. She ran past, slicing through the wind with a smile that showed pure enjoyment.

---

After the 800m run came 100m on unicycles inside the track. Ayumu cleared this effortlessly too. Other athletes handled it well, perhaps due to a week of practice. But several who rushed fell, widening gaps.

Next was a long water tank brought in by heavy machinery - two 10m x 5m tanks connected side-by-side. With waist-deep water and awkward length, it became an underwater walking challenge.

Ayumu, still leading, discarded her shorts just before entering. For a moment, Yuu thought they were white panties, but they might have been bikini bottoms. She chose to walk through the water rather than swim, advancing steadily. When she was halfway through, the second-place athlete - wearing light purple, likely from a sports club - finally arrived.

"Whoa."

Yuu couldn't help but vocalize his awe. Most athletes stripped gym clothes or uniforms before entering, probably to avoid water weight. School swimsuits, competitive swimwear, even bikinis - they entered one after another. Though all were serious without any playfulness, for Yuu it was a visual feast. He regretted not being able to see it up close.

"Wow, amazing!"  
"She's practically superhuman!"

While Yuu watched the group entering the tank, Ayumu had already started the next rock-climbing course. When he looked, she was over halfway up the 3.5m structure built by the organizing committee. The gap with second place kept widening.

After reaching the top, climbers descended the other side. Just before touching ground, they crossed a thick tug-of-war rope via tightrope walking to the finish. Ayumu cleared the tightrope easily and finished far ahead. Thunderous cheers erupted immediately.

Over a minute later, the others finished. PE Course athletes dominated, taking 8 of the top 10 spots - only 7th place went to a PE teacher and 9th to a general course 2nd-year.

---

The top three were brought before the headquarters for an on-site award ceremony.

"Ayumu-senpai, amazing! Not just your speed - your running form was mesmerizing."  
"Ehehe."

Praised by Yuu, Ayumu flashed a bright V-sign with a refreshing smile. When Yuu's gaze dropped unintentionally, he almost stared - the fabric covering her crotch, barely more than panties, was soaked and clearly showed camel toe.

"Congratulations on placing. As the winner, Hayakawa-san, please choose one of three special prizes."

Sawa, the vice president standing beside Yuu, held out three envelopes. The 2nd place soccer club 2nd-year and 3rd place track club 3rd-year watched Ayumu's choice intently.

"Then, I'll..."

Ayumu hesitated briefly but glanced at Yuu and picked the middle envelope.

"「Aah...」"

Sighs escaped the 2nd and 3rd placers. The prizes were: amusement park pair tickets, high-end restaurant pair meal voucher, and a "half-day with the student council president" voucher. Every participant undoubtedly aimed for the last prize. And Ayumu had chosen exactly that.

"When can I use this?"  
"Hmm... Not today, but anytime after tomorrow? We'll coordinate."  
"Got it. I'll use it soon!"  
"Yeah. Looking forward to it."  
"Waha..."

Though Yuu had met Ayumu during the quiz championship, her busy club schedule left little interaction. He genuinely looked forward to spending time with her.

---

The final event was the high-stakes class relay. First up: 1st years.

As selected runners took positions, class cheers intensified. Before this, Classes 1-1 and 1-5 had been neck-and-neck for top class points, with 1-1 slightly leading. The relay would likely decide it.

Just like during the ball games tournament, these two sports-club-heavy classes seemed destined to clash. Sawa (1-1) and Yoshie (1-5) both cheered passionately for their classes. While Yuu remained neutral outwardly, he privately rooted for the familiar 1-5.

The starting gun fired, and first runners took off. Being elite selections, gaps remained small. Surprisingly, last-place Class 1-6 took early lead, with 1-1 and 1-5 in 3rd and 2nd.

The baton passed to second runners. Class 1-5's runner was Nakai Mao. Though a baseball team reserve, Yuu heard she was a speedy outfielder who played in practice games.

"Go Mao!"

Seeing Mao - whom he'd once been intimate with - running desperately with long limbs pumping, Yuu couldn't help but cheer. Perhaps spurred by his voice, Mao surged to overtake 1-6. But Class 1-1's runner chased closely behind. Positions solidified with 1-5 leading as batons passed to third runners.

"Aah... Please, go! Overtake!"  
"Good! Keep it up, keep it up! Hold on!"

Yoshie and Sawa cheered for their classes. Until the final baton pass, 1-5 held the lead, but 1-1 barely snatched first place at the last moment. They maintained the lead through fourth and fifth runners, with 1-5 trailing by just one meter. Gaps behind them widened, narrowing the race to these two classes.

Finally, anchors received batons. Class 1-5's anchor was Yokota Satilat (Satti). Though in general course, she was known as one of the soccer club's fastest wingers. Still, 1-1's anchor was undoubtedly among their top runners too. Both had slender, well-proportioned bodies, with 1-1's anchor slightly taller than 175cm Satti.

At that moment, 1-1 fumbled their baton pass slightly. Class 1-5 passed smoothly to Satti. The gap closed until they seemed neck-and-neck. The 1-1 anchor desperately tried to pull ahead while Satti chased fiercely. Their speeds matched so closely they appeared parallel, but 1-1 might have held a hair's breadth lead.

Just a little more. Yuu clenched his fists. Though he knew favoritism was wrong, when Satti rounded the curve approaching him, he couldn't stop himself.

"Satti! Gooooooooooooooo!!!"

Hearing Yuu's shout, Satti's face lit up with joy as she surged forward. Yuu's cheer seemed to empower her. Gaining a step, Satti pulled ahead while the 1-1 anchor visibly panicked. Desperately pumping limbs to avoid being passed, Satti overtook her as if pushed by an invisible force. Satti maintained her slight lead down the final straight to finish. Class 1-5 had won.

Adding relay points flipped the narrow gap, making 1-5 the overall winner. They avenged their second-place finish in the ball games tournament.

"Thank you! Yuu-kun!"  
"Yuu-kun, that's not fair, is it?"  
"Ah, uh... I couldn't help it..."

Overjoyed, Yoshie hugged his arm. Sawa gripped his shoulder with strong force. Trapped between their contrasting reactions, a flustered Yuu tried to laugh it off, but Sawa was clearly angry - he'd have to apologize seriously later.

---

The 2nd and 3rd-year relays proceeded with equal excitement before finalizing rankings. Before relay excitement faded, closing ceremonies began. Organized smoothly by the committee, Yuu presented awards to winning classes. Representing champion Class 1-5 was class representative Yoshihara Makie.

"Y-Yuu-kun... will you come to the after-party later?"  
"Ah, I have some student council work left, but I'd love to join!"  
"Yes!"

Like during the ball games tournament, winning classes could hold joint after-parties with boys after cleanup. However, security concerns limited it to one hour before dark. Still, getting official mixed-gender interaction time made class competitions fiercer.

Receiving the trophy and shaking Yuu's hand, Makie beamed with genuine happiness.

---

### Author's Afterword

Hayakawa Ayumu, the tomboy track girl who was Yuu's lucky pervert encounter partner in "131. Quiz Championship ④". I wanted her to reappear and finally gave her this sports festival spotlight. Her choosing the "half-day with student council president" prize suggests she's been conscious of Yuu. I'll post their date chapter soon.

Random thoughts: Female track athletes' revealing uniforms and honed physiques are beautiful yet arousing. But such feelings should stay private - either solo or through fiction. Spreading photos with lewd captions or sending edited images to torment real people is going too far (inspired by a recent article). While I enjoy various scenarios in my imagination, real-world actions should be restrained to avoid inviting excessive regulations.

### Chapter Translation Notes
- Translated "ファイト" as "Fight!" preserving the Japanese sports cheer context
- Translated "マッハ" as "Mach" per Fixed Terms reference
- Translated "ボクっ娘" as "tomboy" to convey the masculine speech/gender expression
- Translated "マンスジ" as "camel toe" using explicit anatomical terminology
- Preserved Japanese honorifics (-senpai, -kun) and name order throughout
- Italicized internal monologue *(So beautiful)*
- Used ""..."" formatting for simultaneous sighs from multiple characters