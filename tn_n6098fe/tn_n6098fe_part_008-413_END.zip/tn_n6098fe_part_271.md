## 255. After the Sports Festival ~SWEET MEMORIES~

After seeing off the student councils from sister schools one by one, I helped with cleanup.

Yuu folded the headquarters tent and carried long tables and folding chairs to their designated locations, working alongside student council members and female executive committee members. 

This year's executive committee included one boy from each grade level, but they were only assigned light tasks like document organization. Yuu was the only boy voluntarily working on the field alongside the girls.

As most students had returned to their classrooms and the grounds grew quiet, the cleanup gradually restored the field to its usual state. A slightly lonely feeling settled in, the sign that a day-long festival had ended.

But it wasn't unpleasant to mingle with the female students, lifting things together while chatting as they carried items.

"Hey, Yuu-kun, we're good here now. Shouldn't you head over?"  
"That's right. Yoshie-chan is in Class 5 too, you should go while you can."  
"Huh? Is that really okay?"

When they finished storing the tent equipment in the warehouse, Emi and Mizuki spoke up. Class 1-5, which had won first place, was planning a joint celebration with the boys' class. It might have already started.

Sawa from Class 1, which narrowly missed victory, agreed with an aloof "Why not go already?" Since the student council members were being considerate, Yuu and Yoshie thanked everyone present and decided to slip away early.

***

"Aah, he's finally here!"  
"You're late! Yuu!"  
"Sorry, sorry"  
""""""Yuu-kun!""""""  
"Student council president, thank you for your hard work!"  
"Congratulations to everyone in Class 5 for winning!"  
""""""Thank you!""""""  
"It's definitely thanks to Yuu-kun's cheering"  
"Absolutely!"

When Yuu entered the Class 1-5 classroom, he was immediately surrounded by a crowd of boys and girls. Yoshie seemed to slip away unnoticed to join her friends.

Nearly all of Class 5 was participating in the celebration. Though not mandatory for boys, about 30 had stayed, with only a few going home due to illness. Desks were arranged in two rows forming a = shape when viewed from above. 

Snacks and juice bought for the occasion covered the desks, served buffet-style on paper plates and cups. "Congrats! Class 1-5 Sports Festival Champions!" was written large on the blackboard, with participants' names listed below for each class event. Strangely, Yuu's name appeared under "Special Thanks" surrounded by pink heart marks.

"Yuu-kun, cola, orange, or tea?"  
"I'll take cola, please"  
"Yuu-kun, want some chocolate?"  
"Potato chips too if you'd like"  
"U-um... here's some Bocky"  
"Haha, I can't eat everything at once. Tell you what - open wide, one at a time"  
"Ah... gladly! Here, aaah~"

As expected, Yoko, Kazumi, and the usual group of eight were proactive. But other classmates weren't far behind. Even those who hadn't interacted much before eagerly offered snacks, feeding him directly when asked. Yuu casually placed hands on shoulders or gripped hands tightly during exchanges - all the girls delighted in this proactive skin contact.

"Satilat's run during the relay was amazing!"  
"Well... I got strength from Yuu-kun. It was my best run ever"  
"I know I should stay neutral, but I couldn't help cheering when I saw Satilat"  
"Th-thank you for saying that..."

Satilat's large eyes grew moist as she gazed at Yuu, restraining herself from hugging him right there. Her usually tied-up straight black hair flowed freely, and though her wheat-colored skin normally gave a healthy charm, today she wore it in a one-length style with one side draped forward, looking unusually alluring.

"I worked hard too!"  
"Yeah. That's right. Mao's running was cool too"  
"Right?"

When Mao approached from the side, Yuu touched her slender legs extending from her bloomers and stroked them without hesitation. The casual touch was accepted normally, but Mao blushed and pressed closer, clearly wanting more contact.

"I ran hard in the relay too!"  
"Me too!... even though I got passed"  
"All's well that ends well. Everyone did great!"

Not to be outdone by Satilat and Mao, all relay participants made their appeals. Yuu smiled while touching them and praising their efforts.

***

When things calmed down, Yuu went to a corner and surveyed the room. Rei Higashino, who got along well with Yuu, was being attentively cared for by tall Risa Sato and Miyoko Ukawa flanking him, alternately feeding him snacks and drinks. Masaya Yamada was chatting intimately with a girl from the brass band club - clearly something was developing. Haruto Hosho was chatting happily with three boys and three girls sharing similar athletic interests.

Everyone seemed to be enjoying themselves without exclusion - the ideal co-ed scene. Though girls constantly surrounded Yuu, they seemed mindful not to overcrowd or monopolize him. Yuma and Mashiro had been beside him earlier, but now Yoko and Kazumi had taken their places. Yuu chatted with them while casually stroking hair and touching their bloomer-clad buttocks.

***

"Hey, I'm going to the restroom"  
"Eh..."  
"Yuu-kun, want me to come?"  
"I'll be fine"  
"I see..."

When Shoko Ueno and Kayo Shimozono, now flanking him, looked disappointed, Yuu pulled their waists close with both arms and whispered "Sorry" while breathing into their ears. Leaving the dazed pair, he headed for the exit when Masaya called out.

"Going to the restroom alone? Want me to come?"  
"What're you saying? Stay with your girlfriend"  
"Th-that's not..."

Not planning a group bathroom trip, Yuu teased him. Masaya fell silent while the girl turned bright red. Leaving the blushing pair behind, Yuu stepped into the hallway.

"Come to think of it, this is my first time using this building's restroom"

Yuu murmured as he entered, immediately realizing it was a women's restroom with four stalls instead of urinals. Without gender markers, he hadn't noticed, but the first building wasn't designed for male use. Masaya must have meant the men's room in the second building.

Normally he'd panic, but Yuu stayed calm. In this world, women entering men's rooms were treated as criminals, but men in women's rooms faced no consequences. Besides, no man would deliberately enter one.

"Once in a while is fine"

Too lazy to go to the second building, Yuu decided to use it. Few remained in the building besides the celebrating class. Apart from executive committee members cleaning outside, most classes had left after the festival. Only the distant buzz from Class 5's party could be heard in the quiet.

As Yuu opened the first stall door and saw the closed toilet lid, footsteps suddenly sounded.

""Yuu-kun!""  
"Ah..."

Seeing two girls at the restroom entrance, Yuu felt oddly guilty - probably residual instincts from his old world. The two - Rosa Anzai and Shiori Mano - showed contrasting expressions upon seeing him: Rosa beaming happily, Shiori looking determined. They rushed to Yuu and pushed him into the stall.

***

"Mm, chu, chu, chupaa"  
"Sniff sniff... Yuu-kun's sweat smell... haa, haa"

After locking the door, Rosa and Shiori embraced him. Rosa, about 5cm taller than Yuu, stared at him, confirmed he wasn't resisting, then pressed her lips against his while cradling his head. Shiori, shorter than Yuu, buried her face against his neck, inhaling his scent.

Both were among the sixteen who'd slept with Yuu during the quiz championship overnight stay - his first partners for both. But since then, they'd only exchanged brief hallway greetings, with no sex or even kisses. They'd chased this opportunity, determined not to miss it.

"Hey, my turn now"  
"Geez... fine"  
"Hehe. Yuu-kun~"  
"Ah, Shiori, long time no see"

When Rosa pulled back, Shiori immediately pressed forward. Their alternating kisses grew increasingly bold, tongues soon entwining.

Rosa was Japanese-Italian mixed race. Her stunning figure and fiery red wavy hair marked her as a Latin beauty, radiating sex appeal unbelievable for 16. Shiori was a classic Japanese beauty with straight black hair reaching mid-back and a slender build. During the overnight stay, they'd declared their bra sizes: Rosa E-cup, Shiori B-cup.

Though Rosa seemed cheerful and proactive, she actually possessed Japanese modesty. Shiori, seemingly quiet and proper, hid passionate intensity that sometimes shocked others. Though contrasting like fire and water, both reveled in this time with Yuu.

"Chu, chu... ah, being with Yuu-kun like this!"  
"Un... kissing Yuu-kun feels so good after all"  
"Sorry to both of you. Even when we meet in the hallway, I can't spend proper time with you"  
"It's fine. Right now... I want to kiss you deeply, mm"  
"Hehe. Yuu-kun's... ah!"

While Shiori's left hand had been stroking Yuu's chest, her pinky brushed something hard when it reached his lower abdomen. Even through his half-pants, Yuu's erection was unmistakable.

Hardly surprising - embraced by two bloomer-clad beauties with breasts pressed against him while deep kissing. Yuu smiled while stroking their buttocks.

"Because Rosa and Shiori are so attractive"  
"Yuu-kun!"  
"C-can I touch... it?"  
"Mmm... okay"

Rosa showered Yuu's cheeks with kisses while beaming. Shiori kept her eyes fixed on his crotch as she asked. While their hands worked to remove Yuu's half-pants and trunks, his own hands slid under their bloomers, fingers settling precisely on their clefts. Moisture immediately transferred to his touch.

"Hehe. Both your bloomers are soaked?"  
"Ahhn! Because..."  
"It's Yuu-kun... ah, right there... feels good..."

Rubbing fingers over bloomers, Yuu felt soft, wet pussies through the coarse fabric, fueling his arousal. Slipping fingers under bloomers to touch their panty crotches revealed greater wetness. Rubbing their clefts made Rosa and Shiori writhe and moan.

Meanwhile, their hands relentlessly pushed Yuu's pants down to his knees. When his erect cock sprang free, both gazed at it with rapturous expressions.

"Haaaah~~~"  
"Yuu-kun's... cock"

Just then, the stall door rattled - *gata*.

"I don't think three people should be having sex alone"  
""""Eh?"""

Looking up at the voice, Yuu saw Makie Yoshihara peering over the stall door. Among Class 5's shortest students (under 150cm) alongside Yuma, it was puzzling how she managed this vantage point.

***

Yuu leaving for the restroom was known. (Rosa and Shiori had slipped out unnoticed). When Yuu didn't return after ten minutes, Class 5 girls grew worried but couldn't all leave mid-party. Class reps Yoshie and Makie discussed it and decided Makie and another girl, Emiko Kino, would search.

Hearing voices from the restroom, Makie climbed onto Emiko's shoulders to peek inside.

"Nn... ufuh... noo, I'll melt... desu"  
"Good girl, Makie. Now it's Emiko's turn"  
"Nn"

When Yuu embraced Makie and Emiko for kisses, both melted against him. The rescuers had become captives.

Now seated on the open toilet lid with lower body exposed, Yuu was surrounded by four girls. Rosa diagonally behind him to the right, Shiori to the left. Makie to the front right, Emiko front left. Five people crammed into a stall meant for one - the four girls couldn't sit, instead clinging to Yuu like insects on nectar.

"Ahhaahn! My, my boobs... good, feels good... more, lick more"  
"Churu, lerolero, haamuchu, chu, chupaa... haa, haa, haa... Yuu-kun, Yuu-kun, Yuu-kun, Yuu-kun, Yuu-kun's chest... ahn!"

With Rosa cradling his head, Yuu pressed his face into her voluminous breasts, licking and rolling her nipples with his tongue. Shiori pushed up Yuu's gym shirt to kiss and lick his chest.

"I-it's been a while... but it's amazing"  
"Yeah. So hot and hard... wonderful"

Makie and Emiko clung to Yuu's thighs, faces near his crotch, carefully observing his cock while touching it with fingertips. Yuu's urge to urinate had vanished, replaced by the need to ejaculate. So he asked all four for handjobs. Like Yuu's gym shirt, all four girls now exposed their breasts. Makie had barely-there AA-cups. Emiko had decent-sized breasts, slightly larger than Shiori's.

Busy kissing each in turn while stroking heads and groping breasts with both hands, Yuu's fully erect cock was completely hidden by four hands stroking from tip to ballsack. Since their overnight experience, all four lacked practice, requiring Yuu's guidance.

"Nnfu. Something came out of Yuu-kun's cock?"  
"Nn... let me taste"  
"Ah, no fair! Me too"  
"Kuh, uu... feeling so good... ah, yes, so good!"

Makie and Emiko stroked with overlapping hands while Rosa massaged his balls and Shiori teased the glans with her fingertips. Precum soon leaked out, coating Shiori's fingers. Emiko licked it off first, followed by Makie's tongue.

Pressed against four bloomer-clad girls with gym shirts open while getting a handjob, Yuu's arousal peaked beyond containment.

""Yuu-kun!""  
"Ugh, ahh, I'm cumming! Cumming!"

Rosa cradled Yuu's head between her breasts like a baby while Shiori rubbed her cheek against his chest while handling his cock. Makie and Emiko double-teamed him with handjobs while licking his glans. Amid this, Yuu finally reached his limit, spurting semen powerfully.

""Fuaaah!""

The forceful ejaculation splattered across Makie and Emiko's faces, coating about half each, while Shiori's palm tracing his perineum was also covered. During multiple spurts, Makie and Emiko actively took his cock in their mouths to swallow semen. Rosa and Shiori also pressed close to his crotch, not missing their chance.

"Fuuuu... That felt amazing. Thank you"

Though Yuu thanked them, all were too engrossed with his cock to listen. In the cramped stall, pressed close during cleanup blowjobs, Yuu's cock remained battle-ready. Minutes later, he ejaculated again, covering all four faces and gym shirts in semen. Ultimately, Yuu enjoyed himself with the four until Yoshie, Yoko, and Kazumi arrived as the second group.

***

### Author's Afterword

I was able to bring back the Class 5 girls who first interacted with Yuu in chapters 135-140 during the sports festival. (Including Yorika Randou who appeared in the borrowing race). I personally like the Rosa and Shiori pairing.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" consistent with series terminology for gym shorts
- Translated "おチンポ" as "cock" following explicit terminology rules
- Preserved Japanese honorifics (-kun, -chan) throughout
- Transliterated sound effects (e.g., "gata" for ガタ)
- Maintained original name order (e.g., Anzai Rosa)
- Translated simultaneous dialogue 「「祐君！」」 as ""Yuu-kun!""
- Used explicit anatomical terms ("pussy", "cock", "semen") per style guidelines
- Italicized internal monologue *(This is concerning.)* per formatting rules