## 256. Reward Date ① ~First Date~

On Sunday, October 21, the day after the sports festival, in the afternoon.

After driving southwest from Saito City for about an hour, the mountain range visible from the car window drew noticeably closer, and the road continued as if cutting through small hills.  
The car slowed down upon entering a slightly open basin area that could be considered the foothills of the Chichibu Mountains.  
Apparently, we were near our destination.  

The tall stainless steel walls surrounding the area and a building entirely concealed by gray sheeting indicated ongoing construction.  
However, Yuu and the others' car entered through a gate opened by security guards.  
Though one might expect the interior to be under construction too, there was already a brand-new parking lot and road paved with dark asphalt, painted with vibrant lines.  
At the end of this road stood a semi-cylindrical building about one size larger than a gymnasium.  
Its freshly painted exterior glittered brilliantly in the sunlight.  

"Here? Really?"  
"Yeah. That's what they said. It's not open yet, so we have exclusive use today."  
"Wooow!"  

Not only the regular protection officers Kanako and Touko, but also two veteran protection officers added for outings came in two separate cars.  
The one who immediately approached and spoke to Yuu after getting out of the other car was Hayakawa Ayumu. A second-year in the Physical Education course at Sairei Academy, one year above Yuu.  
They had come for her reward date - the prize she earned by winning the special Mini-Triathlon event at the sports festival.  

Even though it was called a date, Yuu's nationally recognized face and name severely limited their options.  
Setting foot in the city or leisure facilities like amusement parks would likely cause a huge commotion.  
On the other hand, heavy security would ruin the fun.  
Only places with special considerations for men, like the hot spring inn in Nagatoro he visited with his family before, would work. Though he went voluntarily, it was inconvenient.  

Yuu consulted Toyoda Satsuki from the Toyoda Sakuya Memorial Foundation.  
She mentioned a facility in Saitama Prefecture nearing its reopening that could be exclusively reserved now, and managed to arrange access. Having flexible, powerful connections was invaluable.  

The place was originally a hot spring hotel that fell into management difficulties, bought by a tourism company affiliated with a railway company.  
The foundation invested in its revival project and proposed transforming it into a facility where both genders could feel safe.  
The project expanded the hot spring leisure facilities while reducing the hotel portion by about half.  
Though accommodations were available, the main focus became a spa resort for day trips from the metropolitan area to enjoy hot springs and heated pools.  

Exterior and interior renovations were complete for the November 1 opening.  
Contractors were still working at the hotel section today, but the building Yuu and Ayumu were heading to had only minimal operational staff and security - truly exclusive access.  
However, with no staff present, the shops and restaurants couldn't be used.  
They had lunch before departure and stopped at a convenience store on the way to buy snacks.  
Incidentally, what Ayumu bought herself was all meat - chicken, frankfurters, croquettes. She must burn off fat through daily training.  

"Waaah~ The view is nice, and the air feels delicious somehow~"  
"Ah, yeah."  
"Yahoo!"  

Though only an hour, Ayumu seemed bored in the car and delighted to be in a wide-open space. Holding her convenience store plastic bag, she spun around and jumped for no reason.  
Yuu was concerned about the bag's contents.  

*(Still...)*  

Yuu observed Ayumu's constant movement.  
Her very short hair, boyish enough to be mistaken for a boy, hadn't changed since their first meeting at the quiz championship.  
Perhaps not prone to tanning, she had fair skin with well-defined features.  
To strangers, she might seem like a boyish girl or a boy - a neutral impression.  
But if dressed in feminine clothes like a pale-colored dress, she'd transform into an attractive girl.  

Yuu had assumed girls dress up for dates.  
Moreover, he heard this was Ayumu's first date despite her track-focused lifestyle...  
Surely she wouldn't wear her jersey, even if changing inside.  
Yet she wore a white jersey with purple stripes, "Sairei Academy" emblazoned on the back, and "Track Team Hayakawa" embroidered on the left chest.  
A full-fledged jock girl. Worse than Yuu's pre-reincarnation self who lacked fashion confidence. Now he'd improved slightly by consulting his mother, sister, and Sayaka.  

"Hayakawa-senpai, let's go."  
"Yup!"  

Yuu called out with a wry smile at Ayumu jumping like a child. Satisfied, she dashed over at incredible speed.  
Then she finally noticed the difference between Yuu's outfit and hers.  
Yuu wore a black jacket with khaki cotton pants, plus the hat and sunglasses he got for his birthday - increasingly important accessories.  

"Was the jersey a bad choice? I don't have many clothes."  
"It's fine. I don't mind at all. Besides, I'll change inside anyway. Come on, let's go!"  

Though belated, Yuu acted unconcerned. He didn't want to make her feel awkward from the start.  
Taking Ayumu's hand, he headed for the entrance.  
Holding hands, Ayumu smiled happily.  

"Good afternoon. Thank you for having us today."  
"Heya, thanks for having us!"  

As Yuu and Ayumu greeted energetically at the main entrance, the elderly female security guard standing sentry looked slightly surprised but returned the greeting.  
She was probably told they were inspection proxies for the new management.  

The protection officers split into pairs to guard the main entrance and staff entrance.  
Yuu smiled his best smile while entrusting their security to the four officers for their exclusive playtime.  

The first floor had restaurants, lounges, and an amusement floor with arcades, karaoke, and billiards, but half the lights were off, making it dim.  
The second floor had a heated pool, and the third had a hot spring floor (semi-outdoor with retractable roof).  
After checking the map, Yuu asked Ayumu:  

"Where do you want to go first, senpai?"  
"It's obvious! Swim in the pool!"  
"Haha, thought you'd say that."  

Ayumu had already let go of the hand she'd held moments before, radiating eagerness to go to the second floor.  
Yuu smiled at her desire to move thoroughly, though privately thinking keeping up would require stamina.  
Ayumu started walking first, then turned back to Yuu.  

"Hey hey."  
"Yeah?"  
"Skip the formal 'senpai' stuff today. Call me by name."  

Though sports clubs seemed strict about age differences, Sairei's PE girls Yuu knew weren't like that.  
Maybe because he was male. Regardless, what to call her?  
"Ayumu-san" felt distant. But would "Ayumu" without honorifics be okay?  

"Ayu is fine. In exchange, can I call you Yuu? Kinda similar, right?"  
"Nice idea. Ayu."  
"Right! Yuu!"  

Beaming, Ayumu took the stairs two at a time.  
But did she know the way? Yuu hurried after her.  

Neither brought swimwear since rentals were available.  
Yuu exited the changing room first, but Ayumu soon followed.  

""Huh?""  

They exclaimed simultaneously, surprised by each other's unexpected swimwear.  

"Yuu, that's way too bold."  
"Ayu, you're unexpectedly daring too."  

At the Hakone hot spring resort, Yuu reluctantly covered his chest, but with only Ayumu here, he chose trunk-style swim shorts only, leaving his chest bare.  
Normal swimwear to him, but in this world, it resembled topless women in his previous life.  

Meanwhile, Yuu expected Ayumu to choose a competition swimsuit, but she wore a pure white bikini.  
Just two small triangular cloth pieces tied with strings, but her small bust filled it adequately.  
On someone like Martina, it would become a micro-bikini barely covering the breasts.  
Instead, Yuu was captivated by her perfectly toned, athletic body - exactly like female track athletes on TV.  
Not bodybuilder muscles but an athlete's honed, supple physique.  

"Meh, it's exclusive anyway. Let's swim!"  
"Yeah."  

Ayumu had been glancing at Yuu's chest. Trying to hide it, she quickly walked off.  

The pool area was about one size larger than a gymnasium, with a donut-shaped pool.  
Probably meant to be a flowing river pool, but now just filled with water.  
A 20m slide branched off, not quite a waterslide but cleverly using space, ending in the pool.  
In the center was a shallow oval pool, perhaps for toddlers.  
Impressive for an indoor pool.  

"Ooh..."  

Yuu felt his heart leap, not having swum since Hesperis in August.  

"Wait! You gotta stretch properly!"  
"Ah, yes."  

Ayumu moved constantly since leaving the car, so stretching seemed unnecessary, but Yuu humored his PE senpai.  
After 15 minutes of stretching and radio calisthenics, he was lightly sweating and thoroughly warmed up.  
Still, they didn't dive in immediately, first testing the water temperature with their feet.  
Not cold - properly heated as advertised.  
Likely designed for safety, depth reached only Yuu's visible chest level.  

"Ahh, feels great~. Swimming this late in the season."  
"Really."  

As Ayumu swam swiftly, Yuu followed with breaststroke.  
With no one else in the pool, the water was clear.  
This made Ayumu's wide leg spreads during breaststroke quite a view.  

"Hey! Let's play tag!"  
"Tag?"  
"Yeah! I'll chase first, so you run away."  
"Okay."  

After swimming normally to warm up, around one lap, Ayumu turned back.  
Though female, Ayumu was nationally top-ranked.  
On land, Yuu couldn't win, but in water...  
He'd thought that once.  

"Gotcha!"  
"Wh-what?!"  

Yuu started swimming first with a 10m head start.  
He swam crawl at full speed to gain distance, occasionally checking that Ayumu wasn't close.  
Yet suddenly, she touched his back. She must've approached underwater.  

"When did you get close? Had no idea..."  
"Nyehehe."  

Ayumu grinned triumphantly.  
Yuu thought his new body moved well - not slow among boys.  
Could she overwhelm others even in swimming?  
Still, losing so easily hurt his pride.  

"Now it's my turn to chase Ayu."  
"Hehe. Catch me if you can! I'll count to five."  
"You said it!"  

Five seconds seemed generous.  
But true to her word, Ayumu swam exceptionally well.  
Unlike her warm-up swim, she moved smoothly without splashing, almost like an aquatic creature.  
Yuu started swimming crawl after counting, but the gap didn't close - it widened.  

So Yuu devised a plan.  
He got out on the inner side.  
If he couldn't catch her swimming, he'd take land. Fortunately, Ayumu was submerged and hadn't noticed.  
Yuu jogged about one-third around, shortcutting to jump in ahead of her.  

"Pwah!"  

Startled by Yuu suddenly appearing, Ayumu stopped.  
Yuu grabbed her with both hands.  

"Ayu, caught you!"  
"Eh? How?"  
"Couldn't catch you swimming, so I shortcutted."  
"What?! Cheater!"  

Ayumu pounded Yuu's chest but suddenly blushed, realizing she was touching his bare skin.  
Unintentionally, they were embracing face-to-face.  

"Ah! Yuu, let's go to the slide!"  
"Ah, sure. Let's."  

The mood turned slightly awkward, but Ayumu pointed at the slide smiling, so Yuu nodded.  
Her quick recovery was childishly endearing.  

"Yahooooo!"  

Though too small for a proper waterslide with minimal elevation, Ayumu slid down energetically and splashed into the water.  

"So fun! Hey hey, Yuu, come quick!"  
"Haha, okay. Coming."  

After confirming Ayumu finished safely, Yuu sat at the slide's starting point.  
Releasing the handrails, his body slid smoothly down with the flowing water.  

"Whoa! This is..."  

More thrilling than expected. The gently curved slide ended instantly, and Yuu plunged into the water.  

"Wah!"  
"See? Fun, right?"  
"Yeah! Fun!"  
"Let's go again!"  

Whether aware of Yuu's dazzled gaze on her wet body or not, Ayumu invited him smiling.  
Climbing out, Yuu suddenly wondered:  
Unlike large waterslides, was that flimsy fabric really safe?  

With no one else, no waiting - they rotated heavily like children.  
On the fifth turn, as Yuu surfaced after a splashy entry, he noticed.  

"Ah... Ayu"  
"What's wrong, Yuu?"  
"Your chest..."  
"Huh?"  

Ayumu's top had come off, floating on the water while she stood by the pool edge.  
Unaware, she was exposing her modest chest to Yuu.  
About an A-cup. Understandable for a track athlete - smaller is better.  
Even nowadays, some elementary girls are larger.  
Still, a girl's chest - her areolas and nipples were light pink and cute.  

"Here, put it on."  

Yuu picked up the swimsuit to hand to her.  

"Hmm. This is fine. With Yuu."  
"Eh..."  

Knowing women here had no resistance to nudity, Ayumu seemed the same, showing no shyness topless.  
She stood confidently even when viewed frontally, making Yuu blush instead.  

"Then... let's slide together this time."  
"Together? Well, okay."  

Yuu sat at the start holding petite Ayumu from behind.  
She leaned back on Yuu without caution.  
Her exposed upper body pressed close, their skin touching, almost stimulating Yuu's lust.  

*(Hold on. Not time to panic yet.)*  

This was their special date.  
Though considering intimacy, Yuu intended to just play in the pool.  

"On three, I'll let go."  
"Okay."  

Perhaps slightly conscious, Ayumu spoke briefly.  

""Three!"  

Releasing the rails, Yuu wrapped both arms around Ayumu's waist.  
With two people's weight, they slid faster than before.  

The slide ended instantly.  
Holding Ayumu tightly throughout, Yuu plunged into the water.  

"Hey Yuu, something hard was poking my butt?"  
"Ahahaha. Ayu, how about the hot springs upstairs now?"  
"Hmm. Wanted to play more."  
"Come on, let's go!"  

Yuu laughed off his erection - his right hand had touched Ayumu's chest during the slide.  


### Chapter Translation Notes
- Translated "ご褒美デート" as "Reward Date" to maintain prize context
- Preserved Japanese nicknames "Ayu" and "Yuu" per mutual agreement
- Translated "脳筋体育会系女子" as "full-fledged jock girl" to convey athletic stereotype
- Rendered "トランクスタイプのパンツ" as "trunk-style swim shorts" for accuracy
- Kept "Aカップ" as "A-cup" as universal bra size terminology
- Transliterated sound effects: "ぷわぁ" → "Pwah", "バシャン" → "splash"
- Maintained Japanese name order: Hayakawa Ayumu throughout
- Translated "柔軟体操" as "stretching and radio calisthenics" to specify exercise types