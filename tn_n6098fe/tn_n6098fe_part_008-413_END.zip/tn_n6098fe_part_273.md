## 257. Reward Date ② ~Body & Soul~

### Author's Preface

Since I wrote Ayumu's follow-up story at the end, it became slightly longer.

---

After leaving the pool, Yuu and Ayumu showered and went up to the third floor still in their swimwear.  
At least Ayumu put on a top to cover her chest.

The third floor was one-third indoor space with the remainder being an open-air bath.  
However, since it was currently covered by a semi-transparent dome roof, even the open-air bath couldn't offer outdoor views - a shame.  
Instead, hot water flowed through a Japanese-style garden like a river, with colorful flowers providing visual enjoyment.

At first, Ayumu played energetically - swimming in the large bath and splashing in the jet bath. But when holding hands while strolling through the garden, she suddenly became shy.  
Perhaps she was finally becoming conscious of Yuu as a man during their date.  
Finding this amusing, Yuu sprayed water from a stone lion fountain onto her face, sparking a water fight.

---

"Hey hey, no sleeping okay?"  
"Fuuun... feels so good..."

After returning indoors and sweating in the sauna, they soaked side-by-side in lukewarm water.  
Ayumu suddenly fell silent, then her head tilted toward Yuu with a thump.  
Seems drowsiness had overcome her.

"I... haven't relaxed like this in so long... and doing it with Yuu makes it extra fun... thank you, Yuu"  
"You're welcome. But this isn't over yet"  
"Nn~?"

Peering at Ayumu's drooping eyelids, Yuu whispered close to her small ear.

"I still want to try something. We're going down to the first floor this time. Let's go? Ayu"  
"Un... I'll go... with Yuu"

Though she responded, Ayumu still seemed sleepy.  
With a wry smile, Yuu lifted her out of the bath. She remained passive even as he toweled her dry.  
Yuu decided to take the elevator instead of stairs, carrying Ayumu princess-style.  
Her compact frame felt unexpectedly heavy - likely because she was mostly muscle with little fat.  
Ayumu clung to Yuu affectionately as he carried her.

---

"Huh? This place..."  
"This is the relaxation room. The massage area"  
"Massage?"  
"Yeah. I'll give you a massage. Just relax now"  
"Eeh... that's too much"  
"My turn first. Then Ayu's turn. If I have energy left"  
"Nn..."

After laying Ayumu face-down on the treatment table and stroking her head, she gave a small reply and closed her eyes.  
Beyond the large room with standard massage equipment were private rooms - Yuu carried her to the innermost one.  
Having read the facility guide beforehand, Yuu knew this was designed for sensual massage.  
Though typically women perform these on men in this world, Yuu's case was reversed.

He turned on the aroma light on the headboard and turned off the main lights.  
Only the wavering pink glow illuminated Ayumu's innocent sleeping face.  
Simultaneously, a cloyingly sweet fragrance drifted from special aroma oil.  
The guide claimed it came from rare plants historically used for seduction with aphrodisiac effects, but Yuu assumed it was psychological.  
Yet as he inhaled the scent while gazing at Ayumu's vulnerable form - her bikini-clad body bathed in soft light - lust truly welled up inside him.  
But he resisted the urge to pounce like an animal.  
Instead, he opened a semi-transparent container and dripped thick liquid onto Ayumu's back.

"Hyah, cold!"  
"Sorry. It's lubricating lotion"

The guide claimed it would warm the body, induce sweating, and increase sensitivity.  
Yuu spread the lotion over her entire back, gently kneading with his fingertips.  
He also unfastened the strings of her bikini top.

"Nnaa... ahn... feels good, Yuu... nn, uun... getting warm..."  
"Glad to hear. You can sleep if you want"  
"Un..."

Ayumu responded dreamily as Yuu's hands moved from her nape to shoulders, back, and waist.  
Then his hands moved downward.  
Her well-toned legs felt soft when relaxed but firm to the touch.  
He applied lotion while massaging from her inner thighs to calves.  
When he bent her knee and rubbed between her toes, Ayumu moaned - her feet apparently had erogenous zones.

"Nyaa... nn... kuh... there..."  
"Your legs are important. Gotta loosen them up properly"  
"Nn, nn, nfuu... weird..."  
"Now the other leg"  
"Hyauun!"

While massaging between every toe, Ayumu squirmed continuously.  
Though she might not consciously understand why toe-play aroused her, her body clearly reacted.

After finishing both legs, Ayumu's breathing grew ragged.  
Yuu placed hands on her waist and moved along her spine toward her sides.  
This seemed purely pleasurable as Ayumu relaxed.

"Taking this off too"

When Yuu touched her bikini bottom, she didn't resist.  
He slid it down just enough to avoid exposing her genitals, revealing her plump buttocks.  
Dripping fresh lotion, he kneaded the springy, soft flesh.  
He avoided directly touching her anus or genitals while thoroughly working the cheeks.  
The squelching sounds from her cleft as he worked felt obscene.

---

"Turning you over now, okay?"  
"Uun..."

When Yuu lifted her, Ayumu looked up with dazed eyes.  
Her flushed cheeks showed feminine allure rather than her usual boyishness.  
Impulsively, Yuu covered her slightly parted lips.  
Ayumu grasped Yuu's arms tightly without resistance.

"Ahah, my first kiss"  
"Glad it was me?"  
"Un. Happy Yuu was first"  
"My pleasure. But I'll make you feel even better with my special massage"  
"Un, make me feel good"

Her innocent smile was so adorable that Yuu kissed her repeatedly.  
Laying her supine, he removed the troublesome swimwear.  
True to her athlete status, her upper body was toned but her breasts were modest.  
Her pink nipples were small like unopened buds.

He dripped lotion on her abdomen and sides, working it into her muscular frame.  
He had her raise her arms to gently massage her armpits and biceps.  
Facing upward now, Ayumu's breathing grew ragged with soft moans.  
Though avoiding sensitive areas, she seemed aroused simply by Yuu's touch.

Moving to her shoulders and neck, he lifted her chin.

"Ayu, feel good?"  
"Nn, feels good... Yuu's hands... so nice"  
"Fufu, good girl"

After kissing her, he slipped his tongue inside.  
Ayumu flinched momentarily but clung to Yuu's back as their tongues met.

"Nn, nfa, ae... Yuu, yu... u... nn, ero, chupaa... ann, Yuu... nchu, chu, churero, rero, npa... Yuu!"  
"Chu, chu, chup... Ayu's so cute"  
"Cu... cute?"  
"Un, look at this"

Yuu pulled down his still-worn swim trunks.  
He'd been erect since starting the massage.  
Ayumu turned her head and gasped at the sight.

"Wowaa... so huge? Never seen that. Why?"

Her track-focused life seemed to have left her sexually inexperienced.

"Because Ayu's cute and sexy. Because I want to have sex"  
"Sex?"

Despite everything, she didn't seem to grasp the sexual implications.

"Up we go"

Yuu removed his trunks and positioned himself at Ayumu's feet.  
Spreading her legs, he entered the space between them.  
One thrust would achieve penetration.

"Didn't you learn in health class? Putting this in here?"  
"Ah, un. But it's different from what we learned"

School teachings focused on female-led approaches.  
This kiss-and-caress method likely wasn't covered.  
Given her lack of experience, she probably didn't recognize this as sex.

"Umm... Yuu wants to have sex with me?"  
"Un. If Ayu doesn't mind"  
"Okay. Let's have sex. Ah! But pregnancy would be bad"  
"You mean..."  
"Haven't become Japan's best yet. Need another year at least"  
"Got it. Won't cum inside today. When Ayu becomes Japan's best, let's do creampie sex as celebration?"  
"Unn!"

Yuu embraced her small frame and kissed her passionately.  
The lotion made their skin contact slippery and heated, increasing excitement.  
When Yuu extended his tongue, Ayumu actively reciprocated - their slurping saliva echoing.  

Meanwhile, his rock-hard cock pressed against her dripping slit.  
He'd noticed during leg-spreading that the wetness wasn't just lotion but her arousal.  
Her body clearly responded despite her naivety.  

Yuu fought the urge to thrust in immediately.  
Since she was a virgin, he wanted her to feel more pleasure first.

---

"Aaah! Yuu! Nyaa, ah, ah, so much... yah! No... weird... feels hot... coming!"  
"Gonna cum? Don't hold back. Just surrender to the feeling"  
"Aaah! Good! Iinn! Can't... hold back... aah! Ah, ah, agu... nnaaaaaahhhhhh!"

While tweaking one swollen nipple and rolling the other in his mouth, Yuu traced her nearly hairless mound with his middle finger.  
A mere brush against her small clitoris made Ayumu arch violently.  
Pinning down her bucking body, he continued stimulation - bringing her to climax in minutes.

"Wha... what's this... head fuzzy... body floating"  
"You came. Congratulations"  
"I came? I came... ah! Yuu wait... vuaah!"  
"Hohou. Ayu's pussy's flooding"

Seizing her limp state, Yuu inserted a finger into her vagina.  
Her hymen seemed broken by past athletic activity rather than masturbation.  
Though narrow, her well-lubricated canal accepted his finger easily - but immediately clenched tightly.  
The pressure suggested vaginal tightness.  
How much could he loosen her before penetration?

"Aah! Yuu! Inside me... finger... inside... this is... aah, uunnn! Nnn——!"

With little masturbation experience, Ayumu clung to Yuu, burying her face in his chest.  
Initially just tight, her vagina gradually softened as Yuu stimulated her depths and clitoris.  
Juicy squelching accompanied each finger thrust.  
Ayumu wore a pained expression until Yuu kissed her.

"Chu, chu. Ayu, how's your pussy? Foreplay before my cock. Want you feeling amazing"  
"My pussy... ah, ah, hot... so hot! Yuu's finger digging... vuaah! Don't... hyaan!"  
"Close?"  
"Don't... know... aah!"

Suddenly arching her back, Ayumu sprayed fluid.  
Another climax approached.  
Yuu continued fingering through her orgasm.

---

With each thrust of Yuu's hips, wet sounds and Ayumu's moans echoed intermittently.

*(This alone feels amazing. But might as well)*

Though appearing in missionary position, Ayumu's legs were partially closed in a sumata (genital grinding) state.

"Ayu, gonna insert now. Let's become one"  
"Un. I... become one... with Yuu"

After glancing at her innocent smile, Yuu spread her legs fully and positioned his cockhead at her entrance.  
Two orgasms had left her glistening and ready.  

He pushed his hips forward - the glans plunging in.

"Oouh!"  
"Ih! Ah! Aah!"

As expected, her vaginal walls clamped down tightly around his thickness.  
Yuu pistoned shallowly to widen the passage.

"Kaha! Ayu's inside... feels amazing... kuu..."  
"A, a, yu...u... going in... hya, so big... ihyaa!"  
"Sorry. But a bit more... aah! Ayu!"  
"Com...ing... Yuu, Yuu! Hyauu!"

When hitting her depths, Ayumu arched violently.  
Yuu nearly came from the intense pleasure but held back - determined to honor their no-creampie promise.

*(How long can I last?)*

Even motionless, her vaginal folds stimulated his cock.  
Instead of thrusting, Yuu embraced and kissed her.  
Ayumu's arms around his back tightened painfully but relaxed slightly during kissing.  

After deep kissing, drool dripped into Ayumu's half-open mouth when they separated.  
Stroking her head, Yuu whispered.

"Ayu, congratulations. Graduated from virginity. You did well"  
"You know... glad Yuu was first. Hurt a bit but Yuu's so gentle... makes me feel good. Ehehe. Love you"

This time Ayumu initiated a passionate kiss.  
Even accustomed to female attention since rebirth, Yuu felt emotional.  
Involuntarily, his hips moved.

"Aun! Yuu so big inside... ah, ah, moving... aah, oh, sho, amazing! This is... sex..."  
"Ah, no creampie today but someday... let's make babies!"  
"Hah, hah, haan! Let's... make babies... with Yuu! Ann! Inside... rampaging! More than... haa! Amazing... ahhyiin!"

His cock had acclimated and her fluids provided lubrication, allowing faster thrusts.  
Wanting to savor her pussy, Yuu tried slowing down but couldn't stop.  
Slapping hip sounds blended with sticky squelching at their junction.

"Kuh... uu... dangerous, too good. Gonna..."  
"Faah... Yuu too... cumming? Don't hold back"  
"Nn! Okay. Cumming on Ayu's body"

After 5-10 minutes inside a virgin - impressive stamina.  
Yuu slowed his thrusts to avoid creampie.  
He adopted deep, deliberate strokes to prolong pleasure.  
Ayumu's reactions changed.

"Ah, ah, hya... wait... that's sho... amazing! Ran... again... kihyau yo... aah! Ann! Ann! Yuuuu... vuaah, aann! Iinn!"

Chin raised, Ayumu shuddered with intermittent moans. Her grip on Yuu's biceps became painfully tight.  
Yuu believed she'd climax if he continued, but his limit approached.

"A...Ayu! Cumming! Kuh!"  
"Hyahh! Aah, uunnn!"

Withdrawing at the last moment, he pressed against her groin where they'd grinded earlier.  
Ejaculate sprayed powerfully - some hitting her enlarged clitoris making her arch violently.  
A glob of semen splattered from her mouth to chin.  
Continued spurts dotted her throat, chest, and abdomen with white fluid.  
Her body appeared coated with the massive load.

"A, a, aah... amazing, Yuu's seeed? So much... aahn, overflowing..."  
"Ah, sex with Ayu felt so good, came a lot. Now suck this"

Still breathless after her first sex, Ayumu seemed unable to rise.  
Despite her stamina, this differed from athletic exertion.  
As she lay supine, Yuu brought his still-hard cock to her mouth.  
In her dreamlike state, Ayumu obediently took it in her mouth and began sucking.

---

◇ ◆ ◇ ◆ ◇ ◆

---

"Congratulations to Hayakawa Ayumu from Saitama Prefecture's Sairei Academy, third year - winner of the 100m dash at the National High School Track and Field Championships with a new record!"  
"Ah, thank you"  
"Last year Ayumu placed sixth, but this year dominated with overwhelming speed. Would you say you've grown significantly since last year?"  
"Well, yes. My desire to win - to become Japan's best - was stronger this year"  
"I see. Who would you like to share this victory with first? Please face the camera"  
"First, thank you to our club advisor and coach for their passionate guidance. Also to the track team members who practiced with me, and everyone at school who cheered me on. Thank you!"  
"Yes. Thank you ver-"  
"Excuse me, one more thing!"  
"Ah, yes?"  
"Yuu! I became Japan's best! Let's have baby-making sex like promised!"

After reciting scripted lines, Ayumu flashed a triumphant smile and peace sign.  
The live broadcast caused nationwide uproar.  
Track officials planning to invite her to national training camp were especially shocked.

Meanwhile, at Sairei Academy, everyone from students to faculty simply nodded: "Of course it's Yuu-kun" or "Naturally Hirose-kun."  
Needless to say, Yuu fulfilled his promise days after the competition.  


### Chapter Translation Notes
- Translated "性感マッサージ" as "sensual massage" to maintain explicit terminology while fitting context
- Preserved Japanese honorifics (-kun) and name order (Hayakawa Ayumu)
- Transliterated sound effects: "ちゅぱちゅぱ" → "chupa chupa", "じゅぷぅ" → "jupuu"
- Translated explicit anatomical terms directly: "チンポ" → "cock", "おマンコ" → "pussy"
- Rendered sexual acts without euphemisms: "素股" → "sumata (genital grinding)", "中出し" → "creampie"
- Maintained original dialogue formatting with new paragraphs for each speaker
- Italicized internal monologue: "（これだけでも...）" → "*(This alone...)*"
- Translated "リラクゼーションルーム" as "relaxation room" since it's a common term, not fictional
- Kept "Japan's best" for "日本一" to reflect athletic achievement context
- Used "baby-making sex" for "子作りセックス" to preserve literal meaning