## 258. Pregnancy Rush ~Papa~

Monday, October 29th, the final week of October.

After school, Yuu was called to the first floor of the second school building. He found himself in a compact faculty room—too small to be called a staff room.

The one who summoned him was the homeroom teacher for the first-year boys' class.

When Yuu entered the faculty room, Kambayashi-sensei—his homeroom teacher—and Tezuka Taeko, the homeroom teacher for Class 1-5, were seated on a small sofa typically used for student consultations.

Among the first-year classes, Yuu was closest with Class 1-5, so he was somewhat acquainted with their homeroom teacher, and he'd also heard about her from Yoko and Kazumi.  
25 years old, single. A chemistry teacher with an intellectual appearance accentuated by silver-framed glasses.  
Being entrusted with homeroom duties in her third year spoke to her teaching excellence. He'd heard she was calm and composed, never raising her voice even when problems arose, instead patiently discussing matters until students were satisfied.  
Though not particularly tall at just under 160cm, she was a beautiful teacher who might resemble Riko in 7-8 years.  
Incidentally, while she wasn't particularly close with any male staff, students could clearly see she had feelings for her colleague Kambayashi-sensei sitting beside her. No special progress seemed to have been made yet, though.

"What's this about today?"  
"Today... it's just a precaution, but there's something we wanted to confirm with you, Hirose-kun."

Yuu sat facing the two teachers. After Kambayashi-sensei's opening remark, he glanced at Taeko.  
Female teachers couldn't enter the second building without special reasons.  
It seemed Taeko had asked Kambayashi-sensei for permission to meet Yuu here.  
However, she appeared hesitant to speak.

"Should I step out?"  
"Eh? N-no... not at all."

Normally, only homeroom teachers for first to third-year boys used this room—all male teachers. The second and third-year homeroom teachers were absent, likely still in their classrooms.

"Kambayashi-sensei should probably hear this too."  
"Understood. Then I'll stay."

When Kambayashi-sensei nodded, Taeko visibly relaxed.

The matter Taeko brought up: Pregnancy reports from her Class 1-5 students. Not just one or two—nine at once.  
Kambayashi-sensei froze in shock, but Yuu took it calmly. He'd expected this might happen soon—if anything, it felt overdue.  
*Though nine at once is more than I anticipated*, he thought.  
The notepad Taeko handed him listed the names in attendance number order:

Aki Kazumi  
Aramaki Yoshie  
Ueno Shoko  
Gotou Mashiro  
Shimozono Kayo  
Hiyama Yoko  
Maegashira Yuma  
Yoshihara Makie  
Randou Yorika  

"Eeeeeeh?! This... could it be... all of them...?"  
"Hirose-kun?"  
"Yes, that's right."

As both teachers stared at him, Yuu nodded.  
Of these, he'd had creampie sex multiple times with Yoko and Kazumi (the first he'd gotten close to), followed by Mashiro and Yuma, then Shoko and Kayo, and Yoshie (now in the student council).  
However, Makie and Yorika had only been with him once—during the quiz championship and school camp night at the lodge—but that single encounter had apparently been enough.

Actually, Yoko and Kazumi had confirmed their pregnancies much earlier but waited to report, anticipating others would come forward.  
Additionally, Yoko (basketball club) and Yuma (table tennis club), though naturally athletic and fast, had withdrawn from class competitions during the recent sports festival due to morning sickness affecting their condition.

Kambayashi-sensei's shock was understandable.  
While this was the first time this academic year, past records showed first-year girls getting pregnant—cross-grade interactions happened through clubs. Still, it was usually only a few per year.  
Nine simultaneously in one first-year class was unprecedented.  
All nine had confirmed at obstetric clinics and could provide proof if needed. Taeko knew how close her students were with Yuu and never doubted their claims.

"Wow... incredible. Hahaha..."  
"I knew Hirose-kun was popular with girls. I was shocked when he got three former student council members pregnant and engaged, but this..."

Kambayashi-sensei couldn't hide his astonishment, letting out a dry laugh. In contrast, Taeko seemed calmer—perhaps because she'd already processed the shock when her students told her.

"Class 1-5 is full of cute, good kids.  
That must be thanks to their homeroom teacher's guidance, right?"  
"Not at all... I didn't do anything..."

Yuu tried complimenting the Class 1-5 homeroom teacher, but she shook her head. Truthfully, without Yuu as the partner, nine pregnancies this early in first year would've been impossible.

"Kids these days are amazing. I could never... uu..."  
Taeko muttered softly while looking down, then glanced at Kambayashi-sensei—a look Yuu didn't miss.  
*They're both adults—I wish they'd be bolder*, he thought.

After a pause, Taeko regained her composure and spoke calmly.  
"You might receive 'Special Priority Class' designation."  
"Special Priority...? Ah, I think..."

According to Taeko, Special Priority Class designation occurred when ≥1/3 of a class became engaged or pregnant by the same academy's male. This granted class-wide privileges: group prenatal checkups at school, access to on-campus counselors (for maternity blues), and priority booking for the Special Male-Female Interaction Room.  
Moreover, the male partner could be openly invited to class—even attending lessons—and received priority for interaction room reservations.  
Incidentally, homeroom teachers of designated classes received higher evaluations, though Taeko felt conflicted since she hadn't done anything special. Yuu appreciated her honesty.

"A few more might join. Then we'd reach one-third."  
"R-really...?"

After all, he'd had sex with others beyond these nine and planned to continue. With consistent creampies, more pregnancies were likely.

"Until now, one class per year was the maximum—and only in third year. I never imagined first-years... Wh-what should I do?"  
"Tezuka-sensei..."

Kambayashi-sensei watched the distressed Taeko with concern. Fundamentally kind, he never treated women coldly—likely why he was popular among male teachers. Young and handsome too.  
Taeko looked up and impulsively grabbed his nearby hand.

"Huh?!"  
"Kambayashi-sensei! Could you please advise me from now on?!"  
"Eh, um... yes, of course."  
"Th-thank you! I'm so glad to hear that..."  
"No problem, hahaha."

Yuu watched the two teachers—still holding hands while gazing at each other—with amusement. But noticing Yuu's stare, they quickly separated.  
*They're both 25 yet so innocent*, he mused. Still, Yuu felt it best for teachers to get along, just like students.

*(Pregnancy, huh...)*

Walking back to class, Yuu murmured to himself.  
Since reincarnating into this world—where sexual morals were reversed—he'd slept with countless women. He'd kept count until surpassing 30 around three months after starting high school.  
But he'd lost track after that, especially after that night at the lodge with 16 Class 1-5 girls in late July.  
In August, he'd slept with Saiei Academy student council members one after another.  
The climax was the hot spring resort in Hakone.  
*I might've already hit 100 women.*

Among them, Sayaka, Riko, and Emi were the first confirmed pregnancies.  
Nurses Shiho and Mio, plus his half-sisters Saira and Takahata Kiyoko, had personally told him about their pregnancies. Former housekeeper Akiko (now back in Aomori) and half-sister Yanai Miku had also written letters announcing their pregnancies.  
Additionally, Kuroda Noriko—the third-year from Saitama Eiko High whom he'd counter-attacked in a restroom during a tournament support visit in late May—had contacted him through the school about her pregnancy two weeks prior. Given the circumstances, Yuu gave a vague response to avoid compromising her position.  
That brought his confirmed pregnancies to ten.

*(I'm going to be a father, huh...)*

Unlike women who naturally develop maternal awareness through pregnancy, men supposedly only feel like fathers upon seeing or holding their newborn—or so he'd heard before reincarnation.  
His realization of fatherhood might come later.  
He also wondered about the Red Scorpions' four members and Nishizawa Manami, the inn proprietress. (Note: Though later revealed in interludes that Mari, Misa, and Manami were pregnant, Yuu wasn't informed at this point.)  
Regrettably, protection officers Kanako and Touko weren't pregnant yet—likely due to timing.  
As for Sayaka's sister Kiyoka, he'd been ejaculating externally per their "creampies after high school enrollment" agreement.

Back in his seat, Yuu listed past partners in his notebook when he realized he'd forgotten someone crucial.

*(Ah! Mom!)*

"Hey, Yuu-kun?"  
"Ah, Rei? You're still here?"

In the nearly empty classroom, Higashino Rei—a close friend—approached Yuu. Their other friend Yamada Masaya had left for club activities (brass band).

"Ah... yeah. I was talking with some girls downstairs..."  
"Got it. Those two?"  
"W-well, yeah."

The "girls" referred to Class 1-5's left-right duo—Satou Risa and Ukawa Miyoko. They'd wanted to spend even a little time with Rei before volleyball practice. That Rei made time for them suggested their pure relationship was progressing well.

"Are you getting a ride from the seniors again today?"  
"Well, yeah. I'm heading home today instead of Sayaka's condo, but just in case."  
"I see..."

Rei looked dejected at Yuu's reply. Since the chauffeuring began, they could no longer commute together. While cuddling with Sayaka and others during rides was blissful, Yuu felt guilty leaving his same-sex friend lonely.

"Did you want to talk about something?"  
"Umm..."

Rei seemed hesitant. *Must be about women*, Yuu guessed.  
Looking around, the few remaining classmates had left—only Yuu and Rei remained.

"See? No one's listening now."  
"Yeah. Actually..."

Rei's problem: His sister Satomi's advances had recently escalated. This might relate to his slightly deepened relationship with Risa and Miyoko since the new term—creating chances to talk briefly after school like today, or him starting to call them by first names.  
Satomi, already severely brother-complexed, had likely sensed she might "lose" her brother.  
At home, she clung to him more than ever—hugging him constantly.  
Daily greeting kisses—once on the cheek, now 100% on the lips—were standard.  
Though they'd stopped bathing together two years ago, she'd recently started wanting to again.  
She'd increased her frequency of sneaking into his bed at night, rubbing against him suggestively.  
Worse, she'd pinned him to the sofa several times when alone at home, leading to deep kissing.  
Rei sighed, confessing he loved his sister but was troubled by these overt advances. Especially when cuddling in bed at night, he felt confused by his own rising urges.

"Satomi-chan's in eighth grade, right?"  
"Yeah."  
"Ah, girls that age... once they fixate, they're so straightforward..."

Yuu vaguely recalled his own sister Elena going down a dangerous path around that age, damaging their relationship.  
Incest was taboo, but in this world, the barriers seemed lower—while legally unrecognized, family members did end up sleeping together.  
Yuu had actively responded to advances from his half-sisters (blood-related through their father). He saw sister Elena and mother Martina as attractive women rather than family, leading to sexual relationships.  
He frequently did erotic things with Elena, but since she was a ronin aiming for university, creampies were postponed until she passed.  
Rei, with his severe sister-complex, might inevitably cross that line. With them living together, escape was impossible, yet Rei couldn't outright reject her like Yuu had in his past life.  
If persuasion failed, acceptance might be best. Yuu placed a hand on Rei's slender, non-muscular shoulder.

"Rei, what I can say is... as her brother, as a man, don't just go with the flow—take the lead."  
"The lead?"  
"Yes. Even if she escalates, accept it as sibling skinship—but set limits. Like unlimited hugs and kisses, but no bed visits after bedtime greetings. You'd suffer from sleep deprivation, right?"  
"R-right."  
"But in exchange—"  
"In exchange?"  
"Promise not to cross the line until Satomi-chan graduates middle school."  
"Huh?! Cr-cross the line?!"

It might have been too early for virgin Rei.

Since becoming student council president in October—and after his exclusive interview in Weekly Fuji—Yuu had been busy.  
As the first male president, requests flooded in from across the school. Student council meetings, once held three times weekly, now occurred five times weekly, including Saturdays.  
For safety during commutes, he increasingly stayed overnight at Sayaka's condo.  
Today was the council's weekly day off, so he was heading home.

After this, he'd meet Emi via the student council room, call a car from the internal phone, and head home (picking up Sayaka and Riko en route).  
An hour had passed since classes ended, with few boys remaining on campus.  
Feeling bad parting with Rei here despite living in the same condo, Yuu arranged for him to ride in the car.

Fortunately, since October, they'd added a second car. Protection officers Kanako and Touko knew Rei well. Though reluctant, Rei was welcomed by Sayaka's group and the officers. Due to seating, Rei rode separately from Yuu—surrounded by women, but he'd have to endure it.

After arriving at the condo, Yuu parted with Rei and the two officers. Opening the front door, he called "I'm home!"  
Elena rushed to hug him.

---

### Author's Afterword

Pregnancy announcements have been trickling in since earlier, but I've consolidated them in this chapter.  
Next chapter: Family time at home after so long. Another report might be coming.  

2020/11/23  

Originally, I wrote that Yuu didn't know about Noriko's pregnancy, but I've revised it per reader feedback to reflect he was informed.

### Chapter Translation Notes
- Translated "妊娠ラッシュ" as "Pregnancy Rush" to convey the sudden influx of pregnancy announcements
- Preserved Japanese honorifics (e.g., "神林先生" → "Kambayashi-sensei")
- Maintained Japanese name order (e.g., "安芸 和美" → "Aki Kazumi")
- Translated explicit terms directly (e.g., "中出しセックス" → "creampie sex")
- Italicized internal monologues per style guide (e.g., "（妊娠か……）" → "*(Pregnancy, huh...)*")
- Transliterated sound effects (e.g., "えええぇぇぇぇ" → "Eeeeeeh")
- Translated "特別重点クラス" as "Special Priority Class" per Fixed Reference terms
- Rendered dialogue with new paragraphs per attribution rules