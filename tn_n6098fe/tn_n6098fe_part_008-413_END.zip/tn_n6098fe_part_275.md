## 259. Family Gathering ① ~I'm Home~

Cooking dinner at home for the first time in a week.  
Since there was a large pack of mixed ground meat and onions, I made hamburg steak.  
It's not a difficult dish once you're used to it, but beginners often fail by burning it on high heat while the inside remains raw.  
So Yuu covered the frying pan and cooked it slowly over low heat (flipping only once midway).  
Even after turning off the heat, he let it sit to cook through with residual warmth.  
Doing this almost guarantees no failure.  
When he previously made Japanese-style hamburg steak topped with grated radish and soy sauce, it was well-received, but since there's no radish now, he simply mixed medium-thick sauce and ketchup.  

By the time Yuu turned off the stove, the rice cooker had switched to keep-warm mode, and side dishes of boiled broccoli, carrots, and potatoes were already plated. The green and red colors made it visually appealing.  
Checking the clock, it was past 7:30 PM.  
Mom should be home soon.  
Though Martina had been returning late due to busy work since September, today she apparently rushed to finish work upon hearing Yuu was coming home.  
During the free time, Yuu started cleaning by washing knives and cutting boards.  

His sister Elena watched him intently from the dining chair.  
Since Yuu's return, she'd been trailing him like a goldfish's waste, trying to touch him or plant kisses everywhere whenever possible.  
Yuu had humored her at first, but kitchen work with knives and fire required distance.  

About 15 minutes later, the front door finally opened.  
An orange jacket over a loose navy blue long skirt.  
Her white blouse strained over exceptionally voluptuous breasts.  
Upon seeing Yuu who came to greet her, Martina bloomed like a large flower, her face breaking into a full smile as she called her beloved son's name.  

"Yuu...chan!"  
"Mom, welcome home."  

Martina threw her bag aside and hugged Yuu standing on the entrance step—still wearing her shoes.  

"Aahn! Yuu-chan's scent, your warmth... truly healing~"  
"I heard you've been working late recently. Really, thank you for your hard work."  
"Hey, Yu...mmph..."  

Yuu instantly covered Martina's lips as she lifted her face.  
He knew what she wanted without words.  
They embraced passionately while stroking each other's heads and bodies, feeling each other's scent and warmth—like lovers reunited after long separation.  

After several minutes of kissing and embracing, Yuu suddenly noticed something and slightly pulled back.  
He unexpectedly brought his right hand forward and squeezed her breast.  

"Hey Mom. Haven't these gotten bigger?"  
"Ah... well..."  

Her explosive breasts overflowed even his full palm.  
When he touched them with a supporting motion from below, they felt heavier and fuller than before.  
Though they hadn't had full intercourse often, Martina often let Yuu fondle her breasts during daily skin-ship.  
Surely they hadn't grown just from his frequent groping.  
Or perhaps women's breasts swell before menstruation, but not enough to show through clothes.  

"Yuu-chan. We'll talk later."  

When told that, he had no choice but to back off for now.  

With Elena's help to serve before the food cooled, dinner was laid out.  
With fewer chances for the three to share meals since October, both Martina and Elena were in high spirits, chatting happily throughout the enjoyable meal.  

When Yuu started to rise after finishing most of the meal to prepare wine for Martina, she stopped him.  
Thinking it unusual, Yuu sat back down as Martina adopted a formal tone.  

"I'm pregnant with Yuu-chan's child. Four months along."  
"Eh?"  
"I actually knew over a month ago but couldn't bring myself to say it... You know, we've both been busy."  
"I could've told you, but Mom wanted to tell you directly herself."  

Gata—Yuu stood up.  
Perhaps due to his pre-reincarnation ethics, guilt flashed through him for impregnating his biological mother—but only momentarily.  
The joy that Martina—this attractive woman—was pregnant with his seed overwhelmed everything.  
So Yuu walked around the table to Martina's side and hugged her tightly.  

"Congratulations. And thank you."  
"Yuu...chan..."  

She must have been anxious inside.  
Hearing Yuu's words, Martina teared up and hugged him back fiercely.  

Yuu didn't know this well, but in this world where men are precious, families sometimes have children together—and raise them normally.  
The child would legally be Elena and Yuu's younger sibling.  

Cases where multiple women marry one man and bear children are minority scenarios.  
Most women use public artificial insemination or pay for semen to get pregnant.  
Thus, the father's name on birth certificates is optional.  
The conception method isn't questioned.  
However, boys are overwhelmingly born through natural conception.  

"Brother or sister—either is fine. Just give birth to a healthy baby, so take care of yourself and ease up on work soon."  
"Oh? I plan to work until January?"  
"Eh?"  
"I had them switch me to less mobile duties, so it's safe."  
"That's not the issue..."  

Martina had almost no morning sickness this time, and now in her stable second trimester, exercise is actually recommended.  
Women seemed far tougher than Yuu realized.  

"So nice... Mom is... I want Yuu's soon too..."  

While Yuu was still hugging Martina, Elena pressed herself against his back.  
Though they'd agreed on creampie sex after her university acceptance, Elena's true wish slipped out.  
Before the instinct to bear children from a desired man, blood relations meant nothing to this world's women.  

Yuu looked between Martina and Elena and said:  

"Hey, how about the three of us bathing together sometime?"  
"Eh?"  
"Really?"  
"It's a rare opportunity."  
"Yay!"  
"My, fufufu."  

Unlike Elena who showed simple joy, Martina displayed slight shyness—proof she already saw Yuu as a man rather than just her son.  
Since women take longer to prepare, Martina and Elena went to bathe first.  

"Fufu, Yuu-chan, feels good?"  
"Nngh, uwaa..."  
"*Nchu*, lelo leloo... *afu*, ohihii, Yuu, more, *churu*, nmu moo"  
"My my, Elena dear. Now Yuu-chan can't answer."  
"Ahhhteee, Yuu's hardened cock is hitting meee."  
"Lucky. Let me touch too."  

When Yuu entered the bathroom, Martina washed his head while Elena washed his feet.  
Then they made him stand and sandwiched him front and back with soapy bodies.  
From the front, Elena interlocked fingers like lovers and rubbed her chest against his stomach.  
From behind, Martina pressed her voluptuous breasts against his back while her hands—having cleaned from shoulders to armpits, then buttocks including his anus—now slid along his thighs.  
Yuu's crotch had long been erect, and feeling the heat against her lower abdomen, Elena pressed her lips to his with a lust-drunk face.  

"*Chu*, *chu*, Yuu-chan's skin is so smooth. Now, let's clean your cock too!"  
"Aah! That... feels so good!"  

While repeatedly kissing his nape, Martina's right hand slipped down to where Elena was against Yuu's lower abdomen.  
She teased the glans with enveloping fingers, then vigorously rubbed the coronal ridge where smegma collects.  

Sandwiched between two naked beauties alone was heaven, but combined with the soapy slickness, Yuu's excitement skyrocketed—transparent precum already dripping from the tip.  

"Yuu-chan!"  
"Ca... caahyan, nmu!"  

Martina rubbed her cheek against his and stole Yuu's lips from Elena.  
Then Elena—still hand-in-hand—shifted her hip angle. She clamped his shaft between her labia and began gyrating.  
Her love juices and his precum mixed, creating squelching lewd sounds that echoed in the bathroom.  

"Ah, nnngh! Yuu... anngh! Good... so good! Your hardness... hitting me!"  
"Daah... me... I'm gonna..."  
"*Nchu*, *chupaa*... It's fine... cum"  
"Faa... ngh, oooh, uwaa!"  

Feeling Yuu near his limit, Martina lightly gripped and stroked his shaft with expert fingers and perfect pressure, guiding him to orgasm.  
Thick white semen shot out powerfully, splattering all over Elena's waiting upper body.  

"Gyaaah! It... came... Yuu's seeeemen... hahi, hahi... hot! Iih, Iih, Iiiiiin........"  

Drenched continuously in semen from chest to abdomen, Elena inserted fingers into her vagina and shuddered to climax.  

Though spacious, the bathtub was cramped for three adults.  
While rinsing off under the shower, Elena—apparently instructed by Martina—soaked briefly before quickly leaving.  
So now Yuu was soaking while cradling Martina from behind.  

His hands reached forward to knead her melon-sized breasts half-floating in the water.  
He used gentle touches to savor their softness.  
With her long black hair tied up, Yuu couldn't stop kissing her exposed nape.  

"Ah... fuu... really, Yuu-chan, you're so fond of this."  
"Blame Mom for being too beautiful and alluring. *Chu*"  
"Ngh... I'm happy. Hearing that from Yuu-chan. Honestly... I was embarrassed."  
"Why?"  
"...Getting pregnant at this age."  

At 36, Martina would turn 37 this year—technically an advanced-age pregnancy.  
She looked youthful enough to pass for 30.  

"Mom's still young. No need for shame."  
"Thank you, Yuu-chan... I already felt happy just having us three getting along like before. But now Yuu-chan's child is inside me—our loving family growing by one more. It feels unreal, like too much happiness."  

When Martina placed her hand on her belly, Yuu covered it with his right hand.  
Now that he looked, her previously taut stomach seemed rounder.  

"That's why I'm scared Yuu-chan became student council president and gained nationwide fame. Young boys are already targeted, and you were actually kidnapped once, right? I just hope nothing irreversible happens."  

She turned only her face, gazing at him worriedly.  

"They increased my protection officers, and everyone at school protects me—so I think I'm safe. But I won't live in fear. I'll do what only I can do. It's fine. Kanako-san taught me self-defense, and I'll overcome any hardship."  

Though cherished as a man, this world made free living difficult.  
But having gained a second life, Yuu resolved to actively engage with people.  
He smiled reassuringly and covered Martina's lips while keeping a hand on her belly.  
They exchanged a passionate kiss.  

Martina had to accept her beloved son was no ordinary boy.  
Such beings existed in the past—she'd loved one and borne two children with him.  
But he died young.  
So Martina prayed fiercely that no such tragedy would befall Yuu.  

---

### Author's Afterword

The ending was written to express Martina's feelings—worrying about Yuu as both her son and a man she's conscious of—not to set up tragedy flags. Just to clarify.  
Well, given how prominent he's become, some turbulence is inevitable.  

### Chapter Translation Notes
- Translated "合い挽き肉" as "mixed ground meat" to specify beef/pork blend
- Rendered "オチンポ" as "cock" per explicit terminology rule
- Preserved "-chan" honorific in dialogue ("Yuu-chan")
- Translated "悪阻" as "morning sickness" (standard medical term)
- Used "creampie sex" for "中出しセックス" to match explicit terminology requirement
- Transliterated sound effects: "がたっと" → "gata", "びゅるっと" → "splurt"