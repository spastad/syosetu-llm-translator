## 260. Family Gathering ② ~Sweet Challenge~

### Author's Preface

This time features anal training with Elena.

Come to think of it, despite all these chapters, this might be the first anal scene.

I've avoided writing proper anal sex because it's troublesome to handle. Honestly, I have no personal experience either, so I researched to write this. There might be odd parts - please forgive me.

---

"With this... all set. How is it, Sis? Not too tight?"

"Ahh... being tied up by Yuu's hands... feels so good... li-like I'm dreaming... ufunn"

"Take this!"

"Kyahn!"

*Peshi!* When he spanked her buttocks, Elena arched her back. Yet her expression remained relaxed.

Elena, who inherited her father's fair complexion and slender build, was completely naked with red ropes digging into her from chest to crotch. Her modest breasts were slightly emphasized, both arms restrained behind her back. The crotch rope dug deep - an imperfect diamond bondage. To finish, a leather pet collar was fastened around her slender neck, its lead held by Yuu.

Using a beginner's SM guidebook from Saira's leftover bag as reference, Yuu tied her for the first time. Elena's naturally colored brown hair was long enough to tangle with the ropes, so she'd put it up in the same updo as during baths. Though it took longer than when Saira tied her, it seemed like blissful time for Elena. The rope digging into her crotch was already slick with moisture. As Saira predicted, Elena clearly had masochistic tendencies.

"This should do. Shall we begin?"

"Un..."

They were specially recording with a video camera on a tripod. Yuu originally had no interest in filming sex. Before rebirth maybe, but surrounded by girls daily now, he didn't need recordings for enjoyment - his sex life was luxurious enough.

This was Elena's request. They'd agreed: Elena wouldn't assault Yuu without permission. Conversely, when Yuu desired it, she'd accept as his sexual relief sister anytime. Yuu permitted daily skin-ship (kisses, touching, hugs). Living together seemed to offer constant opportunities. When Yuu didn't have sex at school, he'd pounce on Elena immediately after returning home - her summer outfits so defenseless it felt provocative.

But since becoming student council president, Yuu got busier with more overnights at Sayaka's apartment. Elena's frustration built up. Hence, the recording as exclusive masturbation material for Elena. Yet perhaps nervous about the camera, Elena's expression seemed stiff.

"What's wrong, Sis? C'mon, smile more"  
"Ah! A...fe...yu, uun...nn, nn, nnaaah...a, a, so gooood!"

Standing behind her, Yuu lightly tugged the lead while pinching a nipple with his other hand. As he rubbed with two fingertips, it quickly hardened like an erection. Simultaneously sniffing her post-bath hair and soft skin while nibbling her ear, Elena trembled with uncontrollable moans.

"What were we doing today? Tell the camera"  
"A...i...uun...but wait...hyahn! Like this...can't...talk"  
"Can't be helped then"

From their position bedside, the tripod-mounted camera stood slightly diagonal in the cleared space. Yuu released the nipple and turned Elena's chin toward the camera, moving his mouth from her ear to her cheek. Elena's cheek felt feverishly hot.

"I-I'm...being tightly tied by Yuu like this. Th-the ropes against my skin...make me feel it. Even on sensitive spots...nfuu. And tonight...besides Yuu tormenting me...he'll develop my butt too. I cleaned it earlier...so...wh-what will he put inside? Ju-just imagining it...haa, haa, gets me excited. Aahn!"

What a masochistic pervert. Despite nothing happening yet, just imagining and talking to the camera made her love juices visibly drip down her thighs.

A mean thought crossed Yuu's mind: build her anticipation then leave for Martina's room. He recalled "abandonment play" existed. But while Elena was douching earlier, Yuu had accompanied Martina to her bedroom after bathing for a goodnight kiss. Martina had work tomorrow but asked him to relieve Elena's frustration.

"Well, that's enough"  
"Yuuuuu...hyatt! Ah, there!"

Yuu palmed her modest breasts to knead the nipples while tugging the crotch rope from her lower abdomen. The effect was spectacular.

"Ah, ah, v'unn! Good! Good! Clit, touching...i'hiin! Nmo'!"

As Elena's volume increased, Yuu covered her lips with his, sliding his tongue in. Elena welcomed it, sloppily overlapping her tongue. With mouth, breasts, and crotch simultaneously stimulated, Elena wore a thoroughly melted expression, body trembling *bikun, bikun*.

"Nmo', o', i', nii'! I'.........nguuuuuuuuuuun!"  
"Oh? Came already? Sis really is a pervert. This is just the prologue. The main event comes next"  
"Ai'...yu...uun..."

Elena faced her butt toward the camera, knees on floor, upper body leaning on bed. Yuu stroked her pert upturned buttocks when suddenly he raised an object in his right hand and swung down.

*Batchiiiiiiin!*

"Nhiin!"

Elena's muffled cry escaped. To prevent loud noises disturbing Martina's sleep, she wore a ball gag. The crotch rope spread her legs wide, two pink vibrators inserted in her vagina. Cords extended to remotes strapped on both thighs. The spanking implement was a black rubber paddle - supposedly loud but not too painful. The red ropes, ball gag, and vibrators were all souvenirs from Saira's visit, finally being used again.

"Take this!"  
*Batchiiiiiiin!*  
"Nguh!"  
*Batchiiiiiiin!*  
"Vua'!"  
*Batchiiiiiiin!*  
"O'un!"

After repeated spankings, her fair buttocks reddened. Drool dripped from the gagged mouth onto sheets while her pussy squirted *pushu pushu* - both holes leaking freely.

"Getting off from spankings? Sis really is perverted"  
"Vuaaaaaa...a'"

Yuu set the paddle down, sat on the bed edge, and spread the monkey-red buttocks with both hands. The camera surely captured Elena's shameful parts clearly. *Bububu* vibrations came from deep inside as love juices dripped *pota pota*. Her labia minora twitched, slick vaginal entrance gaping - seemingly awaiting Yuu's cock.

"Your pussy is ready, but let's loosen this next"  
During summer break, Saira gave an additional package with a note: *'Stretch Elena's ass for me! Next 3P, I want Yuu and me to double-penetrate her!'* It contained an anal training kit (with instructions) - enema, anal plugs, anal beads, lube (high-viscosity anal type)...

Yuu was stunned when opening it, but now felt grateful. Anal sex was convenient for creampies without impregnating Elena during her college prep. Why hadn't he thought of it sooner? He knew some enjoyed anal, but lacking interest himself, he wouldn't have known how to start.

Elena had douched beforehand to clean internally. An anal plug might have eased penetration, but lacking time tonight, Yuu had to loosen her manually. Her clean anus twitched slightly, perhaps reacting to vaginal stimulation.

"Starting now"  
Maybe not hearing Yuu, Elena merely moaned softly. Yuu prodded her anus with a lube-coated middle finger.

"Nge'!?"  
For Elena, it felt suddenly invaded. She jerked upright, looking back at Yuu. Ignoring this, Yuu dripped lube directly, working his fingertip to loosen her. *Kupuku, nechinechi* - sticky wet sounds accompanied his movements. With increased slickness, he inserted to the second knuckle.

"A'o'! N...hii..."  
"Ooh, in. Still tight though"  
The inserted finger got *kyu* squeezed - virgin-hole tightness. Yuu finger-fucked slowly like masturbating her, gradually going deeper.

"How is it, Sis? Whole middle finger in"  
"V', v'a', nn', nn', uu'n!"  
"Feels good for me too? Well, good"  
Though originally just an excretion hole, getting fucked *zubo zubo* for the first time. Initially grimacing with pained whimpers, Elena now looked at Yuu with lust-drenched eyes. Though the finger slid smoothly, penetration needed more preparation. Time for the next step.

Yuu produced pink anal beads - 25cm long, bead-strung, tapering smaller toward the tip. The largest base bead was 2.5cm diameter, thicker than a finger.

Added lube and repeated fingering had slightly opened her anus. Yuu inserted the anal beads.

"Sis, relax. C'mon, how deep will it go?"  
"A'o', v'o, o'...u'uuuuun! N'kuun!"  
To distract her, Yuu rubbed her swollen clitoris with his other hand. Known and unknown pleasures mixed as Elena shook her head side-to-side like refusing while arching her back. It seemed stuck midway, but repeated insertion let it sink deeper gradually.

Vaginal depth varies but averages 8-10cm. But her asshole swallowed half the 25cm beads, still sinking *zubu zubu*. Yuu found it oddly fun.

With about 1/4 remaining including the ring, the beads were fully inserted. Unaccustomed, Elena writhed, shaking her butt - like having a short tail.

"How is it? More?"  
"Nn? V'un...no'! O'! O'!"  
"Ooh, goes in pretty deep"  
Pushing *gui gui*, it sank further. Elena endured motionless. Love juices dripped cow-saliva-like from her vagina. Already adapting - Yuu felt pleased. After maximum insertion, the finale. Yuu removed his trunks, exposing his erect cock, but Elena faced away unknowing.

"Sis. Almost all in. You did well"  
"Nn, v'u...fo'!?"  
Patting her head *pon pon*, Elena turned and saw the standing cock. After staring dazedly, she looked up longingly. Yuu grabbed a buttock with one hand, hooking the tip ring with the other.

"Pulling out"  
"Ve?"  
Slowly at first, then forcefully, he yanked the beads out.

"Vua'! A'ooooooooooooooooon!"  
*Pushu! Busha! Pushaa!*  
Lube gushed from her anus following the beads, while her pussy squirted copiously, soaking the floor. Butt still raised, back arched taut, Elena trembled *purupuru*. Yuu immediately moved behind her, pressing his cock against the gaping hole and thrusting in one motion.

"No'! Th-this is..."  
"Nhii! A'...ga...o'in fo..."  
"Still tight? But I'm entering. Taking Sis's anal virginity"  
"N'i'! U...v'un'! No'! I'iiii"  
It felt like deflowering an underdeveloped young girl - physically tight. But copious lube (not love juices) provided good slip. Pushing persistently *gui gui*, it gradually entered.

"Kuh...fuu...damn tight, Sis's ass... But once trained, I'll creampie you here anytime?"  
Perhaps those words helped - her tension eased as his cock sank deep inside.

"Nu'o'...nn', o', guu..."  
"Ahh, all inside Sis... Whoa, amazing, Sis's ass feels great too!"  
"V'un'! V'u..."  
First anal penetration for Yuu. Likely Elena's first too - tighter than her pussy, *gichi gichi* hard squeezing. The resulting cock friction felt intensely pleasurable - addictively good.

"Haha. Dangerous. My hips... won't stop. Aah! Might... cum like this"  
Yuu covered her back, starting to thrust. Already soaked from asshole to pussy, his groin - pubes to balls - dripped wet. Each thrust produced dull *pasun, pasun* slaps.

"Sis close from anal?"  
"V', nuun...o', i'n!"  
The ball gag muffled clear answers, but Yuu sensed Elena nearing climax. Her cheeks flushed pink long ago, whole body sweaty, moans continuous. For good measure, Yuu kneaded her breast with left hand while his right pinched her clit.

"Vua'! O'iin! V'u! Na'!"  
As Elena's body jerked, he held her down for the final sprint.

"Cumming, Sis. Gonna ejaculate deep inside. The semen you wanted. Here... v', kuh, cumming, cumming! Take your little brother's load in your pervert ass-pussy! Take it! CUMMING!"  
"Nye!? O', o', o'o! Vuaaaaaaa!"  
With his cock buried deep in her rectum, Yuu reached climax. Thick semen gushed *doku doku doku* into Elena's colon.

Though not the womb she originally wanted, being creampied directly by beloved Yuu was the same. Elena seemed struck by intense ecstasy, chin jerked high as muffled moans escaped. Then she collapsed face-down on bed. But her expression looked deeply satisfied.

One ejaculation couldn't satisfy Yuu. Realizing he'd forgotten the camera angle, he lifted Elena's limp body to face the camera - reverse cowgirl position with him sitting on bed edge. Anal penetration continued. Though maneuvering tall Elena in this position was tough, the camera surely captured their joining well. Good masturbation material. Feeling the mixed semen and lube *gucha gucha*, Yuu released his third ejaculation of the night inside her.

### Chapter Translation Notes
- Translated "アナル調教" as "anal training" to maintain explicit terminology
- Preserved Japanese honorifics (-san not used in this intimate scene)
- Transliterated sound effects (e.g., "Peshi!" for ぺしっと)
- Translated sexual anatomy/acts directly ("clitoris", "ejaculation", "anal penetration")
- Maintained original name order ("Hirose Yuu", "Hirose Elena")
- Used italics for internal thoughts (*(This is concerning.)* equivalent)
- Translated "チンポ" as "cock" per explicit terminology rule
- Rendered dialogue quotes with standard "" for single speaker
- Kept specialized terms like "creampie" for direct translation