## 261. The Delinquent Girl Arrives ~Taming the Shrew~

### Author's Preface

Aside from interludes, there's a character who hasn't appeared in a long time.

---

On the afternoon of the last day of October.

While discussing the upcoming school festival in the student council room, Hirose Yuu received a visit from Komatsu Sayaka and excused himself to head to the first floor of the administration building, walking together with her.

"So, this student from Saito Comprehensive High School who wants to meet me?"

"Yeah, her name is Mihara Ryoko. She's... well, someone I had history with in middle school..."

Sayaka seemed somewhat reluctant to explain. Yuu didn't immediately recognize the name... but searching his memories, he did recall meeting someone named Ryoko once before. But was she really Sayaka's rival from middle school?

"Back then, she was notorious as a delinquent. But she was the principled type - hated underhanded tactics, never bullied the weak or ambushed people. Even in fights, she was honorable. So among delinquents, she stood out as a lone wolf. I fought her often, but I never disliked her character."

"Huh."

The daughter of a major corporation's president, trained since childhood in her family's dojo, and a model student who served as kendo club captain in middle school. That such a refined person like Sayaka had history with a delinquent... could it be?

As Yuu pictured a stereotypical delinquent girl in his mind, they arrived at their destination - one of the guest rooms adjacent to the first-floor office of the administration building. Unlike the reception room for distinguished guests, this was a small conference room typically used for vendor meetings.

"Komatsu-san and Hirose-san? We've been expecting you."  
"Thank you for your trouble."

Two school security guards stood by the conference room door. Since this was an unannounced visit from another school's student, they remained cautious.

"Shall we accompany you inside?"  
"No need. We're old acquaintances."

Though they could have left, the guards remained stationed outside as part of their duties.

Sayaka opened the door and called out:  
"Been well, Ryoko?"  
"Yo! Long time! Yeah, doing fine. Though repeating my second year's a drag."

A girl in a sailor uniform lounged back on a pipe chair, legs crossed. When she saw Sayaka, she grinned and raised one hand. Her long skirt reached her ankles, and her bleached light-brown hair fell straight to mid-back. Thick makeup unusual for a high schooler - bright red lipstick and purple eyeshadow stood out. In short, a classic 1990s delinquent style rarely seen these days - the sukeban look.

"Ryoko!?"  
"Y-Yuu! You came... Uhyahh!"

Ryoko, who'd been smirking defiantly at Sayaka moments before, suddenly tensed up when Yuu appeared behind her. When Yuu approached without hesitation and took her hand, she flustered like a fan meeting their idol. Sayaka's eyes widened in surprise at this unprecedented reaction from Ryoko.

---

"So... the Edo Shovels? members?"  
"Red Scorpions!"  
"Ah, right. How did Yuu-kun come to know Ryoko and the Red Stoppers members?"  
"Hey! You're doing that on purpose!"

Yuu could tell Sayaka was deliberately misnaming them - her face was clearly smirking. Seeing this playful side of Sayaka was rare.

After exchanging greetings, they sat across the table from Ryoko. Naturally, Sayaka was curious about Yuu and Ryoko's connection. Yuu fabricated a story about last May: while shopping for presents, he wandered off from his guards and encountered delinquents from Ichimatsu High. Just as they were about to take him away, the Red Scorpions intervened. Though Ryoko's group beat them, the delinquents called reinforcements and chased them, forcing Yuu to hide at the Red Scorpions' hideout.

Ryoko blushed and nodded as if recalling that day. She was indeed a delinquent, but not the type to kidnap and assault men. In fact, she was completely inexperienced and shy. Sayaka mostly believed Yuu's story - she wouldn't be shocked even if Yuu had slept with them, as his future primary wife had the composure to accept any number of lovers or children.

"From my perspective, I'm more surprised you two know each other."

After Yuu finished, he asked about what had been on his mind. Both spoke simultaneously:  
"That was in middle school—"  
"It was spring of second year—"

Sayaka talked over her, so Ryoko fell silent.  
"They called her Mad Dog Ryoko, or Red Wolf Ryoko because of her bright red hair back then?"  
"Heyyy! Stop with that name!"  
"Why? When we first met, you proudly boasted about being called that."  
"It's a past I want to forget!"

A nickname typical of middle schoolers - the kind that becomes an embarrassing memory. Ryoko buried her face in the table, squirming with embarrassment. Feeling sorry for her, Yuu reached out and patted her head.

After calming down - or perhaps cheered by Yuu's touch - Ryoko continued:  
"Well, I was fearless back in middle school. Lived in Asaka City, ran wild all over town with no rivals. Then I heard there was an insanely strong girl my age in neighboring Wakou City. Went there looking for her."  
"I was shocked. Hearing a delinquent middle schooler came to challenge our dojo. But when I heard she'd beaten skilled middle and high school dojo members, the master told me to face her."

That was how Sayaka and Ryoko met. They agreed to a bare-knuckle fight with no weapons, battling fiercely until both collapsed battered after two hours. The master - Sayaka's grandaunt - even invited Ryoko to join the dojo, but Ryoko simply bowed and left. For Ryoko, this was her first tough fight against someone her age. Rather than frustration, she felt fired up by finding a rival.

From the next week, she came weekly to challenge Sayaka, becoming like a half-member of the dojo. Though different from friendship forged through fists, they clearly respected each other. This continued until Ryoko moved to Saito City after middle school.

"Final tally in one-on-ones: I led 25 wins, 20 losses, 13 draws."  
"Hold up! Six of your wins were when the master told me to try fighting with a wooden sword. Unfair since you did kendo! Without those, I led 20 wins, 19 losses, 13 draws."  
"If we're going there, what about when we hunted biker gangs causing public nuisances? You cheated using an unlicensed bike to charge in!"

As they argued over everything from dojo eating contests to ghost tests - far removed from fighting - Yuu couldn't help laughing. It was rare to see Sayaka so stubborn.

---

"So Ryoko, you didn't come all the way to Sairei Academy just to reminisce, right?"  
"Course not. Took effort just to get in here. I came because there are two things I really wanted to tell Yuu."  
"Okay. I'm listening."

Though she'd been bickering with Sayaka moments ago, Ryoko now spoke seriously. Yuu straightened his posture.

"First: Mari and Misa are pregnant."  
"Whoa!"  
"They told me not to say anything since it might trouble you, but I thought you should know."  
"Come on, that's cold. I'm happy about it. Tell them congratulations for me."  
"Good. They'll be glad to hear that."

Ryoko looked genuinely relieved. She'd worried Yuu's fame might suffer if people knew they were carrying his children. Her considerate nature seemed at odds with her delinquent image.

Yuu recalled: he'd ejaculated inside all four that day. Though not all got pregnant, two did on their first try. Sadly, Ryoko hadn't conceived. That she came to report this showed how much she valued her friends.

"Given the timing, their due dates might be close to yours?"  
"Oh?"  
"I knew it! Something felt different about you!"

Though Yuu and Sayaka's relationship was school-famous and they'd been seen together at each other's apartments, they hadn't publicly announced their engagement. Yet even Ryoko, meeting them after so long, could sense their spousal bond.

"Heeey~ So the proper young lady Komatsu is... fufuun~"

Ryoko smirked at Sayaka - clearly planning payback for earlier teasing. Just as Yuu thought this, Sayaka abruptly said:  
"Don't you want to carry Yuu-kun's child too, Ryoko?"  
"Huh?"  
"What do you think, Yuu-kun? About Ryoko."  
"Ah, I think she's a great woman. I'd definitely want to sleep with her."  
"See? Good for you, Ryoko."  
"W-wait!"  
"You don't want to with Yuu-kun?"  
"......I... I do..."

Ryoko glanced at Yuu for just a second before blushing and looking down - her usual pure-hearted self. For now, Yuu decided to arrange a time to impregnate Ryoko later and asked for her second topic.

But Ryoko just stared out the window without speaking. Unlike the pregnancy announcement, she seemed hesitant. After a while, she turned back to Yuu.

"Yuu... remember our leader?"  
"Kei... Kate? Of course I remember. Last met her around early August?"  
"I see."  
"But recently, meeting Saiei Academy's new student council, I heard she hasn't been to school... ah, I see."

Sayaka, who didn't know the context, received an explanation. Though they'd never spoken directly, Kate's striking blonde hair and blue eyes were memorable from meetings between student councils.

According to Kate, she'd clashed with her only family - her mother - since just before high school. She'd snapped at her mother's high-handed demands. Though it seemed like a daughter's belated rebellion against an uncomprehending parent, their stubborn standoff continued. Whenever they met, they'd trade insults, sometimes escalating to physical fights that wrecked their home.

Though Kate played the model student at school, she avoided home and spent most time at the Red Scorpions' hideout. Her jersey outfit when Yuu first met her was because she'd changed directly after school.

Her mother being busy with company management meant Kate could avoid her by timing it right. This continued peacefully until an incident near August's end - the night Yuu stayed at the Toyoda Sakuya Memorial Foundation annex, when he was kidnapped by radical group members.

After ejaculating inside all the perpetrators at their hideout, Yuu was rescued at dawn by protection officers. The incident was reported without naming Yuu, but shocked society when investigations revealed connections to the Dankyo Party - expected to make major gains in the next election.

The dummy company's representative handling illegal fundraising was Jane Grimwood - Kate's mother. With Jane fleeing early, Kate as her only family faced media harassment, silent calls, graffiti, and thrown rocks at home. Unable to stay, she took valuables and now lived at the hideout.

"The cops apparently understand our leader had nothing to do with that bitch. But the public doesn't see it that way. Media just writes sensational crap. Kate planned to get a job and move out after graduation, but this mess ruined everything."  
"That's... terrible luck."

Yuu knew from post-rescue news that his name wasn't reported and perpetrators cooperated, but hadn't followed subsequent developments.

"Is she safe now?"  
"For now. But the old building's scheduled for demolition this year. She plans to leave once she finds live-in work, probably moving somewhere rural for safety."

Ideally, she could rely on American relatives, but they'd been estranged since her mother left young. Ryoko looked at Yuu with unprecedented seriousness.

"My Red Scorpions crew are precious friends. Especially our leader - besides Sayaka here, she's one of the few women I respect. So Yuu... could you meet her before she leaves?"

---

### Author's Afterword

For Ryoko's image, I pictured Junko Mihara in her youth (note: surname changed from Mihara to Mihara during writing). Even if you don't know her name, you might recognize the line: "Her face is dangerous, but her body... her body!" Though I never saw her live, image searches show she's truly beautiful.

### Chapter Translation Notes
- Translated "じゃじゃ馬ならし" as "Taming the Shrew" to capture the headstrong/wild horse metaphor
- Translated "ステゴロ" as "bare-knuckle fight" (slang for street fight without weapons)
- Translated "タイマン" as "one-on-one" (slang for solo confrontation)
- Preserved Japanese honorifics (-san, -kun) and name order
- Transliterated sound effects: "うひゃあっ" → "Uhyahh!", "おいぃぃ" → "Heeey", "ふふーん" → "fufuun"
- Used explicit terminology: "ejaculated inside" for 中出しセックス