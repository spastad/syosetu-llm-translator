## 263. Sharing Secrets ~Goodbye Yesterday~

### Author's Preface

The conversation between Yuu and Kate alone would fill a normal chapter, but adding Ryoko's reward scene made it quite long.

I considered splitting it, but cutting at an awkward point might leave readers unsatisfied, so I'm posting it as is.

*Note: Corrected some author misunderstandings in the initial post. May revise if I find odd contextual spots upon rereading.*

---

In November, even when days are sunny and warm, nights turn cold abruptly. Tonight wasn't too windy, thankfully, but sitting on the gazebo bench, cold air seemed to seep up from below.

"Sayaka, are you okay? Not cold?"  
"I'm fine. Thank you, Yuu-kun."  
"But come closer. Let's snuggle."  
"Okay."

The seating order on the bench was Ryoko, Kate, Yuu, Sayaka. Yuu wrapped his right arm around Sayaka's waist and pulled her close. Feeling her warmth where their bodies touched warmed his heart too. Sayaka happily wrapped her left arm around Yuu's back. Ryoko watched them with slight envy while Kate observed with cool detachment.

"Engaged... right? And pregnant too?"  
"Yes. Sayaka was the first woman I fell for at first sight in this new life."  
"I see. Yet you casually touched our gang members."  
"Leader, that's backwards. *We* came onto Yuu. He kindly accepted even delinquents like us."  
"Ah, right. Not just reversed chastity norms but polyandry being normal... Still hard to accept."

Seeing Kate cradle her head, Sayaka and Ryoko couldn't hide their confusion.

"*Reversed?*"

Yuu explained: In his previous world, genders were nearly equal. Men typically initiated romance, and men committed most sexual crimes. Here, young men are the vulnerable minority, but there, young women were prey.

"From what I've researched, before the Red Death pandemic decimated men, this world had similar history. The skewed ratio changed everything - gender roles, society itself."  
"Can't believe a world with equal men/women exists!"  
"Learned it in history class but never thought deeply. Current norms felt natural..."

Even Yuu struggled to accept reversed chastity norms after reincarnating. Their confusion was understandable. Some might imagine an "if" world without the Red Death pandemic. But with men scarce, such speculation remains fantasy.

"So Yuu-kun never feared girls - he happily approached them."  
"That's why he stayed calm when surrounded at our hideout..."  
"Right. In my mind, bonding with girls was joyful. I couldn't grasp being wary of them and got scolded often."

Having Yuu as proof helped them accept this.

"People change. Who'd think the man devoted to Masami-san would..."  
Kate muttered this, and unfortunately, Yuu heard.

"True. Back then, I only saw Masami. I planned to love her my whole life. Then she betrayed me. 'Found true love' my ass!"  
"......"

A decade-old memory. His ex-wife left hoping for new love, but Yuu felt like half his soul was ripped out. Grief consumed him until time scabbed the wound. Meeting Sayaka and others in this world helped him heal - until Kate's words reopened it.

Kate seemed ready to retort but only shuddered briefly before staying silent.

"Yuu-kun!"  
"Sayaka..."

Though unclear on details, Sayaka sensed Yuu's rare anger and hugged him tightly. Now Yuu had Sayaka - an amazing woman. Her hair's scent and warmth soothed him as he stroked her head.

Calmer now, Yuu questioned Kate.

"Earlier - how did you know my ex-wife's name?"  
"We met once. She introduced herself. You forgot?"  
"Huh? You met as Kurimori Keiko?"  
"Yes."

Yuu studied Kate's face but remembered her different original appearance.

"Salon de Ke. Where Masami-san was a regular. Remember?"  
"Hmm...... Ah! The owner!?"

About a year after marrying, Masami became a regular at Salon de Ke. Yuu once picked her up post-appointment and greeted the female owner. Taller than Yuu's original 170cm frame, she had neat black short hair like a Takarazuka male-role actor - minimal makeup, sharp eyes, slender build. Skilled too; Masami's style improved noticeably after visiting.

Many female clients adored the owner. Masami complained about wanting more time with "Keiko-san" instead of "Owner."

"Masami-san started calling her Keiko-san midway."  
"Yes."  
"Leader knew Yuu before?"  
"Not acquaintances, but we'd met. Completely forgot though."  
"Hey Leader, what were you like back then?"  
"Different impression but... beautiful, cool woman. Skilled hairstylist."  
"R-really...?"  
"Hohoho."

Kate seemed about to speak but Ryoko's question interrupted her.

"What were you like as an adult, Yuu-kun?"  
"Well... ordinary guy. School, job, marriage. Expected kids someday. Wanted simple family happiness. Then divorce... downhill from there."  
"Yuu-kun... It's okay. You have me now."  
"Thank you. Meeting you after rebirth is my greatest treasure."  
"Pfft! So cheesy!"  
"Don't add extra syllables!"

After the mood lightened, thoughtful Kate spoke.

"If you know... are there others like us? Reincarnated from another world?"

Yuu knew the answer but hesitated to share. Still, tonight's talk was secret anyway. One more secret wouldn't hurt.

His silence made Kate think he didn't know.

"Guess not..."  
"Actually, I know one."  
"*Gasp!*"

Not just Kate - Sayaka and Ryoko gasped too.

"But... deceased."  
"Deceased? Then... ah!"

Sayaka and Ryoko seemed to recall someone. Yuu nodded at them.

"Toyoda Sakuya."

Sayaka nodded understandingly. Ryoko looked stunned. Kate seemed confused.

"But how do you know?"  
"He's my father."  
"Father!?" "Seriously!?"

Ryoko was shocked. Sayaka already knew from engagement formalities.

"Ah right... Yuu kinda resembles that Sakuya guy. Before meeting Yuu, Mari and Ginko treasured magazines featuring him."

Yuu explained: His mother realized her pregnancy post-Sakuya's death, so they never met. Last summer, through the foundation, he learned details from Sakuya's wives. Thus, only Sakuya's first wife etc., knew about their reincarnation. Hugging Sayaka, he added:

"So I planned to tell my wives after marrying. Told you a bit early though."  
"Reincarnation doesn't matter. To me, you're just you. Nothing will ever separate us."

Yuu's chest warmed at her words. Sayaka was beautiful, strong-hearted, and precious. She then gave Ryoko a mischievous look.

"Ryoko knows our secret now - practically family. Maybe Yuu-kun should rein her in properly."  
"Yeah, good idea."  
"Huh!?"  
"Hey!"

Yuu touched Ryoko's hair past Kate's back. First met with ponytail, now worn down. Ryoko flinched but allowed it. Her repeatedly bleached/dyed hair felt damaged.

"As ex-salon owner, care for Ryoko's hair? She's pretty - dye it nicely?"  
"Wha!? P-pretty?"  
"Don't whisper in my ear!"

Amid the chaos, Sayaka beckoned Ryoko.

"What?"  
"Kate doesn't seem to hate Yuu-kun but..."  
"Ah, Leader? Rumors say she's either hung up on someone or a hardcore lesbian."  
"I can hear you! I'm just... uncomfortable with men!"

In this world, women uninterested in men but liking women exist - possibly more common than Yuu's original world. With scarce men, attractive same-sex companions spark romance. Near Yuu, former Riko and Sawa were similar. But women outright calling men "uncomfortable" are rare. Yuu understood, sharing original-world values.

"Sorry for touching/approaching casually. Please forgive me."  
"Not hate... okay. Apology accepted."  
"Good."

As calm returned, Yuu checked his watch: 10 PM. Time to wrap up. Then Kate murmured:

"Why were we reincarnated?"  
"Dunno... Dying at 40 seems too early? Capricious god's gift?"

Reborn as a teen despite dangers and sexual perks, Yuu never pondered deeply. Post-divorce life was downhill - he felt grateful for the reset.

"Not for me..."  
"Actually, I heard something."

Given Kate's circumstances, she might not feel grateful. Yuu deliberately changed subject.

"Haruka-san - Father's first wife - said modern gender ratios keep widening. Population will decline post-20th century peak. Some divine will summoned dead souls from other worlds to fix humanity's distortion. Maybe others reincarnated like Father and me. But they either didn't try changing the world or died mid-effort like Father. Baseless speculation though."

Nature doesn't guarantee 1:1 gender ratios - lions/seals have alpha males with harems; some species only mate seasonally. But humans originally had equal ratios. Post-Red Death, reversed roles might accelerate extinction. Perhaps reincarnators came to fix this.

"Assuming that's true... Sakuya and you were chosen men?"  
"Now that you mention it..."  
"Was I dragged along? You jumped in front of my car!"

Kate scowled, but Yuu had complaints too.

"Hey, I couldn't stop! Unavoidable! Legally, you're the perpetrator!"  
"Ah... right. My fault. Sorry."

Yuu's rebuttal made Kate shrink. As an adult, she recalled driver responsibility. Though Yuu held no grudge.

"Water under the bridge. And this is just speculation."

Had timing differed slightly that morning, the fatal accident might not have happened. Maybe Kate was fated to reincarnate with Yuu. Regardless, supernatural causes remained unknowable speculation.

With night deepening, they wrapped up. As only two known reincarnators, Yuu wanted to stay connected. Kate agreed.

"Even living apart, I want us as friends."

Yuu extended his right hand. Kate stared before sighing softly and shaking it. Her hand felt cold, so Yuu warmed it between both hands until she pulled away.

"Thanks Ryoko. If you don't mind, my gratitude."  
"Ah, Ryoko'd never refuse Yuu! Hah!? Mmmph...!"

Seeing Ryoko's reaction, Yuu silently embraced and kissed her. Though usually sharp-eyed, Ryoko's cheeks flushed red as they kissed, expression softening. She timidly hugged Yuu back, stroking his back. They kissed deeply, changing angles, holding tightly. When Yuu's tongue entered, Ryoko flinched but welcomed it with her own.

Like Yuu, Ryoko had worthless parents - rebellion was her only path. Fighting constantly, the Red Scorpions were her sole refuge - enemies were crushed mercilessly.

Yuu melted Ryoko's heart and body that day. After half a year, this embrace and deep kiss made heat surge through her as she desperately sought Yuu.

"Mmph, mmph, mmph... ah, Yuu... Yuu, ahh... more... lick, lick, mmph... huu... Yuuuuuu..."

Ryoko's denim jacket hung open. She pressed her breasts against her sweater and lower abdomen against Yuu. What began lightly intensified as Ryoko's enthusiasm aroused Yuu. They tangled tongues up/down, exchanging saliva in deep kisses. Yuu caressed her cheeks/nape with one hand while groping her shapely ass with the other, rubbing his hardening crotch against her. Feeling this, Ryoko moaned. Tears of joy welled in her eyes.

Watching Yuu/Ryoko kiss/embrace like reunited lovers up close, Kate stared dumbfounded at Sayaka.

"Really okay with this?"  
"Huh? What?"  
"Your fiancé doing that before your eyes."  
"If Yuu-kun were being forced, I'd stop him. But Ryoko isn't the type to assault men. Since Yuu-kun accepts her willingly, I welcome it."  
"Incredible..."

Kate couldn't comprehend Sayaka's composure. Sayaka smiled and put an arm around Kate.

"W-what!?"  
"Getting chilly. Need warmth."  
"Hey wait!"  
"Bragging before Yuu-kun, but pregnancy makes cold dangerous."  
"Ugh..."

Kate couldn't refuse. She accepted Sayaka's hug - easier than accepting an unknown man. Sayaka's warmth felt comforting.

"Kate."  
"Mmm... what?"

Their similar heights delayed Kate's response to Sayaka's whisper.

"Earlier... I admired your strength surviving alone. Regardless of your mother, you deserve respect. Be my friend?"  
"Ah... Okay. Gladly. Likewise."

Kate's cheeks flushed red under Sayaka's direct gaze - unused to such frank affection. She shyly lowered her eyes.

"Then, as friendship's proof."  
"Huh?"

Sayaka covered Kate's lips. Kate stiffened in surprise but found it strangely unobjectionable.

Yuu watched them intently. In the gazebo's darkness, the kiss between blonde/blue-eyed Kate and pure Japanese beauty Sayaka made a striking image. Mostly, he rejoiced at their bonding.

"Ryoko."

Yuu called to Ryoko, who was nuzzling his neck.

"Y-yes?"

Ryoko's face was fully in "female craving male" mode - she'd gladly spread her legs if pushed down. But starting here was impossible. Instead, Yuu's left hand held her waist while his right slid downward. His fingers slipped past her jeans into soaked panties.

"Ah, ah, Yu... Yuuuuuu!"  
"I'll creampie you deeply someday. Then carry my child."  
"Huh? Mmmph! Mmmh! Mmmmmmm~!"

Inserting his middle finger into her vagina while declaring this, Yuu kissed her again. With his finger deep inside, Ryoko climaxed within seconds.

---

Sometime after they left, someone crawled from beneath the gazebo. A woman of indeterminate age hid messy hair under a hat, wearing black-rimmed glasses and cloth mask. Her worn survival jacket and jeans were tattered - a homeless person at first glance. Anyone approaching would grimace at her stench.

But she was actually a Rescue Women Military Council executive who kidnapped a boy two months prior. She escaped police by ordering underlings to stall. After entering Saitama by train, they scattered toward a Gunma mountain hideout. Disguised as homeless to evade authorities, she slept in deserted parks by day and biked/walked north cautiously by night. In Saitō City, she nearly encountered patrol cars near Sairei Academy and took refuge here.

Finding the gazebo's deteriorating concrete foundation had a hollow space inside, she laid cardboard/newspapers for warmth, camouflaging it for days.

Drinking water and eating stolen convenience store bread, she replayed the conversation overheard beneath the floorboards. Staying motionless to avoid detection, she caught names like "Yuu," "Kate," "Sayaka," "Ryoko," and the shocking revelation about their reincarnation. Though pursued, she pondered exploiting this information.

---

### Author's Afterword

Next: A Kate-focused intermission before closing the chapter.

The Yuu×Ryoko scene might seem excessive but was Ryoko's reward for arranging the meeting.

Note: Kate isn't lesbian - Sayaka's unconsciously charming nature caused it.

Sayaka was already high-spec, but pregnancy/engagement honed her as a wife. Excellent mind, martial arts black belts, athletic. E-cup perfect proportions. Charismatic/charming (works better on girls). Flaws: Sometimes careless and single-minded when fired up, but aides prevent disasters. Future: Destined to lead a major Japanese corporation. Though she'd support him as a househusband, she'd fully back his dreams. Who wouldn't want such a woman?

2020/12/12 Edit: Slightly revised the eavesdropping woman's situation.

### Chapter Translation Notes
- Translated "東屋" as "gazebo" for accuracy in describing the park structure
- Preserved Japanese honorifics (-kun, -san) per style rules
- Translated sexual terms explicitly: "膣口" → "vagina", "中出し" → "creampie"
- Transliterated sound effects: "わちゃわちゃ" → "chaotic", "ごそごそ" → "rustling"
- Maintained original name order: "Hirose Yuu", "Komatsu Sayaka" etc.
- Italicized internal monologues: "（ち、近い！）" → "*(C-close!)*"
- Used ""..."" for simultaneous dialogue when multiple characters react identically