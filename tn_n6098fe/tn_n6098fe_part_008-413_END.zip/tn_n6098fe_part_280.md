## Interlude 9: Keiko's Recollection

### Author's Preface

I've slightly revised the situation of the woman eavesdropping at the end of Chapter 263.  
I only fixed parts that were unnatural in the situation - there are no major changes to the overall story.  

---  

I worked frantically as a beautician and achieved my dream of opening my own salon at age 28.  
Thanks to financial assistance from my wealthy stepfather, I was more fortunate than others in the industry.  

When I first opened 'Salon de Kei', most customers were regulars from my employed days, but new clients gradually increased through word of mouth. Business stabilized about a year later.  
I met the Hirose couple around that time.  

Hirose Masami came recommended by a regular customer's friend.  
Despite being in her mid-twenties, she had a delicate charm that made her seem childlike - the type you want to protect even as a fellow woman.  
I wondered what kind of handsome man her husband might be, but unexpectedly he was quite ordinary-looking.  
However, as someone who disliked confident, popular men despite my refined appearance, this left a good impression.  

Yuu-san - that was the husband's name - had a gentle personality that radiated inner kindness. His words and attitude clearly showed how deeply he cherished his wife.  
I only met and spoke with Yuu when he came to pick up Masami - just a handful of times - but to me, the Hirose couple seemed like an ideal married pair. At least that's what I thought back then.  

The salon's location was slightly removed from the station's bustling area, closer to a quiet residential neighborhood.  
This apparently appealed to female clients, and customer numbers grew steadily.  
About a year and a half after opening, a small article featured my salon in a magazine's beauty parlor special for married women.  
This caused customer numbers to double, making us extremely busy.  
Simply hiring more staff wasn't enough, so I switched to a reservation-only system.  
I worked nonstop except for one weekly closing day, completely exhausted by closing time, but they were fulfilling days.  

However, business success doesn't bring only good things - annoyances emerged too.  
New interview requests or cosmetics salespeople were manageable, but there were also recruitment offers from nationwide chain groups, suspicious investment proposals, and even men wanting to date me...  
As the client base grew, so did troubles. I even needed a lawyer to handle malicious complainers.  
I wanted to focus on beautician work, but non-core tasks increasingly consumed my time.  

What subtly wore me down were the persistent advances from enthusiastic female clients.  
I'd always known I appealed more to women than men.  
Though I never had a boyfriend in school, I received confessions from girls every year.  
Some even made forceful advances.  
This might have stemmed from my offhand comment - "I'm not really into men and don't want a boyfriend right now" - being distorted by others.  

After my parents divorced during my mother's pregnancy with me - she was also a beautician - we lived just the two of us. Many men pursued my eternally youthful, beautiful mother.  
But she had terrible luck with men, my father included.  
Some turned out to have massive debts demanding financial help, others became abusive after sex.  

Her first remarriage was to a cram school operator. He'd inherited a small neighborhood tutoring center from his parents, then expanded it by poaching talented instructors to specialize in private middle school entrance exams - a shrewd businessman.  
I understood why my mother was drawn to him - not bad-looking and always radiating confidence.  
He seemed perfect - competent at work yet family-oriented, and exceptionally kind to me as I entered the difficult age of sixth grade.  

At least he seemed much better than previous suitors, genuinely trying to be a good father.  
Though initially distant in this new male presence, I gradually warmed to this father who bought me clothes, game consoles - anything I wanted. I was just a child.  

But his true nature was that of a monster who repeatedly molested elementary school girls.  
As my guard lowered, he found increasing excuses to touch me, took photos of me in vulnerable states, and "accidentally" opened doors while I changed clothes.  
At least I was too old for shared baths.  

About six months after the remarriage.  
That day, my mother was dining with beauty school friends after work, and "Dad" often worked late. Having lived long in a single-mother household and with both working after remarriage, I was used to being alone.  
After eating dinner alone, bathing, finishing homework and school prep, I'd just fallen asleep when my stepfather silently entered and assaulted me.  

By sixth grade, I had some knowledge about such matters.  
At 155cm tall - above average for my class - my body was already maturing.  
Later testimony revealed he'd wanted to claim me before I fully matured - his selfish reason for violating his stepdaughter.  

But I differed from his previous victims - girls lacking sexual knowledge or constrained by teacher-student dynamics.  
Subconsciously taking my mother as a cautionary example, I'd developed a habit of distrusting men.  
So I fought back fiercely from the first moment he attacked.  
Knowing I couldn't match his strength, I immediately screamed loudly.  
I bit the hand covering my mouth, scratched with nails, tore hair.  

My mother returned early, worried about leaving her daughter alone. Hearing commotion, she first thought her husband had brought a mistress home - which had actually happened before.  
Instead, she found her husband and daughter locked in desperate struggle on the bed, covered in bruises and scratches.  

I'd never seen such fury on my mother's face.  
Without hesitation, she kicked my stepfather in the groin.  
As he writhed, she swiftly called police and had him arrested. Subsequent crimes came to light.  
The divorce proceeded methodically.  
My mother apologized profoundly. I was just relieved I'd protected myself until she returned.  

Though my mother said "I'm done with men," rejecting all suitors for five years, she eventually remarried.  
He was twenty years older than my then-40-year-old mother - practically a grandfather to me.  
Apparently, he'd met my mother two years after his regular-customer wife died and had pursued her ever since.  
My mother hadn't been interested so soon after divorce but relented after three years of persistence.  

This new father was the second son inheriting a famous Japanese confectionery shop - a good-natured rich boy.  
Though unremarkable as a businessman, he was an excellent husband and father, compensating for past misfortunes.  
Thanks to him, I pursued my desired career path and received substantial help opening my salon.  
He had one son who became a chef in Italy with no contact - fortunate not to be bothered by step-relatives.  

What troubled my seemingly successful salon career were human relationships.  
Men who pursued me would retreat when firmly rejected - the better scenario.  
Like regulars' boyfriends or married salon owners - why step on such landmines?  

The problem was women - over 90% of clients.  
I avoided appointment systems due to constraints, but felt genuinely pleased when clients requested me.  
I conversed easily with most female clients, and gaining regulars helped business.  
But however close we became, I wanted to keep it professional - no private interference. Not everyone understood.  

"Won't you visit that trendy spot from TV with me?"  
"Just work hours aren't enough - let's talk over a meal. I know a great place."  
"Could I see your lovely home just once?"  

I had no time for such things.  
On days off, I either slept exhausted or researched beauty trends - days vanished instantly.  
Women would invite me without considering my schedule.  

Being customers, I could only politely decline with a smile.  
Some understood it was just small talk.  
But one or two persistently refused to give up, aggressively closing in.  
I only shared salon contacts - never personal numbers or address - carefully avoiding exposure.  

That rumors spread about me preferring women despite no male presence might explain why some customers sought relationships beyond professionalism.  
An employee showed me such posts on social media, but I ignored them.  

Among customers escalating to stalking was Masami.  
Initially, she seemed incapable of such behavior.  
But perhaps reserved people internalize things intensely.  
I couldn't comprehend her developing feelings for me when so loved by Yuu.  

I simply disliked men with ulterior motives or outdated, abusive mindsets about female submission.  
My first time was in vocational school. After missing the last train post-drinking, I went to a male classmate's apartment and pushed him down for sex in drunken impulse. He was a quiet boy - not a boyfriend.  
I'd felt strangely aroused then. It ended after that.  

Meaning I'm completely normal - not lesbian.  
Yet when Masami dreamily declared "Keiko-san, you're my destiny! Please accept my feelings!" I couldn't reciprocate.  
Though I politely declined, she escalated.  

When away on errands, she'd persistently call about my return time.  
She'd watch from the café across the street, eventually ambushing me after closing, forcing harsh words.  
When she solemnly said "Understood" and backed off, I relaxed.  
I still saw her as a customer who'd understand if talked to.  
But such people's psychology is incomprehensible.  
Something in her seemed triggered.  

On a closing day, I slept late, ate lazily, and lounged when the doorbell rang unexpectedly.  
Masami stood there pulling a large trunk.  
Startled, I mistakenly invited her in to talk.  

"If you can't date me because you're married, Keiko-san... well, affairs are wrong even between women.  
But don't worry. I've properly divorced now."  

Beaming, Masami left me speechless.  
Taking silence as agreement, she cheerfully continued.  

"Hmm... first time inside. Nice apartment. Plenty big for two.  
A bit messy though. Dust in corners... but you're busy, Keiko-san.  
I'll handle everything now. Housework, anything. In return... pamper me sometimes..."  

Masami's cheeks flushed crimson like a schoolgirl's.  
I'd heard she chose all-girl schools and female-dominated companies because she disliked men.  
Initially, I thought we'd get along.  
But seeking same-sex substitutes divides people.  

My stepfather's assault during puberty - not quite trauma but impactful - made me reject confident, selfish men. Work priority also sidelined romance.  
Meeting a gentle man like my current stepfather earlier might have changed things.  

In that sense, I'd even envied Masami for finding a good partner.  
Her divorcing was fine, but forcing herself on me without consultation was pure nuisance.  
Later I learned she'd sneaked into the salon office on an off-day pretending to use the restroom, stealing an envelope from the trash (likely tossed intact by a lazy employee) to get my address.  

While Masami bubbled about our future, my heart chilled.  
Suppressing emotions, I calmly told her to leave.  

But no words made Masami grasp my discomfort.  
Though speaking Japanese, we couldn't communicate.  
Cherished by parents and husband, she couldn't fathom her feelings being dismissed.  

My precious day off was consumed handling her.  
Having consulted police about past stalkers, I knew they wouldn't act without physical harm - only "civil matter."  

That night, I ignored Masami completely.  
She started sobbing meso meso at being ignored, but I locked myself in the bedroom.  
I hoped she'd give up and leave, but Masami proved unexpectedly tenacious - or mentally unfathomable.  

Returning late from work next night, she greeted me beaming as if nothing happened.  
Not only was the apartment spotless, but redecorated, with a celebratory feast prepared.  

I locked myself in the bedroom and contacted the friend who introduced Masami, asking her to have Masami's parents collect her immediately.  
Early next morning, her parents and sister from Tochigi came and took her after commotion. They seemed decent people - luckily - and hadn't known about the divorce.  

But when Masami escaped home a week later, I decided to move.  
Relocating the salon was impossible, so she kept coming.  
Had she been violent or destructive, I could've called police. But she wasn't.  
She'd enter as a customer, endlessly ranting about her feelings for me and complaints about interfering family. When ejected for disrupting business, she'd stare at me outside. A horror movie presence.  
Her family would take her home, but she'd escape at every chance.  
This repeated for a year before suddenly stopping.  
Masami's mother came to apologize, explaining they'd finally hospitalized her locally. The mother, worn down by her mentally ill daughter's turmoil after a happy marriage, looked aged.  

"Anyway, Leader, what do you really think about Yuu?"  
"Huh? Oh... fine as a friend, I guess."  
"Eh? Like... wanna have sex?"  
"Se...!? Wha-wha-wha... not that far!"  
"Kukuku. Just once wouldn't hurt. It's not like you'd lose anyth... oh right, men lose semen. But Yuu seems fine even consecutiv... ouch! Okay, stop kicking!"  

After parting with Yuu and leaving the park, walking to my parked motorcycle with Ryoko, we exchanged such banter.  
Despite my mental age being higher, I couldn't match my peers in sexual topics.  
Well, girls this age freely make dirty jokes - especially aggressively among themselves.  

Realizing I'd reincarnated as a 15-year-old Caucasian girl - with exceptional beauty and proportions - while discovering my mother's awfulness left no peace.  
Learning the 1:30 gender ratio where men rarely appear publicly and women dominate society shocked but gradually normalized me.  
After fierce fights with my monstrous mother Jane - worse than stalker Masami - I avoided her for mutual benefit, indulging in nightlife.  
A girl wandering night streets attracted no male attention - men don't roam alone.  
Instead, all delinquents harassing me were female - refreshing.  

Though home life was awful, high school after 22 years and hanging with Red Scorpions friends from nights out were fun.  
Until Jane caused that incident.  

"Leader's a bit unconventional... maybe you have another man preserving chastity?"  

Hearing Ryoko's mutter, I reflexively reacted.  

"Well... there was one man I noticed."  
"See! What kind?"  
"Th-that was long ago!"  
"Long ago? When? You're 16... oh right, reincarnated, before dying?"  
"Secret!"  

The man who came to mind was Yuu from my past life - met just once.  
But I couldn't possibly say that.  
While troubled by Masami's actions, I'd wondered how she'd react if I dated her "discarded" Yuu.  
"If you don't want him, I'll take him" - but I doubted inexperienced me could easily attract Yuu, leaving it a passing thought.  

Despite the skewed gender ratio, I still can't accept this world's norm of multiple women sharing one man.  
That Yuu had consecutive sex with four of our members, and has three fiancées (including Sayaka!) - pregnant! - is unbelievable.  
Everyone idolizes him while accepting his multi-partner relationships as normal.  
He became high school student council president as a first-year, fully adapting to this world and living proactively.  
I can't deny feeling envy or resentment.  
But earlier he apologized for touching me carelessly. Hearing that, I was glad his kindness remained.  

Come to think of it, I never told him I caused his divorce.  
That's my only regret.  

---  

### Author's Afterword

This concludes Part 7.  

For pre-reincarnation Yuu, Masami was his ideal woman whom he loved sincerely, but such relationships are complicated.  

With Yuu and Kate's connection established, Part 8 will focus on Sairei Academy (e.g., school festival) for a while.  

However, Part 8's plot isn't progressing well...  
Apologies, but the next update may take over ten days.  

As compensation, I'll post a completed novella (approx. 45,000 characters) from another site around next weekend.  
Similar to *Reborn in a Chastity Reversal World*, it features a male protagonist taken from train gropers to a love hotel for intercourse - a concept I couldn't use here.  
If interested, please read it.  

↓Posted 12/19-20 (9 chapters complete)  
*When the Door of Time Shifted*  
https://novel18.syosetu.com/n2690gr/  

2021/9/10  
Added revisions: Details about Yuu meetings during marriage and Keiko's first experience episode.

### Chapter Translation Notes
- Translated "サロン・ド・ケイ" as "Salon de Kei" preserving the French naming convention
- Rendered "めそめそ" as "meso meso" for the sobbing sound effect
- Maintained Japanese name order: "Hirose Masami" (広瀬 麻沙美) as used in narrative
- Translated sexual terminology explicitly: "性的行為" as "sexual acts", "襲われた" as "assaulted"
- Italicized internal thoughts like *Why would she...?* for implied monologues
- Preserved cultural terms like "トランクケース" as "trunk case" without localization
- Used direct anatomical terms: "股間" as "groin", "貞操" as "chastity"
- Kept honorific "-san" in "Yuu-san" per translation rules