## 265. Sairei Festival Preparation ② ~Single-Minded Pure Heart~

### Author's Preface

I forgot to mention last time that I've added characters from Chapter Seven to the "Character Introduction" section.

The "Character Introduction" has become quite extensive now.

There are so many characters that even I, the author, forget their features and what they did.

I considered splitting the "Character Introduction," but since it would misalign with the chapter numbers, I've left it as is for now.

And even as we enter Chapter Eight, new characters will continue to appear.

---

Within the Ayakuni Group, Saibo Academy was the first to be established and has now become one of the prefecture's top academic schools. It also includes a middle school division.

While Sairei Academy has always had some connections with group-affiliated high schools, they've particularly increased this year. However, there had been no special connection with Saibo Middle School.

Only a few students from Saibo Middle School, interested in it being a co-ed school within the same group, had taken exams and enrolled.

Inviting Saibo Middle School students to the cultural festival was unusual, but no objections were raised. The Saibo Middle student council panicked upon receiving the notice but couldn't possibly decline such an invitation. They immediately accepted Yuu's proposal for a secret meeting between student council presidents.

In the student council office, sitting seiza-style facing Yuu was the Saibo Academy Middle School student council president. Like Yuu, she was a second-year elected in October: Asagi Ruriko.

Her height was slightly shorter than Yuu's, around mid-160cm. Her slender figure was clad in the same black sailor uniform as Saibo Academy High School—the difference being a white ribbon. The skirt was long enough to nearly cover her calves, with white school-designated socks on her feet.

Her black hair was tied in a single bundle at the nape, the ends reaching mid-back. Her meticulously neat appearance, as if preparing for a high school entrance interview, epitomized a well-behaved middle school girl. Her nervous stiffness stemmed from being alone with a boy in a closed room for the first time.

Yuu began with small talk to help her relax, starting with questions about Saibo Middle's student council and school life, with Ruriko responding. Though initially avoiding eye contact and speaking minimally, Ruriko gradually opened up and began asking about Sairei's situation. In this regard, she seemed bolder than Aizawa Midori, the high school student council president at Saibo Academy.

When Yuu broached the main topic—inviting up to 30 students to the cultural festival—Ruriko immediately bloomed into a lovely smile. Her joyful demeanor wasn't boisterous but carried a calm dignity. To Yuu, she seemed less "cute" and more a cool beauty type. As expected of a student council president, she possessed an un-middle-school-like composure while appearing somewhat mature. Perhaps Riko had been similar during her middle school years. However, the way she blushed and averted her eyes whenever meeting Yuu's gaze felt genuinely fresh and innocent.

"Being invited to Sairei's cultural festival... I'm truly honored. Our students will surely be delighted too."

"That's good. Then may I leave the selection and precautions to your student council?"

"Yes! Since we've been invited, I'll ensure thorough selection and caution to prevent any mistakes."

Yuu smiled at her earnest promise, made with clenched fists. Though the official festival pamphlets for invitees weren't complete yet, he handed her a prototype copy. She now scrutinized it intently.

"But still, being invited to a co-ed school's festival is a first... What kind of atmosphere should we expect?"

"Well... this is my first time too, so I don't know details. But unlike previous years, all boys are participating this time. So there will be male-led events... see, it's written here."

Yuu leaned forward, pointing at the open pamphlet. Their faces drew so close that his breath touched her, staining Ruriko's cheeks crimson. Her utterly innocent reaction was adorable. Simultaneously, seeing her downcast eyes with their long lashes and almond shape made Yuu want to tease her. He took Ruriko's hand—a small, smooth girl's hand.

"Ah...!"

"I'll be participating too, so please come see me."

"Y-yes! Ab-absolutely! I'll definitely come watch!"

Smiling while maintaining eye contact, Ruriko nodded, her face still flushed red.

The meeting progressed smoothly, and they finished today's agenda, but there was still some time left. Yuu decided to spend every last minute chatting with this beautiful middle school student council president. Ruriko placed a hand on her chest as if calming herself, then spoke again.

"May I ask one thing?"

"Sure. Ask anything."

"Why... did Hirose-san become student council president despite being male?"

"Hmm?"

"Ah! Of course, I thoroughly read the Weekly Fuji article sent to our student council. 'Wanting to contribute to my alma mater. Gender doesn't matter. Though just a first-year, I want to do what I can.' That determination is truly admirable. But I wondered if there might be another reason not mentioned in the article."

Ruriko explained she had an older male cousin who attended a boys' high school. They played together as children, but he became distant around middle school, barely conversing even at family gatherings. At most, he'd give curt one-word replies. Sometimes he'd ignore her when in a bad mood. Their mothers said this was normal for young boys—essentially treating him like a fragile object.

Yet Yuu, the same age, remained composed even surrounded by girls and conversed naturally with her, a first-time meeting. The idea of a male becoming student council president in a female-dominated school was unbelievable, and not just the student council—the whole school buzzed about Yuu.

While Yuu had indeed chosen his words carefully for the Weekly Fuji interview as a formality, his true feelings weren't far off. Still, for someone like Ruriko who only knew ordinary boys outside Sairei, such doubts were understandable. He answered with a wry smile.

"That's... not so different from your reasons or other student council presidents, I think. I love this school and want to improve it. Well, in our case, since it's co-ed, I want to actively foster friendships between boys and girls—not just out of obligation but proactively from my position as a boy."

"I... see."

Ruriko looked unconvinced, so Yuu continued.

"Besides, I had good role models. One was former student council president Komatsu Sayaka. The other... a man named Toyoda Sakuya."

"Ah!"

Ruriko seemed to finally understand, apparently recognizing the name.

"But thinking and acting are different. It must have taken tremendous courage. Weren't you scared? Becoming student council president alone is unprecedented, but then giving interviews and becoming so conspicuous... Ah, but thanks to that, we got to know about you, Hirose-san, which is good..."

Yuu smiled, touched that she'd thought so deeply about him despite their first meeting. Unthinkingly, he took Ruriko's hand again and gazed directly at her. Though momentarily flustered, this time she met his gaze steadily.

"Apparently I'm unusual—I don't find girls scary at all, and being alone in a room like this doesn't bother me... well, that's not entirely true. Even with a younger, pretty girl like you, my heart races."

"Fweh!?"

Ruriko's face flushed crimson again, just as she'd regained composure. Yuu smiled and continued.

"I know in this world, oddballs like me are rare, and boys like your cousin are the majority. But if possible, I want high schoolers to interact with girls without fear—not because they're forced to, but because they choose to. Starting within my reach. That's what I think."

"Y-yes."

Yuu noticed the clock. Though he wanted more time with her, it was almost time to go. Student council work awaited him later. Keeping hold of Ruriko's hand, he stood up.

"Then, see you at the Sairei Festival. I'll be waiting."

"Yes! I'm looking forward to it."

Her nodding head was adorable. Reflecting, since his rebirth before high school, most women Yuu grew close to were older—few were younger.

"By the way, it might be early, but have you thought about your future path?"

"Um..."

Ruriko's eyes darted. Rather than undecided, she'd likely already chosen one of the prefecture's top high schools... but perhaps this encounter had shaken her resolve.

"Umm..."  
"Go ahead."

After a moment's hesitation, Ruriko spoke with determination.

"I... I want to become Hirose-san's junior... would that trouble you?"

"Trouble? I'd welcome it! Please come to Sairei and become my junior."  
"Hyaa!"

Delighted by her request, Yuu hugged her. Though tall, her body felt fragile enough to break in his arms. Yet he sensed a girl's unique softness and pleasant fragrance. Meanwhile, experiencing her first male embrace, Ruriko's face turned redder than ever, as if steam might rise. Consequently, her body stiffened completely, leaving no room to hug back.

The day after meeting Saibo Academy Middle School's student council president Ruriko, the three sister school presidents visited Sairei Academy. They arrived earlier than expected, having apparently shared a taxi right after classes.

Today's agenda was festival invitation planning. Though they'd used the student council office during their first meeting, today it was occupied by executive committee members preparing for the festival, so they borrowed a room on the dormitory's third floor. Yoshie and Nana had offered to attend out of concern for Yuu, but extra hands were needed for preparations. He asked them to help there instead.

Smiling awkwardly at Yuu was Saibo Academy's student council president, Aizawa Midori. Her hair was neatly braided in two pigtails parted down the middle. With a round face and thick-lensed glasses, she looked the studious type. Her orthodox black sailor uniform featured an unusually long skirt for modern times. Being the smallest of the three, she appeared childish. Had she stood beside yesterday's Ruriko, it'd be hard to tell who was older.

In contrast stood Saiai Academy's student council president, Hinuma Shuri. Whether always like this or dressed up for Yuu, her makeup was flawless. Her long hair, mixed red-brown-gold, had soft permed waves. In anything more revealing than her dark gray sailor uniform, she could pass for a hostess club girl. Most eye-catching was her skirt length—already above the knees last time, today it seemed even shorter. Barely covering her hips, it would surely reveal her panties if she sat down. Taller than Yuu with noticeable breasts and excellent proportions, her thighs were exposed to a risky degree. Noticing Yuu's gaze drawn to her legs upon meeting, Shuri struck a pose with a triumphant expression.

Lastly, Saiei Academy's student council president, Mikageishi Mayo. At first sight, Yuu thought she was someone else—she'd chopped off her waist-length black hair into a nape-revealing short cut. The one-sided fringe covering half her face remained, but the refreshed look improved her impression. Her formerly pale complexion now had some color, and she wore reddish lipstick. Perhaps she'd finally grown accustomed to being student council president. However, even after entering the 8-tatami Japanese-style room in the dormitory and sitting around the low table, Mayo fidgeted without making eye contact until Yuu addressed her.

"You cut your hair. I barely recognized you, but it looks mature and suits you well."  
"Eh... r-really? I'm glad."

Having apparently been anxious, Mayo smiled shyly when praised by Yuu. Previously unsettling due to unhealthy thinness, her short hair now gave her a mysteriously attractive aura.

"Araaan. What about me? I put effort into looking good for Yuu today~?"

Leaning over the table from Yuu's right was Shuri. Her long hair cascaded down, and an adult-like perfume tickled his nose. Her open collar revealed not just collarbones but threatened to show cleavage. Turning to Shuri, Yuu smiled confidently and naturally extended his right hand. Stroking her fluffy hair, he brought his mouth near her ear and whispered.

"Of course, Shuri's unbelievably sexy and beautiful for a high schooler."  
"...!"

*Bam!*

The one who slammed both hands on the table was Midori, sitting formally opposite them.

"We're wasting time. Shall we begin?"  
"Ah, sorry. Let's start."  
"Y-yes."  
"Mm."

Contrasting with Mayo and Shuri—pleased by Yuu's compliments—Midori's stiff tone made all three reply hastily.

---

### Author's Afterword

This is the final update for the year. The first update of the new year will be on 1/6 (Wednesday).

Everyone, please have a wonderful New Year!

### Chapter Translation Notes
- Translated "一本気純情派" as "Single-Minded Pure Heart" to capture the earnest and innocent personality traits emphasized in the chapter
- Preserved Japanese honorifics (-san) and name order (Asagi Ruriko) per style guidelines
- Maintained explicit anatomical descriptions (e.g., "胸の谷間まで見えてきそう" → "threatened to show cleavage")
- Transliterated sound effects: "カチカチ" → "stiffness", "ばん" → "*Bam!*"
- Translated culturally specific school terms consistently: "セーラー服" → "sailor uniform", "正座" → "seiza-style"
- Rendered dialogue with new paragraph formatting except when attribution precedes speech
- Kept specialized terms like "Weekly Fuji" and "Ayakuni Group" as established in Fixed Reference