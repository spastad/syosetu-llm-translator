## 266. Sairei Festival Preparation ③ ~Don't Take Off the Sailor Uniform~

### Author's Preface

Happy New Year.

We look forward to your continued support for 'Reborn in a Chastity Reversal World' this year.

The medium-length chastity reversal story posted on December 19-20 last year is here (9 episodes complete).

'Beyond the Door of Time'

https://novel18.syosetu.com/n2690gr/

---

"Until last year, Sairei Academy's festival only invited up to 10 student council members from our sister school Saiei. But this year, we've decided to invite students from all junior and senior high sister schools. Since 10 people is too few, we'll allow up to 30 per school. I already informed the Saibo Middle School student council president yesterday."

"Ooh!"

"Heeeh~"

"Hoh"

Having anticipated today's gathering about Sairei Academy's festival, the reactions were somewhat expected. Midori openly rejoiced with a fist pump before shyly lowering her hands when Yuu looked at her. Shuri maintained her expression but smiled happily. Mayo remained impassive with little change in expression.

"A-a coed school festival... What does it feel like to have male students in the school? I can't imagine."

"Hmm~. But even if we go, won't Sairei's female students be tightly guarding the boys?"

"That's possible."

"Male performances will be held in the gymnasium with extra seating. We won't exclude students from other schools."

"Hohoh!"

"However, it's strictly forbidden to act strangely or get overly excited upon seeing boys. This trial expansion of sister school invitations could collapse otherwise, and you might get banned from future events."

The three student council presidents nodded solemnly at Yuu's words. Many girls at all-girls schools have lived without exposure to boys their age. Yet late teens are precisely when interest in the opposite sex peaks. It's unpredictable how they might react upon seeing real boys up close for the first time. Until last year, invited Saiei students were strictly monitored to prevent contact with male students. During prior student council discussions, Saiei was deemed highest risk, followed by Saiai, while academically-focused Saiho was considered relatively stable. However, even studious girls might not remain calm around boys. The three presidents here with Yuu in this private room maintain composure due to their sense of responsibility as school representatives and mutual wariness among unfamiliar sister council presidents.

"Along with careful selection, we need thorough warnings."

"It'll be difficult even with student council leadership. This news will cause an uproar throughout the school."

"Also, the campus might become chaotic."

"Well, we'll have to leave that to each student council. Considering the future, I'd prefer focusing on first and second years."

To deepen future sister school exchanges, student council members would naturally attend. This would likely lead to selecting students close to the councils, inevitably causing dissatisfaction among others. Thus, they agreed on clear selection criteria: top academic performers at Saiho, competition winners at Saiei and Saiai.

"Thirty people... hmm, a flat thirty?"

Shuri rested her cheek on the low table while muttering thoughtfully. After glancing at Midori and Mayo in turn, she looked at Yuu and declared:

"Considering total student numbers, our school faces the fiercest competition."

"Huh?"

Sairei has the largest enrollment among the four schools, nearing 900 students since April with monthly transfers. In contrast, academically selective Saiho has only about 400. Saiei has slightly over 500, while Saiai exceeds 600 due to its vocational programs.

"Roughly speaking, we have 1.5 times Saiho's enrollment. So by enrollment ratio, Saiho should get 20 spots and Saiai 30. Or increase Saiai's quota to 45."

"Th-that kind of demand is inappropriate!"

"Eh? Why?"

"Being formally invited to a coed school festival is already an honor and rare opportunity. Making demands as invitees would complicate matters unnecessarily!"

"But still..."

While Shuri's argument had merit, Midori naturally resisted being disadvantaged due to smaller enrollment. Mayo silently observed their argument, perhaps because she had few connections with the previous student council. She seemed detached from the conflict.

Leaving Midori and Shuri to argue would likely escalate tensions since they were fundamentally incompatible. Yuu leaned forward and placed hands on their shoulders.

"Wait. Please listen."

"Ah!"

Yuu stroked their hair as both froze simultaneously. His left hand gently slid from Midori's neatly braided hair to her cheek, immediately flushing it crimson with heat. His right hand caressed Shuri's fluffy long hair down to her slender neck, drawing a sensual sigh of "Ahfuu" when touched.

The effect was remarkable. Both narrowed their eyes in pleasure. Mayo watched intently, thinking she should have joined the argument if it meant receiving such attention.

Yuu gradually realized Shuri wasn't seriously demanding more spots. While appearing to argue with Midori, she kept glancing at Yuu - using enrollment numbers as leverage to extract personal favors. Indeed, Shuri placed her hand over Yuu's on her neck, gazing at him expectantly. So Yuu slid his right hand sideways to cup her chin, leaned in, and covered her deep pink-rouged lips.

"Mmph!"

Shuri's eyes widened momentarily before closing. This was her first kiss, and her heart pounded violently though she struggled not to show it. Yuu's right hand had moved to her nape while his body pressed closer. Hiding her joy, Shuri trembled as she pinched Yuu's clothes - her utmost effort as a virgin with no sexual experience despite her carefree facade.

"How nice."

Mayo murmured while watching Yuu kiss Shuri. Midori remained silent but shared the sentiment, hand on the cheek Yuu had touched earlier.

***

After a brief kiss, Yuu pulled back after over a minute. Shuri slowly opened her eyes, tearfully looking up at him - clearly moved by her first kiss, not accustomed to it. Deeply touched, Yuu scooted closer and embraced her.

"A-ah, um... mmph!?"

Yuu cradled Shuri's head with his right hand and pushed her onto the tatami. Feeling her soft yet defined body heightened Yuu's arousal. He kissed her repeatedly from different angles as Shuri's mind reeled, surrendering completely. She accepted when Yuu's tongue parted her lips and entered her mouth.

"Fweh!? Nmm... nn, fa... anm... slurp, nnn... naaah... ahh, ohh, ufuh, nmph, julu reloo..."

Cradled and pinned under Yuu's weight, the deep kiss continued. Their tongues pressed together, exploring from gums to inner cheeks. Yuu's tongue roamed freely through Shuri's mouth. Intoxicated by unfamiliar pleasure, Shuri wrapped her arms around Yuu's back, clinging tightly while whimpering. Yuu's leg slipped between her thighs. His left hand groped her breasts over the sailor uniform, enjoying their palm-filling volume with measured pressure.

After enjoying the wet, slurping deep kiss, Yuu slowly withdrew his tongue, leaving strands of saliva trailing back into Shuri's open mouth.

"Nkuh... haa, haa... hey, ah... fam"

Her words cut off as Yuu's tongue approached again. Shuri extended her tongue to touch his tip. Eyes closed, they entwined tongues.

Yuu lifted the short sailor uniform hem to touch bare skin. Despite the cooling weather, she wore nothing underneath. A black lace bra came into view.

"Seriously, too erotic."

The cups swelled to create cleavage. After a glance, Yuu sucked her neck while their lips remained wet, licking upward to her ear.

"Shuri, are you actually a virgin?"

"Hweh? Nya, what are you saying!?"

Yuu had only been fishing, but it struck true. Her ears turned crimson. The mature-acting Shuri revealed her true teenage self. In this world, many seemingly experienced girls are actually virgins. Yuu wanted to be her first man.

"Can I be the one to take your virginity?"

"Eh... y-yes"  
"Fufu, you're adorable, Shuri."

As she meekly agreed, Yuu covered her lips again while unhooking her bra. Released from the cups, her ample breasts swayed and bounced with ragged breaths. Her matching black lace panties came into view, translucent fabric revealing dark pubic hair and damp crotch fabric.

Refusing served food shames the man. Having come this far, backing out was impossible. Yuu quickly removed his shirt and pants, leaving only a T-shirt and trunks. His fully erect penis visibly tented the fabric.

"Wa..."

Midori and Mayo covered their mouths in astonishment. Shuri stared blankly too but tried to sit up upon remembering women should initiate actions - including undressing men and folding clothes.

"Me..."  
"Stay like that."  
"But..."

Yuu pinned her down again, admiring her alluring body. Bringing his lips to her ear, he whispered:

"Don't worry. Leave it to me."  
"Tha... nnn! Fuu...n... ah, aahn!"

He kneaded her magnificent breasts that remained full without the bra - soft yet elastic, molding in his palms. His lips traveled from her ear down her neck to collarbone before sucking hard. Already sensitive from his touches, Shuri cried out when he flicked her nipples with his tongue. Simultaneously, his left hand stroked from her waist's curve to buttocks. With Yuu's leg between her thighs, his fingers touched her panty crotch.

"Nnn! Ah... there..."  
"Just as I thought. You're soaking wet. Shuri's quite lewd."

Touching her vaginal opening beside the damp fabric produced a squelch, immediately coating his fingers with love juice. Blushing deeply, Shuri moved a hand from his back to caress his cheek.

"Tha... that's... can't help getting... aroused. I... fell in love at first sight... this was my dream."  
"Truthfully, I've wanted to have sex with Shuri since the beginning."  
"Aahn! I'm happy... hey, can I say your name?"  
"Of course, Shuri."  
"Yuu! I love you... I love you so much!"

Yuu sealed her lips in response.

***

"Hyah! Ah, ah, aahn! N-no! S-such a thing... haun! Yaaaah! I can't... take it... c-cumming, I'm cummiiing!"  
"It's fine. Cum. Hyora."

While sucking her breasts - licking, nibbling, sucking - Yuu continued teasing her clitoris with featherlight touches. Already on edge, Shuri couldn't endure when he inserted his middle finger into her vagina and pumped. Her hymen had apparently been broken by toys, allowing easy entry, but her virgin passage remained tight. Love juice overflowed, splattering the tatami.

Reaching climax easily at Yuu's encouragement, Shuri lay spread-eagled and limp. Deeming the time right, Yuu slid off her damp panties and removed his trunks.

"Hih!"  
"What is that..."

His penis stood fully erect against his abdomen. For Midori and Mayo with minimal sexual knowledge, its size, thickness, and appearance were shocking. Ignoring them, Yuu positioned himself over Shuri's exposed lower body.

"Huh? Wha...?"  
"I'm entering? Shuri."  
"Eh? Eh? Why? Ah... no way... aahn! Yuu... hih! S-something hard!?"

Feeling Yuu's weight brought joy, but the hard object against her startled her. Still basking in post-orgasmic bliss, Shuri hadn't noticed his erection.

The tip slid in smoothly. Though her hymen was broken, taking a girl's virginity thrilled Yuu. Moreover, her dark gray sailor uniform remained on - only underwear removed - making uniform sex irresistible.

But Yuu proceeded patiently without rushing. When the glans was swallowed, her vaginal walls resisted deeper entry, so he used shallow thrusts to advance gradually.

"Ugh... kuu... ahh, inside me... Yuu's... penis is... entering?"  
"Yeah. Your pussy's tight, so I'll go slow. Does it hurt?"  
"Nn! I-I'm fine, no problem... gyaah!"

Frowning in discomfort as she accepted her first penis, Shuri gripped Yuu's back tightly. Having taken many virgins, Yuu found her relatively easy - likely due to prior dildo use. As shallow thrusts continued, his penis steadily penetrated until finally hitting deep inside.

"Kuhii! Ooh... ah... d-deep..."  
"Congratulations on graduating from virginity. Phew~~ Shuri's pussy feels amazing. I almost came."  
"Ha... hi... good, so good... sob... why am I... crying when I'm happy?"

Tears trailed down her cheeks. Yuu caught them with his finger, licked it, and smiled. Men weaken at women's tears - knowing they sprang from moved happiness deepened his affection. He kissed her again. Shuri hugged him tightly without reservation.

"I'm moved too, having sex with a wonderful woman like Shuri. I'll start moving now, okay?"  
"Haaah? Ahn! W-wait... Yuu's... too big... didn't know... hyaun!"

Yuu began gently thrusting for his virgin partner. Pain now overcome by pleasure, Shuri cried out joyfully at receiving a man for the first time.

### Chapter Translation Notes
- Translated "セーラー服" as "sailor uniform" to maintain school attire specificity
- Preserved Kansai dialect markers for Hinuma Shuri's speech (e.g., "やん" → "isn't it", "や" → informal copula)
- Transliterated sound effects: "ぴちゃぴちゃ" → "picha picha", "じゅるれろ" → "julu reloo"
- Translated explicit anatomical terms directly: "チンポ" → "penis", "膣" → "pussy/vagina"
- Rendered sexual acts without euphemisms: "ディープキス" → "deep kiss", "挿入" → "insertion"
- Maintained original name usage: "祐" → "Yuu", "碧" → "Midori", "朱里" → "Shuri", "真夜" → "Mayo"
- Italicized internal monologues: "（それはわざと相手に見くびらせるためのポーズでしかなかった）" → *(It was merely a pose to deliberately make the opponent underestimate her)*