## 267. Sairei Festival Preparation ④ ~They Won't Stop~

Partly because it was today's first ejaculation, but more so because the virgin vagina that had accepted a man for the first time was exceptional.  

Though Yuu had intended to endure, when he came, it was abrupt—yet with the greatest pleasure that made his whole body tingle—as he released a considerable amount of semen inside Shuri.  

After holding each other and exchanging kisses for a while, Yuu became concerned about Midori and Mayo behind him and decided to pull out.  

The tip of his slowly withdrawn cock trailed a string of cloudy fluid, looking as if reluctant to part.  
The freshly vacated vaginal opening gaped open, twitching as if begging for more.  
The surrounding area was drenched in their mixed sweat and love juices, the wet pubic hair clinging lewdly.  
After a moment, semen that had flowed back from deep within the vagina began to seep out slowly.  
Yuu immediately grabbed several tissues from the low table and pressed them against her.  
Shuri herself had her eyes closed, still in a dreamlike state.  
Her legs remained spread, and with each breath, her heaving chest rose and fell visibly.  

Yuu temporarily turned his attention from Shuri toward Midori and Mayo.  
When they noticed Yuu watching, they flinched and averted their eyes—but it was obvious what they'd been doing moments earlier.  
Their flushed faces and hands still tucked inside their skirts gave them away.  

Yuu smiled and stood up.  
Despite having ejaculated, the thing between his legs remained erect, pointing skyward.  
The ignited passion hadn't cooled, now directed at the other two.  
Midori and Mayo froze, unable to look away from Yuu's crotch.  
Yuu sat between them from behind, spreading his arms to pull them close.  

On his left was crimson-faced Midori, glancing up at him with upturned eyes.  
On his right was Mayo, looking down with flushed cheeks.  
While debating whom to choose first, Yuu's mouth captured Midori's slightly parted lips.  

"Mmmpf!"  

Excited, Yuu not only pressed his lips but forcibly pushed his tongue into Midori's mouth.  
Using his extended tongue, he tangled with hers, pushing it upward.  
Perhaps she'd been expecting it—Midori obediently accepted Yuu's advances.  

"Kkh... nyeh... ahp... uun... chu, chup... jurl... ahh..."  

Hearing a pitiful "Auuuun" from his right, Yuu broke off and turned to Mayo.  
Her large, dark eyes—which had seemed slightly eerie at first sight—were now moist as she gazed at him.  

"Mayo. Open your mouth a little and stick out your tongue."  
"Nn... kay."  

Mayo's pursed lips parted slightly, revealing a red tongue.  
Yuu prodded it with his own tongue.  
As their mucous membranes touched in this initial kiss, Mayo's expression melted, her lips naturally opening wider.  
Seizing the opportunity, Yuu overlapped their tongues while joining their lips.  

"Nn, nn, nmmo... fwo... uun! Ofo, jurl... nfuun"  

The kiss seemed too intense for her first time.  
Held by Yuu, Mayo let out whimpers while her slender body trembled violently.  

After several rounds of alternating kisses with Midori and Mayo, the two who'd initially been reserved now clung tightly to Yuu, running their hands over his chest and back to savor his firm muscles.  
Pressed between two girls while alternating deep kisses, Yuu's excitement only grew.  
Naturally, both Midori and Mayo couldn't ignore the still-erect cock at his crotch, but neither could bring themselves to say it.  

"Nn?"  

Yuu smiled at Mayo's dazed expression after pulling away with her tongue still out, but noticed Midori rubbing her cheek against his chest while staring fixedly at his lower abdomen.  

"Midori, curious?"  
"Eh, hah! Um..."  
"It's fine. Touch it. But in exchange, let me touch both of your precious places too."  

Neither Midori nor Mayo showed any resistance to baring their skin, nodding vigorously.  
Though virgins showing some shyness would've been more exciting, not everything goes as planned.  

At Yuu's request, Midori kept her uniform on but removed only her underwear.  
Lifting her sailor dress along with her innerwear, her unexpectedly full breasts were revealed when her plain white bra came off.  
Though the shortest of the three, her breasts had clearly received ample nourishment.  

Sairei Academy's uniform was a one-piece sailor dress, making partial removal difficult.  
While Yuu was admiring Midori's beautiful breasts, Mayo had somehow become completely naked.  
Her overall figure was slender with little flesh—almost concerningly thin.  
Judging cup sizes: Shuri was E, Midori was B leaning toward C, and Mayo... likely AA.  

"Yuu..."  
"Wait a sec."  

With naked Mayo and half-undressed Midori watching closely, Yuu removed even his T-shirt.  
The orange sunlight filtering through the curtains signaled approaching dusk.  
Though the sunny day had been warm, temperatures were gradually dropping—yet the room remained heated by their collective passion.  

"Come here."  
"Okay♪"  
"Eh?"  

Pushing past Midori and Mayo, Shuri—who'd somehow recovered—threw herself against Yuu's chest.  
And she was completely naked too.  

"Yuu's huge cock... really amazing. Had no idea it'd be this incredible. Absolute bliss! So... I want more! Again!"  
"Wait a minute!"  

Naturally, Midori and Mayo stopped Shuri as she tried to mount Yuu and insert him herself.  

By this world's standards, even young men needed long intervals after ejaculation—once per night was the norm.  
Thus, with multiple women and one man, who received the creampie became crucial, sometimes leading to fights regardless of the man's consent.  

From Shuri's perspective, she desperately wanted to deepen her bond with Yuu before rivals Midori and Mayo—who clearly adored him.  
That's why she'd used the festival invitation quotas as leverage earlier.  
When Yuu understood her ploy and approached, she couldn't hide her joy.  

But Yuu's actions surpassed Shuri's expectations.  
She never imagined he'd kiss her so suddenly.  
Then came her first time—pleasure and climax beyond anything from masturbation.  
When he creampied her thoroughly, she nearly lost consciousness.  
Being the only one of the three to experience Yuu gave her a sense of superiority.  
Seeing Yuu kiss Midori and Mayo afterward seemed acceptable... until she saw his crotch when he stood to remove his shirt.  
The majestic erection she'd been too frantic to notice earlier.  
The sight made her lower body throb with renewed desire, so she leaped at Yuu when he said "Come here."  

Yuu managed to quell what could've become a vicious catfight.  

"I want you sister school presidents to get along."  
*Bachan!*  
"Hyauu!"  

"So no selfishly cutting in line, okay?"  
*Bachan!*  
"Gah! Aahn!"  

"Really understand now?"  
"Hauu... s-sorry... I'm suuuper sorry. So... more!"  

"Calling it punishment? Looks like a reward to me."  
"Yeah. She seems delighted."  

Kneeling Yuu faced sideways-crawling Shuri, her plump round buttocks now red and swollen.  
Despite experiencing Yuu first, she'd tried cutting in front of the other two. Objectively, she was at fault. Hence the punishment.  

Yuu disliked violence against women, but with Midori and Mayo present, visible discipline felt necessary.  
He'd spanked with enough force to sting but not injure... yet Shuri's moans grew increasingly sweet-sounding.  
Glancing at her butt, he saw transparent fluid trickling down her thighs from her wiped-clean vagina.  
Stopping his spanking hand, he plunged a middle finger into her vaginal opening.  
Inside was slippery, warm, and coated his withdrawn finger with ample love juice.  

"Aahn! Deeper...!"  
"Seriously? Getting turned on by spanking, you变态 student council president?"  
"Don't say it... this is your fault!"  
"Hmm."  

Like his sister Elena, Shuri seemed to have masochistic tendencies—the punishment had become a reward.  
Unconsciously, Yuu cupped her breast from below and kneaded it.  
Voluminous and heavy in his palm.  

"Hey Yuu-kun. Touch mine instead of hers."  
"Midori..."  

Perhaps competing, Midori—now fully nude—pressed against Yuu's right side.  
Normally serious, she'd mustered courage through rivalry with Shuri.  
Though petite, her perky breasts pointed upward, their pale pink nipples tiny. A faint milky scent tickled Yuu's nostrils.  
He couldn't refuse—continuing to knead Shuri's breast with his left hand while gently massaging Midori's with his right.  

"Mine too!"  
"O-okay"  

Mayo squeezed between Shuri and Midori.  
With only two hands, Yuu leaned toward her modest swell and took a nipple in his mouth.  

"Nnuun... Yuu, harder... squeeze harder!"  
"Hah, hah, hah... breasts... feels good! So happy you're touching me! Annh!"  
"Hiuu! Something... amazing, feels so good! Haan! Like this... ah, ah, ah! Yes!"  

While savoring three pairs of breasts and listening to moans, Yuu contemplated.  
Ideally, he'd continue fucking Midori and Mayo for a full harem play—he had the stamina. But time was limited.  
Since he'd see them again, he didn't need to fulfill every desire now.  
He recalled an orgy scene from an eroge or manga. Why not try it?  

On the tatami, the four lay in respective positions.  
Beside supine Yuu's face was crawling Midori's small buttocks. Her sparse pubic hair revealed a glistening, closed slit.  
At a right angle, Mayo buried her face in Yuu's crotch, clumsily but earnestly pleasuring his cock with mouth and hands as instructed.  
Parallel to Yuu lay sideways Shuri, face buried in Mayo's spread crotch while having her own pussy licked by Midori.  

From above, they formed a square—each servicing someone's crotch while being serviced.  
Yuu's idea to satisfy all four simultaneously. His reference involved another man, but Shuri substituted.  
Only she didn't touch Yuu since she'd already lost her virginity.  
Though sex itself was postponed, Midori and Mayo accepted.  
Since they'd agreed not to stop until all came, no half-measures were allowed—even between women.  

"Let's see. This is awkward. Spread your legs... oh, such a tiny cute pussy. Time to feast. Amm... peron rero rero juru, chuu, jupaa!"  
"Hyah! Stop! Yuu...kun, seriously... hah! Annh! Feels... so good! But... can't concentrate!"  

Twisting his body, Yuu lifted Midori's right leg from the root, spreading her slit wide.  
Though shadowed, the clean salmon-pink interior revealed a tiny hole. He devoured it, licking voraciously and sucking overflowing juices.  

Moments earlier, Midori had been nervously sniffing Shuri's unmistakeable semen-tinged scent before tentatively extending her tongue.  
This first cunnilingus experience made her involuntarily lift her chin.  

"Chu, chu, rehro, chup... nfuu... Yuu's cock, like this. Haa~, hot. Hard. So lewd... exciting."  

Muttering, Mayo traced Yuu's cock from tip to base with her fingers, kissing and licking obsessively.  
When it twitched under her tongue at the ridge, she smiled knowing he felt it. Eager to please, she continued diligently.  

"Uu, fine then! I'll make you cum with my skills! At least let me hear good sounds.  
Ah, come on! Lick my precious place properly!"  

Sandwiched between two girls, complaining Shuri pressed her mouth to Mayo's crotch while scolding Midori for only moaning under Yuu's cunnilingus instead of reciprocating.  
Shuri's sociable nature (excluding boys) meant she was experienced with girl-girl play during sleepovers.  
Her plan: make Mayo cum hard to take her place sucking Yuu's cock.  

Wet sounds and moans continued until Midori—overstimulated by Yuu—was first to break.  
Her body convulsed violently as she cried out, still face-down on Shuri's crotch.  
Yuu's mouth was drenched from her overflowing juices, but he continued fingering and licking her virgin pussy with growing fervor.  
Mayo diligently worked Yuu's cock, but he wasn't close—rather, Midori's reactions fueled him.  

"Hyaah! Ah, ah! No... more! Hik, kuu... Cumming, cumming! Aah! Aah! Shokorameeeee! Hiuun! Ikk! Gahn!"  

After relentless clitoral teasing, Midori shuddered and came abruptly.  
Inexperienced, her climax surpassed anything from masturbation. Gasping, she buried her face in Shuri's crotch, barely moving her fingers.  
But Yuu's cunnilingus continued.  

"Come on, Midori, make Shuri cum too. Not done yet. Chu, rehro, juuchuuu"  
"Hyai. Trying... annh! Shoko, sensitive... ah! Feels... so good!"  

Meanwhile, Shuri's skilled tongue drove Mayo to the edge.  
Yet Mayo persisted, stroking Yuu's shaft with one hand while deepthroating the head.  
Would Mayo cum first or make him ejaculate?  
Her spread thighs made squelching sounds as she moaned muffledly, clinging like a leech.  

Ultimately, Midori collapsed first after cumming three times.  
Mumbling incoherently while Mayo remained fixated on Yuu's cock—possibly having cum once from Shuri.  
Yuu grabbed Shuri's thighs and buried his face in her crotch.  

"Gbah! Kufu... nn, nmmo! Gya... nuun!"  

Unlike earlier gentle teasing, Yuu's serious cunnilingus drew wanton moans from Shuri—who still didn't remove her mouth from Mayo's pussy.  
Mayo struggled too, the irregular tongue movements in her mouth from Shuri's moans feeling irresistible.  
In the three-way battle, anyone could break first—until Shuri came simultaneously with Yuu.  
Caught off-guard by his silent ejaculation, Mayo spilled some semen but swallowed what was in her mouth before diligently licking the rest.  

---

### Author's Afterword

This concludes the meeting arc with the sister school student council presidents.  

I originally planned to take the remaining two virgins (Midori, Mayo) consecutively, but to avoid monotony, I tried a different development.  

I took inspiration from old eroge.  

### Chapter Translation Notes
- Translated "ちっちゃくて可愛いマンコ" as "tiny cute pussy" maintaining explicit anatomical terminology
- Preserved Japanese sound effects through transliteration (e.g., "ぺろんれろれろ" → "peron rero rero")
- Rendered sexual acts without euphemisms (e.g., "クンニ" → "cunnilingus")
- Maintained original given name usage for characters (Shuri, Midori, Mayo) as per source text
- Italicized internal monologue *(This is concerning.)* per style rules
- Translated "変態生徒会長" as "pervert student council president" preserving contextual nuance