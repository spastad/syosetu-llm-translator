## 269.1 Class 1-5 Baby-Making Day ② ~Erotic Kisses on the Back~

### Author's Preface

After posting Chapter 268, I reread Chapter 269 and noticed Irene's speech patterns were slightly inconsistent. 

Originally set as quiet and polite (calling Yuu "Yuu-san"), I revised 268 but it ended up ambiguous... Meanwhile, Saya goes wild in the latter half.

---

Taking the virginity of cute high school girls one after another, impregnating them with his own seed. What could make a man's heart leap more than this?

However, no matter how strong Yuu's sexual stamina, the number of partners he can handle at once is limited. Nights like those at the training camp or Hakone's hot spring resort Hesperis right after summer vacation started were special occasions. 

That said, Yuu himself occasionally fantasizes about being surrounded by large groups of naked girls.

In that sense, he's grateful that Yoshie and Makie manage the class schedule, assigning about four girls per week. 

The Class 5 girls have to wait their turn due to menstrual cycles, but if things go smoothly, all applicants might get to have baby-making sex with Yuu by year's end. This benefits everyone. Yuu hopes to continue beyond New Year's too. While he can't manage all, he's determined to get over half of Class 5's 37 members pregnant by the end of the academic year.

Even among virgins, each feels subtly different upon penetration. Differences in physique and constitution surely matter, but perhaps masturbation habits do too. While tightness is universal, the gripping sensation, vaginal texture, and depth vary. 

Fortunately, Irene didn't seem to experience hymen-breaking pain since hers was already torn, but Yuu's unexpected thickness made her wince. Irene's virgin vagina was incredibly tight yet deep. As Yuu lowered his hips over her, he penetrated gradually but hadn't reached the deepest part yet. By the time he fully sheathed himself, beads of sweat dotted Irene's forehead.

"Irene. I'm all the way in. You did great. Congrats on losing your virginity."  
"Agh... Yuu-san's... ugh! V-v... incredible... swallowing me whole... Ah, this is sex... hah, hah, unbelievable... Nothing like I imagined... nghaa!"

"Haaah~ Irene's virgin pussy feels amazing."

Yuu remained buried inside her without moving, pressing his face against her chest. Her porcelain-white skin glistened with sweat, radiating heat. But he suddenly realized: Their height difference made kissing impossible in this position.

So Yuu slid his hands under Irene's knees, lifting them while thrusting his hips forward. The tip of his cock naturally gouged deep into her vaginal depths.

"O-ow! W-wait, plea... hyaa... agh!"  
"Sorry. Did that hurt?"  
"N-not painful... but... d-deep... cock... ooh... ngh! All the way... deeper than any vibrator... so hot and hard... fah! Ah, sh-shugoire suuuu!"  
"Irene, let's kiss more. Come on."  
"Yu-Yuu-hyan... mmph!"

He shifted into the impregnation press position. Though concerned if this posture was too much right after her first time, Irene was merely bewildered by the novel stimulation. At least her body seemed happy to accept Yuu. With his hands occupied, Yuu asked her to initiate kissing. Once unleashed, Irene wrapped her arms around Yuu's back without hesitation, pulling him close as she pressed her lips to his aggressively. Even without movement, their excitement built as tongues intertwined.

"Chururoo, mfuh, umm... nnaa... ahn... mmoo... nk, nk... faaaaaaa..."  
"How is it? Feeling good?"  
"Ahhaa, shugoku, ii resu."  
"Glad to hear. More kissing?"  
"Yes. Yuu-hyan's saliva... delicious."  
"Haa, haa, damn. Never thought I'd witness such lewd real-life mating... *What a feast for the eyes!*"

While Yuu and Irene remained connected through deep kissing, Saya—unable to contain herself—approached clutching her sketchbook. She'd been fingering herself instead of drawing.

"Haha. Glad to be of service. I'll take care of you too, Saya. Just wait a bit."  
"Fu-fu... P-please don't mind me. Merely watching this close-up already fills my heart and stomach to bursting."

Though her eyes hid behind long bangs and she maintained her formal speech, Saya's flushed cheeks betrayed her arousal. But Irene remained Yuu's priority. Breaking the kiss slightly, he watched strands of saliva stretch between their mouths before slowly starting to move his hips. Stimulated both above and below, Irene's expression grew increasingly blissful.

Yuu's own pleasure intensified too, but having already ejaculated twice, he still had stamina. Deciding to savor this virgin vagina fully, he varied his movements—shifting from shallow thrusts to deep strokes, then grinding his hips in circles.

Thump—Yuu's hips dropped. Though not particularly fleshy, Irene's buttocks distorted under the impact. At their joining point, his thick cock stretched her labia wide, buried nearly to the base. After grinding deep inside, he slowly withdrew. As his veiny, glistening cock pulled out bit by bit, milky fluid seeped from her vagina, trailing down to her anus. Consequently, the sheets were thoroughly soaked.

"Ah, this... real sex... Lady Irene's pussy rejoicing so...  
Fuu~. It's like my common sense got flipped. Splattering fluids, thick lewd scent, flesh colliding sounds. Everything's obscene, stimulating my female instincts to the max!"

Saya watched from her VIP seat on all fours, with five sketches of the impregnation press from various angles scattered by the bed. Irene's unfamiliar high-pitched moans had filled the air earlier, but now muffled sounds suggested Yuu had sealed her lips.

"Irene."  
"Ha... ha... hahi"

While ravaging her mouth with his tongue, Yuu whispered during brief lip separations, mechanically pounding her all the while.

"Gonna cum soon. Your pussy feels too good—I'll give you lots."  
"Agh, yessss... mfuh, mfuh, hahfuhn! P-please... do it!"

Yuu's hips accelerated for the final sprint—pan pan pan pan!—the sound of flesh slapping flesh echoing through the room.

"Ah, Irene!"  
"Yu-Yuu-hyan!"  
"I-I'm cumming! Guh... aaaagh! C-cumming!"  
"Ha... hi, hahe... I-I'm too... ooh... ooh... ooh... huge... ku... ruu... vaaah... aanngh! No! Ihyu! Ngaaah!"

Feeling Yuu's semen surging inside her, Irene must've sensed the forceful injection into her womb. Though her lower body went limp, she hugged Yuu tightly, pressing her face against his shoulder as she climaxed.

Semen tests show Yuu's sperm is far denser than this world's average male. Still, a third ejaculation would dilute it considerably. Pregnancy remains possible even diluted, but Yuu stayed sheathed inside Irene for sentimental reasons. Exhausted, he rested with his face buried in her heaving chest.

Suspecting he'd kept Saya waiting too long, Yuu sat up—only to find her gone. As he glanced around puzzled, someone suddenly plastered themselves against his back, making him yelp in surprise.

"Eh... Saya? You scared me!"  
"Hufu, hufu... Yuu-tan's back... that curved, hard back... magnificent! And the sweat... nchu~~~ licking lick lick lick lick lick... ahh, delicious!"  
"Ooh! Uh, well..."  
"Hah! My apologies for this rudeness!"  
"No, it's fine. Seems I kept you waiting."

Ultimately, Saya had watched Yuu and Irene's union till the end while sketching and masturbating. Though fortunate to witness three sexual acts for her art, she'd planned to just sketch and masturbate while engraving the scenes in her mind. But seeing Yuu's sweaty back after ejaculating, she'd impulsively pounced. As a male-back fetishist seeing real male nudity for the first time, she couldn't resist.

"...So... may I continue licking and sucking Yuu-tan's back?"  
"Yuu-tan, huh... Sure, go ahead."  
"Nnhhoo~! Then I shall partake! Chupa, chupa, muchu! Yum yum. Ah—n, lick lick lick lick lick lick"  
"Uwah, that tickles!"

Being petite, Saya started licking Yuu's upper back—along his spine and shoulder blades. But with permission granted, her eyes sparkled. Until now, she'd admired Yuu from behind, never head-on. He alone wore gym clothes without underwear, perfectly showcasing his back's contours. Seeing it slightly translucent with sweat was unbearably sexy—like a busty girl going braless in rain-soaked gym clothes.

She locked her arms around his torso like a vise, hoisting herself to suck his right shoulder—chu chu—before licking across to the left. That Yuu didn't resist or flee despite such perverted acts mystified but delighted her. For Yuu, it merely tickled; he actually enjoyed her voluptuous breasts pressing against him.

After savoring his shoulders, Saya eyed one of her top-five favorite parts of Yuu's body—his nape—and grinned. She'd have died happy after licking it thoroughly. The slight curve as Yuu tilted his head, skin taut with faint downy hair, cervical vertebrae protruding—all perfect to her. Sweaty male scent tickled her nostrils, making her throb.

Saya knew her sexual desires were strong and twisted. Hence she'd avoided reality, venting through 2D art. But witnessing Yuu's sex acts and now his actual body overwhelmed her with unprecedented excitement. Eyes turning heart-shaped, she latched onto Yuu's nape.

"Ufuh, chu, chu, chu, chupah, chupah, chuuuuuuu! Juru, lero lero lero lero... so good... Hah, hah, hah, Yuu-tan, shuki! Hah, hah, irresistible~... Yuu-tan, Yuu-tan, Yuu-fan muchuuuuun lero lero juru chupah"  
"Oof, vuh... kwa..."

Shivers of pleasure ran down Yuu's spine. Unnoticed, Saya's hands groped his chest while her ample breasts pressed insistently against him. His softening cock revived, standing rigid again.

Watching this, Satilat and Mao stirred below. They'd obediently observed Yuu with their classmate, but his sex acts aroused them more than any AV. Though satisfied after receiving his semen earlier, as energetic 16-year-olds, seeing Yuu moan under Saya's "assault" (from a female perspective) proved too stimulating.

"So jealous... I wanna lick Yuu-kun too."  
"True. But now..."

Trying to be considerate, they couldn't hide their rising desire. Propped on the bed staring intently, Yuu and Saya noticed them.

"Satilat and Mao, mind joining?"  
"Fai, if Yuu-tan permits, I don't mind."

Saya seemed content just licking Yuu's nape and back. Thus Satilat took his right side, Mao his left, surrounding him.

Just before, Yuu glanced back diagonally.  
"Saya, we haven't kissed yet. Come on, let's."  
"Eh? Eh? Such... I couldn't possibly!"

Her logic—licking his nape was fine but kissing seemed presumptuous—made little sense, but Yuu pulled her arm close and claimed her lips. Though her mouth was slick with saliva from licking, Yuu pressed on, sliding his tongue inside. Being passive didn't suit him. Turning fully toward her, he grabbed and kneaded her breasts—surprisingly full and soft despite her petite frame, molding fascinatingly in his palms.

"Mmmph... ooh, mua... nn, nn, nk... nnn! Fah... churu, juru! Nnfi... amu, lero, lero... nnfoo~"

Dazed by her first kiss with a male, Saya seemed overwhelmed by pleasure signals when their tongues met. Eyes drooping, face slack, she instantly lost herself in the deep kiss.

After minutes of wet, tangled tongues and exchanged saliva, strands connected their lips when they parted. Overwhelmed by such intense first-kiss stimulation, Saya buried her face in Yuu's shoulder.  
""Yuu-kun!""

Seeing this, Satilat and Mao couldn't resist clinging to him. Like puppies, they opened their mouths with tiny tongues extended, begging. Not entirely displeased by these slender beauties, Yuu petted their heads and kissed each in turn.  


### Chapter Translation Notes
- Translated "子作りセックス" as "baby-making sex" to maintain explicit terminology
- Rendered "種付けプレスの体勢" as "impregnation press position" for anatomical accuracy
- Preserved Irene's speech quirk "祐ひゃん" → "Yuu-hyan" and Saya's archaic speech "でござる" → formal English equivalents
- Transliterated sound effects: "ちゅるろぉ" → "chururo", "ぺろぺろ" → "lick lick", "パンパン" → "pan pan"
- Maintained Japanese name order: "中井 真央" → "Nakai Mao"
- Translated internal monologues to italics: "眼福でござる" → "*What a feast for the eyes!*"
- Used explicit terms: "チンポ" → "cock", "マンコ" → "pussy", "精液" → "semen"
- Preserved honorifics: "-さん" → "-san", "-たん" → "-tan" (affectionate diminutive)