## 270.1 Class 1-5 Baby-Making Day ③ ~Fortissimo~

"Hoo~, so this is Yuu-tan's penis. How manly and magnificent..."  
"Seriously. Even after three ejaculations, it's still this energetic."  
"Ufufu. Yuu-kun's penis is always so mesmerizing."

With Saya straddling Yuu's lap as he lay on his back, Mao and Satilat watched his crotch with heated gazes from both sides.  
They had been kissing and touching each other until now, but Satilat and Mao suggested letting Saya observe thoroughly since it was her first time.  
Yuu's penis was already fully erect.  
All that remained was to penetrate Saya - the last one for today - but since there was no rush, Yuu agreed.

Meanwhile, Irene had recovered and came over to kiss Yuu.  
This blocked Yuu's view of the other three. Her striking silver hair draped over his face and neck, tickling him as he stroked her back.

"Shall we touch it first?"  
"Want to pamper his penis?"  
"O-oh... th-then..."

First, Satilat and Mao reached out to touch the penis.  
Being experienced, they traced the glans and shaft with one hand while the other hand freely caressed Yuu's waist.  
Seeing this, Saya also tentatively reached out.  
She explored the warmth of blood-filled flesh, the veiny shaft, the smooth glans, and the soft wrinkled texture of the balls with her fingertips.  
Touching revealed sensations that mere observation couldn't convey.  
Her creative inspiration was intensely stimulated while her excitement kept building.

Though Yuu felt pleasure from the three-way caresses, Irene - now without restraint - covered his mouth, leaving him unable to speak.

The trio used fingers and palms to thoroughly fondle the erect penis, taking turns licking the precum that dripped down. But a desire awakened in Saya.  
The erotic manga she enjoyed mostly featured men being violated in various scenarios - situations nearly impossible in reality.  
But today Yuu had sex in positions she'd never seen. She knew he was friendly with all girls, but sexually he was unbelievably proactive and tolerant. After all, he'd even let her lick his back extensively.  
Surely he'd fulfill her secret desire too.

Saya pulled away from Yuu's crotch and approached his face - currently showered with kisses from Irene covering not just his face but his neck and shoulders.

"Yuu-tan, Yuu-tan."  
"What is it, Saya?"  
"I have a once-in-a-lifetime request!"  
"Huh?"

When Saya whispered her request in his ear, Yuu hesitated to answer immediately.  
As a man, the pose she demanded was embarrassing.  
Seeing Yuu's reluctance, Saya immediately prostrated herself in dogeza.

"Please, I beg of you!"  
"Honestly... fine. Lift your head."  
"Huh? Really?"

Saya was shocked that Yuu readily agreed to her half-hearted request.  
She immediately enlisted Satilat, Mao, and Irene's help.  
Satilat and Mao looked dumbfounded at the request, but Irene couldn't hide her excitement - she'd also started reading such manga under Saya's influence.

"Sorry, Yuu-kun~"  
"Ufufu. Excuse us~"  
"Ah, yeah. Be gentle."

The three taller girls surrounded Yuu, leaving Saya aside.  
Satilat and Mao grabbed Yuu's legs from left and right, spreading them apart.  
Though not forced, Yuu felt like an AV actress in a gangbang scene.

Irene sat with her butt flush against the headboard, lifting Yuu's head slightly to wedge herself under him.  
Yuu's elevated head ended up sandwiched between her thighs.  
Simultaneously, Satilat and Mao lifted Yuu's spread legs while Saya grabbed his buttocks to lift his hips.

"Yuu-tan, please hold your own toes with both hands."  
"U-uhhn. This really is embarrassing..."  
"Amazing! We can see everything important!"  
"Whoa, so erotic!"

Yuu was now in a pose resembling yoga's Happy Baby position but with elevated hips.  
If a girl did this, it would be called "mangura-gaeshi" (pussy exposure).  
But when a man does it...?

"Behold the secret technique! Chin-guri-gaeshi (reverse genital exposure)!"  
"Ooooh!"

*(No way... I'm being subjected to this...)*  
The girls' excitement peaked at Saya's battle-cry-like declaration, while Yuu felt utterly strange.  
His erect penis now pointed alarmingly close to his own face. Ejaculating in this position would mean getting hit directly.  
For boys in this world, this was even more unthinkable than being on all fours.  
But having agreed, he couldn't back out now.

"Now then~ for the finishing touch~. Pardon me."

Saya - who'd been leering at Yuu's scrotum and anus while licking her lips - pulled back with a creepy smile.  
Swapping places with Irene, she approached from Yuu's left side, straddling him with her right leg spread wide.  
Her large buttocks loomed before Yuu's face.  
As she lowered her hips, love juice dripped from her still-excited pussy, wetting Yuu's face.  
She was attempting face-riding - one of many women's unrealized fantasies - directly onto a boy's face.

"Glurgh!"  
"Haaaaaaah... Defiling Yuu-tan's noble face with this humble pussy... truly... truly like a dreammmmm!"

Though he could barely breathe through his nose, Yuu's mouth was sealed by Saya's pussy. His face was already drenched before anything happened.  
While swaying her hips, Saya lifted the precious member before her eyes with both hands, signaling Satilat and Mao.  
Thus began simultaneous handjobs and blowjobs from all four.

"Thinking about it, seeing a boy in such a humiliating pose is basically impossible~"  
"Perks of the job. Or rather... thanks to Naname-san... Saya-chan and Yuu-kun."  
"Lick lick... m-my apologies... mmph! Fah! Aah! Hyah... un!"  
"Hmm?"

But Yuu wasn't just passively taking it.  
Letting the girls pleasure him was enjoyable, but Saya's unexpectedly intense character made him want to overwhelm her with his skills.  
With her pussy pressed against him, he immediately extended his tongue and licked vigorously.  
His freed hands moved forward to knead her ample breasts, pinching and twisting her nipples.

"Nnhhooo! Good! So gooood! Yuu-tan's tongue... ah... my pussy, my pussy feels too good! Ah! Ah! I'm cummming! Ahhhh! Nooo!"  

Though outnumbered 4-to-1, Saya - who'd already orgasmed multiple times from masturbation - had become a weakling despite her virginity.  
When Yuu probed her vaginal walls with his long tongue, she threw her head back and moaned.  
Meanwhile, hands stroked his penis and breasts for titty-fucking.  
Satilat and Mao licked and fondled his balls from the root.  
Irene - pressed against Yuu's butt - moistened her fingers with saliva and circled his anus, inserting shallowly.  
The unexpected pleasure made Yuu's hips jerk involuntarily, but Irene firmly held him down.  
Both Yuu and Saya neared their limits.

"Ah... fah! This is... incredible... ah! Ah! Nooo! I'm cummming! Ahhhhhhh! Already... falling!"  
"Ngghh! Ihh! Cumming!"

Saya fell first under Yuu's simultaneous nipple and vaginal assault.  
Then Yuu succumbed to the stimulation urging his ejaculation.

"Glugghh! Ihh, CUMMING!"

He ejaculated with his face still smothered in Saya's love juices.  
With his tip sandwiched between her breasts, thick semen pulsed out, forming a white lake in her cleavage.  
Though his fourth ejaculation today, the continuous four-way stimulation ensured ample volume.

After a short break, it was finally Saya's turn.  
Having fulfilled her request earlier, Yuu now chose the position: making her get on all fours, spread her own pussy lips with her fingers, and beg for his penis.  
It would've been cute if a demure girl said it shyly, but Saya's samurai speech felt oddly mismatched.  
Regardless, his penis - stroked by Satilat, Mao, and Irene - stood ready. He inserted it into her drenched, spread-open entrance.

Plump Saya had soft flesh everywhere. Though she had a waistline, her flesh yielded softly when firmly grabbed.  
Yuu preferred slender girls, but Saya's chubbiness was well within acceptable range.

With each thrust, *pachun*, *pachun* sounds of flesh meeting echoed pleasantly.  
When Yuu pushed deep, her fleshy buttocks deformed voluptuously.  
When he pulled back, the flesh wobbled *tayun*, and milky fluid leaked from their joining point.

Though Saya's hymen was long gone, accepting Yuu's penis remained challenging.  
But extensive prior masturbation had loosened her, and her love juice acted as lubricant, preventing difficulty.  
Rather, her heated vaginal walls gripping him brought Yuu pleasure.  
Had he not ejaculated four times already, he might've reached his limit quickly.

"Haa~. How is it, Saya? Not that I need to ask."

When he thrust deep and ground against her cervix, Yuu covered her back completely, pressing their bodies together.  
Reaching forward with both hands, he grabbed her full breasts - so large they overflowed his grasp - kneading them as he asked.  
Saya - who'd arched her back while gripping the sheets - had no breath to answer, her voice already hoarse from screaming.  
Despite receiving a penis for the first time, she felt no pain, only being tossed about in a storm of pleasure from the start.

"Hiiin! How could... I endure this... ah! Oh! Ba-baka! I'm becoming stupid... ah! Hya! This humble weakling pussy... surrenders to Yuu-tan's penis! Ah! Ah! Ah! Cumming! Cumming! CUMM... AHHHHHH!"  
"Whoa!"

As her grip on the sheets loosened, Saya's upper body started collapsing.  
Yuu prevented her face from hitting the sheets by holding her breasts, though her head lolled limply.  
Supporting her body, Yuu slowly lowered her upper body onto the sheets.  
Keeping his penis inside, he straightened his knees - shifting into mating press position.

"Yu... Yuu-tan... I... this humble one... is satisfied. Ah! No! Give up! I give up! No more... ahhn! Don't thrust... so deep... I'll cum agaiiin!"  
"Haa, haa, haa... Saya, I'm about to cum too. Last sprint!"

*Pan! Pan! Pan! Pan! Pan!*

Yuu suddenly accelerated his thrusts, but soon noticed Saya wasn't reacting. Being on top of her and unable to see her face, he realized too late.

"Huh? Saya?"  
"Lady Saya?"

Irene peeked at her face and discovered the truth:  
Saya had passed out with her eyes rolled back.

"Problem... I haven't cum yet..."  
"Then! Do it with me!"  
"Wait! If we go by order, it's my turn!"

Satilat and Mao - who'd patiently waited for Saya to finish - clung to Yuu the moment he muttered, both dashing over simultaneously.  
Among Yuu's eight athletic club friends, only these two weren't pregnant yet. Hence their urgency.  
Yuu smiled wryly and embraced them both.

"I'll take care of you both at once. Who gets the cum depends on the moment."  
"Yuu-kun... thank you. I love you!"  
"Me too... loved you since we met on the bus!"  
"Hahaha, thanks. I love you both too, Satilat and Mao."  
"Yuu-kun!"

Satilat and Mao were both slender, sporty beauties with modest chests.  
Yuu's "love" wasn't a lie - just broadened in scope.

After Irene moved Saya's body aside, Satilat and Mao lay before Yuu, embracing each other.  
Yuu then alternately inserted his still-erect pre-ejaculation penis into each of them.

---

### Author's Afterword

Days later, Saya sold original doujinshi based on her experience at a Tokyo location.  
The innovative ideas and realistic depictions drew immediate attention, achieving unprecedented sales. However, some cynical opinions emerged: "No such boy could exist. Even for fiction, it's too unrealistic" and "The delusions of man-starved women have gone too far - scary."

### Chapter Translation Notes
- Translated "ƒƒ（フォルティシモ）" as "Fortissimo" (musical term for very loud)
- Preserved Japanese honorifics (-tan, -kun) and samurai speech patterns for Saya
- Translated explicit anatomical terms literally ("penis", "pussy", "scrotum")
- Rendered sexual acts without euphemisms ("ejaculated", "penetrated")
- Transliterated sound effects ("pan pan", "pachun", "tayun")
- Maintained Japanese name order (Naname Saya, Yokota Satilat)
- Italicized internal monologues per style guide