## 271. CM Appearance ① ~Remember Sweet~

"Huh? A commercial shoot? For me?"

'Yes. The scheduled male talent had an emergency hospitalization, and they couldn't find a replacement on such short notice.'

"But even so, why would they want an amateur like me..."

'They'll rewrite the script to minimize your lines. They plan to avoid showing your face on camera.'

This phone call with his half-sister Satsuki last week marked the beginning. Since the Weekly Fuji article about his student council presidency, Yuu had received countless media requests - interviews, promotional posters, gravure shoots for photo weeklies. But Yuu had no desire for fame or attention outside school. Becoming student council president only to get distracted would defeat the purpose. While meeting celebrities sounded intriguing, he'd already met actresses like Tsutsui Takako and the duo Wish at Hakone's Hesperis hot spring resort - even having sex with them. That was satisfaction enough. So he'd instructed all inquiry channels to decline offers. That Satsuki - herself connected to these circles - proposed a commercial was unexpected.

Though details differed, year-end sales campaigns thrived in this world too with winter bonuses and Christmas. For over a month, winter products had flooded the market with TV commercials.

'And get this - the talents starring in this CM are Wish.'

"Huh!? Wish is..."

The commercial was for Tenko Corporation's new chocolate line launching this month. Tenko, a top-tier Japanese food conglomerate, handled confectionery, dairy, beverages, nutritional foods, and retort meals. Yuu knew the brand well, having consumed their products. In this reincarnated world, Tenko held status similar to companies owning pro baseball teams or using era names. They'd maintained ties with the Toyoda Sakuya Memorial Foundation since Sakuya's lifetime as a sponsor. Food provisions meant elite young employees visited Hesperis - one who'd met Yuu in August apparently suggested him as a last resort.

Hearing this and tempted by seeing Wish again, Yuu agreed on two conditions: Shooting would only occupy one Sunday, and Satsuki would help investigate Kate's relocation.

***

Satsuki acted as manager that day, meeting Yuu en route. In the car, she explained details while reviewing documents. Shooting would occur at a Tokyo-area studio owned by the contracted production company. Male talent shoots rarely used outdoor locations except in rural areas due to security concerns - indoor sets were standard. After brief orientation and preparation, they'd proceed to rehearsals and filming. Normally taking 2-3 days, everything was compressed into one day for Yuu.

The concept: A man hosting his two new girlfriends at home eases tension by sharing new chocolate. Originally featuring light flirtation, the script was simplified to mundane daily scenes since Yuu was an amateur.

The script sent in advance showed Wish delivering most dialogue while Yuu spoke minimal lines like "Please" or "Glad you liked it," ending with all three saying the slogan. Elementary school play-level presence. Though only his back would show, his positioning between the two idols would draw viewer curiosity.

The car entered an underground parking garage through an inconspicuous back entrance. Escorted by Satsuki and four protection officers, Yuu headed to the conference room where all staff were gathered, guided by a studio security guard permanently assigned for male talent.

"Good morning! I'm Hirose. Pleased to meet you all today."  
""""Eh......""""

Though afternoon, "good morning" was standard industry greeting. Yuu thought starting energetically mattered, but the dozen-plus women in the conference room just stared blankly.

*(Did I mess up already?)*

A woman in maroon jacket and knee-length pencil skirt stood abruptly. Her beige floral blouse complemented waist-length black wavy hair. About 30 years old and Yuu's height, she radiated capable businesswoman energy. From the far right seat, she reached Yuu astonishingly fast.

By then, whispers filled the room:

"Hey, is he the one Maruyama-san recommended?"  
"Hirose Yuu...kun!?"  
"The famous male student council president? To see him in person..."  
"When he greeted us so energetically, I thought he was a crossdressing young actor."  
"Young male talents won't even let female staff approach, much less converse..."

"Yu-Yuu-kun! You really...came! I'm so happy!"  
"Orie-san's been family friends with Mom since forever. I'll do my best today!"  
"Wonderful! Just standing there, you'll be picture-perfect!"

The woman before Yuu - Maruyama Orie - couldn't hide her joy despite visible nerves. Her distinct double-lidded eyes and full lips complemented voluptuous curves contrasting with a slim waist and long legs. At 34, she'd been the oldest among women Yuu slept with at Hesperis in August, radiating mature charm and maternal warmth. Now wearing rectangular rimless glasses, she looked every bit the competent executive. Though their single encounter was months ago, the cover story cited her as a friend of Yuu's mother who often received gifts.

Her business card identified her as Tenko Confectionery Promotion Department manager - impressive for such a major corporation, likely a rising star entrusted with new product campaigns.

When Yuu shook her hand instead of exchanging cards, her delight peaked. Staff who'd seen her stern expression moments ago were stunned by the transformation. Of course, a young man freely conversing with and touching an older woman was rare enough to inspire envy. Satsuki approached Orie, whispering:

"This is a special exception. Only because of Tenko's ties with us and Yuu's rare willingness."  
"U-understood!"

Satsuki emphasized this shouldn't become routine against Yuu's wishes.

Staff introductions followed - production heads, director, assistant directors, camera, editing, lighting, music, and costume teams. Too many to remember. Assistants remained elsewhere. Wish was summoned from their waiting room upon Yuu's arrival.

Hearing the news, rapid footsteps approached before the door burst open. Hidaka Akemi - one of Yuu's half-sisters performing as Akane - beamed while staring intensely. Mizuki Aoi (Ao) blushed crimson upon seeing Yuu, covering her mouth. Even professionals couldn't hide their joy. Worried they'd slip up, Yuu spoke first:

"Wow! The real Akane-san and Ao-san! I'm a huge fan! So happy to meet you! May I shake your hands?"

Using stage names, Yuu approached with outstretched hands. A subtle glance conveyed his meaning. Ao quickly composed herself, both clasping his hands.

"Of course! Nice to meet you, Hirose-kun."  
"We're thrilled to meet the famous male student council president!"  
""Pleased to work with you today.""  
"Yes. This is my first shoot, so I might cause trouble, but I'll do my best!"  
"Aww! So polite and cute!"  
"We'll lead, so relax!"

Male talents were notoriously difficult, sometimes demanding co-star replacements. Seeing the trio's immediate rapport, staff felt confident about the shoot.

After greetings, the CM content and schedule were explained. Yuu's scenes would be filmed today - a packed agenda. Preparations began immediately.

Despite minimal lines and only back shots, Yuu couldn't just stand before cameras. After basic voice and posture training came line rehearsals. While dramas might use scripts, Yuu memorized his short lines easily. Wish had memorized theirs too - professionals indeed.

Next came costumes - stylish casual jackets and pants. Changing alone in a small booth, Yuu then received hairstyling with gel and light makeup (necessary for camera lighting despite no face shots). Two assigned staff (all female) trembled so much that Yuu eased their nerves with conversation.

Footsteps hurried down halls while studio preparations continued - staff shouting directions. From director to assistants, everyone worked intensely. Yuu found this unknown world of commercial production unexpectedly interesting.

***

"Hey, like chocolate?"  
"Yeah! Love it!"  
"Me too."  
"Great. Half-sweet for Akane-san. Bitter for Ao-san."  
"Yay!"  
"Thanks."

Yuu passed chocolate bars to both. Akemi (Akane) reacted extravagantly; Ao (Ao) showed cool appreciation.

The red-packaged half-sweet was low-calorie yet sweet. Blue bitter packaging matched their image colors.

"G-good?"  
"Yeah! Super delicious!"  
"Cut!"

The director's call came. Compared to Akemi's natural smile, Yuu's stiff expression drew a sigh. Take 5 - his fifth mistake. Minimal lines, yet another flub.

"Don't be discouraged. It's your first time."  
"But..."  
"We messed up constantly during our first shoot too. Especially Ao with all her NGs."  
"D-don't bring that up!"

Everyone struggles initially. Since reincarnating, Yuu thought he'd grown accustomed to speaking before crowds. Entering the brightly lit studio, he felt confident. But when filming started, the atmosphere shifted unnervingly.

Overly conscious of being filmed, his delivery turned wooden. While acceptable, his repeated mistakes were problematic. Professional talents would've been scolded. Staff's encouraging attitude despite his errors made Yuu feel worse, creating a vicious cycle.

After Yuu's tenth mistake, Akemi raised her hand.

"May we take a break to reset?"

Sponsor representative Orie was just happy Yuu came, ignoring his acting. But the director wanted at least decent acting for a rewatchable CM. A break was approved. Akemi whispered to the director.

"Hmm. Worth trying. If it works, bonus for us."  
"Thank you."

As Akemi bowed, the director issued new instructions.

---

### Author's Afterword

After Chapter 193 where Yuu's singing gained attention, some suggested he could succeed in entertainment. But I never considered it. One reason: Knowing a famous "narou" work where the protagonist becomes an idol in a chastity reversal world. Being a fan myself, I'd risk excessive influence.

This time, I wanted a light episode between festival arcs, hence Wish's CM cameo. Yuu's entertainment skills: Singing - decent amateur level. Never seriously played instruments. Some acting ability, but here camera nerves reveal his limitations. Protagonists need flaws.

Tenko models M●eiji. Wish references Wi●ks who starred in Meiji● Seika CMs. The subtitle song was actually used in marble chocolate commercials.

### Chapter Translation Notes
- Translated "歳末商戦" as "year-end sales campaigns" to convey commercial context
- Preserved Japanese honorifics (-san) and stage names (Akane/Ao)
- Translated "大根" as "amateurish" (literal "daikon/radish" implies bad acting)
- Rendered internal monologue *(Did I mess up already?)* in italics
- Used """"Eh......"""" for simultaneous stunned reactions per formatting rules
- Translated "スポンサーの担当者" as "sponsor representative" for professional context
- Kept product names untranslated (Half-Sweet/Bitter) as brand terminology