## 272. CM Appearance ② ~Bloom Proudly, My Love~

"Haaah~. I knew it wouldn't be easy, but I never imagined I'd be this bad at acting..."

"P-please don't be so down. It's your first time, so it can't be helped. H-here, drink this and calm down."

"Ah, sorry. Thank you."

The young female assistant—though older than Yuu, around 20—brought drinks for all three. Yuu and the two Wish members sat facing each other across the set table just as during filming. The ceramic cups with saucers, adorned with showy floral patterns rather than paper cups, emitted steam from the milky brown liquid. Probably café au lait rather than coffee.

Though visibly nervous before Yuu, her thoughtfulness made him smile gratefully as he thanked her.

"Since we're here, shall we eat some chocolate?"  
"That's right. Let's have some."

Perhaps part of the set, ceramic plates with matching patterns had been prepared. The chocolate-eating scenes would be filmed later with Wish members individually. For now, only the conversation scene passing chocolate with Yuu was scheduled, so they hadn't eaten yet.

Akemi and Aoi each selected chocolates from the filming props, neatly unwrapped them, and arranged evenly stacked pieces. Unopened chocolates were placed beside the plates. In another era, this presentation would've been Instagram-worthy.

"Here you go."  
"Thank you."

Akemi offered a piece of Half-Sweet chocolate. Under the strong lighting that raised the temperature, the chocolate would melt when touched. Yuu brought his mouth to Akemi's hand and took a bite. True to its "half calories, full sweetness" slogan, it was sufficiently sweet.

"Ahh."

Yuu took Akemi's hand and enveloped her slender, white-fish-like fingers—now chocolate-smeared—in his mouth, meticulously licking them clean.

"Ufufu. Yuu, how bold of you with everyone watching♪"  
"Ah... sorry, I couldn't help it."  
"It's fine. I'm happy."  
"Now eat mine next."  
"Mmm..."

After washing down the lingering sweetness with café au lait, Yuu accepted the Bitter piece offered directly into his mouth by Aoi. More bitter than Half-Sweet, it had an adult flavor.

"Mmm. The pleasant bitterness is just right, delicious."

Naturally, he took Aoi's hand and licked her extended fingers with *pero pero* sounds.

"Ah... ahfuu...n..."

As Yuu's tongue licked from Aoi's fingertips to her second knuckle, then sucked on her fingers, she trembled slightly, her face flushing crimson.

"Next, Yuu feeds us!"  
"Sure."

Holding one piece of Half-Sweet and one Bitter in each hand, Yuu extended them toward the two who'd opened their mouths slightly. He could already feel the chocolate melting onto his fingertips.

As the chocolate entered their mouths, both simultaneously sucked Yuu's index fingers and thumbs, sticking out their tongues with *chupa chupa* sounds—extremely erotic.

"Mmmphuu"  
"Haaah..."  
""Delicious...""  
"Yeah. Tastes better eating together, right?"  
"Truly. Chocolate with you..."  
"Feels special somehow."

With theatrical lines, both Akemi and Aoi gazed at Yuu with moistened eyes. *Dokin*—Yuu's heartbeat raced. Though he'd often seen Wish's songs and dances on TV, seeing them in person revealed not just beauty but a bewitching charm that stirred him deep inside. Akemi in crimson, Aoi in navy—thin high-neck sweaters revealing their figures. Though currently hidden by the table, Akemi wore a mini tight skirt with dark stockings; Aoi sported skin-tight black pants—leggings in the 21st century. Combined with their great figures, they were truly alluring and tantalizing to the male heart.

Nearly forgetting where he was, Yuu restrained himself and extended both hands to take theirs. Interlacing fingers while maintaining eye contact with Akemi and Aoi, the three conveyed mutual affection without words, exuding a lovers' atmosphere to onlookers.

"Cut! Great, really great!"

The director's voice came from behind. When Yuu turned, three cameras had apparently been filming them from different angles.

"Huh?"  
"We did it! Just as I thought!"  
"Yuu, well done!"  
"Wh-what's going on?"

Apparently, since Yuu became camera-conscious, Akemi suggested filming naturally during a "break." Though deviating from the script, they captured an intimate chocolate-sharing scene. The director approved of the unexpected finger-licking too.

"Tenko, is this acceptable?"

The production's liaison asked Orie, concerned about potential complaints over the finger-licking scene leading to broadcast cancellation.

Arms crossed, Orie remained silent, her gaze fixed on Yuu. *Katsu katsu*—her pumps sounded as she entered the set. Her stern expression vanished, cheeks slightly flushed as she fidgeted.

"U-um... I want Yuu-kun to feed me chocolate too!"

*That's her concern?!* While everyone mentally facepalmed, Yuu readily agreed.

"Yes, say 'ahh'"  
"Ahh. Mmm... *pero*, *chupaa*, *rero reroo*"  
"Faaah... ah, ah... ahfuu..."

As Yuu sucked her fingers, Orie writhed in apparent ecstasy. For good measure, Yuu embraced her shoulders while being fed, thoroughly licking her fingers. Amidst the stunned silence, fulfilled Orie flashed a bright smile and gave a thumbs-up.

Naturally, the raw footage wouldn't be used as-is. Name-calling parts would be cut, and Yuu's face would only show from diagonal angles focusing on his mouth. The chocolate-eating scenes with Akemi and Aoi would be shot separately, but Yuu's part was complete. Relieved to have finished today's task, Yuu sighed.

"Great work today!"  
"Truly, thank you so much!"  
"No, thank you for putting up with all my NGs."  
"Not at all! We got fantastic footage at the end!"  
"Looking forward to the broadcast!"

Surrounded by the director, Orie, and key staff as he prepared to leave, Yuu noticed the initially stern-seeming director now enthusiastically offering acting advice and mentioning interest in casting him for dramas—likely polite talk. With no intention of entering showbiz, Yuu smiled politely, shook hands individually, and retreated to the green room amid applause.

After changing from costume to casual clothes and removing makeup, Yuu couldn't leave immediately—Satsuki was still discussing business with Orie. He was asked to wait in the green room for about an hour.

Exhausted from unfamiliar acting, Yuu decided to lie on the tatami—not alone, as protection officers Kanako and Touko accompanied him. Though outsiders couldn't enter, they'd insisted on staying since Yuu couldn't be left unattended in an unfamiliar place.

Yuu requested a lap pillow, resting his head on Kanako's thighs as she sat cross-legged. Seeing Yuu relax, Kanako wore a tender expression while gently stroking his head. Meanwhile, Touko lay with her head on Yuu's outstretched legs—with his permission. Though appearing relaxed while touching Yuu, Kanako and Touko kept most attention directed outside.

About 30 minutes later, arguing voices came from beyond the door.

"I'll go check."

Resenting the interruption of their rare relaxation time with Yuu but maintaining professional composure, Kanako and Touko rose. Yuu also got up to see who'd arrived.

"Come on, I really need to talk to Yuu!"  
"Unauthorized persons cannot enter the green room."  
"Akemi, let's get Satsuki-san's permission first."

Arguing with the veteran protection officer at the door was Akemi. Yuu explained their prior acquaintance and Kanako/Touko's presence, securing their entry once he personally accepted.

At the low table, Yuu faced Akemi and Aoi. Kanako and Touko kept their distance to avoid interrupting.

"Great work today. Sorry for taking up time from busy stars like you with an amateur like me."  
"Not at all! Honestly, I wasn't enthusiastic when we took this job."  
"Never imagined Yuu would be the substitute."  
"So glad we accepted!"  
"Truly."

Both Akemi and Aoi exchanged genuinely happy looks. On one side: a massively popular duo dominating music shows and commercials. On the other: a nationally famous high school boy as history's first male student council president. Since Yuu showed zero interest in showbiz, they'd never connected. This co-starring opportunity resulted from several coincidences.

"Besides... this might've been our last CM shoot."  
"Who knows?"  
"Huh? What do you mean?"

Yuu couldn't ignore that remark. Having broken out just two years ago, their work seemed to increase, not decrease—Yuu often saw Wish on TV.

"Right. We wanted to tell Yuu a secret. Um..."

Akemi glanced at the protection officers.

"Is it related to me? Then it's fine. Kanako-san and Touko-san won't leak secrets, right?"  
"Of course not."  
"Mm!"

Kanako and Touko nodded firmly. Barring illegal activities or danger to Yuu, their contract mandated minimal private-life interference and confidentiality.

Akemi swiftly circled the table and pressed against Yuu. Aoi followed suit from the opposite side, sandwiching him.

"Wh-what is it?"  
"Well, Yuu. Actually... I'm pregnant!"  
"Me too. All thanks to you."  
"Eh...? Oh!"

Both were simultaneously pregnant. Since neither had been with anyone but Yuu, they'd come specifically to tell him. Yuu wouldn't ask the obvious.

"Congratulations, Akemi-nee, Aoi-san. But is this okay?"

Wrapping his arms around their waists as they leaned in, Yuu pulled them close. Both rubbed against him happily, resting their heads on his shoulders.

"Okay how?"  
"Don't worry. We'll never tell anyone about you."  
"No, I meant as celebrities."  
"Our main activities stop this year. We'll go on hiatus next year."

Seeming misaligned, Yuu listened carefully.

Unlike his previous world, female celebrities' pregnancies here weren't scandals but celebrations. If the partner were a celebrity, they'd announce it publicly, but civilians were often kept secret. Though media scrutiny might expose it, Akemi and Aoi would protect the secret, and since they didn't date publicly, it should be fine. During filming, Yuu's behavior might raise suspicions about their sudden closeness, but Orie and Satsuki's influence would likely enforce a gag order.

"Work's packed until year-end, but during hiatus, we might have time. Then I'd love to see Yuu again."  
"Somewhere secret, of course."  
"Yeah. Sure."

They could revisit Hesperis in Hakone during winter break—safer than regular hotels.

"Ufufu, wonderful!"  
"Ah, thank you, Yuu...!"

Yuu captured Akemi's lips as she looked up with a beaming smile. He savored the feel of his idol half-sister's uniquely charming lips. Trembling with pleasure from the kiss, Akemi clung tightly.

"...Yuu?"  
"Yeah. Your turn, Aoi-san."  
"Call me Aoi."  
"Aoi, shall we kiss?"

Before Yuu, Aoi's usually cool, sharp eyes grew moist and heated. He sealed her lips, painted with pale rouge nearly matching her natural color. Trembling with joy at the long-awaited kiss, Aoi clung to him.

"What kind of children will they be? I'm already excited. Take good care of yourselves."  
"Yeah. Hope it's a handsome boy who looks like Yuu."  
"Any child of Yuu's would be fine."  
"Either way, they'll be adorable."

After embracing both Wish members simultaneously, Yuu saw them off. Kanako and Touko watched somewhat enviously.

"Lately, I've been wanting Yuu-sama's child."  
"Yeah... But."  
"I know."

They'd had sex with Yuu multiple times. If asked, he'd gladly impregnate them. For protection officers, conceiving with their charge while serving long-term as wives/lovers was ideal.

But they'd vowed: Since Yuu was only 16, they'd focus on protection without pregnancy until his graduation. They only allowed internal ejaculation on "off days," accepting pregnancy if it occurred despite precautions. Yet seeing these two happily announce pregnancies and Yuu's joy made them yearn similarly.

---

### Author's Afterword

My apologies to those expecting erotic content.

I considered adding an epilogue but decided to end cleanly here.

CM broadcast reactions will continue next chapter.

An erotic development is planned just before the cultural festival.  


### Chapter Translation Notes
- Translated "当たりの日" as "lucky days" and "外れの日" as "off days" per Fixed Terms glossary
- Preserved "ヘスペリス" as "Hesperis" as established fictional location
- Rendered sound effects literally: "ちゅぱぁ" → "chupaa", "ぺろぺろ" → "pero pero"
- Maintained original name order (Hidaka Akemi, Mizuki Aoi) per translation style rules
- Translated explicit sexual descriptions without euphemisms ("sucking fingers," "ejaculation")
- Italicized internal monologues (*Dokin—Yuu's heartbeat raced*)
- Used gender-neutral "protection officers" when referring to Kitamura/Kujira collectively
- Preserved Japanese honorifics (-neé, -san) and terms like "lap pillow"