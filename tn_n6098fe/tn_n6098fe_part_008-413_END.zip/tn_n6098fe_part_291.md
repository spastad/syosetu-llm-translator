## 274. Sairei Festival Eve ② ~Pincer Attack~

After finishing rehearsals, Yuu conducted afternoon patrols as part of student council duties.

By 4 PM, the classroom stalls and courtyard rest areas appeared nearly complete.

Near the main gate, an arch crafted by art club members was being installed. "Sairei Festival" was boldly inscribed at the top, with extravagant decorations covering every corner.

A reception tent stood immediately beside it.

Beyond the gate functioned like a checkpoint, where staff cross-referenced invitations with pre-approved lists to admit only authorized guests.

Unauthorized visitors would be turned away by intimidating security guards.

  

Yuu checked progress and estimated completion times at each location.

Seeing the advanced preparations filled him with irrepressible excitement for the coming festival.

His rising enthusiasm drove him to greet every student working on preparations, whether he knew them or not.

Everyone responded with bright smiles.

While only girls were visible on the grounds, inside the gymnasium both genders worked together decorating the stage.

  

All preparations were to conclude by 8 PM, with only security teams staying overnight.

Though concerns existed about meeting the deadline with student labor, everything appeared on schedule.

  

  

  

  

"Oh right! I need to go to the gymnasium."

"Huh? Why?"

"Final costume fitting. Seems I'm getting special treatment."

  

While returning to the student council room after patrolling campus, Yuu remembered.

The cosplay show costumes, designed by the Fashion Research Club and meticulously crafted by the Home Economics Club, were specially made.

Design submissions for male costumes had been solicited long ago, building anticipation for this event.

Thus, costumes remained confidential until showtime, with Yuu's outfit treated as top secret by its two creators.

Despite multiple fittings where it seemed perfect, the obsessive creators insisted on last-minute checks.

  

"Ah~ those two, huh?"

"You know them, Emi?"

"Yeah. They're the fa... *ahem* geniuses representing Fashion Research and Home Ec clubs."

"Sounded like a suspicious word almost slipped out."

"Anyway, I'm off. Might take a while."

"No problem. We still have work too. We'll wait for Yuu-kun."

"Sorry."

  

After parting with Emi and other student council members, Yuu had Chizuru's security team accompany him to the gym entrance before proceeding alone to the boys' changing room.

The gym stood nearly empty, with only a few girls cleaning up after preparations.

  

  

  

  

"Should be all good now, right?"

"Perfect. Perfect. Absolutely wonderful. Suits you splendidly. Hehe. As expected of Yuu!"

"Ugh..."

"Fufufu. Fits like a glove. Can't wait to see everyone's faces during the actual show!"

"Well... they'll certainly be stunned."

  

Both were second-year girls.

They flanked Yuu, gazing dreamily at his reflection in the full-length mirror.

On the left, examining Yuu and his reflection from every angle, was Fashion Research Club's Aruma Vanessa. Her naturalized Italian parents included a renowned fashion designer mother.

  

Vanessa stood nearly as tall as Yuu. Her figure boasted pronounced curves where they should be and slimness where needed.

Her seemingly black hair revealed chestnut-brown brunette waves upon closer inspection.

Deep Western features gave her a mature aura beyond her years.

Though checking Yuu's costume with sharp eyes, she couldn't help staring at his exposed skin, failing to suppress her lust.

  

On the right, pressing unusually close while checking the costume with her fingers, was Uryu Yuri from the Home Economics Club.

She stood nearly 180cm - taller than Yuu.

Her long black hair reached her back, cut in a no-bangs one-length style that gave a demure impression.

Her melon-seed shaped face was pretty but not exceptionally so among Sairei's beauties.

Her most striking feature was her voice.

Slightly husky with a glossy resonance.

Less suited for singing or voice acting than radio hosting - a soothing, ear-pleasing tone.

When Yuri whispered in that doting older-sister manner, Yuu shivered with arousal.

  

During last month's special health education class, these two had guided Yuu to ejaculation as the first group from Class 2-1.

Meeting them again vividly revived those memories for Yuu.

  

Vanessa and Yuri had won the privilege to handle Yuu's costume when the cosplay show was planned.

They'd gone beyond "what suits Yuu" to create "what only Yuu could wear," discarding countless designs before finalizing one.

Both possessed outstanding talent but eccentric tastes, earning them the nickname "Dangerous When Mixed" in their clubs.

Yuu knew nothing of this but was taken aback by their design.

Yet their persistence made refusal impossible.

  

The body-hugging design required the creators' assistance for dressing/undressing.

With treasure-handling care, they slowly removed Yuu's costume.

First exposed was Yuu's bare upper torso.

  

"Ahh, Yuu's body... Mesmerizing every time. Broad shoulders with bony width. Firmly muscled chest despite being slim. The smooth curve from back to waist. Ufū... Such a feast for the eyes!"

"Hah... hah!"

  

Yuri's breath warmed Yuu's nape as her licking gaze roamed his body, making him shiver.

  

"Oh my, sorry. Cold?"

"A-a little. Could you warm me up?"

  

Yuu turned only his head to look back at Yuri.

Naturally looking up at her made her chest flutter.

  

"Sure. I'll warm you... with my body."

  

Yuri wrapped her arms around Yuu's chest from behind and clung to him.

Despite her slender frame, perfectly hemispherical breasts pressed directly against his back.

She'd swiftly unhooked her bra and hitched up her sailor uniform top.

  

Meanwhile, Vanessa finished removing the lower half, leaving Yuu only in underwear.

His erection tented the fabric.

  

"Kufufu"

  

Vanessa, hearts in her eyes, eagerly unhooked her bra and hitched her sailor top.

Yuu's right hand naturally reached out and groped her - a handful overflowing his palm.

Vanessa nuzzled Yuu's erection through his underwear before looking up.

  

"Now, off these go."

"Nngh, ahf... mmph!"

  

Yuu couldn't reply - Yuri had covered his mouth.

Instead, Yuu gently stroked Vanessa's brunette hair with his left hand.

His right hand kneaded her ample breast without excessive force, occasionally teasing the nipple.

  

"Fufun. Now... grand reveal!"

  

Vanessa slowly slid down Yuu's underwear.

  

"Haa, haa, always so... magnificent! Color, shape, scent - tutto magnifico! Innamorarsi!"

"Getting this hard while sandwiched between women? Such a naughty boy."

"Well..."

"It's fine. I love that about you. So much I could eat you up! *Ham*, *chupa*, *lerolero*!"

"Kyaah!"

  

Yuri whispered in his ear while playing with Yuu's nipple with one hand and tracing his glans with the other.

When she nibbled his earlobe and inserted her tongue, Yuu nearly jumped.

Vanessa firmly held his hips, though. After sniffing intently, she showered kisses from the coronal ridge down the shaft.

  

This was the third fitting.

While dressing was manageable, being stripped while sandwiched always aroused Yuu.

Perhaps lingering effects from the special health class?

Since undressing always involved just these three, a conditioned reflex had developed: his erection would be brought to ejaculation by them.

  

  

  

  

"Ugh... Feels too good... I'm in trouble."

"Oh my? That good?"

"*Chu*, *churu*! So much clear fluid dripping from the tip. Aha, twitching cutely!"

"Because it's you two doing it, Yuri and Vanessa."

"Doing what where? Tell me?"

"Aah... Y-Yuri's pretty hand is stroking my shaft... *shiko shiko* jerking me... nnngh!"

"And then?"

"Va-Vanessa's tongue... kuh! Li-licking the tip! Aah! There! Yes! If you keep... I'll ejaculate!"

"Aahn! Yuu, so cute! Love you! *Mwah*! *Chu*! *Chupaa*!"

"*Amchu*, *erorerorero*, *jururi*... haa, haa... Then... I'll sandwich it like last time."

  

Vanessa swiftly removed her sailor top. Bare-chested, she jerked Yuu's erection between her ample breasts.

Gazing lovingly at the glans protruding from her cleavage, she kissed and began sucking it.

Though soft, her full breasts applied firm pressure when squeezed together.

  

Yuri hugged him from the side, cradling Yuu's head as a deep kiss began, tongues entwined.

Yuu's left hand stroked Vanessa's head while his right slid under Yuri's skirt, slipping into her panties.

Yuri's thoroughly soaked pussy made *kuchu kuchu* sounds as Yuu's fingers moved.

As before, this brought Yuu to ejaculation.

  

Their skilled caresses came from experience - though virgins, both had seen, touched, and sucked male erections before.

While Sairei's serious sports clubs were female-only, cultural clubs admitted boys. In this world (from Yuu's perspective), many boys preferred traditionally feminine hobbies.

Thus cultural clubs like band were popular, but girls joining just for boys were weeded out during trial periods. Only diligent female members gained opportunities for contact.

  

Thus Yuri and Vanessa, with their unique charm and charisma, had become close with boys and literally touched them.

Now both were infatuated with Yuu, masturbating countless times while imagining him during costume creation.

  

  

  

  

"Nngh... C-coming... Can't hold... aahh!"

"Nngh, nngh, mmoooouuugh!?"

  

Arching back while embraced by Yuri, Yuu reached his limit.

His semen gushed forcefully into Vanessa's mouth as she sucked the glans while milking him with her breasts.

Anticipating this, Vanessa's eyes widened at the force but calmly swallowed, gulping audibly.

  

"Aahn, give me some too!"

"Nnfuu..."

  

Vanessa wore a moved expression after swallowing most semen. Yuri immediately extended her tongue to lick remaining drops.

Soon Vanessa joined, and like last time, their tag-team cleanup left Yuu's erection no time to soften.

  

Yuri and Vanessa gazed dreamily at the now-clean erection.

For them, Yuu's large, enduring penis was unprecedented, making prolonged enjoyment possible.

As Yuri moved to suck it again, Yuu stroked her hair and spoke.

  

"Hey. Since you made me feel so good..."

"Oh? What?"

"Now it's my turn to make you feel good!"

"Eh? Eh? Yuu?"

  

Having played the submissive boy until now, Yuu intended to take control.

Lifting the kneeling Yuri, he pushed her against a wall-mounted locker.

The floor was too cold, and chairs were unavailable, so standing sex it would be.

Yuri hesitated at Yuu's sudden assertiveness after his earlier passivity.

Yet this unexpected turn undeniably thrilled her.

  

  

  

  

  

  

  

  

  

  

---

### Author's Afterword

I reintroduced two members from the first group that brought Yuu to ejaculation in "249. Student Council President's Work? ④" here.

Novels rarely highlight voices compared to appearances, but Yuri's whispering voice alone can arouse men.

This recalls a jazz singer radio host whose sultry voice I loved listening to weekly years ago.

Also, when trying to name her "Yuri," the first kanji that appeared was 由梨 - used for a heroine in my previous work *Dream Leaper*.

Though quite different from that character, it somehow fit the image so I kept it.

### Chapter Translation Notes
- Translated "挟み撃ち" as "Pincer Attack" to convey the dual-attack imagery
- Preserved Italian phrases with English translations in parentheses
- Translated "シコシコ" as "*shiko shiko*" for masturbation sound effect
- Maintained "*lerolero*" for licking sounds per transliteration rules
- Used clinical terms "glans" and "ejaculation" per explicit terminology requirement
- Kept "sailor uniform" for セーラー服 as standard attire description
- Rendered internal thoughts in italics (e.g., *(C-close!)*)
- Preserved name order "Aruma Vanessa" and "Uryu Yuri" per fixed character list