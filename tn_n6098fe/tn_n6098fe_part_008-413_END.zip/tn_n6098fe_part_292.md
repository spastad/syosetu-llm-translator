## 275. Sairei Festival Eve ③ ~BIG COCK's Counterattack~

"Nngiiiiii... It's going in... ugh... Yuu's... cock... hiiin!"

"Kuh, it's tight after all... Yuri, are you okay?"

"I-I'm fine... Just give me... all of Yuu's..."

"Okay. Here goes."

"Aaah! Aa, aa, d-deep... it reached... Yuu's... inside me... full... so full!"

In the changing room, with Yuri's hands braced against the lockers lining the wall, I penetrated her in standing doggy style. Her uniform remained on, panties pulled down midway. Though her hymen seemed already broken, Yuri's vagina felt incredibly tight accepting a man's member for the first time, making insertion take time.

Though Yuri had acted like an experienced older sister earlier, once I took her from behind at the insertion stage, she threw her head back with desperate moans. Perhaps there was still some pain. The sensual gasps as she suffered accepting manhood for the first time seemed too mature for a high school girl, fueling my excitement. Grabbing her waist with both hands, I flipped up her sailor uniform and tightly embraced her breasts.

In this world, women taller than me are common. While cowgirl and missionary work well with such partners, I prefer doggy style for the masculine sense of conquest. The drawback is my face only reaching mid-back due to height difference. Instead, I buried my face in her swaying long black hair, inhaling its fragrance.

"Fufu. I took Yuri's virginity. And your insides feel amazing."

"Ugh... I'm glad, but... I never imagined losing my virginity in this position..."

"Did you hate it?"

"Hyan! N-no, I don't hate it... ugh, you moved!"

"It's your first time. I'll ease you into it slowly."

"Ah, ah, wait... ooh! Hii... wh-what is this... hahi, hahi, ah... nnngh! I'm... being impaled by this thick thing... I don't... know this feeling... nnggh!"

I massaged breasts barely graspable with both hands while attempting small hip movements. My cock felt tightly squeezed inside her narrow vagina. Even slight movements - or rather, movements too small to be substantial - created incredible friction. Virgins are irresistible. Had I not ejaculated earlier, I'd have come instantly upon reaching her depths. Though holding back now, each tiny thrust sent paralyzing pleasure up my spine.

"How enviable. I've dreamed daily of losing my virginity to Yuu too."

Vanessa hugged me from behind, now completely naked. Moving my hips, I glanced back.

"Of course I'll have sex with you too, Vanessa. Wait a bit."  
"Mmh! I'm happy! Chuu~"

Honestly, I'd sleep with every Sairei girl if possible. While unrealistic, claiming these two alluring virgins was natural. Feeling Vanessa's soft skin and warmth against my back sent my excitement soaring. As we kissed repeatedly, tongues intertwining, I accelerated my thrusts into Yuri.

"Ahhn! Ahn! Aaahn! I'm... having sex with Yuu... Yuu's cock... d-deep inside... thudding... ooh! Coming! So good! Yes!"  
"Kuh! I feel it too! My hips won't stop now!"

Though pressed flush against Yuri's back, my hips pistoned in short rapid strokes. Each thrust produced loud *pan, pan, pan* flesh-slapping sounds. Yuri's pain seemed minimal now, her moans pure ecstasy. Hearing this, I grew wilder, driving harder to please her. Their duet approached climax.

Meanwhile, Vanessa had crawled under the joined Yuri - who was bent over lockers - to closely observe our union.

"Wow... Yuri's pussy is stretched so wide swallowing Yuu's cock... Amazing! Ah, splashes are hitting me everywhere!"

Our mixed fluids soaked Vanessa's face, but she didn't care - even licking them eagerly. Watching this unprecedented position ignited her curiosity, drawing her close enough to catch spray. She also supported Yuri when pleasure made her slip, preventing a fall.

"Haa, haa... Yuri, I'm about to... come!"  
"Aahn! Haaan! Th-that's too... intense... nngh... st-stop... hiiin! What? Aah, there... yaan!"

After a deep thrust, I stopped pumping and ground my hips instead. Yuri's head jerked down from the cervix stimulation, but my embrace prevented collapse. Worse, Vanessa wrapped arms around Yuri's lower abdomen, pressing her face close - not just watching but actively licking. *Pichapicha, jurujuru* sounds joined the moans. Regardless of virginity, this world's schoolgirls actively engage with partners of either sex.

"Fuaah! St-stop... this is too much... I'll go crazy! AAAAAAAAAAAAH! I'm coming, coming! Aaah!"

Simultaneously stimulated on clit and inside by Yuu and Vanessa, Yuri thrashed her long hair wildly, gasping as she glanced between us. Facing this erotic sight, I neared my limit.

"O-oh... I'm coming too! Ejaculating! Yuri!"  
"Yu, Yuu! Give it... give me Yuu's... semen!"  
"Of course! Guh... ooh, ooh... CUMMING!"  
"Nggh!? Aah, aah! Hii! My belly... bulging... so... intense... kufuun..."

As I thrust deep and ejaculated, thick spurts of semen flooded Yuri's womb. Having squirted at climax, Vanessa's face below our union must have been drenched - yet she took it unfazed.

"Can you really... continue like this?"  
"Hmm, possible but... I want to hold Vanessa a while longer."  
"Ufufu. Being teased isn't bad either? Ahn! It's touching me... your cock's already hard... haa, haa, Yuu?"  
"Vanessa... chuu~"  
"Nn, mmph..."

Standing upright, Vanessa and I embraced face-to-face. We conversed between *chuu, chuu* pecking kisses. Her ample breasts pressed against my chest, visibly flattening yet transmitting firm elasticity. Though my groin seemed calmed by heavy ejaculation, feeling Vanessa's soft body fully revived it. With her turn finally arriving, Vanessa looked intoxicated with anticipation, stroking my back and begging for kisses.

"Let's see."  
"Ah!?"

I hoisted Vanessa by her waist. Toned as she was, she felt lighter than expected. Adjusting her position, I felt her dripping wetness against my tip - enough to slide right in.

"Shall I enter now?"  
"Nn... I want it... but how? Like with Yuri?"  
"Hmm... Grab my shoulders and lift one leg?"  
"Like this?"

Keeping Vanessa pinned to the lockers, I slid my left arm under her raised right knee, supporting her thigh. I aimed for the "Standing Tripod" position - also called standing one-leg-raised missionary.

"Lean your hips forward more. There. Now I'll enter."  
"Whoa! Nngh... i-it's going in..."

Without beds or chairs in the changing room, the floor felt cold. With our similar heights, this standing position worked perfectly - though requiring male strength to support her. The benefit was missionary-like closeness and deep penetration.

Slightly crouching, I aligned my erect cock - still wet with fluids - with Vanessa's vaginal entrance. Angled slightly, I pushed upward. Being virgin, her inner tightness prevented immediate entry. I slowly stretched her open.

"Nnggh... aau... k... un... aah, haa!"  
"Vanessa, okay?"  
"O-okay... but Yuu, hold me tight... kiss me?"

How could I refuse this beauty's teary-eyed request? I pressed my lips to hers while making small hip movements. Virgin sex never loses its thrill. Conquering depths with an erect member is male instinct. Resisting vaginal pressure pushing back, I advanced slowly. Though time-consuming, my cock gradually sank deeper until hitting her cervix.

"Kyauun!"  
"Hah... all the way in. Your insides feel incredible."  
"A, a, o, oh... I-I'm... impaled deep by Yuu... hah, hah... this is... sex... Incredibile! (Unbelievable) Caspita! (Amazing)"  
"Fufu, congrats on losing your virginity. I'll move slowly now?"  
"W-wait... aauhn!"

Her tightness prevented large strokes. This position actually worked better with minimal movement. So I thrust gently. Her ample breasts pressed against my chest swayed *tapum, tapum*. Having broken her hymen earlier, she showed no pain.

Still, Vanessa frowned while clinging to me, her body heat and sweat palpable. Her vaginal folds clenched *gyu-gyu* around my cock, intoxicating me with supreme pleasure. Had I thrust straight in this position, I might have come instantly. Having ejaculated twice already, I could properly savor Vanessa's first time.

"Vuuaah! St... aahn! So d-deep... ooh... vungh! Haa! Giin! I'm going crazy... your cock... thudding against my belly... ahi, hahi... Yuu... amazing!"

Listening to Vanessa's intermittent moans, I thought:  
*(This position... feels good but strains my back. Only possible with teenage stamina)*

Standing sex looks dramatic in fiction but requires more energy than bed/sofa sex. Doing two girls consecutively compounded this. My breathing naturally grew ragged. Yet the deep penetration while pressed together created intense connection. Indeed, Vanessa had lost all composure, clinging desperately while moaning wildly. Though I'd thought myself in control initially, deep penetration meant I fully savored her magnificent vagina even without large strokes - transmitting back-breaking pleasure. My limit approached faster than expected. I resolved to push through to the climax without stopping.

"Kunnngh! Ngaah! Aahn! Yuu! Yes! Yes! I can't... take this! C-coming, coming, coming!"  
"Vanessa... hey, Vanessa?"

When I rubbed my cheek against hers and whispered, Vanessa nodded repeatedly.

"I'm coming too."  
"Nngh, nngh!"  
"Together... come?"  
"Coming... with Yuu... aah! No! Hinuh... oh, oh, oh, ohi, it's coming... so strong... Yuu! AAAAAAAAAAAAAAAAH!"  
"Guh! EJACULATING!"

As I came, Vanessa screamed wildly through her climax. My ejaculation continued through her cries. Afterwards, having finally lost her virginity to Yuu as desired, she closed her eyes contentedly.

---

### Author's Afterword

The cultural festival finally begins next chapter. Since we'll distance from explicit content for a while, I included this scene with two sexy seniors right before.

### Chapter Translation Notes
- Translated "立ちバック" as "standing doggy position" for anatomical accuracy
- Preserved Italian exclamations "Incredibile!" and "Caspita!" with translations in parentheses
- Translated "四十八手で「立ち鼎」" as "Standing Tripod position" referencing traditional shunga terminology
- Used explicit terms "ejaculation," "vagina," and "semen" per style guidelines
- Maintained honorifics (-san omitted as none used in this intimate scene)
- Transliterated sound effects (e.g., "pan pan pan" for ぱんぱんぱん)
- Kept Japanese name order (Uryu Yuri, Aruma Vanessa) per fixed references