## 276. Sairei Festival Day ① ~The Starting Place~

### Author's Preface

The cultural festival arc begins.

I initially planned to wrap it up lightly in about 2-3 chapters, but once I started writing, the content expanded...

After all, the cultural festival is the highlight of the school. I'll proceed in the same manner as before.

---

On the day of the cultural festival, Yuu arrived at school one hour before opening, but there was already a long line formed in front of the main gate.

Not only Yuu's car but also the buses transporting male students passed by without entering through the main gate. The normally unused west gate had been temporarily opened for entry into the campus.

According to later reports, some people had been lining up since before dawn.

The security team ended their shifts early and began checking invitations and distributing numbered tickets ahead of schedule.

There was even a commotion when a woman without an invitation tried to force her way in, but she was criticized by those around her with proper invitations and left dejectedly.

This demonstrated just how much expectation was placed on the cultural festival of a co-ed school with male students, especially since Yuu's fame had drawn particular attention to Sairei Academy.

The previous night, the campus had been brightly illuminated, with security handled by professional guards and physical education students.

This was because intruders attempting to sneak in during the night were anticipated - reports indicated about 30 intruders had been apprehended from after students went home until dawn.

The lower-than-expected number had a reason.

The school had taken countermeasures after viewing Yuu's assault during the sports festival seriously.

The 2-meter-high wall and 1-meter-wide irrigation canal surrounding the north and east sides were deemed insufficient against those prepared to attempt intrusion, so barbed wire had been strung along the top of the wall.

Incidentally, the west and south sides facing the athletic field had high nets installed, making them less likely to be chosen as intrusion routes, but depending on future circumstances, barbed wire might be added there too.

It had become as heavily fortified as a prison, but appearance couldn't be prioritized over the safety of male students.

Thanks to this, during the Sairei Festival eve patrols, many who were unable to climb the wall were driven away.

The only remaining task was waiting at the three gates to apprehend those who managed to get inside.

On the actual day, in addition to the student security team, school security guards patrolled inside and outside.

A temporary police box was set up beside the reception area at the main gate, with police officers stationed there.

Furthermore, patrol cars circled the school perimeter.

Baggage inspections were conducted upon entry. Photography was prohibited except for those authorized by the school, so photography equipment was temporarily held. If weapons or other dangerous items were found, they would be confiscated and handed over to police.

Such extensive security measures were planned.

As a male student, Yuu's scheduled appearances were in the afternoon, so in the morning as executive committee chairman, he entered the special tent set up for the executive headquarters in the courtyard.

Adjacent to it was a tent for the security team composed of physical education students - a result of considering convenience during emergencies and Yuu's safety.

Besides the headquarters, branches for executive committee members and security were set up near the main gate, on the third floor of the first school building, and at the gymnasium to handle nearby problems immediately.

Moreover, around Yuu, not only student council officers but also executive committee members and security teams meant that over ten female students constantly surrounded him.

As Yuu got out of the car in the parking lot and walked to headquarters with Sayaka and others, he saw students busily making final preparations before opening.

At last, the Sairei Festival was beginning.

This was Yuu's first cultural festival since being reborn as a high school student. During the sports festival, he had been more purely excited, but this time as the executive responsible, the pressure was immense.

Currently, Yuu felt more nervous than excited.

Noticing Yuu's stiff expression, Sayaka took his arm and leaned in.

"It's okay. We're here for you."

"Sayaka... yeah, thank you."

From the opposite side, Riko took Yuu's hand and interlaced their fingers.

"We've had so many meetings and prepared thoroughly."

"Riko... that's right."

"Yuu-kun, we've all worked hard together. It'll be fiiine!"

"Haha, hearing that from Emi gives me energy!"

Emi shook her twin tails and smiled cutely from the front, making Yuu smile back too.

Thanks to the three of them, the heavy pressure weighing on Yuu's chest seemed to lighten. Yuu wasn't alone.

The three who had experienced a year in the student council were always by his side, and everyone in the student council and executive committee was cooperating.

During high school in his previous life, he hadn't experienced leading as a leader, but as a former working adult, he had motivated everyone with considerate support.

That said, the female students who became executive committee members just to see Yuu showed such enthusiasm that discussions sometimes turned heated, so Yuu mainly handled mediation.

He had received considerable support from Sayaka and others regarding aspects where his understanding of this world's norms was lacking.

"Good morning! You're all early."

"""Good morning, Yuu-kun!"""

"""G-good morning!"""

As Yuu approached the headquarters tent, all current student council members except Emi and most of the executive committee members were gathered.

Seeing their motivated smiling faces, Yuu's spirits lifted and he raised his right hand, exchanging high-fives left and right.

Some committee members were students he'd first spoken with during festival preparations, but now they felt quite close.

Meanwhile, the remaining committee members including male students arrived.

At 8:30, confirming everyone was present as scheduled, Yuu stood beside the signboard boldly inscribed "Sairei Festival Executive Headquarters." Everyone lined up facing him.

"Now, as executive committee members, we'll begin opening preparations. Please go to your assigned positions as scheduled. Contact between branches and patrol groups via walkie-talkie. If any problem arises at a branch that can't be handled locally, notify headquarters immediately.

Let's begin!"

"""""Yes!"""""

Teams of several members each led by third-years headed to their branches.

Nana waited before the microphone inside the tent.

She would now make the opening announcement for all students.

Having studied acting since childhood, her vocal projection was exceptionally skilled, so she handled announcements.

Emi and Yoshie were record-keepers.

Yuu himself would sit in the innermost part of headquarters, giving instructions as executive committee chairman.

To his left and right were vice-chairmen Kiriko and Sawari. As special support, Sayaka and Riko were also nearby.

At exactly 9:00, the Sairei Festival began with Nana's announcement.

In Yuu's high school days before rebirth, cultural festivals started quietly. Crowds and liveliness usually came around noon.

But in this world, co-ed school cultural festivals were completely different.

"Huh? Footsteps?"

"They're here."

"Yes, as expected."

"What? 100, 200... no, more?"

"Security team members!"

"""Yeah!"""

Everyone around Yuu seemed to know what was coming. Kiriko was contacting someone via walkie-talkie.

Only Yuu was left out of the loop.

"Yuu-kun, could you come out in front of the headquarters tent?"

"I think they won't calm down until they see your face at least once."

"What do you mean?"

Amid countless footsteps approaching like a demonstration crowd, Sayaka and Riko explained.

Most female guests invited to the Sairei Festival wanted even a glimpse of the real Yuu. Many hoped to exchange words with him.

The invitations and distributed pamphlets listed Yuu as executive committee chairman.

Believing they could meet Yuu at headquarters right after opening, they had lined up since early morning.

Yuu's surroundings had anticipated this influx of women and prepared countermeasures.

"Co-come on, hurry!"

"Yuu-kun, over here!"

Urged even by Kiriko and Sawari, Yuu exited the tent.

A podium for morning assemblies had been prepared without him noticing.

The area before the executive headquarters resembled a park-like rest area.

A fountain stood at the center of the lawn, surrounded by planters with flowers carefully cultivated by the gardening club.

Benches were placed around the lawn perimeter.

Just as Yuu stepped onto the podium, an executive committee member holding a flag like a tour guide entered the rest area approaching the headquarters tent.

The flag read "Student Council Chairman Viewing Tour."

Behind her came an orderly four-column line.

Executive committee members and security teams flanked the line, apparently controlling it.

The procession filing in consisted entirely of women - from elementary schoolers to uniformed middle and high school students (including recognizable students from city schools and sister schools), and adults ranging from young people to elderly women.

Women in the front rows saw Yuu and cheered.

"Kyaa! It's Yuu-kun!"

"Wow! The real Hirose Yuu... I finally saw him!"

"He really is a h-a-n-d-s-o-m-e man! If only I were younger..."

"I want to see him closer!"

"Stay in line! Anyone approaching without permission will be ejected!"

The procession stopped near the benches after passing before Yuu on the podium.

Everyone gazed at Yuu with shining eyes, buzzing with excitement.

The line facing Yuu horizontally numbered about 100.

The next line waited with spacing before entering the rest area.

Beyond that, the line continued uninterrupted down the path from the main gate - Yuu couldn't tell how many people there were.

Perhaps the psychology of "let's just get in line" was at work too.

Rather than letting this crowd act freely, fulfilling their expectation of seeing Yuu by following instructions seemed the approach his surroundings had prepared.

Though it felt like being a spectacle, with this many women gathered, some measure was necessary.

Moreover, most invited guests were relatives of Sairei Academy students or students from sister schools.

Therefore, Yuu decided polite treatment was best.

"Good morning, everyone!"

"""G-good morning!"""

"Hehe... mornin', Yuu-kun!"

"Fwaaaaah... he spoke! A boy smiled at me!"

"What are you saying? He smiled at me!"

"Now now, no fighting."

Since many women had little interaction with young males, Yuu's proactive greeting worked.

Though some nearly argued, others mediated.

Yuu continued regardless.

"Thank you for coming to the Sairei Festival today.

The executive committee I chair, along with all our students, have worked hard preparing for this day.

We've prepared many creative stalls, exhibits, experience corners, and performances.

However, there are rules we ask you to follow when visiting Sairei Academy, as written in the pamphlet.

We hope our invited guests will enjoy themselves while following the rules.

Thank you for your cooperation."

When Yuu bowed, energetic replies and clapping spread through the crowd.

Feeling somewhat embarrassed, Yuu smiled shyly and waved.

Seeing this, the women cheered excitedly.

Ultimately, Yuu repeated this greeting about four times for groups of 100 people each.

Among them were student councils from sister schools who cheered for Yuu enthusiastically.

"Phew. Just made it for the morning patrol."

"Good work, Yuu-kun."

"Thanks to you, everyone achieved their initial goal. They obediently followed guidance."

"Most are relatives of our students, but I'm relieved they didn't do anything reckless."

Nearly an hour after opening, the groups specifically there for Yuu had been cleared.

Afterward, women still peeked toward the executive headquarters from the rest area, but security kept them at a distance, with Yuu occasionally waving back.

He had a scheduled patrol as executive committee chairman starting at 10:00.

Incidentally, during this time, male students not at headquarters as executive committee members were either doing final adjustments for plays or performances, or waiting in classrooms.

During the Sairei Festival, male students never acted alone.

By tradition, each male student had two same-grade female companions assigned for morning and afternoon, with group movement encouraged.

Thus, males would tour the campus after being met in classrooms by their female companions.

"Shall we go?"

"""Yes!"""

"Be careful, Yuu-kun."

"Especially around students from other schools."

"Yeah, got it."

Accompanying the 10:00 patrol were Kiriko, Yoshie, and Nana from the student council, plus one executive committee member per grade (Riko for third-years).

Sayaka stayed behind to temporarily act as committee chairman in Yuu's absence.

As Yuu's special security team, former basketball team captain Shiina Chizuru led two six-member teams guarding front and rear.

"First, let's head to the first school building."

"Okay. Looking forward to seeing the stalls."

"I'm more worried... about customers trying to lure big brother."

"I get that."

Though relieved at smoothly handling the initial crowd, would invited guests who saw Yuu up close remain well-behaved?

While Yuu showed open anticipation, the female entourage tightened their focus, knowing the real challenge began now.

With security students still in the courtyard watching women there for Yuu, that area was secure.

Exiting the courtyard, the group headed toward the first school building entrance.

The paved area between the administration building and athletic field resembled a small festival square. Near the administration building entrance stood a campus map created for the day.

Over ten women gathered there seemed to notice Yuu approaching.

But with Chizuru's six-member team forming a vanguard, they only sent heated glances without approaching.

Just as they were about to pass by, light footsteps made Yuu look right.

"Yu, Yuu...kuuun!"

"Hey, wait!"

"Miwa! No!"

"Huh?"

A small girl rushed toward Yuu from the right - seemingly just entered elementary school.

When she tried approaching Yuu, a security member stopped her.

The girl froze wide-eyed. Not forcing her approach made everyone breathe easier.

Chasing after her was a woman around 30 in a suit - silver-rimmed glasses and tied-back black hair giving a plain impression (though her large chest was evident even in the suit). Yuu recognized her.

"Miwa, Yuu-kun is doing important work. Don't bother him."

"But, Mama..."

"Ms. Watanabe from the office, right?"

Yuu addressed the mother.

She was a school office worker he'd spoken with several times.

He remembered her full name was Watanabe Kazuyo.

"Sorry for my daughter stopping you during your busy schedule."

"So this is Ms. Watanabe's daughter."

Since she wasn't a complete stranger - at least a school staff member - Yuu felt inclined to chat briefly.

He wouldn't have been wary of a young girl anyway.

Yuu crouched before the girl.

She had cute big eyes and pigtails tied with bunny character hair ties. If her mother removed those strong-prescription glasses...

"What's your name?"

"Um... Watanabe Miwa. Mi for beautiful, wa for peace. I'm seven!"

"I see, so you're Miwa-chan. You're cute."

"Ehehe."

When Yuu patted her head, Miwa smiled shyly.

"My name is Hirose Yuu."

"I know. Um, Mama always says at home: 'Yuu-kun is so kind and cool! Love love! I wonder if he'll talk to me again?'"

"Miwa! Th-th-that's not..."

Kazuyo behind Miwa flushed bright red.

Yuu smiled wryly and stood up.

Miwa probably meant no harm.

He wanted to chat more with both, but now wasn't the time.

"Well then, I'll be going. See you later."

"Ye...s!"

Waving "Bye-bye" to the smiling Miwa and the bowing Kazuyo, Yuu headed to the first school building entrance.

En route, Kiriko and Yoshie cautioned him to avoid engaging with everyone who approached since it would be endless.

This wasn't jealousy but for Yuu's own good.

They fully understood Yuu couldn't act coldly toward anyone. They steeled themselves to physically intervene if he seemed headed for trouble.

### Chapter Translation Notes
- Translated "彩陵祭" as "Sairei Festival" per Fixed Reference
- Preserved Japanese honorifics (-kun, -chan) throughout
- Maintained Japanese name order (e.g., Watanabe Kazuyo)
- Transliterated sound effects (e.g., "Kyaa!" for キャー, "pachi pachi" for パチパチ)
- Used "Miwa" for みわ as given name appeared without surname initially
- Translated "実行委員長" as "executive committee chairman" for formal role
- Rendered simultaneous dialogue with triple quotes (""") per formatting rules
- Translated culturally specific "お立ち台" as "podium" with context
- Handled internal monologue *(Miwa probably didn't mean any harm.)* with italics