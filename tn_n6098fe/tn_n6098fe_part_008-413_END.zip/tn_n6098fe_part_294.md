## 277. Sairei Festival Day ② ~Welcome To My School~

The southern end of Building 1 served as the usual student entrance.  

Like any school, shoe cubbies for each class lined the spaced-out area where students changed from outdoor shoes to indoor slippers.  

One hour after opening, the building had filled with considerable crowds.  

Whenever entering the all-female Building 1, Yuu always noticed a sweet fragrance. Today, the air hung heavier with varied scents—likely perfumes worn by adult visitors.  

Women who spotted Yuu stopped to stare. Reactions proved stronger among external visitors than Sairei students, creating minor disturbances.  

Chizuru's security team took point, clearing paths through corridors while urging crowds not to block the way. Kiriko and Riko flanked Yuu closely, with Yoshie and Nana guarding immediately behind. As they approached the first classroom, the scent of sweets wafted through the air.  

"Oh? This place is...?"  
"Class 6's cafe, Silent Hill."  
"Eh!?"  
"What's wrong, Yuu-kun?"  
"Ah, nothing."  

Kiriko—being a fellow second-year—answered as they walked side-by-side. Building 1's classrooms hosted mock shops and events run by general-course second-years. Though first-year classes normally occupied the first floor, convenience and foot traffic considerations placed festival venues there.  

Half of each floor's eight classrooms served as preparation rooms. The front first-floor classroom housed the formal cafe Silent Hill. Girl guides in traditional long-skirt maid uniforms (not gothic lolita style) stood in the corridor. Beyond the open door lay chic walls and flooring, with luxurious patterned curtains and even wooden chairs/tables added. Elegant classical music flowed inside.  

The elaborate setup—unrecognizable as a former classroom—perfectly mimicked a real cafe. Yuu felt relief realizing this shared only the name with the horror game franchise, not its themes.  

A glance at the menu board showed various drinks and specialty sweets. It clearly proved popular, packed with female customers.  

"Um! Please visit if you have time!"  
"Thank you. On patrol now—I'll come later."  
""""We'll be waiting!""""  

Three maids bowed as Yuu passed. Though uncertain about personal leisure time, he responded amiably.  

The next classroom—separated by one room—hosted a fortune-telling and magic show. Dark curtains hid the interior, but sounds indicated decent attendance. Fortune-telling seemed popular among women.  

Noticing corridor commotion, a figure emerged from a side door. At first mistaken for a customer, she wore a purple hood and black translucent face veil—classic fortune-teller attire. Her hooded dress featured a deep chest opening with a sparkling blue crystal necklace. The long skirt's slit revealed fishnet-stockinged thighs.  

Yuu's gaze instinctively drifted to the bewitchingly sexy outfit. She smiled and waved subtly—clearly a student who knew him, though heavy makeup obscured recognition. Yuu reflexively waved back while passing.  

After passing an escape maze with quizzes, the deepest room hosted a butler cafe. Naturally, female students crossplayed as butlers.  

Yuu observed the entrance from the corridor. Their appearance and service motions appeared impressively professional, explaining the bustling crowd inside. According to Kiriko, Class 6's formal cafe and Class 1's butler cafe competed fiercely.  

"Young boys are so lovely... jurl"  
"You're drooling."  
"Aahn! I wanna see his whole body up close~"  
"I want to hear his voice~"  
"Okay okay, move aside please—coming through!"  

Attempting to ascend to the second floor, they found the stairs occupied by middle-aged women hoping to view Yuu from above. Security and passing students forcibly cleared them despite protests—smiling while creating space.  

The second floor's first attraction was a haunted house. The wall displayed a massive painting of a decayed mansion surrounded by gruesome ghosts, will-o'-wisps, resentful severed heads on guillotines, emerging skeletons, and bloodstained flying knives.  

*(Art club members' work? Impressive intensity.)*  

Dark curtains hid the interior, but genuine-sounding female screams echoed out—not playful shrieks.  

"This looks... fun to try."  
"Ufufu. Me too."  
"Eeh! S-scary... but with Yuu-kun..."  

Contrasting the timid Kiriko (despite her stature), Riko looked fascinated. Yoshie and Nana also showed interest. Yuu wanted to enjoy close contact with frightened girls—a sentiment everyone shared.  

Right on cue, a girl in white robes beckoned ominously with a creepy smile. Though the large group couldn't enter together, Yuu approached her invitation.  

"How's business?"  
"So-so. Everyone gets genuinely scared."  
"Looks professional."  
"Hey, come in, Student Council President. I wanna hear a boy's frightened voice."  
"Haha. Maybe later if time allows."  

With disheveled long hair, thin eyebrows, and white-powdered skin, she resembled a classic ghost story apparition. Her eerie speech blurred performance and reality. Chuckling awkwardly at the unsettling invitation, Yuu waved and moved on.  

The last second-year classroom hosted a casino—though without real gambling. For ¥100, visitors bought 10 medals for 10 plays (fixed per person). Similar to arcade medal games, simple card/dice games offered returns for wins. Accumulated medals traded for prizes, with players exiting upon losing all.  

Beyond the casino, half the second floor and entire third floor featured displays by cultural clubs/hobby groups using split classrooms. Though less crowded than second-year venues, attendance varied.  

"Come to think of it..."  

Yuu addressed his companions.  

"We're not seeing any boys."  

Hundreds of visitors attended—surely some male family members among them. Nor did all Sairei boys seem likely to stay confined during the festival. Yet Kiriko, Riko and others wore "obviously" expressions.  

"They're just avoiding your vicinity."  
"Probably on the first floor now?"  
"Or at the festival plaza?"  
"Eh? Meaning?"  

A trail of external female visitors followed Yuu like baby ducklings—currently clustered 5 meters behind the rear security team. Ranging from children to adults, they stared intently at the rare sight of a real boy.  

"That's a real boy?" "Weird! Different from Mom." "Way hotter than TV idols." "Hope he shakes hands."  

The explanation became clear: crowds waited for Yuu's group to pass before entering venues.  

Thus leading this swollen entourage (now dozens strong), Yuu patrolled upward. With sparse corridor crowds, no issues arose. No acquaintances appeared either.  

Reaching the end classroom—housing the executive committee branch office—they noticed unusual crowding. Fearing trouble, Yuu peered inside...  

"Yuu!"  
""""He's here!""""  

Chairs scraped as people stood. Though only 10 executive/security members occupied the room, nearly 30 girls packed inside—mostly student council members from sister schools Saibo, Saiai, and Saiei. Hinuma Shuri, Saiai Academy's president, spotted Yuu first.  

They'd arrived 1-2 hours earlier, heard Yuu's morning greeting, then timed their move to headquarters after crowds thinned. Learning of his patrol, they deduced Building 1's third-floor branch office would intercept him—a student council-worthy strategy.  

As they surged forward, Chizuru's team blocked them while Kiriko's group tightened guard—Riko even wrapping her arm around Yuu's waist. Though acquainted, precautions remained necessary. Yuu patted surrounding girls to ease the encirclement.  

To avoid obstruction, he moved to the classroom center while greeting them. Meanwhile, rear security prevented the follower crowd from entering.  

"Waiting here for me? Welcome to Sairei Academy. We're glad to have you."  
"Nah, I just dropped by after seeing calligraphy club displays."  
"I-I... um... came after visiting literature club..."  
"What nonsense! You both entered right after me and came straight here!"  
""W-well..."  
"Doesn't matter. Great seeing you. Shuri, Midori, Mayo."  
"Yuu! I missed you!"  
"M-me too! I've counted the days!"  
"I did too! Yu-Yuu-kun I..."  

Just as an argument flared, Yuu's words instantly cheered up Saibo president Aizawa Midori and Saiei president Mikageishi Mayo.  

The three councils had exchanged greetings during Sairei's sports festival but interacted minimally with Yuu. However, their presidents had recently shared intimate moments with him.  

Naturally, their closeness showed despite the crowd—especially when Yuu addressed them without honorifics. While Shuri remained unflappable and Mayo stared transfixed, only Midori fidgeted under others' scrutiny.  

Saibo's council maintained their predecessors' simple hairstyles and high glasses ratio—true study-focused image. Saiai balanced gyaru and honor students, exemplified by Shuri. Saiei's arts-course members displayed strong individuality: dyed red/green hair, mushroom cuts, twin buns mimicking Mi●ky Mouse, braided updos—all unique. Only president Mayo seemed subdued.  

After greetings, Yuu sought status reports from the third-year branch leaders. With only 1.5 hours elapsed, nothing unusual occurred—though the entire room's attention and Yuu's presence made the seniors' voices tremble.  

Needing to patrol the school grounds next, Yuu bid farewell to each council.  

"Okay, heading out. See you later."  
"Mm. Wish we had more time... but you're busy."  
"Then at the gym this afternoon—"  
"I'll definitely come!"  
"Haha... Hope I meet expectations."  

Midori interrupted Shuri's reluctant farewell, making Shuri scowl. Yuu soothed her by taking her hand—prompting Shuri to grip it joyfully with both hands. Not to be outdone, Midori seized Yuu's left hand.  

"Auuu..."  

Late to act, Mayo stared resentfully at the hand-holding pair. Noticing this, Yuu withdrew his hands.  

"Don't make that face. It ruins your cute looks."  
"...! Hyai"  

Yuu stepped close to pat Mayo's head—so near their bodies almost touched despite her taller height. Blushing but delighted, Mayo relaxed with half-closed eyes.  

"The three presidents seem utterly smitten by Yuu-kun."  
"Mission accomplished for sister-school cooperation?"  
"Perhaps excessively so."  
"Impressive as always, brother. I want head pats too."  

Amidst watching companions—Riko, Kiriko, Yoshie, Nana—Yuu shook hands with every council member before exiting, reiterating instructions to maintain order.  


### Chapter Translation Notes
- Translated "じゅる" as "jurl" to convey drooling sound effect
- Preserved Japanese honorifics (-kun) per style rules
- Maintained original name order (e.g., Hinuma Shuri)
- Translated "ガタガタ" as "scraped" for chair sounds while keeping onomatopoeic essence
- Rendered "ウチ" as "I" for Kansai dialect speaker Hinuma Shuri
- Used "crossplayed" for 男装した女子 to emphasize gender performance aspect
- Translated "骨抜き" as "smitten" to capture romantic enthrallment nuance