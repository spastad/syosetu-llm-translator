## 278. Sairei Festival Day 3 ~For the moment~

The paved space surrounded by Building 1, the administration building, and the gymnasium—during the Sairei Festival, called the "Festival Plaza"—and along the tree-lined path leading to the main gate, food stalls were lined up.

It was truly a festival scene.

There were more people and more liveliness than when Yuu and the others had entered Building 1.

Boys could be seen here and there. Of course, they were firmly surrounded by girls in Sairei uniforms.

The adult women nearby might be family members of the boys or of the accompanying girl students.

The third-year classes were in charge of the food stalls.

From the classic yakisoba and takoyaki stalls, a savory aroma had been drifting since earlier.

What seemed particularly popular with the girls were crepes, soft-serve ice cream, and ice cream.

It was understandable that people would want to eat them since it was a clear day and the temperature had risen.

The caramel popcorn and churros were popular with their unique sweet smell.

It wasn't that crowded yet, but if the temperature dropped in the evening, people might gather at the oden stall.

It was still early for lunch, but people seemed to be lining up at each stall regardless of the time.

The students working at the stalls looked busy, but it was clear they were working with real enjoyment.

"Wow, it's bustling," said Yuu.

"Yuu-kun, if you'd like, why not stop by our class's stall?" asked Riko.

"What's your class selling, Riko?"

"Crepes. Though I'm on the executive committee, so I haven't helped much. But I got to sample them, and they were delicious. Especially on a day like today, the ice cream crepe is recommended."

"Then, after we've looked around, we'll stop by on our way back to headquarters."

Riko seized the moment to promote it, and Yuu became interested.

He didn't usually eat them, but to tell the truth, in his previous life as a third-year high school student, he had sold crepes at his class's stall during the cultural festival. Though it was just selling pre-made items, it had been a fun memory selling them alongside his classmates—especially the girls he didn't usually talk to.

Since it was a stall run by high school students, they didn't make everything from scratch like a real store.

Even if cooking was required, they procured items that were somewhat pre-prepared and sold them with minor adjustments according to the menu.

Sometimes, they rented machines, like for soft-serve ice cream and popcorn.

As for what the first-years were in charge of, they were split between the Festival Plaza and the central courtyard, selling drinks and running a children's festival game and stamp card station.

Not as many people came here, so they seemed a bit bored.

Naturally, it seemed that the second and third years had more substantial plans for their class-based activities.

Yuu's patrol group, led by the security team, managed to make their way through the crowded plaza.

They encountered several acquaintances, including boys from the same class, but they couldn't stop, so they just waved lightly when they made eye contact and moved on.

When they reached the halfway point of the tree-lined path to the main gate, the rush of visitors seemed to have passed, and the crowd thinned.

On both sides of the path, in front of the soccer goals on the field and on the tennis courts, sports clubs were holding activity trials and mini-games, and the cheerful voices of elementary and middle school girls could be heard.

*I wonder if among them there are children who will enroll in Sairei's physical education course in the future.*

Until now, Yuu had mostly encountered fellow high school students or older women, so he had little connection with elementary and middle school students, and he was a bit curious, but for now, the patrol took priority, so he only watched from a distance.

The group arrived near the main gate.

"Yuu-kun, it's better if you don't get too close to the gate."  
"We'll be your wall, so go behind the tent."  
"Okay. Thank you."

According to a member of the security team who had gone to scout, there seemed to be quite a few women who, without official invitations, had been denied entry but couldn't give up, so they were loitering in front of the main gate or on the surrounding roads.

Among them was a group from Ichimatsu High School, notorious in the city as a delinquent school.

The school security guards had made them keep a distance that didn't obstruct traffic, but they were repeatedly warned for trying to peek inside the school grounds.

*Hiding in the shadow of the tall basketball team members of the security squad made me feel somewhat pathetic as a man. However, if I were seen and caused unnecessary chaos, it would only cause trouble, so I decided to obediently comply.*

Even now, people who had passed the checkpoint at the main gate were arriving in a steady stream, receiving pamphlets at the reception desk just inside and heading toward the school buildings.

With the security team acting as a wall, Yuu slipped behind the reception tent to avoid standing out.

"Good work, Fujieda Captain."  
"Hey, Yuu-kun! You came. But I've retired, so I'm not captain anymore, right?"  
"Ah, that's right. I slipped up."

The one who had come to the back of the tent despite being busy, to report on the situation, was the leader of the security team in charge near the main gate and the former captain of the soccer team, Fujieda Wakako (3rd year, physical education course).

She wore a tracksuit top and bottom with the security team's happi coat over it. At about 175 cm tall, she was average height for the physical education course, and she had a slender build that didn't appear heavily muscled.

But due to the full-body contact in her sport, she was actually lean and muscular. Apparently, she looked impressive without clothes (in terms of muscle).

She had short, wavy brown hair and tanned skin that still showed traces of sunburn.

With her sharp, well-defined features, she was a handsome senior who gave off a masculine vibe.

Because of this, during soccer matches, enthusiastic cheers would fly from the stands.

According to what Yuu had heard before, she had been academically excellent since middle school and was an all-rounder who could have gotten into Sairei's general course on academic merit alone, not just soccer.

This Wakako greeted Yuu in a friendly manner.

She had served as the executive committee chairperson for last month's sports festival and had been acquainted with Yuu since he joined the student council.

"So, how are things? Well, I can imagine it's been tough."  
"Yeah. I did security last year too, so I thought I knew what to expect, but this year was beyond my expectations..."

Wakako gave a tired smile in response to Yuu's question.

Her voice was a bit hoarse, probably from shouting since morning. Unlike on the field, the difficulties of security duty at a school event were entirely different.

She had worked with the school security guards to handle the large number of visitors since early morning. Even though it was only near the main gate, she must have had a hard time dealing with those who tried to force their way in.

"Thanks to the cooperation of the police and security guards, we haven't allowed any intrusions so far. I'm worried about the group loitering outside growing as time passes. Anyway, we change shifts at 12, so just one more push."  
"The Sairei Festival is proceeding smoothly without incident, and we male students can feel safe especially thanks to the security team. Please hang in there just a little longer."

As Yuu approached, intending to at least shake her hand to show appreciation, Wakako muttered softly.

"If I could hug Yuu-kun tight, I could keep going... Ah! Just kidding, kidding! My wish slipped out."  
"That's an easy request."  
"Sorry, I said something weird... Huh?"

With the right hand he had extended for a handshake, Yuu took Wakako's arm and pulled her close.

Though she looked delicate, Wakako was strong, but for now, she let herself be pulled by Yuu, and their bodies pressed together.

She looked surprised, but upon feeling Yuu's body and scent, she broke into a truly happy expression and wrapped both arms around his back.

Of course, Yuu also wrapped both arms around her and held her tight.

Wakako's body, being well-trained, felt firm at first, but her chest was surprisingly ample, and the softness that came through was pleasing.

The faint scent of sweat tickling his nostrils wasn't unpleasant to Yuu; rather, he found it appealing.

"Fujieda-senpai?"  
"Call me by my name. Just Wakako is fine. Like... like Shiina from the basketball team."

Though she hadn't gone around saying they had sex, Shiina Chizuru, the former captain of the basketball team who was in charge of Yuu's personal security at every school event, was considered to have a special closeness with Yuu.

Wakako seemed to envy that.

"Okay. Got it. Wakako, I'm always counting on you."  
"Fah! I-I'm so happy! For Yuu-kun, I can do my best!"

As Yuu whispered that, rubbing his cheek against her neck, Wakako writhed with joy.

If it made her happy, Yuu thought, he kept their bodies pressed together like passionate lovers and continued stroking her short hair.

The security team was busy, so Wakako was the only one who could come to Yuu's call, but now she thought it was for the best. She could bask in the happiness of having Yuu all to herself.

In the end, it continued until Riko, Kiriko, and Chizuru, who had come along, told them, "That's enough."

"Here! A little extra!"  
"Eh! That's too kind."  
"No, no. For Yuu-kun... we have to give extra. Right?"  
"Um, well. Thank you."

Even though he had bought two packs of takoyaki (8 pieces each), he was given an extra one.

In return, Yuu shook hands one by one with the third-year girls working at the stall.

Except for a few, the third-years hadn't had many chances to interact with Yuu, so they were ecstatic at the stall.

Having finished patrolling from the main gate through the grounds, Yuu and the others were now going around the stalls in the Festival Plaza one by one.

They intended to buy something from every stall for the student council and executive committee members who were holding down the fort.

At that time, they were told it would be better if Yuu did the buying, and now he understood why.

Every time they went to a stall, they got extra.

Each time, Yuu shook hands with each of the salesgirls.

By the time they finished shopping at all six stalls, Riko, Yoshie, and Nana had plastic bags hanging from both hands.

"Then, let's head back to headquarters."  
"Wait a moment, Yuu-kun!"  
"What's up?"

The ones who stopped Yuu were the security team members from the basketball team, including Chizuru.

"Over there, our classmates and underclassmen are making curry."  
"If Yuu-kun goes to buy some, I think they'd be really happy."  
"Ah, that's right!"

In the physical education course, where all students belonged to sports clubs, security teams were organized by club, with shifts from the night before until the end of the event, so they didn't do class-based activities.

Instead, they ran a curry stall jointly across all three grades. Led by Chizuru and the others, Yuu decided to go there.

Near the gymnasium, a large tent was set up with banners fluttering that read "Sairei's Famous Super-Spicy Curry" and "Popular with Boys Too!"

People were gathering from the field side, and it seemed quite popular.

The reason the curry stall was set apart from the plaza was that the curry smell was too strong and would interfere with the other stalls' business.

"Ayu!"  
"Hyaa!"

Perhaps because it was near lunchtime, Yuu avoided the crowd in front of the tent and went around to the side with Chizuru and the others, where he spotted a petite girl coming out.

With short hair so boyish it could be mistaken for a boy's, and small in stature. Her well-toned, efficient body was clad in a short-sleeved gym shirt and bloomers.

Startled by a sudden tap on the shoulder from behind, she turned around and, upon recognizing Yuu, broke into a flower-like smile.

"Yuu!"  
"Long time no see, Ayu."

The one who high-fived Yuu with both hands and smiled happily was Hayakawa Ayumu, the ace of the track and field team, a second-year.

Last month, she had won the special event at the sports festival and had a date alone with Yuu, which naturally led to a physical relationship. But at school, Yuu was busy with the student council and Ayumu with club activities, so they hadn't had a chance to meet.

"Don't tell me you were making curry too, Ayu?"  
"Ahaha... I'm totally useless at cooking, so I'm just selling. This is only until 12; in the afternoon, I'll be with the track and field club."

It was now past 11:30. Just when he was getting hungry, the curry smell was appetizing.

Looking, there were three types: mild, medium spicy, and spicy, plus an extra spicy for those who liked it really hot.

When Yuu made curry at home, it was always medium spicy. Only his sister Elena disliked spicy food, while Yuu and Martina liked it fairly spicy.

That said, once he tried a 20-times-spicy instant curry and struggled to eat it, so he wasn't particularly strong against spice.

"Perfect timing, tell me: how spicy is the extra spicy?"  
"Extra spicy? Hmm, some girls can't eat it because it's too spicy, but some say they can handle it... Do you like spicy, Yuu?"  
"Well, I guess so."  
"Then you'll definitely be fine! You can handle it!"

Ayu was inherently optimistic and preferred to push forward rather than retreat when in doubt.

With Ayu's innocent smile giving her stamp of approval, Yuu got into the spirit.

The basketball team members, including Chizuru, knew exactly how spicy it was and looked worried, but they also wanted to see Yuu's reaction, so they silently watched the exchange.

"Then, I'll take one of each: mild, medium spicy, spicy, and extra spicy."  
"Roger! Wait just a sec."

Since Yuu lining up would cause a commotion, Ayu went to place the order for him.

The four curries, served in deep paper plates, would be carried to headquarters by Ayu and another first-year track team member.

Yuu hadn't met her before. She was tall and slender, exactly like a track athlete. Every time she spoke, her short ponytail swayed; she had a small face and was cute.

According to what he heard on the way, she specialized in the high jump.

Since she was good friends with Ayu, she was chosen for the carrying job and was very happy to talk to Yuu for the first time.

"I'm back."  
"Welcome back!"  
"Welcome back, Yuu-kun!"  
"I thought I smelled something good."  
"It's about lunchtime, so let's eat together?"

When Yuu returned to headquarters, Sayaka and Emi welcomed him.

There had been some reports while he was away.

As expected, there were people trying to infiltrate the school.

They seemed to be targeting the closed west or east gates, seeing that security was tight at the main gate and climbing over the barbed wire on the walls would be tough.

However, the security side was aware, and those who climbed over were promptly caught.

He was relieved to hear that the invited guests from the sister schools hadn't caused any problems so far, as had been a concern.

In the afternoon, there was a boys' event in the gymnasium.

Yuu had time before his turn, but as executive committee chairperson, he intended to watch from the beginning.

He wanted to go to the gym at 1 PM, so he decided to have lunch right away.

It seemed they had ordered delivery from each class's stall to headquarters, and right after Yuu returned, the food started arriving.

Everyone wanted to see Yuu and have him eat, so there was more food than needed for the headquarters staff. So they shared some with the security team.

"Then, shall we start with the curry?"  
"Eh... Yuu-kun, don't tell me that's..."  
"No way...?"

Sayaka and Emi were surprised that he picked the plate of curry that was clearly red and thick among the four.

They knew how spicy it was.

"Let's eat!"  
"W-wait!"

Ignoring the surrounding worries, Yuu took a bite of the curry.

Immediately, a tingling spiciness ran through his mouth. Spicy.

But not so spicy he couldn't eat it. Better than the 20-times-spicy. At most, about 10 times.

He could also feel the richness and umami of the curry beneath the spiciness.

*I can handle it!* he thought, and kept eating bite after bite.

But after one or two minutes.

"Ugh! Nnnnnnnnnnnnnnnnnnnnnn!!!"

A strong spicy stimulus ran from his forehead to his head. His face flushed, and sweat poured out.

"Ho... hot..."  
"Here. Yuu, drink."  
"Th-thanks."

Ayu, who had come near without him noticing, opened a blue can similar to Pocari Sweat and offered it.

"The spiciness hits you afterward. Everyone who's eaten it says that. You need a drink with it."  
"Ayu-senpai, you should have said that earlier."  
"Tehehe."

"Glug, glug... Mmm... Phew. It's not that it's not delicious, but it's spicier than I expected."  
"That spicy? Onii-san, let me try some too."  
"Ah!"

Nana naturally took the plate Yuu had started eating from.

Yoshie and Kiriko, who had apparently been eyeing it too, looked disappointed.

Nana, and then Yoshie after a few bites, covered their mouths and drank water, and finally Kiriko, who loved spicy food, finished it.

Yuu was scolded by Sayaka and Riko for eating spicy food when he had an event in the afternoon.

And to neutralize the spiciness, Riko fed him a sweet ice cream crepe.

---

### Author's Afterword

Selling crepes at the cultural festival was based on the author's real experience.

Even though the conversation with the girls was lively in the festival mood, there was no particular development, and things went back to normal afterward.

### Chapter Translation Notes
- Translated "ブルマー" as "bloomers" to preserve cultural specificity of Japanese gym attire
- Preserved Japanese honorifics (-kun, -senpai) and name order (e.g., Fujieda Wakako)
- Transliterated sound effects: "ぱくっと" → "pakutto", "パクパク" → "pakupaku", "う゛っ！ んんんんん～～～～～～～～～～っ！！！" → "Ugh! Nnnnnnnnnnnnnnnnnnnnnn!!!"
- Rendered internal monologues in italics with asterisks per style guidelines
- Used "Pocari Sweat" for "ポカリスエット" as it's a real product reference
- Maintained original dialogue formatting with new paragraphs for each speaker