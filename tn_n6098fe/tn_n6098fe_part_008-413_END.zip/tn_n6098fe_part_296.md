## 279. Sairei Festival Day ④ ~Stardust Stage~

In the gymnasium during the morning, band performances, choruses, and skits were being held.

However, all were by female students. Audience attendance was so sparse that it was considered decent if even half the pipe chairs placed in the front section were filled.

This changed completely after lunch.

Because the male students' performances would begin in the afternoon.

That said, reserving seats from the morning was prohibited.

When the morning performances ended just before 12 PM, the gym became off-limits to non-staff, and preparations began.

Then, exactly at 1 PM, when the large metal doors in front of the gymnasium were thrown open, the waiting women surged in all at once.

Had Yuu been watching, it would have reminded him of middle-aged women rushing into department store bargain sales.

The seating arrangement remained unchanged, so the approximately 300 pipe chairs placed at the front were filled within about five minutes.

Most were occupied by second- and third-year students or their families. The rest were faculty members with free time.

Since this happened every year, everyone knew seats would disappear if they didn't arrive early.

Incidentally, students who had drawn the short straw for afternoon shifts at food stalls were shedding tears of frustration while looking at the now deserted school grounds and plaza.

First-year students and invited sister school students also streamed in, claiming spots close to the stage.

Long before the 1:30 PM start time, nearly 1,000 people had packed the gymnasium to capacity.

Those who arrived late and couldn't get inside stood near the open doors, peering in.

The gymnasium was so packed there was no room to stand, jammed like sardines, with the women's heated anticipation for the boys' appearance making everyone sweat.

Additionally, a second-floor seating area was set up at the back of the gymnasium. In the center, school-approved photographers and cameramen from Weekly Fuji and Saito News were setting up cameras with large telephoto lenses. About thirty guests including Ayakuni Group executives, board of education members, and local politicians lined up holding binoculars.

"Wow... so many people"  
"I-I'm getting nervous"  
"It'll be fine. We practiced so much"  
"Everyone's here to see the boys. We just need to perform like normal"

With most students and visitors crowding into the gymnasium, the executive committee had moved their headquarters to the second floor. Only some committee members remained at the headquarters tent as liaisons.

When Yuu went to check on the first-floor waiting room, he overheard performing female students talking.

First-years couldn't hide their nervousness at the unexpectedly large audience, while experienced second- and third-years encouraged them.

Though the girls were nervous about the crowd size, they smiled with relative composure.

In contrast, first-year boys participating for the first time looked pale or fell silent to a concerning degree.

Amidst this, Yuu spotted his friend Masaya and tapped his shoulder from behind.

"Yo"  
"Gah! W-what, Yuu? Don't scare me like that"  
"Don't stiffen up so much. Relax, relax"  
"I-I know"

The afternoon segment would open with the brass band club, and Masaya's unprecedented tension showed in his rigid posture.

"But it's great you get to perform with your clubmates, right?"  
"W-well, yeah. Senpai, classmates—I think I joined a good club regardless of gender"

Yuu had met Sayaka, Riko, and Emi through the student council. Since the council transition, he'd also been happily working with Kiriko, Mizuki, Sawa, Yoshie, and Nana.

Hearing that Masaya—the friend he'd made immediately after being reborn into this high school—was enjoying club activities beyond just studying made Yuu happy as if it were his own achievement.

"Looking forward to your band's songs, Masaya. Show me what you practiced!"  
"Y-yeah"

Though Yuu knew little about music, his anticipation for the live performance was genuine.

When Yuu raised his fist, Masaya awkwardly smiled and bumped fists back.

At exactly 1:30 PM, a buzzer sounded, and the buzzing gymnasium fell silent.

*'We will now begin the co-ed performance by Sairei Academy High School. First up is a performance by the brass band club.'*

As the announcement played, the curtain lowered over the stage rose.

Under bright stage lights, the brass band stood assembled like an orchestra, instruments in hand.

Among the approximately 40 members from end to end, 14 were male. Unlike sports clubs that retired after summer tournaments, many cultural clubs treated the Sairei Festival as their final event, so all three grades were present. Though the brass band was popular and had more female members since boys joined annually, only a limited number could perform here.

Members weren't in uniforms—girls wore white blouses with black long skirts, their chest ribbons in various colors like red, purple, and blue.

Boys also matched in white dress shirts and black slacks, with necktie colors apparently left to individual choice.

Masaya, wearing a navy-and-red striped tie, held the trumpet—considered the brass band's star instrument.

Now with his instrument ready, he appeared composed.

The gathered audience came almost exclusively to see male high schoolers.

They likely wanted to see the rare sight of male high schoolers on stage with their own eyes—a rarity outdoors.

Indeed, the audience's eyes were fixed on the male members holding instruments.

Before the music started, whispers like "That one's handsome" or "He's my type" leaked out.

Even so, this many spectators had gathered.

The performers wanted to captivate them with skills honed through daily practice.

Hence, they seemed to have chosen songs known to the general public.

After the conductor bowed, the first song began.

*Combat March*.

Its brave melody, like warriors heading to battle, made hearts race.

While certainly an energetic opener, Yuu strongly associated it with baseball cheering songs.

Perhaps it was used as a cheering song in this world too.

The march seemed to successfully grab the audience's enthusiasm, and the momentum carried into the second song.

A heroic, majestic symphony evoking mythical war maidens.

The audience's excitement from *Combat March* escalated further.

*Ride of the Valkyries*.

In this world where even war was waged by women, Valkyries were generally viewed not as ominous death-bringers but as invincible heroes whose divine exploits terrified enemies.

That said, Yuu almost hallucinated an impending helicopter gunship assault.

Then the third song started quietly with resonant low notes, completely changing the mood.

*Going Home* (original: Dvořák's Symphony No. 9 "From the New World," 2nd movement).

The earlier fervor vanished as everyone listened intently.

Images of twilight scenes or childhood homes likely surfaced in their hearts.

Especially for older attendees, nostalgic emotions were stirred.

Long introduced in Japan, this song with Japanese lyrics was beloved as a children's song. Like in Yuu's world, it played nationwide in evenings to urge people home.

Perhaps that's why—hearing it made one want to return home.

As the performance ended, silence enveloped the gymnasium.

Immediately, thunderous applause erupted.

The playing had been that memorable and magnificent.

Every brass band member on stage wore an expression of fulfillment.

The applause continued long before the next announcement played.

*'Second is a play presentation by the drama club. The title is "Best Girl: Sairei Special Edition."'*

After a five-minute intermission for preparations, the curtain rose with the announcement, and the drama club's performance began.

Based on a 1980s American film about a bullied girl who meets a Japanese-American elderly woman and grows through learning karate, this version transformed into a school battle drama set in a co-ed high school modeled after Sairei Academy—inexplicably incorporating "Cinderella" elements.

The story followed the unremarkable youngest daughter of a dojo-owning family who, under a sage-like elderly woman's guidance, grew stronger rapidly. Her chubby physique became leanly muscular through rigorous training, and her messy hair was cut short to reveal androgynous beauty.

At the school's martial arts tournament (replacing a ball), she won the heart of the male student council president hosting it.

Incidentally, instead of a glass slipper, she dropped a colorful mask used to hide her identity.

The play unfolded with passionate developments: comedic elements in the chaotic training segments and protagonist's goofiness, intense battles against the master's mother, apprentice sister, and school rivals, all while depicting romance with the student council president.

Frankly, the acting by male members—especially the student council president—wasn't skillful by any stretch.

But the performances by the protagonist girl, her mother and sister, and the president's fiancée/rival (who somewhat resembled Sayaka) were outstanding and elevated the play.

The ending—where the rival acknowledges her and she amiably becomes one of the president's fiancées—felt like a fitting conclusion for this world.

Next came a song and dance by second-year boys, backed by a mixed-gender band from the light music club.

Originally planned for nine members like the currently popular male idol group, only seven participated.

Still, when they took the stage in idol-inspired costumes, cheers erupted.

Female students waved penlights in time with the music.

The scene resembled stars twinkling in the night sky.

Around that time, Yuu was heading to the waiting room.

Next was the boys-only cosplay show.

With many boys not participating in performances like music, plays, songs, or the final pageant, 54 boys from all three grades would parade down a runway extending from the stage in various costumes.

Female audience members eagerly anticipated this visual feast.

Yuu would close the show. Though appearing last, he went early due to time-consuming costume changes and preparations.

Security guarded the waiting room entrance to prevent outsiders from entering.

Only event managers, home economics club members, fashion research club members, and their advisors helping with costumes and changes could enter besides the boys.

When Yuu entered, chaos reigned with the show approaching.

"Has Group 1 finished changing? 15 minutes until showtime!"  
"Two more people, wait five minutes!"  
"What about Group 2's preparations?"  
"Where's the silver belt? That was custom-made!"  
"Maybe still in the bag in the next room. I'll look!"  
"Hurry!"

Though reasonably spacious, the waiting room was packed with about 70 people rushing around frantically.

However, only the girls seemed flustered.

Performing boys either changed as instructed or waited quietly in designated spots.

They understood it was best not to interfere during such chaos.

Costume changes occurred in two curtained-off spaces at the back.

The larger right side was boys-only, but the smaller left side allowed girls to assist with complex costumes requiring help.

Having collaborated to make the Sairei Festival stage successful, the boys didn't fuss over details now.

"Whoa, that suits you well! That uniform looks cool too!"  
"R-really? Hehe..."

Near the entrance, tape marked the floor where the first group of changed first-years lined up.

The three at the front wore police uniforms.

Though usually quiet classmates, they seemed pleased by Yuu's praise.

Besides police, there were military uniforms, butler outfits, and baseball/soccer uniforms—all representing male-dominated professions nearly nonexistent in this world.

Based on real female uniforms with modest coverage, they differed slightly from Yuu's memories and felt distinctly cosplay-like on high schoolers.

Yuu complimented them to motivate them since they'd need to pose and perform brief acts, not just walk.

"With that huge crowd... I'm getting nervous again"  
"Should I go to the bathroom one more time?"  
"Well, everyone's nervous. Let's enjoy this special stage!"  
"Hahaha..."  
"Speaking of, Hirose-kun, you've got it tough closing the show"  
"Yeah. Plus the costume's kinda outrageous..."  
"It's a surprise finale, right? Nobody's seen it"  
"Don't be shocked when you see it"  
"Not sure about that..."

Perhaps the shared stage created camaraderie, making them more talkative than usual.

Just then, a first-year who'd finished changing arrived, and an event manager immediately called out.

"Group 1, please follow me to the stage wings!"  
"Ooh, finally!"  
"It's time!"  
"Go for it!"  
"""Ooh!"""  
"C-can I do this well...?"

Some were eager, others visibly nervous—all followed the manager out of the waiting room.

Meanwhile, Yuu noticed Uryu Yuri and Vanessa waving enthusiastically from the left changing area and smiled wryly.

He'd heard they'd apply makeup during the costume change.

Though the costume was embarrassing, he had to hype up the show as the closer.

Steeling himself, Yuu headed toward where they waited.

---

### Author's Afterword

If history changes, culture changes too—so famous songs shouldn't exist in this world.

As with Saiei Academy's music recital earlier, I've used historically famous titles for reader familiarity, prioritizing that over whether high school brass bands would actually play them.

**[Supplementary Notes for Unfamiliar Readers]**

*Ride of the Valkyries*

"Yuu almost hallucinated an impending helicopter gunship assault."

→ Because a war film featured a scene of helicopters playing this song at full volume during strafing runs.

A similar scene appeared years ago in an anime where the Self-Defense Forces traveled to another world.

Videos exist on YouTube if you're curious.

### Chapter Translation Notes
- Translated "星屑のステージ" as "Stardust Stage" to reflect the penlight imagery
- Preserved musical titles as *Combat March*, *Ride of the Valkyries*, and *Going Home* per real-world equivalents
- Translated play title as "Best Girl: Sairei Special Edition" maintaining the adaptation context
- Transliterated sound effects (e.g., "Gah!" for っぁ)
- Maintained Japanese name order and honorifics (e.g., Hirose Yuu, -kun)
- Italicized internal monologues per style guide
- Translated "ペンライト" as "penlights" for cultural accuracy
- Rendered simultaneous dialogue with double quotes per attribution rules