## 280. Sairei Festival Day ⑤ ~Show Time~

"Now then, it's finally time for the cosplay show by Sairei Academy's male students! First up, first-year boys with the concept 'Dream Occupations'!"

Cheers filled the gymnasium, shaking the air. Compared to earlier, the announcer's voice had noticeably more energy. This was the long-awaited appearance of cosplaying high school boys - a rare opportunity only available here and now. Since photography wasn't allowed, everyone fixed their heated gazes on the stage, determined to sear the images into their memories.

To the theme song of a famous detective drama, three boys appeared wearing police uniform-inspired costumes. They faced forward near center stage, saluted, then struck poses with toy guns drawn.

"Yaaay! So cool!"  
"Shoot through my heart!"  
"Arrest me!"

Playful cheers erupted. The female students seemed determined to encourage the boys and liven up the show. The boys on stage flushed crimson under the enthusiastic cheers as they walked down the extended pathway from center stage. At the circular end platform, they stopped and scanned their surroundings with serious expressions. It seemed both men and women looked more attractive in uniform. Not just students, but first-time visitors seeing high school boys in person also felt their hearts race.

The police-costumed boys didn't return immediately.

"Hmph! Spotted the suspect in a major case! Arrest her!"  
"Yes ma'am!"

Though somewhat theatrical, the middle officer pointed toward the audience seating - where security members sat guarding against unauthorized access. Two male officers descended amid the murmuring crowd and apprehended two female teachers who'd secured front-row seats. They were playfully handcuffed with toy restraints, looking delighted nonetheless. Thus, the officers returned with their "suspects" in tow - a planned surprise element to enhance the show beyond mere modeling.

The show continued with soldiers, butlers, and athletes - occupations nearly extinct for men in reality - drawing nonstop cheers. The second-year theme was "Historical Heroes." In eras with equal gender ratios, warfare had been men's domain. Many women sought romance in antiquity when modern reality offered little hope. Hence, anime/games set before the Red Death pandemic remained popular, spawning countless derivative works. Fans grew so passionate they fiercely debated favorite historical figures from the same era.

The second-year boys wore European knight armor and samurai gear (lightweight substitutes) supervised by the History Research Club, posing with spears and swords. Though wearing thin innerwear, the neutral color made gaps appear bare-skinned, exciting the audience. "Captives" included not just students and staff but lucky audience members and sister school students, who looked flustered yet pleased at the surprise.

The third-year concept was "Our Heroes" - tokusatsu teams (where actresses play male roles), magical boys, futuristic pilots, and fantasy warriors (in gender-equal/male-majority settings). Short skits unfolded: a girl "kidnapped" by an evil leader (smiling without fear), rescued by heroes; middle school girls tearful at joining a reverse-harem adventurer party. Regardless of acting skill, every woman sharing the stage with cosplaying boys wore joyful smiles.

『That concludes the cosplay show by Sairei Academy's 53 male students across three grades! Did everyone enjoy it?』

Applause and cheers answered the announcement. But some students shouted a different name - Yuu's.

『Actually, it's not over yet! The finale will be... Sairei Academy's proud student council president, Hirose Yuu! His concept is... the Demon King! What terrifying demon king will appear? Ahh! H-he's coming! The Demon King-sama descends!』

Before the announcement finished, heavy sound effects echoed as low piano notes began the BGM - literally titled "Der Erlkönig" (The Erlking). Yuu emerged from the wings amid stage smoke, draped in a jet-black cloak with high collar and bone-spiked shoulder pads, wearing a crown with two horns.

Under dimmed lights, only a spotlight illuminated Yuu. His sharp gaze and makeup created a perfect demon king aura as he faced forward.

"Oooh!" The gymnasium stirred instantly. Yuu concealed his body with the cloak and began walking silently, thick-soled boots echoing sharply. Unfastening the clasp at his left shoulder as he strode, the cloak parted to reveal his outfit. The audience gasped.

Beneath: sleeveless top and slim pants in glossy black leather. A necklace glittered at his chest, silver chains and imitation jewels sparkling around his waist. To Yuu, it resembled heavy metal or steampunk fashion more than a demon king. Vanessa's designs had included shorts with fishnets, but he'd rejected those as too embarrassing.

Still, the female audience couldn't hide their excitement. Yuu's quarter-Latin features, enhanced by makeup, radiated dangerously beautiful charm. But there was more to see: in this world, men rarely wore short sleeves in summer, let alone exposed armpits. Yet as Yuu walked, he alternately raised his arms in "scanning the horizon" poses, revealing dark underarm hair. Many women stared intently at the unprecedented sight of bare arms and armpits.

Countless others admired his long, slender legs, while many focused on his crotch. Those nearby or using binoculars noticed the distinct bulge. Though not erect, the tight pants made it obvious - deliberately so, as Vanessa had tailored them snug. They proved difficult to remove, requiring her careful assistance during fittings.

Yuu slowly turned, deliberately displaying himself, then grinned and spoke.

"Fuhahahahahaha!"

Though Yuu aimed for a demonic heavy metal vocalist laugh, the audience seemed stunned. *(Maybe I weirded them out?)* he thought nervously, but pressed on with a low voice inspired by Demon Kogure-*sama*.

"It's been long since I came from the demon world, but what perfect timing. So many women gathered here! Excellent. I shall select worthy servants from among you."

"Yuu Demon King-sama!"  
"Kyaa! Amazing!"  
"Thrilling!"  
"Take me to the demon world!"  
"Me! I'll serve you forever!"

As enthusiastic students shouted, others joined in.

"Kukuku. Already women stir under my demonic power. But for servants, I require young women of beauty and talent. Hmm... You there! Come closer."

Yuu pointed at Nana standing before the front row. She'd changed into a pure white dress with hair loosely flowing - a simple look accentuating her innocent beauty. Like a sleepwalker, she floated up the steps to Yuu. Her large eyes fixed on him, appearing genuinely enchanted.

"State your name."  
"Nana."  
"A fine name."  
"Demon King...sama..."  
"Nana. Will you become my servant?"  
"Yes. I'll serve with all my body and soul."

As Nana bowed deeply, lustrous black hair cascaded down. Yuu combed her hair with his right hand, then pulled her close by the slender shoulders. Seeing her pale nape, Yuu grinned and pantomimed a vampire bite. Though not breaking skin, when Yuu's mouth closed on her bare skin with slight suction, Nana released a soft sigh. He caught her as she nearly collapsed, then held her as she clung to him with a dazed expression. Immediately, "I'm jealous!" "Me too!" erupted.

This followed the rehearsal plan. Yuu decided to take another, scanning the audience where softer lighting now allowed recognition. His gaze fixed on familiar uniforms.

"Ho? This... is a supreme woman."

Yuu's left hand rose. The indicated area stirred, some women waving and calling "Me! Me!"

"What...? The Saibou Middle School student council president? Come here."

Only one person fit that description. Urged by her council members ("Go on, President!"), Asagi Ruriko emerged through the crowd. Though slightly nervous facing Yuu unexpectedly, her dignified beauty seemed beyond middle school age. Yuu lifted her well-shaped chin with his fingertips.

"You should feel honored to be chosen as my servant."  
"Ah..."

Yuu's fingers trailed from chin to cheek, lightly brushing her ear before stroking her hair. Ruriko flushed crimson. Seeing her reaction, Yuu pulled her close. No woman would refuse now. When Yuu "bit" her nape like Nana's, Ruriko shuddered with a small gasp. Without letting her act, Yuu forcibly embraced her, turned sharply, and strode away. Amid continuing calls for Yuu, the demon king exited dramatically, cloak swirling, with Nana and Ruriko pressed happily against him.

"Yuu-kun, great job!"  
"It was wonderful!"  
"Seriously amazing! The costume was perfect!"  
"Yeah. Cool performance too."  
"Ahaha, thanks. I'm getting embarrassed now though."

Backstage, Vanessa, Yuri, and many others greeted Yuu. Even boys praised him with shining eyes, perhaps inspired by the chuunibyou-esque performance. Hearing their praise, Yuu felt his over-the-top acting paid off. Still, he wanted to change quickly for the Miss Contest to see seniors and friends crossdressing.

He addressed the girls still clinging to him:  
"Nana performed perfectly as planned, and Ruriko came despite the sudden call. Thank you."  
"Mmm..."  
"Ah... y-yes."

Neither tried to move, reluctant to lose this closeness. Though half-sisters, they rarely lived together or had private time with Yuu. Nana wanted to indulge now, while Ruriko stayed attached since Nana did.

Yuu noticed Nana's thin dress revealed she wore no bra - small breasts pressed against him through the fabric. *(Must resist...)* he thought, fighting arousal. Seeing his discomfort, Nana looked up pleadingly.

"Onii-san. If you're grateful... I want a reward."  
"A reward? What would you like?"

Instead of answering, Nana tilted her chin up and closed her eyes. Despite the crowd, Yuu kissed her soft lips without hesitation.

"Whoa!"

Ignoring the outburst, Yuu thoroughly enjoyed her lips, even inserting his tongue. Nana accepted eagerly, actively tangling tongues.

"Mmph... mmmph... nnf... chup... uun... ero, nero... ah... fuu... chupaa... nihhyan, suki... nn, nn, nkuun"

Spectators watched stunned as they kissed wetly for a full minute. Yuu wanted more but pulled away, a thread of saliva visibly connecting their tongues. He supported Nana as her legs wobbled, then turned to Ruriko.

"Ruriko?"  
"Me..."

Blushing crimson, Ruriko hesitated but closed her eyes resolutely. Yuu kissed her normally at first. "Open," he whispered, and when a small gap appeared, his tongue slipped in. At the touch, Ruriko gasped "Nn... fuu" and clung tightly. After another minute-long deep kiss, Yuu patted both heads. They pulled away reluctantly.

"Hey! M-me too... give me a reward!"  
"Me too! I want one too!"  
"Well... alright."

Caught in the heated mood, Vanessa and Yuri rushed over. Despite their tendencies, they'd helped Yuu considerably - including with his lower half. As Yuu extended his arms, they jumped into his embrace with joyful expressions. He kissed them alternately. Then he kissed over ten more - fashion club members, home economics club helpers, and event staff who'd assisted with makeup and costumes.

Finally noticing the Miss Contest announcement, Yuu rushed to the wings without changing clothes.

---

### Author's Afterword

The initial cosplay concept was a male king in black leather bondage wear - covered chest but with midriff exposed, boomerang pants, and whip. I reconsidered since Yuu would probably refuse (though women would love it), opting for the cool demon king look (essentially heavy metal fashion).

### Chapter Translation Notes
- Translated "魔王" as "Demon King" maintaining fantasy terminology
- Preserved Japanese honorifics (-sama, -kun) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "Fuhahahaha" for ふははははは)
- Translated explicit actions literally ("deep kiss", "tongue insertion")
- Maintained musical term "Der Erlkönig" for cultural accuracy
- Rendered sexual descriptions without euphemisms ("bulge", "no bra")