## 281. Sairei Festival Day ⑥ ~The Beautiful Battle~

"Now, finally—the Mr. & Miss Contest featuring Sairei Academy's male and female students!"

Waaah—cheers erupted.

Twenty-one girls selected from regular and physical education classes across three grades, dressed in male attire.

Alongside them appeared fifteen boys in female attire—five from each grade.

Being a contest, judges were present: randomly selected guests, faculty, and invitees from various age groups, comprising 2 males and 48 females for a total of fifty.

For this event alone, front-row seats were secured for proper viewing.

First came first-year girls, followed by first-year boys in sequence.

Attire was free, but since this wasn't cosplay, participants prepared their own moderately flashy outfits.

Still, as this was a special stage representing their classes, friends and families had collaborated to create elaborate costumes.

Hearing the opening announcement, Yuu rushed over without changing and observed from an inconspicuous wing position, concealed by his cape.

Surrounding Yuu were not just Nana, Ruriko, Vanessa, and Yuri, but numerous girls forming a human wall.

The first cross-dressing girl appeared in dark gray suit with crimson tie.

Shoulder-length hair slicked back with styling gel. Square black-framed glasses.

She seemed about 180cm tall, and likely from a sports club—more masculine than average boys.

Yet to Yuu's eyes, she didn't fully carry the suit—at best resembling a job-hunting student.

Still, perhaps due to good material, her male attire looked quite dashing.

Subsequent cross-dressing girls ranged from casual wear to sportswear. Being contest selections, all had excellent faces and figures. Hair was either short or cleverly styled with gel to appear inconspicuous.

Contestants walked to the extended runway's end, struck poses matching their outfits to appeal, then returned.

Despite knowing they were girls, the audience cheered: "Cool!" "Awesome!"

Next came the cross-dressing boys.

Made up with wigs and skirts for femininity, but their unladylike walks were part of the charm.

Now each received cries of: "Cute!" "Pretty!"

By the fourth boy, Yuu could only see them as merely pretty okama, struggling to suppress laughter internally.

*(Just pretty okama...)*

"Now, closing the first-year segment—Higashino Reina-chan!"

When introducing names, male-attired girls received masculine versions (e.g., Youko → Youji). Conversely, female-attired boys got girlish names.

Had Yuu participated, he might've been called Yuuko or Yuuna.

Since Rei was first-years' finale, he became "Reina."

From the wing opposite Yuu, a petite girl emerged.

Flaxen-colored? Voluminous light-brown hair reaching mid-back.

Navy ribbon worn vertically like a headband, bow-ends standing like rabbit ears.

Light blue/white apron dress.

Skirt hem below knees, white knee-high socks, navy shoes matching the ribbon.

Perhaps Alice in Wonderland-inspired.

Unlike previous cross-dressing boys, minimal makeup was visible from Yuu's position—barely noticeable pink rouge on lips.

With light makeup, she looked unmistakably like a young teen girl.

Possibly nervous, Rei kept his gaze slightly lowered until midway. Yuu waved encouragingly.

Noticing this, Rei smiled faintly.

He resembled his sister Satomi.

Yuu recalled mistaking cross-dressed Rei for Satomi during a past home visit.

Rei naturally had an androgynous, girlish face.

Until middle school, he'd cross-dress for family outings without ever being caught.

Even Yuu had been fooled up close.

Everyone seeing Rei's cross-dressed form for the first time was stunned.

As Rei began walking steadily down the extended runway, the silent audience erupted.

"Wh-what is this... sh-she's too cute!"  
"First-year Higashino-kun? I knew he was cuter than average girls but..."  
"Cl-close up... I want to adore her! Protect her!"

At the runway's end, Rei pinched his skirt for a curtsy—forward, left, and right. Well-practiced and graceful.

"Reina-chaaan!"

Yellow cheers (high-pitched) showered him. Rei smiled and waved lightly.

One girl got a nosebleed from excitement over his cuteness.

"Cute" seemed absolute justice even for women.

Amid roaring cheers, Rei flushed crimson, pivoted on his heel, and skipped back.

Elbows bent, hands lightly raised—the skip was pure natural-born girl.

His skirt fluttered up with the light motion, revealing knees and thighs but no leg hair.

He'd meticulously groomed even hard-to-see areas.

Next came second and third years.

Higher grades showed slightly more refinement in both cross-dressing categories.

Still, while several male-attired girls passed as beautiful boys/handsome men, the female-attired boys couldn't shake their okama aura.

Rei remained the exception. Becoming the opposite sex required altering posture and mannerisms—practice mattered.

Finally, the last third-year male-attired contestant.

The announcement declared her name.

"Everyone—your long-awaited Komatsu Sayato-san! Student council president until September!"

Waaah! The gymnasium shook with cheers.

Sayaka, defeated by class-wide pressure to participate again this year.

At first glance, a standard school uniform.

Cap tilted low, torn at front, covering one eye.

Black cloak over open gakuran. Geta clogs.

Long black hair deliberately messy.

The "bankara" (delinquent) style rarely seen outside cheer squads.

The proper ex-student council president playing gang leader felt refreshing.

Sayaka's bust—larger than average—was unnoticeable, likely tightly bound with sarashi.

Onstage, Sayaka seemed resolved.

She strode majestically, geta clacking loudly, drawing cheers rivaling Rei's.

But Sayaka didn't smile—only sharp eyes ahead.

The audience adored her coolness.

"Kyaa! Sayato-saan! Awesome!"  
"Hug me! Let me hug you!"  
"Ahh... stared at like that... I'm getting wet!"

Fascinating contrast.

Sayaka—usually dignified and pure—now embodied a magnificent gentleman.

Perhaps her family's dojo and childhood martial arts training contributed.

She radiated a gang leader's tension before a duel.

Though lacking wildness for bankara and overly pretty, she captivated all genders.

At the runway's end, Sayaka drew her sword.

The blade gleamed under lights.

Surely a replica, but her stance was masterful.

Stationary, she performed an exquisite sword dance before leaving.

Her retreating back received thunderous applause.

After a 10-minute judging break, all contestants lined up onstage in appearance order.

Male-attired girls and female-attired boys formed an impressive lineup.

"Now—results time!"

The announcement electrified the gymnasium.

Mr. category (male attire) first: third place announced upward.

Second place went to a third-year PE representative, third to a second-year.

The winner... as predicted: Sayaka.

Moreover, she secured 20 of 50 votes—10 votes ahead of second place.

"Sayato" chants erupted for her consecutive win.

"For the presenter—Demon King Yuu-sama watching from the wings!"

His surprise reappearance intensified the excitement.

Though requested as executive committee chair, no time remained to change—he'd present in demon king cosplay.

Yuu resigned himself—audience joy mattered most.

Taking the medal from the committee member, Yuu approached center stage.

He stopped before a sturdy second-year girl in judo uniform.

"Congratulations."  
"Th-thank... you, sir!"

As she bowed her headband-wrapped head, Yuu placed the bronze medal around her neck.

Yuu offered a handshake, but she stood rigidly at attention, gaze averted.

Already overwhelmed by Yuu's proximity during the medal placement.

Smiling, Yuu extended his hand. Contact finally registered—she nodded repeatedly while shaking hands.

Next, the second-place third-year wore ultra-short hair with short-sleeved shirt and shorts.

Over 10cm shorter than Yuu, she resembled an old-anime boy—likely aiming for shota appeal.

Probably from the track club.

Yuu placed the silver medal as she bowed slightly—this handshake went smoothly.

Finally, facing Sayaka for the gold medal, Yuu found her cap pulled low, avoiding eye contact.

"Sayaka?"  
"E-embarrassing... being seen by Yuu-kun."

Her tension gone, normalcy returned with shyness.

Like a cross-dressed man embarrassed before his lover in Yuu's original world.

But Yuu found this Sayaka adorable too.

"I love cross-dressed Sayaka—dashing and beautiful."  
"Eh..."

Blushing crimson, Sayaka glanced at Yuu. Struck by her charm, Yuu barely resisted hugging her.

Instead, without waiting for her bow, he leaned close—nearly touching—and placed the gold medal.

Next: Miss category (female attire) results.

Votes split below second place. Two third-years tied second with 5 votes each—one being Ichijo Koki in sexy dress. Handsome origins clearly helped.

Then Rei won overwhelmingly with 28 votes—over half.

"Congratulations, Rei. Impressive."  
"Nah... never expected... to win."  
"Big brooo! Congrats! Knew you'd win!"

Still blushing during Yuu's medal placement and handshake, Rei heard an especially loud voice.

Likely his sister Satomi attending as family.

"Wave to Satomi-chan and everyone."  
"O-okay."

Even on this glorious stage, his timid demeanor suited the cross-dressed look.

Yuu gripped Rei's left hand, facing the audience, and raised it. Rei managed a smile and small right-hand wave.

"Reina-chan" chants erupted again.

"Ahh... kinda tired."  
"Yuu-kun, great work!"  
"Ah... but must return to HQ."  
"Rest while changing?"  
"Hmm... shouldn't impose."  
"Thanks to popular afternoon events, spectators are behaving calmly."  
"Then I'll accept your kindness."

Back in the dressing room, urged by student council members like Emi, Sawa, and Kiriko, Yuu rested briefly.

Yoshie and Nana stayed beside him.

Yuu noticed Yoshie's hesitant demeanor.

"Speak freely," he prompted, but she remained silent.

So Yuu took Yoshie's hand and stood.

Still uncostumed, he enveloped her in his cape.

"Ah! Yuu-kun?"  
"Now others won't hear. Speak?"

Inside the cape, their foreheads touched.

Yoshie's sweet scent filled the enclosed space.

Frontal contact flushed Yoshie's cheeks instantly.

Even in darkness, Yuu saw her eyelids flutter behind glasses.

"U-um... but... you're resting—"  
"Just say it."  
"Uhh... well..."

Yoshie explained: Class 1-5's last-shift members were planning something in the gymnasium's upper storage room.

If Yuu was free post-event, they wanted him brought there.

Class 1-5 ran the children's festival grounds.

During patrols, Yuu avoided interrupting the children, observing from afar.

Today, apart from Yoshie and Nana, he hadn't spoken to Class 1-5.

Visiting them seemed good.

He also wondered about their plan.

"Okay. Let's go."  
"Eh... really?"

As Yoshie looked up, Yuu impulsively covered her lips.

Realizing she was kissed, Yoshie's eyes widened—but she accepted it, wrapping her arms around him.

Kissing cape-concealed amid others—this thrill fueled fierce, lustful kissing until Nana slipped in.

"Brother, me too?"

Silently, Yuu pulled Nana right and Yoshie left, kissing them alternately.

Later, supporting the limp pair, Yuu excused himself—"Heading upstairs briefly"—and left the dressing room.

---

### Author's Afterword

Hayakawa Ayumu (track club second-year from the curry stall) could've passed male-attired—or even normally—but apparently had no participation plans.

With too many characters, even I sometimes confuse the girls' appearances.

I'd forgotten Yoshie wore glasses—added that detail.

She's meant to be my preferred type: glasses-wearing committee chair with long black hair half-up... yet I forgot.  


### Chapter Translation Notes
- Translated "男装" as "male attire" and "女装" as "female attire" to maintain gender-reversal context clarity
- Rendered "オカマ" as "okama" (cultural term for effeminate men) with contextual explanation
- Preserved "bankara" (delinquent style) and "sarashi" (binding cloth) as culturally specific terms
- Translated "黄色い声援" as "yellow cheers" (Japanese idiom for high-pitched female cheers)
- Kept "gakuran" (male uniform) and "geta" (wooden clogs) as culturally authentic terms
- Maintained Japanese honorifics (-kun, -chan) and name order per style rules
- Transliterated sound effects: "Waaah" (わぁぁぁ), "Soree!" (そーれ)
- Italicized internal monologues: *(Just pretty okama...)*
- Used explicit terminology for intimate scenes per fixed style guidelines
- Preserved contest aliases "Reina" (Rei) and "Sayato" (Sayaka) as in-world constructs