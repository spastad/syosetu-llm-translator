## 282. Sairei Festival Day 7 ~Nameless Buttocks~

### Author's Preface

This situation is rarely seen in chastity reversal novels.

While considering whether I could implement ideas suggested in the comments section, I happened to introduce a character who might conceive such a plan, so I incorporated it at this timing.

---

The students of Class 1-5 became close with Yuu through club visits right after enrollment, followed by the Newcomer Welcome Orienteering and sports festival. Now, he has physical relationships with half the class, resulting in nine pregnancies. 

Since being designated as a Specific Priority Class, Yuu regularly visits the classroom, interacting intimately even with previously unacquainted girls through conversation and touch. 

It's only natural that Yuu's chest swells with anticipation knowing these girls planned an event for him.

Accompanied by Yoshie and Nana, Yuu ascended the gymnasium stairs to the table tennis and badminton practice area. He recalled deepening bonds with eight Class 1-5 girls in this very storage room after May's sports festival. The experience of intimately touching multiple girls in bloomers in the darkness remained unforgettable.

"Ah, Yuu-kun!"  
"Y-you came!?"

Hiyama Yoko and Aki Kazumi greeted him, their faces instantly lighting up as they rushed toward him upon spotting Yuu. Both were among the first in Class 1-5 to get pregnant, now around five months along—though their tracksuits concealed any visible baby bumps. Taking advantage of the absent classmates, Yuu stretched both arms to embrace them.

"Yoko, Kazumi. Good work. Has Class 1-5 already cleared out?"  
"Still tidying up, but..."  
"The big items are mostly done."

Pressed against Yuu from both sides, the two answered with delighted expressions. Their children's festival booth had an early closing time, and they'd apparently started cleaning up as the boys' gym events ended. Yoshie cleared her throat with a "Ahem."

"We asked you here during their break, so let's show him quickly."  
"R-right."  
"Sorry, Yuu-kun."  
"Ah, well, it's fine. I'm just curious about what kind of event you planned."  
"That's a surprise for after you enter."  
"Honestly, I'm amazed they came up with such an idea."

Surrounded front and back, Yuu walked toward the storage room. Yoshie and Nana, having been stationed at headquarters as student council members, seemed unaware of the details. Kazumi's muttered comment—"I can't believe they thought of something like that"—lingered in his mind.

"Yuu-kun, you can go in now."  
"Ah, yeah. I'm heading in."

Yoko entered first, apparently informing classmates inside of Yuu's arrival. Cheers echoed—likely from five or six girls. When only Yoko reemerged, Yuu slipped through the slightly opened door. Yoko, Kazumi, Yoshie, and Nana seemed to be guarding the entrance against other students.

"A wall? Wha—!?"

The normally spacious storage area felt cramped due to a 2m high, 3m wide wall installed immediately to the right. But that wasn't all. Three lower bodies protruded through the middle of this plywood wall—likely made from two stacked panels—positioned butt-up with slight spacing between them. All wore Sairei uniforms, their pleated skirts raised to expose thighs, feet flat on the floor.

*(A wall-butt situation!?)*

Yuu internally screamed. It mirrored erotic game scenarios where girls get stuck waist-deep in walls, vulnerable to assault from front or back. He never imagined encountering it in reality.

Upon closer inspection, the plywood was covered with evenly drawn flowers, animals, and anime characters—likely used for the festival booth. A B4 sheet taped to the center read:

『To Yuu-kun. This is a game.  
Identify who the three selected Class 1-5 members are using only their lower bodies.  
You may do anything. Please test them to your heart's content.  
The reward comes if you guess correctly!』

The situation itself felt like the reward rather than any "prize" for guessing.

"Okay. I'm game! First, let me observe carefully."

Yuu approached the three, examining them in turn. Cloth stuffed into the plywood holes around their waists prevented stomach discomfort while immobilizing them—leaving them unaware of Yuu's actions.

Yuu resisted immediately flipping up their skirts. Peeking underneath excited him more.

Only one dim fluorescent bulb lit the room. Though shadowed, he could discern underwear colors and patterns. He started with the left girl, drawn to her large, pale buttocks and plump thighs. Her legs were slightly spread.

"Black. Erotic."

Crouching directly behind her, Yuu looked up to see black see-through lace panties. Though shadowed, her pale skin showed through the thin lace covering her ample buttocks. Plump thighs extended from her groin—tempting him to squeeze them between his cheeks. Yet her slender legs tapered to tightly cinched ankles in navy knee-high socks.

"Oh?"

While enjoying the soft flesh of her thighs with both hands, Yuu noticed something when looking up at her crotch. Black fabric covered her intimate area. Lifting her skirt with one hand for a better view, he saw floral patterns on the lace—but her large buttocks revealed mostly skin tone, and the crotch appeared strangely wedged. When he brought his face closer, a familiar feminine scent hit him. As his left hand savored the pliant softness of her thigh, his right rested on her upper buttock. Then, with his middle finger extended forward, he slowly lowered it.

"Nfuooh!"

A voice came from beyond the wall as Yuu touched her. His finger passed the anal dimple toward her pussy slit. It was already moist—his finger sank in and didn't rebound. Stopping at her vaginal entrance, he rubbed with his fingertip, producing sticky *guchi guchi* sounds.

"Already wet? What a naughty girl."  
"...! O-... kufu... nn, nnn!"

Yuu rubbed her slit with his middle finger. She seemed determined to stay silent but moans escaped at his caresses. Seeing a vertical stain form on her crotch, Yuu temporarily stopped. Based on buttock size, three candidates came to mind: Gotou Mashiro, Naname Saya, or Randou Yorika. Height suggested the first two, but identifying from lower bodies proved unexpectedly difficult.

Moving to the right girl, Yuu noticed thick boards under her straightened feet—indicating her smaller stature.

"First... let me see what underwear you're wearing?"

Approaching from behind, he crouched to peer under her skirt, feeling like a pervert. Her slender legs gave a delicate impression. White panties with scattered bunny prints covered her small buttocks—a childish style unexpected for a high schooler. But it worked.

As Yuu stroked her legs, she trembled slightly but stayed silent. Her thighs had pleasant, plump firmness rather than voluptuous softness, with smooth skin. Slowly raising both hands to her skirt hem, he lifted it to observe her panty-covered buttocks.

"Such cute buttocks."

The comment slipped out. She seemed more elementary or middle school-aged. Three Class 1-5 girls fit that impression. Maegashira Yuma and Yoshihara Makie were possibilities—Nana was guarding the door. Yuu stroked and kneaded her buttocks, but she remained silent, fueling his mischief.

His left hand crept up her inner thigh—a ticklish spot—with three fingers. Still no sound; she endured. So Yuu positioned his right middle finger on her pussy slit while running his tongue along her inner thigh.

*Rub rub rub rub... Lick lick lick lick...*

"Hih, hii! Nn, nmu... uk... nn! Fumyu... nnn!"

After repeated rubbing, high-pitched moans escaped. Simultaneously, his fingertip grew wet. Pinpointing her clitoris, he vibrated his middle finger rapidly like a pink vibrator. Then, releasing his mouth, he hooked his left fingers under her panty sides and lifted—creating a makeshift thong.

"Hya... yah...n...nn, uwa... aan, no... shu..."  
"Such a cute voice. But more later."

Seeing the stain where his finger had been, Yuu paused. Though wanting to continue, the center girl remained. After kissing the exposed buttock, he stood and moved center.

The center girl's legs matched the left girl's length but were extremely slender. Crouching behind her, Yuu peered underneath. Sensing him, she fidgeted slightly. Though aware of Yuu behind her, the wall blocked his actions and expressions—perhaps mixing anticipation with anxiety.

His gaze traveled up her thin legs to slim buttocks with visible hip bones, covered by plain white panties. Few Sairei girls wore pure white. Since visiting Class 1-5, girls he'd been intimate with showed their daily underwear as greetings—flashing them by lifting skirts. Their choices were colorful and elaborate.

Her legs below the knees looked fragile enough to snap. Though pressed together, her thighs had gaps from lack of flesh—making Yuu wonder if she ate properly.

"Who could this be? No idea."

He genuinely muttered, not joking. Many Class 1-5 girls were slender, but legs alone gave no clues.

Over several minutes, he thoroughly touched her thighs and buttocks. Extremely patient, she made no sound. Even fingering her through the panties didn't moisten her like the others.

"Now I'll touch you directly, okay?"

Getting no response, Yuu interpreted silence as consent. Standing behind her, he spoke. When he removed their panties, the left and right girls had strings of love juice stretching from their crotches—but the center girl showed no wetness, her labia tightly closed.

*(Could she be...?)*

Suspicion arose. Was the center girl a virgin? Or hard to arouse? That only made him determined to pleasure her.

With less than 50cm between them, Yuu could stimulate all three simultaneously. Kneeling directly behind the center girl, he reached left and right. The voluptuous left girl's pubic area had thick black pubic hair—his left finger elicited a *kuchu* sound of pleasure just grazing it. In contrast, the right girl was hairless. His right finger found her already wet.

"Nfuooh!"  
"Hya! Mugu..."

Both gasped when touched but quickly silenced. Yuu brought his face to the center girl's groin. The scent was mild—feminine skin and soap. As his tongue approached her still-closed vulva:

*Lick, chuu, chupa, chupa, churu! Churururu! Juru, chupon!*

"Ohi! Finger, feels so gooood! Aah, aaah, more! Deeep... oonn!"  
"Nnnnn~~~~~~! Aah! Ngu... hyan! There, no... stoh... nmu"  
"...nn, nna... fum! Un! A... aah, nn!"

Rubbing clitorises and thrusting fingers made the left and right girls moan louder. Their love juices played wet symphonies.

The center girl also began gasping as Yuu performed cunnilingus. When his tongue touched, she jerked and tried pulling back—but her hip bones caught. She couldn't stop his tongue prying open her tight labia. As he licked around her vaginal entrance and clitoris, love juices seeped out with watery sounds. Resigned, she surrendered to Yuu, emitting soft moans.

"Foh! Iin! Body stuck in wall, pussy played with... this situation's irresistible! Ooh! Cumming, cumming, cumming! Aaah! Sho... sho... good... ra... me... oho! Cumming!"

The left girl abandoned restraint, moaning unrestrainedly. Though unseen, she ejaculated so forcefully that puddles formed around her spread legs. After a final full-body shudder, Yuu pulled two dripping fingers from her vagina.

Next, the right girl neared climax. Muffled sounds suggested she covered her mouth. When Yuu toyed with her clitoris, her small buttocks jumped. Crossing index and middle fingers, he attempted penetration. Sufficiently wet and relaxed, her vagina swallowed his fingers and clenched.

Starting slow, then thrusting vigorously as lubrication increased:

"Nn, nuwaa! Aah, hiin! Yah! Don't... pound... so... deep... suu... ann! Ann! I'll... cum! Aaan! No... shu... a, a, a, cumming! Nmu! Nnn! N~~~~~~! Ihyu... nnnn! ...Cu... cumming... taah!"

Hearing her cute climax, Yuu continued cunnilingus on the center girl. Using his freed left hand, he peeled back her clitoral hood for delicate rubbing. His tongue meticulously licked around her vaginal entrance, sucking juices. She was more responsive but needed time to climax.

Yuu stood up, pausing. His erection strained painfully against tight slim-fit pants. After adjusting earlier, intercourse seemed inevitable now. Unzipping, he lowered his pants and briefs together. His freed cock sprang up vigorously.

"Now then, who first?"

Hearing his murmur, the left girl spread her legs invitingly—rising onto tiptoes in a wide stance. Her freshly orgasmed pussy visibly twitched with desire.  


### Chapter Translation Notes
- Translated "壁尻" as "wall-butt situation" to convey the erotic game scenario where girls are immobilized waist-deep in a wall
- Rendered explicit anatomical terms directly ("pussy," "clitoris," "labia") per style guidelines
- Preserved Japanese honorifics (-kun) and name order (e.g., Hiyama Yoko)
- Transliterated sound effects (e.g., "guchi guchi" for ぐりぐり, "kuchu" for くちゅ)
- Translated sexual acts without euphemisms ("cunnilingus," "ejaculated")
- Maintained game instruction formatting with single quotes as per original text structure
- Translated "パイパンマンコ" as "hairless" to convey the explicit meaning of pubic hair absence
- Used "love juices" for 愛液 (aibyō) to balance clinical accuracy with narrative flow