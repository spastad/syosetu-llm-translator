## 283. Sairei Festival Day 8 ~Unforgivable Round Buttocks~

"Oooh! Nnghoo! Sh-shugoi! Yuu-tan's cock is amazing after all! Aahh! Aahh! N-no... kuhfoo! Aauu aauu... I can't, I can't anymore, I'm cummiiiiing!"

"Ooh... Though you have big buttocks, your pussy inside is tight and constricting. What a good cunt!"

When Yuu chose the left girl, he didn't thrust vigorously from the start. Rather, to savor the first girl's vaginal interior, he used slow strokes.

Since only their lower bodies protruded through the wall in this wall-butt state, unfortunately he couldn't swing his hips while groping breasts. Instead, he gripped both buttocks with fingers digging in. He spread the buttocks wide while inserting, hitting deep with a *clunk*. When pulling out, he went slowly until nearly withdrawn. He could feel the inner folds clinging as if reluctant to part.

Occasionally, he thrust shallowly in rapid movements when fully inserted, or ground his hips. Though only about three minutes had passed since insertion, his partner was moaning excessively. Well, since she'd shown the strongest reactions among the three, this was expected. Despite the strong constriction, the interior was thoroughly drenched, making movement easy while providing intense pleasure that tempted him to speed up his hip movements.

This time, he slammed his hips forcefully with *bachun bachun* sounds that distorted the buttock shape, gouging deep into her vaginal depths.

"Are you cumming already? Here, how about this?"  
"Hyaa! Tonton no! I-I'm too weak! Ahhn ahhn ahhn! Cumming, cumming, oho! Already... Yuu-tan's... fucking me... no! My... pussy is being trained! Fah! Yuu-tan, Yuu-tan! Oooh... kuhh~~iihhyiiin..."

She seemed to have reached climax. Though Yuu wanted to continue until ejaculation, two others remained. After stroking her buttocks and saying "That felt good," Yuu withdrew his cock.

Next, Yuu looked at the remaining two buttocks. Passing the center one, he chose the right girl. He pressed his still-wet cock against the small round buttocks' cleft. He felt her shiver slightly.

"Spread your legs wider. I'm inserting now."  
She obediently spread her legs wider than shoulder-width at Yuu's command. Though she ended up on tiptoes, Yuu firmly gripped her hips for support. Though not in his view, her closed vulva had slightly opened. Yuu pulled his hips back, positioned the tip, lightly pressed against the vaginal entrance to sink the glans in, and with a *nup* sound, overflowing nectar dripped down her thighs. Yuu gripped the small buttocks with both hands and gradually pushed his hips forward. His rock-hard cock was swallowed into the soft vaginal interior.

But immediately, he met fleshy resistance as if being pushed back.

"Ugh... ah, ah, ah! I-it's going in!"  
"Ooh... tight. But—"

Moving both hands from buttocks to waist, Yuu firmly gripped her and continued insertion with hip strength. Perhaps due to her petite frame, her small pussy was physically narrow, almost virgin-like tightness. But she should have experience receiving Yuu's cock. Without forcing further, Yuu moved his hips in small motions to gradually acclimate her. Before he knew it, it slid in *nyurun* to full depth.

"Hyaun! Kah... ah, ah, ah, inside me... Yuu-kun's, cock... is in... muh... nn! Mmm~ no! I can't hold back my voice! Ahh, it's been so long... with Yuu-kun's... cock... filling me... ahhaa..."  
"Haa~ This pussy feels too good."

Even without her words, he could tell her body—or rather her lower mouth—was delighted. The vaginal interior tightly constricted, and even without movement, the folds undulated, feeling immensely pleasurable. From his crotch to lower body and back, tingling pleasure spread.

Compared to the left girl, the love juice seemed less abundant, but now it dripped like cow saliva. He felt it wasteful that the vaginal depth was shallow, preventing full insertion.

*If I move, I'll cum too.*  
Though driven by this thought, he couldn't stop moving. Gripping her slender waist with both hands, Yuu began swinging his hips.

"Hii... nn! Ah, ah, ah... ya... it's going... deep... ann! No, it's feeling too good... I'm becoming... ann! Aahn! Your cock is... amazing... it's coming deep inside!"  
"Kuhu... hips won't stop. Feels good! Wh...whoever you are, this tight-tight pussy is great!"

Though Yuu had guesses about who was left and right, he saved confirmation for later. For now, he thrust into the buttocks protruding from the wall, swinging his hips to savor their vaginal interiors. He'd intended to just sample them before going to the center girl last. But he couldn't seem to stop before ejaculating. His male instincts desperately craved to pour out his seed.

With powerful *zun zun* strokes, Yuu drove into her. Each time, the small buttocks lifted, and her tiptoed feet shook violently. Inside her vagina, she seemed to receive constant *gori gori* stimulation on her cervix, her moans rising in pitch. Meanwhile, Yuu also received stimulation as if his glans were being sucked open and squeezed deep inside, finally reaching his limit.

"Kuh... can't hold back! I-I'm cumming! Aah! Cumming!"  
"Hya! Wai... nyaa! Aah... iih... hyiin! N-no... aah! Aah! Aaaaaaahhhhhhh! Kyahi! It's... coming... uuun..."

Thick, hot semen flooded into her womb in massive quantities. She let out a long moan without restraint. Her legs stiffened and trembled immediately after—she must have climaxed too. Yuu lowered his upper body, pressing his head against the wall, wrapping his arms around her stomach to hug her tightly. He remained in that position until completely spent.

Though he wanted to stay connected after ejaculating, he couldn't. One more remained. Moreover, he had no idea who it was. He had to identify someone he'd never had sex with by only their lower body. This was a difficult problem.

He pressed his hips against the center girl's buttocks—a so-called sumata position. It felt slippery and pleasant. Though he'd heard restrained moans when cunnilingus earlier, he didn't recognize the voice.

"Huff... huff... nn!"  
"You can feel my cock touching you, right?"  
"Nn... I can."  
"I'm inserting this into your vagina now. Probably your first time?"  
"Y-yes."

Yuu tried conversing, but she spoke little and it wasn't helpful. Surely, she wasn't the type to initiate conversations with Yuu—reserved and quiet. Moreover, among the extremely slender girls, he vaguely remembered one but couldn't be sure. Even Yuu couldn't remember all of Class 5's full names. He remembered those he'd been intimate with, but not girls he'd barely spoken to.

He had her spread her legs wider beforehand. Peering into the opened vulva, it was a clean salmon pink, slippery and wet. A small vaginal opening was visible inside. Though questionable for a first experience to be doggystyle through a wall, this situation still aroused him as a man. Despite having ejaculated once, Yuu's cock stood rigidly hard for this virgin girl. He wanted to taste her vaginal interior quickly.

"Here I go."  
No response came—she stayed still. As usual, Yuu positioned his cock tip and tried inserting.

"Nn!?"  
Only about half the glans entered. Virgins unused to receiving male members were indeed difficult to penetrate... Yuu applied more hip strength. He seemed to hit something like a thin membrane but continued pushing through. He felt something *buchi* tear.

"Higii! Aah... iih!"  
"Eh... could it be?"

Virginity rates were high among this world's high school girls, but their high libido meant many masturbated—probably comparable to boys in his previous life. Also, he recalled health classes recommending breaking one's own hymen beforehand for smoother first-time penetration. Still, not everyone did so. For Yuu, who'd taken many virgins, this was his first time breaking a hymen in a while.

"A-are you okay?"  
"Iih... hurts, but I'm okay... so..."  
"Understood."

In such cases, continuing was better than stopping. Gripping the rarely seen slender waist, Yuu tried to continue insertion... Perhaps due to her slim build. It was simply tight and narrow. Though wet inside, it was physically constricted and wouldn't go in easily.

"Uwaa! Nn... iih..."  
"Sorry, bear with it a little longer."

Each *guri guri* push brought pain to his cock tip. For Yuu, it was pain mixed with pleasure, only fueling his arousal. She might have been covering her mouth to suppress sounds, but sobs still leaked out.

As he moved in small motions, he gradually felt progress. Like forcing his body through a narrow crevasse.

"Ooh!"  
"Kyaa!"

Finally, he achieved full insertion. It felt like a long time, but perhaps not much had actually passed.

"Aah... dangerous..."  
"Hah, hah... it's in!? Th-this..."

The post-insertion pleasure was as intense as pre-ejaculation. Numbing ecstasy shot through Yuu's body like electricity, beyond words. Simultaneously, his desire to ejaculate inside this vagina intensified. He should have stayed still to let her adjust, but instinct made his hips move unconsciously.

"Ugh, oh, ooh..."  
"Hii... aah... aeh..."

Beyond words now. Purely bestial. Like a virgin experiencing his first time. Yuu thrust mindlessly. Though he could barely move inside, the friction—painful yet pleasurable—intensified the ecstasy. His mind was dominated by the desire to pour his seed into this unknown virgin high school girl's vagina.

"Bad... this is... ah, ah, ah, cumming, cumming!"  
"Hahi, hahi, iih, iih, hyiin!"

Before long, both Yuu and she were drenched in sweat. Gripping her slender waist tightly to prevent slipping, she could only accept Yuu's *zun zun* hip impacts. The end came almost abruptly.

"Kuh!"  
"Hyaa!"

With *dokun dokun* force that seemed to take his hips with it, semen gushed out. Each spurt made her lower body twitch *bikun bikun*. He ejaculated as much as the first time, if not more. Though Yuu usually aimed for sex where he could fully feel his partner and climax together, this time he had no composure—just instinct-driven, one-sided ejaculation.

After the long ejaculation ended, he slowly pulled out his cock while feeling drained. Soon, cloudy fluid flowed back from her vagina, oozing out. Yuu watched as pink-tinged fluid mixed with defloration blood dripped down.

"Yuu-kun!" "Yuu-kun!" "Yuu-kun!"  
Called from beyond the wall, Yuu snapped back to reality. He felt something like guilt for what felt like assault. But for them, creampies were enthusiastically welcomed.

"Shall we check answers?"  
"Ah, yeah."  
Yuu reached out to stroke both left and right buttocks. Both twitched slightly at his touch.

"From my view, left is (Naname) Saya. And right is (Yoshihara) Makie, right?"  
"Correct! Then who's the center?"  
"Hmm... no idea."

Saya and Makie were easy from speech and physique. But the center girl remained unidentifiable till the end—he had to surrender.

"Right? You wouldn't know after all."  
"Sacchan never talked with Yuu-kun, right?"  
"Ha... un."

Sacchan—the girl called this still seemed breathless. Her full name was Fukumoto Sachiko. Though auspicious-sounding, Yuu had no memory of it.

"Unfortunately, not a perfect score."  
"But you got two right!"  
"Yeah."

"Hey hey, what reward do you want? Ufufu."  
"What else but..."

The suggestive laughter from beyond the wall sounded familiar. Apparently, the other girls besides the three wall-butts wanted to continue playing.

While penetrating Saya on the left, Yuu had noticed another hole beside her. Even conveniently labeled "↓ For Yuu-kun ♡". This was clearly the expected pattern.

With his lower body still exposed, Yuu moved before this hole. His cock, having ejaculated twice, was semi-erect. He inserted it and said:

"Suck it."  
"Yes!""Yes!""Yes!"  
"Wawa! This is... Yuu-kun's!?"

Apparently, four others besides the three wall-butts were beyond the wall. Immediately, three hands touched Yuu's cock. Another timidly touched with fingertips. Like Sachiko, they seemed to be seeing it for the first time.

Though his cock was wet with three girls' love juices, semen, and sweat, no one minded as they competitively touched. Multiple tongues joined in, quickly reviving his cock.

"Chu, chu, churochuro... nfu! Your cock's revived!"  
"Ahaa... it smells lewd... anmu, leroleroloo"  
"Really, how did something this big fit inside? Ah, I want it inside me too."  
"Th-this magnificent... and hard..."  
"Ooh, good. Feels so good."

From glans to coronal ridge, shaft to base. Even testicles—tongues and fingers roamed everywhere. The reverse of earlier. Four unknown girls beyond the wall caressed every part of his cock. Sometimes this was nice too. Not seeing them heightened anticipation of what might happen next.

"Ufufu. Something came out."  
"Twitching. Your cock feels good, huh?"  
"Is it okay to lick here?"  
"Let's lick together."

Suddenly, his glans was *pak* taken into a mouth. Inside, it was licked *pero pero*. The shaft was stroked by multiple hands. Both balls were simultaneously sucked by two mouths. Someone licked from coronal ridge to frenulum. With hands free, two reached through gaps to touch Yuu's buttocks.

"Kua! I-it's good! I'm already..."

Having ejaculated earlier, he'd been relaxed at first. Though not intensely stimulating, the genital-wide caresses from four girls brought unexpected pleasure.

"Nmoo, lero, erochu, jupu"  
"Chuu, chupa, juru"  
"Chu, lerolerolero... haa, haa, Yuu-kun, close? Cum lots for me"  
"Ug... nn, nna!"

Though visionless, he heard their sucking sounds beyond the wall—which aroused him further. Glans, shaft, balls—all felt so good that Yuu's patience vanished.

The girl sucking his glans pulled back and stimulated his urethral opening with her tongue tip. The stroking speed increased...

"Kua! I-I'm cumming!"

Arching his back and thrusting his hips forward, Yuu reached his limit.

Dopyu! Dopyu! Dopyuu!

"Waa!"  
"Feh!?"  
"An! Amazing"  
"It... came out... seeeemen"

Yuu's ejaculation drew surprised and delighted cries from all four.

---

### Author's Afterword

If we were doing wall-butts anyway, lining up over ten would've been luxurious. Class 5 girls could probably manage it, but since Yuu's handling it alone, three is just right. Instead, I tried having other girls give wall-cock blowjobs. Since Sachiko's first appearance, it was natural not to know her. I'll add some dialogue with her next chapter.

### Chapter Translation Notes
- Translated "壁尻" as "wall-butt" to describe the scenario where only buttocks protrude through wall openings
- Preserved speech quirks: "しゅごい" → "shugoi" (lisped version of "sugoi"), "拙者" → "this one" (archaic first-person)
- Translated explicit anatomical terms directly: "チンポ" → "cock", "マンコ" → "pussy"
- Transliterated sound effects: "ばちゅん" → "bachun", "ぬぷ" → "nup"
- Maintained Japanese honorifics: "祐たん" → "Yuu-tan", "祐君" → "Yuu-kun"
- Translated sexual acts without euphemisms: "中出し" → "creampie", "フェラ" → "blowjob"
- Preserved Japanese name order: "福本 幸子" → "Fukumoto Sachiko"