## 284. Sairei Festival Day 9 ~The Sky Beyond the Night~

In a world where male and female chastity concepts are reversed, sexually explicit 18+ content is exclusively targeted toward women, so naturally men become the subject matter.

Especially in erotic games, anime, manga, and doujinshi, content featuring unattainable rape scenarios has been created with rich variations.

While there are various situations for rape scenarios, the pattern of restraining men and gang-raping them is representative.

For example, incorporating various bondage techniques seen in SM is standard, but there are also scenarios involving operating tables, delivery beds, crucifixion, special machines, tentacles, slimes, and flesh walls.

Some scenarios involve a man embedded in a wall with his lower body invisible, being raped by unknown women while simultaneously receiving facesitting. Or being made to stand with the front of his body pressed against a thin wall, having his penis molested by women through holes.

Such situations are sometimes called "wall penis."

***

At the Sairei Festival, Class 1-5 responsible for the fairground events—children's games like lotteries, ring toss, and hoop throwing—wrapped up just before 4 PM and began cleanup.

That day, they had absolutely no opportunity to interact with Yuu.

Those who could see male students appearing in events at the gymnasium were still fortunate.

But those assigned to the late afternoon shift and cleanup cursed their own bad luck.

That's when they came up with an idea.

Coincidentally, classmates Aramaki Yoshie and Tsutsui Nana were student council officers.

Could they use that connection to arrange a meeting with Yuu if he had free time?

Preferably, they wanted to monopolize him alone.

Yuu had always visited Class 1-5's classroom, smiling and talking casually with everyone, showing familiarity through easy physical contact.

If they could meet him, they wanted direct physical intimacy and affectionate play.

Then Naname Saya, who was knowledgeable about erotic genres, had an epiphany.

They wanted Yuu to do the "wall penis" scenario, but he might dislike it. Even she could distinguish fiction from reality.

But conversely, what if they tried being "wall buttocks" themselves? Wouldn't Yuu react positively rather than coldly? After all, sex with Yuu was far more original and stimulating than cheap adult content.

Since those present were relatively quiet girls, no one stopped Saya's idea—or rather, her reckless impulse.

Aki Kazumi and Hiyama Yoko, who heard the idea, reluctantly agreed while promising cooperation—they were already pregnant with Yuu's child and had that leeway.

They suggested the storage room above the gymnasium would be perfect since few people went there.

They hastily processed plywood used for the fair and set it up.

The "wall buttocks" roles went to the proposer Saya, while the remaining two slots were decided by lottery.

The lucky winners were class representative Yoshihara Makie and Fukumoto Sachiko—the quietest, most inconspicuous, shadow-like presence in the class.

Regardless of Saya and Makie's experience with Yuu, Sachiko had barely spoken to Yuu before and couldn't even approach him.

Once, during break time when Yuu visited the classroom, they almost collided at the entrance.

At that time, Yuu apologized with "Gomen ne" and spoke to her, but Sachiko was too shocked and nervous to respond properly.

Sachiko fell into self-loathing over her suspicious behavior, but Yuu didn't mind, smiling while saying "Glad you're not hurt" and patting her shoulder. That incident left a strong impression on her.

They didn't know if Yuu would come.

But if he did come, surely he'd stroke their buttocks, right?

For Sachiko, since faces wouldn't be visible, no conversation would be needed—she could just leave everything to Yuu.

With that thought, she waited nervously, but she never imagined he'd lick her genitals and penetrate her right there.

***

After what seemed like a spectacular ejaculation, while the girls were squealing excitedly beyond the wall, they carefully wiped Yuu's cock clean.

Simultaneously, the wall was dismantled, and Yuu saw the girls.

The girls who had been "wall buttocks" seemed to have been leaning on a long desk in front of them.

Saya and Makie, who experienced being penetrated one-sidedly as "wall buttocks," wore extremely satisfied expressions while wiping their crotches.

As Yuu pulled up his pants and underwear, his concern was for Sachiko in the middle.

Her name suggested fortune, but she gave an impression of lacking it.

About 10cm shorter than Yuu, her hair was more like an old-fashioned bob than a short bob. Looking at her, he felt like he'd spoken with her before.

Sachiko tried to stand up, but her already slender legs wobbled precariously.

Right after losing her virginity, he recalled hearing that some people feel discomfort in their lower body and can barely walk.

The moment he thought "Ah," Yuu swiftly moved and caught Sachiko as she nearly collapsed.

"Are you okay?"

"Hya! Ha... eeeeeeh?"

"You were bleeding, right? Sorry for hurting you. I'll support you."

"W-w-w... I'm! Embarrassed... d-do something!? Aaah......"

"Huh?"

Sachiko's face turned apple-red, and she momentarily tried to pull away, but Yuu deliberately kept holding her. She seemed too unsteady.

In her agitation, her words seemed dialectical, but her intense fluster was evident from her expression.

Then Saya spoke up.

"Yu-tan, Yu-tan"

"Yeah?"

"I heard Sachi-sama was born in Tsugaru. She transferred here mid-junior high and has been self-conscious about her dialect."

The dialect from Aomori Prefecture's Tsugaru region at the northern tip of Honshu is strong and hard to understand when spoken plainly.

Her reserved personality, combined with dialect anxiety, might have made her even more withdrawn.

Still, she was smart enough to enter Sairei Academy and had good looks.

Though too thin for his liking, her fair skin was smooth and pleasant to touch.

"S-sorry... for troubling you."

Sachiko hung her head in Yuu's arms.

But Yuu didn't feel troubled at all—rather, he found it endearing.

Yuu stroked her jet-black hair.

Sachiko, who had tightly closed her eyes, opened them slightly as she felt the pleasant sensation.

"Sachiko"

"...!"

At Sairei Academy, no woman could remain unmoved when embraced by Yuu and called by name.

Sachiko's cheeks, previously flushed with shame, now heated with joy.

"I think it's fine"

"Eh?"

"No, girls with dialectical speech are rather cute, I think. So don't worry about it."

"Ah"

The moment Sachiko looked up, Yuu covered her small lips.

Belatedly realizing it, he embraced and kissed her gently while feeling gratitude toward Sachiko for offering her virginity.

As Sachiko floated in heavenly bliss, Yuu noticed the surrounding gazes after slightly separating from her.

""""Yuu-kun! Me too!""""

"O-oh"

Besides Sachiko, Saya, and Makie who had been "wall buttocks," four others had sucked him through the wall penis hole.

Kino Emiko, Maiya Irene, and Randou Yorika had already had physical relations with him. But Tomioka Yumi alone hadn't had such relations yet and had been excited seeing his cock for the first time today.

About 150cm tall and petite, with naturally curly short hair. Always bright and cheerful with a smiling face. She'd spoken with Yuu several times since he started visiting the classroom.

Yuu began embracing and kissing the four in turn.

Saya and the others who had been "wall buttocks" also pressed close to Yuu.

Amidst this, the door swung open.

"Yuu-kun! You need to return now!"

"Brother, the seniors are looking for you!"

What Yoko, Kazumi, Yoshie, and Nana saw was Yuu holding Sachiko and Yumi in his arms, while tall Irene and Yorika stroked his head and cheeks from behind.

Moreover, Saya, Makie, and Emiko had slipped between his legs, rubbing their cheeks against his crotch and buttocks.

Like ants swarming sweet candy, Yuu was not only pleased but also stimulated enough for his cock to swell up again.

However, finally realizing over an hour had passed, he hastily said goodbye and rushed out.

***

When Yuu returned to the operations headquarters, they were facing a troubling problem and discussing it.

Yuu apologized for being late and immediately joined the discussion.

They planned to have invited guests leave by 5:30 PM and begin preparing for the bonfire in the schoolyard as the after-party.

But reports indicated many women without invitations were loitering nearby, unable to give up.

Not just 100 or 200—possibly more.

So far, within the school, invited guests including those from sister schools had caused fewer problems than anticipated.

There were incidents of guests persistently trying to talk to male students, nearly causing arguments with female guards, and attempted intrusions into the second building used by male students, but nothing major.

That's why they wanted to conclude without major issues.

Considering what might happen if they proceeded with the after-party:

Would the uninvited women stay silent after seeing and hearing the fun in the schoolyard?

It was fully conceivable they might force their way in.

If it were just a few or a dozen, it might be manageable, but with over 100 or 200 people, security would be overwhelmed.

The executive committee members, including second and third-year boys, were almost unanimously leaning one way.

Only Yuu's decision remained.

Recognizing this, Yuu nodded.

"Understood. Cancel the after-party in the schoolyard. Instead, we'll hold the closing ceremony in the gymnasium and dismiss."

"""""Yes!"""""

"It can't be helped."

"That's best."

"Then let's make an announcement immediately."

"Wait. Maybe it's better if I say it."

Nana had already announced to guests that the festival was ending and they should leave the premises.

By now, security teams were probably sweeping the school to expel any remaining guests.

However, they hadn't started bonfire preparations yet.

『All students, we originally planned to hold the after-party in the schoolyard, but due to unavoidable circumstances, it has been canceled.』

From far away, disappointed voices of "Eeeeeh?!" could be heard.

But perhaps because Yuu was announcing it, there was no accusatory tone.

『Instead of the after-party, we will hold the closing ceremony in the gymnasium.

All students except security personnel, please gather in the gymnasium at 6:30 PM.』

Everyone was currently cleaning up, but completing it was impossible.

Full cleanup was scheduled for tomorrow.

***

The closing ceremony wasn't formal.

As executive committee chair, Yuu simply declared the Sairei Festival had ended without major issues and thanked all students and staff.

Since it was mealtime, they distributed light meals and drinks originally prepared for the after-party.

They also gathered leftover ingredients from stalls and food stands. It wasn't enough to fill everyone's stomachs, but it couldn't be helped.

"Now, to celebrate the success of the Sairei Festival, cheers!"

Following Sayaka, whom he asked to lead the toast, cheers rose everywhere.

It was a standing buffet with long tables arranged.

Here, boys joined female classes in groups of six per class to facilitate as much male-female interaction as possible.

From the podium, the ratio appeared about 1:6, but it was clear boys and girls mingled harmoniously.

Perhaps the festive atmosphere lingered.

Maybe it would spark some romances.

"Shall we go now?"

At Yuu's words, over twenty surrounding girls—student council, executive committee, and security team members—nodded.

They planned to deliver refreshments to the external security personnel and the security headquarters who kept guarding.

Some tried to stop Yuu when he insisted on going outside the gymnasium, but he wouldn't yield.

So to prevent Yuu from being seen externally, they surrounded him in a large group.

The refreshments were leftovers and cold canned drinks, but Yuu personally delivering them made the night-shift PE students and tough-looking security guards erupt in joy.

Yuu wasn't doing this for popularity.

They could enjoy themselves because people were diligently guarding them.

Originally, during his corporate days, he had no connection to promotions. He often handled inconspicuous tasks rather than flashy work.

Regardless, his gratitude toward security personnel was genuine.

That's why they were happy to receive the refreshments.

***

"The stars are visible."  
"Yeah. It was clear today."  
"Oh, really."

After delivering refreshments to the temporary security office at the west gate, Yuu stopped while crossing the second athletic field to return to the gymnasium and looked up at the night sky.

Surrounded by Sayaka, Riko, and many others.

Especially with tall security team members like Chizuru and Connie forming an outer perimeter, Yuu's figure wouldn't be visible from a distance.

Around Saito City in central Saitama Prefecture, more stars are visible than in Tokyo.

Still, Yuu only knew basic constellations—at most Orion in the eastern sky. And the red-glowing Mars. The moon was a crescent.

"Seeing the night sky like this from the schoolyard is nice too."  
"Fufu. That's because I'm with Yuu-kun."  
"I fully agree!"

Yuu looked around at the surrounding girls, then nodded deeply with emotion.

"We could safely conclude the Sairei Festival thanks to all of you.  
Sayaka, Riko, Emi, Kiriko, Sawa, Mizuki, Yoshie, Nana—thank you."  
"""Yuu-kun..."""  
"Ah, just being with Yuu-kun is enough for me..."  
"Because Yuu-kun was here, we could do our best!"  
"That's very true!"  
"But brother, it's not over yet."  
"They say field trips aren't over until you return home."  
"That's true too."  
""""""Ahahahaha""""""

After laughing together, Yuu shook hands with every security member—including Chizuru's team who guarded him exclusively today—thanking them one by one.

For Chizuru and others, being assigned to Yuu's security detail itself was a source of pride, joy, and motivation.

Being thanked specifically was embarrassing, but they still smiled happily.

Yuu looked up at the night sky surrounded by over twenty girls.

As student council president = executive committee chair, he bore heavy responsibility during the Sairei Festival, but thanks to the girls surrounding him, it seemed to conclude smoothly.

He truly felt becoming this school's student council president was the right decision.

---

### Author's Afterword

Thus, the long Sairei Festival arc—including preparation periods—concludes.

For reference, the meaning of the line spoken by Sachiko when Yuu held her back:

"Waaah! Embarrassing... Wh-what do I do!?"

While elderly people might speak that way, I thought such strong dialect might be odd for a young girl, so I toned it down to this level.

Personally, I like girls with dialects.

### Chapter Translation Notes
- Translated "壁チンポ" as "wall penis" to maintain explicit terminology while preserving the compound word structure
- Translated "壁尻" as "wall buttocks" to match the parallel terminology
- Preserved Tsugaru dialect indicators through contextual phrasing rather than phonetic spelling
- Translated "祐たん" as "Yu-tan" to maintain affectionate nickname style
- Used "crotch" for "股間" as anatomically precise term
- Maintained Japanese name order throughout (e.g., "Aramaki Yoshie")
- Italicized internal monologue *(This is concerning.)* per style rules
- Transliterated sound effects (e.g., "Hya!" for ひゃ)