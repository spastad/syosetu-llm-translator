## 288. Classmates ② ~Joy of Love~

Currently, three buttocks were lined up before Yuu's eyes.

The left one was Yoshie, the middle was Sawa, and the right was Nana.

All three had slender builds, so even from behind their buttocks appeared slim, though with some individual differences.

Slightly rounded and plump-looking was Yoshie.

Childlike cute small buttocks belonged to Nana.

The thinnest with prominent sit bones was Sawa.

Moreover, with their buttocks slightly raised and legs spread shoulder-width apart, their thoroughly drenched private parts were fully exposed.

  
"Nice. All three of you look incredibly erotic. I'm super excited."  
"Yuu-kun is staring intently at my embarrassing place..."  
"Somehow, my heart is pounding so hard."  
"Th-this pose... if someone saw us..."

  
Nana's request was to have Yuu spank her buttocks.

During the sports festival patrol, when intruders including children attacked, Yuu had made one expose their buttocks and spanked them hard as punishment.

In this world, not only do men rarely hit women, but raising a hand at all is uncommon.

Perhaps because the physical disparity has disappeared, and in some cases women might even be stronger.

Being a minority in a female-dominated society likely makes men passive and hesitant.

  
Due to his original world's values, Yuu never considered hitting women willingly and was basically gentle with those he cared for.

But after being reborn and adapting to this world, he'd come to feel using force might be necessary depending on the situation.

  
Yuu interpreted that Nana probably wanted something soft-SM style.

Whether pain transforms into pleasure varies by person. If only he had the discernment to tell like his half-sister Saira who'd identified Elena as a masochist, but Yuu lacked that confidence. Through trial and error he'd learned where each partner was sensitive.

Trying it might awaken new fetishes, or just end in plain pain.

But he thought changing things up might be good.

So he decided to add some SM flavor using available materials.

  
As part of this, he used the abundant towels in the waiting room to blindfold all three and bind their hands behind their backs.

To make their bodies somewhat comfortable, their upper bodies rested on folded futons rather than directly on the tatami, face down.

While Nana and Yoshie readily accepted Yuu's proposal, Sawa seemed resistant. But she ended up bound by the other two flanking her.

  
"You're really okay with this?"  
"Un. Onii-chan, do it."  
"Me too."  
"........."

  
When Yuu asked, Nana answered with her blindfolded face slightly turned, and Yoshie agreed.

Only Sawa remained silent, which he arbitrarily interpreted as embarrassment about affirming.

  
Truthfully, he wanted to thrust his cock into one of the three buttocks, but he also felt like indulging in this sideshow for now.

Kneeling directly behind Sawa, Yuu extended both hands to touch Yoshie and Nana's buttocks. He kneaded their buttocks with his wide-spread palms.

  
"Ah!"  
"Nn!"

  
The two gasped at the sudden touch.

With their buttocks thrust out and blindfolded, they couldn't anticipate anything.

Without mental preparation, even slight touches made them react sensitively.

That said, since it was Yuu whom they already liked, the tension added just the right essence.

  
*Pechin. Pechin.*

Yuu lightly spanked Nana's buttocks with his raised right hand.

He held back, so the sound was small.

He also couldn't bring himself to hit his cute half-sister too hard.

  
"Haah, haah, Onii-chan. Harder, please?"  
"Hm? Okay then, no holding back."

  
Responding to Nana's breathless plea, Yuu steeled himself.

It probably wouldn't mean anything without actual pain.

He recalled mercilessly spanking the ample buttocks of Omori Norika, vice president of Saiei Academy's student council, in their basement. When he'd spanked continuously, his own hand hurt.

Using that force as 10, maybe 7 would be appropriate now.

  
*Bachin!*

Putting more strength than before into his arm, he spanked Nana's buttocks, producing a satisfying sound.

  
"Hyauun!"  
"Like this? Here goes!"

  
*Bachin, Bachin!* He spanked consecutively.

Under Yuu's hand, the white skin gradually reddened.

  
"Ah, ah, it hurts... but feels good! Onii...chan, more!"  
"Yuu...kuun. M-me too!"

  
Apparently, pleasure arose alongside the pain.

Seeing Yoshie wriggle her hips and beg, Yuu smiled.

  
"Yoshie's turn next."

  
Yuu shifted left.

Raising his right arm slightly, he brought it down.

  
*Bachiin!*

  
"Hii! Wha, wha...!"

  
Yuu's right hand struck Sawa's buttocks instead. Caught off guard, her body jerked up.

Yuu continued spanking Sawa's buttocks.

  
*Bachiin! Bachiin! Bachiin!*

  
"Agh, agh, sto...p... hyuun! It huuuurts!"

  
Meanwhile, he sandwiched his cock into the upper cleft of Yoshie's waiting buttocks.

Yuu too was aroused by spanking the girls. Feeling the heat and hardness of his rigid cock, Yoshie released a hot breath.

  
"Agh! Sto...p... aghn! Kuu... uah... agh, agh!"

  
After about five spanks, Yuu noticed Sawa's voice changing.

Though shaking her head as if resisting, her voice gained a sensual tone.

Perhaps Sawa, who seemed most reluctant, actually had masochistic tendencies.

While enjoying the sensation of his cock sandwiched in Yoshie's buttocks, Yuu kept spanking Sawa until her buttocks turned bright red.

  
After that, he continued spanking all three - Yoshie, Nana, and Sawa - in turn with variations.

When all three had reddened buttocks, he lowered his head for closer inspection.

  
Nana and Sawa had clearly been aroused from the start, enjoying being spanked by Yuu.

Though initially in pain, surprisingly Sawa seemed most affected.

Evidence: love juices dripped continuously from her slightly parted slit, soaking her thighs and futon.

  
*(I can't hold back any longer!)*

  
Without needing to get closer, Yuu caught the scent of female arousal and reached his limit.

Ignoring Sawa's ragged breathing, Yuu brought his hips closer and pressed his cockhead against her.

Sawa's vaginal entrance accepted it easily with a *nupuu* sound the moment it touched.

  
"Huh? Aaaaaaaaahhhhhhhh!"

  
Grabbing her waist with both hands, Yuu thrust in.

In his frenzied state, he pushed his hips with force to penetrate deep, but immediately met resistance from vaginal muscles.

  
"Guu... ooh..."  
"Wai... aagh! It's... in! Igh! Dee...p... ku...rugh!"

  
Unusually for Yuu, his cock forced its way through the narrow vaginal canal in excitement, the tip gouging her deepest spot.

At that instant, pleasure like an electric shock ran from Yuu's waist to back. He barely resisted ejaculating right then.

  
"Hafuu. Inside Sawa feels... amazing..."

  
Pausing his hips to regain composure, Yuu extended both hands left and right.

Their destinations: Yoshie and Nana's wet vaginal openings.

  
"An!"  
"Haan!"

  
Inserting middle fingers into both vaginas.

The thoroughly moistened entrances accepted Yuu's fingers, making them moan in pleasure.

After just a few thrusts, love juices overflowed, soaking up to his finger webs.

  
While penetrating the middle girl, simultaneously fingering the left and right.

A dream harem play.

But actually, the doggy style position was hard to move without holding down.

So Yuu devised a solution.

  
"Sawa?"  
"Ah... hi..."  
"Sawa!"

  
"Ahfe! O, o, ohinpo gaa..."

  
Putting strength into his hips, he ground his cock deep into her vaginal depths. Sawa threw her head back as if repelled.

Having unexpectedly awakened to a new fetish from the spanking, present Sawa drooled, cheeks flushed pink, completely transformed. Her mind could only think of Yuu's cock.

  
"Move with me, Sawa. Slowly is fine. Okay?"  
"Ha, ha, hahi"

  
Yuu and Sawa moved their hips to collide with each other.

Initially out of sync, but as Yuu looked down at their joining point to match movements, their timing aligned.

  
"An! An! Aaan! Good! Good! Yuu...kuun... ohinpo, feels good... haau! Dee...p! Ighn! No! Ahhaa!"  
"Ooh, ooh... dangerous, I'm... feeling it too!"

  
As Yuu and Sawa slammed hips, *tan, tan* flesh-smacking sounds echoed. Their joining point, and even Yuu's lower abdomen, became drenched with splattered love juices and sweat.

With her head thrown back, Sawa's moans grew higher.

Yoshie and Nana, being fingered, remained face down, leaking muffled moans.

  
"Hah, hah, kuha... almost..."  
"Ogh, ogh, aghn! Yuu...kuun! Igh... CummingCummingCumming! Agh! No! Ahi!"

  
Minutes after starting to slam hips with Sawa, Yuu sensed his limit approaching.

Unconsciously perhaps? Each deep penetration brought stronger vaginal contractions.

As if trying to squeeze out his essence.

Wanting to prolong this pleasure, Yuu tried enduring, but his lower body seemed to move independently, accelerating.

This made Sawa climax first apparently.

Bound hands behind her back, violently shaking her head - Sawa's long black hair was completely disheveled, her blindfold nearly off.

  
Focused on thrusting, Yuu kept his fingers inserted deep into Yoshie and Nana's vaginas without moving them.

Hands stationary, Yuu leaned forward over Sawa's slender back and began his final sprint.

  
"Fmm! Egh, ogh, nmu... hyame... vuun! Limi...t... Cumming!"

  
Perhaps lacking strength to lift her head, Sawa buried her face in the futon, releasing muffled moans.

Ignoring Sawa, Yuu thrust solely to ejaculate.

  
*Ban ban pan pan!* Hip-smacking sounds continued... "Igu! Vu... Ejaculating!"

Shoving his cock deep as if lifting her womb, groaning as he stopped moving, Yuu ejaculated.

  
"Nagh! Ah... afuu... fill...ing... uun... so gooood... aha... so mu...ch..."

  
Feeling hot semen pulsing *dokudokudoku* inside her, Sawa wore a feverish expression, muttering nearly meaningless words.

  
After the long ejaculation ended, Yuu regained some composure.

Removing the nearly-off blindfold and hand restraints, he lifted Sawa's body firmly and moved her forward.

Meanwhile, Sawa stared dazedly at Yuu, then mumbled.

  
"Huh? Say that again."  
"N... so I said, I love you!"  
"What?"

  
Meeting Yuu's mischievous gaze, Sawa pouted slightly but seemed resolved.

She clung to Yuu with both arms.

  
"I love Yuu-kun!"

  
Without giving Yuu time to respond, she pressed her lips against his.

  
Yuu faced a difficult choice.

After moving Sawa, two girls remained in the buttocks-raised pose.

  
Aramaki Yoshie, Class 1-5 representative, had grown close since the ball games tournament.

Serious and responsible, yet inexperienced with men, she had an innocent charm.

Mutual attraction from the start, he'd secretly taken her virginity on a stair landing during a chance meeting at the First School Building.

Even after Yuu became student council president, she supported him devotedly as a member.

  
Tsutsui Nana, daughter of actress Tsutsui Takako, transferred after summer break.

A natural actress who played various "little sister" roles, but since Yuu said he preferred her true self, though quiet, she didn't hide her affection for him.

Apparently yearning for an older brother figure, she was actually a heavy-loving half-sister.

Though still developing physically, her cuteness ranked top-tier at Sairei Academy.

  
"Onii-chan... hurry, put it in."  
"Yuu-kuun... I can't hold back either."

  
If only Yuu had dual reproductive organs like a snake, he'd penetrate both simultaneously.

But as a mere human, he had to choose one.

Faced with two females desperately craving his cock, Yuu had to decide quickly.  


### Chapter Translation Notes
- Translated "お尻ペンペン" as "spank buttocks" to maintain explicit terminology while preserving the childish reduplication
- Translated "ソフトSM" as "soft-SM" to retain the Japanese loanword abbreviation while making it accessible
- Translated "手マン" as "fingering" for explicit anatomical accuracy
- Preserved Japanese terms like "Onii-chan" and "-kun" honorifics per style rules
- Transliterated sound effects (e.g., "Pechin", "Bachin") with contextual descriptions
- Translated "メスの匂い" literally as "scent of female arousal" for anatomical precision
- Maintained original name order (e.g., "Aramaki Yoshie") when full names appeared in narration
- Translated sexual acts without euphemisms (e.g., "膣奥を抉る" → "gouged her vaginal depths")