## 289. Classmates ③ ~Ejaculating with Three People~

"Faaaaaaaah! Ah...n! Kuun! This is... so good... Yuu-kun's... cock... feels so good! Ah! Ah! I'm cumming, I'm cumming, I'm going to cum!"  
"Chu, chu, chupa... mmm... amuu... Big brother, hurry, I want it too."

After Sawa, who was in the middle, withdrew, Yuu pressed Yoshie and Nana, who were lying face down, tightly together and decided to insert alternately.  
The blindfolds and the towels that had bound their hands had already been removed.  

Although the two had had intercourse multiple times since losing their virginity, it was still tight at the initial insertion.  
However, after repeating the alternating insertion about two times, they became lubricated by their love juices, and the thrusting became smoother.  

For Yuu, it was good to be able to enjoy the inside of Yoshie's and Nana's pussies alternately.  
Aroused, Yuu was now almost in a doggy-style position and was thrusting into Yoshie.  
However, being considerate of Yoshie's pregnancy, he supported his body in a push-up-like manner to avoid putting weight on her and continued to move his hips.  

Yoshie, who was among the top five in class academically, well-behaved and strongly responsible, the very model of a class representative and honor student, was now moaning with the face of a cock-crazed slut.  
Meanwhile, Yuu was kissing Nana, who had turned only her face toward him, and their tongues were entwined.  

"You can cum, Yoshie. Here."  

Yuu, having parted his lips from Nana, whispered in Yoshie's ear.  
As if that was the trigger, Yoshie lifted her chin.  
Her glasses had been removed when she was blindfolded, and she looked back at Yuu with moist, doe-like eyes.  
Yuu placed his hand over Yoshie's left hand, which was gripping the comforter, and pressed his cheek against hers.  

"Hyai! Ah... I'm... cumming... ah, ah, ahh! Amazing! Yuu-kun Yuu-kun Yuu-kun Yuu-kun! Hyaa! It's too much... ah... ahhoooon!"  

Even though there were intervals due to the alternating insertion, she had been receiving intense pleasure continuously since the spanking.  
After being knocked deep inside a few times during the third insertion, Yoshie came easily.  

Confirming that, Yuu smiled and pulled his hips back, withdrawing his cock.  
From Yoshie's pussy, a sticky string stretched as if reluctant to part.  
Yuu moved slightly to the right, pressed his wet, glistening cock against Nana's butt, and after gropingly inserting it into her vagina, he thrust deep in one go.  

"Hi, hyaaauuuuun! Aa... hea... Big brother... ukyuun..."  
"N-Nana? Are you okay?"  

Nana had arched her back like a shrimp and let out a loud moan, then collapsed face down onto the futon, so even Yuu was flustered.  

"I'm... okay. My head went blank... it was amazing... I came... Big brother's... cock feels so good... more, more, please?"  

After a moment, Nana turned only her face toward Yuu and pleaded in a broken voice.  
Yuu couldn't help but feel affection for Nana.  
He covered her without putting too much weight on her.  
Nana, underneath, was the smallest in the student council and about the third smallest in Class 1-5, so she was completely enveloped by Yuu's body.  
He combed her hair, which had been half covering her face, and let it flow down her back, then pressed his cheek against hers and said.  

"I'm moving."  

Seeing her nod repeatedly while breathing heavily, Yuu slowly began to move his hips.  

Bachun! Bachun! Bachun!  

"O, o, o... mufu... uun! Big brother, ai! I'm cumming, I'm cumming again... a, a, a, a, nnaaaaaaaah!"  

In a doggy-style position with Nana's butt slightly raised, Yuu thrust his hips relentlessly.  
It seemed Nana came again without much time passing.  

Originally, he should have withdrawn and taken his turn with Yoshie next, but in fact, Yuu was also losing his composure.  
Nana's pussy, which was already tight, was now tightly squeezing him, and whether thrusting or pulling, the stimulation from the fine folds brought Yuu the utmost pleasure.  
Yuu wanted to cum inside Nana just like this. If she wasn't pregnant yet, he wanted to make sure to impregnate her.  

"I'm going to cum... like this! I'll ejaculate inside your pussy, Nana!"  
"Hyun! Please... Big brother! Ah, ah, haan! Please!"  
"Gu..."  

Yuu embraced Nana's upper body with both arms.  
Nana, who had been tightly gripping the comforter, let go and instead grabbed Yuu's hands.  
Yuu's hips moved faster, and with one final thrust deep inside, he reached his climax.  

"Ah! Ha... I'm ejaculating!"  
"Hia! Ah... uun... inside... it's coming... Big brother... so much... ahhaa..."  

Yuu released a massive amount of semen, no less than when he did with Sawa.  
After ejaculating, Yuu lost his strength and ended up putting his weight on Nana.  
For Nana, feeling Yuu's heavy weight and body temperature through her back gave her a sense of security. Moreover, feeling the hot torrent pouring into her womb, she closed her eyes with satisfaction.  

"Here, Yuu-kun."  
"Thank you."  

The cup handed by Sawa contained just tap water, but now that he was sweaty, it tasted very good, and Yuu drank it all in one go.  
Unlike in Tokyo, even in Saitama, the tap water in this area had almost no chlorine smell and could be drunk as a matter of course.  

With the three of them lying side by side on their backs, Yuu had ejaculated in quick succession into Sawa and Nana, so it was time for a break.  
Only Yoshie hadn't been creampied, but since she was already pregnant and generally reserved, she didn't seem dissatisfied.  
However, she was leaning against Yuu's left shoulder as he sat on the futon.  
Nana, who had just been creampied, was lying down, using Yuu's lap as a pillow and having her head stroked, looking very pleased.  

Sawa, who had gone to the water heater room with a sheet wrapped around her body, sat directly in front of Yuu.  
Yuu looked at Sawa's face and noticed she was avoiding eye contact, looking down diagonally and fidgeting.  

"What's wrong?"  
"Huh...?"  
"You look like you want to say something."  
"Yeah. Actually..."  

According to Sawa, when she went to the water heater room, Riko had just entered the student council room.  
Seeing Sawa wrapped only in a sheet, Riko seemed to have figured it out.  
She smiled and left, saying, "I'll come to pick up Yuu-kun in about an hour, so enjoy until then."  

Come to think of it, an hour had already passed since they started.  
Riko probably knew that the student council wasn't busy at this time, so she might have come to pick him up early.  
For Sawa, being seen by Riko might have brought her back to her senses, and she suddenly felt embarrassed.  
But Riko was a former student council member, so she was like family. It was fortunate that it wasn't a complete stranger.  

"So, we have a little less than an hour left. What should we do?"  
As Yuu looked at the three in turn, they all pounced on him at once and pushed him down.  

"This time, we will"  
"make Yuu-kun"  
"feel good!"  
"Mmmpf!"  

Sawa, who had removed the sheet, from the front, and Yoshie from the side, rained kisses on him as if competing.  
Nana, who should have been using his lap as a pillow, ran her lips and fingers over Yuu's chest.  
Not only Yoshie, but even Sawa, who usually acted aloof, was being unusually proactive now.  
Thinking that this might be good once in a while, Yuu let them do as they pleased.  

"Muchu, chu, chupaa, nreloreroo... anmuuuuu... chupon! Hah, Big brother, I love you, I love you, I love you so much!"  

With his head held by Nana, Yuu was being kissed and licked not only on his face but also from his neck to his shoulders.  
Even though it was only his upper body, she seemed to have lost herself in monopolizing Yuu and caressing him as she pleased.  
Nana's long black hair hung down, and the tips tickled his skin, but he used his left hand to comb it and gently stroked from her shoulders to her back.  
Sometimes Nana would approach with her tongue out, and he would accept it, enjoying the kiss with wet, smacking sounds.  

"Haaa~ As always, Yuu-kun's cock is so big and splendid..."  
"Muchu, chu, really, this thing... lero, lero, it's hard to take in... ah. Anmu... nmoeroreerojupu. Even trying to take it in my mouth... is impossible. Chupa. It's already too much for me."  

Yuu was lying on his back in a spread-eagle position. Straddling both his legs were Yoshie and Sawa, both lovingly caressing his cock.  
Yoshie was carefully observing, stroking the details like the veins and wrinkles with her fingers, murmuring in an admiring tone.  
Sawa, perhaps frustrated at having been made to cum multiple times, was muttering complaints while continuing to give a blowjob, taking the glans into her mouth, so it was hard to understand what she was saying.  

"Kuu! It feels good... ah, nmmo"  
"Mufuun... nero rero... chiro, chiro, Big brother... chupu, nfu... more, more... aahn!"  
"Ah, Nana"  

The words that leaked out from the pleasure of the double blowjob were blocked by Nana covering his mouth with hers.  
Nana licked the drool around Yuu's mouth with her small tongue, then looked closely at his face as he was feeling pleasure, smiling broadly and pleading.  
While kissing Nana, Yuu reached out with his left hand, grabbed her small butt, and inserted his middle finger into her vagina.  
Just playing near the entrance, it immediately made wet, squelching sounds.  

Meanwhile, Yoshie and Sawa's blowjob became more active.  
The two of them stroked the shaft while licking from the glans to the coronal ridge without caring if their tongues touched. It felt so good that Yuu's hips almost jumped up.  
The two were probably getting excited while giving the blowjob. They seemed to be moving their hips back and forth on Yuu's legs, and he could tell that their crotches were wet where they touched.  
Even though he had ejaculated twice, his cock was already dripping precum, which was immediately licked or sucked off by Yoshie or Sawa.  
Being caressed by three beautiful girls, Yuu once again felt the urge to ejaculate building.  

"Fufu, you're going to cum soon, aren't you? You look like you're about to cum. It's twitching so much... I'll make you cum. Anmu"  
"Aahn, I want to lick that part too"  

As the speed of stroking increased with a shaka shaka sound, Sawa seemed to sense something. She swallowed the glans whole, took it into her mouth, and stimulated it with her tongue.  
Yoshie, who had been running her tongue along the underside, was late and, seeing that Sawa wouldn't yield, moved to caress his testicles instead.  
Although Sawa usually acted aloof toward Yuu, once she got into it, she became bold and devoted in her blowjob.  
It seemed that at some point, she had been taught blowjob techniques by Riko and Emi.  
Opening her mouth wide, she took about half of Yuu's cock into her mouth and used her hands and tongue to guide him to ejaculation.  

"Nmu... o, o, I'm... n, nn!"  

Nana, covering him from the side, held his head and boldly inserted her tongue, ravaging his mouth.  
It was as if she was competing with Sawa, and Yuu could only let out moans.  
Receiving passionate caresses from above and below, Yuu was finally about to reach his limit.  

"Mug! I'm cumming!"  

Stimulated all over his cock, Yuu felt a pleasure so intense his whole body might jump, and he ejaculated.  

"Nmo!? Ogo... un... gulp!"  

If this had been the first ejaculation of the day, it might have been terrible. Fortunately for Sawa, it was the third time, so the volume had decreased somewhat.  
Even so, compared to a normal male, a large amount of semen hit Sawa's throat.  
She held back the urge to gag for a moment and swallowed it all in one gulp.  
The semen, just ejaculated and not exposed to the outside air, passed through her throat while still warm.  
Though it was sticky and hard to swallow, Sawa didn't remove her mouth and drank it all to the last drop, as if squeezing it out.  

"Fuhaa... that felt good. Thank you."  
"Fufu, you're welcome."  

Sawa, who had sucked out every last drop, scooped up her fallen hair with one hand and smiled at Yuu.  
The smile she showed, with her usually cool face now flushed and heated, was incredibly beautiful and sexy.  

"Aahn. I want Yuu-kun's cock too..."  
"Let me lick it this time."  

As Yoshie tried to take the glans into her mouth, Nana tried to join in.  
The lust-drenched girls showed no signs of stopping.  
Yuu smiled wryly, raised only his upper body, pulled Sawa close with his right hand, and said.  

"Then, you two suck it together nicely."  

Yoshie and Nana nodded happily and, instead of replying, kissed the glans together and began sucking eagerly.  

---

### Author's Afterword

After all, it might be easier to create more intense content with two or three partners.

### Chapter Translation Notes
- Translated explicit anatomical terms directly: "おチンポ" as "cock", "膣内" as "pussy", "射精" as "ejaculating"
- Transliterated sound effects (e.g., "ばちゅん" as "bachun")
- Preserved Japanese honorifics (-kun) and name order
- Represented Nana's speech quirks ("にいひゃん"→"Big brother") without phonetic alterations for readability
- Maintained explicit descriptions of sexual acts per translation guidelines
- New dialogue lines formatted as separate paragraphs per attribution rules