## 292. A Certain Holiday ~How to Spend a Holiday~

### Author's Preface

Sorry. I went out and came back late.

Inserting a small everyday story before the Christmas party arc begins next chapter.

---

On a Saturday afternoon when Yuu and Martina's schedules finally aligned, the Hirose household spent time together as a family. After enjoying dinner prepared by Yuu, the three bathed together and tumbled straight into the bedroom for a passionate night.

The next morning, Yuu left his still-sleeping mother and sister in bed and headed to the training center of the security company where Kanako and others belonged. This had become his Sunday morning routine for training and learning self-defense techniques. Being able to function despite staying up late must be a privilege of youth.

After three hours of rigorous exercise and sweating, Yuu finished by showering while getting intimate with Kanako and Touko.

Lunch was eaten at the training center. It was safer than going out to eat since security was thorough inside the facility. Though the facility was available to men with security contracts, Yuu rarely saw other males there. Occasionally some middle-aged men reluctantly came to exercise after being warned by doctors about obesity from lack of exercise.

Amidst this, Yuu had become popular at the training center, visiting almost every week and cheerfully greeting everyone - whether it was the muscular security officers or cafeteria aunties - while readily engaging in conversation.

Feeling drowsy in the car during the return trip, Yuu rested his head on Kanako's lap and fell asleep, allowing her to enjoy blissful moments. He wasn't woken immediately upon arrival because all the security officers in the car, including the driver, took turns gazing at his sleeping face and stroking his head.

After 2 PM, Yuu visited Sayaka's apartment. Sayaka had lived in a single-person unit in a two-building complex but moved to a 3LDK family-type apartment after getting engaged to Yuu. Now at six months pregnant, Sayaka lived there with Riko and Emi, and Yuu stayed over about every other day. Sometimes even current student council members like Kiriko, Mizuki, Yoshie, and Nana stayed overnight. On such nights, Yuu would be surrounded by up to seven women. They usually couldn't stay up too late since school was the next day, but the nights remained passionate.

Today at 3 PM, a certain person was scheduled to visit, and Yuu and Sayaka planned to talk with her alone - Riko and Emi had been informed of the situation.

---

While preparing tea and sweets to entertain the guest, the doorbell rang and Sayaka went to greet them. After hearing some conversation, Sayaka returned. When the woman following her tried to enter, Yuu called out.

"Welcome. Ryo...ko!?"

"Y-yeah, it's weird, right...? L-laugh if you want. Sayaka laughed at me too earlier. Anyway... it doesn't suit someone like me."

The delinquent girl from Yuu's memory was nowhere to be seen. When they first met, she wore a uniform with a skirt that seemed to drag to her ankles. The next time, she wore denim top and bottom. Today she wore a black leather jacket with a matching tight skirt. Her long legs stretched out covered in black pantyhose.

As before, she seemed to have a habit of leaving her jacket open regardless of the cold - revealing a red cutsew that emphasized her well-shaped breasts. Her hair, which had been patchy with red and brown from repeated dyeing and bleaching and looked damaged even to an amateur's eye, had been cut short. It now reached shoulder-length and was nearly black.

Her makeup wasn't the heavy delinquent-style with strong eyeshadow and bright red lipstick. Though her eyes remained sharp, the natural makeup highlighted her attractive features. It was a surprising image change - and a significant improvement. She looked less like a delinquent and more like a policewoman or detective.

"Heeeh~"

Yuu stood up and approached Ryoko. Though Sayaka had laughed, it probably wasn't because the look didn't suit Ryoko. She likely smiled imagining Yuu's reaction after being surprised by the sudden makeover. Yuu took the hand of Ryoko, who was looking down shyly.

"I thought some sexy beauty had come. It suits you well. You're beautiful, Ryoko."  
"Fwaah!?"

Holding her hand, Yuu embraced Ryoko. A floral scent drifted from Ryoko's neck, tickling Yuu's nostrils. He stroked her hair as well. It seemed shinier than when they last met.

"Did you choose this yourself?"  
"Th-this is... well, the leader... ahh..."

Whispered to by Yuu near her ear, Ryoko turned bright red and flustered. Though today's outfit was cool and sexy, she remained as inexperienced and innocent as ever around men.

According to Ryoko, she had gone on a rare outing with Kate to a shopping mall in the southern part of the prefecture where Kate coordinated her outfit. Among the clothes Kate selected were flashier and cuter options, but Ryoko refused out of embarrassment. After much time, they finally chose clothes that somewhat matched Ryoko's taste.

Furthermore, at Kate's suggestion, she went to a salon and drastically cut her hair. They promised that once Kate's life stabilized, she would color it whatever color Ryoko liked. Since she was meeting Yuu today, Kate even did her makeup.

Though Kate remembered what Yuu had said during their previous meeting, her true intention was to thank Ryoko for looking after her since leaving home. Seeing that Yuu's praise was genuine, Ryoko finally relaxed and smiled happily.

"I'll prepare it. Both of you sit down."  
"Sorry about this, Yuu-kun."  
"O-okay."

After seating Sayaka and Ryoko on the living room sofa, Yuu resumed preparing the tea and sweets. The kitchen felt familiar. Having stayed over regularly and done housework together, he was practically a resident.

Among the three pregnant women, Sayaka had the worst morning sickness and her belly was growing larger, so Yuu paid special attention - almost overprotective. Sayaka smiled wryly but accepted Yuu's kindness.

Yuu brought a tray with three cups and cookies to the sofa. Today Sayaka wore a loose white sweater with a light blue long flare skirt - prioritizing warmth to avoid chilling her body. Yuu sat beside her, facing Ryoko.

Ryoko seemed unable to shake her habit of wearing long skirts or pants - even in a tight skirt, she sat with her legs spread, revealing her white panties clearly visible through the pantyhose. Sayaka didn't correct her, perhaps thinking it pointless to teach her ladylike manners now. Yuu decided to leave it as eye candy.

"Ryoko, what do you take in your coffee?"  
"Um... b-black!"  
"Huh?"  
"W-women drink it black, right!?"  
"You had a sweet tooth when you stayed with us."  
"I'm not a middle schooler anymore!"

While smiling wryly at Ryoko acting like a boy trying to act cool on his first café date with a girl he likes, Yuu placed a cup before her. Yuu drank his black. Sayaka used to do the same but since becoming pregnant craved sweetness, adding milk and about a teaspoon of sugar.

"Bitter!"  
"I told you so."

Ryoko grimaced after taking a sip. Yuu preferred coffee with mild acidity and deep richness, which might have made it taste extra bitter. Though Yuu and Sayaka offered milk and sugar, Ryoko endured it. Rather than stubbornness, she seemed to want to savor the coffee as Yuu prepared it.

First, they discussed the Red Scorpions members' recent situations. Mari and Misa were progressing well in their pregnancies. With leader Kate forced into hiding, the Red Scorpions' team activities were suspended. Taking advantage of this, rival gangs in the city had been trying to assert dominance.

On their way back from visiting Kate's temporary hideout - a closed café - Ryoko, Ginko, and Mari encountered a group from an enemy gang. Though outnumbered ten to three, they didn't back down. Pretending to flee, they lured them into a narrow alley to avoid being surrounded, then took them down one by one.

During the fight, Ryoko and Ginko shielded the pregnant Mari and took the brunt, but two enemies climbed over a wall to flank them. However, Mari calmly handled them with her expert judo throws. One enemy was thrown onto the asphalt without being able to break their fall and knocked unconscious.

"Don't be reckless."  
"Well, we had pent-up flatration too."  
"Shouldn't that be frustration?"  
"Y-yeah, that's it."

After exchanging such updates, they moved to the main topic. Ryoko set down her cup, which still contained dark brown liquid since she'd been sipping slowly, and spoke.

"The leader's new place and high school are decided."  
"Oh? Where finally?"  
"Matsumoto, she said. In Nagano."  
"Matsumoto, huh..."

Yuu traced the route in his mind. From Saito City to Matsumoto City in Nagano Prefecture, it was fastest to take the limited express from Shinju - about four hours. The mixed-use building housing Kate's current hideout - a closed café - was scheduled for demolition this year.

She wanted to move before year's end but struggled to find a place with live-in work. The move would now happen after New Year's, with a temporary stay in a weekly mansion until then.

"Kate's really grateful to you. Thanks. She said she appreciates it."  
"Ah well, gotta use the connections I have."

Due to her mother Jane being nationally wanted, Kate got caught up in the scandal, couldn't stay home, and voluntarily withdrew from Saiei Academy. She hoped to work while attending night school. Like in his previous life, she aimed to become a beautician, planning to attend vocational school after graduating high school to get certified.

However, finding work and a school was difficult in her situation. So Yuu requested the Toyoda Sakuya Memorial Foundation to arrange her transfer in exchange for appearing in their commercials. Among several options, she chose a place neither too far nor too close.

"A-and... um, Yuu... h-here's this."  
"Huh?"  
"A t-token of gratitude, they said. We both chose it."  
"You didn't have to..."

Stammering, Ryoko presented a small box wrapped simply in pale paper. It was light too.

At Sairei Academy, giving expensive gifts was prohibited to promote healthy relationships, but outside school, women often wanted to lavish gifts - especially older working women. But Yuu had declined during high school, feeling that physical relationships were enough. His resistance to being spoiled by women was also significant.

When Yuu declined, women liked him more for being humble. Exchanging birthday presents with Sayaka, Riko, and Emi was special.

"May I open it here?"  
"P-please."

It felt rude to reject her kindness. Thinking he could accept it without hesitation if it was appropriate for a high schooler, Yuu unwrapped the box.

"Eh... a ring?"

Inside the pure white case was a ring. Completely different from the wedding ring Yuu had once given his wife. To Yuu's imagination, it resembled the thick, chunky rings flashy men wore.

A black ring with a flat silver top. Simple with no particular decoration.

"Hmm..."

As a gift from a girl, it was frankly awkward, leaving him unsure how to react.

"That's... not just a ring. Actually..."

Ryoko pulled an instruction manual from under the ring cushion. After reading it, Sayaka approved of accepting it even before Yuu did. Because it was a practical item shaped like a ring.

"If that's the case... thank you. I'll treasure and use it. Please tell Kate too."  
"I'm glad you accepted it! Whew, first time giving a guy a present."

Ryoko looked relieved as if completing a task. Meanwhile, Yuu hesitated over which finger to wear it on. Of course, he'd save his left ring finger until marriage.

"First of all, Yuu-kun. Does it even fit?"  
"Ah!"

Sayaka's words made not only Yuu but Ryoko gasp. Had they bought it without checking his ring size? But trying it on revealed: The glossy ring part looked metallic but was actually elastic. So it seemed to fit any of the three middle fingers.

Thus, Yuu chose his right ring finger - avoiding index and middle fingers since he used them often.

---

"Alright, I'm heading back."  
"Eh? Since you came, why not stay for dinner? Hey, it's fine, right Sayaka?"  
"If Yuu-kun says so, I don't mind at all. Or rather, Yuu-kun will be cooking anyway."  
"Ugh... that invitation... is super tempting."

Standing up, Ryoko seriously agonized. But after shaking her head, she made an extremely pained expression.

"N-no... can't... I promised to help at Mari's mom's shop tonight, then visit the leader."

Mari's mother worked at a bento shop. Ryoko and Mari helped during the busy evening hours, occasionally delivering bento to Kate. Though she clearly wanted to eat with Yuu, prioritizing her promise to her friends showed Ryoko's strong sense of loyalty. That was her virtue, and being refused didn't feel bad.

"Ryoko really is a good woman."  
"Yu-Yuu!?"

Yuu approached and embraced the standing Ryoko, claiming her lips. Though Ryoko's eyes widened in surprise, she soon closed them and wrapped her arms around Yuu's back.

"Mmm, chu, chu... nnaa"

When Yuu inserted his tongue, Ryoko accepted it and pressed her own tongue against it. Yuu's right hand gently stroked her silky hair while his left moved from her slim waist to knead her well-shaped buttocks wrapped in the tight skirt.

Their tongues tangled wetly with *chupa chupa* sounds. As pleasure built, Ryoko tightened her embrace. When Yuu's right fingers trailed from her hair down her neck, and his left lifted her skirt to touch her panties, reaching for her crotch - already wet.

"Fwaaaaah! N-no more... a-any further and... I won't be able to go baaack."  
"S-sorry. Got carried away. We'll continue next time."

After one more kiss with the blushing Ryoko, Yuu pulled away. Once Ryoko caught her breath, Yuu and Sayaka saw her to the entrance.

---

### Author's Afterword

2021/5/29 Added details about Kate's moving period.

### Chapter Translation Notes
- Translated "イメチェン" as "image change" to convey the concept of personal transformation
- Preserved "フラットレーション" as phonetic transliteration to maintain character's speech quirk before correction
- Translated "ガチムチ" as "muscular" to describe security officers' physique
- Rendered sound effects literally (e.g., "ちゅぱちゅぱ" → "*chupa chupa*")
- Kept Japanese culinary terms like "3LDK" and "bento" as culturally specific
- Maintained honorifics (-kun, -san) per style guidelines
- Translated "クロッチ" as "crotch" for anatomical accuracy