## 295. Christmas Party ③ ~The President is Santa Claus~

"Sorry to keep you both waiting."

"Yu-yu-yu, Yuu-kun! You really came! For us, we—"  
"Hi! YUU!"  
"Hey, Connie"

Though Chizuru had met Yuu many times since starting school event security, she seemed unusually nervous today. Her first words came out stuttered and stiff.

In contrast to Chizuru, Connie remained as cheerful as ever, high-fiving Yuu before hugging him. Even without full body contact, her rocket-like breasts pressed against him, making Yuu happily bury his face in them. Connie was a full 20cm taller after all.

"Hey! No fair!"  
"Then it's Chizuru's turn next."  
"Wah! Ahaha..."

After enjoying Connie's rocket breasts, Yuu now hugged Chizuru. Though not as tall as Connie, Chizuru still stood about 15cm taller than Yuu with equally impressive breasts. When Yuu hugged her, their softness pushed back with enough elasticity to make him bounce. With Yuu's face perfectly level under Chizuru's eyes, she wrapped both arms around him with clear delight.

The two greeting Yuu after he slipped away from Christmas party cleanup were third-year PE students who'd retired from basketball club that summer: Shiina Chizuru, the former captain, and Constance Wilson (nicknamed Connie)—a blonde, blue-eyed Caucasian who spoke fluent Japanese having been raised in Japan. Both sported long ponytails with exposed foreheads.

Since first exchanging words during April's club orientation, they'd repeatedly handled security for events. They'd essentially become the student council president's personal guards. Their closeness stemmed from the basketball team's instant infatuation with Yuu and his own appreciation for the tall beauties. This bond culminated in October when Yuu became intimate with both at their retirement gathering.

Both wore basketball uniforms again—white with purple school-name lettering on sleeveless tops and shorts, showcasing their long, slender legs. Though they'd worn track suits against the cold earlier, Yuu saw them hurriedly stripping down when they spotted him approaching. The uniforms were at Yuu's request, heightening his excitement.

"Alright, let's go"  
"Y-yeah"  
"Right. Everyone's getting restless waiting"

While tolerable during intense gym activity, going outside warranted warmth. Yuu positioned himself between the two, wrapping arms around their waists for full contact. Chizuru and Connie each held their discarded track suits in one hand while wrapping their other arms around Yuu's shoulders, walking happily.

They entered the administration building through dimly lit fluorescent corridors. Though open for the Christmas party, only emergency exit signs and fire equipment lights pierced the darkness. For Yuu, the warmth of the two pressed against him provided comfort and reassurance.

"Yu..."  
"Wah!"  
"Who's there?!"

Someone suddenly emerged from a corridor corner, startling them. The tall figure resembled Chizuru and appeared to be another third-year PE student.

"S-sorry for startling you"  
"No worries. Just couldn't see well in the dark"

She was Sofue Tamami, former softball captain. Yuu knew her from student council activities since April. Her once-short black hair now reached her back in twin braids resembling Shizuka from *Doraemon*. Though slender at 185cm, she'd been a power-hitting first baseman. Her navy uniform had blended into the darkness.

"Ah, Tamami-san. Bringing the cakes?"  
"Y-yes!"

Seeing boxes dangling from Tamami's hands, Yuu spoke up. She replied in a voice an octave higher, smiling brightly. Though they'd talked before, she remained shy around him. According to Ueno Shouko from Class 1-5 Softball Club, Tamami was a confident captain during practice but became timid around Yuu. Yuu dismissed it as typical for PE students with limited male interaction.

When Yuu approached to take one box, Tamami frantically shook her head, urging "L-let's go" toward the first building. Just then, running footsteps approached from behind.

"Hey! Waaaaaait uuuuup!"  
"Hm? That voice—"  
"Tch"

As Yuu tried placing the voice, Tamami clicked her tongue unnoticed. The person who'd dashed from the restroom skidded to a stop upon seeing Yuu.

"Ah, Yuu-kun♪"  
"Hey, Tamaki-san"

Her angry expression instantly transformed into a forced smile. Yabue Tamaki—baseball team's former captain with tea-colored short hair and sharp eyes that hinted at her strong personality—also knew Yuu through student council.

"Hey! Sneaking off while I was in the bathroom? Cheap move!"  
"Your dawdling's the problem"  
"What?! You lanky slowpoke! Getting slick now?!"  
"Can't keep Yuu-kun waiting, shorty!"

Baseball and softball—similar sports with ball/rule differences—traditionally competed for field access. Both were equally popular here, with girls switching between them in middle school. Annual April recruitment battles intensified their rivalry. Complicating matters, their captains shared similar names and were both elite hitters—Tamami tied the school's career homerun record while Tamaki (though the shortest present at 165cm) was a contact-hitting third baseman.

"Honestly, these two..."  
"Always fighting"

Chizuru and Connie sighed. Despite their history, Tamaki and Tamami had been chosen to fetch refrigerated cakes/drinks from the home ec room while meeting Yuu with Chizuru/Connie for escort. Just as Yuu wondered if selecting longtime rivals was a mistake—

"Both of you, no fighting"  
"Ah!"

The glaring pair immediately looked chastised when Yuu intervened.

Yuu suddenly noticed Tamaki's uniform—in her rush, she hadn't fastened her white pinstripe pants, revealing purple underwear underneath in the dim light. She gasped and fumbled to adjust.

"S-sorry you saw that..."  
"*giggle*"  
"Let me help"

"Eh?!"

Yuu instinctively knelt before Tamaki to avoid her occupied hands (holding a large plastic bag). As he glimpsed her defined abs, he straightened the twisted black underwear and refastened her pants button and belt. Tamaki stood frozen throughout.

"All done"  
"Th-thank you..."

Tamami—who'd laughed at the uniform mishap—now watched enviously as Yuu personally fixed it. Rising, Yuu wrapped arms around both rivals' waists, pulling them close until their faces nearly touched.

"Wish you'd get along tonight"  
"...!"  
"O-okay. For Yuu-kun"  
"F-fine. Sorry for the delay"  
"My apologies too"

With the truce, Yuu proceeded down the corridor surrounded by Chizuru, Connie, Tamami, and Tamaki, eventually crossing to the first building.

***

No PE students attended the main Christmas party. As dedicated club athletes, they prioritized training. Few developed close bonds with male students—Yuu being this year's sole exception.

Noticing their absence during preparations, Yuu pondered. Since April, sports club members had handled event security. Though rotating shifts, they couldn't fully enjoy festivities. The male students' safe participation relied on these guards. How to repay them?

He considered hosting a separate Christmas party for graduating third-years. Asking unfamiliar boys felt awkward. Since sports clubs were led by third-years until summer retirement, the student council had connections—and personal friends like Chizuru. Surely they'd appreciate his personal attendance.

Chizuru and Connie enthusiastically endorsed the idea when consulted. Thus, Yuu would visit their classroom after the gym party. Nighttime classroom use was pre-approved—the school couldn't refuse the student council president and PE department's request. Officially, Yuu's safety was guaranteed by all third-year PE students present. To outsiders, it might resemble a rabbit entering a wolf pack—but rabbits breed constantly. To Yuu, it felt like entering a herd of beautiful, powerful does.

***

Escorted by four, Yuu ascended the first building stairs. Night schools felt eerie—ghost stories like "Hanako of the Toilet" made sense. Most boys here would find human women scarier than ghosts. A lone boy in a night school should be terrified—yet Yuu thrilled at the classroom full of waiting girls.

At the end of the third-floor corridor outside Class 7 (PE), Fujieda Wakako—former soccer captain—popped out, her tanned face beaming despite winter.

"Everyone! Yuu-kun's heeeeere!"  
""""""Ohhh!""""

A stir of voices and scraping chairs echoed from the classroom. To them, this was the ultimate early Christmas gift. Smiling at Chizuru's group, Yuu entered the open-doored classroom.

"Alright everyone—take your seats. I'm Sairei Academy Student Council President, Hirose Yuu"  
"Yuu-kun! It's really Yuu-kun..."  
"He actually came"  
"His smile is gorgeous"  
"Hehe, still so handsome"

His teacher-like stance at the podium was playful. Yet everyone obeyed, including Chizuru's group. Before Yuu stood all 28 third-year PE students in club uniforms per his request—baseball, track, table tennis, judo, gymnastics, tennis, basketball, volleyball, softball, soccer. White uniforms embroidered with school names in kanji/roman letters, or vivid purple/red/yellow school colors created a vibrant display. All watched Yuu with sparkling, expectant eyes.

---

### Author's Afterword

Other sports clubs (kendo, archery etc.) exist but have no third-year PE students. 

Setting note: PE course admission requires middle school tournament achievements, with waived tuition/fees. Initially limited to ~20 students, enrollment increased post-coeducation. Thanks to Yuu, next year's applicants will surge.

Unlike modern Japan, baseball isn't the national sport—softball fills that role. But since women's baseball exists realistically, I included it. However, it competes with softball for players, ranking below soccer in popularity and comparable to basketball/volleyball.  


### Chapter Translation Notes
- Translated "ロケットおっぱい" as "rocket-like breasts" to convey the protruding shape while preserving the metaphor
- Preserved Japanese honorifics (-san for Tamami, -kun for Yuu) per style rules
- Transliterated sound effects: "ぼよんっと" → "boyon", "ちっ" → "Tch"
- Translated "どら◯もん" as "*Doraemon*" with asterisks indicating the reference
- Maintained original name order (e.g., "Sofue Tamami" not "Tamami Sofue")
- Rendered simultaneous speech """"""Ohhh!"""""" for 「「「「「おぉう！」」」」」
- Translated "牝鹿" (female deer) as "does" for natural English zoological term
- Used "track suits" for "ジャージ" (jerseys) as contextually appropriate athletic wear
- Translated "借りてきた猫" idiom as "timid as a borrowed cat" but adapted to "became timid around" for fluency
- Preserved culturally specific uniform descriptions (bloomers not mentioned but referenced via *Doraemon* note)