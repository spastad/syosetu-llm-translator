## 296. Christmas Party ④ ~Please Kiss Me, Santa Claus~

### Author's Preface

From Christmas Party Part ③ onward, many new girls from the PE course appear.

Therefore, I'll note the class members who appeared up to the previous chapter.

Name・Height・Clubs belonged to until retirement.

  
Shiina Chizuru (しいな ちづる) 187cm Basketball Club  
Constance Wilson (nickname Connie) 192cm Basketball Club  
Fujieda Wakako (ふじえだ わかこ) 175cm Soccer Club  
Sofue Tamami (そふえ たまみ) 185cm Softball Club →New!  
Yabue Tamaki (やぶえ たまき) 165cm Baseball Club →New!  
---

  
The classroom had blackout curtains covering the windows.  
They were taped tightly with duct tape to prevent light leakage outside.  
The heating worked well here too, maintaining a temperature warm enough that even their light uniforms weren't cold.  

Yuu stood at the teacher's podium facing 28 high school girls.  
If he became a girls' high school teacher, this would be his daily reality.  
When young, he naively envied girls' school teachers.  
But after entering society and aging, realizing he wasn't good at handling women, his perspective reversed.  
Groups of women seemed terrifyingly incomprehensible to men.  
Being stared at by so many made him nervous about speaking.  

Having been reborn in a world with reversed chastity norms due to skewed gender ratios, and spending nine months as a high school student at a co-ed school, Yuu had grown accustomed to life surrounded by women.  
Girls proactively talked to him, and even if he couldn't give clever responses, it wasn't a problem. Rather, they were delighted just by his friendly demeanor.  

Thus, Yuu wasn't particularly nervous entering the third-year PE course classroom.  
About half of these 28 held representative positions in their clubs and had met/talked with him through student council matters, which helped greatly.  

Yuu briefly savored the feeling of being a girls' school teacher. After removing his jacket and placing it on the lectern, he stepped forward in his dress shirt. The front-row seats were close enough to touch by reaching out.  
There were five rows of seats, apparently arranged by height. The aisle and window-side rows had five seats each, while the center rows had six.  
Chizuru and Connie, exceptionally tall even for their class, sat side-by-side in the back row.  

When Yuu made eye contact with a girl he recognized in the center front row and smiled, she immediately blushed crimson and looked down. Fresh and adorable.  

Looking around, compared to the general course where appearance was part of selection criteria alongside personality, these were average-looking high school girls.  
Though some like Chizuru, Connie, Wakako, and Tamaki had beauty rivaling general course students.  
The class's average height likely exceeded Yuu's 170cm. As visible through their uniforms, all possessed well-trained physiques. A timid boy might have been intimidated.  

But Yuu knew from nine months of student council interactions.  
Whether due to innate personality or Sairei Academy's lady-like education, they were all good girls from a male perspective.  
Remembering how they'd devotedly cooperated for him since he joined the student council - perhaps because he was their only male connection - Yuu surveyed the entire third-year PE class before speaking.  

"Starting from April's Newcomer Welcome Orienteering through the athletic meet, quiz championship, sports festival, and Sairei Festival - these past nine months, I've truly been helped by all you sports club members. Especially after I became student council president and that weekly magazine article came out, when people trying to force their way into school surged, security must've been tough."  

When Yuu paused, some nodded deeply with bitter smiles, recalling those hardships.  
Though mobilized for security during events was tradition since co-edification, this year's sports festival and Sairei Festival were particularly burdensome.  
Yet no one openly criticized it as "extra work" - rather, they persevered with pride in protecting Yuu and other boys. That defined Sairei's sports girls.  
Yuu continued.  

"As student council president, I'm immensely grateful for all sports club members' cooperation.  
Now, while not every club is represented here, the PE class includes seniors who are club cores - captains and vice-captains. Since you're holding a Christmas party today, I, Hirose Yuu, came to repay you all directly!"  

"Waaaaaah!" The classroom erupted, chanting Yuu's name.  
While club representatives who'd attended student council meetings were accustomed, those who'd never directly conversed with him were overjoyed just by him speaking before them.  

Even for Yuu, seeing a whole class of girls expressing such frank delight was embarrassing. Their volume was typical of sports types.  
Considering the late hour, Yuu raised an index finger before his mouth. "Shhh." They immediately quieted.  
Seeing this, Yuu spoke somewhat shyly.  

"I wish I'd brought presents like Santa..."  
"It's fine! You coming here is enough!"  
"Yeah! Even if you couldn't attend the party, being with Yuu is all we need!"  
"Ugh... Truly..."  

Some were even moved to tears.  

"Hmm. I didn't plan anything... What should I do?  
If there's anything you want me to do, anything at all, tell me?"  
""""""An-anything!?""""""  

At those words, everyone stared hotly at Yuu.  
Some grinned foolishly while shaking their heads violently. What fantasies flashed through their minds in that brief moment?  

"Yes!"  

Wakako energetically raised her right hand and stood.  

"Proposal! Let's ditch formalities like grade levels and genders! How about no honorifics, just first names?"  

After a momentary pause, voices of agreement rose one after another.  

"That's great!"  
"Soccer club, well said!"  

During the Sairei Festival patrols, Wakako had mentioned this to Yuu. She clearly yearned to be called by first name by a close male friend.  

"If seniors are okay with it, I don't mind at all."  
"As expected, Yuu-kun!"  
"You're welcome. Wakako."  

Wakako smiled happily and sat down. Having already gotten Yuu's consent for first-name basis, she'd proposed this for classmates who'd never spoken to him - showing consideration worthy of a former soccer team captain.  
Yuu noticed a girl raising her hand slightly in the left front row. Petite with sleepy-looking narrow eyes and twin buns. She wore a light purple polo shirt and dark purple shorts uniform.  

"Um, you're..."  
"Table tennis club vice-captain, Wang Yuling. Japanese reading is 'O Urei,' but they said 'Yurin' is cuter. So call me Yurin."  
"Yurin... so cute!"  

She was a Hong Kong Chinese immigrant from the Republic of China (Nanjing Nationalist Government) - one of four divided Chinese mainland nations maintaining friendly ties with Japan.  
Yuu approached the seated Yurin and carefully patted her head without disturbing her buns.  

"Fweh!?"  

Startled stiff, Yurin soon closed her eyes blissfully, seemingly enjoying Yuu's touch.  

"Ahh! No fair, me too!"  
"Pat me too!"  
"Me!" "Me!" "Me!" "Me too!"  

Seeing so many hands raised, Yuu smiled wryly.  

"Haha. Okay. Then from the front in order."  

Yuu entered between the two aisle-side rows, using both hands to pat heads sequentially.  
Most had short or tied-up hair, though some had grown it longer since retiring.  

In his previous life, hair was considered a woman's crowning glory - not something men casually touched.  
But in this world, everyone delighted in Yuu's touch. Yuu too found touching girls' hair pleasant. Truly a win-win.  

After several minutes of simultaneous head-patting, he reached the tall girl in back. With a boyish buzz cut and 186cm height rivaling Chizuru, Baba Reiko had been volleyball team captain. Known as a demon captain who terrified juniors with her sharp rebukes, she became a different person before Yuu. Now she sat meekly enjoying his pats.  

"Ahh~ Being head-patted by a boy was my dream~"  

Few boys matched her height. Combined with her sharp eyes and perpetually angry appearance, she'd assumed any approach would scare boys away. Yuu alone spoke normally and willingly patted her head.  

"Hehe, you look happy, Reiko."  
"Un. Feels good, Yuu-kun."  

With no one in the left seat, Yuu placed his left hand on Reiko's shoulder while gently patting with his right. Reiko's eyes softened blissfully. Yet Yuu's gaze drifted to her body.  
Her sleeveless white uniform top clung tightly, clearly outlining her muscular shoulders and prominent bust. The red bottom resembled bloomers, revealing thick thighs. In short, the revealing outfit showcased Reiko's voluptuous physique.  

"U-um... Yuu-kun?"  
"What is it, Reiko?"  
"Eh, eh, um..."  

Usually looking down at others, now gazing up at Yuu felt novel, making her heart pound uncontrollably. Clasping her hands near her crotch, she fumbled for words.  

"Go ahead. Anything's fine."  
"Ah..."  

Yuu's patting hand slid to Reiko's cheek, feeling its heat and redness. His touch had already moistened Reiko's nether regions. As his fingers crept from cheek to mouth to chin, Reiko spoke with feverish expression.  

"Yuu...kun... I want... to hold you."  
""""Whoa whoa whoa!""""  

Nearby seats reacted, but Yuu just smiled.  

"Is that all? Easy enough."  
"R-really!?"  
"Un. But how?"  
"Here, here!"  

Still seated, Reiko scooted her chair back and patted her thighs - indicating she wanted Yuu on her lap, not vice versa. Given their height difference, this made sense.  
After slight hesitation, Yuu nodded, turned sideways, and sat on Reiko's left thigh.  

"Not too heavy?"  
"N-not at... all..."  

With Yuu on her lap, their faces drew close despite his slightly higher position. Actually having him there flustered Reiko more.  
Yuu then wrapped his left arm around Reiko's back, drew his face near her ear, and whispered:  

"It's okay, don't hold back."  
"Hyai!"  

Reiko's right arm encircled Yuu's back. Her large bust pressed against him - not over her heart, but her pounding heartbeat was palpable. Yuu extended his right hand and interlaced fingers with Reiko's left.  

"Ugh, jealous..."  
"Lucky..."  
"Hmm. Strongly agree."  

The whole class watched Yuu being held. A boy who smiled at every girl, talked casually, and touched them - especially their idolized student council president. Seeing a classmate holding Yuu ignited their suppressed desires.  

Meanwhile, Reiko grew unusually excited with Yuu's face near her neck. Holding a boy on her lap was every large-framed girl's unfulfilled dream. Now embracing Yuu, experiencing him up close - was this dream or reality? Savoring his male body with all senses, her consciousness grew hazy as desire spilled out.  

"Haa, haa... Yuu-kun, Yuu-kun, you smell so good, suuhaa, suuhaa. Afun! Can't stand it! Fuu, fuu, love love I love you! Chu, wanna kiss. Wanna lick... hah!"  

Suddenly regaining awareness, Reiko panicked. Releasing their joined hands, she covered her mouth. Realizing she'd vocalized her thoughts, cold sweat dripped down her back as her face turned lobster-red.  
Certain she'd repulsed him, Reiko timidly looked up - just as Yuu's face approached, stunning her.  
Yuu's right hand avoided her covering hand and sealed her half-open lips.  

"Ngeh!?"  

Reiko froze at the suddenness. Classmates watched speechlessly. Amidst this, Yuu - having heard her wish - enjoyed the kiss.  
After pressing lips firmly, he slipped his tongue inside since her mouth was open.  

"Nmo? Ah... nhyu... un..."  

The moment tongues touched, a tingling sensation shot through Reiko's head, her whole body trembling with newfound ecstasy.  
Initially letting Yuu's tongue roam freely, she soon entwined hers with his.  

"Nn, nmuaa... julu, chupu... un, ero, rehro, afu... chupa, ann, nuumu..."  

About two minutes passed since they began deep kissing while tightly embracing.  
When they slightly separated with tongues still out, multiple saliva strands connected them.  
This time Reiko initiated, sliding her tongue into Yuu's mouth.  
Even before full lip contact, their overlapping tongues made wet smacking sounds.  

Everyone watched silently, breath bated.  
Some even pressed their thighs together while clutching their crotches.  
Finally noticing the stares, Yuu broke the kiss.  
Smiling, he declared:  

"Want me to kiss everyone?"  
""""""Y-yeessssssssssssss!""""""  

The hearts of the third-year PE class became one in that instant.  

  

  

  

---

### Author's Afterword

I finally started Twitter. Name is "遼魔@ノクターンノベルズ" (Ryoma@Nocturne Novels).  
I made the account last month but left it idle, but decided to use it for Nocturne.  
I'd be happy if you casually share impressions or ideas.  
However, while I always reply to Nocturne's comment section, I haven't decided about Twitter yet.  


### Chapter Translation Notes
- Translated "プリーズキスミーマイサンタクロース" as "Please Kiss Me, Santa Claus" to preserve the playful English phrase in the original title
- Rendered "中華民国（南京国民政府）" as "Republic of China (Nanjing Nationalist Government)" per Fixed Reference consistency
- Translated "夢か現(うつつ)か" as "dream or reality" while preserving the furigana wordplay in parentheses
- Kept "ユリン" as "Yurin" following character's stated preference
- Used "deep kiss" for explicit tongue play descriptions as per explicit terminology rule
- Maintained Japanese sound effect transliterations (e.g., "Waaaaaah", "Fweh", "Chupa")
- Preserved first-name basis transition without added honorifics when characters drop formalities
- Translated "ブルマー" as "bloomers" for culturally specific gym attire
- Rendered internal thoughts in italics without asterisks per formatting rules (e.g., *Groups of women seemed terrifyingly...*)