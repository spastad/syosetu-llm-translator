## 298. Christmas Party ⑥ ~Ever-Sweet Lips~

### Author's Preface

The following are the third-year PE course students who have appeared up to the previous chapter in the Christmas party arc.

Name, height, and club they belonged to until retirement:

Shiina Chizuru (椎名 千鶴): 187cm, Basketball Club  
Constance Wilson (nickname Connie): 192cm, Basketball Club  
Fujieda Wakako (藤枝 和歌子): 175cm, Soccer Club  
Sofue Tamami (祖父江 珠美): 182cm, Softball Club  
Yabue Tamaki (藪江 環希): 165cm, Baseball Club  
O Urei (王雨玲, nickname Yurin): 152cm, Table Tennis Club  
Baba Reiko (馬場 礼子): 186cm, Volleyball Club  
Sakata Cristiano (坂田 クリスティアーノ): 177cm, Soccer Club →New!  
Nagaki Riku (長城 莉玖): 158cm, Track and Field Club →New!  
Yawaki Michie (矢脇 美知恵): 166cm, Judo Club →New!  

In the previous chapter, Yuu enjoyed the girls' breasts, but this time the roles are reversed?

---

"Could you all return to your seats for a moment? I still want to do more fun things with everyone."

Yuu, who had been holding Connie as she went limp from his caresses and reached orgasm, looked around as he spoke.  
Without anyone noticing, the girls who had gathered nearby reacted immediately.  
The eight girls who had enjoyed the fresh cream Yuu applied to their breasts earlier ranged from A to G and I cups.  
Those not chosen had shared strawberries via mouth-to-mouth feeding, but with so many, some had settled for light kisses in turn.  

Having witnessed not only Yuu kissing every girl but also sucking breasts to induce orgasms—an experience beyond common sense—everyone's hearts raced with excitement about what Yuu would do next for the girls in this classroom.  

"Phew~. It's getting hot, isn't it?"  

As he returned to the teacher's podium, Yuu loosened and removed his tie, then began unbuttoning his dress shirt from the top.  
Everyone who had returned to their seats stared at Yuu with expressions of surprise.  
By the time he reached the podium, most buttons were undone, revealing a white T-shirt underneath.  
A *gokuri* gulping sound could be heard from someone.  

*In my past life, I would have thought it was just a guy taking off his shirt down to a T-shirt.*  
*But in this world with reversed chastity values, the value of underwear is also reversed.*  
*I now know it's equivalent to a high school girl taking off her uniform top and showing her bra in a boys' classroom.*  

Thus, as Yuu removed his fully unbuttoned dress shirt and stood in his white T-shirt, everyone stared at him unable to hide their excitement.  
Facing these girls with an unwavering smile, Yuu took off even his T-shirt.  

"Ooooh!" A stir shook the classroom.  
From the back, many instinctively rose from their seats.  
That they managed not to charge at Yuu—instead covering their mouths or chests, taking deep breaths, and sitting back down—was a testament to Sairei Academy girls.  

Yuu's upper body, which had been skinny until middle school, was still in its growth phase. Combined with nearly nine months of training at home and the training center, he had developed considerable muscle.  
Compared to the girls here who had trained for years as athletes, his muscle mass might be less, but from their perspective, it was a body beautiful enough to admire.  

Yuu opened the box of another cake on the podium.  
Even shirtless, Yuu showed no shyness, but being stared at by 28 high school girls, he spoke with a hint of embarrassment.  

"Okay. Now it's everyone's turn."  

The girls, who had been letting their eyes wander over Yuu's exposed shoulders, chest, stomach, sides, and arms, were dumbfounded by his words.  

---

First, five girls from the hallway-side row came out and surrounded Yuu.  
Each had scooped a dollop of cream onto their fingertips.  

"Go ahead. Don't hold back."  
"Waha... Really, is it okay?"  
"Yeah. Anywhere you like."  
"Th-then... I'll..."  

The first to approach Yuu's chest was Taiga Misao (太賀 美沙緒), former captain of the gymnastics club.  
She was about the same height as Yuu, and even through her skin-tight leotard, her developed muscles were visible. She did apparatus gymnastics, not rhythmic gymnastics.  
But rather than bodybuilder-level bulk, her physique showed well-balanced beauty.  
Misao, with her hair in a bun and slightly upturned eyes in a well-proportioned face, expressed her excitement as she dabbed cream onto Yuu's nipple.  

"Fuu, fuu, fuu... I-I'll have some!"  

Seeing the cream about to slide off his nearly vertical chest, Misao frantically latched onto Yuu's chest.  

"Nngh!"  
"Uh, are you okay?"  
"I'm fine. Don't worry, just lick."  
"Th-then... *chu*"  

By then, the other four girls, seeing Misao's actions, began to imitate. Each chose a spot on Yuu's upper body to apply cream and brought their mouths close.  
That is, following Misao, Wakako went for his chest. Two more took positions on his back.  
With two in front and two behind, the last one, Michie, crouched in front of Yuu after hesitating—apparently choosing his stomach.  

"Ugh! That tickles... Ah, fah! Ngggh!"  

Being licked in five places simultaneously, Yuu couldn't help but let out strange sounds. His nipples being sucked on was a particular weakness.  
The cake smeared on his skin had already been licked clean, but Misao and Wakako showed no sign of stopping.  
Naturally so. The chance to directly lick a young boy's skin was a once-in-a-lifetime luck. Even if they went to a brothel, they probably wouldn't be allowed to do this much.  

Of the two who had moved behind him, one seemed to trace her tongue along his shoulder to the nape of his neck, while the other went up and down along his spine.  
Before long, Yuu's lowered hands were grabbed by the two in front and the two behind.  
Michie, who had been licking his stomach, grabbed Yuu's thighs and obsessively licked around his navel. After making it drool-soaked, she gradually moved down toward his belt.  
Like a mother cat grooming her kitten or a dog jumping on its beloved owner to lick their face—or with even more enthusiasm—she licked all over Yuu's skin.  

"Hey. That's enough already!"  
"Yeah, yeah!"  
"We demand a change!"  

The classmates who had been watching Yuu squirm from their seats finally raised their voices in impatience. It seemed over five minutes had passed.  

"Haa, haa... Should we switch now?"  
"Ah... I got too carried away."  
"Y-yeah, that's right. Sorry, Yuu-kun."  
"It's fine. Thank you, everyone."  
""""""!!!!!""""""  

Misao and the other four were astonished.  
They were the ones who should be grateful after acting like perverts, licking him in a frenzy, yet he was thanking them.  

"Aahn! Yuu-kun! You're wonderful!"  

Misao hugged him tightly, and Yuu nearly fell over, supported by the two behind him.  
Before the class girls who had waited long enough got angry, Yuu kissed each one before letting them go.  

Then, six girls from the next row came forward.  
Their eyes were gleaming, cheeks flushed, not even trying to hide their excitement.  
Perhaps it was because they saw Yuu's cheeks reddening from being aroused.  
From then on, a time limit of seven minutes per row was set, and Yuu surrendered himself.  

---

"Haa, haa, haa... kuh..."  

Face, neck, shoulders, arms, armpits, chest, stomach, even his back.  
Yuu was licked continuously by six girls.  
Even though it was only his upper body, having sensitive spots like nipples, sides, and nape persistently licked made him involuntarily moan.  
With six girls, there weren't enough spots, so some transferred cream mouth-to-mouth, leading to deep kisses, or sucked on his fingers.  
Seeing Yuu squirm, some girls from the seats had already thrust their hands between their legs and begun diligently pleasuring themselves, but no one scolded them. Rather, others imitated and started masturbating.  

The third row finished, and after kissing each in turn, they returned.  
As the fourth row of six stood to leave, Yuu approached them.  
By chance, Riku in the front row followed Yuu's face down with her eyes and widened them in surprise. She noticed the prominent bulge in his crotch area.  
Though he wore dark gray slacks, up close it was noticeable.  
Under such gazes, Yuu stepped between the two rows by the window and looked left and right.  

"Next, I have a request for all the girls in these two rows."  

Saying this, Yuu began unbuckling his belt with a *kachakacha* clattering sound.  

---

Yuu lay naked on his back atop four desks arranged lengthwise.  
Using the entire other cake, the 11 girls from the two window-side rows had decorated most of his body's surface.  
On his face, dollops of whipped cream remained on his forehead, nose, cheeks, and chin. His throat had a thin layer of cream, starting from his Adam's apple.  
His chest had a piece of sponge cake placed directly on it, with strawberries dotted around, including on his nipples.  
His erect cock was carefully coated with cream and adorned with crushed chocolate pieces.  
Both legs were meticulously covered with cream down to the tips.  
At their request, his arms were stretched above his head, and even his armpits were smeared with cream.  

"Waaaah... It's so erotic."  
"Somehow, artistic yet immoral."  
"Nn. I want to take a photo and treasure it at home."  
"It's only because it's Yuu-kun that it looks so picturesque."  
"More importantly, only Yuu-kun would let us do this."  
"Definitely."  

Even in a world with reversed chastity values, human thoughts aren't so different—there exists a play called "male body plating" as a counterpart to "female body plating."  
However, that was only in fictional worlds.  
In any case, not just the 11 girls who had decorated Yuu's body, but all the other classmates watching from a distance fixed heated gazes on him while chattering.  

"Trying it out is kind of embarrassing... but I hope you enjoy it?"  

Yuu asked, trying not to move his face, and Chizuru, standing near his head, answered.  

"Yu, Yuu-kun... It's the best... Th-then, for the finishing touch. Open your mouth a little."  
"Mmm."  

Chizuru took a remaining strawberry and placed it in Yuu's half-open mouth.  
The male cake plating of the student council president was complete.  
Faced with Yuu's nakedness, it wasn't just Chizuru who couldn't contain her excitement—everyone surrounding him felt the same.  
Chizuru looked around at her classmates encircling Yuu. Everyone had the expression of a carnivore before prey. They couldn't hold back any longer. All that remained was the signal.  
When Chizuru looked down at Yuu's face, he gave a slight nod since he couldn't speak with the strawberry in his mouth.  

"Well then."  
""""""Bon appétit!""""""  

The 11 girls voraciously attacked the cake adorning Yuu's body.  

"Nngh! Nngh! Fo... nam... elo, eloo... amchu, chupa, chupa, hafoo... nnaah! Ah! Nngh!"  

First, Chizuru, who had just placed the strawberry, was the one to voraciously latch onto Yuu's lips.  
She bit the strawberry in half, pressing her lips wetly against his. Excited, Chizuru kept her mouth open and invaded Yuu's mouth with her tongue, practically forcing him to swallow the chewed strawberry mixed with saliva.  
Of course, Yuu didn't resist.  
After swallowing the mixed saliva with the strawberry, he actively intertwined his tongue with Chizuru's.  

The girls surrounding Yuu near his face, chest, stomach, and legs—each pair from left and right—devoured the cake with fierce intensity, then meticulously licked the cream remaining on his skin.  
He was being licked all over simultaneously.  
While his mouth was being ravaged by Chizuru, muffled sounds escaped him. His body nearly convulsed, but his limbs were firmly held.  
Riku, though small and slender, firmly held Yuu's feet and licked the tips.  
The cream on both legs had been licked off by the three girls near his lower body.  

"Wahaa... This is Yuu-kun's cock..."  
"Amazing! So big! I've never seen anything like it even in AVs!"  
"Ufufu, it's so splendid and hard!"  
"Wh-what would happen if this... went inside a pussy...?"  

Though his penis had been thickly coated with cream and chocolate until its original shape was unrecognizable, being licked by four girls had revealed more than half of it.  
One of them, Tamaki, poked the glans curiously with her finger, and a drop of clear fluid dripped down.  
Startled, Tamaki stuck out her tongue and licked up the pre-cum. As if wanting more, she sucked on the urethra.  
As if that were a signal, the remaining three began licking the chocolate and cream from the coronal ridge, shaft, and testicles.  

"Ugh! Ah, ah, that feels good... haa!"  
"Yuu-kun, so cute, so cute!"  

Chizuru, watching Yuu writhe and moan aloud as his crotch and entire body were sucked, gazed enraptured while licking the saliva around her mouth.  
Her left hand firmly held Yuu's right hand stretched above his head.  

"Basketball club! You're already privileged with guard duty, so give up your turn at his mouth!"  
"Mu, fine."  

The one who spoke in a ladylike tone from the opposite side of Chizuru was Koda Miwako (幸田 美輪子), former captain of the hard tennis club.  
She was slightly taller than Yuu. To amateurs, tennis might seem elegant, but it actually requires intense physical exertion, especially developing shoulder muscles.  
Miwako, who served as captain with top-tier achievements in tournaments, was no exception—her shoulders appeared sturdy. Her breasts were fairly large, around D-cup, with a toned physique.  
However, upon retirement, she dyed her long black hair brown and got loose perms. With makeup applied, she now had a flashy appearance. Though her speech was ladylike, her looks were more like a gal or hostess.  

"Now, Yuu-sama. Shall we recreate that passionate kiss from earlier?"  

Having taken over from Chizuru, Miwako licked off the cream remaining around her mouth but, without swallowing it, approached Yuu with her tongue out.  

"Haa, haa... Mi, Miwako... I also want to do lots of tongue kisses with Miwako."  
"Ufufu!"  

Her eyes shining at his words, Miwako thrust her tongue deep into Yuu's open mouth.  

"Nngh, nmo... ofu... maa... oo, oo, ugh! Igh... mmph"  

Now having his mouth ravaged by Miwako, Yuu let out muffled moans while trembling.  
Over ten minutes had passed. With 11 girls toying with his entire body, he had been tossed by intense pleasure and was nearing his limit.  

"His cock is twitching."  
"Could it be?"  
"Yuu-kun, do you want to cum?"  
"We'll make you cum!"  
"I-I'm cumming... ngh!"  

Hearing that, the two near his chest sucked his nipples even more vigorously.  
They must have learned from AVs or such. The two overlapped their hands and began jerking him off rapidly while taking turns sucking his balls.  
Tamaki and another girl sucked on the glans and coronal ridge from left and right, using their entire mouths to stroke him.  
Riku held his feet and licked them obsessively until they were drool-soaked.  
Chizuru caressed the inside of his ear with her tongue.  
Miwako, having pulled away from his mouth, stuck out her tongue and connected with Yuu's as he panted with his tongue out.  

"Gwaah! Ah! Igh!"  

His cock trembled violently, then he ejaculated profusely.  

"Huh?"  
"Wah!"  
"It came out!"  
"Amazing!"  

The two who had been leaning in to lick his nipples turned their faces toward his crotch just as the semen spurted out, splattering onto them.  
Though startled by the thick globs sticking to them, their expressions softened.  
Of course, the semen continued to spurt out in rapid bursts, also hitting the faces and hands of Tamaki and the others near his cock.  
With enraptured expressions at seeing real semen for the first time, they hesitated not at all to put it in their mouths.

### Chapter Translation Notes
- Translated "おっぱい" as "breasts" for consistency with explicit terminology rule
- Translated "チンポ" as "cock" to maintain explicit anatomical terminology
- Transliterated sound effects: "ごくり" → "gulping sound", "ちゅっ" → "*chu*", "ぺろり" → "licked off", etc.
- Preserved Japanese honorifics: "祐君" → "Yuu-kun"
- Translated internal monologues in italics as per style guide
- Used explicit terms for sexual acts: "手コキ" → "jerking him off", "射精" → "ejaculated", etc.
- Maintained original name order for Japanese characters (e.g., "Taiga Misao")
- Translated "男体盛り" as "male body plating" as defined in Fixed Special Terms
- Handled simultaneous dialogue with double quotes: `""""""Bon appétit!""""""` for 11 girls speaking together