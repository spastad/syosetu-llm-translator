## 299. Christmas Party ⑦ ~The Promise Called Love~

### Author's Preface

These are the third-year PE course students who have appeared up to the previous chapter in the Christmas Party arc.

Listed in order: Name・Height・Club belonged to until retirement.

Shiina Chizuru (しいな ちづる) 187cm Basketball Club  
Constance Wilson (nickname Connie) 192cm Basketball Club  
Fujieda Wakako (ふじえだ わかこ) 175cm Soccer Club  
Sofue Tamami (そふえ たまみ) 182cm Softball Club  
Yabue Tamaki (やぶえ たまき) 165cm Baseball Club  
O Urei (おううれい) (nickname Yurin) 152cm Table Tennis Club  
Baba Reiko (ばば れいこ) 186cm Volleyball Club  
Sakata Cristiano (さかた クリスティアーノ) (nickname Chris) 177cm Soccer Club  
Nagaki Riku (ながき りく) 158cm Track and Field Club  
Yawaki Michie (やわき みちえ) 166cm Judo Club  
Taiga Misao (たいが みさお) 171cm Gymnastics Club →New!  
Koda Miwako (こうだ みわこ) 174cm Hard Tennis Club →New!  

Initially planned for about 10 new named characters (from Tamami onward), but likely to exceed.

---

Being surrounded by so many girls and having my entire body licked clean feels this good?  

Since being reborn in this world, Yuu had experienced this several times, but it still felt like ascending to heaven.  

After ejaculating, Yuu remained dazed for a while as the 11 girls continued covering his entire body with kisses, licks, and caresses. But eventually, protests came from waiting classmates and it ended.  

Without regard for order, girls rushed forward first-come-first-served, wiping his entire body with damp towels. Throughout this, his cock remained erect.  

Over two hours had passed since entering this classroom, and it was past 10 PM.  

Taking a break, Yuu drained the drink poured for him.  

The girls in class were nearly half-naked.  

Athletic PE girls surrounded Yuu in this indecent state. Wherever he looked, exposed skin was visible, leaving no chance for his crotch to calm down.  

When one girl begged him to take her virginity, others followed suit, nearly causing chaos until he managed to calm them.  

"But Yuu-kun, even for you, handling this many people..."  
"Then should we draw lots?"  
"Or battle royale with the winner deciding?"  
"Hah? Just because you're in judo club, don't get cocky or you'll regret it!"  
"What was that?"  
"You wanna go?"  
""""Now, now...""""  

"I'd like to do it with everyone. If you're all okay with it, that was my intention."  
""""""Eh?""""""  

Except for Chizuru and Connie who already had experience, all 26 had lived school lives without male contact. Yuu as student council president was their sole exception.  

Thus their determination to seize this chance was immense.  

As Michie from judo club and Tamaki from baseball club glared at each other, others tried to mediate. Yuu's statement froze everyone.  

Yuu, who had been sitting on a desk, pushed through the girls and simultaneously embraced Michie and Tamaki.  

""Ah!""  
"Hey, no fighting in front of me. Please?"  
"Yu, Yuu-kun... Annnh!"  
"So, sorry... For showing such an unsightly scene in front of... Ooooh!"  

Both Michie and Tamaki had magnificent muscular physiques with large breasts.  

Pressing them against his sides, Yuu reached under their arms to grope their ample breasts. Both were slightly shorter than Yuu, placing his hot, hard meat rod right at their waist level.  

Michie and Tamaki, who had been glaring moments ago, now felt not just Yuu's naked body heat but the hardness and heat of his penis, their cheeks flushing pink.  

"Understand now?"  
""Unnh!""  

When Yuu whispered in their ears, they replied in completely changed voices, nodding repeatedly.  

""""Yuu-kun!""""  
"Whoa! Wait. Will you listen to me first?"  
"Come on now—listen to Yuu-kun!"  

Having pushed through the crowd, Yuu was surrounded. Just as he was about to be mobbed, he raised his voice.  

Some who were completely aroused tried to cling forcefully, but relatively calm members like Chizuru, Connie, and Wakako managed to pull them away.  

"All of you in the PE course aim for athletic careers after graduation, right?"  

Yuu sat on the desk where he'd been lying moments before. The 28 PE girls stood in a semicircle about 2 meters away.  

Their eyes continued devouring Yuu's naked body, especially his crotch, but they seemed calm enough for conversation. All nodded affirmatively at Yuu's question.  

For example, Chizuru had secured recommendation to a nationally famous sports university. Her dream was to become a teacher. Connie had an informal offer to join a major beverage company's Saitama branch basketball team.  

All had been core members of athletic clubs for three years with proven results. Their paths were set—either sports universities or corporate teams.  

Though none would immediately become top professionals, some might become Olympic candidates in a few years.  

"As I said earlier, I want to have sex with all of you here."  

Cheers of "Waaah!" erupted, but Yuu interjected, "But..."  

"28 people might be impossible."  
"Right..."  
"Then let's fairly draw lots?"  

Even after ejaculating once, his continued erection was already abnormal. But (except Chizuru and Connie) these inexperienced girls accepted the reality before them over their limited knowledge.  

"No, I'll try to have sex with everyone as long as my stamina holds. I don't know how many times I'll ejaculate. What worries me is the high pregnancy risk if I cum inside."  

Finally understanding Yuu's meaning, they fell silent.  

Having dreamed of becoming pros since childhood, they'd prioritized athletics over men. Now an unexpected chance had fallen into their laps.  

If they received Yuu's seed and got pregnant, they could grasp feminine happiness. But they'd be sidelined from athletics for over a year.  

Trained since childhood that skipping one day of practice required days to recover, these 18-year-olds were approaching their athletic peak. A year-long gap would be devastating.  

Normally, pregnancy from one sexual encounter would be unlikely. But Yuu had impregnated multiple women with single encounters—resulting in nine pregnancies in Class 1-5 and special priority class designation.  

"Ugh... But... But... With my adored Yuu-kun..."  
"I don't think I'll ever meet a boy better than Yuu-kun after graduation. Let alone get close."  
"Even if someone gets pregnant, it'd be just one, right? Then..."  

At this point, most leaned toward having sex with Yuu despite pregnancy risks, even if it meant pausing athletics.  

Conversely, imagine a virgin male high schooler getting a chance to lose his virginity with the school's idolized beauty—but with a 1/28 chance of abandoning childhood dreams to become a husband raising (someone's) child. For teenage girls, suppressing sexual desire was harder.  

Yet abandoning their hard-trained athletic dreams was also unthinkable. Watching the troubled girls, Yuu spoke.  

"So I have a proposal..."  

Yuu's proposal: He'd penetrate everyone but not ejaculate inside. When close to orgasm, they'd make him cum with handjobs or blowjobs. Specifically, he'd take them row by row as with the cake, ejaculating once per row. He intended to manage five times.  

Everyone was stunned speechless at the idea of five more ejaculations. If Yuu said he could, maybe he could—but those with any male knowledge wore disbelieving expressions.  

Then Yuu made another proposal with a triumphant expression.  

"Anytime—10 or 15 years later—after retiring, if you want a child but lack a partner... I'll provide my seed. To everyone in this classroom."  
""""""Eh?""""""  

After a stunned silence, they grasped the immense meaning. Having Yuu available later was huge. None had ever seen a man with such broad-minded generosity.  

"Waaahhh! Yuu-kun! So kind and wonderful!"  
"My first love and eternal idol!"  
"I'll definitely go pro, earn tons, and give it all to Yuu-kun!"  
"Wawawa!"  

Over ten girls rushed at Yuu, sobbing. Instead of avoiding them, Yuu welcomed them head-on.  

Smiling as half-naked girls pressed against him from all sides, he patted their heads one after another.  

"Now then, tonight I'll have sex with everyone!"  
""""""Unnh!""""""  

Desks and chairs were moved to clear space in the classroom center. The floor was cold this season, so cardboard was laid down—but not just that.  

"Having Yuu-kun lie on us would be our honor!" Two judo club members stripped off their uniforms and spread them in the center. Others followed suit, creating a colorful bedding of mainly white uniforms.  

Yuu lay supine on them.  

Surrounding Yuu were the first row from the hallway side, ordered by height:  

Hoshimi Aki Softball Club  
Yawaki Michie Judo Club  
Taiga Misao Gymnastics Club  
Fujieda Wakako Soccer Club  
Ashina Karin Track and Field Club  

All five were naked, having removed even their underwear.  

By seating order, Aki—at the front—waited nervously at Yuu's feet. Aki had been starting catcher until summer tournaments—essentially Tamami's "wife."  

Typical catcher build: overall plump with powerful lower body. Short hair, plain face, but self-reported E-cup breasts—impressive bowl-shaped mounds.  

"Yu-yu-yuu, Yuu-kun! Is... is it okay now!?"  
"Don't be so nervous. Relax, relax."  
"U, unnh!"  

Aki was tenser than during her final summer tournament softball game. After all, this was the sexual experience she'd given up on—and with Yuu, whom every schoolgirl adored. Asking her not to tense up was impossible.  

Seeing this, Yuu raised his upper body and extended both hands.  

"Come here, Aki"  
"Fweh? Waaah!"  

As Aki crawled forward on all fours from his feet, Yuu grabbed her hands and pulled her in. She ended up clinging to him, pushing him down.  

"Yuu... ku...n? Ah, it's touching... uunnmm!?"  

Straddling Yuu with legs spread, their genitals touched—inadvertent sumata (dry humping). Whether from earlier masturbation or pre-virginity-loss excitement, Aki's privates were slippery wet.  

Holding Aki from below, Yuu enjoyed the feel of her ample breasts against him while pulling her head down for a kiss, immediately inserting his tongue to ravage her mouth.  

"Nmmph! Nn... nn... churu, chu, chuparelo... oh, kufu... haa, haa, anmmph! Nnnnnnnnnnnnnnnnnnnnnnnn!"  
"Kufuu. See? My cock's touching your pussy, right? Just shift your hips forward a little... There. Like that. Nn, a bit more. There... oh, it's going in!"  
"Kwaah! This is... aahhh! Going in... aaaaaaaah! Ku, ku, kuruu!"  

Supporting Aki's large buttocks, Yuu assisted penetration.  

With a *nupuri* sound, her vaginal entrance swallowed his glans.  

"O... ohh! Kkuu! Amazing tightness!"  
"Hae... lie? Waaah! This... this... aahhh! So big... faaaaaaaah!"  

Though virgins, intense sports or toy masturbation had broken their hymens. Confident in her libido, Aki had vigorously masturbated with vibrators.  

She knew Yuu's cock was bigger than her favorite vibrator, but seeing and taking it differed completely. Meanwhile, having taken many virgins, Yuu groaned at experiencing Aki's well-trained vaginal walls despite her plump appearance.  

"Not done yet. Only half in."  
"Aaihh! W, wait! Annnh!"  
"Here, together."  

Yuu gripped her large buttocks and pushed. Clinging to Yuu, Aki shifted her hips slightly to continue penetration. Resisting vaginal pressure that pushed back against the foreign object, the cock gradually invaded deeper.  

""Oh!""  

Their voices overlapped when reaching the deepest point.  

"D, doesn't it hurt?"  
"N, not at all... rather... Yuu-kun's... feels good... this cock... ahhaa..."  
"Fufu. Good. Congratulations on losing your virginity."  
"Yuu-kun!"  

Aki clung tightly, mashing her lips against his. Though not moving her hips, this suited Yuu—the pleasure upon deepest penetration was so intense that moving might make him cum.  

Overwhelmed by connecting with Yuu, Aki forgot to move her hips and just passionately kissed him while lying atop him. But she couldn't monopolize Yuu here.  

"Ho-ra, next person's turn!"  

After about five minutes joined together, Aki's body was mercilessly pulled away by four hands waiting their turn.  

Girls took turns straddling the supine Yuu for penetration. To outsiders, it might look like gang rape. But for Yuu, it was bliss to taste multiple virgins consecutively.  

The second girl, Michie, barely endured.  

In a position resembling yokoshihogatame (side four-quarter hold), Michie began slowly rocking her hips over Yuu when the three waiting girls pulled her off. Michie resisted but couldn't overcome three people's strength.  

Then the third girl, Misao, tried straddling Yuu. Seeing the carnivorous-eyed Misao dripping vaginal fluids as she lowered her hips, Yuu felt danger.  

The moment of penetrating a virgin felt unbelievably good. Experiencing it consecutively, he could climax anytime.  

"Yuu-kun, Yuu-kun! I, I'm putting it in?"  
"Okay, Misao"  
"Ahh... the moment I've dreamed of!"  

Spreading her legs wide, Misao lowered her hips. Yuu cooperated, aligning their genitals perfectly.  

"Kwaah! Nn... mmph... nnnn! Uuuh!"  

As her vaginal entrance swallowed the tip, Misao covered Yuu's mouth with hers. Even trying to accept Yuu's cock, it wouldn't go in smoothly—same for anyone.  

Misao sealed Yuu's mouth, moaning muffledly while forcibly lowering her hips to insert it. Despite some pain from extreme tightness, Yuu felt an all-over stroking sensation.  

Misao only frowned initially at the size and hardness of her first real cock. Now consumed by carnal desire to fully savor Yuu's cock, she forcefully lowered her hips to complete insertion. When Misao thrust fully deep, paralyzing pleasure shot through Yuu's lower back.  

"Misao! I'm... gonna cum like this!"  
"Annh, annh! For the first time... this, this, I... love this cock! Can't stop! Cumming from this cock, cumming from this cock! Cumming! Cumming! Aaaaaaaaaaaaaaaaaaah!!!!!"  

As Yuu ejaculated, Misao's violent hip movements made him slip out. Thus, instead of inside, semen sprayed over her gaping vaginal entrance and surrounding area.  

### Chapter Translation Notes
- Translated "素股" as "sumata (dry humping)" with transliteration and English explanation for culturally specific term
- Preserved Japanese club names (e.g., "柔道部" → "Judo Club") as per academic term precision rule
- Translated sexual sounds literally: "ぬぷり" → "*nupuri*", "ばちゅん" → "*bachun!*"
- Maintained explicit anatomical terms: "チンポ" → "cock", "おマンコ" → "pussy"
- Rendered sexual acts without euphemisms: "中出し" → "ejaculate inside", "手コキ" → "handjob"
- Kept Japanese name order: "星海 愛生" → "Hoshimi Aki"
- Italicized internal monologue: "（体力が続くかぎり...）" → "*I'll try to have sex with everyone...*"
- Preserved honorifics: "祐君" → "Yuu-kun"
- Used simultaneous quotes formatting: "「「「うんっ！」」」" → """"""Unnh!""""""