## 300. Christmas Party ⑧ ~Christmas Love (After Tears, White Semen Falls)~

### Author's Preface

Third-year PE course students who have appeared up to the previous chapter in the Christmas Party arc.

Name・Height・Club affiliation before retirement:

Shiina Chizuru (椎名 千鶴) 187cm Basketball Club  
Constance Wilson (nickname Connie) 192cm Basketball Club  
Fujieda Wakako (藤枝 和歌子) 175cm Soccer Club  
Sofue Tamami (祖父江 珠美) 182cm Softball Club  
Yabue Tamaki (藪江 環希) 165cm Baseball Club  
O Urei (王雨玲) (nickname Yurin) 152cm Table Tennis Club  
Baba Reiko (馬場 礼子) 186cm Volleyball Club  
Sakata Cristiano (坂田クリスティアーノ) (nickname Chris) 177cm Soccer Club  
Nagaki Riku (長城 莉玖) 158cm Track and Field Club  
Yawaki Michie (矢脇 美知恵) 166cm Judo Club  
Taiga Misao (太賀 美沙緒) 171cm Gymnastics Club  
Koda Miwako (幸田 美輪子) 174cm Hard Tennis Club  
Hoshimi Aki (星海 愛生) 161cm Softball Club →New!  
Ashina Karin (芦名 花凜) 179cm Track and Field Club →New!  

I thought I could wrap it up neatly at 300 chapters, but it wasn't possible. The next chapter will be the finale of the Christmas Party arc.

---

Honestly, I might have underestimated the sexual desire and obsessive persistence of virgin athletes. Or perhaps it should be said that despite having ejaculated once already, Yuu couldn't withstand the incredible tightness.

That he barely avoided internal ejaculation was due to Misao being inexperienced and coincidental timing, but for her, she might have been happier if he had ejaculated inside.

At any rate, to keep his promise, Yuu decided to change his approach. Specifically, from now on Yuu would take the initiative during insertion, having the girls get on all fours and line up with their buttocks facing him.

Currently exposing her beautifully toned body before Yuu was Wakako, former captain of the soccer club. When you think of soccer players, you might imagine thick legs and a sturdy lower body. But Wakako was tall with lean muscle and a well-proportioned figure. The thought of entering her from behind made Yuu's excitement soar.

Since Aki, Michie, and others had forcibly moved Misao aside and eagerly licked his freshly ejaculated cock, it was now standing vigorously erect again. Yuu pressed his engorged member against the cleft of her upturned buttocks.

"Sorry to keep you waiting, Wakako. I'm going in?"  
"Y-Yuu-kun... p-please, hurry... I want it"

Seeing Wakako look back at him with a melting expression, Yuu gradually lowered his cock still pressed against her buttocks. With her legs spread wide, he could see her moist pussy gaping open, waiting for his cock. Adjusting the angle with his right hand, he pressed the tip against her entrance with a *kuchuryi* wet sound.

As he pushed his hips slightly forward, the entire glans was swallowed inside with a *zuburi* sound. Yuu grabbed her beautifully defined waist with both hands and thrust powerfully forward.

"Nghaa! Yuu...kun! O-oh, your cock...!"  
"Nggh, still tight as expected. But!"  
"Gyaaaah! I-It's in... ah, ah, ahi!"

Even though her hymen had been broken beforehand, she was still an 18-year-old virgin receiving a man's member for the first time. Insertion took time. But the pleasure when he thrust deep inside was beyond measure.

"Ah, ah, aaaah... Wakako's pussy... feels unbelievably good"  
"Iiih... ugh... m-my insides... filled with Yuu-kun... aha. This is... having a cock inside me..."

For a moment, Yuu remained still with his cock buried deep, savoring Wakako's virgin pussy. Partly because the tightness made movement difficult, but also because if he got carried away and thrust, he might ejaculate again.

Yuu noticed Karin on his left, on all fours like Wakako, looking at him with longing eyes. Though tall from being a high jumper in track and field, she was slender with modest breasts and a toned body. Keeping his right hand on Wakako's waist, he stroked Karin's buttocks with his left hand, then rubbed around her vaginal opening with his extended middle finger. The already wet entrance made a *kuchu* sound in response to his finger movements. She seemed ready too.

While making her wait, he decided to loosen her up with his fingers, inserting his middle finger palm-up with *zubuzubu* sounds. Unlike his cock, it slid in easily, but he felt her insides tightly clenching around it.

"Aah! Yuu... your finger..."  
"Yuu-kuuun... aahn! I-It's moving...! Ooh, all the way deeeep!"

Yuu began slowly moving his hips while fingering Karin.

---

After full insertion, he limited himself to about 4-5 minutes per person. He would have preferred more time, but there were 28 girls. Since they were all virgins, insertion took time, but if he let his guard down even slightly, Yuu might not be able to hold back. To conserve stamina and suppress ejaculation, he focused on slow thrusts, savoring the subtle differences in each girl's vaginal texture. He lasted through Wakako and Karin.

Before finishing the first row of five, Yurin from the second row came to wait beside them. Of course, while Yuu was inside Karin, his fingers had made her thoroughly wet.

"Yurin, sorry to keep you waiting"  
"Hah, hah, hah... Yu...u... aahn, your cooock..."

Unlike Karin, the petite Yurin stood only about 150cm tall. Yuu pressed his erect cock against her back, almost covering her small frame. Then he had an idea - why not change positions here? The problem was that with Yurin's small stature, insertion might take time...

"Hah, hah, it's in... aah, my belly... so full... kyaa?"  
"Sorry. I'm going to change positions, okay?"

After somehow managing to insert into Yurin's vagina, Yuu lifted her while holding her firmly from behind, raising her upper body.

"Kyauu!"  
"There we go. How is it, Yurin?"  
"Kyaa! D-deep... so deep inside... your cock... all the way... gyaah, gyaaaah... kuun!"

With about 20cm height difference, Yuu changed from doggy style to seated position - Yurin leaning back against him while connected, with Yuu sitting cross-legged. Her legs were spread, making their joining point clearly visible from the front. Some waiting their turn watched with interest from a slight distance.

The moment their positions changed, Yurin's own weight drove Yuu deeper inside, making her cry out involuntarily. Though there was pain from receiving a penis for the first time, being held from behind by Yuu made joy overcome the discomfort.

"You're so cute, Yurin"  
"Hyaaaa... haeeeeee"

After being whispered to near her ear, Yurin had her lips sealed by Yuu, sending her into ecstasy. Yuu then began playing with her modest breasts - left hand fondling her nipple, right hand moving down to stimulate her clitoris. Instantly Yurin let out high-pitched moans. Though the insertion time was short, Yuu aimed to pleasure his partner as much as possible.

"Faaaaah! Hyameh! Ah ah... I'm cumming! I-hyau yooh!"  
"Good girl. Cum for me, Yurin"

Though his hip movements remained slow, his hands continuously stimulated her sensitive spots, bringing her to climax as intended. His earlier fingering probably helped too. But Yuu himself was approaching his limit while savoring Yurin's incredibly tight pussy. The narrow passage couldn't take his full length, with dense folds tightly gripping his cock, stimulating him with even the slightest movement.

Wanting to make Yurin climax at least, Yuu thrust upward while pinching and stroking her swollen clitoris. Attacked simultaneously on nipples, clitoris, and vagina, Yurin felt her consciousness fading from unprecedented pleasure.

"Pyaaaaah! No more... I-I'm going crazy... nyaah... hyaaan! Cumming, cumming! Gyaaaaaaaaah!"  
"Kuh... damn, me... too!"

As Yurin cried out in climax, Yuu pulled his cock out at the last moment and rubbed it against her lower abdomen. Immediately semen shot out forcefully, splattering thickly across her chest and stomach.

---

During a short break, Yuu had the waiting girls suck his cock. There was no shortage of girls eager to suck, so he asked three waiting their turn. Then as soon as his crotch revived, he began inserting again. Though his ejaculation pace was faster than expected, this time he lasted through five girls.

When he covered the large-framed Reiko from the volleyball club, he pulled out at the last moment and splattered semen on her belly. Finally feeling fatigue, Yuu collapsed onto Reiko's broad back.

---

"Phew. I'm really tired"  
"Yuu-kun, you've worked so hard"  
"Unbelievable. Ejaculating four times in such a short time..."  
"Only Yuu-kun could do this. All I can say is amazing"

Surrounded by mostly naked girls who showered him with amazed and admiring words, even Yuu felt embarrassed. But there were still 11 left - not even half done. Still, Yuu felt he had enough mental and physical stamina left.

"Could someone get my backpack?"

Yuu asked Chizure nearby to bring the backpack he'd brought. He rummaged inside and pulled out a long, thin black case containing a small bottle.

Back in late August at Hakone's hot spring resort Hesperis, on the final day, Yuu had pleasured 44 women in four groups of 11. Anticipating his stamina might fail, he'd drunk a special energy drink - not commercially available and reportedly costing five figures for just a small amount. Later, he'd obtained several bottles specially for this day.

Compared to that night with 44 women, 28 seemed manageable. Wanting to take their virginity without letting his guard down and make them remember the shape of his cock, he downed the first bottle. It was almost midnight. Having ejaculated multiple times, Yuu felt hungry and ate chicken from the girls' leftover food.

Then the banquet resumed.

"I-is this okay?"  
"Ahh... this is wonderful. I'm so happy"  
"Ufufu, Yuu, you're adorable!"

At Yuu's request, Chizuru and Connie stripped and sandwiched his head between their breasts - a titty fuck sandwich. For men, breasts bring both excitement and comfort. Meanwhile, three girls from the middle row crowded around Yuu's crotch as he sat with legs outstretched, sucking his cock.

Though it had shrunk and drooped temporarily, his cock soon reared up, swelling vigorously.

"Waaah!"  
"Y-your cock... already so energetic again... anmu, peropero"  
"Haa, haa, chiro, chiro. Can't resist. Chupaa... w-want it inside..."

The three girls stared hotly at Yuu's erect cock with heart-shaped eyes, licking it upward with their tongues. Their hands were at their own crotches, making *kuchukuchu* wet sounds as they writhed.

---

He had the third row line up their buttocks and proceeded to insert one by one. Having ejaculated four times, he'd built some tolerance - lasting through four girls at about five minutes each. He ejaculated a fifth time almost simultaneously with Tamami's climax during the fifth girl.

After another short break, starting with Connie, he changed positions to missionary - partly because Yuu wanted to bury himself in Connie's rocket breasts. During Miwako in the fourth row, he ejaculated a sixth time.

After pleasuring 21 girls, with seven remaining, even Yuu was exhausted.

It was well past midnight, after 1 AM. While hydrating, Yuu drank another special energy drink and rested surrounded by the waiting seven. Though not sleepy, he felt heaviness in his lower body.

During this "rest" while enjoying a lap pillow from Chizuru, a proposal came: all seven would massage his arms, shoulders, waist, and legs. True to their athletic backgrounds, they knew not only how to push their bodies but also aftercare.

"Your muscles are really tense. We'll give you a good massage!"  
"Your skin is so smooth and supple, yet firm... I want to keep touching forever"  
"Yuu-kun, how is it? Feels good?"  
"Aah~~~~~~ so good... makes me want to sleep like this"  
"Ufufu, if I could keep touching Yuu-kun forever, that might be fine too"  
"But..."  
"Hey"

Someone peeking at Yuu's lower abdomen from the side noticed. His cock, which should have been subdued during the seven-person massage, had revived.

"It's okay. I promised to help all you class members graduate from virginity. Thanks to you, my body feels much better now."  
"""Yuu-kun..."""  
"Hey, wouldn't it be better from now on if Yuu-kun lies down and we ride him?"

Among the seven who were less massaging and more caressing Yuu's skin, Chizuru spoke calmly.

"That makes sense, but when it comes down to it, can we control ourselves..."  
"True"

She was referring to what happened with the third girl, Misao. When Yuu tried to pull out as he neared ejaculation, lost in pleasure, Misao clung to him. Being naturally strong, even three people couldn't pry her off.

"I understand you've waited your turn. But here, we strictly adhere to five minutes per person. Move slowly to avoid burdening him. That benefits Yuu-kun and all of us."  
"Mmm... you're right"  
"Okay, we'll do our best!"  
"We'll make sure to get through everyone"

True to their athletic spirit, they united when it counted. They agreed to cooperate so everyone could lose their virginity. Yuu felt happy they cared about him beyond their own desires during this cooperative sex.

Sitting up, he felt the sand-like heaviness in his lower body lighten. He kissed all seven masseuses in rapid succession. Then looking at them, he said:

"Well then, shall we begin?"  
"""Yes!"""  


### Chapter Translation Notes
- Translated "四つん這い" as "on all fours" to maintain physical positioning accuracy
- Rendered "くぱぁ" as "gaping open" for anatomical clarity while preserving the wet sound nuance
- Kept "チンポ" as "cock" per explicit terminology requirement
- Translated "おマンコ" as "pussy" for anatomical accuracy
- Preserved "Yuu-kun" honorific throughout as per style rules
- Transliterated sound effects: "くちゅり" → "kuchuryi", "ずぶり" → "zuburi"
- Translated "特製の精力ドリンク" as "special energy drink" with contextual explanation
- Maintained Japanese name order: "Fujieda Wakako" not "Wakako Fujieda"
- Used explicit terms: "clitoris", "vagina", "ejaculation" per style guidelines
- Rendered simultaneous dialogue quotes with double quotes: """"Yuu-kun...""""