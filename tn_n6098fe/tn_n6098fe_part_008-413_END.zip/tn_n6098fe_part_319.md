## 301. Christmas Party ⑨ ~Sleepless Angels~

### Author's Preface

Since no new characters were introduced in the previous chapter, please refer to the preface of the chapter before last if you wish to review the names of the third-year PE course students.

---

Yuu lay on his back as the first girl tried to straddle him. The vagina attempting to receive his rock-hard erection was soaking wet and fully prepared.

Yuu called out to Chizuru, who was next in line, to sit on his face.

Chizuru was taken aback by the sudden proposal, but when Yuu encouraged her with a smile, she managed to respond in a trembling voice.

As an important junior two years his junior. As the student council president everyone admired. And, to put it further, as the first boy Chizuru had ever fallen in love with. Various emotions raced through her heart.

In any case, she felt a sinful excitement at the act of straddling Yuu's precious face and placing her buttocks on it.

Convincing herself that it was because Yuu had encouraged her, Chizuru breathed heavily as she lowered her large buttocks toward Yuu's face. Drops of love juice dripped down in her excitement, wetting Yuu's face, but he paid no mind and stared at the approaching genitalia. Even in the shadows, the parted labia seemed to quiver hungrily.

"Ahh! Yu, Yuu-kun!"  
"Kuu... My cock... Yu, Yuu-kun's... cock! I-It's, it's going in!"

As soon as Yuu's mouth and cock simultaneously made contact with the drenched female genitalia, the two let out moans of pleasure.

The cock was slowly swallowed into the vagina, but the cunnilingus started off fast, immediately producing wet, splashing sounds. Chizuru melted into the pleasure transmitted from her lower abdomen, her face slack with ecstasy as she unconsciously lifted her chin.

Yuu also let the third and fourth girls use his outstretched hands as they pleased.

The two girls sitting on either side of Yuu spread their legs wide, each grabbing one of his hands and guiding them to their vaginas.

Centered around Yuu, the four had truly become like females in heat.

After about five minutes, the connected girl reluctantly pulled out the cock to switch places.

Perhaps because the waiting time had been long.

Once the cock was swallowed, there was almost no pain of the first time, and they seemed to be struck by intense pleasure.

Even in just five minutes, they came easily, collapsing as soon as it was pulled out.

"It was my last chance, so I'd given up, but finally... it's here!"

The 28th was Haigaki Yui (排垣 結衣), who sat in the window seat at the very back and belonged to the volleyball club.

As an attacker for the team, she was slightly taller than captain Reiko, with a stature nearing 190 cm. With short hair and sturdy, muscular build reminiscent of a female warrior, her abs were even defined.

Despite her physique, her ordinary appearance and quiet demeanor gave the impression that her expressions were hard to read at first.

Yui had originally attended a high school in Fukushima Prefecture with a PE course, but moved to Saitama around the end of her first year due to her mother's work.

As one of the top athletes in Fukushima, Saitama Eiko High School, the top school in Saitama Prefecture, was naturally an option for her transfer.

However, Yui chose Sairei Academy, which ranked about fifth in the prefecture. The reason was because it was co-ed.

In truth, ever since learning to masturbate in third grade, she had done it daily without fail, making her an extreme pervert.

She strongly wished to attend a co-ed school where she could interact with boys, even if the chances were low.

However, with her club-centered school life, she only saw boys from afar and rarely had opportunities to interact. During events, she was often assigned to security.

After a year and a half, the first time Yui had a direct conversation with a boy was ironically when she was on security duty during the sports festival.

Like a chick imprinting on the first being it sees after hatching, Yui fell head over heels for Yuu, who not only talked to her but also smiled and held her hand to comfort her.

Yuu, who had been performing cowgirl positions one after another while simultaneously giving cunnilingus and fingering two girls with his hands, was covered in female bodily fluids, having been showered with squirt.

Even so, to Yui, he seemed more attractive than any male idol.

The magnificent, erect cock, coated with the love juice of many, shone brightly, even appearing divine.

In fact, she had almost come during the previous girl's turn and barely held back.

"Yu, Yuu...kun. I, I rea... really want... yer cock, sir... I can't stand it, 'bout."  
"Huh?"  
"Ah!"

The local dialect she had suppressed since moving to Saitama.

In this heightened emotional state, it seemed to slip out.

Yui turned bright red with embarrassment and covered her face with both hands.

Seeing this, Yuu sat up.

"Yui, are you from Tohoku? That's nice. I like girls with accents too. Come here."  
"Feh? Nmyu!?"

Reacting to the word "like," she moved her hands away, only to find Yuu's face there as he hugged her tightly and kissed her.

Today, starting with Yuu patting her head, Yui experienced her first kiss. She also touched and licked Yuu's skin.

Through this process, now that they were naked and embracing, Yui was showing the highest level of excitement.

Yuu's tongue entered Yui's mouth, overlapping with hers and moving actively, making wet sounds. At the same time, their bodies pressed tightly together, and her modest breasts, despite her developed chest muscles, pressed against Yuu's chest. Her nipples rubbed against his skin with every squirm.

Being led by Yuu now, Yui's head felt like it was boiling, and love juice overflowed from her private parts like a flood, streaming down her thighs.

"Now, let's become one."  
"Ah, aye."

For the last one, Yuu chose a seated position, placing his hands on Yui's raised buttocks and guiding her down.

"Gwaah! Aaah! Ha, ha, aun! Wait, hold... I didn't... know... nyaa! Iihyuu! Hyu, un! Fha, fhaaaaaa... oh, oh, deep (ogu)uuuuuuu... it's amazing! Oh! Voon!"

Not only by Yui's own weight but also guided by Yuu's hands on her tightened waist, she was inserted somewhat forcibly.

The moment the tip of the cock bumped deep inside, Yui hugged Yuu so tightly it hurt, throwing her head back and shouting.

At the same time, Yui's body trembled in small shivers, and warm liquid gushed out from their joined area with a splashing sound.

"Yu, Yui?"  
"Uwa... ahhaa... it's like... heaven... 'b."

For a first time, it was nearly impossible, but Yui came just from being inserted.

Perhaps because the wait had been long and she had masturbated many times, her body was ready.

Her secret crush on Yuu and the long-awaited loss of her virginity. The emotion of this moment must have pushed her over the edge.

On the other hand, Yuu had finally calmed down a bit after the interval, but the moment he inserted fully and Yui came, she tightened strongly, bringing him close to his limit.

"Ah, Yui. I'm... nmu"  
"Yuufuun, chu, chup! Shuki! Shuki shuki! Aanmuchuu, chuu, churerorooo... shaikouranooon... a, ai hite... ru fuu... nmaa, jyuru!"

Yuu tried to say something, but Yui grabbed his head and pressed her lips against his.

Now dominated by lust, Yui not only pressed her lips but also inserted her tongue, greedily exploring his mouth. She also began moving her hips up and down slowly.

Was it an instinctual desire? Inside her vagina, folds wriggled to milk the cock. As if she wouldn't get another chance.

*(Ah, this is impossible. I can't hold back.)*

At this point, Yuu gave up on pulling away. Instead, he wrapped both arms around Yui's sturdy back and hugged her tightly, thrusting his hips upward to ejaculate.

"Wa... Yu, Yui... I'm cumming, cumming... vuu!"  
"Ahi, hahee... Yu, Yuu... k... ma, again... faaaa! Jyuuto, kimohii yoo... hyuun! Ohinpo, ohinpo shama, ihii!"

Only about 3-4 minutes after insertion. Yuu couldn't hold back and was about to ejaculate.

Chizuru and the others watching felt something was wrong and thought to call out, but seeing them hugging so tightly, they hesitated to speak.

Yui, connected to Yuu and having her cervix knocked repeatedly, had a completely ecstatic expression.

Because even after coming once, she was continuously swept by waves of climax without a moment to calm down.

She wrapped her long legs around Yuu's waist as if never wanting to let go.

Because of this, Yuu's movement was somewhat restricted, but he was already at his limit.

Yuu thrust deep inside, grinding as he reached the final moment.

"Yu, Yui!"  
"Yuu-kuun... aah!"  
"Aaah!"

The first internal ejaculation with the 28th girl. In that short time, both were struck by immense pleasure. As a result, neither Yuu nor Yui could speak or move, remaining tightly embraced.

After a while, having broken the promise, Yui came to her senses and tried to prostrate herself in apology to those around her.

But Yuu apologized instead, saying that despite his initial declaration, he had ended up ejaculating inside. Both bowed their heads, and the matter was settled.

Feeling thirsty, Yuu tried to stand but staggered, causing a moment of panic.

After hydrating, he now felt the urge to urinate.

"I need to go to the bathroom."

At Yuu's words, everyone exchanged glances.

Surrounding Yuu tightly with no gaps, the room was filled with heat due to the density.

But the hallway in late December would be cold.

They all somehow didn't want to let Yuu leave the classroom.

"Yu, Yuu-kun! Um, you can do it here."  
"Huh?"  
"We have a container right here."  
"Yeah, yeah. We don't mind if it's Yuu-kun's pee."  
"Actually, I want to see you pee. Let me see."  
"Me too." "Me too." "Me too." "Me too." "M-m-me too!"

Yui, who had just been intimate with Yuu, mustered her courage and declared, and the others followed suit.

What kind of humiliation play is this? Yuu thought.

But in a gender-reversed world, there are men who get excited seeing cute girls urinate.

For them, seeing a boy pee in person must be a rare opportunity.

Exposed to so many expectant eyes, it became hard to refuse.

In the end, they brought an empty PET bottle, but the opening was too small.

So a quick-thinking girl tore off a notebook cover, taped it into a funnel shape.

"Here, Yuu-kun, go ahead!"  
"Haha..."

With a resigned smile, Yuu pointed his now flaccid cock toward it.

Surrounded by 28 naked girls staring intently.

This was also quite stimulating.

Perhaps the effect of the special energy drink remained, as his cock threatened to react, and Yuu frantically began counting numbers in his head.

Since most of his body's fluids had been lost as sweat, he didn't pee as much as expected, but the girls surrounding him seemed quite excited.

"I'm really... sleepy now."

Having achieved the feat of having sex with all the third-year PE course students in order, Yuu suddenly felt sleepy once things calmed down.

Although he only ejaculated inside Yui at the end, he had taken the virginity of 26 girls (excluding the experienced Chizuru and Connie), and they were all smiling.

Many still had lingering desires seeing Yuu naked, but they didn't dare push the exhausted Yuu, who had ejaculated seven times.

They tried to talk to him, but Yuu was about to fall asleep.

So Wakako, Chizuru, and other key figures began whispering among themselves.

As a result, they decided to have four girls at a time cuddle closely around Yuu as he lay on his back, taking turns every 30 minutes as a human blanket.

The first four: Aki and Michie clung to Yuu's left and right arms. The two stretched their arms to serve as his pillow.

Misao and Wakako held his legs.

"Ah, it's warm. I think I can sleep well."  
""""Yuu-kun, good night!""""  
"Un... nigh... ni..."

Though his arms and legs were mostly restrained, Yuu couldn't fight his sleepiness and closed his eyes.

Aki and the others, who had been staring at Yuu's face, gently stroked his body to avoid disturbing his sleep.

"Huh?"  
"Hey, hey."  
"Come on, what?"  
"Look."  
"No way!?"

About five minutes after Yuu fell asleep.

Perhaps because he felt the soft skin of girls all over his body. Or maybe it was just a physiological reaction.

His cock, which had been quiet, began to swell and rise.

Without thinking, Misao reached out and touched the cock.

"Hey!"  
"Ah, I couldn't help it..."

Stimulated by her fingertip touch, the half-erect cock grew even larger.

"Wow, Yuu-kun's cock... amazing."

Misao, who had withdrawn her hand, reached out again and stroked the glans as if petting it.

The cock stood erect as if pleased.

"Ah, Yuu-kun."  
"Me too."  
"Gently, so we don't wake him."

Aki, Michie, and Wakako also reached out.

Even as four hands caressed his fully erect cock, Yuu showed no sign of waking.

Their touch remained gentle. Not to induce ejaculation, but as thanks to the cock that had worked hard for 28 girls.

They had promised not to participate if they fell asleep. They stayed awake until their turn, took their turn cuddling, and fell asleep when time passed.

As an epilogue.

After winter break, Yuu kept his promise and made "baby-making tickets" for all 28 third-year PE students.

Handwritten by Yuu with his seal. No expiration date.

The girls were overjoyed to receive them.

Yui declared, "I'll treasure this for life, 'bout!" only to be teased by Reiko from the same volleyball club: "Then you won't be able to make babies with Yuu-kun until you die!" making everyone laugh.

Incidentally, Yui was the only one who received internal ejaculation, but it turned out she didn't get pregnant by graduation.

Sairei Academy's PE students were at a high level within the prefecture, but only a few were recognized as top nationally. Few exceptions like Hayakawa Ayumu, a second-year track and field athlete, stood out.

Graduating the following March, they showed unprecedented success, with Connie becoming a rookie-year regular in a corporate team and excelling.

Within a few years, many became regulars on pro teams or made the national team.

Tucked in their pockets were Yuu's baby-making tickets, laminated.

Meanwhile, Shiina Chizuru (椎名 千鶴), the former basketball team captain who continued to serve as Yuu's guard during school, aimed to become a teacher and entered a physical education university.

But she changed her path midway. The reason seemed to be her days with Yuu.

Five years after high school graduation, Chizuru got a job at a major security company and had a dramatic reunion with Yuu. Namely, she became a newly appointed protection officer.

---

### Author's Afterword

This concludes the Christmas Party arc.

Next, we will have an interlude and close Chapter 8.

### Chapter Translation Notes
- Translated "ガチガチに勃起したチンポ" as "rock-hard erection" to convey the intensity.
- Preserved Japanese honorifics (-kun) and name order (e.g., Haigaki Yui).
- Transliterated sound effects (e.g., "ぴちゃぴちゃ" as "wet, splashing sounds").
- Used explicit terms for sexual anatomy and acts as per style guide (e.g., "cunnilingus", "vagina", "ejaculation").
- Translated "子作り券" as "baby-making tickets" to maintain the literal meaning while fitting the context.
- Rendered internal monologue in italics: "*(Ah, this is impossible. I can't hold back.)*"
- Kept the dialect for Haigaki Yui's speech (e.g., "だべ", "ほ" rendered as "'bout", "yer").
- Maintained the original Japanese term "PETボトル" as "PET bottle" as it's a common loanword.