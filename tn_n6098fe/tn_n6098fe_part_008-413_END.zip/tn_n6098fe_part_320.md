## Interlude 11: The Deeply Sinister Woman (Part 1)

### Author's Preface

This covers the past of Jane, Kate's mother, who has made brief appearances until now.

She's scheduled to appear as an antagonist in the next chapter.

Though the content may not be pleasant since it departs from the protagonist's perspective, I have this bad habit of wanting to write about the circumstances that lead someone to become a villain, no matter how despicable they may be.

I agonized over starting this, but once I began writing, it exceeded my expected length so I've split it into two parts.

---

"Jane! You disgrace to the Mason family! Get out!"

"Wait! Mother! There's a reason for this—"

"I don't want to be called mother by you. You're disowned!"

Even as I tried to plead my case at the entrance, I was restrained by burly security guards. Unable to move, I looked up to see the door about to close. Beyond it, I could tell my sisters were sneering as if to say, "Serves you right."

*I've been had...*

I gnashed my teeth in frustration, regretting my own stupidity for falling right into my sisters' trap.

It was a holiday, and Mother and my sisters had gone shopping. I remember feeling strangely aroused after afternoon tea. Something must have been mixed in—perhaps the maid who poured the tea had taken orders from one of my sisters?

Feeling my face flush and a throbbing deep in my lower abdomen, I left my room to cool my head in the breeze. But when I stepped into the hallway, the area outside my brother's room—usually guarded—was unmanned. My feet moved on their own, and I opened my brother's door.

Seeing me suddenly enter, my brother smiled gently as always. Drawn like a magnet, I rushed straight to him and clung to him. Though surprised, he didn't reject me.

Once that happened, there was no stopping. Even when I pushed him down on the bed, he didn't resist.

"What's wrong?" he asked kindly. I was happy he hadn't changed from when we used to play as children.

Normally, I would have stopped there. But feeling his body heat and scent awakened my animalistic desires. I lost myself in excitement, and the beast inside me screamed that this was my chance to make my fantasies real.

I sealed his words by pressing my lips against his. With frantic hands, I undressed him, touching his skin. Whether it was because it had been so long since I'd touched his bare skin, my excitement kept building until my pussy was soaking wet. My brother mumbled something, but he didn't try to push me away. Taking advantage, I pulled his pants down to his ankles and reached for his cock.

At that worst possible moment, Mother and my sisters—who should have been out—returned home and opened my brother's door. They claimed they'd come back for forgotten items, but it was all a setup. To drive me out, the nuisance.

The Mason family traces its ancestry to an earl's house descended from the British Royal Family. Presumably, one faction that lost some conflict and drifted to the New World. They established themselves as an elite family that produced high-ranking government officials and military officers by contributing to the founding of the United States and subsequent wars.

As the eldest daughter, I had obeyed our matriarch Mother's orders and worked hard since childhood. In fact, I maintained top positions in both academics and sports through junior high. While I strove to prove myself worthy as the Mason family heir, my sisters were natural geniuses.

Catherine, the second daughter, demonstrated exceptional comprehension and memorization skills, mastering high school-level academics by age 13 and securing early admission to a prestigious university. Dominique, the third daughter, wasn't as academically gifted as Catherine but possessed terrifying insight and acting skills, excelling at deceiving people. As a result, everyone in the family—starting with Mother—doted only on brilliant Catherine and charming, manipulative Dominique, growing colder toward me each year despite my excellent grades.

My only comfort was my brother John, two years my senior. Only he was kind to me. As the sole male in the family, he'd been sickly as a child and was raised as a sheltered son, never allowed outside the mansion. But it had been decided he would soon be married off to the Buchanan family, another elite Eastern clan.

All three sisters adored our brother as a member of the opposite sex. But strict security made crossing that line impossible.

Lately, Mother said nothing when Catherine and Dominique played with our brother, but she harshly scolded me for merely sitting close to talk with him. I felt Mother's love pouring only onto my sisters as I gradually became isolated.

Finally, my sisters plotted this decisive performance to drive me out, and I fell right into their trap.

When I was driven to the gate, something was thrust into my hand—my wallet. It seemed I avoided the worst-case scenario of being thrown out with only the clothes on my back, but the wallet contained only about $300.

If I abandoned my pride as the Mason family heir and sought help from families connected to ours, I might avoid homelessness. But I'd live despised by everyone. Though I felt I'd lost everything and hit rock bottom, I couldn't choose that path. Lifting my head, I began walking toward the nearest station.

After transferring between trains and Greyhound buses from Portland station, I arrived in New York, the largest city on the East Coast. Since I intended to live without relying on my family name after being cast out, this metropolis far from home seemed fitting.

But job options were limited for a 15-year-old who'd only completed junior high. As my money dwindled, I couldn't find suitable work. Having studied politics and management for my future beyond school, I couldn't possibly become a street vendor now.

Finally, when I crouched on the street trying to save money for lodging, three punks suddenly surrounded me. Probably planning to steal what little money I had as a country girl down on her luck. Their stupid, foolish grins irritated me.

*Perfect for venting my frustration.*

Minutes later, it was the punks crawling on the ground. At 14, I'd already surpassed 6 feet (about 180 cm) and, recognized for my physique and athleticism, had been drilled in various martial arts by a Marine Corps veteran cousin.

Last year, I represented my school in boxing and reached the state finals—putting up a good fight against an upperclassman but losing by decision. Mere punks were nothing.

When they called for backup and I'd beaten down three or four more, a middle-aged woman in a black suit—different caliber from punks—stopped me. Taller than me with a prominent scar on her cheek, she clearly wasn't an amateur. She reminded me of my cousin who'd retired from the military after battlefield injuries. The unnatural bulge at her chest was probably a gun. But even unarmed, I wasn't confident I could beat her.

"You're good. How about joining the family?"

That was my encounter with King Cobra, a gang based in the Bronx. The woman who recruited me was Sandra, a mid-30s executive. She turned out to be a former Marine sergeant like my cousin.

With no home or job, I jumped at Sandra's offer.

Punks like those who'd accosted me—plentiful in the slums—couldn't be called full gang members. Just hoodlums with King Cobra backing—disposable pawns. Girls who'd run away from the country but couldn't find good jobs. Orphans whose parents died or abandoned them. A gathering place for such girls. Only those with potential became associate members allowed to help with the business.

Sandra seemed to take a liking to me, personally teaching me firearms and Marine Corps knife techniques. King Cobra, composed solely of whites, constantly clashed with Black, Hispanic, and increasingly powerful Asian gangs.

As part of Cobra Juniors, I led young punk groups, rushing to support during disputes and sometimes assisting with family business.

Though I'd carried my family name and lived as an honor student for 15 years, this life of blood and violence suited me surprisingly well. I decided to rise in this world.

If the Mason family—a typical WASP elite—shone in high society, I'd build real power in the underworld. However long it took, however despicable the means, I'd have my revenge on my sisters. So I vowed.

A year after joining the family, I turned 16. I'd already discarded the Mason surname and went by Jane Gillian. I should have been attending the high school Mother chose, but I'd adapted to gang life.

I'd killed people—Blacks and Hispanics we fought. I felt no particular emotion. Just impressed at how easily guns could kill.

That day, with nothing to do, I was killing time with comrades at our hangout bar. As I flipped through a worn pulp magazine with a cigarette dangling, TV sounds reached my ears. It had been playing entertainment shows, but breaking news came on.

"According to reports just in, United Airlines Flight 299 from Heathrow to Portland crashed during landing and caught fire. Information indicates many crew and passengers killed or injured. Rescue and firefighting efforts face extreme difficulties due to bad weather, with fatalities and serious injuries expected to be numerous..."

Air accidents weren't rare in the US with its developed aviation network. Though mass casualty crashes happened maybe once a year. I tried to dismiss it as someone else's problem, but hearing "Portland" gave me an uneasy feeling. Maybe someone I knew was aboard. I decided to check later.

Early next morning, I bought a newspaper. Front page: Portland airport plane crash. Photo of a mangled airliner—wings broken on the runway, scattered parts, charred fuselage—headlined with 91 deaths. Page two listed victims' names in small print.

Held by a bad premonition, I checked them one by one. Midway, I found names I could never forget and couldn't believe my eyes.

Miranda Mason (41)  
John Mason (18)  
Catherine Mason (15)  
Dominique Mason (14)

"Ha? Lies...? M-mistake...? This can't be! Hey!"

People turned to look at me shouting in the street. Thinking me crazy, everyone averted their eyes. But I didn't care. I hurriedly bought other papers and checked TV. No mistake in the casualty list.

I remembered. Every spring, our family traveled together to London. I hadn't gone the past two years since I wasn't invited.

I went wild afterward—so much that comrades couldn't handle me. I never imagined Mother, barely past 40, and my sisters, full of promise, could die so easily—but that was fine. Why did my brother have to die! My always kind brother. The only one who gave me familial love. Who, though medicated, tried to accept me without fear when I attacked him in animal lust. I wanted only him to live...

After exploding in rage and smashing things, I was overcome with emptiness like a hole in my heart. I'd lost not only my beloved brother but also my targets for revenge. For three days, I drowned myself in drink at the bar. Maybe naturally alcohol-tolerant, I never passed out no matter how much I drank—only intensifying the pain. Maybe drugs would have made me forget, but after seeing many addicts' fates this past year, I couldn't go that route.

"Ooh, if it isn't Sakura! Came after a year?"

"Sakura... that Sakura?"

"Who else? The man who comes all the way from abroad to be on TV! Damn, my Sakura's one fine man..."

"Since when was he yours?"

"But hey, rumor says if you meet him directly and he likes you, he'll do you."

"That rumor true?"

"Seems so. Last year in D.C., he spent a night with four hotel staff and knocked up two."

"When that Hollywood actress came onto him, he did seven including her staff and other actresses."

"The one from that movie... Was her pregnancy from Sakura?"

Hearing the commotion at the TV, I rose from the sofa. Standing up, I knocked against the table, toppling several empty bottles, but ignored it and looked toward the voices.

I'd heard the name Sakura. On the CRT screen, a man smiled cheerfully while waving, surrounded by many women. Japanese, I think, but apparently American women were captivated by his looks and drive.

"How old is Sakura? Looks young."

"Dunno. Can't tell with yellows. Around 20?"

"Nah, should be 30 by now."

"Huh~ Still, what a man."

"Yeah. And I hear he's huge down there? Women cum like they're ascending to heaven."

"Whew! I wanna try a man like that just once."

"Same here."

"A man..."

"Hyah!"

"What, just Jane..."

My muttering made them turn. Seeing me, they flinched or screamed. After learning my family died in the crash, I'd rampaged emotionally. Sandra happened to be away, so no one could stop me. Lately, since I'd just been drinking alone without violence, they'd left me alone. So my zombie-like face standing behind them startled them.

All the girls at the hangout—myself included—were virgins. Chances to even meet young men were rare. Though I heard the King Cobra boss kept a young bought man as a lover. Making remarkable achievements got you personally acknowledged by the boss at family-run upscale bars. Not just that—you could receive "service" from his lover. Sandra had happily told me how she got to suck cock in a back room.

About men... Last month I saw a naked one for the first time. We raided a rival Black family's hideout and kidnapped a man there. After executives gang-raped him for three days straight—probably using drugs—we lower ranks saw him. Though likely in his 30s, he looked like a broken old man. Sadly, his cock stayed limp. We poked and stroked it together, but it wouldn't revive.

I glared at the screen. Didn't need to be as handsome as that man on TV. I'd rise in the family, capture men, and rape them. So I resolved.

Never imagining such an encounter would come just days later.

That night, after eating while inspecting a family-connected shop, I noticed being surrounded. Women with dark skin blending into the shadows. Some ostentatiously flashed knives. Three of us against about ten of them. I'd heard they planned retaliation after we took out one of their bases. And of course, I wasn't carrying a gun. Just stepped away briefly from the scene—maybe my turn had come.

"I'll charge. You two scatter left and right!"

"B-but that way you'll—"

"Just go!"

Shoving my comrades aside with both hands, I grabbed the survival knife at my belt. Then charged straight at the biggest, most conspicuous Afro-haired Black woman.

"Haa, haa, haa..."

Bloodied but having shaken them off, I walked through back alleys. I'd cut and knocked down several, but taken many wounds. Especially the deep cut on my left arm wouldn't stop bleeding. Probably in Manhattan. With many important facilities here, minorities faced strong prejudice. They likely gave up chasing to avoid police. But I was growing dizzy from blood loss.

While main streets had glamorous hotels, theaters, and museums, back alleys were equally littered with trash and grime.

"Made it this far... Should be safe. Rest a bit..."

Leaning against a wall in a smelly alley corner near an exhaust vent, I wanted to sit down. But sleeping here could be fatal. Had to make it somewhere for treatment... Just then, a door nearby opened and someone came out.

"Trouble."

Probably an employee of the large building before me. Being kicked out would be bad enough, but if they called police, real trouble. Seeing them approach, I tried walking the other way.

"Hey, you okay?"

A low voice called. Ignoring it, I took a few steps before stumbling.

"Careful!"

About to fall, I didn't faceplant. Someone caught me firmly from behind. About my height? From the feel, I thought her body unusually hard for a woman.

"You're covered in blood! Stay with me! Your name?"

Strange intonation. Maybe a foreign worker? More importantly, I wanted to avoid burdening civilians. But I lacked strength to break free and run. My vision seemed foggy, consciousness fading. She didn't mind her clothes getting bloody holding me—too kind. As I vaguely thought this, another voice reached me.

"Mr. Sakura! Trying to go out alone again... What's with that woman!?"

---

### Author's Afterword

I named her Jane without much thought, but her becoming one of three sisters has a model.

In the story, she meets a tragic end, but she's an incredibly good woman. By the way, her voice actor in the TV version is Toshiko Fujita.

Fixed a terrible typo right after posting...

### Chapter Translation Notes
- Translated "因業深き女" as "The Deeply Sinister Woman" to convey moral complexity
- Preserved original name order for Japanese characters (e.g., Toyoda Sakuya)
- Translated sexual terms explicitly ("pussy," "cock," "rape")
- Transliterated sound effects ("Haa," "Ha?," "Hyah")
- Maintained US cultural context while preserving Japanese storytelling conventions
- Italicized internal monologues per style guidelines
- Kept gang terminology consistent with Fixed Reference (King Cobra, Cobra Juniors)