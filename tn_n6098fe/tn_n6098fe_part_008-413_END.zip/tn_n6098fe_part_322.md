## 302. New Year's Eve at Home ① ~NEW YEAR'S EVE~

### Author's Preface

Sorry to keep you waiting. A new chapter begins. Though the chapter title sounds ominous, it starts with a peaceful New Year's Eve scene.

The author originally planned to have Kate move before year-end but postponed it to next year due to circumstances. Though not mentioned in Chapter 292, the timing has been adjusted accordingly.

During the break, I updated the character introductions. It's become quite lengthy, so school-related characters have been separated into another page. All Class 1-5 students who have appeared so far are now included there.

Along with the character introduction updates, I've come up with a project idea. Details in the afterword.

---

Days when loneliness sinks deep when alone - besides Christmas Eve, it's probably the year-end and New Year period. 

When young it might be fine, but approaching middle age, having no one to spend time with feels lonely. In that sense, Hirose Yuu's reborn self seems destined for a lively year-end.

As New Year's Eve 1990 approached, Yuu busily moved around his home since morning. 

Common area cleaning had been done by the live-out housekeeper by the previous day, so he focused on his room, then his sister's. Elena was bad at tidying and would quickly make a mess if left alone. 

As a student preparing for exams, she spent most of her day studying - good in itself - but in exchange, trash scattered the floor and clothes were strewn everywhere. Several pairs of panties and bras lay abandoned in the corner of her bed. 

If he'd seen this when young, he might have been disillusioned, but for Yuu with his middle-aged mentality, it meant nothing. At any rate - not metaphorically but physically - he spanked Elena's butt and made her clean together.

Mother Martina was better than Elena, but normally busy with work, so her bedroom closet wasn't exactly tidy. Plus, he didn't want to overwork his pregnant mother, so after finishing Elena's room, he organized with Martina.

*Why do women have so many clothes and underwear?* 

Harboring such doubts, he stored things in drawers and hangers. By the end, he was sweating despite midwinter.

"Thank you so much, Yuu-chan. You did almost everything."  
"You're welcome. Oh, I put newly bought items in the front costume case so they're easy to access."  
"R-right."

Though folding women's clothes was troublesome, with Martina's guidance Yuu managed to organize them, leaving the bedroom much tidier. Visibly moved, Martina pressed close, and Yuu embraced her shoulders. 

This was true both before and after rebirth - men dislike organizing women's clothes. Too many types, and handling methods are unclear. The former Yuu was like that too, but now with drastically increased contact with women, he didn't mind much. 

The increased clothing was partly due to buying maternity wear that could be worn even with a growing belly. Having seen Sayaka and others prepare and wear such clothes at home, he knew somewhat.

"I'm hooome! Finally finished everything!"

Elena's voice came from the entrance. Besides the accumulated items in Elena's room, she'd taken the sorted unwanted clothes to the apartment's garbage area. The apartment should have trolleys per floor, but being this day, they were unfortunately all in use. 

Though Yuu would have helped, he couldn't casually go outside. So Elena made multiple trips alone. It seemed tough on her slender arms.

"Good work, Sis."  
"Huff... I'm exhausted. My arms hurt... totally worn out."  
"You worked hard. Good girl, good girl."

Facing Elena still in the entryway, their height difference was reversed with her head at an easily reachable position. Yuu embraced Elena as she leaned in frontward and stroked her head. Her long chestnut hair was tied at the nape to avoid interference, and Yuu's hand gently stroked from head to back. Perhaps from carrying heavy garbage bags repeatedly, a slight sweat scent came from Elena's skin.

Having sweated too, Elena buried her nose in Yuu's unbuttoned collar, sniffing deeply.

"Hey, Yuu. My reward."

Without letting the somewhat flushed Elena finish raising her chin, he covered her mouth. Immediately Elena slipped her tongue in, and Yuu accepted it, their tongues overlapping. Embracing while making loud *jurujuru chupachupa* sounds in a deep kiss.

Though sometimes cold to his severely brother-complex sister, he indulged her occasionally. Despite being siblings, Yuu was the one controlling Elena.

After letting Elena enter, Yuu looked toward another door in the long entryway. That was the resident bodyguards' room. Half-open, voices from within suggested mid-deep-cleaning.

"Hello~"  
"Waaait!"  
"No way I'll wait when told to!"

Peeking in, Yuu saw something chaotic. Touko was being chased by Kanako, jumped on a chair before him, and wobbled upon recognizing Yuu.

"Kyaaah! Yuu-sama!"  
"Whoa! Careful!"

As Yuu stepped forward, Touko leaped at him with somewhat flat delivery. Yuu firmly caught the petite Touko. Beyond the desk, Kanako seeing this groaned "Grungh." 

Touko boasted nimble movements worthy of a ninja. Both Yuu and Kanako knew her wobble and clinging was deliberate. In high spirits, Touko clung koala-like with all limbs, sniffing *kunkun* at his skin.

Kanako stood imposingly in T-shirt and jeans despite midwinter, bandana on head and duster in hand. Yuu smiled at her.

"Seems you're cleaning. Good work."  
"Haa. If only my partner there didn't slack off, we'd have finished long ago."

The resident bodyguards' space had shared areas doubling as offices plus private rooms. The capable Kanako had nearly finished cleaning, but Touko had been lazing in her room, apparently making Kanako angry.

"Let me see."  
"Ah, no!"

Still holding Touko, Yuu moved. Touko tried to get down and stop him, but Yuu wouldn't release. If serious, Touko could easily escape, but when Yuu squeezed tight, she weakened.

Come to think, he'd occasionally visited the shared space, but never entered their private rooms. So Yuu was very curious.

"This is... quite a match for Sis."  
"No matter what I say, she won't listen."

Touko's six-tatami room had comics, magazines, discarded clothes and snack bags scattered with no floor visible. Only dumbbells and training equipment were properly arranged - amusingly. Walls displayed framed cutouts of articles featuring Yuu and photos from hot spring trips. 

Checking his watch, Yuu considered time allocation for upcoming tasks.

"Okay. I'll help for just one hour, let's do it together!"  
"Really? Yay! I'll work if it's with Yuu-sama!"  
"Honestly, so mercenary."

Setting Touko down, Yuu first instructed garbage sorting, then turned to Kanako. Her white T-shirt front bulged with large breasts, and sweat made her bra pattern visible through - alluring. Yuu spread his arms and hugged Kanako. Kanako's ample breasts pressed against his chest, her sweat scent tickling his nostrils.

"Kanako-san. It's tough, but hang in there."  
"Y-yes!"

Kanako's irritation vanished wrapped in happiness from Yuu's hug. To her, Yuu was both an important protectee and a male she could shower with genuine brotherly affection. Strangely, he even provided healing like an older man. At any rate, Kanako reaffirmed this was truly a good year since becoming Yuu's protection officer.

Helping somewhat with Touko's room cleaning, it passed 4 PM. The intended one hour had overrun by 15 minutes. After prioritizing garbage disposal and tossing discarded clothes into the washer, Touko's tension stayed high cleaning with Yuu. 

During protection duty she seemed reticent and elusive, perhaps from concentration, but privately showed a girlish innocence unbelievable for her age. Yuu barely suppressed wanting to dote on her.

When the bed was finally clear and floor visible, Yuu left vacuuming to them and returned.

Dinner prep started early - year-end soba. Half-Japanese Martina raised in Japan was accustomed to Japanese food. Not eaten yearly, but hearing store-bought soba was delicious before, Yuu declared he'd make it this year.

Normally using store-bought mentsuyu, today he made it from scratch. Before rebirth, Yuu had researched online and made it several times. Not restaurant level, but with effort homemade broth turned tasty. 

The housekeeper had shopped yesterday, so ingredients were ready.

Broth used two bonito types: regular katsuobushi and mixed sardine/mackerel shavings - a fistful each boiled hard. While boiling, the kitchen filled with katsuobushi's good aroma. 

He made "kaeshi" with soy sauce, mirin, and sugar. This could be stored refrigerated for later use in stews.

With soba broth ready, he prepared tempura oil. Frying took time, so focused only on isobe-age chikuwa. On another burner, a large pot for boiling noodles heated. Cooking efficiency depended on multitasking. Trying everything rarely went as planned, so he avoided overdoing.

Chikuwa in oil puffed quickly, swiftly removed. As chikuwa finished, the pot boiled, so Yuu added soba. Premium fresh noodles among supermarket offerings. Slightly undercooked, stopped heat early, drained in colander under cold water.

After draining, noodles went into bowls, topped with kaeshi-thinned broth. Finished with isobe-age chikuwa, chopped scallions, seaweed, and fishcake.

"Looks delicious! Let me photograph it."  
"Haaaaaah... Yuu's handmade..."  
"Uh, let's eat quickly?"

Martina aimed a bulky camera, making Yuu smile wryly. His cooking always followed this pattern. Bragging at work once caused an uproar - "We'll pay you to cook!" etc. - so now she only documented.

""""Let's eat!""""

Rich broth coated soba well. Isobe-age dipped in broth was delicious too.

"Ahhn! Everything Yuu makes is delicious, but tonight's exceptional!"  
"Now, that's exaggerated."

Martina's lavish praise made Yuu blush. Compared to housekeepers or full-time housewives cooking daily, it was nothing special. He knew Martina praised through the filter of her beloved son's cooking.

"Huh? Mom, what's wrong?"

Elena enthusiastically slurped soba, ate toppings, and seemed ready to drink all broth, but Yuu noticed Martina had stopped eating.

"Ah... sorry. Just happy we're all together this year-end... feeling emotional."  
"Mom, there'll be more from next year, something to look forward to."  
"Hah! True. Childcare... first time in ages, it'll be tough."  
"By then Sis's exams should be over. Hope next year brings multiple celebrations. Hey Sis, drinking all that will give you too much salt!"  
"Uu... but..."

Elena as exam-taker rarely watched TV, Martina professionally favored news. Yuu also diligently watched news with Martina to understand society. The Hirose household rarely watched entertainment shows, hence suspicion.

At any rate, only Yuu concentrated on TV now. Martina and Elena pressed close on Yuu's left and right. For them, being with Yuu sufficed. The Hirose family's New Year's Eve passed quietly.

---

### Author's Afterword

Thanks to you all, "Reborn in a Chastity Reversal World" has surpassed 300 chapters with many characters (mainly female) appearing.

Thus, I'd like to hold a character popularity poll. Yes, I've always wanted to try this with my own work (laugh).

【Poll Rules】

・Voting Period: 5/30 (Sun) - 6/5 (Sat) 23:59.

・A voting page will be created in Activity Reports (before 5/30 date change). Vote in its comment section. Access Activity Reports by returning to page top and clicking author name, or via author X page at bottom.

・Voting targets: Characters listed in "Character Introduction 1" and "Character Introduction 2 (Sairei Academy)". Both genders OK. Protagonist OK. Deceased OK.

・Vote for 3 people. Please select 3 if possible. If absolutely impossible, 2 is acceptable. If 4+ names written, first 3 counted.

・Full names preferred, but first names OK if distinguishable. Some characters only have first names listed.

・Characters not in introductions won't be counted.

Example ① Komatsu Sayaka, Hanmura Riko, Ishikawa Emi  
Example ② Toyoda Sakuya, Martina, Kate Grimwood  

・One vote per person. Corrections possible during period by writing "Correction".

・Results tallied by 6/9 (Wed) and announced in that post.

・If under 10 voters, the project might flop. Even those who haven't commented before, please vote enthusiastically.

Thank you.

### Chapter Translation Notes
- Translated "年越し蕎麦" as "year-end soba" (toshikoshi soba) with cultural context explained in narrative
- Preserved Japanese honorifics (-chan for Yuu, -san for adults) per style rules
- Maintained original name order (Hirose Yuu, Kitamura Kanako)
- Transliterated sound effects: "じゅるじゅるちゅぱちゅぱ" → "jurujuru chupachupa"
- Translated "日本レコード大賞" as "Japan Record Awards" with proper noun capitalization
- Rendered "Wish" without translation as established group name
- Translated "ブラコン" as "brother-complex" for cultural accuracy