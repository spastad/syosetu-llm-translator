## 303. New Year's Eve at Home ② ~Elena's Request~

### Author's Preface

The popularity poll I started on Sunday has now been voted on by 15 people as of tonight.

Great, just great. I was worried we wouldn't even reach 10 people.

I'm surprised that not only expected characters but unexpected ones are getting votes too.

Also, I'm grinning while reading all your comments. Thank you!

The voting period is still open, so if you haven't voted yet, please write in your favorite character!

↓ Voting page below.

https://xmypage.syosetu.com/mypageblog/view/xid/175790/blogkey/299499/

---

At 11:45 PM, the TV screen changed to 'Year In, Year Out'.

As always, it showed people visiting shrines and temples for hatsumode nationwide.

However, only women appeared on screen.

Amidst this, footage showed over a dozen young women in their teens and twenties praying inside a hall at a temple in Iwate Prefecture. Yuu was shocked to see they were worshipping an intricately crafted phallus. From what he could see on screen, it appeared to be as long as the distance from a woman's middle fingertip to her wrist when her hand was spread open.

It was so realistically detailed that Yuu wondered if it was appropriate for public broadcasting. According to the narration, it was said to grant wishes for marriage and pregnancy.

The erect phallus served as a sacred object, surrounded by egg-shaped wooden carvings representing vulvas. These were brought by the visiting women. Though Iwate was shown by chance, similar rituals occur nationwide. This demonstrated how desperately women in this world wished for relationships with men and pregnancy.

The camera zoomed in on one woman's profile. A fair-skinned, black-haired woman in a navy kimono with white arrow-feather patterns looked about twenty. With her short hair and eyes closed in prayer, she was clearly a petite beauty with a pure impression, her slender neck and wrists visible.

In his previous world, such a beauty would have had men flocking to her without effort, yet here she prayed with intense sincerity. In rural areas, the male shortage was so severe that young people moved to cities, accelerating aging and depopulation. Perhaps she had urgent reasons, like needing an heir for an established family.

To Yuu's sensibilities, this situation was abnormal. He'd heard that while artificial insemination technology had maintained the population since the 20th century, the gender ratio gap kept widening. If sperm-providing men decreased further, everything would collapse.

Of course, Yuu alone could only do so much. As student council president, he could at most steer his alma mater in a positive direction. But he had a powerful ally—the Toyoda Sakuya Memorial Foundation. He resolved to gradually expand its influence in the new year.

When the on-screen clock showed 11:55 PM, Yuu tried to change the channel but found both arms pinned. Martina held his right arm, Elena his left—both clinging tightly with their heads on his shoulders. Neither was watching the TV anymore; they just wanted to be close to Yuu. Their post-bath fragrances enveloped him.

Yuu looked at Martina on his right. Her abundant wavy black hair was tied at her nape, revealing a glimpse of her tanned neck. Though in her late thirties, her skin's smoothness rivaled women in their twenties. Since becoming intimate with Yuu, she'd become even more diligent about skincare—proof that while she was his mother, her awareness as a woman had heightened.

Her upper arm was sandwiched between breasts that had grown larger with pregnancy. She wore a fluffy white bathrobe over a camisole, but her chest was open, clearly revealing the valley between melon-sized breasts. Yuu's forearm rested against her belly, which had swelled since winter began—carrying a life conceived by his seed. This child would be Elena and Yuu's sibling. He hoped for a healthy baby regardless of gender.

On his left, Elena pressed Yuu's arm against her chest while trapping his fingertips between her thighs, grinding against them. Her pink winter pajama dress had ridden up, fully exposing her thighs. "Haah, haah," her ragged breaths hit Yuu. Though slightly exasperated by his sister getting aroused using his arm without permission, he didn't resist. Elena was perpetually in heat around him, but unsolicited sexual advances were generally forbidden—it would never end. Instead, he let her indulge during relaxed moments like this.

"Oh!"

The countdown had begun on screen. Less than 10 seconds remained until the new year. With his mother and sister clinging to him, Yuu watched the screen. 5, 4, 3, 2, 1, 0.

At that instant, a hand turned Yuu's face right as Martina's plump lips approached.

"Yuu-chan, happy New Year! Another great year together! *Chu*"  
"Nn. You too—"

Before Yuu could finish his New Year's greeting, Martina sealed his lips again. Her slick tongue invaded his mouth. Without him noticing, she'd wrapped her arms around his head and chest instead of his arm.

He recalled seeing on TV how couples kissed at New Year countdowns in America or Europe. Though he kissed Martina daily from morning till night, this must be similar.

After a moment's thought, Yuu responded while stroking Martina's head and back with his right hand. The TV screen faded from his awareness as he lost himself in their deep kiss. With mouths open, their tongues slid wetly against each other, exploring oral cavities. As mucous membranes repeatedly touched, mutual arousal built into what resembled saliva exchange, with *picha picha* sounds echoing in their joined mouths.

"Ah! Mama beat me to it! Hey, Yuu! Me too!"

Elena, who'd been distracted, cried out—her own fault for being engrossed in rubbing against Yuu's hand. Yuu prolonged his kiss with Martina before Elena could turn his head. Her hand seized his jaw, sealing his lips as her tongue pushed in.

Since Elena had tied her long brown hair into two buns, Yuu stroked her slender neck and exposed nape with his left hand.

"Nmooh... chupa, chupu, chururi, juru, nyero, rerorerorerojupu! Ufun! Yuu, more!"  
"Sis, happy New Year."  
"Nn, you too. Erochu! Chu, chu, anmu, nn, nn, nku... ahan!"

Elena focused entirely on tangling tongues and devouring Yuu's mouth rather than greetings. Yuu moved his tongue in sync while tracing her neck upward with his fingers and gently caressing her small, well-shaped ears. Elena narrowed her eyes in pleasure, emitting faint sighs as she slid her hand toward her crotch.

Considerable time passed as Yuu alternated kisses with both. The TV clock showed 12:25 AM, displaying a famous veteran female singer reading viewer postcards and performing live.

"Hey, hey, Yuu?"  
"What is it, Sis?"

Elena lifted her face from Yuu's chest. After repeated deep kisses and delicate touches, her expression was thoroughly lustful.

"Let me suck your cock. I want your semen."

Yuu smiled wryly at his sister's libido erupting right after New Year. With about a month and a half until university entrance exams, he'd heard her preparation was going well—her December mock exams yielded an A-rating for her target school. So she planned to indulge freely during New Year's and the first three days.

"My, my. Elena, aiming for 'Lord's First'?"  
"Un! It's been my dream—drinking Yuu's as soon as the year starts!"  
"Lord's First?"

In his previous world, New Year sex was called "Princess First" or "Secret First." This must be the reverse version. Swallowing semen at the year's start was believed to ensure pregnancy that year. However, few women actually received semen—most young women practiced a ritual where they kissed such phallic objects before drinking cloudy sake representing semen, wishing for maidenhood loss and pregnancy. Elena, who'd gain creampie privileges upon university admission, clearly yearned intensely to conceive Yuu's child like Martina.

Patting Elena's head, Yuu agreed. "Fine by me. But since we're at it..." He made a request to Martina. Blushing slightly, Martina granted her beloved son's wish.

Yuu lay supine on the sofa with his head on Martina's lap. Martina had opened her robe wide and slipped her camisole straps off her shoulders. Thus Yuu's view was blocked by her prominently protruding breasts. As Martina leaned forward, her nipples neared his face. Along with her swelling belly, her nipples and areolae seemed larger and darker—her body preparing for breastfeeding.

"Taste them before the baby monopolizes them... Oh, I could have you both suck together..."  
"Really... Yuu-chan. Well, alright."

Martina blushed, imagining Yuu and a baby suckling simultaneously in the near future. Children remained adorable regardless of age. Having her 16-year-old son want her breasts made her undeniably happy.

While breasts filled Yuu's vision, Elena waited at his feet, ready to pull down his sweatpants.

"Ahh, this moment always excites me! Th-then... Yuu's cock and balls, here I come!"

His pants and trunks slid down together. His semi-erect cock sprang out with a *pyon*.

"Dehehe~. Cocky..."

Elena, who'd inherited the beauty that captivated women worldwide from their father, now had drooping eyelids and a slack mouth—a far cry from her usual cool impression. Instead of immediately sucking, she pressed the removed clothes to her face, sniffed them, then set them aside.

"Ahh! Mama, no fair!"  
"Ufufu. First come, first served."

While Elena was distracted, Martina reached out, firmly grasped Yuu's shaft, and began stroking rapidly. Warmth flooded his cock in her hand, hardening it steadily. By then, Yuu was licking the breasts filling his vision before taking a nipple into his mouth.

"Nmu, nn, nku, chuu, chupaa... As expected, no milk yet. Amu"  
"An! N-not yet... It only comes... near term..."  
"Nn~~~~ Tha's too baaad... nnn!"

Thus began the breastfeeding handjob Yuu had requested—a first in a while. Though her belly had swelled, milk production was still premature. While Yuu rolled the nipple in his mouth with his tongue or suckled like a baby, Martina lightly stroked his fully erect cock from glans to base. Then Elena, kneeling beside them, engulfed the glans from over Yuu's belly.

"Nmuu! Mufu... churu, chuu~~ juru"  
"Haan! Yuu-chan, really... nfuu... Such a naughty baby... Do you love... Mama's breasts... that much... Ahh!"  
"Muchu, nchu, rero, ju, ju, jupuu... n~am, eronrero"

Instead of answering verbally, Yuu kept suckling fervently. He gently bit with his teeth or kneaded with his tongue. Though no milk came, he thoroughly savored the plump nipple. Overwhelmed by sensation, Martina gradually lowered her upper body until her breast's weight pressed fully on Yuu's face. Rather than minding, Yuu felt blissful and continued suckling. Martina moaned while her stroking hand accelerated. Elena, having taken the entire glans into her mouth, sucked passionately—not just licking but savoring it with her whole mouth, making *becha becha* sounds. From the side, her cheek occasionally bulged when the glans pressed against it.

"Nfuu, Yuu's cocky, so tasty"

Pulling back, Elena gazed rapturously at the cock glistening with pre-cum and drool. The mixed fluids dripped down the shaft, creating sticky, *nechi nechi* sounds with each stroke of Martina's hand. Elena slid her right hand to Yuu's chest while her left reached between his legs to caress his buttocks. She felt his hips tremble—a sign of approaching climax.

"About to cum?"

Yuu didn't answer Elena's question, still suckling a nipple. Instead, he gripped her shoulder tightly with his free left hand. That alone conveyed it.

"Un. Big sis will make you cum, Yuu. Aaahnmu"

Elena kissed the glans with her mouth half-open, teasing the urethral opening with her tongue tip. Hearing Yuu's muffled "Nguu!", she grinned and began licking the entire glans broadly. With both stimulating him, Yuu neared his limit. His rising semen felt ready to burst from Martina's hand and Elena's mouth. When Elena felt Yuu's hips twitch, she prepared to receive it in her mouth. As Yuu groaned "Vu!", semen shot vigorously into Elena's mouth. Waiting calmly, she swallowed it all in one gulp. Elena's face melted in ecstasy as she tasted the hot semen, not spilling a single drop.

"Fuu, that was a lot. Felt great... Satisfied, Sis?"  
"Wehehee... So satisfied... Tasty refu"

Elena's grin revealed her mouth still whitened by the last swallow. Though post-ejaculation, Yuu kept enjoying Martina's breasts—sucking and kneading—before sitting up.

"Yuu-chan?"  
"Now Mom's turn."  
"Eh... But..."  
"I want Mom to suck me."  
"Ahh..."

Standing before Martina, Yuu's cock remained fully erect and curved upward despite ejaculation, gleaming wetly after Elena's thorough licking. What woman in this world wouldn't lust after such a sight? Not even his own mother.

"Uun... Yuu, let me suck... Mama wants... your semen too... Chu"

Martina first kissed the glans repeatedly. After showering it with kisses, she moved her mouth to the base, stuck out her tongue, and meticulously licked upward. Smelling the cock's musky scent, tasting the bulging veins and textured surface, Martina's eyes glazed over into a thoroughly female expression. Wrapping both arms around Yuu's waist, she opened her mouth wide and engulfed his cock.

---

### Author's Afterword

In Japanese cultural history, phallic worship or worship of the golden spirit (a phallic-shaped deity) existed in various regions, as you may know. I modeled one such practice here.

Also, the program aired after New Year was modeled after NHK's Masashi Sada program. Checking revealed it started in the 2000s, but since this is fiction, I'll skip details. In this world, perhaps a singer like Miyuki Nakajima would host it.

On a personal note: About two years ago, I was told I showed signs of glaucoma and was prescribed eye drops to reduce pressure. Thanks to the drops, my biannual checkups showed almost no progression. But since Monday, my left eye suddenly grew cloudy. It worsened daily, affecting work and personal life, so I'm visiting the eye doctor tomorrow. I managed today's update despite the difficulty of both writing and reading.  


### Chapter Translation Notes
- Translated "殿はじめ" as "Lord's First" per Fixed Reference terminology
- Preserved Japanese honorifics (-chan for Yuu) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "ちゅぱ" → "chupa", "ぴゅる" → "pyuru")
- Translated explicit sexual terminology directly ("fellatio", "semen", "phallus")
- Maintained original dialogue structure with new paragraphs for each speaker
- Italicized internal thoughts like *(C-close!)* though none appeared in this chapter
- Translated culturally specific terms like "harigata" as "phallus-shaped object" with contextual explanation
- Used gender-neutral "they" when original Japanese omitted subject pronouns
- Preserved specialized terms like "Toyoda Sakuya Memorial Foundation" per Fixed Reference