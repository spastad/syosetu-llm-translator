## 305. New Year's Party ② ~Pop Children~

### Author's Preface

My apologies for causing concern.

My left eye hasn't fully healed yet and remains difficult to see with, but if I can get treatment at the hospital early next week, I should be able to recover somehow.

Since so many of you kindly voted, I worked hard to tally the results and update the activity report.

Results announcement for the "Reborn in a Chastity Reversal World" character popularity poll!

https://xmypage.syosetu.com/mypageblog/view/xid/175790/blogkey/300900/

To list just the top results:

1st: Komatsu Sayaka (15 votes)  
2nd: Ishikawa Emi (7 votes)  
2nd: Hirose Martina (7 votes)  
4th: Tsutsui Nana (6 votes)  
4th: Higashino Rei (6 votes)  

In addition to the other rankings, I've written author comments about the ranked characters and the origins of their names in the activity report article. If you have time, please give it a read.

---

"Now now, no monopolizing him okay?"  
"That's right. No matter how cute Yuu is~"  
"Ah! S-sorry!"

Sayaa, who had been hugging Yuu in a dreamlike state, reluctantly pulled away when called from behind. Though she initially seemed like a cool, composed woman ten years his senior, Yuu's impression of her rose upon realizing her innocent side.

But many others still needed greetings. After subtly squeezing Saya's hand before letting go, Yuu approached the half-sisters coming near.

First was Toyoda Kanna. At 28 and single, she was the second eldest after Satsuki here. Giving off a managerial vibe with her well-fitted suit - fitting for the successor candidate of her mother Koyuki's company. Slightly shorter than Yuu with shoulder-length black hair. Though wearing light makeup, her fine features compensated fully.

Next was Mitane Moeka. 27 and single. Short bob hair with inward curls. About 160cm tall and plump, but possessing the largest breasts here - eyes inevitably drawn to her half-exposed cleavage. Yuu found himself wanting to be pampered by this droopy-eyed, gentle-mannered woman.

This was Yuu's first reunion with Kanna since late August's mixer, and with Moeka since mid-August at Hesperis. Following age order, Yuu exchanged greetings while hugging the half-sisters without hesitation. Kanna, Moeka, and the sisters meeting him for the first time all accepted Yuu enthusiastically, smiling warmly as they stroked his head affectionately. With over ten women, each embrace felt too brief, nearly lingering longer than intended.

Finally, the dissimilar sisters who had been waiting quietly approached Yuu.

""Yuu!""  
"Mana-neé, Rina-neé, sorry to keep you waiting!"  
"N-no, it's fine..."  
"We missed you"  
"Me too"  
"I heard you're pregnant"

Yuu spread his arms and embraced both at once for the first time since Hesperis. Older sister Mana worked at a sports company, younger Rina attended voice acting vocational school. Though their family home was in Gifu Prefecture, both now lived in Kanagawa. Their first night with Yuu at Hesperis had apparently succeeded - their double pregnancy delighted their birth mother. Though not visible through dresses, when pressed close, their bellies felt softly rounded. Rina's ample breasts against him lifted Yuu's mood, but first he whispered softly:

"Morning sickness okay? Bodies holding up?"  
"Mine was relatively mild, but Rina had it worse"  
"Ugh... remembering it... though I guess it was good for dieting?"  
"That was hard to watch"  
"But having big sis there helped so much!"  
"Being together definitely gave us strength"  
"Well that's good"

Mana had played tennis in school - cheerful and straightforward. Rina was indoor-oriented with otaku hobbies, quite shy. Yuu recalled how she could barely speak to him initially. Her natural anime-like voice was charming when she did talk. Though opposites, their sisterly bond remained strong.

"I wonder whose child it is... yours or mine. So exciting"  
"Wish we knew boy or girl"  
"For me, I'll be satisfied if you both deliver safely"

Yuu casually rested his hands on their bellies, stroking gently. His words made both sisters smile genuinely. Though both in Kanto, Saitama and Kanagawa were distant, and Yuu was busy. Having joined today's party hoping to see him, Mana and Rina were deeply moved to finally talk with Yuu.

While speaking with the sisters, Yuu glanced back. Sister Elena was sandwiched between Masaki and Sakuma with other similar-aged half-sisters before her, managing conversation somehow. Elena was reclusive with extremely limited social circles. Though graduating from Sairei Academy like Yuu, she barely contacted classmates - her stunning looks and attitude inspired admiration but few close friendships. At previous mixers too, she'd spoken little beyond family and Suzanna/Saira.

No need to force friendships. University would offer diverse people - Elena could build relationships at her pace. But getting along with these half-siblings - too many for mere relatives - wouldn't hurt. Elena caught Yuu's eye with a help-seeking look, but he just smiled and waved. Martina was deep in chat with the "mama-sans". Once those women started talking, leaving them be was wisest.

After finishing with Mana and Rina, Yuu headed toward the corner where three young mother-daughter pairs stood. They'd been watching Yuu but hesitated, yielding to the other half-sisters. Mothers appeared early-to-mid twenties. Daughters were preschool age, about 3-5. Girls wore frilly, fluttery dresses while mothers favored plain but practical pantsuits. Up close though, subtle necklaces and ribbons added festive touches.

"Happy New Year"  
"Ah! Happy New Year!"

Yuu greeted the mothers - his half-sisters. All three were first meetings. Living in Tokyo but busy balancing work and childcare, this was their first gathering since giving birth. After exchanging greetings, Yuu crouched to eye-level with the oldest-seeming girl. Fair-skinned with flaxen hair in twin tails. Large eyes with light brown pupils. Her mother looked similar - perhaps mixed-race. The girl had been studying Yuu curiously but tensed when their eyes met.

"Hello"  
"H-h-hello!"  
"What's your name?"  
"H-Haruka! I'm 5!"  
"Oh~ Haruka-chan? Lovely name"  
"Ahaha"  
"I wanted her to be a reliable girl people could depend on. Got permission from Haruka-san for the name. For her March birth - the 'spring' in fragrance"

Yuu glanced toward the "mama-sans" chatting behind. The event's hostess shared the same name reading. But "Haruka" was common for girls - probably coincidence - when the mother elaborated. Hearing this, Yuu stroked Haruka's head warmly.

"Come to think of it, Haruka-chan does smell like spring flowers. May I hold you?"  
""Eh?""

No immediate reply. Mother and daughter exchanged looks. Having never been refused before, Yuu had asked casually - perhaps too familiar for first meeting.

Reality was the opposite of Yuu's assumption. The mother had conceived naturally through foundation connections but didn't cohabitate with the father. Meaning this was Haruka's first time seeing and speaking to a real man. Being held was beyond her expectations.

"Of course. Let him hold you"  
"Um... please"

Yuu smiled at Haruka, who bowed with hands clasped.

"Then, young lady, I'll hold you"  
"Yes... W-wah!?"

Yuu slid his arms under Haruka's shoulders and lifted. Preschoolers weighed around 20kg, but Haruka felt light - perhaps petite from her early birth. Startled, she clung tightly to Yuu. Eyes darting restlessly at the height and unprecedented closeness to a young man.

Meanwhile, Yuu felt deep affection from her sweet, uniquely childish scent and soft skin. If he felt this for a half-sister's child, how much more for his own? The saying "you wouldn't feel pain even if they were in your eye" might be true.

"W-want me to hold you too!"  
"Me too!"

Seeing Haruka held, the other two girls clamored enviously. Mothers looked troubled, but Yuu readily agreed.

"One by one. First, your name?"  
"Y-Yukino"  
"Yukino-chan! Lovely name! Come here"  
"Okay!"

Yukino (4) had long, silky black hair and a snow-white dress matching her name. Next, he held energetic, tomboyish Kaho (3) with short hair.

Haruka pressed her chest nervously, cheeks slightly flushed while looking up at Yuu. Yukino kept clutching Yuu's slacks. "Yay! So high!" cheered Kaho, bouncing joyfully. Three distinct reactions. Noticing Haruka wanting to speak while touching his pants, Yuu crouched again to eye-level.

"U-um... Yuu... err"  
"Hmm... 'big brother' might confuse with others. How about calling me Yuu-nii?"  
""Yuu... nii""  
"Kyaha! Yu-nii! Yu-nii!"  
"Yuu, nii, right?"

Patting hyper Kaho's head while correcting, though doubtful it would stick. Not just Haruka - Yukino leaned in wanting to speak too.

"Um, um... Yuu-nii, will you..."  
"Go on, say it"  
"When I grow up... marry me?"  
"Marry Mama?"

Haruka wished to marry him someday. Yukino wanted him to marry her mother. Both utterly serious.

"Mama says if I find a good man, never let him escape but marry him"  
"Mama says she really wanted to marry"  
"If younger, I'd date Yuu and marry him"  
"She said that earlier!"  
"My mama too!"

Children listen well to adult talk, even muttered. Mothers panicked, trying to cover mouths - too late. Being wanted by women, even little girls or mothers, pleased Yuu. Smiling, he looked at them.

"First meeting today, but to me, your mothers are wonderful sisters, and you're adorable nieces. I want us close from now on. Want to meet as much as possible. And... how about entering Sairei Academy like me? Then if you become fine ladies like your mothers... let's marry? For now today..."

Yuu hugged each and kissed their cheeks.

"Ah... yes! I'll become a splendid lady like Mama!"  
"Wow..."  
"Yay! Marry! Marry Yu-nii!"

Resolute Haruka, dazed Yukino, still excited Kaho. After patting each head, Yuu stood and faced the mothers.

"Not flattery - you're all truly young and beautiful"

Like with the half-sisters earlier, Yuu approached and hugged each. Having male relations and bearing children made them luckier than most women here. But these single mothers were still young. Held tightly by Yuu with beauty praised in their ears, warmth seeped into their parched hearts like water.

Sensitive ears grew wet from whispers alone. Hands on Yuu's back felt hard muscle - never wanting to let go. Fantasizing about sex with Yuu and bearing his child. After separating, all three gazed at Yuu heatedly. Now three little girls clung to Yuu's legs, immobilizing him. Then a group approached calling his name - the "mama-sans" led by Haruka.

Their presence made the mothers hastily peel off their daughters.

"Yuu, finished greetings?"  
"Yes, somehow"  
"Then come eat here"  
"Now that you mention it, I'm hungry"  
"Here here, Yuu-chan! Food's delicious. Eat eat"  
"Haha. Mom, I'll get it myself"

Now surrounded by Martina and the mother-generation, Yuu ate. Being among few males and youngest, everyone wanted to feed him. Soon Yuu was completely full.

---

### Author's Afterword

It feels like the chapter ended with reuniting with half-sisters and interacting with little girls. Every age has charm, but I find preschool girls' precociousness especially adorable.

### Chapter Translation Notes
- Translated "ポップチルドレン" as "Pop Children" to preserve the original nuance of youthful energy
- Translated "ケッコン" as "marry" (from 結婚) to maintain directness per translation rules
- Preserved Japanese honorifics (-neé for sisters, -chan for children)
- Translated "ママさんズ" as "mama-sans" to convey the group dynamic of older women
- Used "half-sisters" consistently for 異母姉 (different mothers) to distinguish from full sisters
- Transliterated sound effects (e.g., "Kyaha!" for きゃはっ)
- Maintained original name order (e.g., Toyoda Kanna) per style rules