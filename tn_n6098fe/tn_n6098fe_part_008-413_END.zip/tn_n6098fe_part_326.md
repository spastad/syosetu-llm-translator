## 306. New Year's Party ③ ~Strong and Fleeting Ones~

The largest and most important event of the Toyoda Sakuya Memorial Foundation is apparently the general meeting held in March.  

Besides the general meeting, serious gatherings like board meetings seem to be held almost monthly, but for now, they don't directly concern Yuu and his family.  

There are regular social gatherings held in January, May, and August. The Hirose family first participated in these starting last August.  

Additionally, during certain summer and winter periods, people freely gather at Hesperis, the hot spring resort in Hakone. Yuu knows that promising women from companies supporting the foundation come to Hesperis to spend their leisure time.  

The foundation's events aim to deepen bonds among those connected to Sakuya who gather from all over the country. Though only a few in number, men always participate, so some women come from far away specifically for this.  

At any rate, there were 20 registered wives alone. Lovers with whom he had relationships for certain periods numbered more than twice that. Countless women were one-night stands.  

Officially recognized children alone number 200.  

Furthermore, grandchildren are being born from the children's generation.  

While historic noble families have many relatives, the scale spanning just three generations is incomparable to others, and since they're scattered nationwide and worldwide, it's impossible to meet everyone in one lifetime.  

That's precisely why at social gatherings, they deepen bonds even with those they might only meet once.  

Even if it's their first meeting, they interact as intimately as old friends reuniting. Yuu found this atmosphere quite pleasing.  

For a while, Yuu was surrounded by about 10 "mama-san" types including Martina while eating.  

Fitting for New Year's, the spread centered on traditional osechi cuisine, but also included fried chicken, roast beef, nigiri sushi, Chinese dim sum, and other diverse dishes.  

They kept offering food to Yuu one after another, eventually taking turns saying "Aah" to feed him. Rather than being played with, it was more like doting on a boy his age.  

Since Yuu obediently complied, the mama-sans were delighted, petting his head or pressing their chests against his back from behind.  

Surrounded by this average 40-year-old beauty brigade of mature women, Yuu not only became full but also felt aroused.  

Midway, Yuu excused himself to use the restroom.  

When he stepped into the hallway, security guards stood at regular intervals, and surveillance cameras seemed to have been increased.  

An extremely strict system was in place to absolutely prevent any external intrusion.  

Yuu could sense the guards' tension heightening the moment he appeared.  

He gave a slight bow as he passed and finished in the restroom.  

Instead of returning to the room immediately, he sat on a sofa placed in the hallway.  

Though he felt the guards' gazes from a slight distance, he tried not to mind and unfolded the participant list he'd been given beforehand and kept folded in his pocket.  

In this era, women's personal information isn't protected, so it listed names, ages, addresses, contact details, and even workplaces or school names.  

For men, only names and ages were listed.  

Yuu was writing down his impressions of each person he met.  

This had become an established habit due to increased opportunities to meet many women at once.  

"Yuu! You were here!"  

The moment she spotted Yuu on the sofa, Elena came running over and sat right next to him on his right, deliberately pressing her shoulder against his.  

"Ah, Sis, bathroom too?"  
"I couldn't see you anymore!"  

Even while talking in separate locations, Elena had apparently been keeping her eyes on Yuu.  

"Wait a sec. Let me finish writing this."  
"Hmm. You're so diligent, Yuu. I knew there were lots of brothers and sisters, but... I only need Yuu."  

Elena leaned her head on Yuu's shoulder and peeked at what he was writing, but quickly lost interest.  

Though she'd conversed reasonably well with her half-brothers today, apparently only Yuu registered in her vision. Her severe brother complex was no joke.  

After noting characteristics of half-siblings and nieces he'd met for the first time (to remember them later), Yuu glanced at Elena.  

Elena had her face sideways on Yuu's shoulder, her left hand on his back, and her right hand constantly stroking his chest—as if replenishing her brother-deprivation after their time apart.  

"Sis, can I ask you something?"  
"What is it?"  

Their faces came close at point-blank range.  

Though Elena usually goes out barefaced without issue, today she wore proper makeup.  

Her ideally beautiful oval face contour and distinct features inherited from both parents stood out even more. Her large eyes opened wide beneath long curled lashes, Yuu's face reflected in her brown pupils.  

Perhaps because she was relaxed being pressed against Yuu, her slightly parted lips colored with deep pink rouge exuded a healthy sensuality.  

She wouldn't lose to celebrities on TV—rather, she was a sister he could boast was more beautiful than average entertainers. She was also academically excellent.  

However, Elena becomes incompetent when it involves Yuu. She tends to be shy and has low communication skills.  

Since being reborn and gaining a new family, Yuu felt a strange sensation toward Elena—like she was both an older sister and a younger sister who required constant attention.  

"Sis, you're aiming for a national qualification in a professional field, right?"  
"Y-yes. I want to get a qualification that'll be useful to Yuu."  

For Elena, Yuu always comes first.  

Though careless in private life, Elena is quite outstanding academically. She initially considered becoming a lawyer.  

When she seriously began entrance exam studies, Yuu once consulted with her about career paths.  

Looking at her high school report card and asking about her strengths/weaknesses, he found Elena was exceptionally strong with numbers—unlike arts-focused Yuu. She'd gotten nearly perfect scores in math and science during high school.  

She might be better suited for accounting than law.  

Thus, she decided to aim for certified public accountant or tax accountant. She's also applying to business/economics departments at universities.  

"I won't tell you to forcibly make more friends, Sis. But when entering society, connections matter. Having many relatives is advantageous, don't you think? Moreover, the foundation has connections with many companies. For future work, if you have such contacts and connections, you should use them."  
"Hmm... you think so?"  

Though "connections" have negative connotations, the term originates from "connection" (ties).  

This was a regret from Yuu's previous life.  

Besides his own abilities and bad luck, having absolutely no contacts or connections contributed to his downfall.  

From Yuu's perspective, while Elena excels academically, her clumsiness in social interactions resembles his past self somewhat, making him worried.  

Meanwhile, for high school graduate Elena, hearing such words from her first-year high school brother was unexpected. Yet strangely, it felt persuasive.  

"Well, if Yuu says so. Maybe I'll try harder."  
"Yeah. Do your best, Sis."  

When Yuu patted her head, Elena's expression softened happily. In good spirits, she rested her chin on his shoulder—like a cat purring.  

"My, Yuu? You were here."  
"Ah, Haruka-san!"  
"Everyone's waiting in the venue, you know."  
"S-sorry."  

Appearing were Haruka and Fuyuno.  

Fuyuno, like Haruka, was Sakuya's classmate and first wife. One of the so-called "First 4."  

Over 180cm tall with a slender model build. Her demeanor was elegant, and her personality gave a very quiet, reserved impression.  

At August's gathering, she'd brought a son named Touya, but he wasn't here today.  

Incidentally, last time she wore a black dress like Elena's, but today it was a chic maroon long dress.  

"Let's go back. Sis."  
"Aah. I wanted to stay with Yuu a bit longer."  

Partly because of what Yuu had just said, when he took Elena's hand, she obediently complied.  

But then Haruka, looking like she'd thought of something, spoke to Yuu.  

"That's right. I had something to tell Yuu. Sorry, Elena. Could you go ahead and let Martina-san know?"  
"Ah... yes."  

Though Haruka said it cheerfully, there was an undeniable forcefulness that even Elena couldn't help but nod.  

After seeing Elena off back to the venue, Yuu found himself flanked by Haruka on his right and Fuyuno on his left, walking away from the venue.  

The room was smaller than the student council room Yuu frequently used at school—about 6 tatami mats. No windows, just a whiteboard, rectangular table, and six chairs. A small room likely used for brief meetings.  

With the two women flanking Yuu as they sat, Haruka took a sheet of paper from her handbag.  

Unfolded, it was an A4 printout densely packed with text.  

"UG Studio Japan?"  
"Yes. A large theme park aiming to open in Osaka in two years."  

The official name printed was "Universal beyond Gender Studios Japan"  
Abbreviated as UG Studio Japan.  

Launched about three years ago by a major film distributor as a theme park where you can fully experience Hollywood movie worlds. Originating in America.  

While its selling point is attractions related to America's proud Hollywood films, it also features limited-time entertainment collaborations with European and Japanese blockbusters.  

A clear difference from a certain mouse-themed land targeting women is its focus on being enjoyable regardless of gender, especially for men. The "beyond Gender" in its name signifies aiming for enjoyment beyond gender.  

Thus, it aspires to create a theme park where both genders can relax without reservation, with considerations for male safety.  

Yuu was unfamiliar with this world's creative works and uninterested in overseas matters, but he'd heard rumors at school.  

Actually, in America, there's an organization founded by Sakuya to deepen gender interaction, which was involved in the original UG Studio's facility development.  

Meanwhile in Japan, influential figures from various fields decided to invite it to Kansai as a rival to a certain land in Chiba. The name UG Studio Japan was decided.  

Moreover, though the foundation has an Osaka branch, it was decided to expand its scale and get involved in establishing UG Studio Japan.  

That's why two of the First 4 relocated to Kansai last April to expand branch personnel. That's why Yuu hadn't met them yet.  

"We want to hear a man's perspective from you, Yuu."  
"From me? But for men, there's Masaki-niisan or..."  
"We want Yuu's opinion."  

Repeatedly told, Yuu realized.  

Haruka and Fuyuno knew about Yuu's reincarnation.  

Meaning, like Sakuya, he was an adult inside with reversed chastity values.  

They apparently wanted opinions from a man with that perspective.  

Though Yuu had worked as a salaried man for about 17 years, he wasn't confident how helpful his opinions would be when shown a large theme park proposal.  

"Well, if I'm acceptable..."  

He couldn't refuse a request from Haruka, central to the foundation that had helped him so much.  

When Yuu agreed, Haruka smiled with relief.  

"Good. Then, tomorrow at... 10?"  
"Make it 11?"  
"Right. Come to the headquarters' boardroom at 11."  

After exchanging meaningful looks with Fuyuno, Haruka conveyed this.  

They'd already decided to stay overnight tonight.  

At the previous gathering, Yuu spent time with Elena, Saira, and Saira's mother Suzanna.  

Though it wasn't decided who he'd be with tonight, he'd certainly indulge in lovemaking with multiple partners.  

He thought they'd set a late morning time considering that.  

"Understood. Then tomorrow at 11. Is that all?"  
"Well..."  

Yuu asked as he saw Haruka folding the printout, but she only gave an ambiguous smile.  

As Yuu tilted his head in confusion, he was suddenly grabbed by the shoulders and pulled close.  

"Huh?"  

Fuyuno, positioned opposite Haruka—on Yuu's left—reached out as if to a lover.  

Though slightly surprised since being doted on by these mother-generation women was common, he didn't dislike it.  

Despite no direct blood relation, he felt genuine motherly love from them. Plus, while physically a generation apart, mentally they felt close.  

Resting his head on tall Fuyuno's shoulder directed his gaze toward her chest.  

Through the V-neck dress opening, her breast swellings were clearly visible. Though not huge, he could imagine they'd fill a palm.  

Feeling vaguely guilty, Yuu turned his face to see her clearly defined collarbones and slender neck.  

She should be in her mid-40s, but even up close, her fair skin showed no spots.  

Though different from kimono, Fuyuno, like Haruka, had her long black hair tied up.  

An elegant perfume scent tickled his nostrils.  

"Hey, Yuu. Don't overdo it, okay?"  

Fuyuno's voice came from above Yuu. A husky, sensual tone reminiscent of an adult woman—like a mother scolding a mischievous son.  

"Um... wh-what do you mean?"  
"Even we hear things, you know. Like how Yuu's been sowing seeds with tons of women."  
"Ah, ahahaha..."  

As foundation board members, these two had undoubtedly heard not only about his impregnating half-sisters and Hesperis incidents but also his school exploits to some extent.  

Though not problematic if known, he'd admittedly overdone it. He imagined they might be worried.  

"It's fine if Yuu works hard however much he wants. Rather, since you're making partners happy, go right ahead. As long as safety's ensured. At school, or our foundation facilities... security's been significantly strengthened since that incident."  
"But Yuu's kind to everyone, so we worry he might get caught by delusional women... or worse, face danger. Don't underestimate this world's women's malice."  

Not only did Haruka speak with loving expression, but Fuyuno also stroked Yuu's head gently while speaking.  

Then Fuyuno rubbed her cheek against Yuu's head.  

"Yuu... resembles him more than anyone."  
"That much?"  

Martina and others had said this before.  

Fuyuno, who likely knew Sakuya best, spoke these words, and Haruka nodded.  

"If a woman you loved was in danger?"  
"Of course I'd save her."  
"Even if you were the only one who could move?"  
"Yeah."  

Sitting upright, Yuu turned toward Fuyuno who'd asked and nodded firmly.  

Sayaka's figure surfaced in his mind.  

If Sayaka called for help, he'd rush to her no matter what.  

"That's exactly it."  
"See?"  
"Um..."  

Before he realized, Fuyuno hugged him from the front and Haruka from behind.  

"Yuu is brave, kind, and a good boy. But now that you're becoming women's hope, we want you to prioritize safety as much as possible. Because..."  
"We can't help imagining worst cases. We mustn't repeat the tragedy of his time."  

Yuu realized.  

He shared something with them from his past life.  

Losing a loved one after marriage.  

Though Yuu was on the receiving end of a one-sided divorce, what befell Haruka and Fuyuno was sudden death.  

Despite differences, he could imagine the depth of their sorrow.  

"Um, I'll keep what Haruka-san and Fuyuno-san said in mind."  
"Fufu. You think we're worrywart, annoying women, don't you?"  
"Not at all..."  
"But it's true we care for you like a real son. If anything troubles you, consult us anytime."  
"Y-yes."  

Yuu remained still as they touched him from head to shoulder.  

But Haruka and Fuyuno realized:  

Having told Elena they were borrowing Yuu, monopolizing him longer would be awkward toward waiting participants.  

After reconfirming tomorrow's appointment, Yuu and the two hurried back to the venue.  

---

### Author's Afterword

Apologies for another dialogue-heavy chapter after the previous one.  

Regardless of Elena, the conversation with Haruka and Fuyuno was a scene I wanted to include in the New Year's party arc. It feels somewhat like a flag being planted, for better or worse.

### Chapter Translation Notes
- Translated "ママさんたち" as "mama-sans" to convey the mature women's affectionate yet dominant group dynamic
- Preserved Japanese honorifics (-san) and name order (e.g., Toyoda Haruka)
- Translated "あーん" as "Aah" to maintain feeding gesture nuance
- Used "First 4" for "ファースト4" as established in Fixed Terms
- Translated "ポンコツ" as "incompetent" to convey Elena's brother-complex induced clumsiness
- Rendered internal monologues in italics (e.g., *This was a regret...*)
- Maintained explicit anatomical terms ("breast swellings", "sowing seeds")
- Kept organization names consistent (UG Studio Japan, Toyoda Sakuya Memorial Foundation)