## 307. New Year's Party ④ ~Tonight's a Hearty Party~

By the time Yuu returned to the venue, the banquet had reached its peak.

What had initially been tables divided roughly by age groups had now dissolved into free mingling. Over half the participants appeared to have consumed alcohol, yet they remained cheerfully boisterous without any signs of severe intoxication, creating quite a lively atmosphere.

Apart from Yuu, the only three males present (his brothers) were each surrounded by their own circles. Tohru, who seemed fond of children, was playing cat's cradle with three young girls. Masaki stood at the center of a mixed group of half-sisters and mother-aged women—Elena included among them—handling the interactions skillfully. Sakuma was being teased by his sisters Saya and Sae, among others.

"Yuu-chan!"  
""""""Yuu!""""""  
"We've been waiting! You took so long!"  
"Sorry, sorry. The conversation ran long. My apologies for making you wait."

Immediately upon entering, Yuu found himself surrounded by Martina and numerous other women. He exchanged hugs first with Martina who welcomed him, then with Elena who had rushed over from farther away. As he embraced his half-sisters who'd been eagerly waiting to talk to him, whispering apologies near their ears, their moods immediately improved. Thereafter, Yuu moved through the venue like a migratory fish, circulating without lingering too long in one place to interact with as many women as possible.

As 9 PM—the scheduled end time for the New Year's party—approached and Satsuki drew near, Yuu found himself encircled by Martina and other mother-aged women. The tipsy "mama-sans"—or perhaps pretending to be drunk—pressed themselves tightly against Yuu. The sober Martina leaned against Yuu's left side as he gently stroked her wavy black hair with his left hand.

Koyuki clung tightly to his right side, her fair cheeks flushed pink from alcohol as she touched him with disheveled gestures. Affected by her allure, Yuu grew bolder, moving his right hand from her slender waist to her buttocks, then resting it on her thigh. When Koyuki responded with a smile rather than resistance, he took advantage and slipped his hand beneath the slit of her qipao-style dress. Under the tablecloth's concealment, his fingers crept from her thigh toward the perilous boundary of her groin, causing Koyuki to release sweet sighs against his neck.

From the front, women took turns leaning across the table to kiss his cheeks, leaving multiple lipstick marks on both sides. All this resulted from Yuu treating these mama-sans not as mothers but as attractive women, lavishing praise on their beauty. Delighted, their doting on Yuu escalated somewhat, which he gladly accepted.

"Yuu, got a moment?"  
"Nn? Ah!"

While relieved her mother Haruka wasn't part of this circle, Satsuki approached Yuu's ear from behind with a wry smile. Not exactly competing with the surrounding women but still mischievous, she kissed his ear then extended her tongue to lick it.

"Staying overnight tonight, right?"  
"U...n...yeah, staying."  
"Well then, got a request~ chu, chuparelo~"  
"Ah, ahh, S-Satsuki nee...nnnh!"  
"That's unfair, Satsuki-chan! Then I want too!" "Me too!" "What about me, nee, Yuu? Wanna suck mama's boobs?" "Hey now, you're drunk!" "Ufufu. Isn't it fiiine? I've always wanted a baby boy to drink from me~" "If Yuu sucks them, it'll get me all horny~" "Yuu's a good man. Second only to Sayaka-san." "My my ufufu. Yuu's junior-chan is..." "Waoh!" "Can I touch?"

"Enough of this!"

Haruka sharply reprimanded the escalating women. While being kissed, having breasts pressed against him, his ear sucked, and various body parts caressed, Yuu's crotch had begun reacting—a development he welcomed, but it prevented him from hearing Satsuki's request.

After the mama-sans calmed down and stepped back slightly, Yuu finally heard Haruka and Satsuki's request. The matter concerned Yuu having impregnation sex with unmarried, childless women over 25 among the attendees.

Biologically speaking, younger ages are considered preferable for childbirth. However, in reality, few teenage girls actually have sex with men and get pregnant—Yuu's surroundings being a special exception. With men generally passive about sex nationally, opportunities are created to connect adult men and women, encouraging marriage and childbirth. Furthermore, in this society, unmarried childless women face increasingly heavy tax burdens starting at age 25. Hence women actively seek opportunities to connect with men during their twenties, but the gender ratio inevitably leaves some without chances.

Even among Yuu's half-sisters at this New Year's party—all beauties who wouldn't lack suitors in his previous world—many had aged without marrying or bearing children.

"That child... Her standards are too high. She must still compare men to our father in her heart."

So went Koyuki's assessment of her daughter Kanna. Indeed, like Satsuki, women who'd been doted on by Sayaka during his lifetime often remained single without forming bonds with specific men.

"But Yuu is special."  
"Indeed. Please take care of my daughter."  
"I'd be glad to."

Yuu would've happily taken on not just a mother-daughter combo with Koyuki and Kanna, but all the beautiful mature women present—though he kept silent, thinking that might be too greedy. Among them, the unmarried childless women over 25 were Kanna, Moeka, and sisters Saya and Sae. He could ejaculate inside each once—twice if possible. Though handling all four might be difficult, he wanted to impregnate as many as possible with his seed.

"Your room is on the first floor this time—different from before. No intruders should disturb you, so do your best there, Yuu."  
"Haha, yes."

When he'd stayed last August, he'd encountered intruders while moving rooms. Tonight, with four women to handle, Yuu anticipated staying holed up in his room until morning.

"Ah! Right, right! Please take care of that woman too!"  
"Huh?"

Where Satsuki pointed sat an unfamiliar woman—a Western-looking foreigner. Hard to guess her age due to ethnicity, but likely late twenties to early thirties. Softly curled red hair reached mid-back. She wore a strapless white dress printed with multicolored roses. Standing over 180cm tall, her height and long legs created a striking, flower-like presence as she chatted cheerfully with crossed legs, wine glass in hand.

Had she just arrived? Having no memory of conversing with her, Yuu was about to ask Satsuki when Haruka clapped her hands while addressing the room. Without raising her voice, the chatter naturally subsided as everyone turned toward her.

"As much as we may regret parting, it's time to conclude our gathering."

About half would proceed to the lounge for an after-party. Haruka, Fuyuno, and Koyuki planned to drink until dawn. Pregnant Martina and Satsuki, along with Mana and Rina (who were pregnant for the first time), would refrain from alcohol—Mana and Rina wanting to ask experienced mothers Martina and Satsuki questions.

The trio with young children would leave now. However, the energetic Kaho started fussing about not wanting to go, and Haruka and Yukino seemed to share the sentiment, tears welling in their eyes despite not voicing it. Even when their mothers urged them, all three resisted leaving the venue. Understandable—they'd not only eaten delicious food with many older sisters today but also been entertained by young men starting with Yuu.

Seeing this, Yuu enlisted his brothers. As he picked up Haruka to soothe her, Tohru similarly held Yukino and Masaki held Kaho. Unfortunately, Sakuma was declined due to his "scary face." Thanks to this, the three young girls cheered up and departed peacefully.

After seeing off the three parent-child pairs, Tohru spoke to Yuu.

"Yuu, what after this?"  
"Spending time with 4... no, 5 people."

He didn't specify what they'd do together, but the implication was clear.

"Five!? Well, if it's Yuu... guess that's within acceptable range... Haa."  
"Very Yuu-like. I was surprised too when I first heard."  
"F-for real? Damn Aniki, you're insane!"

Having experienced Hesperis, Masaki and Tohru were shocked yet accepting. Sakuma turned pale with a second shock upon hearing his biological sisters Saya and Sae were among the five—never imagining anyone could dominate his strong sisters in bed. Tohru had one partner, Sakuma was forcibly assigned two, and Masaki also had two for the night. Apparently both Sakuma and Masaki had taken a liking to Elena but were rejected.

"Well then. Yuu, good luck. Don't overdo it."  
"Likewise. Odd coming from me, but take care of our sisters."  
"Yeah. You brothers too. See you later."  
"Let's eat together tomorrow if no one's down."

After the four brothers left the New Year's party venue, Satsuki led them through several corners deep into the building, surrounded by security, where they exchanged farewells. From there, each entered individual first-floor special restrooms prepared for men to spend the night.

Between September and November, the annex underwent emergency expansion and renovation, leaving a faint scent of new building materials. Security checkpoints stood along the way, and Yuu heard each room had no windows, completely sealed off—likely due to his recent kidnapping incident.

"Waoh! Amazing room~"

Five special restrooms were prepared: Rooms 102-105 designed for up to four users, while Yuu's Room 101 was slightly larger. The enormous bed—big enough for 5-6 people—made Yuu wonder if it had been assembled in pieces or installed before walls were sealed during renovation. A compact counter kitchen and sofa set were installed, and the bathroom appeared twice as large as his home's, easily accommodating 4-5 people.

After surveying the room, showering, and donning the provided white gown while drinking water from the fridge, a soft knock came. Opening the door revealed five women including Kanna still in party dresses.

"Please, come in."  
"O-ojama shima~su"  
"Excuse us"  
"Really came... Welcome"  
"Yuu..."

Though overjoyed by the advance notice about tonight, Kanna and the others now felt anxious. During the party, alcohol and atmosphere had facilitated touching and bonding with Yuu. Yet spending a night with Yuu—over a decade younger—felt somehow improper. But when Yuu naturally smiled and invited them in, even taking each hesitant woman's hand, not just Kanna but Moeka, Saya, and Sae smiled happily. The last one—the foreign woman—looked bewildered as she spoke.

"Umm... Me, really okay being here?"  
"Absolutely. First meeting, right? I'm Yuu."  
"Yuu...? H-hajimemashite. Lucy, I am."  
"Lucy! Thought I recognized you! That Lucy Sawyer!?"  
"The real one...?"

Saya blurted out in a shrill voice while Sae covered her mouth in shock. Finding the doorway unsuitable for conversation, Yuu guided them to the sofa set. Since some were meeting for the first time, they decided to chat over tea.

Of the five, Yuu knew two. Kanna (28), eldest daughter of Koyuki—one year younger than Haruka's group and still using the Toyoda surname. Holding a key position in her mother's restaurant chain, she was a youthful beauty like her mother and highly competent. Yuu knew her kind nature and found it puzzling she remained unmarried. Today he'd learned from Koyuki that her standards were too high, with almost no dating experience.

The other was Mitane Moeka (27). Her mother was from Akita Prefecture, having met Sayaka during a high school trip to Tokyo. After growing up locally, Moeka encountered her father while attending Tokyo university and secured Tokyo employment through Toyoda family connections. Yuu had taken her virginity at Hesperis—her fair, mochi-like skin typical of Tohoku beauties left an impression.

Saya (26) and Sae (25)—sisters of half-brother Sakuma—were first meetings today. Their mother had married Sayaka but, like Martina, returned to her Gunma Prefecture hometown after his death. They'd actually been notorious delinquents who'd stormed in intending to assault Sayaka but got overpowered in bed—resulting in one boy and two girls, suggesting passionate relations. Saya worked as a junior high teacher locally, Sae as an apparel shop clerk.

The last: Lucy Sawyer (34) from Canada, met by Sayaka during his late-life US tour. Then a high school student modeling part-time while unknown, she'd accepted Sayaka's invitation to Japan. Their three-month relationship ended abruptly with Sayaka's death—similar to actress Tsutsui Takako's position. Incidentally, Lucy knew Takako who became the next mistress; close in age, they'd grown friendly. While Takako paused acting due to pregnancy, struggling upon return, Lucy—boosted by being Sayaka's chosen foreign model—gained explosive popularity through magazine features and CM offers in Japan. Now a supermodel popular in Japan, Canada, and America.

"Wow... Getting to be with such beautiful onee-chans, I'm so lucky."

For Yuu, this came from genuine sincerity. Yet these women felt fortune-showered today, unable to hide their happiness at his words despite some confusion.

"Really? Yuu, really, me, okay?"

On the sofa, Yuu sat flanked by Kanna and Moeka, facing Lucy, Saya, and Sae. In his previous world, having sex with his father's lover/mistress might feel complicated. But present Yuu didn't mind much—unlike with Takako whom he'd known through Martina's dramas.

Lucy's long legs before him showed no excess fat—just slender perfection. Sitting upright with perfect posture, her model training showed. Though Yuu usually found foreign fashion models sexually unappealing—tall with long thin limbs but lacking allure—Lucy's soft expression and bust radiated feminine charm.

"Lucy. I... want to have sex with you. Truly, from my heart."  
"Oh... Been too long, what should I do?"  
"I'll lead."

Following the flow, they decided to proceed by age starting with Lucy. Though Yuu would've been fine with dresses on immediately, he suggested they shower first to avoid staining or wrinkling the special outfits.

---

### Author's Afterword

Finally getting to the real ero part next time.

### Chapter Translation Notes
- Translated "宴もたけなわ" as "banquet had reached its peak" to convey the lively atmosphere
- Rendered "ママさんたち" as "mama-sans" to preserve the Japanese term for middle-aged women
- Translated "ジュニアちゃん" as "junior-chan" maintaining the diminutive honorific
- Preserved "ちゅっ, ちゅぱれろぉ" as "chu, chuparelo~" for onomatopoeic kissing sounds
- Translated "子作りセックス" literally as "impregnation sex" per explicit terminology rule
- Kept "onee-chan" untranslated to maintain cultural nuance of addressing older females
- Used "qipao-style dress" for "チャイナドレスのように" to specify the garment type