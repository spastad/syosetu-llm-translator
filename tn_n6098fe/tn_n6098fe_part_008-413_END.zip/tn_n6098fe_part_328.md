## 308. New Year's Party ⑤ ~Year-Round Enthusiasm "I Want You"~

"Yuu. It's out."  
"Eh..."  
"Hmm? Is my body... strange?"  
"No... it's incredibly beautiful. So beautiful I'm speechless. I'm completely captivated."  
"My... *giggle*. I'm happy."  

Lucy, who had showered first, came straight to Yuu waiting on the bed after drying herself with a towel, completely naked without any shame. In this world with reversed chastity norms, women rarely feel embarrassed about nudity before men - only if they're self-conscious about weight or similar reasons.  

*Come to think of it, I recall hearing something once. Behind the scenes at fashion shows, models change clothes naked regardless of men present due to tight schedules. Lucy especially has no reason for shame in this world.*  

Though she hadn't washed her hair, her long red locks were tied back to avoid inconvenience. Several damp strands clung to her pale skin, looking glossy and alluring. Her proportions seemed superhuman - perhaps eight or nine heads tall - with notably long legs. Though slender-limbed, her breasts and hips curved femininely. Her breasts were perfectly sized, not too large nor small. Professionally groomed, her pubic hair was completely shaved.  

Even a top model felt pleased being complimented by Yuu. Lucy struck a pose - angling diagonally toward him, right hand on hip, right leg slightly bent and lifted mid-air. Though her weight rested on the left leg, she remained perfectly still. Her toned abs and overall physique revealed rigorous training. Maintaining this model-worthy body into her mid-30s clearly resulted from daily discipline.  

Yuu felt he was viewing a masterpiece, thinking Lucy could perfectly recreate the Venus de Milo. Rising from the bedside, he discarded his gown and stood naked too. Lucy's composed expression instantly shifted to shock as she covered her mouth, seeing his erection spring to life.  

"Lucy. Come here."  
"Y-yes..."  

Lucy worked in a female-dominated industry. Though male models existed, even supermodels remained untouchable. This was her first naked encounter with a man since Sakuya - 16 years later. Despite twice Yuu's life experience, Lucy trembled with virgin-like nervousness, as if Sakuya had reappeared.  

"Lucy, are you okay?"  
"Wah! Ah? I..."  

Seeing tears streak Lucy's cheeks, Yuu embraced her.  

"Feeling sentimental after so long?"  
"*Sniff*... Sorry, Yuu."  
"It's fine. Don't worry. Come here."  

Held by Yuu, Lucy approached the bed. Though Yuu thought supermodels wouldn't arouse him, Lucy's magnificent body proved otherwise - his cock stood rigid.  

"Kyah! Yuu?"  
"Lucy. I'm incredibly horny and can't hold back."  
"Ah! Ah! Me too!"  
"Lucy!"  

Yuu pinned Lucy to the bed. At kissing distance where his face reflected in her blue eyes, he claimed her lips. First light pecks, then deep, wet kisses. For Lucy, her first kiss in 16 years. Yuu's chest against her breasts and hot cock against her lower abdomen swirled her senses, drawing sweet gasps.  

After repeated kisses, they locked lips wetly. Red hair tangled across her face as they embraced. Lucy ran her hands over Yuu's head and back.  

"Mmph! Ah... un... mmmph!"  

While kissing deeply, Yuu's tongue pried past Lucy's lips. Her eyelids fluttered open at the mucosal contact.  

"Yu...u...n! Ooh! Unh!"  
"Eh?"  

Lucy's long-dormant passion ignited, blazing hotter through kissing. Before Yuu realized, Lucy had rolled atop him. They'd rotated while kissing, luckily not falling off the wide bed. Now Lucy's long tongue invaded Yuu's mouth. He accepted it, their tongues sliding and prodding with wet *picha picha* sounds, fueling mutual arousal.  

"Haah, haah, Lucy!"  
"Yu...Yuu! Ah, mmph..."  

They'd briefly part to call each other's names before locking lips again. Another rotation put Yuu on top. His right hand groped her breast - a soft mound slightly spilling from his palm. The nipple hardened instantly against his palm.  

"Wow... so hot."  
"Next is Moeka's turn."  
"U-un... but watching Yuu and Lucy-san..."  
"Even I'm getting... strangely excited."  
"M-me too."  

Kanna emerged after a thorough 30-minute shower. She'd expected Yuu and Lucy to be coupled or finished. Instead, they kissed passionately while rolling across the bed. Despite their 10cm height difference, Yuu seemed to dominate the taller Lucy. More passionate and raw than any adult video, the sight made Moeka and the other two blush and fidget in their underwear, dampness spreading at their crotches.  

Even after Moeka went to bathe, the others kept watching. Yuu and Lucy were lost in their world. Between kisses, Yuu licked Lucy's slender neck, collarbones and shoulders. Lucy tried reciprocating but could only pant while caressing Yuu's back and buttocks. Their tangled legs left Yuu's knee soaked with her juices where it parted her thighs.  

Yuu shifted rightward, licking her nipple while sliding his right hand down her smooth abdomen. His hooked right foot spread her legs wider. Just touching his middle finger to her slit produced a wet *squelch* - she was drenched.  

"Aahn! Yuuuu!"  
"Lucy, touch my cock too."  
"Ahh, hot... so hot and hard... ah! Ah! Hyahnn!"  

Guiding Lucy's hand to his cock, Yuu slowly drew his finger along her slit, exposing her clit. Lucy's body jerked as *pishuu* she squirted, soaking his wrist. Probing her entrance, *kuchu kuchu* sounds echoed. When he inserted his middle finger, her wet pussy swallowed it greedily while tightening internally.  

"Time to put my cock in."  
"Hah! Hah! Haauuushokoooooo!"  
"Lucy? What position?"  
"Oh! Yes! Yes! Ah! Yuu! Yuu! Do... as you like!"  

Yuu finger-fucked her deeply. Lucy could barely speak through her moans. Smiling, Yuu withdrew his finger, straddled her right leg, and positioned himself between her spread thighs. Though feigning calm, he'd been desperate to enter. Precum dripped from his throbbing cock as he pressed against her slick slit.  

"Ahh, Yu...u..."  
"Here goes, Lucy."  

Her red hair, now thoroughly tangled, fell across her face. Brushing it aside, Lucy gazed at Yuu with moist eyes and reached out. Yuu clasped her left hand while holding her thigh with his right, adjusting his position. The tip pressed against her entrance with a *nupuu* sound - wet and yielding. Encouraged, Yuu pushed forward.  

"Gwah! Ah! It's in... ah... Lucy."  
"Higuu! Ugh! Aah... ah... Yuu! Ahaa..."  

After full insertion, Yuu paused. Releasing her thigh, he grabbed Lucy's shoulder and buried his face in her soft breasts, comforted by their warmth.  

They stayed still for 2-3 minutes. Lucy's right hand remained clasped with Yuu's left while her left gently stroked his head. Though motionless, Lucy's pussy felt scalding hot, gradually tightening around him. But it wasn't enough.  

"Moving now?"  
"Nngh?"  

Face still buried, Yuu looked toward Lucy and thrust.  

"Ah! Ah! I'm having... sex... moving... oh! Deep! Yuu! Wait! Big cock! Haan! Unbelievable! Wait! Noooooooo!"  
"Haah, haah, can't wait. Lucy. Feels too good. Can't stop thrusting. Might... not last."  

Increasing English interjections revealed Lucy losing composure. Her free hand gripped the sheets while she shook her head side-to-side. Meanwhile, vaginal folds milked Yuu's cock, intensifying pleasure with each thrust. He wanted Lucy to climax first but was drowning in uncontrollable ecstasy. At least his first thick load would surely impregnate her.  

Pausing, Yuu sat up. Sliding both hands under her knees.  

"Huh? Yuu?"  
"Final sprint. Might be heavy, sorry. Up we go!"  
"What!? Naah!? Aaaaaaah!"  

Lifting both legs while mounting her, Yuu raised their joined hips - the breeding press position. The spectators gasped.  

"Gonna cum like this."  

Yuu sank his hips, grinding deep. When he lifted slightly, their mixed juices dripped onto the sheets. Deep thrusts. Grinding. Pulling out.  

Staring at Lucy, Yuu repeated the motions. Lucy clung to him, wrapping her long legs around his waist.  

"U-hyii! Ooh... ooh... my god! Oh yes! I...I...I'm coming!"  
"Guh... Lucy! Aah! I'm... cumming!"  
"Yuu! Yuu! Ahh! Ah! I'm... coming... I'm coming!"  

Lucy screamed loud enough to echo through adjacent rooms as Yuu ejaculated. Keeping his cock deep against her cervix, Yuu pumped thick semen inside, relieved they'd climaxed together.  

---

### Author's Afterword

Looking at fashion show photos, perhaps due to avant-garde outfits, models don't seem particularly sexual. But seeing candid shots of some foreign models in casual wear, I found them incredibly attractive. They must be women whose mere presence creates art. Thus I aimed to give Lucy, like actress Takako, that ageless special aura.  

### Chapter Translation Notes
- Translated "年中夢中" as "Year-Round Enthusiasm" to capture the pun with "I Want You"
- Preserved Japanese honorifics (-san for Lucy) and name order (Hirose Yuu)
- Translated explicit anatomical terms directly ("cock", "pussy", "semen")
- Rendered sexual acts without euphemisms ("ejaculated", "squirted")
- Transliterated sound effects ("picha picha", "nupuu", "pishuu")
- Italicized internal monologue section
- Maintained dialogue formatting rules (new paragraphs for each speaker)
- Preserved English phrases spoken by Lucy ("Wait", "Big cock", etc.)