## 309. New Year's Party ⑥ ~Always Loving Women~

Feeling the sensation of having ejaculated copiously inside Lucy's vagina, Yuu grabbed several tissues from the bedside box and pressed them against her gaping vaginal opening just after pulling out his penis.

"Yu, Yuu..."  
"Kanna-neé"

When called in a trembling voice, Yuu turned to see Kanna, now completely naked, approaching the bed. Perhaps aroused by watching Yuu and Lucy's passionate sex, her expression was utterly lustful. Though he imagined her as slender, her breasts were unexpectedly full. As she hugged herself, her ripe fruit-like breasts were emphasized even more.

If supermodel Lucy's nude body was a work of art with perfected beauty, Kanna - though shorter than Yuu - had a well-proportioned body that seemed comfortable to hold, her curves exuding a sweet, fragrant sensuality. Even immediately after ejaculation, Yuu's erection remained standing firm as he turned to welcome Kanna, moving toward the edge of the bed.

"Yuuuuuuuuuuuuuuuuu!"  
"Huh?"  
"Whoa?!"

A white nude body rushed past Kanna at incredible speed. In Yuu's vision, he saw Moeka approaching, her large breasts bouncing vigorously. Yuu caught Moeka with open arms in a kneeling position as she jumped at the bedside. The impact made him fall backward, but the wide bed saved them.

Moeka, straddling Yuu who lay on his back, wrapped her limbs around him and pressed her lips against his. Perhaps begrudging the time to dry off, water droplets fell from her hair tips, and her voluptuous body was still damp. But as if reflecting her blazing passion, Moeka's skin surface seemed to radiate heat.

"*Chu*, *chuuuuu*! *Nerorerooo*... Haah, haah, you know, Yuu. I couldn't forget that night, how many times I comforted myself while remembering it. So... I wanted to see you. I wanted to see you and do it again. *Chupa*, *chupa*, *chup*. Haah... I love you, love you so much! Yuu, now, I only have eyes for Yuu... I'm sorry. Sorry. You must hate being clung to by an older, plump sister with such an age gap, yet you gently accepted me just like that time... Ah, Yuuuu... I love you."  
"Mo·e·kaaa!"  
"Ouch!"

A dull *baching* sound echoed. Moeka had been kissing not just Yuu's lips but his entire face, sliding her tongue while grinding her hips to press her genitals against his penis. Left alone, she would have skipped the order and inserted it.

Just in time, Kanna with an angry expression slapped Moeka's large butt from behind.

"We decided on age order, didn't we? Acting selfishly will trouble Yuu. And think about Saya and the others waiting too."  
"S-sorryyyyy. When I saw Yuu right after my bath, I couldn't control myself."  
"First of all, Moeka, you lost your virginity to Yuu in August, right? I get you can't forget him after being a long-term virgin. But me too... I haven't done it for years either!"

Moeka sat seiza-style bowing her head before Kanna who stood imposingly angry. Seeing Moeka jump on Yuu and kiss him fiercely, Saya and Sae were first dumbfounded then irritated. They too had been restraining themselves from doing the same. Kanna had voiced their feelings, so they remained calm now.

Only Yuu could soothe Kanna whose resentment hadn't subsided after having her good mood stolen.

"Kanna-neé"  
"! Yuu... Ah"  
"Moe-neé seems to have reflected, so let's forgive her"

Yuu hugged Kanna from behind, whispering while rubbing his cheek against hers. As Kanna blushed and fell silent, he used both hands to turn her around halfway. Facing Yuu, Kanna's expression showed embarrassment instead of anger, ashamed that Yuu saw her furious side.

Before Kanna could speak, Yuu hugged her and covered her lips.

"*Anmu*... *n*, *churu*... *nhaa*... Yuu! *Nnn*... *afu*, *uun*... *hau*... *nnn*! Yuu! Yuu!"

Only sweet breaths and Yuu's name escaped Kanna's lips. The passionate kiss while embracing melted Kanna's heart completely. Moreover, Yuu's hand firmly grasped her well-shaped buttocks, and his still-hard cock pressed against her lower abdomen. Kanna's secret place overflowed with love juices, dripping down her thighs.

"Ahh... hey, Yuu? Ha, hurry"  
"Shall we go to bed, Kanna-neé?"  
"Un... let's"

Kanna tilted her head cutely and rubbed her face against Yuu's shoulder. Her inner self was so happy she wanted to frolic, but suppressing it was typical Kanna. To Yuu, even with the age gap and being nearly 30, he found the demure Kanna adorable.

As Yuu climbed onto the bed still hugging Kanna, he stopped moving. His gaze fell on Moeka who remained sitting seiza-style with bowed head.

"Moe-neé, don't stay sitting there forever, come here"  
""Eh?""

At these words, Kanna and Moeka simultaneously looked at Yuu in surprise.

"You apologized for jumping the queue. I'd rather have all three of us together. Kanna-neé goes first for insertion. Hey, okay? Kanna-neé"  
"Ah, ahh! Okay! If Yuu wants it, I understand! Aahn!"

Yuu reached his right hand toward Kanna's crotch and played with her vaginal opening. Already soaked, it made *kuchu kuchu* wet sounds with each finger movement. Originally, Kanna and Moeka were close in age and got along well. Still, familiarity requires courtesy - that's why she got truly angry earlier. For Kanna, as long as she got to go first, she didn't mind at all.

Though Kanna's body was ready for insertion, Yuu wanted all three to enjoy together. First, with Yuu in the middle, Kanna and Moeka hugged him from both sides. Moeka, accepted by Yuu and Kanna, was tearfully overjoyed. Yuu alternated kissing both while reaching out to knead their breasts with both hands. When Kanna, unable to resist thinking about his cock, asked to touch it, they changed positions.

"Haaaaaa... I knew it was big, but seeing it up close is amazing, Yuu's cock. I've never seen one so large and mighty before"

Kanna was on all fours facing the opposite direction from Yuu on his back, bringing her face close to the erect penis standing before her. Some time had passed since ejaculating inside Lucy, so it seemed slightly dry, but the shaft from base to tip was wet and glossy while maintaining its erection. Above all, the mingled bodily fluids of Yuu and Lucy emitted a unique scent without needing to bring her nose close. Just feeling the heat and hardness with her fingertips while sniffing with her nose made Kanna feel a *kyun* throb.

"Ahh..."

With sensually moistened eyes, Kanna thoroughly observed from the glans to the veiny shaft, sliding her fingertips to confirm the texture before opening her lips. For her first time in years - moreover facing an exquisite cock beyond anything she'd seen before - she drooled as she took it into her mouth.

Meanwhile, Moeka lay sideways giving Yuu a lap pillow. Yuu recalled when he took Moeka's virginity, pretending to be her childhood crush neighbor brother and enjoying sibling roleplay. When he asked what she wanted today, Moeka said she wanted to fulfill Yuu's desires instead. She was probably grateful he mediated her quarrel with Kanna.

Thus, Yuu held like a baby with his head cradled was now suckling on Moeka's weighty breasts. The breasts before his eyes had considerable volume. Though her nipples were small, her areolae were large. For her age, the pigmentation seemed light, appearing pale pink. Touching them felt marshmallow-soft. After licking around the nipples with his tongue, Yuu took a nipple whole into his wide-open mouth.

"*Nn*... *kufuu*... Yuu is... sucking my breasts... Ahhn! Such a naughty baby... Ah, ah, don't suck so much... *nnnn*!"

Her 11-years-younger brother sucking her breasts like an infant. Was it maternal love? Sibling love? Or perhaps shota love? Regardless, shivers of pleasure ran through Moeka, and strength filled her arms hugging Yuu's upper body.

While receiving a blowjob from Kanna and suckling Moeka's large breasts in a breastfeeding style, Yuu basked in supreme bliss. As for his hands: his right arm wrapped around Moeka's waist from behind, while his left hand kneaded her other breast. Supporting from below, he enjoyed the plump softness before tweaking the nipple with his fingertips.

Having both nipples stimulated simultaneously, Moeka let out loud moans and pressed her breasts against Yuu. Though his mouth and even nose were nearly buried in the voluminous breast flesh, being crushed by the softness felt irresistibly good. Though he wanted to keep kneading Moeka's breasts forever, Kanna's buttocks shaking with each suck entered Yuu's view. Unable to resist, Yuu extended his left hand toward them.

"Hyaan! *Mooo*, Yuuu~"  
"My my, Kanna-neé, you've made your pussy completely drenched"  
"Well, yeah... *amueru*, *rero*, I've been horny this whole time... Aahn! Don't play with it like that"  
"Then, shall I insert it soon?"  
"Really?"

"Kanna-neé's blowjob feels great too... but I want to ejaculate inside you"  
"Ufu. Then... I'll ride you"

As for Moeka, she sat with her buttocks flat against the bed, supporting Yuu's back. She worried about putting weight on him, but Moeka smiled and said it was fine. This was actually a scene from a popular adult comic where two sisters have sex with their brother - the sandwich position with one in front and one behind. Saya and Sae had happily mentioned it. Essentially the reverse of two men sandwiching a woman front and back.

Incidentally, in the comic, the story progressed to anal development of the brother, even showing the rear-positioned sister inserting with a strapon. Fortunately for Yuu, no one suggested recreating that far.

"Ha... *kuuuu*... wait, it's big, it won't go in"  
"It's okay. Kanna-neé, no need to rush"  
"Uun..."

Perhaps due to her pride as an experienced sister, Kanna tried inserting it herself. At first it seemed smooth, but it stopped midway. Apparently, the thickness and length were vastly different from her past partners. Though Kanna spread her legs wide in a forward-leaning position, Yuu could see the shaft hadn't fully entered.

"Come to think of it, I struggled at first too. Yuu's cock is too big"  
"Uun. Sorry about that"  
"It's fine! It didn't hurt at all, and when the whole cock went in, it felt amazing... I truly think having Yuu as my first was wonderful"  
"Moe-neé..."

While Kanna struggled with insertion, Moeka - now a human chair - hugged Yuu tightly with apparent affection. First experiences leave lasting memories. That's probably why men obsess over virgins, wanting to be a woman's first. That night at Hesperis, Moeka was just one of 44 for Yuu. Still, he was happy she respected him as her first man.

"Ah... guh, *kuu*! O'h! This is, my first time, d-deep inside... ah, ah, inside me... being pushed up by... the cock! U'n! Amazingyyyy..."

Having finally inserted it fully, Kanna made an overwhelmed expression before collapsing face-first onto Yuu's chest. Yuu stroked her head as if consoling her.

"Ahh, Kanna-neé's vagina is hot and gooey, squeezing me, feels great"  
"Ehehe. Yuu. I'll try harder to make it feel even better. So, cum lots inside your big sister!"  
"Nn!"

Kanna smiled broadly, kissed Yuu, and slowly began rocking her hips.

"Ha, ha, ha... Ahh! Th-this is! W-wait... ahn! Cumming cumming! A'aaahhhhhhhhhhh! Amazing! Cummmiiiiiiiiing... afuuuuuuun..."

Kanna's breasts bounced like softballs with each rhythmic hip swing. Her moans and hip movements gradually intensified until she seemed to reach climax at the peak. After orgasming while looking at the ceiling, Kanna collapsed onto Yuu's chest.

"Okay. Guess I'll move soon"  
"Eh? Wait... Yuu? A'u!"

Kanna's movements as an experienced woman seemed decent enough. It might be presumptuous, but not bad. However, having already ejaculated once, Yuu wouldn't cum immediately, so Kanna came first. Now Yuu wanted to move and make Kanna feel him inside her vagina.

Yuu supported Kanna's buttocks with both hands, maintaining their connection while sitting up. They shifted to a facing position. The deep penetration made Kanna cry out and cling to Yuu. Yuu had Moeka keep hugging him from behind. Pressed front and back by breasts, he felt softness and the heat of female bodies. Especially around his groin, sweat and love juices mingled slickly.

When Yuu began thrusting, it made sticky *nuchu*, *nuchu* wet sounds. Yuu thrust hard from the start.

"A'h, a'u... Yuu wait... aun! So rough! I just came... no, cumming again! Hyaun! I-I don't know this feeeeeeling!"  
"Kanna-neé, then... let's cum together... yo! I'm feeling so good... I'm about to cum too"

Moeka pressed her face against Yuu's sweaty, pulsating back with a blissful expression. Kanna, feeling continuous orgasms, clung to Yuu while rubbing her cheek against his. With each thrust, *tan*, *tan*, *tan* flesh-slapping sounds echoed. Unconsciously, Kanna's arms hugging Yuu tightened powerfully while her vagina clenched *kyuu*. As if her body craved Yuu's semen and tried to milk it out. This made Yuu's thrusts come faster until finally he thrust deep, gouging her cervix. Yuu and Kanna climbed toward the peak together.

"Ka, Kanna, hey... ahh! Cumming, ejaculating!"  
"Hyai! Me too... cumming cumming cumming! Amazing, cummmiiing... f-fill me, Yuuuuu... a'h! Haeeeeee... se-semen... so much... inside... ah, hii..."

As Yuu reached his limit, *dokun*, *dokun*, semen equal to his first ejaculation poured into Kanna's womb. Accepting the ejaculation while climaxing made Kanna's vision turn white, nearly losing consciousness.  


### Chapter Translation Notes
- Translated "萌花" as "Moeka" per Fixed Reference character list (Mitane Moeka)
- Translated "カンナ" as "Kanna" per Fixed Reference (Toyoda Kanna)
- Preserved Japanese honorifics: "-neé" for "姉" (elder sister address)
- Translated explicit anatomical terms directly: "膣内" → "vagina", "チンポ" → "penis", etc.
- Transliterated sound effects: "ぱくついた" → "took it into her mouth", "ぬちゅ" → "*nuchu*"
- Maintained Japanese name order: "Toyoda Kanna" not "Kanna Toyoda"
- Rendered sexual acts without euphemisms: "射精" → "ejaculation", "挿入" → "insertion"
- Italicized internal sensations: "きゅんと疼く" → "*kyun* throb"
- New paragraphs for each dialogue line without attribution