## 310. New Year's Party ⑦ ~Double Game~

It was understandable that Kanna was in a daze for a while after climaxing at the same time as Yuu's ejaculation.

But Kanna was pulled away from Yuu by Moeka, who was waiting her turn.

Though smiling wryly at the forceful action, Kanna—satisfied from being creampied thoroughly—silently moved away from the two.

  

"Good job, Yuu. I'd like to let you rest here for a bit, but... sorry. Big sis can't hold back anymore. You don't need to move. Leave everything to big sis. Ahhn, your cock's hitting me. It's still so haaard... Ahhaan"  
"M-Mo...nee...nngh!"

  

Moeka covered Yuu's body as he was pushed onto his back, pressing tightly against him.

Perhaps continuing from when she'd pushed him down earlier. Her hands gripped Yuu's shoulders while her ample breasts crushed against his chest. Truly a female flesh blanket. Her plump body made the softness and weight feel pleasant.

Furthermore, Moeka rubbed her lower abdomen against him with her legs spread wide. Her expression could only be described as that of a female in heat.

Even while Yuu had been connected to Kanna in cowgirl position moments earlier, Moeka had kissed his back repeatedly.

With saliva glistening at the corner of her mouth, Moeka sealed Yuu's lips while moving her hips in small, grinding motions. Though not inserted yet, it seemed like she was doing warm-up exercises.

  

While deep-kissing Moeka, Yuu recalled:

When they first met, Moeka had been a virgin with no prior lovers, seeming rather reserved.

But perhaps through her experiences with Yuu, her hidden lust had awakened?

If so, he wanted to accept everything she offered here.

Though he thought his cock might calm down after two consecutive ejaculations, there was no way it would subside while receiving stimulation from her steamy pussy.

Moeka's wriggling tongue inside his mouth and the softness of her breasts pressed against his chest only fueled Yuu's desire further.

  

"Mmmph mmjurlp, churlp, puhhaa... Nnfu. Yuu's mouth tastes good.  
Haaan... I want to insert it soon. But I want to feel Yuu's body more."  
"Mo...nee... you can... do whatever... kuhah... you want. I'll... properly ejaculate inside you at the end."  
"Anh! Yuu, what a good boy! Love you love you! Chuupaa"  
"Nmph!"

  

Overjoyed at Yuu's words, Moeka kissed him again with saliva threads still hanging.

His cock, stimulated by dry humping, was now fully erect again.

Each time it rubbed against her soaking wet pussy, it made squelching sounds.

They remained connected both above and below for a while, but when the glans hit her clitoris, Moeka nearly came.

Ultimately, following her desire to feel his cock inside her vagina when climaxing, she pulled back and swallowed Yuu's cock into her vaginal opening.

  

  

  

  

"Pyauu! Aah! Aah! No... I'm... cummiing, kuuuuuuuuuu... n... hahii"

  

After climaxing, Moeka trembled violently before collapsing.

Including right after insertion, this was her third orgasm.

Though her vaginal tightness felt like that of a virgin, Yuu had some leeway since he'd ejaculated twice already.

  

"Mo-nee, I'll change positions a bit, okay?"  
"Nngh?"

  

Moeka's response was sluggish as she buried her face in Yuu's neck, breathing heavily.

Smiling, Yuu firmly embraced Moeka's back and waist while slowly rolling to the right.

As he lifted his upper body midway and withdrew his right hand, he saw her heavy-looking breasts sway sideways when they turned. He placed his hand on Moeka's shoulder while his left hand firmly held her thigh. Of course, he kept his hips pressed to prevent his cock from slipping out. He moved slightly in that position.

  

"Hya, something's... hitting me..."

  

This was similar to the spooning position, which allows deep penetration for some, but Yuu found the angle somewhat awkward for movement.

So he only used it briefly when transitioning between missionary and cowgirl positions or vice versa.

While moving his hips in small motions, Yuu spread Moeka's legs and turned her from sideways to supine.

Keeping them connected, he slid both hands along Moeka's plump thighs to behind her knees, then lifted them.

  

"Yu, Yuu!?"  
"I'll ejaculate inside your pussy in this position, Mo-nee."  
"Haaah, aahn! It's deep, going all the way in... Do it. I want you to impregnate me!"

  

It became a breeding press position like with Lucy earlier.

As Yuu leaned in forcefully, his cock seemed to push up against her cervix, plunging deep inside. Looking down, Yuu saw her hill-like breasts jiggling wildly.

Stimulated directly on her womb and intoxicated with passion, Moeka stretched out both arms and clung to Yuu.

Needless to say, Moeka began crying out in ecstasy as soon as Yuu started moving.

  

  

  

  

After pouring his third load of the day into Moeka's vagina, Yuu pulled out his cock and lay on his back.

Though Saya and Sae were still waiting, he wanted to rest a bit.

  

"Yuu, good work~"  
"You did great, Yuu"

  

Lucy and Kanna brought drinks and damp towels from the kitchen, but after exchanging glances, they stopped and handed them to Saya and Sae.

Understanding the intention, the two happily accepted and approached Yuu as he sat up.

Of course, both were already naked, with their long hair tied at the neck and draped over their shoulders.

  

"Here, drink"  
"Thank you, Saya-nee"

  

Clear liquid was poured from a pitcher into an ice-filled glass on the tray, which Saya handed to Yuu.

The chilled mineral water tasted incredibly refreshing as it permeated his body.

Except for Moeka lying on the bed with legs spread wide, the four women watched Yuu gulp it down with affectionate gazes.

  

When Yuu returned the empty glass, they approached with towels.

  

"Yuu, you're sweaty, right? Let me wipe you."  
"I-I can do it myself!"  
"No, let me!"

  

There were two towels—Saya on Yuu's right and Sae on his left.

They probably wanted to fuss over him regardless.

Yuu smiled wryly but ultimately let his two half-sisters handle it.

  

"Haa... Yuu, you have such a nice body."  
"Your skin's so smooth too. As expected of a teenager. I'm jealous."  
"Ahh! That tickles!"  
"Come on! Raise your arms!"  
"Ba, banzai!"

  

Since they had a brother Sakuma, they'd surely seen male nudity plenty.

But unlike Sakuma's broad-shouldered, sturdy build, Yuu was comparatively slender.

Yuu's 16-year-old body seemed like a coveted prize for the two mid-20s women—they observed him closely while wiping, almost licking him with their eyes.

Yuu's entire face. Around his neck. Shoulders to chest, back. They made him raise his arms and didn't forget his armpits.

Then they moved to his lower body.

Making Yuu kneel, they meticulously wiped his sweaty lower abdomen, buttocks, and thighs with towels.

  

For the final touch, they wiped from his testicles to glans while pressing tightly against him from both sides.

By then, his cock had revived after briefly calming down.

Seeing it regain hardness in their hands through the towel, Saya and Sae showed expressions of surprise and delight.

Despite having ejaculated three times already, Yuu's masculine symbol stood vigorously erect.

They'd heard about it beforehand, but seeing it firsthand seemed to move them.

Saya and Sae smiled broadly while whispering in Yuu's ears.

  

"Hey, Yuu. We have a request."  
"Can we do it together?"  
"O-of course. I'd love to be with both of you, Saya-nee, Sae-nee."  
"Ufuu. Thank you!"  
"Yuu, you're truly a good boy."  
"Auh!"

  

Saya and Sae hugged Yuu from both sides and began licking his ears while whispering.

Each hand caressed Yuu's chest and back, and their legs entwined with his.

They seemed intent on pleasuring Yuu's entire body simultaneously.

  

"Come on, Yuu, let's kiss. Open up."  
"Mm, aaah mmph"

  

Sae turned Yuu's face toward her and immediately pressed her lips to his, tangling their tongues.

Meanwhile, Saya kissed Yuu's neck repeatedly, her tongue crawling along it. Though she'd seemed cool initially, her eyes now looked like those of a predator eyeing prey.

Minutes later, Yuu turned the other way and deep-kissed Saya. Her tongue moved as if violating his mouth.

Meanwhile, Sae pleasured Yuu's neck and shoulder bones with loud sucking sounds.

This repeated several times.

Naturally, Saya and Sae's hands weren't idle either.

Especially since both played with Yuu's nipples simultaneously, making even Yuu let out girlish moans.

  

Of course, Yuu wasn't inactive either. Having grown accustomed to being pleasured by multiple women, he folded his arms to touch their breasts.

His right hand on Saya's modest breasts, his left on Sae's overwhelmingly large ones—alternating between them. When he teased their nipples with his fingertips, both Saya and Sae let out sensual sighs.

Saya and Sae seemed experienced in pleasuring a man together.

Their coordinated movements—switching places while watching Yuu's reactions—were so skillful that Yuu couldn't focus on his own hand movements.

  

"Chu, chu, chupaa... How is it? Yuu, feeling good?"  
"Ah, ah, i-it feels good!"  
"Kufu. We can tell by your face. And look—your cock's been drooling like this since earlier. Yuu's such a perverted boy."  
"Ufuun... I'm glad Yuu's feeling so much. Hyah!? Yu, Yuu...?"  
"Nngh!"

  

Yuu wasn't just being tossed about by their dual caresses.

When Saya and Sae bent down to lick and suck his nipples, Yuu's hands reached for their lower abdomens.

Passing through their drenched pubic hair, he found their clitorises and began rubbing them with his fingers.

  

Seeing Yuu moan from their caresses yet still go this far, Saya and Sae exchanged glances while extending their tongues to lick his nipples. Their gaze directed downward.

Hands moved behind his back and slid down to massage Yuu's buttocks through the sheets.

Not just that—Saya's right hand reached for his testicles, while Sae tried loosening his anus with her saliva-moistened right finger.

Their other hands gradually moved from his stomach toward his crotch.

  

"Kuaaaah! Th-there... no!"  
""Aahhn!""

  

The moment Saya and Sae's hands simultaneously touched his cock, feeling its heat and hardness, Yuu's finger movements sped up.

Struck in his anal weak point, Yuu nearly arched his back.

Their hands overlapped to grip the shaft, making sticky, squelching sounds with each slow up-down motion. Though they'd just cleaned him, precum dripped because he remained erect.

  

Determined to make them feel more with fingering, Yuu defiantly stroked both their clitorises with two fingers. Immediately, loud splashing sounds came from both sides.

Saya and Sae trembled violently from the waist down at Yuu's skillful fingering, nearly pulling back but unable to escape since they didn't want to stop pleasuring Yuu.

  

"Ahh, Yuu..."  
"Yuu!"  
"Saya, Sae, hey..."

  

Both Saya and Sae lifted their faces and brought their lips close to Yuu's.

After nearly continuous kissing, words spilled from them simultaneously.

  

"Shall we?"  
"Yeah."  
"Do it."

  

Still with their hands wet from juices, Yuu embraced Saya and Sae.

Logically, he should penetrate the elder sister Saya first, but he didn't want to leave Sae out now.

Then the two made a proposal after exchanging glances.

  

"We have a request, Yuu."  
"Since it's a rare opportunity."  
"Keep going with your cock."  
"Huh?"

  

Despite seeming experienced in pleasuring men, both were virgins.

They'd honed their sexual skills—starting with blowjobs—since their brother Sakuma entered middle school.

Though Sakuma's virility strengthened thanks to daily milking, they'd never had intercourse. Their mother said it was better to get semen from a man with different blood, even half-related.

Three years ago, they had a chance with another half-brother, but they got carried away while pampering him—making him ejaculate twice from blowjobs alone until he collapsed. Thus they remained virgins.

So today, they wanted to lose their virginity simultaneously before Yuu went soft.

  

Saya and Sae's concern was perfectly reasonable.

For ordinary men, even teenagers, twice per night is the limit.

Yuu himself, accustomed to multiple partners, could easily ejaculate five times per night.

  

"I'm honored to take such beautiful sisters' virginity. Okay. Let's do both at once."  
"Ah, thank you. Yuu's truly wonderful."  
"You're so young yet broad-minded, Yuu. I understand why other women obsess over you."

  

After hugging, Yuu, Saya, and Sae moved toward the center of the bed.

For simultaneous action, Yuu requested them:

Saya would lie on her back, with Sae straddling her facing Yuu.

  

Having touched them directly earlier, Yuu could clearly see their genital states now that their legs were spread wide.

Their pubic hair glistened with sweat and juices. The area around their labia minora to their inner thighs shone wetly. Of course, their spread vulvas showed beautiful salmon pink. Their small vaginal openings were virgin holes that had never accepted a penis.

They seemed to twitch, craving Yuu's cock.

Yuu stroked Sae's shapely buttocks with his right hand while placing his left near Saya's inner thigh, thrusting his hips forward.

With Sae sandwiched in the middle, Yuu leaned forward to adjust his cock angle. The tip touched Saya's vaginal opening.

Saya's entrance—about to accept male genitalia for the first time—overflowed with joyful juices as if drooling.

  

"Then I'll insert into Saya-nee first."  
"Ahh, Yuu... come... my pussy, yes, just like that... ghh, yes!"

"Guh! Still tight. Sorry, bear with it a bit longer like this..."

  

No matter how drenched, a virgin vagina accepting a cock feels incredibly tight.

Having broken her hymen beforehand was fortunate, but the physical tightness was undeniable. It felt like forcibly pushing through a crevice.

Sae hugged Saya worriedly as she grimaced in pain.

  

After entering halfway, he used small thrusts to gradually secure the passage. Though it took time, he finally thrust fully inside.

  

"Ahha... I did it. I did it. Haa, haa. Finally... I've lost my virginity! Amazing. Yuu's cock is deep inside me."  
"Big sis, so lucky. Hey, Yuu? Now it's my turn."  
"W-wait... just a little. Wait."

  

Having finally lost her virginity in her late twenties, Saya openly showed her emotion.

Seeing her elder sister like this, Sae couldn't suppress her own desire.

She turned just her face to plead with Yuu.

For Yuu, having fully inserted into Saya, he was struck by intense pleasure and couldn't move momentarily.

If he took Sae's virgin vagina consecutively, he might ejaculate from the momentum.

He also wanted to savor Saya's vaginal interior a bit longer.

Yuu covered Sae tightly against her back and began moving his hips slowly.

  

  

  

  

  

---

### Author's Afterword

A somewhat unusual situation where sisters who honed their techniques on their real brother but remained virgins into their mid-twenties get pampered.

### Chapter Translation Notes
- Translated "種付け" as "impregnate" to maintain explicit terminology per style rules
- Preserved Japanese honorifics (-nee) for sisters throughout
- Transliterated sound effects (e.g., "puru puru" for ぷるぷる)
- Used explicit anatomical terms ("clitoris," "vagina," "testicles") as required
- Maintained original name order (Hirose Yuu) and character names from Fixed Reference
- Translated sexual positions literally ("breeding press" for 種付けプレス)
- Kept internal monologues italicized per formatting rules