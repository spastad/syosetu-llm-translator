## 311. New Year's Party ⑧ ~Melty Love~

"Ngaaaaah! M-my inside, your penis, it's coming in... Oh! Oh! Ahi, wait... Ungh! The depths, it's filling me up...!"

"Sae-neé's pussy, I'm all the way in. Hahh... What an amazing sister's virgin pussy this is..."

Having inserted fully into the depths of her vagina, Yuu supported his body with both hands on the sheets while covering Sae's back. If he put his entire weight on her, the full weight of two people would press down on Saya at the bottom.

Sae's back felt moist, perhaps because she was sweating, and that felt oddly comfortable.

Because Sae had writhed during insertion and shaken her head, her tied-up brown hair had come loose and spread out, with several strands falling on her nape and back. That sight was strangely erotic.

Although Yuu had already ejaculated three times today and should have had some leeway, a virgin pussy was exceptional after all. If he let his guard down even a little, he felt like he might be milked dry.

That's why he had paused temporarily after inserting fully to the depths.

Even though they were sisters, the sensations they gave were subtly different due to their differing physiques.

Saya, being slender, was physically tight and deep, making it intense.

Sae was somewhat softer and easier to insert into, but the moment he entered, she squeezed him tightly.

In a strange analogy, Saya could be called hard-type, and Sae soft-type.

When he inserted into Saya and started moving after getting somewhat accustomed, the friction rapidly increased his urge to ejaculate. So he pulled out once and inserted into Sae, but this time, even without moving, he felt a pleasant sensation as if his penis, fitting perfectly inside her pussy, was being caressed.

"Hey, Yuu? Isn't it okay for you to put it in me now too?"

"Huh? But you just put it in me... Ah! It's moving... coming! Ah, ah, hya!? Oh, oh, it's so big! It's digging into the deep spot, ugh!"

"Sorry, Saya-neé. Please wait a little longer."

Only a few minutes had passed since Yuu first inserted into Saya's virgin pussy. He had pulled out just when things were getting enjoyable.

Saya and Sae had started arguing at extremely close range, almost kissing, but Yuu began moving his hips, forcibly interrupting them.

Covering Sae's back so closely that his chest touched her, Yuu began thrusting his hips.

At first in small movements. As he got accustomed, he increased the range of his thrusts.

Pan, pan, pan.

Yuu's lower abdomen struck Sae's elastic buttocks, making a satisfying sound.

"Ah! Ah! Ah!"

"Sae-neé, does it still hurt?"

"It doesn't... hurt... I'm fine... Yuu, more... harder, please?"

Since her hymen had already been broken beforehand, the pleasure seemed to be outweighing the pain of taking a penis for the first time.

Encouraged by Sae's words, Yuu increased his thrusting speed.

As the sound of flesh slapping became more rapid, Yuu's sensitivity also increased.

In terms of order, he wanted to ejaculate inside Saya's pussy.

Feeling like he had been thrusting for about five minutes, Yuu decided to pull out temporarily.

"Aahn. Don't pull out, nooo."

"Sorry."

The penis pulled out from Sae's pussy had a slightly cloudy fluid clinging to it, forming strings. It was as if their genitals were reluctant to part.

Yuu lowered his hips slightly and pressed his penis, still coated with Sae's love juice, against Saya's vaginal entrance.

"Yuu... Aah! I'm happy! Your penis... your penis! Aaah! Yuu's, your penis... is coming in... it's... in! Hyuguuuu!"

The Saya-Sae sisters had spent years honing their skills at making men ejaculate, but conversely, they weren't accustomed to being pleasured by men.

It was their first time seeing and experiencing sex where both man and woman could feel good together, rather than the man being passive.

While watching the sex until their turn came, their entire bodies had been craving Yuu.

Therefore, receiving Yuu's affectionate caresses, they were struck by pleasure incomparable to masturbation.

Saya, who had been cool and aloof when they first met, had now become a mere female in heat, spreading her legs wide to accept Yuu.

Her body rejoiced at the thick meat rod trying to enter her again, and she repeatedly called out for his penis.

Though her tightness hadn't changed, unlike the first time, when Yuu thrust all the way to the depths in one go, Saya threw her head back and let out a long moan.

"Aheeeeeee... Your penis... your penis is amazing! Ah! Aahn! Yuu's, Yuu's... Ahin! The depths... it's coming deep inside... your penis... feels so goooood... I can't, I can't take it... I can't think straight anymore... Ah! Shoko!"

"Hah, hah, hah, Saya-neé's pussy feels too good... I might not last long."

Yuu thrust his hips while supporting himself with both hands on the sheets in a push-up position.

He thrust deep into Saya's vagina, pulled back just enough, and then thrust deep again.

Not just monotonous straight thrusts, but he also stimulated Saya's G-spot with his upward-curving penis or dug into her by grinding against her womb.

However, he kept it slow. After all, whether thrusting or pulling, the friction sent a tingling, numbing pleasure from his waist to his back. If he thrust wildly with momentum, he felt he might ejaculate in no time.

He had intended to enjoy the sisters' virgin pussies alternately, but he no longer had that luxury.

Beneath Yuu, Saya and Sae were embracing each other.

Saya's black hair, which had been tied up, was now completely disheveled and spread over the pillow because she had shaken her head while moaning. Her glasses had also slipped off, so the considerate Sae had removed them and set them aside.

Without her glasses, Saya occasionally gazed passionately at Yuu over Saya's shoulder with her narrow eyes, but each time he thrust deep into her, she threw her head back and moaned.

Yuu wanted to make Saya climax simultaneously with her virginity loss if possible, but he was about to reach his limit before that.

"Guh... I can't hold back... I'm cumming, Saya-neé?"

"Nngh... no... what's this... Ah! Ahe... Yuu! Yuuuu!"

Seeing that Saya didn't seem to have the leeway to respond, Yuu decided to thrust his hips vigorously without hesitation to ejaculate.

Sae, sandwiched between them, smiled wryly at her sister's uncharacteristic disheveled state while being tightly embraced.

A few minutes later, Yuu poured his fourth ejaculation of the day into Saya's vagina while embracing Sae.

The moment his semen was released, Saya let out a long moan, so she might have climaxed.

At any rate, Saya seemed satisfied, so a relieved Yuu lost strength and collapsed onto Sae's back.

"Ufufu. Yuu, good work."

"Ah... S-Sae, hey..."

Yuu was laid on his back.

After ejaculating inside Saya, Sae, who had turned around, embraced him and pushed him down.

Sae clung to him closely as if snuggling, gazing at Yuu while giving him an arm pillow. Her other hand gently stroked Yuu's chest and stomach.

Naturally, his penis, having just ejaculated, was now docile.

Saya was lying down, basking in the afterglow of being creampied, but Lucy, Kanna, and Moeka tried to approach Yuu.

However, Sae was the only one who hadn't been creampied.

Because she wanted to monopolize Yuu a little longer, Sae sent them away.

"Hey, Yuu. Can I kiss you?"

"Why are you being reserved now, Sae-neé? Let's do it."

"Aha! I'm so happy. They say men usually cool down after ejaculating, right? The men I've had sex with before were like that too. Though there were only two."

Even in the world before his rebirth, most men were apparently like that. For men, ejaculation is the primary goal, so once achieved, they're satisfied. It's like entering sage mode.

Apart from paid services, when Yuu was married, he loved his wife so much that he didn't want to leave her side. Partly because his wife was passive and dry.

Men in this world tend to cool down more after ejaculation. The declining trend in libido might also be a factor.

Yuu's half-brothers, who had relatively strong libidos and didn't dislike interacting with women, were still somewhat better, but even they took breaks.

Someone as greedy for women as Yuu, who could have sex continuously, was rare.

Yuu didn't dislike Sae's closeness; instead, he extended his right hand to comb through Sae's disheveled brown hair. His left hand cupped her weighty breast as if supporting it and squeezed it jigglingly.

"Sae-neé's boobs are so soft and feel great to squeeze. Ah, there's a mole here."

"Ah! When you touch me, Yuu, it's not just pleasurable... it makes me feel so at ease... Haan... my heart and body feel all warm."

While combing her hair, Yuu found two moles side by side near the base of her neck and traced them with his finger.

Feeling pleasure from Yuu's touch, Sae slid her right hand, which had been stroking his stomach, up to his cheek and pressed her lips against his.

Earlier, when it was both sisters, they started with a passionate kiss, but this time it began softly.

However, Sae, unable to contain her excitement, gradually became bolder. She pressed her lips wetly against his, licked his lips with her tongue, then invaded his mouth. Simultaneously, her grapefruit-sized breasts touched Yuu's chest, and her nipples rubbed against him, becoming erect. Her right hand cradled Yuu's head affectionately.

"Mmchu, chupaa... Ah, Yuu! Yuu! Anmu... nmu, ero, lero, ju, npaa..."

When Sae pulled her lips away, a string of drool stretched from her red tongue and flowed into Yuu's open mouth.

This time, Yuu also extended his tongue, poking against Sae's before overlapping it up and down.

"Wawa! Yuu's penis, i-it's getting energetic again!?"

"Yeah. Being like this with Sae-neé got me excited."

"Yaan! Yuu, you're incredible!"

Sae had wrapped one leg around him and noticed the heat and hardness of the meat rod against her thigh.

Touching a girl's soft skin while engaging in a deep kiss.

For Yuu, this was the most stimulating act to his lust. Even after ejaculation, it remained unchanged.

Sae lowered her head to Yuu's chest and ran her tongue over his nipple. Her right hand reached for the revived penis.

Tentatively poking it with her fingertip, it twitched.

When she traced the glans with her fingertip, the penis drooled precum as if rejoicing.

Feeling the fluid clinging to her finger, Sae made a happy expression and began stroking the entire glans with several fingers, enveloping it. Simultaneously, she drooled onto Yuu's nipple and sucked on it, making a vulgar, wet sound.

"Hau! S-Sae-neé... it feels so good! Ahh!"

"Chu, chup... nfu"

Seeing Yuu moan like a girl, Sae grinned broadly and began stroking the shaft lightly with her right hand.

With each up-and-down motion, the overflowing precum made a sticky, wet sound.

It was now fully erect. Ready for insertion at any moment.

Sae thought about straddling him this time, but suddenly Yuu hugged her tightly and, in an instant, flipped her sideways while turning her over.

"Hah, hah, I can't hold back anymore. I'm putting it in, Sae-neé?"

"Eh? Eeh!? Wait, Yuu?"

Yuu hugged Sae from behind as she lay sideways, lifting one of her legs high to insert himself.

A variation of the sideways position, where both face the same direction, known as one of the forty-eight positions: "Window Moon."

Yuu himself had rarely used this position, but since it clearly showed the woman's entire body and the joining point, he remembered occasionally seeing it in adult media.

"Somewhere around here? Sae-neé, guide my penis in."

"Huh? Ah, in this position... Ah! Okay, I got it."

Yuu pulled his hips back slightly and pressed them firmly against her buttocks.

He knew the approximate position, but since he couldn't see from behind, he had Sae guide him to her vaginal entrance with her hand.

"Mr. Penis, big sister's pussy is over here. Come on, come in... Ah! Good... wow, it's so... energetic... thick and hard... ah, ah! It's going in... Ngi! Hyu... oh, the depths!"

As Yuu pressed his hips forward firmly while tightly pressed against Sae's back, his penis slid in more smoothly than before and struck the depths of her vagina.

Unlike normal doggy style, the sideways position made movement difficult.

So Yuu continued with slow thrusts.

That was just right for Sae, who had just lost her virginity today.

Yuu extended his right arm to give Sae an arm pillow. His left hand lifted her thigh, which had just the right amount of flesh.

Sae tightly gripped Yuu's hand and continued moaning.

---

### Author's Afterword

Finally, we've reached the fifth person.

The New Year's Party arc will end with the next chapter.

Reunion group and the older beauties met for the first time, ranging from late twenties to thirties who missed their chance to marry. While paying attention to each character's personality as I wrote their conquest, honestly, five might have been too many.

In retrospect, maybe three would have been better if writing one by one.

### Chapter Translation Notes
- Translated "おチンポ" as "penis" to maintain explicit terminology as per style rules
- Translated "マンコ" as "pussy" for explicit anatomical accuracy
- Preserved Japanese honorifics: "Saya-neé" and "Sae-neé" for "沙綾姉" and "紗英姉"
- Transliterated sound effects: "ぱん、ぱん、ぱん" as "pan, pan, pan"; "じゅぶぶぶ" as "jubububu"
- Translated sexual position "窓の月" as "Window Moon", a known term in English for this traditional position
- Maintained explicit descriptions of sexual acts without euphemisms
- Translated "中出し" as "creampie" (verb: creampied) for accuracy in describing internal ejaculation
- Used "G-spot" for "Gスポット" as standard terminology
- Translated "賢者モード" as "sage mode", common fan term for post-ejaculatory refractory period