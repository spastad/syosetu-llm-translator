## 313. Sex Education Video ① ~For the Sake of Love~

In this world, health and physical education for junior high and high school students, particularly the approach to male and female minds and bodies in health classes, has advanced considerably.

Special emphasis is placed on sex education.

This is likely influenced by the drastically reduced male population lowering the probability of pregnancy and childbirth through sexual intercourse.

No matter how much science advances, the probability of achieving pregnancy through artificial insemination hasn't dramatically increased, making natural conception preferable.

It was only natural that efforts in sex education intensified to ensure proper intercourse leading to pregnancy and childbirth during these precious opportunities.

  

Since it's clearly established that both sperm and eggs are better when young, becoming pregnant during student years isn't negative but positively evaluated.

However, the intensified focus on health and sex education began just a few years before Yuu's birth—coinciding with Sayaka's educational reforms. The nationwide co-ed school establishment boom started around the same time.

  

Yuu had once been surprised that female classmates were being taught in detail about male anatomy, physiological phenomena, and even sexual desires. Of course, this was within common sense in this world, though it hardly applied to Yuu.

  

Conversely, Yuu felt bewildered yet pleased to accept that in this world, women's competitive drive seemed to amplify both sexual desire and pregnancy aspirations.

Being liked, loved, and desired alone boosted his confidence. Though simple, in his previous world, many men's desire for popularity might have stemmed from their sense of masculine worth.

Conversely, average boys in this world lack such aspirations. Going out carelessly means being surrounded by women. If unlucky, gang-raped and milked to their limit.

In today's society, it's understandable men can't be proactive.

  

That aside. On January 2, Yuu was approached about starring in a sex education video.

Speaking of videos, Yuu recalled.

During a special health class for second-years in the Friendship Hall last October, a laserdisc played on the classroom's large display.

A real man had appeared in it. From what he heard while facing away, it seemed educational about physical differences between genders.

But when Yuu started undressing, the female students erupted, derailing everything.

*So, are they going to record me naked like in that class for health education?* Yuu thought, but Satsuki and the others had different plans.

  

"What we want from you, Yuu, is to have loving sex like you always do."

"Huh?"

"You sincerely face and love every woman, right?

Everyone says just watching that makes them aroused—I felt it too.

This isn't an educational video. Not commercial either. We simply want to film you loving a woman."

"Hmm... If it helps society... but is this okay?"

  

In this world's adult video scene (excluding animation), simulated sex with women playing male roles dominates. Professional male actors don't exist.

While men work in the sex industry, male-featuring AVs are rare. Young male performers are scarce—mostly middle-aged men.

Legally, minors can't appear in sexual videos, but underground markets circulate illicit videos—mostly foreign—of seemingly abducted boys being raped.

Yuu's video won't be for profit. His face will be mosaicked to prevent identification.

Exclusive lending to co-ed schools using the foundation's gender exchange program. For special health classes only. A unique educational resource.

Tentatively scheduled for Sairei Academy's second and third-years next academic year.

  

When Yuu asked about his female counterpart, arrangements were set:

A non-public educational video featuring a real high school boy—albeit amateur—in a romance.

Multiple talent agencies recruited unknown female talents (18-22) for the girlfriend role. Over 100 applicants immediately.

Document screening and auditions since last December narrowed it to 10.

Yuu would review photo profiles and rank preferences.

Top choices would be approached through agencies; upon agreement, filming would begin soon after meeting.

  

Yuu received 10 profiles with face and full-body photos.

Chosen as potential high school boy lovers, all looked young and cute regardless of age.

Needing to decide on the spot, Yuu was deeply conflicted.

  

  

  

  

January 5 afternoon. Sairei Academy High School.

Yuu's car entered through the west gate instead of the main student entrance, stopping near the administration building.

Though winter break, club activities had resumed since the 4th. Yet no students appeared in buildings, grounds, or gym.

Only the familiar security guard greeted Yuu as he disembarked with protection officers—no staff in sight.

  

After the entertainment weekly scoop, Yuu's nationwide fame rivaled top celebrities. Even accessing public facilities required caution.

Thus Sairei Academy—as Yuu's school—allowed natural comings/goings with manageable security.

Since the video would debut here, they negotiated campus filming access and secured cooperation.

Hence today's club activities ended by noon. Minimal staff remained during break; only security maintained normal operations.

  

Surrounded by four protection officers including Kanako and security, Yuu entered the administration building. Noticing the nurse's office door ajar down the hall, women emerged upon hearing footsteps.

Attending for the foundation: Yuu's half-sister Toyoda Satsuki and Fujiki Hiromi—both handling Yuu's affairs.

Both wore plain suits today, but their stocking-clad legs extending from tight skirts showcased stunning lines.

  

"Sa, Satsuki nee, Hiromi-san."

"Oh? Yuu, you're a bit nervous?"

"Eh... You can tell?"

"Well, of course."

  

Yuu's rebirth brought changes: speaking confidently before crowds; refined skills with women and sex.

But unchanged traits remained.

Like becoming nervous when filmed, exposing acting flaws.

Fine for school festivals, but acting for a video used in nationwide classrooms? Impossible not to tense up.

Even though it's sex, he feared stiff line-readings like a rookie AV actress.

  

"You'll be fine, Yuu. You'll succeed."  
"Just focus on your partner, not the camera. Be natural."

  

Perhaps nerves showed in voice and expression.

Satsuki drew close, embracing Yuu's shoulder while stroking his head; Hiromi hesitantly approached, holding his hand encouragingly.

Though mentally more mature, both were working adults years older. They saw him as a ward—especially Satsuki, treating him like a much-younger brother.

Touched, Yuu happily spread his arms and hugged them both.

  

"Um..."  
"Ah!"

  

A petite woman had been hidden behind them. Yuu noticed and exclaimed.

Health teacher Kendo Maho.

The sole faculty attendee, pre-arranged.

  

"Hee hee hee, Hirose kyu—ahem! Hirose-kun, t-today... how to say... I'm already shocked! Our, our boy is, is, is—"  
"Maho-sensei, calm down."

  

Seeing Maho more nervous than himself pre-filming, Yuu smiled.

For her, this was material for next year's special health classes—a revolutionary love-themed video starring her male student.

Suddenly attending overwhelmed her.

  

As Satsuki and Hiromi stepped back, Yuu approached Maho directly, hand on shoulder.

No white coat today: light gray pantsuit instead.

Nearly 30 but baby-faced and under 150cm, she looked like a college job-hunter in the unfamiliar suit.

Her bust remained prominent even through fabric.

Yuu recalled their first special health class: finishing by ejaculating between her soft breasts during paizuri.

  

"Y-yes. The one struggling should be Hirose-kun! D-do your best without overexerting!"  
"Yeah. Maho-sensei, I want you to watch me closely."  
"Hauu!"

  

Maho raised elbows in a "fight" pose—accidentally emphasizing her chest.

Yuu instinctively embraced her, savoring the soft mounds against his torso.

  

  

  

"Woooooh! The real Hirose-kun! Meeting him like this! Young! Handsome! Cute! Aah—gratitude and amazement! So glad I kept at this job!"  
"Ha, haha... Please take care of me today."

  

Exiting the administration building, Yuu's group bypassed reception via the north corridor into the Friendship Hall.

Descending immediately to the basement, they entered Room 1—the only open door—greeted by waiting staff.

A plump, dark-skinned mid-40s woman charged at Yuu instantly. ~10cm shorter than him, bulging eyes, large mouth, booming voice. Frizzy back-length hair—unforgettably southern.

This hyper-energetic director thrust her business card after shaking hands: "Zuken Junko" with furigana.

  

"Zu, Zuken...? Unusual surname."  
"Ah, our company CAN Planning's full of Okinawans (Uchinaa)—president Kyan included. Mainlanders (Naichaa) might find our surnames odd."

  

She gestured to three staff prepping equipment.

All wore T-shirts/jeans despite winter. Company-name backs, "Uchinaanchu" (Okinawan person) chest prints.

Staff glanced at Yuu and bowed—minimal makeup, simple vibe. One baseball-capped member kept head lowered shyly.

  

Their Okinawa-based CAN Planning wasn't major but grew steadily—nurturing local talent while producing promos and OVs.

Junko directed, taught at Okinawan academies, and handled Tokyo outreach. Small but elite team.

Yuu's first-choice actress was CAN Planning's Okinawan talent—OV experience with males and vetted for confidentiality.

A four-person crew sufficed where others needed more—their strength.

  

As Satsuki, Hiromi, and Maho entered, greeting Junko, Yuu scanned the room.

Bed surrounded by filming gear; non-director staff busy prepping.

  

"Um, today's partner—"  
"Aiya~ Forgot! Yukki, enough! Come here!"

  

"Yukki"—previously baseball-capped—rose from organizing tapes in a duffel bag.

She was Yuu's chosen actress—unexpectedly helping as staff.

  

"Meet our rising star. Co-stars, greet each other."  
"Wah..."  
"Yukki?"

"Ah! Y-yes. Yonamine Yuki... Nice to meet you... *Yabai*, so hot. Totally my type. Blood's boiling."

  

Junko nudged her. Yuki stared dazedly, forgetting introductions.

After hurriedly bowing ("peko"), she mumbled—inaudible to Yuu.

Cap-removed hair fell "fusa"—short, nape-length strands.

Fixing side-hair while avoiding eye contact, flushed.

  

"Hirose Yuu. Nice to meet you today."

  

Yuu bowed back; Yuki kept gaze down, expression stiff.

Profile-accurate: 159cm, B83-W56-H85. Slender with curves. Staff-matching T-shirt; denim shorts revealed toned legs.

Winter-tanned skin, petite face. Almond-shaped obsidian eyes.

19 but could pass for high schooler.

After studying her face, Yuu smiled.

  

"Good. Much cuter than your photo."  
"Eh?"

  

Yuki glanced at Yuu, then away.

Fidgeting, hands clasped, she squeezed out words.

"Th-thank you. I... I'm really happy... to meet you too, Hirose-kun..."

  

Though not famous, she'd acted before.

But Yuu's nationwide fame dwarfed hers—nerves showed.

  

"Director, may we talk?"  
"Ah, yes! Perfect timing."

  

They couldn't film immediately after meeting.

Leads needed rapport and coordination.

An hour allotted anyway—setups ongoing.

Permission granted, Yuu took frozen Yuki's hand to the adjacent room.

  

  

  

  

---

### Author's Afterword

Filming Yuu having sex AV-style.

An idea floated earlier.

But conversely—no matter how sex-loving—16-year-olds pose legal issues.

Most laws mirror reality.

Inspired by another work's live-streamed sex scene, I decided to implement it here—limited release with face-masking.

  

Work involves frequent Okinawan email exchanges (never met). Their surnames fascinate—Kyan, Zuken, Yonamine this time. Many "gusuku" (castle) names: Kinjo, Tamagusuku, Miyagi, Gushikami. Famous ones: Arakaki, Uehara, Shimabukuro.

With exploding character counts complicating naming, I opted for Okinawan cast. Unnamed staff also bear distinctive local surnames.

### Chapter Translation Notes
- Translated "性教育ビデオ" as "Sex Education Video" maintaining educational context
- Preserved honorifics: "沙月姉" → "Satsuki nee", "宏美さん" → "Hiromi-san", "真保先生" → "Maho-sensei"
- Transliterated sound effects: "ひひひ" → "hee hee hee", "ぺこり" → "peko", "ふぁさり" → "fusa"
- Used explicit sexual terminology: "sex", "ejaculating", "cock", "paizuri" per style rules
- Rendered internal thoughts in italics: *So, are they going to record me naked...*
- Maintained Japanese name order: "Toyoda Satsuki", "Fujiki Hiromi", etc.
- Translated cultural terms: "うちなーんちゅ" → "Uchinaanchu (Okinawan person)" with contextual explanation
- Translated Okinawan dialect "わしとーたん" as "forgot" with original note
- Translated "やばい" as "*Yabai*" conveying "hot/irresistible" nuance
- Preserved "OV" (Original Video) as established term
- Applied dialogue formatting: New paragraph per speaker unless attribution precedes