## 314. Sex Education Video ② ~Premonition of Love~

About a quarter century ago, the girl who sat next to Yuu when he actually entered high school in his previous life was named Honjou Yuki (本条 優希).

I later heard she had been in the track and field club (long-distance specialist) during middle school and joined the same club in high school. She was a petite, slender girl with short hair that suited her boyish style well.

At first, she rarely changed expressions, giving me an aloof impression. But right after entering high school, there were many administrative topics to talk about.

Though Yuu wasn't particularly good at getting along with girls, fortunately the boy and girl in front of us were bright and friendly types, so naturally the four of us talked more often. Thanks to that, Yuu became able to talk with Yuki as neighbors.

Yuki seemed to be the shy type like Yuu, but once she opened up, she became an ordinary girl who laughed and talked a lot.

Yuki excelled at long-distance running, even participating in city marathon events. Perhaps because she trained year-round, her skin was tanned even in April. Her unassuming nature without strong femininity left a good impression on Yuu.

She wasn't a stunning beauty that stood out in class. But her facial features were well-balanced overall, and her double-lidded eyes appeared large depending on her expression. He noticed she had dimples when she smiled.

In hindsight, she might have been a diamond in the rough.

Though Yuki seemed completely outdoorsy, she was also knowledgeable about shonen manga due to her younger brother's influence, which fortunately allowed Yuu to talk about hobbies during breaks.

It was purely a school relationship, but for Yuu at the time, becoming close with a girl so soon after entering high school made him genuinely happy.

However, after summer break. When the second semester started, there was seat reassignment, and Yuki was moved far away.

Strangely, while he could easily talk to her when they were neighbors, once separated, it became harder to approach.

Yuki didn't have many opportunities to talk with boys and was often seen talking with female friends from the same athletic club.

For Yuu at the time, approaching a group of girls to start a conversation felt like a high hurdle.

Eventually, time passed without restoring their previous closeness, and they were in different classes in years 2 and 3.

Then, in winter of year 3. When he heard that a boy from their first-year class whom Yuu wasn't particularly close with had started dating Yuki, he felt a slight pang in his chest.

It might not have been love, but perhaps he'd held faint feelings for her. If Yuu had been a bit braver and more tactful, his friendship with Yuki might have continued, and he might have genuinely fallen for her.

Yuu, who had been given profiles of 10 potential co-stars, quickly scanned them in order.

When Satsuki and Hiromi led the selection process, they apparently used "looking young enough to play a high school girl" as one criterion. Over half wore school uniforms deliberately. Others wore youthful fashions typical of high school girls, with either no makeup or natural makeup so subtle it was hard to tell from photos.

The 10 finalists were 18-20 years old. All looked plausible as high school students. Though not widely known by name and face, they each had at least one year of experience across film, TV, stage, and even slightly adult video works.

Types varied from refined young lady styles to seemingly spoiled little devil types to soft, fluffy airheads, but they all shared being cute girls. Even if told to choose just one to have sex with, it would be hard to decide. Actually, given Yuu's current state, he'd want to ask each one in order.

When Yuu saw the last profile, the name Yonamine Yuki (與那嶺 由貴) and her photo showing a gentle smile facing forward caught his eye.

Simultaneously, memories of Yuki that he hadn't recalled for about 20 years and whose face should have become vague suddenly revived.

He knew it wasn't Yuki. The facial impression from the photo was somewhat similar, and the name pronunciation was the same. But her hometown and age were different.

Fundamentally, though reborn, this wasn't his past self but a different person who only shared the name. Since it's a different world, except for special cases like Kate, he hadn't encountered anyone he knew.

Still, Yuki's photo strangely made him feel that if Honjou Yuki had lived another year or two, she might have looked like this, and he couldn't look away. It might be middle-aged nostalgia. Objectively speaking, other candidates were cuter. But in Yuu's heart, only Yuki occupied his thoughts.

According to the profile, Yuki—her real name used the same pronunciation Yuki but with different kanji—had aspired to be an actress since first year of middle school and applied to CAN Planning's audition.

After passing, she attended a training institute in Okinawa while taking jobs like extra roles on local TV stations. Upon graduating middle school, she moved to Tokyo, attending a metropolitan high school while starting entertainment activities.

However, for the first two years, she only got minor jobs like extra roles. She started getting credited roles, though still among many others, only in the past year and a half.

Her 1990 appearances included 7 CM, drama, and OV (original video film) roles, all titles unknown to Yuu.

On set in Room 1, preparations were still taking time, so Yuu and Yuki entered Room 2 alone.

What they held was a printout with simple settings—too modest to be called today's script. Through prior discussions with CAN Planning, they'd decided what kind of roles to play, incorporating Yuu's input.

The story: A boy and girl attending the same co-ed school begin noticing each other during the first event in their second year. Through several school events and after-school interactions, they develop romantic feelings. Then at a Christmas party, the girl confesses and the boy accepts.

They would play lovers who, one month into dating, have their first experience and become obsessed with each other.

Typically in adult videos or sex education materials, the woman leads. Yuki apparently had some experience, but Yuu was overwhelmingly more experienced. Conversely, regarding acting, Yuki was the professional while Yuu was an amateur. This imbalance was problematic.

So the plan was for Yuki to lead through acting initially, then for Yuu to take over once they moved to sexual acts.

Even as Yuu sat on the edge of the double bed in the room, Yuki remained standing near the entrance.

"Alone together in a locked room... are you inviting me? Surely not for rehearsal here?"

"Ah, um, come sit over here."

"Huh?"

While finding Yuki's behavior puzzling since greeting—avoiding eye contact while muttering to herself—Yuu called out to her. Yuki, looking startled, stared intently at Yuu sitting at the foot of the bed before circling around to the headboard and perching lightly.

"Too far?"

"If I get any closer, I might not be able to control myself."

"Huh?"

It probably wasn't that she disliked Yuu. Seen diagonally from behind, Yuki appeared to be fidgeting while watching Yuu. She must be nervous being alone with him too. But since they'd be playing lovers, Yuu wanted to break the ice here.

Yuu stood up and moved to the opposite pillow side—circling around to the other side of the bed across from Yuki—and sat facing sideways. The distance to Yuki became just over 1 meter.

"You're nervous too, right?"

"...Hii!?"

"Since we'll be co-starring, let's talk about various things. At least at this distance. Hey, look this way, show me your face."

"Ah... haaah~~~"

Yuki remained oddly behaved, but Yuu paid no mind, removing his indoor shoes and putting his feet on the bed as he turned toward Yuki. Perhaps sensing Yuu's gaze, Yuki shifted slightly. Sitting straight while tightly clutching her T-shirt hem emphasized her chest.

Because she'd been muttering and shaking her head after Yuu approached, slightly disheveled hair hung over her cheeks as she looked over, naturally giving a sidelong glance. Combined with her half-open mouth, she exuded coquettish allure.

Drawn in, Yuu fully sat on the bed and closed the distance slightly. Today wasn't just about having sex. With filming starting soon, he felt this wouldn't do and genuinely wanted to know and understand her. By now, Yuu distinguished that Yuki was different from the Yuki in his memories.

He found Yuki herself appealing and felt his choice wasn't wrong. Staring at each other like this made his heart pound excitedly. Yuki seemed the same, gazing at Yuu with heated eyes.

"R-right. The role names are blank, so let's decide together and call each other by those names."

Trying to shift the mood, Yuu spoke while holding the printout. Yuki should have the same printout but had crumpled it from gripping too tightly.

"I think keeping the girl's name as 'Yuki' is fine... is that okay?"

"Eh, um... yeah."

"Great. Hey, Yuki?"

"Ahh!"

When Yuu called her name with a smile, Yuki covered her chest with her hand and looked down. Unnoticed, her cheeks had reddened. Truthfully, Yuki had no experience dating men.

After moving to Tokyo, to gain social experience through the president's generosity, she'd visited a brothel to buy a man. She'd also observed AV filming through agency connections.

The director had recommended her for this project brought to CAN Planning. She applied expecting rejection but was genuinely happy to make the final selection. However, she never imagined being chosen as the lover role and was shocked when hearing specific details.

Before this shoot, she'd frantically studied erotic novels, manga, and videos to cram sexual knowledge. Thanks to that, her masturbation sessions had been productive.

Then came meeting Yuu, her co-star today. Yuki had read the weekly magazine featuring Yuu at her agency, poring over it until it was worn out. She never imagined meeting Yuu himself here today. No wonder she acted strangely at first sight.

Meeting Yuu in person stimulated her earthly desires beyond imagination—alone on a bed in a locked room. She desperately restrained herself from losing control.

Then being called by name directly made waves of joy surge in her chest.

"What about the boy's name?"

"………"

"Yuki?"

"Huh? Ah... s-sorry! Um, um, the, the boy's name..."

Unaware of Yuki's inner conflict, Yuu smiled and moved closer. At a distance where he could reach out and touch, they gazed at each other. Yuki's eyelids opened wide, her obsidian pupils darting about. After opening and closing her mouth, she sealed it and swallowed hard. She licked her lips, which seemed coated with pale lip balm, then opened them.

"Hi... since it's Hirose-kun... hi-hi-hi... Hiroto."

Regardless of Yuki's reasoning, using his real name wouldn't do. Yet no unrelated names came to mind, so she apparently associated it with his surname.

"Nice. Then I'm Hiroto."  
"U...n."  
"Yuki."  
"......hi, Hiroto."  
"Fufu. You're cute, Yuki."

Intending light skin contact, Yuu reached out his right hand. The moment it touched Yuki's shoulder, her delicate body jolted.

"Ahh... no more, I can't... hold back!"  
"Huh?"

With moistened eyes, Yuki lifted her hips—then suddenly lunged at Yuu, pushing him down. Since it was a double bed, Yuu's head barely hit the edge. With strength belying her slender frame, Yuki pinned him down, pressing her chest flush against his. Then she peered closely at Yuu's face.

Her large, dark eyes were thoroughly clouded with lust. Haah, haah—her rough breaths hit Yuu's cheek. Unconcerned about their noses touching, she pressed her lips against his. As if refusing to let him escape, her right arm wrapped around Yuu's head, pressing her lips against his repeatedly with near-violent force—bchu, bchu.

Just when he thought she'd insert her tongue, Yuki's mouth moved to his neck. Pressing her wet lips against it, she began vigorously licking and sucking.

"Fu-, fu-! A boy's skin scent! Muchu, churu, reroreo jupaa... mufuu... o-ohii!"

Though startled, Yuu quickly understood. Despite nearby protection officers and others, he'd been too unguarded with a stranger. Approaching her on the bed, it was natural she'd think he was inviting her. Far from disliking being pinned by a girl like Yuki, Yuu welcomed it.

So he gently stroked the head of Yuki, who was frantically licking from his neck to collar in a frenzy. Yuki's left hand had been wrapped around his shoulder to pin him, but as Yuu didn't resist, it gradually moved to his armpit and chest.

Whereas men would grope soft breasts when pinning women, she seemed to enjoy the hard texture instead.

Before long, Yuki's left hand slipped under his shirt hem, directly groping his stomach and sides, making Yuu feel ticklish. Yuki sucked and licked upward from his collar to nape, then chin and cheeks—chu, chu—raining kisses.

When she lifted her face slightly to kiss again, their eyes met. Perhaps reason returned to her desire-clouded mind. Her expression instantly changed, face contorting.

"Ah... aaaahhhmmu!?"

As Yuki cried out and tried to pull away, Yuu immediately covered her mouth with his right hand—afraid loud noises would bring people in. Simultaneously, his left hand wrapped around her back to prevent escape. Keeping their bodies pressed together, he rolled them sideways.

"Shh! Quiet."

Mouth still covered, Yuki looked panicked but nodded emphatically at Yuu's words. The moment Yuu removed his hand, he sealed it with his lips instead.

While kissing, his right arm became a pillow, his left hand moving from her back to waist to embrace her.

"Um, um."  
"It's rehearsal."  
"Hyam!"

Not letting Yuki speak, he conveyed just one phrase before resuming the kiss. If he'd made Yuki horny and driven her to lust, he had to take responsibility. At least if she came once, she might calm down—perhaps a typically male way of thinking.

From sideways, he rolled again until he was on top. Until then, it had been gentle lip contact, but now it changed. Namely, he forced his tongue into Yuki's mouth.

"Vmo!?" Yuki's voice leaked out, but Yuu ignored it, moving his tongue vigorously. His left hand lifted her T-shirt hem and groped her breast. From the cup gap, he pinched her nipple with his fingers, forcibly making it erect. He flicked it with his fingertips.

Yuki's intermittent moans rose, but Yuu didn't release her lips.

Next, while spreading her legs with his foot, his left hand slid down to her lower abdomen. Perhaps due to her thin build, there was just enough space between her shorts and stomach for his hand to slip in. It invaded straight into her panties.

He immediately knew she was wet. Placing his middle finger against her slit's center, he made small movements, gently pulling back. With each repetition, kchuu kchuu wet sounds grew louder.

"Nmyuu! O'! Uaa... vun! V-! Nn, nn, u... unn!"

With muffled moans, Yuki's body jerked like a freshly caught fish. But Yuu firmly pulled her close with his right arm, lips still sealed, tongue wriggling. Yuki clung to Yuu's body with both hands, surrendering to the full-body pleasure.

---

### Author's Afterword

After writing Chapter 314, I felt somewhat dissatisfied and rewrote most of the latter half. This was because Yuki's character wasn't properly defined.

Yuki ended up pushing Yuu down on impulse, but from her perspective, being approached on a bed by such an attractive boy made enduring impossible. Though her impulsive act could have ruined the job, her inability to hold back stemmed from both her inexperience and Yuu's assertiveness.

Incidentally, Yuu's real-life classmate was initially named Hirosue Yuki (広末 有紀). I imagined two short-haired gravure-idol-turned-actresses still active today, but it felt too obvious so I changed it.

### Chapter Translation Notes
- Translated "本条 優希" as "Honjou Yuki" following Japanese name order convention
- Preserved Japanese honorific "-kun" in dialogue ("広瀬君")
- Transliterated sound effects (e.g., "bchu" for ぶちゅっ, "kchuu" for くちゅ)
- Translated "OV" as "original video film" based on Fixed Reference definition
- Rendered internal monologues in italics (e.g., *This is concerning.*)
- Maintained explicit terminology for sexual content per style guidelines