## 315. Sex Education Video ③ ~Kisses That Take Your Breath Away~

Without taking much time, he rubbed her clitoris with his fingertips until she climaxed once. Then inserting his middle finger into her vagina, he bent it at the second joint and stimulated her G-spot with a guriguri motion, making her climax again. She came so easily it was almost anticlimactic.

Yuki had not only soaked her panties but also dampened the crotch area of her shorts.

Now lying sideways, they were holding each other tightly. Having climaxed almost twice in a row, Yuki was breathing heavily but continued to kiss Yuu intermittently. She wasn't in a feverish state of lost rationality like before. Still, perhaps the flames of desire were smoldering inside Yuki? She would gaze at Yuu with a grin and seek his lips again. Yuu recalled that in such moments, women don't cool down no matter how many times they climax; instead, their passion continues unabated.

"Hey, Yuki?"

Seizing the moment when their lips parted, Yuu called out to her. Yuki's eyes were dazed as if heart marks were floating in them, her lips wet and glossy, slightly parted, but she didn't respond.

"Yuki, Yuuki!"  
"Hyan!"

Tickling her side finally got a reaction.

"That tickles... Hirose-kun."  
"You're supposed to call me by my role name, right?"  
"Ah... sorry, that's right. It's Hiroto, wasn't it? When Hiroto touches me, it feels so good. Way better than doing it myself, like ten times better. And kissing Hiroto... it was amazing. It made my head feel like it was melting."  
"O-overstatement, isn't it?"  
"It's not an overstatement! Hiroto, even though you're young, you're experienced, right? Your fingers and tongue... I was surprised how they could be gentle and delicate one moment, then bold the next, skillfully touching my weak spots. So it felt so good, like I was ascending to heaven. That... it was totally different from my first time at a brothel. Ufufu. I'm so looking forward to the real thing now..."

Yuu was inwardly surprised at how talkative Yuki had become, a complete change from when they first met. It must have been the effect of kissing, hugging, and pressing their bodies together. At least he felt relieved that his actions hadn't been mistaken. He smiled.

"I'm glad you're satisfied. So, Yuki."  
"What is it, Hiroto?"

With a seductive smile and an upward glance, Yuki looked so cute that Yuu hugged her tightly. Stroking her silky hair, Yuu whispered.

"Let's talk about ourselves for a bit.  
I'll start."

Though it sounded a bit like pillow talk, to understand each other better, Yuu began talking about himself—things like being student council president in high school, within acceptable limits. However, Yuki had apparently read the weekly magazine article about Yuu at the agency and remembered almost all of it.

Next, he asked Yuki to talk about herself beyond what was in her profile. Her life in her hometown of Okinawa, what kind of student life she had, what roles she had played in her work, things that happened on set, etc. Once it was about herself, Yuki's words flowed more smoothly. Yuu listened, nodding, showing surprise, and occasionally asking questions. All the while, Yuki's hands continued to touch Yuu's body. It was the body of a young, handsome boy that she rarely got to touch. Especially, she took every opportunity to touch his chest.

Of course, Yuu didn't refuse being touched. Rather, he touched her back. His right hand, which was under her head as a pillow, played with her hair, while his left hand—though only over her clothes—continued to stroke her chest, stomach, buttocks, and thighs. To avoid touching her sensitive spots too much and making her unable to speak, he kept his touches gentle and within reach.

Yuu imagined: Meeting Yuki, who had transferred to Sairei Academy from Okinawa, and developing a relationship where they had sex, just like the girls in Class 1-5 now. Thinking that, it seemed like they would be fine when it came to the real thing.

"By the way, in your profile, it said you admire Tsutsui Takako."  
"Yeah. I want to be an actress like Takako-san in the future."  
"Could it be, the kanji in your name..."  
"Yes. I changed it as a wish. But it's a secret from her. Someone like me isn't in a position to meet her directly and exchange words."

If Yuu made arrangements through the foundation, he might be able to arrange a meeting with Takako. But that would be meddling. It would be ideal for Yuki to grow, become known in the industry, and have Takako reach out to her.

"My work has been increasing since last year, but honestly, I haven't been getting many good roles."

Yuki muttered with a slightly dejected expression. Though not detailed in her profile, the roles she played were... like a thug or delinquent who persistently hits on men or sometimes attacks them, only to be beaten by the protagonist. Or someone who commits crimes in the story and gets caught by the police or meets a painful end. Roles that make the audience think "serves you right" or forget in an instant. Indeed, Yuki looked unfriendly when silent, and her voice was somewhat husky. To Yuu, she seemed more cool than cute. But to other women, she probably seemed arrogant. Among the photos attached to her profile was a scene from a school-based movie where she played a delinquent student in a disheveled uniform. Yuu thought she looked dignified, but the public might not see it that way.

"But even when Takako-san was in a similar situation in her youth, she didn't get discouraged and continued acting seriously, building her reputation step by step to where she is now. So I..."  
"Yuki, you'll be fine. You'll become a bigger actress. I guarantee it."  
"Eh!?"

Wanting to encourage her, Yuu brushed aside Yuki's bangs with his right fingertips and lightly kissed her forehead. Though Yuki had lost her virginity at a brothel, she had actually never kissed before. That's why her desire was strong, and she had pushed Yuu down and pressed her lips against his in a frenzy. But today, Yuu had taught her many kinds of kisses. Gentle kisses. Passionate kisses. Sticky kisses that made her head feel like melting. And when kissed on the forehead, a warm feeling welled up in her chest.

"Guarantee... but I'm happy. Thank you. Hee... when Hiroto says that, I feel like I can do my best."  
"Then, maybe I should get your autograph before you become famous."  
"An autograph... I haven't thought about it."  
"Then think about it. I'll be your first fan."  
"Geez, Hiroto..."

Embarrassed, Yuki buried her face against him. Her hair fell over Yuu's face, carrying the sweet scent of shampoo mixed with a hint of sweat. They wrapped their arms around each other's heads and backs, hugging tightly in silence. In Yuu, feelings of affection for Yuki welled up, and at the same time, feeling the soft limbs of a girl, his desire began to stir.

Just then.  
A knock was heard at the door.

"Yuu? Is it about time?"  
"Hah!"

It seemed Satsuki had knocked. Looking at the clock on the wall, about an hour had passed since they entered the room.

"Coming now!"

Yuu and Yuki hurriedly got up and went to the door.

"My, my... seems you've gotten close in such a short time."  
"Eh... well."  
"..."  
"Let's straighten your clothes first."

Yuu hadn't noticed, but Yuki, who was standing close behind him at an angle, had her clothes—though not taken off—clearly disheveled from their time hugging on the bed. Satsuki, approaching Yuu head-on, buttoned his undone shirt and tucked in his T-shirt that had come out. Yuki's shorts had a large stain at the crotch as if she'd wet herself, and no matter how much she pulled down her T-shirt, it couldn't be hidden.

"They said the preparations are almost done, so they want you to shower and change."  
"Got it. Then, Yuki, you go first."  
"Eh, is that okay?"

Normally, men would go first, but Yuu said this out of consideration for Yuki, who had wet her panties. Grateful, Yuki bowed her head.

***

After showering in the attached bathroom of Room 1, Yuu changed into the prepared clothes. It was the Sairei Academy boys' uniform, which he had only worn during the entrance ceremony. A light purple gakuran, but he wore only the white shirt and slacks, not the jacket.

When Yuu entered the bedroom after changing, it had been transformed. A large camera fixed on a tripod at the head and foot of the double bed to capture the scene. Another handheld camera would be operated by the director herself—three cameras in total for the shoot. The room felt warmer, likely due to the strong lights directed at the bed. White curtains hung to cover the wall behind the bed, and reflectors were set up to increase brightness.

And sitting primly by the bedside was Yuki, now changed into Sairei Academy's uniform—a light purple sailor outfit, the short-sleeved summer version. Though she seemed nervous, seeing her like this, she truly looked like a Sairei Academy high school girl.

On the sofa, which had been turned to face the bed, sat Satsuki, Hiromi, and Maho. The director with the handheld camera. Two staff members near the fixed camera and lights. Everyone seemed to be waiting for Yuu.

"Sorry to keep you waiting."  
"Are you really okay with this? Leaving it to you."  
"Yes. I'll leave the introduction to Yuki's acting, but I'll lead the sex itself."  
"Hah. Well, that's some confidence. Then I'll trust in Hirose-kun and Yukki. I'm expecting some great footage!"  
"Yes!"

Yuu thanked the director. Leaving it to a veteran actress would be one thing, but entrusting it to the inexperienced Yuki and amateur Yuu was a gamble that wasn't even a gamble. They might have multiple NGs or even produce a dud. But Yuu thought it would be better to act as he normally did rather than follow a detailed script.

When Yuu looked at Yuki, she gazed back with pleading eyes. No matter how experienced she was, today's shoot was completely different from her usual work. After all, she was the lead and had to perform sex.

"We're ready anytime on this end. We can edit out any extra lines later. Start at Hirose-kun and Yukki's pace."  
"Yes. Thank you."

To avoid NGs from flubbed lines, it was a relief to be given full rein. Yuu took a deep breath to calm himself. What he was about to do wasn't the filming of an adult video. For now, he had to think of Yuki as his real girlfriend and have incredibly hot sex that would make anyone who saw it envious.

"Okay."

Nodding at Yuki, Yuu approached the bed.

The director signaled the staff with her hand, so the cameras were already rolling. As Yuu sat down beside Yuki on the left, he put his arm around her shoulder. Then, Yuki clung to him tightly.

"Hey, Hiroto... I want to do it... Sorry for being such a slutty girl, always wanting you. I can't stop thinking about Hiroto, and when I see you this close, I..."

Yuki's expression and atmosphere had completely changed. It was the expression of a girl in love, who liked the boy in front of her so much she couldn't stand it. Her demeanor strongly conveyed that she was head over heels, as if she would do anything if the boy asked. Even if it was acting, it was impossible not to be happy when a cute girl said it to your face.

Yuki's hand reached up to Yuu's head and stroked it affectionately, while her other hand wrapped around his waist. At the same time, she pressed her body surface tightly against him and rubbed closer. She buried her head against the nape of his neck, then looked up at him with upturned eyes. Her eyes seemed slightly moist, and her breathing grew rough. It was an appeal with her whole body, not just words. Yuu inwardly marveled that Yuki could act like this. Perhaps the rehearsal-like act in the other room had influenced her.

Yuu turned his whole body toward Yuki. Raising the hand on her shoulder, he gently stroked her head. Yuki narrowed her eyes and let out a sweet sigh. His left hand moved up from her thin side to her slender neck, pointed chin, and smooth cheek, stroking each in turn. Then he brought his face closer.

"I want to... with Yuki too."

Saying that, he captured her lips. When Yuu gently pulled his lips away, this time Yuki kissed him. Not just once, but they repeated kisses many times. The sound of "chu, chu" lip smacks echoed.

The director approached the two, who had started with light kisses, and filmed close-ups with the handheld camera. The most difficult part of the actual filming was the introduction scene. The director felt relieved that Yuu and Yuki had entered their own world without being conscious of the camera.

After continuing to kiss for a while, Yuu pulled away and smiled.

"Yuki, you like kissing, don't you?"

Yuki, her cheeks already pink, nodded.

"Yeah. I like it. I didn't know kissing could feel this good until I did it with Hiroto.  
My head feels fuzzy, a happy feeling spreads in my chest, and I want to keep kissing forever. So..."

Pulled in by the right hand placed on the back of her head, Yuu resumed kissing. Changing the angle of their faces repeatedly, they pressed their lips together as if confirming each other's touch.

"Nn... mu... Yu... ki..."  
"Nn fu... Hi... oto..."

With their lips overlapping continuously, the intervals between lip sounds grew longer, but they whispered each other's names between breaths. As Yuki's lips parted, Yuu inserted his tongue. Yuki naturally met it with her own tongue, overlapping. At first in Yuki's mouth, then Yuki extended her tongue into Yuu's mouth—they entwined obsessively. Now, the sounds of sticky, wet saliva could be heard.

"Amu... nfu... churu, nn, npaa... aan, Hiro... to... ero, re ro, re ro, ah, nmu, nfuun"

Getting into the mood, the two poked at each other with their tongues, mouths open, or pressed them together stickily up and down. Oblivious to the drool falling, they became engrossed in tangling their tongues. While stroking each other's heads and backs with both hands, the deep kiss continued. It was no longer just a kissing scene. It seemed they were already engaging in sex with their mouths. Even the director, who had experience filming love scenes between men and women, had never seen such a passionate kiss. Male actors, in particular, tended to dislike deep kisses where tongues touched. It was clear that Yuki, usually quiet and cool, was genuinely feeling it beyond acting. "This might turn into amazing footage," the director thought as she kept filming.

### Chapter Translation Notes
- Translated "クリトリス" as "clitoris" to maintain explicit terminology
- Translated "Gスポット" as "G-spot" using direct anatomical terminology
- Transliterated sound effects: "ぐりぐり" → "guriguri", "ちゅっ" → "chu", "ぴちゃぴちゃ" → "picha picha", "ねちょねちょ" → "nechonecho"
- Preserved role names: "ヒロト" → "Hiroto" (Yuu's character), "ユキ" → "Yuki" (Yonamine's character)
- Maintained Japanese name order: "広瀬 祐" → "Hirose Yuu", "豊田 沙月" → "Toyoda Satsuki"
- Italicized internal monologues: *(Yuu recalled that...)*
- Used explicit descriptions for sexual acts without euphemisms
- Preserved honorifics: "-kun" in "広瀬くん" → "Hirose-kun"
- New dialogue lines start on new paragraphs per formatting rules
- Translated "彩陵学園" as "Sairei Academy" per Fixed Terms reference