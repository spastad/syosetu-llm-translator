## 316. Sex Education Video ④ ~Feelings of Love~

As they pulled their lips apart with tongues still extended, a thread of saliva stretched between them as if reluctant to part.  
Staring at each other, Yuu and Yuki joined lips again, their tongues intertwining inside their mouths.  
After repeating this several times, they finally progressed to the next stage.  
They began undressing each other.  

At the center of the bed, Yuu and Yuki gazed at each other.  
Couples about to have sex vary greatly. With experience, you can sense what your partner wants through atmosphere rather than words. But especially for inexperienced couples, some things won't be communicated unless spoken aloud.  
Though Yuu and Yuki were already so aroused they could communicate with their bodies, this being a sex education video, they exchanged ritualistic words like "I'll undress you" and "Okay" before beginning.  

Yuu's hands unhooked her skirt and slid it down. White panties with a red ribbon pattern accent came into view. Upon closer inspection, a vertical stain was visible.  
Meanwhile, Yuki's hands, trembling with excitement, unbuckled his belt and removed Yuu's slacks.  
When Yuu pulled her sailor uniform up and off, a white full-cup bra with lace trim matching her panties appeared.  
As he'd felt when touching her earlier in the separate room, she had impressive volume despite her slender frame.  
After admiring her breasts, Yuu smoothed her disheveled hair with his hand.  

Unconcerned about her hair, Yuki worked on Yuu's buttons from the top down.  
Once all were undone, she clung to him as she removed his shirt, revealing a plain white T-shirt underneath.  
Yuu's hands went to her bra hooks while Yuki's grasped the hem of his T-shirt, and they removed them simultaneously.  

"Ooh"  
"Haa..."  

They both stared at each other's upper bodies in admiration.  
The breasts freed from the full-cup bra wobbled voluptuously with the slightest movement.  
Given her slender upper body, the breasts felt disproportionately voluminous - perhaps grapefruit-sized.  
The areolae and nipples were a beautiful pale pink.  
As Yuu's hands touched her breasts, feeling their softness in his palms, Yuki spread her palms across Yuu's chest, patting and exploring the firm musculature.  

"Haha"  
"Fufu"  
"Let's take everything off"  
"Yeah!"  

Yuu's hands went to both sides of her panties first, slowly sliding them down.  
As the fabric descended, a neatly trimmed delta area came into view.  
The lower part was visibly damp. When the crotch parted, a transparent string of love juice stretched from her vaginal opening.  
*She showered and changed, yet she's this wet? How aroused is she?* Not that Yuu minded an eager girl.  
With surprise and delight mixing at being undressed by a boy, Yuki wore a lewd grin as Yuu made her kneel to remove her panties and socks, leaving her completely naked. Now it was Yuu's turn.  

Like Yuki, Yuu was already erect, his trunk tenting the front of his briefs.  
The three observers on the sofa (Satsuki, Hiromi, and Maho) had seen Yuu's cock in person, but Yuki, the director, and the two staff members hadn't - or if they had, never one this size.  
That's why they couldn't help being curious.  

"If you pull straight down, it might catch. Spread the front first. Like that."  

When Yuki reached over from beside the kneeling Yuu before the camera, Yuu's soft advice prevented snagging, allowing smooth removal.  

"Wah!"  

Yuki's eyes widened as she saw the magnificently curved erection, letting out a cry.  
The director and crew were equally startled, leaning forward involuntarily though they didn't vocalize it.  

"I-I always think this... Hiroto's cock is so big... and full of energy!"  

While covering her surprise with words, Yuki's hands kept moving.  
Like Yuki, Yuu was now fully nude.  
Then, the two sat facing each other on the bed.  

"Yuki, you're beautiful"  
"Hiroto... you're so handsome and incredibly erotic. I still can't believe such a wonderful boy became my boyfriend"  
"Believe it or not, I genuinely like you"  
"I love you too!"  

Even if acting, no woman could hear "I like you" from a naked beautiful boy and not rejoice.  
Yuki clung to Yuu as if expressing joy with her entire body.  
Skin-to-skin contact inevitably heightened their mutual desire.  
Her voluminous breasts pressed against Yuu's chest, deforming with a squish.  
As the hot meat rod pressed against Yuki's lower abdomen, her womanly parts reacted - love juice trickled down from her groin along her thigh.  

While exchanging yet another passionate kiss, both used their hands to explore each other's bodies.  
Specifically, Yuu's right palm traveled from Yuki's neck to shoulders and back. His left arm bent, scooping up and kneading her breast from below.  
He thoroughly savored the smooth skin and feminine softness.  

Yuki's right hand stroked Yuu's chest with her full palm.  
Her left moved from shoulder to back, fingertips exploring the hard muscles and bony contours.  

Honestly, both were ready for immediate penetration, but this was nominally a sex education video shoot.  
Not everyone gets aroused immediately.  
They needed to show the stage where couples stimulate each other to build anticipation.  
So they sat side-by-side with shoulders touching, positioning themselves for the fixed camera at their feet.  

"Chu, chu, puh... Yuki's breasts. So soft and voluminous... I want to touch them forever"  
"Ahhn! H-Hiroto's chest too... I love it! This feeling is irresistible... Yahn! There, I'm sensitive... me too!"  
"Fuhah! Ah... i-it feels good"  

Yuu's left hand and Yuki's right crossed to caress each other's chests.  
When Yuu squeezed and kneaded while flicking her nipple with his middle finger, Yuki moaned.  
But Yuki reciprocated in kind. Her initially clumsy movements gradually improved as she watched Yuu's reactions.  

While stroking Yuki's hair and kissing repeatedly, Yuu broke away to lick up her neck, then noisily licked inside her ear.  
Attacked simultaneously on ear and nipple, Yuki moaned an octave higher than usual but retaliated with the same caresses.  
When Yuki's tongue probed his ear canal, Yuu shuddered and moaned like a girl.  

"Haa, haa... Yu-Yuki, let me suck your breasts"  
"Haan... breasts?"  
"Yeah. Breasts"  

With faces flushed from mutual caresses, they kissed deeply before Yuu asked.  
Keeping his right hand kneading Yuki's breast, Yuu lowered his head and latched onto her left breast.  

"Hhyuun! Ah, ah, aaah! H-Hiro... to... ahhn! Nooo, I'm too sensitive!"  

Perhaps due to built-up arousal, Yuki reacted more intensely than expected when Yuu rolled her nipple with his tongue inside his mouth, her body jerking.  
Yuu firmly held her shoulder with his right arm and continued breast play.  
Naturally, he kept kneading with his left hand too.  

He licked up and down, swirled his tongue in circles, nibbled gently, then suckled like a baby while stuffing his mouth.  

"Ah... hyu... ah, ah, hyah! I-It's good! Breasts... feel amazing! Hauun! D-don't suck so... ahi... kyaun!"  

Yuki trembled violently while clinging to Yuu. She might have had a mild orgasm just from breast play.  
Now for payback - Yuki began caressing Yuu's nipples.  
She took the left in her mouth while using her right hand's fingers on the right.  
Exactly mirroring what Yuu had done - he demonstrated, she imitated, both trying to pleasure each other.  

After a while, with Yuu's nipples glistening from Yuki's attention, they shared another passionate kiss.  
Meanwhile, Yuu's hand slid down to Yuki's lower abdomen while hers reached for his erect cock.  

Kuchu.  
"Ahyun!"  

Before the camera, they sat with legs spread, Yuki's left leg crossed over Yuu's right.  
Her glistening labia were fully exposed and wet. When Yuu's middle finger touched precisely where her slit opened, love juice immediately clung to it. As he pulled back slightly and touched the small protrusion, Yuki's body jerked.  

Meanwhile, pre-cum dripped steadily from Yuu's urethra where Yuki's index finger touched. She increased to three fingers, rubbing the transparent fluid over his entire glans.  

"Ah, aah! Being touched by Yuki... feels so good!"  
"Hah, hah... me... too, Hiroto touching me... my pussy is... happy! Ahn! So, so good!"  
"Yuki!"  
"Hiroto!"  

While fondling each other's genitals and moaning through parted lips, they repeatedly called each other's names as their tongues met.  

Over 40 minutes had passed since kissing began, through undressing and continuous caresses.  
The three observers (Satsuki, Hiromi, and Maho) watched with heated gazes. Maho fidgeted while pressing her crotch, less composed than the relatively calm Satsuki and Hiromi.  
The director and two staff remained expressionless while focusing on filming, though they couldn't suppress their pounding hearts.  
Previously when filming couples, the man was always passive.  
But here was Yuu - young and beautiful, exposing his entire body while passionately kissing Yuki and actively caressing her.  
Perhaps that explained why Yuki's genuinely unrestrained reactions were another surprise.  

"Hahyu! Au auu... n-no... more... aah! I'm... cumming! Cumming cumming cumming! Hiroto... iih... uuun!"  

Yuki had likely practiced. Her cock-handling skills seemed unexpectedly skilled to Yuu.  
Preparation and genuine enthusiasm helped.  
Each movement of her lips and tongue mixed saliva and pre-cum, producing lewd squelching sounds.  
The supreme pleasure of having his glans enveloped in warm wetness while her tongue swirled inside was overwhelming.  
Though Yuu wanted to let Yuki continue, he decided to try something.  

"Hey, Yuki? There's something I want to try, is that okay?"  
"Nn?"  

Patting Yuki's head as she diligently sucked while stroking him, she looked up at him with the glans still in her mouth.  

After pausing, Yuu lay back with his head on a pillow.  
Yuki got on all fours facing the opposite direction, straddling Yuu's face.  
Their genitals were nose-to-nose - the classic 69 position.  

Spread legs and bright lighting revealed Yuki's gaping slit with salmon-pink vaginal opening right before his eyes. Love juice dripped onto Yuu's cheek.  
Meanwhile, Yuu's fully erect cock stood before Yuki, who lovingly nuzzled her cheek against it while her hands explored his heavy testicles.  

Two cameras at the bed's head and foot captured both genitals.  
The director hesitated - she'd heard of 69 but never seen it live. She filmed them sideways first, then decided to get close-ups of both genitals.  

Yuki licked up the shaft with broad tongue strokes while gently cupping and massaging his balls with her right palm.  
Letting Yuki take the initiative first, Yuu inhaled the female scent around her wet slit, then spread her labia wide with both hands.  
Though she'd taken a man before, her vulva remained pristine. It visibly twitched, begging for penetration.  
Yuu extended his tongue fully and began licking thoroughly.  

"Hyaaah! Ah, ah, aun! H-Hiroto... no... I can't... concentrate! Aahn! This is... ain! Good! T-this... aah!"  

What started as payback for the blowjob became full-force cunnilingus. Yuki threw her head back and moaned despite herself.  
Ignoring her pleas, Yuu showed no mercy.  
After broad upward licks, he inserted his tongue into her vaginal opening.  
Simultaneously, two fingers pinched and stroked her engorged clitoris.  
Love juice splattered onto Yuu's mouth, chin, and cheeks, but he continued relentlessly.  
He firmly held down her hips when they tried to buck upward.  

While tormented by Yuu's techniques, Yuki tried continuing her blowjob, but intense pleasure shattered her concentration.  
Her hair became disheveled from constant head movements.  
Though gasping with open mouth, her hands kept moving diligently.  
The director kept filming, captivated.  

Yuu changed tactics, inserting two fingers deep into her vagina. Each thrust produced sticky squelches.  
Then he pulled his chin back, extended his tongue, and tormented her clitoris.  
Yuki, who'd been trying to lick his cock, finally cried out.  

"Haaaaaaah! Uun! No... more! Aah, aah, aah! Ah... cumming again! Hiro... to... no, aahn! Cumming uuuuuuuuuuuuun!!!"  

Drooling from the mouth, Yuki arched her back violently as Yuu brought her to yet another climax.  

---

### Author's Afterword

If we reversed the genders here, everyone would be erect.  
Moreover, since they're not used to AV filming and are witnessing rare passionate sex firsthand, I think the director and staff maintaining professionalism without losing composure are admirable.

### Chapter Translation Notes
- Translated "涎の糸" as "thread of saliva" to preserve visual imagery
- Rendered "ちゅっ, ちゅっ, ぷはっ" as "Chu, chu, puh" for accurate sound effect transliteration
- Preserved Japanese name order throughout (e.g., "Hirose Yuu")
- Translated explicit anatomical terms directly (e.g., "ワレメ" → "slit", "チンポ" → "cock")
- Maintained honorifics in internal monologue ("Hiroto" for Yuu)
- Used italics for internal thoughts: *She showered and changed...*
- Translated sexual acts without euphemisms (e.g., "フェラ" → "blowjob", "クンニ" → "cunnilingus")
- Preserved cultural terms like "シックスナイン" → "69 position"