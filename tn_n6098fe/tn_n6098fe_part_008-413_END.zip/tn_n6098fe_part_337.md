## 317. Sex Education Video ⑤ ~With Love in Our Hearts~

"Aahn! Hiroto's, your cock, your coock... this hard thing... is grinding against my, my pussy... ahhn, ahhn, it feels so good... I, I want it inside!"

Yuki, straddling Yuu who lay on his back, had been rubbing her slit against his stiff, curved cock with small grinding motions. With each movement of her hips, wet *buchu, buchu* sounds came from their sticky mucous membranes, coating Yuu's cock completely in her love juices.

"It's okay. Put it in. I want to connect with Yuki."

Yuu smiled up at Yuki, who was making a pleading female expression. Though words were almost unnecessary for both of them, they exchanged this dialogue for the sake of filming consent. They had planned to start with the orthodox woman-on-top position for this world. As Yuki guided his cock toward her vagina with one hand while on all fours, the director's camera closed in from directly behind them.

When Yuki lowered her hips slightly, the tip slid in smoothly with a *nuchari* sticky sound as her vaginal entrance—already loosened from three climaxes today—accepted it.

"Ahh! I-It's in... nnngh! Ngguh! It's too big!"  
"Don't push yourself. Take it slow."  
"U...nn... it's okay. I want Hiroto's cock inside me quickly, all of it... ahh, aaaahhh!"  
"Kuu! Yuki's... inside is so tight!"

Though Yuki had taken a man before, Yuu's cock was noticeably larger. For Yuu, the sensation resembled forcefully widening a narrow crevice during virgin encounters. The vaginal folds gripped and squeezed rhythmically. Yuki might have been in pain from forcing herself down—her hands gripped Yuu's shoulders tightly, and sweat beaded on her furrowed brow. But finally, it slid in effortlessly with a *nyururi* sound.

"Hyaa! Ahh, amazing, i-it's, d-deep... ahh... so deep inside... your cock... ah... hii..."  
"Yuki, we're fully connected. Your insides feel amazing."  
"Aaaii..."

Seeing Yuki overwhelmed after achieving her wish, Yuu embraced her tightly to spare her from awkward conversation.

"Ah, s-sorry, Hiroto. I should be moving..."  
"It's fine. Just being like this feels good. I'm happy to be fully connected with Yuki."  
"Annh!"

When Yuu tensed his hips, the tip thrust deep into her vaginal depths. Honestly, if she'd started moving vigorously immediately, he might have finished instantly, so her stillness helped. Touched by his consideration, Yuki pulled his head close and kissed him. As they exchanged *chupa chupa* kisses, Yuki slowly raised her upper body, her breasts—pressed against Yuu's chest—lifting and swaying with the movement.

At about 45 degrees, Yuki began rocking her hips. Though clumsy at first, her movements soon smoothed out.

"Haa! Annh, annh, annh! I-It feels so good! Hiroto's cock, your cock inside me... all the way deep... ahh! It's hard... grinding... pushing up... ah! I-I'm... cumming again!"  
"Yuki... you can cum first... guh, it feels good for me too..."  
"Sorry, Hiroto! Aahh! My hips won't stop!"

As her movements smoothed, her pace increased, seeking more pleasure inside. *Pashin, pashin, pashin*—the sound of buttocks meeting flesh. *Zuchu, zuchu*—the rhythmic melody of love juices from their joining. When Yuu grabbed and kneaded her swaying breasts, Yuki's face jerked upward. Drool dripped from her open mouth, unnoticed amid constant moaning. Though not much time had passed since penetration, climax approached rapidly. The hip-slapping sounds accelerated to near-continuity. The friction from her vaginal folds intensified, forcing a moan from Yuu, but he endured.

"Haaan! Amazing! Amazing! I'm... cumming! Ahh, ahh! Th-this... ahk! Uwaa... I... can't... think! It's coming... so strong! Hya... ah.........no........nh... kufu..."

Yuki collapsed onto Yuu's chest, unable to support herself. She trembled in small spasms, still riding the waves of climax.

"Ah... haa, haa, haa... my mind went blank... almost passed out. I... never knew sex like this... ahhaa, it was incredible..."

Though Yuki had climaxed three times since filming began, internal orgasm during penetration was clearly exceptional.

"Now I'll move."  
"Eh?"

Holding Yuki in place, Yuu sat up like doing a sit-up. Keeping his cock embedded by supporting her buttocks, he shifted to a sitting position. He adjusted slightly for equal camera coverage. The director—who assumed Yuki would remain on top—hurriedly repositioned, eventually crouching behind Yuki for a close-up of their joining.

"W-w-wahh, I'm... impaled on your cock..."  
"I'm close too. I'm going to keep going."  
"Wa-wa-wait... hyan!"

When Yuu thrust upward, Yuki clung to him desperately. Her breasts pressed against his chest, deforming *munyu* as they bounced. For Yuki, this position felt deeper than when she was moving. She sensed his cockhead pushing against her descending womb—ready to pour his seed into her. Her own desire to conceive with Yuu's semen surged rapidly. Unable to withstand the deep thrusts, she clung tightly while letting out high-pitched moans.

*Tan, tan, tan!*

"Ah, ahi... higu... nnngh! Th-this, no, Hiro... oh, ohi! Amazing, ahh, again... aahh! I can't... I'm cumming, ahhiin!"

As if fused together, Yuu kept thrusting while they embraced tightly. The rhythmic slapping of flesh echoed as Yuki could only moan incoherently. Her next climax approached. Women often climax consecutively after the first—opposite to men's refractory periods. Yuki had remained aroused since the position change. The breaking point was near.

Men come easily the first time, and Yuu—who'd been holding back—also neared his limit. Yuki unconsciously wrapped her legs around his waist, making movement harder, but Yuu didn't stop. He thrust upward as if prying open her cervix, pressing deep.

"Gu... ooh, good! I'm cumming, Yuki!"  
"Ah... hi... heaa! So rough... feels good!"  
"Yuki, I'll ejaculate plenty, take it all, get pregnant with my child... ahh! Yuki! I love you! Yuki!"  
"I-I... hyauun! Amazing! Hi, Hiroto, Hiroto, Hirotoo! Oh.........!"

Calling each other's names like lovers, they approached climax together.

Yuki came first. Staring blankly upward, mouth gaping wordlessly, she received Yuu's powerful ejaculation deep inside.

"Cum... ming... kufuu"  
"Fe? Oh... kuhi... i-inside... filling... ryuu... uun... amazing... ahhaa..."

Yuki felt the thick, abundant semen gushing forcefully to fill her womb. The intense stimulation right after climax seemed too much—her consciousness faded as she buried her face in Yuu's shoulder.

"Cu-Cut!"

The director finally spoke, pausing the filming. About an hour and a half had passed.

"Wow, that was incredible, both of you. I was so absorbed I forgot this was work."

Her words weren't empty praise but genuine. The two staff members nodded in agreement, fidgeting between their thighs now that the tension had eased. For a normal adult video, they'd film one or two more scenarios, but this was a current high school boy. They couldn't push him. The director felt this was sufficient for an educational reference video.

But Yuu disagreed. His lust hadn't subsided.

"Um... I don't want to stop yet."  
"Eh?"

Yuu and Yuki remained joined. Yuki slumped against Yuu's shoulder, eyes closed in a daze, still immersed in the afterglow. Yuu kept himself inside to prevent semen leakage. He could continue for round two, but Yuki needed rest. Fortunately, another woman he'd wanted to deepen relations with was present.

"Maho-sensei!"

Maho didn't immediately respond to Yuu's call from the bed. She hadn't expected to be summoned. Enthralled by Yuu and Yuki's intense sex, she'd been absentmindedly rubbing her thighs together—though not masturbating. Only when Yuu called again and Satsuki nudged her shoulder did she snap back.

"Eh, eh, me?"  
"Yeah. Maho-sensei, come here."  
"Um, well, I need to prepare mentally..."

Maho rose unsteadily from the sofa and approached the bed. With the room's rising temperature, she'd removed her jacket, revealing a white blouse tucked into her pants—accentuating her disproportionately large breasts on her petite frame. Yuu had withdrawn his cock and entrusted Yuki to a staff member. His erection remained firm and glistening as he turned to Maho. Her eyes were drawn to it. Already soaked beyond her underwear's capacity, her lower abdomen clenched at the vivid memory of last year's special health class.

Since youth, she'd been baby-faced and short, mistaken for a student even as a teacher. Her unnecessarily large breasts were a nuisance and complex. She'd achieved her dream of becoming a health teacher at a co-ed school, but male students were handled by male teachers in their building. Then came last year's special request. Yuu—an unexpected presence—appeared before her.

For some reason, his obvious attraction from their first meeting delighted her. Had she not been a teacher, she might have misunderstood—though it wasn't a misunderstanding; Yuu genuinely liked her from the start. Seeing his young naked body during class excited her. She envied watching him interact with female students. The surprise came at the end: Yuu had her perform fellatio. Then he desired her breasts—using them to bring him to climax before the students became her ultimate moment.

Afterward, occasional meetings in the management building led nowhere special. Rumors said Yuu had physical relationships with several staff members besides students—spotted heading to the Friendship Building after school with non-students. Though busy as student council president, Maho longed for his invitation—a wish shared by many female staff at Sairei Academy.

"If Maho-sensei is willing, I'd like you to do the same as last time."  
"M-Me... with Hirose-kun's..."

Eyes shifted between them. Only Maho knew what Yuu wanted, giving her faint superiority.

"Um, this wasn't discussed beforehand, but if you're willing to cooperate, sensei? We'll decide later whether to include it."

The director didn't know what would happen but swelled with anticipation. Yuu kept surprising her beyond expectations.

"I heard Maho-sensei would be supervising today, so I really wanted to ask."  
"I-I... if Hirose-kun wants it, I'll do anything!"  
"Maho-sensei, thank you. I love that about you."  
"Feh?!"

As Yuu leaned forward and took her hand, Maho was pulled strongly toward him. His face neared, his hand touched her cheek—then their lips met. Maho had dated in college but only platonically. Aside from touching male bodies during health training, Yuu was her first for everything. She'd suppressed her strong longing due to their age gap. That made this kiss—initiated by Yuu—exceptional. Despite having just ejaculated, Yuu's lust burned undiminished for the cute teacher. He didn't stop at pressing their lips together but pushed his tongue inside. Maho's head swam when their tongues touched, rekindling the embers deep inside.

"Nchu, churu, chumu... ero, rero, reroo... Hiro...se... kuun... I love you... love you love you... amuchu, nn, nn, aafuu, npaa..."

Maho clung to him, their deep kiss lasting minutes. When they separated with tongues still out, a string of saliva connected them. Maho—expression melted—quickly moved to unbutton her blouse.

"I-I'll strip right away. Wait for me, Hirose-kun!"  
"Wait, sensei. I think it's more exciting with clothes on."

Maho stopped with one button undone, radiating pink aura, as Yuu placed a hand on her shoulder. She tilted her head, uncomprehending.

---

### Author's Afterword

Maho-sensei appeared in chapters 246-249 ("Student Council President's Work?" arc). She's a 29-year-old virgin school nurse with a baby face, short stature, large breasts, and wears a white coat.

### Chapter Translation Notes
- Translated "おチンポ" as "cock" following explicit terminology rules
- Preserved Japanese honorifics (-sensei) throughout
- Translated internal monologues with italics (e.g., *This is concerning*)
- Transliterated sound effects (e.g., "buchu" for ぶちゅっ)
- Maintained original name order (Hirose Yuu, Yonamine Yuki)
- Translated anatomical terms directly ("vagina", "semen", "ejaculation")
- Used explicit terms for sexual acts ("intercourse", "fellatio", "climax")
- Formatted new dialogue lines as separate paragraphs