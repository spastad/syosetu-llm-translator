## 318. Sex Education Video ⑥ ~The Virgin Who Came Between~

Maho sat on the bed with her butt planted firmly, complying with Yuu's request to remain clothed. With her blouse unbuttoned to the second button, the frilly cups of her pink bra and cleavage were visible from above. 

Kneeling as he approached, Yuu bent at the waist and tried to thrust his erect cock upward from below her prominently lifted breasts, but stopped.

"Maybe you should unbutton the lower buttons too?"  
"Okay."

Leaving the third and fourth buttons fastened at her chest, Maho unfastened the buttons below the fifth. What Yuu intended was clothed paizuri. He remembered seeing it in erotic manga and had always wanted to try it. While naked bodies were wonderful, Yuu also found excitement in clothed acts—especially with working women like teachers, nurses, or office ladies.

"Huh?"

As Yuu tried to sandwich his cock through the open front of her blouse toward her abdomen, the tip met the rough-textured fabric of her bra. Peering at the bra, Yuu realized his mistake. Most bras have thick, wired fabric at the bottom to support breasts against the skin. Maho's full-cup bra—designed to support her self-reported G-cup bust—was particularly sturdy. There wasn't even space to slip a finger underneath. The clothed paizuri Yuu envisioned was only possible with wireless bras.

"Wait. I'll undo the clasp."  
Thanks to Maho understanding Yuu's intent and unfastening her bra clasp, the bra loosened slightly. Maho thrust her chest forward, resting both hands straight down on the sheets. She seemed to be emphasizing her breasts while also appearing to beg Yuu for attention.

Yuu bent at the waist again and inserted the tip of his cock into the gap beneath her bra, thrusting upward. The bra lifted slightly inside the blouse but didn't come off since the shoulder straps remained fastened. Though loosened by the unfastened clasp, the unexposed cleavage remained tightly closed. Yuu forced his way in. 

His cock was slick with semen and vaginal fluids, and sweat glistened in the valley of Maho's breasts—likely aiding the smooth slide. With a *nyur* sound, it slipped in, the glans emerging from the cleavage.

"Ah-ha! Your cock said hello!"  
"Ohh... Being squeezed by Maho-sensei's tits is unbearable!"

The blouse strained taut against the intruding object, buttons threatening to pop off. There was no tight constriction like a mouth or vagina. Instead, soft flesh squeezed him firmly, the warmth of human skin feeling wonderfully comfortable.

"Then I'll move now."  
"Please, Maho-sensei. It'd be great if you licked the tip too."  
"Ufufu. Got it."

Clamping her sides, Maho moved up and down, stroking the cock sandwiched between her breasts.

"Ohh, ohh, feels so good!"  
"Waha! I'm glad! I'm happy that Hiro... Hiroto-kun is pleased! Ufufu!"

Had she almost said his real name? Maho laughed it off. Perhaps because of her prior experience, her movements were smoother than before, and Yuu genuinely lost himself in the pleasure without flattery. Visually, the sight of his cock being paizuri'd inside the taut blouse was intensely arousing. 

As a bonus, Maho pulled her chin down and extended her tongue toward the glans protruding from her cleavage.

"Muhah, your cock is so cute. I'll lick it all over!"  
"Oh, ohh! That's good!"

Experienced as she was, Maho paused when the glans emerged, pursed her lips to take it in, and swirled her tongue around it. She varied her oral and tongue movements to avoid monotony. While paizuri alone gave her leeway, combined techniques like sucking made Yuu vulnerable. Maho's knowledge as a health teacher seemed to be shining in her second practical session.

Precum dripped from Yuu's cock, and Maho teased the urethral opening with flicking tongue movements. Unswallowed precum mixed with drool dripped down, making sticky *nucha, nucha* sounds in rhythm with her movements. Each time Yuu's lower abdomen hit her underboob, it made a *tapon, tapon* sound.

"Kuuah! Ah... Sensei, you're so good! T-too good!"  
"Mmmph~"

Maho's smile widened at Yuu's reaction. Not only was she squeezing his hot, hard cock with her breasts, but hearing Yuu's moans from her ministrations aroused Maho intensely too.

About three—no, five minutes passed. Though continuing the movements must have been tiring, Maho showed no sign of fatigue, engrossed in paizuri-fellatio. She even began focusing more on the sucking. Thanks to this, Yuu felt his ejaculation building.

"Ah, ah, ah, s-sensei! I'm... about to cum soon! Kuhu. Your tits and mouth feel so good!"  
"Amujururi, jupuu... Mph. Let sensei drink your hot load. Aaanm."

Pulling her chin down sharply, Maho deepthroated the glans, using her tongue while sucking. Simultaneously, she squeezed her clamped breasts *gyuu, gyuu* tight.

"Whoa! Sensei! Aah, hah... Damn that, I-I'm cumming!"

Feeling the cock pulse between her breasts as semen rose, Maho firmly closed her lips and stopped moving, taking the glans fully into her mouth. When her tongue tip prodded his urethra, hot semen gushed in forcefully, but Maho caught it all.

"Mph! Nn... Mmph... Ung!"  
Unlike last time when she couldn't swallow properly and overflowed, she seemed to have succeeded this time. But even for a second ejaculation, Yuu produced a large volume. Perhaps relieved at swallowing the first few spurts safely, when Maho pulled her lips away, semen *pyuru*-ed out, splattering on her mouth and dripping onto her blouse.

""Ah... Sorry!""  
They spoke simultaneously. Yuu apologized for staining her blouse, while Maho expressed guilt over spilling despite intending to swallow it all. Seeing each other's faces, Yuu and Maho smiled. Yuu reached out with his right hand and gently stroked Maho's head.

"Maho-sensei, thank you. That felt amazing. Your tits really are the best."  
"Ah, aha... Hi-Hirose-kun!"  
"Whoa!?"

Maho reached out with both arms to hug him. In his slightly unstable position, Yuu fell backward. Maho gazed at the cock glistening with semen and her own drool, her eyes heart-shaped with lust. Simultaneously, she gently grasped his testicles and shaft base with both hands, then extended her still-white tongue and began sucking passionately.

"Chu, chu, chupa... Anm, om, nera nera oo... Ahhaa... So big and splendid and strong and twitching so cutely... Chu, chu, mm~~chupuu. Haan, I love Hirose-kun, love your cock so much. What would happen if this went inside my pussy?"

Muttering to herself, Maho devoted herself to pleasuring his cock. Her tongue meticulously licked from glans to coronal ridge, shaft, base, and testicles. Both hands explored the surface texture and lightly stroked. Despite having just ejaculated twice, his hardness didn't diminish. Rather, Maho's attentions felt so good that Yuu, lying on his back, let her continue.

"Shall we try inserting it now?"  
"Hae? Ah... Aaaaaaah!"

Sitting up, Yuu grabbed Maho's arm as she tried to pull away in sudden self-awareness.

"Awawawa... Hyah! H-Hirose-kun?"  
"I'll take off your bottoms."

Though cameras were rolling, Maho didn't realize she'd used his real name. That could be edited later. This time, Yuu laid Maho on her back and removed her belt and pants. Though Maho kept making flustered sounds, she offered no resistance. Her matching pink panties were soaked through, pubic hair visible through the fabric—extremely erotic.

Grabbing both her ankles, Yuu lifted her legs and pushed them forward. The crotch of her panties clearly outlined her vulva, reminiscent of an abalone. Bringing his nose close, he could smell her feminine scent through the fabric.

"Maho-sensei, you're so lewd."  
"Hah, hah, hah... Being watched. Hirose-kun is staring right at my indecent place..."

Maho seemed to have an incredibly rapid heartbeat, pressing a hand to her chest. Yuu held both ankles together with his left hand and began removing her panties with his right. As the pink fabric peeled away from her buttocks, a transparent thread stretched from her vagina when the crotch separated. Yuu deliberately left one panty leg on—another of his preferences.

After lowering her legs and spreading them wide, Yuu positioned himself between them. His cock—still rock-hard from her enthusiastic sucking—pressed against Maho's lower abdomen. Feeling the heat and hardness, Maho's body trembled with pleasure.

Noticing the director filming from near Maho's head in his peripheral vision, Yuu locked eyes with Maho. Though she seemed unable to keep up with the sudden turn of events, seeing Yuu's seriousness, she revealed an ecstatic expression and hooked both hands behind her knees to spread them wide—a self-made M-leg spread.

"H-Hirose-kun will put it in?"  
"Yeah. We'll do it in this position. Um, sensei, have you had experience?"  
"Embarrassingly, I'm still a virgin at this age."  
"Then I'll be Maho-sensei's first. I'm honored."  
"Me too... that Hirose-kun would do this... it's like a dream... I'm so happy..."

Sex with a cute, baby-faced, big-breasted older teacher—and a virgin at that. Yuu felt truly grateful. Pulling his hips back temporarily, Yuu looked down at the target. Maho's wide-spread legs left her slit *kupaa*-open and fully visible, glistening wetly as if eagerly awaiting the male member. Aiming at the tiny hole that seemed barely large enough for a pinky, he guided the tip into place with his hand.

"Ah, it touched!"  
"Here I go."  
"Nnn! Co...ming..."  
"Guh! Tight!"  
"Higuu! I...ih!"  
"A-are you okay?"  
"I'm okay... So... hurry... I want it."

Following health education recommendations, her hymen had likely been broken beforehand. Though there was no deflowering pain, Maho's passage was physically too narrow for Yuu's cock. Still, Maho desired Yuu's insertion more than she feared pain. However, despite appearing thoroughly wet and relaxed, his progress halted midway.

Having ample experience, Yuu didn't panic. He knew women's bodies were mysterious—even vaginas that struggled to accept a finger could accommodate his massive cock once accustomed. Pressing down on her hips with his left hand, he moved in small, slow thrusts. His right hand reached for her breasts, unfastening her blouse buttons and pushing up her bra.

As Yuu's hips moved, hill-like breasts wobbled *taputa-pu*. Cupping them with full palms, supreme softness transmitted through his hands. While penetrating her virgin hole, he kneaded the massive breasts—a man's dream.

"Ah, ah, it's going in!"  
"Yeah. My cock's getting used to Maho-sensei's pussy. See, a bit more."  
"Haun! S-so big! My pussy is being stretched by your cock! Ryu! Hao! Shugo... oh! Ooh!"  
"Hah, hah... Inside Maho-sensei's pussy... so tight! But just a little more!"

It felt like forcibly widening a narrow crevice, securing an invasion route bit by bit. As the cock advanced deeper, Maho's voice became fragmented gasps, her jaw tilting upward. Trembling from the pleasure in his groin, Yuu panted heavily but kept thrusting to bury himself completely. The director captured close-ups of Yuu conquering the female body with his cock.

Though it took time, one final push pierced her deepest depths.

"Piaa! Cock, cock... d-deep inside... nnph... my insides... full of cock... uhee... so happy... with Hirose...kun, finally... connected... ahahn"  
"Haaah~ Maho-sensei's tits were the best, but your pussy is the best too! Squeezing my cock so tight! Kuhu!"

Covering Maho, Yuu spread both arms wide and hugged her tightly. Her voluminous breasts pressed against his chest, *munyu*-ing out of shape. Enveloped in Yuu's arms, Maho looked deeply moved. When pierced to her depths, an unprecedented shock ran through her. Allowing a man's powerful member into her deepest place didn't cause pain—instead, a boiling, hot surge erupted from her core. At age 29, her feminine instincts rejoiced at finally being able to conceive.

Releasing her legs, Maho wrapped both arms around Yuu's back and clung to him with all her strength.

---

### Author's Afterword

Clothed erotica is wonderful. The lewdness of ripping pantyhose, pulling panties aside for insertion, or paizuri while still dressed! It's even better when the girl acts shy, but in this world women are more proactive—they'll actively enjoy the play together, like Maho-sensei in this story.

### Chapter Translation Notes
- Translated "着衣パイズリ" as "clothed paizuri" to maintain the specific fetish terminology
- Preserved Japanese honorifics (-sensei) and name order (Hirose Yuu)
- Translated explicit anatomical terms directly ("cock", "pussy", "testicles")
- Transliterated sound effects (e.g., "nyur" for にゅる, "nucha" for ぬちゃ)
- Maintained internal monologue formatting in italics
- Translated "童顔巨乳" as "baby-faced, big-breasted" to capture both physical descriptors
- Used "deflowering pain" for "破瓜の痛み" to convey the specific cultural concept
- Preserved the alias "Hiroto" during video filming scenes