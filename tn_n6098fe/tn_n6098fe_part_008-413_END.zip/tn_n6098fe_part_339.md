## 319. Sex Education Video ⑦ ~With Love for the Last Scene~

"Maho-sensei, how are you feeling?"

"Haaeeeeee... Being held gyuu by Hirose-kun... it's like... I'm in heaven... Ah, aahn! My breasts feel good too!"

After several minutes of missionary penetration, when his penis had adjusted inside her vagina, Yuu decided to change positions.

He inserted himself from behind while holding Maho in a seated position - in other words, reverse cowgirl. Yuu preferred doggy-style for taller partners, but with the petite Maho under 150cm, he wanted to hold her while penetrating from behind.

Facing the direction of their feet was a fixed camera, while the crouching director filmed their joining point from a low angle at the bedside. The footage would clearly show Yuu's thick penis penetrating deep into Maho's small vagina. Unnoticed, Satsuki and Hiromi had moved beside the fixed camera to watch intently.

Yuu wrapped both arms around Maho's sides while roughly grasping her breasts. Though he considered letting Maho see their joining point, he realized her oversized breasts blocked her view. So while kneading her right breast, he lowered his left hand to her abdomen, letting his fingers slide below her navel.

"Sensei, can you feel my penis tip here?"

"Haaun! Y-yes... I can feel it... Your penis is knocking knock knock on where babies are made! Ahn! Aahn! It feels so good... sooo much... Kyauun! N-no... I'm feeling too much... it's making me crazy!"

When Yuu whispered close to her ear, Maho answered with ecstatic moans. After stroking her lower abdomen, Yuu's fingers descended to her thin delta region and touched her clitoris. Maho trembled violently and ejaculated fluid. Though Yuu's hip movements remained teasingly slow, having her nipples, clitoris, and ears stimulated while being held from behind kept Maho constantly aroused. Feeling Yuu with her entire body, she was enveloped in euphoria. The vaginal opening that had barely accepted a finger before penetration was now stretched wide open for Yuu's penis.

With each small thrust of Yuu's hips, juices dripped steadily, soaking the nearby sheets. Zuchu, zuchu - sticky sounds echoed through the room as the fluid dripping from their joining point grew cloudier with arousal.

"It makes me happy you're feeling this much your first time. Maybe our bodies are compatible, sensei?"

"Uhe, uheheheee..."

Hearing such whispers, Maho's mouth slackened into a lewd smile. Though a woman's sensitivity changes based on emotions, Maho's fondness for Yuu was likely at maximum. After all, the most coveted boy in school was focusing only on her. Though unfamiliar with this position initially, once experienced, it became irresistible. Being filmed actually enhanced the experience for her.

"Ahaha... Sensei... today will... become... a lifetime memory for me! Ahn!"  
"Then if I creampie you and get you pregnant, that'd be even better!"  
"Ahi! Hi-Hirose...kun! Ah! Ah! Ah! Your penis, your penis grinding grindy... feels good, good, ghiin! I want Hirose-kun's seeeemen! I want to have your baaaby!"  
"Then I'll go harder. There, there!"  
"U...hiin! Hiro...ooh! Aaaaaaaaaaahhhhhhhh!"

Yuu pressed down hard on her breast and lower abdomen while accelerating his thrusts. Maho's sweet moans transformed into breathless cries. Someone gulped audibly. From the front, everyone could see Yuu's thick penis plunging in and out of Maho's small vagina - a rare sight that captivated all eyes. With Yuu's movements, zuchu, zuchu - viscous sounds filled the air as the fluid dripping from their joining point turned cloudy with genuine arousal.

"So good! Th-this is my... first time... aahh! Hi-Hirose...kun!"  
"Sensei! I-I feel amazing too... haa, haa, Maho!"  
"Hirose-k...mmph, mm, mua, neraa"

As Maho panted with her tongue out, Yuu covered her sideways-turned mouth, tangling their tongues. Her virgin vagina was exquisite - changing positions made the pleasure surge from his hips to his back, threatening to make him climax instantly. Though he tried distracting himself, it proved ineffective. Instead, Yuu's ejaculatory urge intensified rapidly. Keeping Maho firmly pinned with both hands, Yuu kept thrusting violently - a final sprint toward his creampie goal. With both upper and lower mouths intimately connected, they climbed toward climax together.

"Ma-Maho, heheee... nguh! I-I'm cumming... ooh, ooh, already... guh!"  
"Aaee, nmo! Vuun! In! Hiofe... fuun... aa! Aa! Ifu, ivu! Nbo!? V...nnnnnnn!"

Drool dripping freely, Yuu and Maho kept their mouths open and tongues intertwined. Emitting wordless moans and gasps, they approached their climax. Yuu pressed his lips firmly against hers while gripping her ample breasts tightly with crossed arms. With one final deep thrust, he released his seed into her womb. Maho gripped Yuu's arms tightly as she received his fierce passion through both mouth and uterus, her expression ecstatic as she lost herself. For her, being pinned down by Yuu felt supremely pleasurable - receiving his vigorous semen pulses while surrendering to unprecedented ecstasy.

***

With Yuu in the center, Yuki clung to his right and Maho to his left as they slept together. The blanket only covered up to their stomachs, leaving all three upper bodies visible. After creampieing Maho, they took a break before filming the final scene. Though originally planned for just Yuu and Yuki, Maho's inclusion proved fortunate. In this world where one man servicing multiple women was normal, the crew had only prepared one partner out of consideration for 16-year-old Yuu's inexperience. By adding Maho himself, Yuu created a more natural dynamic.

The intense passion Yuki and Maho felt during intercourse had subsided, but they expressed their joy at being naked against Yuu through their entire bodies - pressing close, rubbing their faces against his shoulders, gently stroking his head, chest, cheeks, and neck. Though hidden under the blanket, their legs were entwined with his. Like animals marking territory, they wanted maximum contact in these final moments.

Yuu looked between them with satisfaction, whispering something that made them blush or exchange light kisses. Without needing to act, they displayed genuine affection.

"Ahh, just feeling Hiroto's warmth makes me happy."  
"Me too... I love Hiroto-kun's skin. I want to stay like this forever."  
"Hahaha. With a flower in each hand, I couldn't be happier."  
""Flower in each hand?""  
"Yeah. It means having cute girls on both sides."  
"Fufu. You say such funny things. If Hiroto wanted, countless women would replace us."  
"That's right. Not just students - all faculty adore Hiroto-kun too."

Though "flowers in both hands" was male romance in his old world, here it was commonplace. Even in fiction, it remained unchanged. Still, Yuu cherished the two against his skin right now.

"Yuki."  
"Nn."  
"Maho-sensei."  
"Hyai!"  
"Right now, Yuki and Maho-sensei are my lovers. I love you both so much I couldn't imagine replacements!"  
"Ah... Hi-Hirotoo"  
"Aahn! Sensei loves you toooo!"  
"Wah!?"

Yuu pulled them tightly against his shoulders as he declared this. Beyond acting, these were his genuine feelings. Understanding this, Yuki and Maho beamed with moved expressions and simultaneously kissed Yuu's cheeks. With lips still pressed, they competitively sought his mouth - not just alternating kisses but overlapping tongues. Yuu's right hand stroked Yuki while his left tenderly touched Maho's head, cheeks, neck, shoulders, and back. Naturally, they reciprocated with every movable body part.

Though hidden under the blanket, Yuu's penis trapped between their thighs rapidly hardened from their healthy, smooth skin and elastic flesh. Despite three ejaculations, the interval had been sufficient. Pressured by two naked beauties, Yuu reacted instantly. His crotch visibly tented the blanket, startling the watching women.

"Cu-cu-cut!"

As a threesome seemed imminent, the director called cut and stopped the cameras. Though Yuki and Maho stopped kissing, they remained clinging to Yuu. Like Maho, even Yuki seemed genuinely infatuated beyond acting. With filming concluded, the director tried to wrap up.

"Erm, Hirose-kun, Yukkie, and sensei too - thank you. Thanks to you, we got wonderful footage toda..."

The director's words cut off when Yuu threw off the blanket, exposing his lower half. Rubbed between their thighs, he was fully erect again.

"Yuki and Maho-sensei got me hard again. Think you'll take responsibility?"  
"Lies... after all that ejaculation... unbelievable..."  
"Dehehehe. If Hirose-kun asks, I'll do anything! Should I titty-fuck you again? Or suck you?"

They alternated heated gazes between his erect penis and face. Getting titty-fucked by both would be good. A double blowjob would too. But noticing the other watching women, Yuu realized filming was over. Scanning all females in the room, he declared:

"Satsuki-nee, Hiromi-san, I want you to touch me too. Actually - staff members, director, would you like to touch my penis?"  
"""Eh..."""

At Yuu's words, Satsuki and Hiromi eagerly approached the bed. In contrast, the director and staff froze - wondering if they'd misheard or hallucinated from wishful thinking. Both staff members had lost their virginity. The director especially, while lacking full AV experience, had seen semi-naked men before. But a male filming subject inviting staff to touch him was unprecedented. They stood paralyzed.

Satsuki and Hiromi patted their shoulders encouragingly. Though bound by confidentiality, since Yuu permitted it, touching should be fine. Seeing the two staff leave their cameras, the director approached Yuu with trembling hands, not wanting to miss this rare opportunity.

***

"Hamu, hamu, lepochu, chu, chupaa... fuu. Even so, getting naked for cameras then getting aroused surrounded by all these women - Hiroto, you're truly lewd~"  
"Ah, ah, uun! Yeah... I surprise myself with how strong my libido is... aah! There, good!"  
"Haa, haa, seeing Hiroto-sama feel good makes me happy... and excited. Let me hear more lovely sounds? Chuuuuu! Lero lero lerorn"  
"Au! Hiromi-san... you're so skilled... feels amazing!"  
"I love that Hiroto! I love you with all my heart!"  
"Sa-Satsuki-nee... me too... nnnn!"

Surrounded by seven women, Yuu sat bedside like sap-covered tree swarmed by insects. His pained moans, sweaty skin, and bodily fluids entranced the women. From behind, Satsuki and Hiromi simultaneously sucked his ears while roaming his head, neck, shoulders, and chest with both hands. Being experienced, they yielded his penis to others while focusing on kissing and upper-body caresses to heighten his pleasure.

"Haaa~ So this big thing was inside me. That's why I felt so full, getting knocked deep inside."  
"I know~ Plus, the glans is so big - it spreads you open when entering, and that ridge feels amazing when pulling out."

On the bed facing downward, Yuki and Maho each hugged Yuu's waist with one hand while touching his penis with the other - mainly stroking the glans and coronal ridge. Recalling his vigorous thrusts inside them, their vaginas moistened again as they writhed. Meanwhile, Yuu's hands cupped and kneaded their voluminous breasts from below.

"Hey, you ejaculated three times already? Not faked?"  
"Yep. We filmed it clearly. No dummy fluid - such thick semen came out."  
"...Yet you recover like this. And letting us touch something so thick, long, and magnificent... ahh, wonderful."  
"I know I shouldn't feel this way but... just touching it makes me throb."  
"I know~"

While adult videos usually featured crossdressing women as male actors, some used real men. Even then, they either didn't film ejaculation or faked it with dummy white fluid - using unrealistically large amounts to excite viewers. Yuu's ejaculation volume matched those exaggerated dummy fluids.

Leaning against Yuu's spread legs were the two staff members. Yuu had learned their names: To his right - tall, slender Kinjou Youko (26), with thin single-lidded eyes, an oblong face, calm demeanor, and semi-long black hair tied up. To his left - plump, round-faced Iha Minami (23), with short brown bob hair making her look younger, her cheerful personality evident when speaking.

They'd filmed and directly witnessed Yuu's ejaculations and the thick white fluid dripping from Yuki and Maho's creampied vaginas. Especially Minami, tasked with cleaning Yuki afterward, had touched the overflowing semen, smelled it, and even licked it.

Like Yuki, Youko and Minami had lost their virginity at brothels. But this genuine lovemaking surpassed such experiences. Though they'd endured arousal for work, their underwear was soaked. Yet they didn't consider changing - not with this opportunity before them. Timidly touching Yuu's penis, they felt its heat and hardness, their expressions dreamy as they expanded their exploration. Though not especially beautiful, Yuu appreciated their sincerity and work ethic.

Kneeling directly before his penis with a serious expression was the director.

"Muu... Seeing once beats hearing a hundred times, but touching once beats seeing a hundred. In ancient times they called this the 'male root' - its gnarled texture and upright stance truly feel like hard tree roots. The testicles feel heavy despite three ejaculations - visibly full of semen. Kkuu, if I were younger, I'd spend my entire fortune for a chance..."

As if her personality had changed, the director muttered seriously while stroking shaft to testicles with her palm, though Yuu didn't register her words.

More observational than sensual, the director's touch and the staff's still-timid stimulation proved mild. Compensating, Satsuki and Hiromi poured affection into pleasuring Yuu's upper body - alternating deep kisses while tirelessly caressing with tongues, lips, and fingers. Meanwhile, Yuki and Maho stimulated his most sensitive areas - glans, coronal ridge, and frenulum - not just with fingers but unhesitating tongues. Their mixed saliva and pre-cum created lewd necha necha, picha picha sounds. With seven women heightening his entire body's sensitivity, Yuu's ejaculatory urge built rapidly.

"Araa, Yuu, close to cumming?"  
"Uu, ugu! Nn... yeees, close... yeah"  
"Fufu, how adorable Hiroto-sama is."  
"Now, show me... your cumming face."

With the staff firmly gripping his lower body and Yuki/Maho hugging his waist, Yuu's eyes fluttered shut, chin lifting as his hips twitched. Experienced from multiple intercourses, Satsuki noticed his tension first.

After sucking his nipples, Satsuki and Hiromi supported Yuu's raised head and showered his face with kisses. As the director kneaded his testicles, Youko and Minami overlapped hands stroking from base to shaft, and Yuki/Maho licked and jerked the upper half, Yuu reached his limit.

"Ah, aah! Already... can't hold back, cumming! Guu!"  
"""Wawa!"""  
"Oho!"  
"""Kya!"""  
"My, my. Amazing, Yuu. So much again."  
"Fufu. As expected of Hiroto-sama."

Despite being his fourth ejaculation, the seven-woman stimulation proved overwhelming. Semen shot out powerfully. While the women reacted variously, the closest - Yuki and Maho - got splattered on their faces. Naturally, Youko, Minami, and the director licked the semen off their hands, savoring it happily.

***

### Author's Afterword

The latter half of Chapter 9 was planned to be non-erotic with serious elements, so I wanted passionate lovemaking beforehand. I reconsidered previously scrapped content and presented it as the Sex Education Video arc.

I wanted to write Yuki's follow-up story too, but since this grew long, I'll end here.

I hope to cover Yuki and Maho later, like with Wish duo or Tsutsui Takako, in an interlude or main story.

### Chapter Translation Notes
- Translated "ぎゅう" as "gyuu" (transliterated squeezing sound)
- Preserved Japanese honorifics (-sensei, -kun, -san)
- Translated explicit anatomical/sexual terms directly (e.g., チンポ→penis, 膣→vagina)
- Maintained Japanese name order (e.g., Kinjou Youko)
- Italicized internal monologue indicators (e.g., *thoughts* though none present)
- Transliterated sound effects (e.g., "zuchu" for ずちゅっ)
- Used standard dialogue quotes except simultaneous speech (none present)