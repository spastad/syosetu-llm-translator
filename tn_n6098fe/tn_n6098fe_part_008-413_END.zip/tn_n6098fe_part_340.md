## Interlude 12: The Taker and the Taken (Part 1)

### Author's Preface

This interlude continues from Interlude 11 from the perspective of Kate's mother, Jane.

I had hoped to complete interludes without the protagonist in a single chapter, but Interlude 12 connects to the main story and inevitably became lengthy. Thus, it has been divided into two parts.

---

Humans in this world are divided into two types.

Namely, the takers and the taken.

One must never become the taken. One must remain a taker for life.

That is my family's motto.

We are the Mason family - fallen nobles who lost political struggles in Great Britain, stripped of positions and territories, forced to flee abroad. After crossing to the New World, we seized wealth and land from indigenous people, continuing our plunder to rise as prominent figures in the United States. Truly fitting, since my brilliant sisters conspired against their foolish elder sister and exiled her, executing our family motto to perfection. Though they met an abrupt end in an aircraft accident.

After coming to New York, I joined a gang family and immersed myself in a world of blood and violence.

Killing people for the family or personal gain became trivial to me.

After all, the world is filled with countless scum whose deaths would benefit society. Though I couldn't deny I belonged among them.

During that time, I met Sakuya. He was a man who transcended the paradigm of taking and being taken - a giver. I felt he taught me about love. Not wanting that feeling to be mere illusion, I pursued him to Japan seeking more of this "love."

But even after arriving in Japan, meeting Sakuya proved unexpectedly difficult. As my frustration grew, I was stunned by sudden news of his death.

I wasn't alone in feeling as if the sun had fallen and the world ended. At the Tokyo funeral, countless despairing women among the crowd became self-destructive and violent. I got caught in the brawl.

Before I knew it, I was arrested. While confined in a detention cell, my pregnancy was discovered.

---

"Hey, have you ever raped a man?"

Detention cells were supposed to hold one person per room, but with so many arrested, two were crammed together. My cellmate was a woman named Terada. She told me it's written with the characters for 'temple' and 'field'.

Terada was 22, five years my senior. With black hair and eyes, she looked typically Japanese but had come to Japan about ten years prior with her Japanese-American mother. She carried an air of detachment.

Terada became invaluable as someone who could communicate with my broken Japanese and English.

Soon after entering detention, I developed morning sickness. Following the medical officer's advice, I got tested.

The positive result seemed to have spread quickly.

The day after my pregnancy was confirmed, Terada asked me that question.

When I answered "Yes," she raised the corner of her mouth with an intrigued expression.

Thus began my long association with Terada.

---

I was released after one week in detention.

With so many women jailed during the riot, only the most malicious or previously convicted remained incarcerated. Others were released after statements and warnings.

My American citizenship probably made them avoid complications.

But upon release, I found myself at a loss with nowhere to go.

I couldn't return to my homeland now.

With fake identification, I couldn't rely on the embassy.

Terada approached me in this state.

She had infiltrated a mansion likely housing men with accomplices during the chaos. Though caught, she never revealed her true intent. Charged with illegal trespassing for burglary, she avoided prosecution - partly because post-Sakuya crime rates surged beyond prosecutorial capacity.

Terada had connections to Japanese gangs - yakuza or bōryokudan - and engaged in various illegal activities while skillfully avoiding criminal records.

Bored in detention, I'd honestly shared my past exploits (omitting most about Sakuya). She recruited me based on that experience.

In safe Japan, those who could kill without hesitation were rare.

Moreover, women who became pregnant through sex with men held higher status than those paying for artificial insemination.

To Terada and her associates, women like me who raped men and conceived deserved respect. In other words, we were takers.

Thus, I joined Terada's organization with surprisingly favorable terms.

---

Being pregnant, I spent nearly the first year focused on "training" - learning Japanese and Japanese customs.

Morning sickness brought awful feelings, but after that phase passed, I stabilized. The huge protruding belly made movement difficult.

When the baby finally emerged after unprecedented pain, I felt immense relief.

The newborn seemed tiny and helpless like a monkey, but gradually grew into a girl inheriting parental features.

Naming felt bothersome, but since J (Jane) came first, I named her K (Kate).

---

From loan-sharking to counterfeit goods, hypnotic sales tactics, psychic scams, rigged gambling, and pyramid schemes - every fraud imaginable. Particularly successful were dating scams and marriage frauds using crossdressing women.

With Terada, I worked in seemingly ordinary companies engaged in swindling money from people.

The world has no easy money. Without talent or effort, no scheme brings effortless wealth. Yet countless fools bite at "guaranteed profits." Thus, the scammed deserve it.

I'd done similar work in New York, but Terada's group was thorough.

Operating at the edge of legality - or crossing it without concern.

Swindling money from greedy people, always positioning ourselves as takers. I became obsessed with this work.

Of course, some victims grew angry and fought back upon realizing they'd been tricked. Some hired lawyers to sue.

We skillfully dissolved companies and relocated when police attention grew, but some proved persistent.

Then we'd use any means necessary to break them.

Alternating harassment and threats until they surrendered.

Beating them half to death usually made them cower and beg for mercy.

When unavoidable, we kidnapped, killed, encased them in concrete, and sank them offshore - never discovered.

Such operations usually had backers, often yakuza. In exchange for tribute payments, they handled situations beyond our capacity.

The political group backing Terada and my corporate group was an anti-establishment faction - a radical political organization disguised as civic activism, merciless toward opponents.

I heard the pyramid's apex was the Dankyo Party.

A party for women, by women, with slogans about managing and sharing men, aiming to establish a complete female-dominant society.

Politics confused me, but I knew politicians worldwide spout pretty words publicly while being utterly corrupt privately.

Only power mattered to me. Powerless complainers were just losers howling at the moon.

Thus, fifteen years passed in what felt like my calling.

---

"I've completed Saiei Academy's enrollment procedures. You'll attend starting April."

"Understood, Mother."

My daughter Kate nodded with expressionless compliance.

Though not matching my height, she resembled my younger self perfectly.

Thanks to oppressive, thoroughly controlled parenting since birth, Kate never talked back.

This followed the Mason family's generational education principles I'd experienced.

In the Mason family, the head was absolute. Even blood relatives weren't permitted selfishness or backtalk.

As heir, I received strict education from early childhood. Enduring it felt possible believing my mother's attitude held expectations for her successor.

But only until about age seven.

My younger sisters began showing abnormal genius from infancy.

Mother's attention shifted completely to them, ignoring me despite my above-average achievements.

Maintaining Mason-family-worthy grades became my sole requirement.

Any lapse brought harsh scolding - sometimes whippings - not from Mother, but tutors under her orders.

Treated not as family but as a tool for the Masons.

Days spent suppressing emotions. The thread of hope that Mother would someday acknowledge me snapped when I was exiled.

Ultimately, I raised my daughter the same way.

Single mother, single child. Controlling a young child's basic needs made enforcing absolute obedience easy.

Raised strictly from infancy, sometimes beaten, taught that Mother's word was absolute.

As she grew, martial arts dojos with strict etiquette prevented rebellious tendencies.

Kate had good athleticism, so I had her learn kickboxing and other martial arts. Her grades stayed high - she could have aimed for better schools.

But Saiei Academy after junior high was predetermined.

Recently, Saiei Academy came under influence from Dankyo Party affiliates. Members' children enrolled and controlled the student council. Graduates increasingly became party supporters.

Enrolling her through recommendation was easy.

Kate never complained about this imposed path.

---

"Arrangements are made for you to join Saiei's student council. Become the student council president's hands and feet. Understood?"

"Yes. As Mother wishes."

Satisfied with the expected response, I nodded dismissively.

Kate bowed at a 45-degree angle and left.

About a month later, she seemed like a different person.

---

The previous day, she'd participated in a goodwill match at the gym. After taking a hard hit, she slipped and struck her head, suffering a concussion. The maid I hired since work often kept me away reported she'd been hospitalized but was fine.

"Where... is this? Um... who?"

One morning as I read the newspaper during breakfast in the living room, Kate emerged from her room in disheveled pajamas and bedhead, addressing me first.

I felt blood rush to my head.

What nonsense was this?

Had the head injury caused amnesia?

Other families might differ, but mine required proper grooming before greeting me each morning. Naturally, children initiated greetings.

I slammed my half-finished coffee cup down violently. Liquid splashed, staining the white tablecloth brown, but that didn't matter.

*Pan!*

Approaching Kate frozen in the doorway, I slapped her cheek.

Holding her reddened cheek, she stared back blankly.

Her expression showed no understanding of why she'd been hit.

Then I'd continue until she remembered.

I slapped the other cheek.

"Guh... wh-what are you doing?! What's wrong with you?!"

Kate's swollen cheeks framed eyes burning with anger - unprecedented emotion that surprised me.

Back in her first junior high summer vacation.

I'd enrolled her in a strict private school where rebellious types inevitably appeared. Kate was influenced and temporarily stopped obeying me.

Furious, I locked her in the storage shed without meals.

I also complained to the school.

After several repetitions, Kate lost the will to resist, and the problematic student was expelled for misconduct.

Since then, she'd seemed completely submissive... until now.

*Pashin!*

My cheek burned.

Seconds passed before I realized Kate had slapped me back.

Rage flared like fire.

Like being bitten by my own dog.

Long overdue for thorough discipline.

This time I swung a fist instead of an open palm, but she dodged.

Instinctively lowering my stance, I threw a one-two combo.

Kate tried dodging but it grazed her shoulder. Then - *thud* - a counter hit me. Blood dripped from my nose.

Strangely, the attacker looked shocked, as if her body moved independently.

Seizing her frozen moment, I landed a body blow. The weight-driven punch connected with her stomach.

Kate folded like a hinge and flew backward.

She collapsed in the hallway beyond the door, but fierce fighting spirit burned in her eyes.

Seeing this stirred my blood.

The maid hanging laundry upstairs rushed over at the commotion. Gesturing "get out" silenced her.

I advanced on the rising Kate to reeducate her.  


### Chapter Translation Notes
- Translated "落魄貴族" as "fallen nobles" to convey loss of status
- Translated "悪阻" as "morning sickness" for medical accuracy
- Preserved Japanese criminal terms like "ヤクザ" as "yakuza" and "暴力団" as "bōryokudan"
- Translated "デート商法" as "dating scams" and "結婚詐欺" as "marriage fraud" for clarity
- Transliterated sound effects: "パン" → "Pan", "パシン" → "Pashin"
- Maintained Japanese name order for Terada (寺田) without adding given name since not provided
- Translated "男共党" as "Dankyo Party" per Fixed Reference
- Used "Saiei Academy" consistently per Fixed Reference spelling
- Preserved honorifics: "お母様" → "Mother" with capitalization indicating respect