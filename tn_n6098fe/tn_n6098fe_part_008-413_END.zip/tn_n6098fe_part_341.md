## Interlude 12: The Taker and the Taken (Part 2)

### Author's Preface

I kept adding and rewriting until the last minute before posting, especially for the important latter half.

As a result, it grew by over 2000 characters compared to the first draft.

---

The first major fight with my daughter who dared to defy me.

After hurling insults, punching, grappling, and kicking each other, my daughter's pajamas were torn to shreds revealing her underwear, her hair was disheveled, and blood dripped from her mouth - probably from a cut inside.

Likely, I was in a similar state.

When I touched my throbbing jaw, blood came away thickly - perhaps cut by flying glass shards.

My left arm wouldn't lift, and my side throbbed with pain.

Before I knew it, the living and dining rooms looked like a typhoon had swept through.

"Don't you understand you should obey your parents!?"

"You call yourself a parent? Ha! Pathetic. Forcing obedience through violence isn't parenting!"

"Who do you think puts food on the table!?"

"What is this!? Some Showa-era dad crap!?"

We argued midway, but it was hopeless.

My daughter seemed like a different person, spouting incomprehensible words.

I don't know how much time passed, but pitifully, my legs gave out and I collapsed on the floor.

Glaring at me, my daughter leaned against the hole-riddled door.

Though I had the advantage in strength and experience, her youth gave her superior stamina.

Initially defensive, she gradually overpowered me.

I never imagined the fists meant to be my pawns against enemies would turn against me.

Eventually, my daughter turned her back and walked out.

What happened to her? Did those lunatics brainwash her?

According to the housekeeper, she'd shown no signs of change.

We crossed paths a few times afterward, but her attitude remained unchanged.

Even her expressions were completely different, openly showing disgust.

Provocations didn't elicit reactions - just contemptuous stares that infuriated me more.

It was as if a stranger inhabited her body, and her retorts sounded unnaturally mature.

Though attending Saiei Academy as planned, she rarely came straight home, wandering somewhere instead, so we hardly met.

The cold war continued.

I was extremely busy then, with no time to deal with my daughter.

After repeatedly shutting down and restarting companies, the operation grew larger with more people.

Before I knew it, I held an executive position with many subordinates.

I became a nominal director of shell companies and was dispatched to oversee other organizations.

"Jane, you're ruthless and merciless, yet somehow give off this well-bred air."

Terada and other long-time associates often said this.

Though I entered the gang world young, steeped in blood and violence, committing every crime - perhaps because I was raised in a prestigious household until 15.

I'd been hauled in for voluntary questioning by police several times, but my composure seemed to unsettle them.

I was never indicted.

After coming to Japan chasing Sakuya and losing my purpose, I'd fully adapted to Japan's underworld.

But this was just survival - my heart remained frozen. I never felt that burning passion since meeting Sakuya.

"Based on multiple sources, we've confirmed the foundation holds seasonal overnight networking events."

"Hosted by males connected to Toyoda Sakuya - meaning his sons - entertaining numerous women. Invitees include bureaucrats, corporate executives, and government officials including lawmakers. They likely hold all-night debaucherous banquets to secure foundation support."

"Wh-what did you say!?"

"Jealou- *ahem*. Out-outrageous!"

"I hear the foundation secretly receives massive government subsidies and corporate support. Using taxpayers' money for women to monopolize men... This is unforgivable!"

The fools chirped like birds before me.

We were in a rundown mixed-use building on Tokyo's outskirts.

Though calling themselves the "Rescue Women Military Council," they were extremist, uncooperative radicals - just one fringe far-left group.

Book-smart enough for elite universities but socially inept, uniformly narrow-minded fools who'd charge blindly at obvious enemies.

Cannon fodder at the bottom of the anti-establishment pyramid topped by the Dankyo Party.

They staged government protests, supported state-enterprise strikes, spread disinformation, and attacked government collaborators. They obstructed all government actions through legal and illegal means.

Naturally, police surveillance was intense, with many arrests.

Membership had halved since their peak. Higher-ups judged it time for one last spectacle before dissolution.

As liaison, I attended this meeting of their executives.

The chairwoman and others couldn't defy "DK" (Dankyo Party) directives and relied on funding from "The Company" - my organization.

They probably thought they were having serious discussions, but I couldn't help but scoff.

All this "for the people," "justice," and "noble cause" posturing was just envy-driven. They imagined state and corporate elites living lavishly, fueling their rage.

Some country's tale: a woman who read too many chivalric romances mistook windmills for giants and attacked them.

These fools imagined fighting giants but only committed petty crimes and public nuisances.

Yet they genuinely believed they were reforming society - hopeless.

The fools planned to infiltrate the foundation's networking venue as their next operation.

Toyoda Sakuya Memorial Foundation - reportedly run by Sakuya's wives, lovers, and children.

They received Sakuya's boundless love. For women like me who never got that chance, they were enviable.

Whether they hid major secrets as rumored was unclear, but the foundation had government and corporate connections.

We might uncover a scandal or two.

Stealing and destroying what they cherished would be fun too.

Damaging the government before elections was priority. Worth it even if this group got destroyed. Replacements were plentiful.

The chairwoman had final say, but couldn't ignore my input as liaison.

I gave the green light but warned them not to confuse means with ends.

I'd need to clean safehouses and erase organizational traces.

The operation commenced late August 25-26.

Fools but thorough, their infiltration succeeded.

Later, an excited call claimed: "We've captured a boy holding the foundation's secrets!" But contact ceased afterward.

Seems the sex-crazed chimps screwed up.

That night, I was meeting Terada and other executives at a Tokyo hotel and stayed over.

Next morning, police raided multiple safehouses - a complete surprise.

The chairwoman escaped by chance, but executives used underlings as decoys.

Worse, police moved too fast to destroy sensitive documents.

We used code words and avoided evidence, but with this sloppy group, raids could expose our connections.

We went underground.

Worst outcome. Police investigation was thorough.

Beyond the Council, many affiliated sites were raided. Arrests snowballed to Dankyo Party offices.

The kidnapping was just a trigger - they'd been investigating for months.

Fugitive Council executives and financiers like Terada and I became wanted.

I lost everything and went deep underground.

With two trusted longtime associates, I fled Tokyo immediately.

As Terada said - we sank or swam together.

We drifted through Nagano, Niigata, Toyama, and Gifu prefectures - avoiding cities for mountains.

I'd prepared foreign bank accounts and hidden valuables for such times.

Our organization had dealt with Asian crime groups entering Japan. Though costly, their police intel proved invaluable.

My appearance stood out, so I chopped my long blonde hair, dyed it common brown, and wore sunglasses constantly. I had fake IDs.

By late November, we were in the mountains bordering Gunma and Niigata. Leaves that had blazed red a week earlier now lay fallen, with early snow starting.

Near ski resorts, this scenic area was developed for villas but sold poorly due to bad access.

The sole management office stood derelict. We hid there.

The land was under an unrelated Chinese national's name - untraceable. The surface was ruined, but we'd renovated the basement into a hideout.

"Did she spill everything?"

"Yeah, the drugs worked. Got what we needed."

"Hah. Impressive."

I spoke flatly as Terada grinned defiantly.

Moments earlier, I'd interrogated a woman with Sawaguchi.

This woman was in the Council's S Squad - intelligence.

I forgot her name, but comrades called her "Nozokiya" (Peeping Tom).

Unremarkable appearance, barely noticeable. Loved peeping more than anything - could stake out locations for days.

Her S Squad work was unglamorous but effective. But her real role was our plant.

On August 25 evening, after monitoring the foundation, operatives were to send her to a Saitama safehouse.

We planned to report separately from Council HQ.

But she vanished.

Reports showed she wasn't arrested.

This month, we found her hiding in one of our safehouses, captured her, and brought her here.

Council executives remained at large in Kanto, contacting the chairwoman monthly.

Combining a Kanto executive's eavesdropped intel, our investigations, and Nozokiya's confession plus her notes, we grasped the situation.

I tossed several magazines before Terada and Sawaguchi. Some covers were frayed, but crucial pages remained intact.

They showed a boy with a cool smile.

"Whoo! Cute kid!"

"Don't you know? That's Hirose Yuu-kun!"

Information was scarce during our fugitive life.

Terada didn't recognize him, but Sawaguchi did. When Nozokiya mentioned the name during interrogation, she was shocked.

"Right. The operatives kidnapped then gang-raped him for fun... Then got caught sleeping it off. Idiots."

I'd authorized kidnapping any man found while exposing foundation secrets.

But upon randomly encountering a beautiful boy, the operatives got excited, took him, and had their fun.

Nozokiya didn't participate but watched everything.

After everyone slept, she confessed to spreading her legs beside the sleeping boy and masturbating.

Too scared to touch him, she lost herself in masturbation before sneaking out at dawn.

Thus, she escaped capture.

The problem was her vanishing without reporting. We made her pay - didn't kill her, just left her tied on the concrete floor.

She wouldn't survive after we left.

The boy was Hirose Yuu. Magazine articles called him Sairei Academy's first male student council president in a co-ed school.

Moreover, he was dating my daughter Kate and the Komatsu Group heiress.

I hadn't looked closely during interrogation, but I picked up Yuu's photos.

In them, Yuu smiled at me.

I rubbed my eyes, thinking I hallucinated.

Then stared holes into the photos.

"Rare to see you so obsessed. Well, it's Hirose-kun. I get it."

"Jane's a woman too - she's raped men before. Wants to strip this young boy naked and make him squeal, right?"

"Ah, no, this is..."

Living in Japan, I'd met men - mostly middle-aged - but felt nothing.

Why did Yuu's photo look like Sakuya?

Simultaneously, emotion surged burning in my chest.

I wanted to meet the real Hirose Yuu.

Not since meeting Sakuya.

"Speaking of which, Nozokiya said something strange."

"What?"

"About that night at the safehouse. Hirose-kun initiated sex with the women. Ended up fucking everyone there..."

"Huh? Bullshit."

"But she always tells the truth about what she sees."

"True. Didn't seem like drug-induced rambling."

All three tilted their heads pensively.

If kidnapped and fearing death, crying and submitting made sense - like men I'd raped.

Never heard of a man initiating sex. Did he snap?

As Terada said, "This isn't porn" - real men were nervous and weak.

"If true, it might explain something I wondered about."

Terada muttered while holding magazines.

At my and Sawaguchi's quizzical looks, she continued.

"Normally, what happens to men kidnapped and gang-raped by multiple women?"

"They get severe trauma, hospitalized... Ah!"

"See? This boy calmly attended school afterward, even became student council president. Not just a figurehead - active."

"Unbelievable."

"Kidnapped and fucked by multiple women without psychological shock. Meaning Nozokiya was right - he's a willing stud... Did one really exist?"

Yes. No such man existed today.

But I knew one existed in the past.

When learning Japanese, I'd devoured newspapers, magazines, and books.

His name was Sakuya Toyoda.

I reread Yuu's magazine profiles, Nozokiya's notes - she'd stubbornly spied on Sairei Academy despite guards - and gathered intel.

Terada and Sawaguchi smiled wryly and left me to it.

Yuu was born about six months after Sakuya's death.

Little information existed before high school.

But he gained attention upon entering high school.

His behavior made him the school idol.

He unusually joined student council as a first-year male, got engaged to three girls including Komatsu's heiress.

Beyond fiancées, girls close to Yuu got pregnant one after another.

He ran for student council president second semester. Everyone welcomed him. He excelled at sports and culture festivals, growing more popular.

Meanwhile, he had strong ties to the Toyoda Sakuya Memorial Foundation and was close with Sakuya's wives and children.

Tracing Yuu's path, an idea emerged.

Was Hirose Yuu Sakuya reincarnated?

Sakuya died younger than I am now. Could his lingering spirit have entered some woman's womb and awakened?

A passing thought, but it stuck.

Nominally Protestant, I barely believed in God.

Spirits and miracles belonged in movies.

Yet I'd seen my daughter Kate change overnight into someone else.

Medically, dissociative identity disorder.

But having watched her since birth, only a soul replacement made sense.

I looked at notes from a fugitive Council executive who'd eavesdropped.

Scrawled words: "Yuu," "Kate," "reincarnation."

Meaning both confessed to reincarnation?

I clenched the notes. Joy surged from my core.

If dead Sakuya was reborn as Yuu, I must thank God deeply.

After three days pondering post-interrogation, I told my associates.

"Hirose Yuu seems treated as a key male figure in this country."

"Let's plan to take him hostage for our escape."

"Hmm."

"Heehee."

At my serious tone, Terada and Sawaguchi smirked.

Rare for me to obsess over a boy.

Sawaguchi didn't hide her delight.

I cleared my throat and continued.

"First... mobilize those fools."

"Fools... meaning the Council executives?"

"Yes. Use them as decoys. Doesn't matter if all get caught if they distract police."

"Their blunder caused this mess. Let them go out with a bang."

We nodded.

We funded them not out of sympathy, but usefulness. They needed to earn it.

"But kidnapping him alone will be tough. Especially Hirose-kun."

Sawaguchi was right.

Only three executives remained from our company. We had underlings hiding regionally, but under ten total.

Contacting uncaptured associates risked police surveillance.

A direct assault on Yuu with his guards was impossible.

"Reluctantly, we must ask... those foreign associates."

"Them? They have weapons and numbers but... hard to control. Might exploit our weakness."

"We'll manage."

I persuaded the frowning Terada and Sawaguchi.

For Sakuya... no, for Yuu, I'd shake hands with the devil.

Whatever hardships awaited, I'd overcome them.

### Chapter Translation Notes
- Translated "覗き屋" as "Nozokiya" (Peeping Tom) as a transliterated nickname since no real name was provided
- Preserved Japanese organizational names like "救女軍事会議" as "Rescue Women Military Council" per Fixed Terms
- Translated "輪姦(マワ)" as "gang-raped" to maintain explicit terminology requirement
- Rendered internal thoughts like "サクヤとして生まれ変わった" as "*reborn as Sakuya*" in italics
- Kept honorific "-kun" in "Hirose Yuu-kun" as per translation style rules
- Maintained original name order "Hirose Yuu" throughout