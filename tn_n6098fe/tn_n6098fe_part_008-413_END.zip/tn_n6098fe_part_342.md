## 320. The End of Obsession ① ~I'll Wait~

### Author's Preface

The subtitle feels somewhat ominous, but part ① has a warm and fuzzy? content.

---

"Are you really going to be okay?"

"Fufu. You're such a worrywart, Yuu-kun. I'll be fine. No problem."

"But unlike driving within the city, it's a long journey, right? Naturally I'd be worried."

"Mm. That's why I plan to take proper breaks without pushing myself."

This was the parking lot of Sayaka's condominium.

Having retired from the student council and secured their future paths, Sayaka and Riko promptly decided to get their driver's licenses. However, they didn't attend a driving school. The Komatsu family owned their own spacious practice ground. Furthermore, they employed retired police officers and driving instructors to regularly hold practical driving lessons and traffic safety classes for those who hadn't driven in a while. Sayaka and Riko attended these sessions about twice a week for both practical and written exam preparation. Then in early November, they took the test at a license center in Saitama Prefecture and passed on their first attempt.

Yuu was surprised, having assumed one needed to attend driving school to get a license. Though in this world too, people normally attend driving schools, cases like Sayaka's—smoothly passing by leveraging privileged circumstances—were apparently special. The fact that her grandmother casually gifted her a brand-new sedan as a celebration present was truly impressive.

Sayaka's dream was to take Yuu on a drive with him in the passenger seat, but that wouldn't be easily realized. Young men generally ride in the back seat with smoked-glass windows, accompanied by protection officers. Still, Yuu wanted to make that dream come true for her someday.

With their due dates just over a month away, the bellies of all three were noticeably swollen enough to clearly identify them as pregnant. From a male perspective, Yuu wanted them to take it easy and rest. But pregnant women, perhaps due to maternal instincts, were surprisingly strong-willed. Especially Sayaka, who had suffered severe morning sickness for a long period and couldn't move much, and being naturally active, seemed unable to stay still. She had become proactive about using the car for regular prenatal checkups and shopping.

January 6th (Sunday) was Kate's moving day. After leaving home, Kate had been living in a rundown mixed-use building that served as her team's hangout, but it was scheduled for demolition since most tenants had already left. They had to vacate by the end of December. Enrollment procedures for the night high school in Matsumoto City and the nearby apartment had been completed last December. However, her prospective employer expressed reluctance because she was a relative of a still-wanted fugitive. So, the foundation Yuu had requested help from urgently arranged employment connections, but it got pushed to the new year.

Kate's belongings in the weekly apartment weren't excessive—a single light truck could easily handle them. She apparently hadn't planned to hire movers, but the issue was transportation. Kate tried asking OG members through Ryoko, but those with licenses had work commitments and couldn't make it. Hearing about this situation, Sayaka volunteered as the driver. Unbeknownst to Yuu, Sayaka had been deepening her friendship with Kate. Naturally, Kate wanted to refuse since she didn't want to burden the pregnant Sayaka. But Sayaka insisted it was fine. Only at the last minute did she confess that she wanted to hear about Yuu from before his reincarnation from Kate.

Last early November. Only a limited number of people knew the secret Yuu and Kate shared, revealed at a park on the outskirts of Saito City. (Excluding foundation directors) Only their fiancées Sayaka, Riko, and Emi, plus Ryoko who was present. Tight-lipped Ryoko hadn't even told her own team members. So during the trip with just the three of them, it would be convenient to talk.

Sayaka's beloved car was a Komatsu Award, a 5-seater sedan. The Award could be considered a standard mid-class sedan in Komatsu's lineup. Fifteen years since the first generation debuted, the fourth generation released just last year stood before them. Having been delivered about a month prior, its white body gleamed spotlessly. She clearly drove carefully and cherished it—not a single scratch. With each generation, the style evolved with the times into sharper forms. Even as someone who lived in the 21st century, Yuu found 1990s car designs cool. He had been wanting to ride with her once her beginner's mark came off.

Sayaka would drive her car to Saito Station, rent a minivan from a Komatsu-affiliated rental shop, and drive everyone to the new place. All Red Scorpions members including the pregnant Misa and Mari would be there, but as mentioned earlier, only Ryoko would accompany them to the new home. They'd help unpack, return the car to a local branch, and return by train. A day trip was possible, but since they wouldn't be able to meet casually anymore, they planned to stay overnight and talk until dawn. Yuu felt more at ease with that plan.

"Well then, I'm off."  
"Really, please be careful."  
"Yuu-kun……"

Yuu embraced Sayaka diagonally from the side to avoid pressing on her belly, pulling her close by the shoulders. Her long black hair was tied back to avoid getting in the way. As he stroked from her exposed nape to her cheek with his hand, Sayaka smiled happily. He brought his face closer for a kiss. Even surrounded by Kanako and the other protection officers, Riko, and Emi—and despite being in a public outdoor space—Yuu was savoring this brief farewell with Sayaka.

During summer break, they'd sometimes gone a week without meeting, and after the student council transition, opportunities to meet at school decreased. But in return, Yuu stayed over at the condominium and spent time with her. Though the frequency of sexual intercourse decreased as her belly grew, physical affection remained unchanged. They naturally exuded a sweet, newlywed-like atmosphere. That's why, even for just one night, Yuu felt loneliness and a hint of unease about Sayaka going somewhere distant. For Sayaka too, being touched by Yuu filled her chest with warmth from joy and reassurance. Their kiss wasn't intense but long, filled with mutual affection. After ending it with a smile, Sayaka exchanged hugs with Riko and Emi. She even bowed to Kanako and the others, entrusting Yuu to them—already showing signs of a wife's awareness.

"It's cold, so let's head inside."  
"Kanako-san, won't you join us for tea?"  
"Well……"

After seeing off Sayaka's car leaving the parking lot, they returned to the room. Having visited frequently, the protection officers had grown close to the three and sometimes visited the apartment. But knowing their place as protection officers, they didn't get overly familiar. With a word from Yuu, Kanako and the others accepted the invitation.

After enjoying tea and chatting for a while, the four protection officers went home. Yuu had spent last night at his own home but planned to stay at Sayaka's condominium tonight. Even with Riko and Emi there, Sayaka held such a significant place in Yuu's heart that the apartment felt hollow without its owner. Emi broke the subtle atmosphere.

"Hey, Yuu-kun, will you help us think of names for the babies?"  
"Sure, but isn't it a bit early?"  
"Not at all. Once we reach full term, we might not have the calm to think about names."  
"O-oh, right. Women have it tough."

Yuu nodded while looking at their large bellies. Among the three, Emi's belly had grown relatively slowly, but now she too had a proper pregnant belly. He thought deciding names right before the due date would be fine, but after all, all three were experiencing their first pregnancy. They might experience abdominal tightening, and premature birth was possible. Once hospitalized, they might not have time to think about names.

"I wonder if they'll be girls or boys. I'm looking forward to it."  
"All three are likely girls though."  
"It'd be nice if at least one was a boy."

Sandwiched between Riko and Emi on the sofa, Yuu gently stroked their bellies while conversing. The gender ratio was 1:30—no, the ratio of newborns was slightly wider now. The probability of girls being born was overwhelmingly high. Sakuya's lineage apparently had a higher-than-average chance of producing boys. How many boys would be born from women impregnated by Yuu was being watched by parts of the Ministry of Health, Labour and Welfare and the foundation. Regardless of gender, these would be Yuu's first children. He would undoubtedly cherish them.

"Ultimately, we won't know the gender until they're born."  
"True. Though I kind of want to know soon..."  
"It's the rule."

Once the fetus grows and organs develop to a certain stage, the gender should be identifiable via ultrasound. However, in this world where boys are precious, there seemed to be complex reasons—artificial insemination rarely produced boys. Natural pregnancy had about a 1 in 30 chance of resulting in a boy. Pregnant women who learned they were carrying boys were overjoyed, while others felt envy or jealousy—a natural psychological reaction. Feeling that way was one thing, but women around childbirth tended to be emotionally unstable, and some acted on negative feelings. When genders were revealed in advance, troubles erupted nationwide, so ultrasound examinations were no longer performed. If the baby was a girl at birth, they'd be moved to a shared newborn room, but boys and their mothers were moved to strictly guarded private rooms until discharge.

"Anyway, I've been thinking of girl name candidates."  
"I'd be happy if you helped think of boy names with us, Yuu-kun. Is that okay?"  
"Of course!"  
"Yay!"  
"That's good. I heard young men often find children bothersome."

Emi stood up and brought naming books from the bookshelf. Purchased three days prior, they had apparently been passed around and read multiple times, with colorful sticky notes marking many pages.

There were households where multiple wives earned income while husbands took the lead in housework and childcare. But just as with housework, a certain percentage of men were bad at childcare. In financially comfortable families, husbands might hire housekeepers and leave childcare entirely to nursery staff. After impregnating their wives, they'd become idle. This was common. Especially when young, men didn't want to participate in childrearing—they wanted to live freely. In extreme terms, young men's role in this world was sperm donation.

"Sayaka, Riko, Emi—and the current student council and Class 5 girls too. Women go through long pregnancies and endure hardship to give birth. No matter who gives birth, they're all my precious children. I consider naming them a father's responsibility too."  
"Mufufufu. I love that about you, Yuu-kun!"  
"Truly. I feel blessed to be carrying your child."

For Yuu, before being reborn, he had strongly desired his own child but it never happened. He felt gratitude toward Sayaka, Riko, and Emi who made it possible first. They were beautiful girls both in appearance and heart—more than he deserved. So he wanted to cherish them. He didn't hesitate to participate in childcare. Though he thought it was early for high school students, in this world where not only the individuals but also families, schools, and society welcomed it with full support systems, he had no worries.

Taking the twin-tail strands of Emi, who beamed with a bright smile, Yuu brought his face closer for a kiss. Though always bright, cheerful, and lovely, Emi now seemed more mature, perhaps due to developing maternal instincts.

After kissing for about a minute, he casually leaned toward Riko who had drawn near and kissed her too. Her once sharp impression had faded, replaced by a nurturing big-sister aura that made him want to cling to her.

After exchanging kisses for a while, Riko and Emi with slightly flushed cheeks returned to the topic. They opened a notebook handed to him. Things to buy for childbirth, health management precautions, nutrients to intake... etc. In this era without widespread internet, research meant reading books or asking experienced people. So this was a notebook for sharing information each had gathered during their first pregnancies.

The opened page had names written in hiragana. Over thirty names, with some marked ○, ◎, △ on the right.

Yui  
Yuika  
Yuimi  
Yuuka  
Yuuri  
Yuka  
Yukari  
Yukie  
Yumiri  
Yuri  
Yuria  
Yurika  
Miu  
Miyu  
Rika  
Rie  
・  
・  
・

"These... you thought of them all?"  
"Mm. First I listed whatever came to mind, then planned to assign kanji using the books as reference."  
"Many start with 'Yu'."  
"Well, obviously."

Of course, it was from Yuu's "Yu". Many girls' names started with "Yu", so they could probably list endlessly. Speaking of which, in Sayaka's family, names with "ka" (華) continued. Sayaka's grandmother was Reika, mother Tomoka, sister Kiyoka. He recalled hearing they followed the tradition of Hanako, who founded and developed the company. If Sayaka had a girl, following tradition, names like Yuka, Yuika, Yuuka, or Yurika seemed likely.

"Girl names can prioritize your three's preferences... but what about boy names?"  
"Hey hey, Yuu-kun. I thought of 'Yuutaro' or 'Yuuichiro', how about that?"  
"You'd both be 'Yuu-kun' then."  
"Not bad, but why not move away from 'Yu' starters? For example, making Emi's name masculine: Eikichi, Eiji, Eisuke, Eita, Eito, etc."  
"Ooh! They all sound cool!"

Having lived in a world with a near 1:1 gender ratio versus Riko and Emi in a 1:30 world, Yuu could recall boy names far more easily.

"Boy names are hard, so I'm glad you're helping us think, Yuu-kun."  
"Yuu-kun will have more and more children from now on, right? No loss in thinking of some candidates now."  
"Speaking of which, Nana-chan too."  
"And Sayori as well. Congratulations to the entire student council."

Following Mizuki, Yoshie, and Kiriko who got pregnant earlier, the first-year duo Nana and Sayori also revealed pregnancies after winter break began. Student council members had many opportunities for creampie sex, so this was natural. Yoshie, who got pregnant earlier despite being the same grade, accompanied them to the OB-GYN. Upon hearing the results, Nana jumped for joy while Sayori showed little emotion. But according to what Yoshie secretly heard, she couldn't stop making an eerie "mufumu" suppressed laugh. Apparently, she was overjoyed not only to be in the same position as her cousin Riko but also harbored ambitions to raise their children together like sisters.

At any rate, after Sayaka, Riko, and Emi reached their due dates in mid-February, Yuu's children would continue being born from March onward. However low the probability, boys might be born too. Thinking of names now wouldn't be wasted. Yuu pondered names and exchanged opinions while imagining the children to come. Yet even now, he remained concerned about Sayaka. Riko and Emi surely felt the same but didn't voice it. She should contact them upon arrival. For now, they could only wait.

### Chapter Translation Notes
- Translated "ほんわかした" as "warm and fuzzy" to capture the author's tentative description of the chapter's tone
- Preserved Japanese car model name "Komatsu Award" as per fictional branding conventions
- Translated "ペーパードライバー" as "those who hadn't driven in a while" to convey meaning beyond literal "paper driver"
- Rendered "むふふふ" as "Mufufufu" for consistent onomatopoeic laughter transliteration
- Maintained original name order (e.g., "Komatsu Sayaka") throughout as per style rules
- Translated "穀潰し" as "idle" to convey the societal perception of non-contributing males
- Preserved honorifics (-kun, -san) and relationship terms (e.g., "OG members") per fixed style