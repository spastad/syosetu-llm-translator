## 321. The End of Obsession ② ~Accident~

### Author's Preface

As written in the comments section, it's about time to include erotic content.

However, the development continues with non-erotic and serious elements.

But rest assured, I plan to include an erotic chapter where Yuu takes the lead, so please wait.

---

It was past 8:30 AM when we saw Sayaka off.

They rented a minivan to go to Kate's temporary residence, and since team members would help with packing, it shouldn't take too long.

Using the expressway with breaks, it would take about 3 hours to reach Matsumoto.

I expected Sayaka's call to come between 1:00 and 2:00 PM.

During the morning, we discussed preparations for childbirth - names for the coming baby, items to prepare, and such.

Around noon, just as we were about to start preparing lunch, the phone rang. Emi happened to be closest and answered.

"Yes. Hello... Huh? Wha? W-wait. What are you saying?"

Emi's expression turned strange as she held the receiver, so Yuu and Riko in the kitchen watched her closely.

A prank call? This apartment's number isn't listed in the phone book.

Besides the Komatsu, Hanmura, Ishikawa, and Hirose families, only some Sairei Academy staff, student council members, and trusted individuals should know it.

"What's wrong?"

Emi looked troubled and turned not to Riko but to Yuu.

"Ah! Yuu!? T-t-terrible! Wh-what should we do!?"  
"Um, is that Ryoko? What's terrible? Take a deep breath, calm down, then speak slowly."

The caller was Ryoko, who was supposed to accompany Kate to her new place. Her voice sounded hoarse and she gasped between words as if she'd been sprinting. Ryoko, usually calm except when Yuu was involved, was this flustered. A bad premonition flashed through Yuu's mind - had they been in a traffic accident?

"Y-yeah. I ran around and f-finally found a payphone. *Deep breath... deep breath...*"

While waiting for Ryoko to calm down, Yuu switched to speakerphone. His chest had been pounding uneasily since earlier. He needed to hear Ryoko's situation first.

"Where are you now, Ryoko?"  
"Location... um, where is this? Near Yokokawa Service Area... no, maybe a bit away. Just a phone booth I found near a park by chance."  
"Okay. And is anyone nearby? Sayaka? Kate?"  
"Ah! Right! It's terrible, Yuu! They've been kidnapped! Forced into a car!"  
"Huh..."

Yuu was speechless at this unexpected situation, exchanging looks with Riko and Emi. As Ryoko's voice threatened to break into tears, he gently coaxed her to explain everything in order.

After entering Joshinetsu Expressway from Kanetsu Expressway heading toward Nagano Prefecture, they stopped at Yokokawa Service Area for a break. It was slightly early for lunch, but Sayaka had suggested trying the "Kama Meshi" (pot-cooked rice), and both Kate and Ryoko agreed.

"That car's been tailing us for a while."

Sayaka had murmured this as they turned from the driving lane into the SA entrance. While other cars zoomed past, Sayaka maintained safe driving at under 100 km/h in the left lane. When she noticed, a black minivan (different color from their rental) had been following closely without passing - at least since they entered Joshinetsu Expressway from Fujioka Junction. It followed them into the SA but turned in a different direction in the parking lot, so they dismissed it as coincidence.

All three got out and used the restroom first. Being near noon on Sunday, the SA was moderately crowded. They bought Kama Meshi along with snacks and drinks. Though Kate and Ryoko had traveled outside the prefecture with their team, this was their first long trip with just the three of them, feeling like a mini-vacation. Until then.

As they approached their car, suspicious women suddenly surrounded them from behind parked vehicles. Sayaka aside, Kate and Ryoko were used to fights and immediately prepared to counterattack. But when a tall, sunglass-wearing woman who seemed like the leader approached Kate head-on and extended her right hand as if for a handshake - except she held a gun in it. Five others surrounded them, two more also holding guns.

*These aren't amateurs.* They had a yakuza-like aura. But why target us? As Ryoko wondered, the leader removed her sunglasses. She had ordinary brown short hair but distinctly foreign features - a Caucasian woman. She somewhat resembled Kate.

"Y-you're!?"

Kate cried out in surprise. The leader wordlessly closed in on Kate and threw a hook punch. Caught off guard, Kate's jaw dropped from the blow. Ryoko, thinking she must protect the pregnant Sayaka, instinctively moved to shield her. But women approached and forcibly escorted both Kate and Sayaka away, each held by both arms. With Kate and Sayaka as hostages, Ryoko had no choice but to follow. They were being forced into that black minivan parked farther away.

There, Ryoko hesitated greatly. Should she let herself be taken by this unidentified group? Fortunately, only one woman was guarding Ryoko at the rear.

Ahead of Ryoko, Kate regained consciousness and confronted the foreign leader. "What do you think you're doing? Stop this nonsense and turn yourself in to the police!" Ryoko heard her say sharply. But immediately, Kate was pinned from behind and slapped by the leader. "Stop!" shouted Sayaka. The commotion made some passersby stop. Flustered, the kidnappers pushed the two into the open van door. Seizing the distraction, Ryoko dashed away from the car like a fleeing rabbit.

It would've been easy to shout "Help!" here. But most people avoid trouble and wouldn't intervene - it might even backfire. Ryoko hadn't used an SA since childhood and doubted police were stationed there. She had to inform someone reliable about the kidnapping. With this resolve, she kept running. She noticed one kidnapper shouting and chasing her, but she'd already gained enough distance.

Eventually, Ryoko passed through crowded shops and restaurants, entered an employee entrance she spotted, and emerged behind the building before being stopped. The kidnappers' target was likely Kate and Sayaka - they wouldn't persistently chase her alone. She felt this intuition.

Climbing over a fence outside the premises, Ryoko hid behind trees while observing. She saw no suspicious figures - not even a single person. Confident she'd escaped, she noted her luck: the downhill side of the SA was near Yokokawa Town. Had it been the uphill side, there'd have been nothing but a golf course northeast, leaving her wandering mountains.

She had her wallet. But finding a payphone proved difficult, and after running around, she finally found one near a park.

"Damn it! Damn it! Why... why this..."  
"Yuu... Yuu! Sorry! I couldn't protect Sayaka... I just ran away alone..."  
"Ah... no, you did great, Ryoko. You desperately escaped and told us. Thank you..."

If it were Yuu - a young man - being kidnapped, it'd make sense. There had been past kidnappings of wealthy families' young daughters for ransom. But who could predict grown women being abducted in peaceful Japan?

Yuu never intended to blame Ryoko. If anything, he blamed himself - he should've stopped Sayaka more firmly. Regret overwhelmed him now. He realized his voice was trembling. A jumble of anxiety, regret, and anger boiled within him. His clenched fists hurt from nails digging into his palms.

"Yuu-kun."

Emi touched Yuu's fist and gently opened it. Seeing the tissue Emi pressed against his palm turn red, he noticed his skin was cut and bleeding. Meanwhile, Riko handled the phone call.

Ryoko would go to Yokokawa Police Station. They'd contact Sayaka's family. Given the Komatsu family founded Japan's leading auto/motorcycle manufacturer with her grandmother as current president, ransom was likely.

Thanks to Ryoko's information, they could inform the family before the kidnappers. Kate's only family was her mother Jane, still wanted with whereabouts unknown - some speculated she'd left Japan for America. But the foreign leader Ryoko saw resembled Kate despite different hair color - likely Jane. They weren't close; Yuu had heard about their conflict from Kate. Why take her? Because she's her mother?

They asked Ryoko to tell police about Jane's possible presence during her statement - it would change their response.

After hanging up, Yuu still couldn't control his emotions. Emi worriedly stayed close. Riko, appearing relatively calm - forcing composure - called Sayaka's family. According to Riko, Sayaka's mother Tomoka was surprised but remained composed throughout. She even politely thanked them and expressed concern for them. The Komatsu family would contact police to coordinate.

Kidnappings were only known from dramas and novels, where criminals threaten "No police or the hostage dies!" upon contact, leaving families panicked. Playing catch-up plays into kidnappers' hands. Thanks to Ryoko, they at least had mental preparation.

"What will you do now, Yuu-kun?"  
"Do? I'll stay as planned."  
"Shouldn't you be home at times like this?"  
"*Because* it's times like this, I think it's better to be together."  
"Yuu-kun... thank you. Honestly I was scared, so I'm glad."

The Komatsu family would contact the apartment if developments occurred. Yuu felt frustrated he couldn't do anything for Sayaka. Ryoko would come to the apartment after police questioning, however long it took. When Yuu answered that he'd wait with Riko and Emi praying for Sayaka's safe return, the gloomy-faced Emi finally smiled. But he noticed Riko's stern, pensive expression.

"Riko, what's wrong?"  
"Huh? Ah, um... just something bothering me..."

Riko removed her glasses as if concerned about smudges and wiped them with a handkerchief. Then she muttered with downcast eyes.

"I wonder what the kidnappers' goal is for taking Sayaka and Kate."  
"Um... to demand ransom from the Komatsu family? Probably Kate was just caught up in it, taken incidentally?"  
"That's possible. But"  
"But?"

Riko stared intently at Yuu before shaking her head.

"Never mind. It's nothing. Just unnecessary worry. Definitely."

Riko nodded as if convincing herself.

Though curious about Riko's unspoken thought, Yuu didn't press. He was desperately worried about Sayaka but could do nothing now. Everything depended on the Komatsu family and police. The anxious frustration wasn't his alone - Riko and Emi felt it too. To distract themselves, they resumed preparing the interrupted lunch.

When all you can do is wait, time feels slow. Still, to avoid negatively affecting the two pregnant women's mental state, Yuu tried to act normally.

That afternoon, breaking news interrupted the constantly-on TV. Bomb threats targeted multiple locations: Tokyo Metropolitan Government Building, Shinjuku Station, Toyoda Sakuya Memorial Foundation headquarters, etc. White smoke and strange odors actually emerged from Shinjuku Station restrooms.

Mid-broadcast, the Komatsu family called. Based on Ryoko's testimony, wanted criminals seemed allied, and the bomb threats likely aimed to distract police. The joint investigation team handling the "Rescue Women Military Council" extremist group would handle the case.

Investigators visited the Komatsu home to set up call tracing for the kidnappers' contact. But as dusk fell, no call had come.

Winter days end early. By 6:00 PM, complete darkness fell. Normally, dinner preparation would start. When staying over, Yuu always paired with someone to cook - usually Riko or Emi since they could handle most chores. Initially, cooking-inept Sayaka was exempt.

"I want to stand in the kitchen with Yuu-kun."

Honoring this wish, Yuu taught Sayaka basics like vegetable cutting and peeling while cooking together. When she succeeded at his teachings, she'd flash a bright smile. Finding her adorable, he'd hug and kiss her. Cooking while flirting with his beloved girl was joyful too.

Tonight, without Sayaka, Yuu felt hollow and couldn't bring himself to cook past 6:00 PM.

Then it happened.

The phone rang. The Komatsu family? Ryoko? Riko answered but looked strange. When she turned to Yuu, her face was pale.

"Yuu-kun... the kidnappers say they have Sayaka and Kate."  


### Chapter Translation Notes
- Translated "峠の釜めし" as "Kama Meshi (pot-cooked rice)" to preserve cultural specificity while providing explanation
- Translated "救女軍事会議" as "Rescue Women Military Council" per Fixed Reference Notes
- Preserved Japanese honorifics (-kun, -chan) and name order (Hirose Yuu, Komatsu Sayaka)
- Transliterated sound effects: "びゅんびゅん" → "byun byun" (cars speeding), "すーはー" → "deep breath" (breathing sounds)
- Italicized internal monologues: *(These aren't amateurs.)*
- Maintained explicit terminology: "拳銃" → "gun", "拉致" → "kidnapping"
- Used standard dialogue formatting with new paragraphs for each speaker
- Translated culturally specific terms: "公衆電話" → "payphone", "売店" → "shops"
- Preserved specialized terms: "SA" (Service Area), "Kama Meshi" (local specialty dish)