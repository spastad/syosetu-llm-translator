## 323. The End of Obsession ④ ~Is Sunday Good for a Drive?~

"No matter what difficulties we face, I'm sure you can overcome them. Because you always surprise us, Yuu-kun. Please take care of Sayaka."

"I believe in you, Yuu-kun. I'll be waiting for you to come back safely... so..."

At the parking lot of Saito Police Station, a large crowd gathered to see Yuu off as he departed.

First, Riko and Emi hugged Yuu.

Yuu smiled and spread his arms to embrace both of them at the same time.

Because they were pregnant, they were bundled up in thick coats to stay warm, but their cheeks felt cold to the touch.

Yuu turned left to look at Riko's face up close.

Riko was usually cool and composed, but now she couldn't hide her anxiety.

Yuu stared into her narrow eyes behind her glasses and put a little more strength into the hand on her back.

As if sensing Yuu's feelings, Riko nodded slightly, closed her eyes, and brought her lips closer.

Yuu tilted his face slightly and gave a light kiss to her slightly parted lips.

Next was Emi.

As usual, Yuu played with the ends of her twin tails in his hand. Her flaxen hair was smooth and pleasant to the touch.

Recently, it seemed that girls in the first and second years had started imitating Emi's twin tails.

They wanted Yuu to touch their hair too.

Emi tried to show a smile, but she couldn't hide her worry for Yuu. Her brown eyes wavered anxiously, becoming teary.

Yuu touched his forehead to hers and whispered.

"Show me your smile, Emi."

"Ah... okay!"

Yuu kissed the lips of Emi, who smiled with a *niko* sound.

Though brief for a farewell ritual, their hearts were connected.

As soon as Riko and Emi stepped back, Satsuki hugged Yuu tightly from behind.

"Yuu! I want to say don't go... but..."

Among Sakuya's children, she was the eldest.

Always bright, reliable, and embracing, Satsuki was the ideal older sister. She hugged Yuu tightly, her words trailing off.

Yuu silently patted Satsuki's hand.

Then he turned his body halfway around.

Satsuki's wavy long hair was fluffy and pleasant to the touch. As he slowly stroked it and turned her face toward him, she looked like she was about to cry.

Careful not to put pressure on her slightly swollen belly, Yuu whispered.

"Big sis, wait for me. I'll be back soon."  
"...! Yeah. Yuu, don't push yourself too hard."

Satsuki cradled her beloved brother's face and pressed her lips against his.

"Sakuya (that man) used to take quite reckless risks in the past too. But he always overcame them. Instead of making enemies of women, he made them allies. That's how he built his network.  
Yuu, my beloved son. Be like your late father... no, surpass him."  
"Yes. I can't afford to stumble here. I'll definitely accomplish this. Mother."

Finally, Yuu exchanged a hug with Haruka.

Even at such a time, Haruka maintained her dignified expression, but when Yuu called her "Mother," she smiled shyly, a mix of embarrassment and happiness, and patted Yuu's head.

"Sorry to keep you waiting."

Yuu bowed his head to the inspector from the Metropolitan Police Department's joint investigation team who had rushed over.

She was a woman in her mid-thirties who seemed like a typical career police officer—sharp and meticulous. Yuu had met her once before when he was questioned after the kidnapping incident.

Another woman, wearing strong prescription glasses and slightly plump, not looking much like a detective, probably in her late twenties. She was in charge of special equipment.

"Do you know how to use it?"  
"Yes. I was taught. It's being monitored properly, right?"  
"How is it?"  
"Abababa... y-yes! The position... oh, audio is b-b-bang on!"  
"Calm down."

At the police station, Yuu was fitted with small devices.

The small radio-like devices in his coat's inner pocket and shirt's chest pocket were dummies, anticipating they would be found and confiscated during a body search.

The real devices were elsewhere. The pendant around his neck looked like a teardrop-shaped locket but contained a listening device. The bracelet on his left wrist and the anklet on his left ankle transmitted location data. All were inconspicuous silver.

To receive the radio waves, they couldn't be too far away, so they were to ride in a dedicated large van that would follow behind.

In any case, he left the fitting to the young woman in charge, but she was so flustered that her hands shook—not only was it her first time approaching a young man, but it was also her first time touching a man's body. When Yuu soothed her by patting her head, she almost fainted, so he hurriedly caught her. Having Yuu's face suddenly so close caused her to roll her eyes.

In the end, Yuu fitted the devices himself while listening to instructions, but her face remained red the whole time as she was conscious of Yuu.

"To put a young man like you through such an ordeal and then send you to those people... I'm ashamed of my own inadequacy. On behalf of the police, I apologize to Hirose-kun."

Indeed, if the police had caught the wanted criminals sooner, this incident might not have happened.

But Yuu had no intention of blaming the police for what had already occurred. The ones to hate were the criminals who had kidnapped Sayaka and Kate.

"Please raise your head. If we can catch them all this time, that would be good, right?"  
"Ah. For that to happen..."  
"Yes. I need to relay the information properly."

How many people were there? Where were they? How many weapons did they have?

At the moment when Yuu, Sayaka, and Kate's safety was secured by the accompanying protection officers, the special forces would storm in.

It seemed like a difficult situation, but depending on Yuu's actions, they might be able to arrest Jane and the others without letting them escape. It was an attempt to turn the crisis into an opportunity.

---

At Kamisato Service Area on the Kanetsu Expressway. The phone instructions had directed them to the restroom—the men's restroom, which for crime prevention was independently located adjacent to the building with shops and restaurants, one for each facility. Usually, at a service area, "restroom" meant only the women's—specifically, the innermost stall. A note with new instructions was supposedly taped behind the pipes.

Yuu stayed in the car while he had the protection officer Iruma Miyo go check.

'Take the Kanetsu Expressway toward Gunma and get off at Akagi Kogen Service Area. The next instructions will be in the restroom there, same as here.'

Immediately, the contents were relayed to the unmarked police car via the radio installed in their car.

Several cars should have been following Yuu's car from behind, switching positions, and the local police station would have been contacted too.

At least it was clear they were heading toward Gunma or Niigata, not Nagano.

The expressway at night was empty.

About 90% of the vehicles were trucks.

Yuu thought that the distribution network in Japan was supported by truck drivers who traveled long distances day and night.

Except for occasionally passing slow trucks, they maintained a speed of 100 km/h in the left lane.

The driving of the veteran protection officer Oosato Yoriko, who often doubled as the driver, was stable. Yuu, in the back seat, was getting sleepy.

Around the time the date changed, they seemed to have entered Gunma Prefecture.

Yuu's hometown was in southern Gunma Prefecture. A small town bordering the Tone River.

It had been absorbed by a neighboring city during the Heisei-era mergers.

After being reborn in this world, he checked and found that it had been merged in the same way around the end of the 1980s.

It was a world that seemed similar but was completely different.

The house where Yuu was born, his parents, and his male friends from junior high and high school probably didn't exist.

Still, perhaps because it was his first time coming to Gunma Prefecture since being reborn, he suddenly felt nostalgic. He wanted to know if the town's scenery was as he remembered.

"Hey, after this case is resolved... I want to come to Gunma again during the holidays."  
"Eh?"

Kanako and the other protection officers riding with him were all surprised.

They had assumed Yuu was silent because, despite having set out, his anxiety was growing.

But Yuu's voice was perfectly calm.

"I want to see Mount Akagi, Mount Myogi, and Mount Shirane (Kusatsu). I also want to visit the hot springs in Kusatsu and Minakami. Hmm, one or two nights probably won't be enough to see everything."

Yuu thought that if he only mentioned his hometown, it might be suspicious, so he listed tourist spots in the prefecture, hoping to see his birthplace along the way.

Thinking about it, the only places he had gone for fun were within Saitama Prefecture and the hot spring resort Hesperis in Hakone.

He went to Tokyo about once a month, but he hadn't been to any other prefectures.

His father Sakuya had traveled all over the country from a young age, increasing his lovers and children.

If safety could be guaranteed, Yuu also wanted to travel all over Japan and have relations with beautiful women.

"Yuu-sama, amazing."  
"Huh?"  
"In your mind, you're already assuming it will be resolved, aren't you?"  
"Ah... well, maybe. In my mind, I only have a vision of it going well."

Anxiety remained, but he deliberately put on a brave front. Jane was one of the most dangerous women he had ever met. There were also Terada and a woman named Sawaguchi, both wanted criminals and Jane's accomplices.

But there were more than just three opponents. He had heard that about five or six people from that extremist organization, the so-called "Something Conference," were also on the run, and there might be others.

In any case, the enemy was waiting for him with bated breath, like a summer insect flying into a flame. They probably intended to use him as an outlet for the sexual desires pent up during their long life on the run.

The only reassuring thing was that they wouldn't kill him.

He hoped there were no extreme sadists or perverts who would make him recoil.

"But I'm not alone. The presence of Kanako-san, Touko-san, Miyo-san, and Yoriko-san beside me is a big support. I'm always grateful. Thank you."  
"Yuu-sama..."

With visible emotion, Kanako and Touko, who were looking at him from both sides, had their hands squeezed.

Miyo, who was usually facing forward in the passenger seat, also turned around. Only Yoriko, holding the steering wheel, remained facing forward, but there was a gleam in her eyes.

"No matter what happens tonight, I will protect Yuu-sama even at the cost of my life!"  
"No, if you say 'at the cost of your life'... if Kanako-san dies... I wouldn't like that. I want you to stay with me forever."  
"Hya, hyai!"

Being stared straight at by Yuu, Kanako's cheeks turned red. It felt like a marriage proposal.

Unaware of Kanako's expression because the car was dark, Yuu told Touko, Miyo, and Yoriko that he relied on them too.

Kanako and Touko, and all four of them, felt truly fortunate to be Yuu's protection officers. Even if a difficult challenge lay ahead.

---

Arriving at Akagi Kogen Service Area.

Similarly, a note with the next instructions was found in the innermost stall of the restroom.

The next destination was Shiozawa Ishiuchi Service Area. It was confirmed they were entering Niigata Prefecture.

The Niigata Prefectural Police would surely be contacted immediately.

"Maybe they're heading to some port?"  
"That's it! They're planning to escape abroad by ship."  
"I think we'll have to ask the Japan Coast Guard for cooperation. I'm sure the police are considering it too."

If they kept running within the country, the possibility of being caught eventually was high. So they were planning to escape abroad. It was exactly what criminals would think.

However, at sea, there was the Japan Coast Guard to police criminals. They probably intended to escape forcefully while holding Yuu as a hostage.

If they were heading to Niigata Prefecture in midwinter, they would have to put chains on the tires.

Fortunately, since the new year, there had been almost no snow, so there were no chain restrictions on the expressway.

---

After leaving the service area, the road seemed to become an upward slope, and the speed decreased slightly.

During the day, they would have been able to see the magnificent Tanigawa mountain range, but unfortunately, it was pitch black outside. It only felt like a huge wall blocking the way.

Passing Minakami IC and Tanigawadake PA, they finally entered the Kanetsu Tunnel, which stretched for 11 km.

Inside the tunnel, illuminated by orange lights, passing cars were sparse. For a while, there were no cars ahead. The lights visible at a distance behind were probably from police vehicles.

Where on earth was he going?

Driving through the long tunnel, the unchanging view made it feel less real.

Yuu's eyelids grew heavy. He leaned his head on Kanako's shoulder beside him and fell asleep.

---

"Huh? I fell asleep..."

When Yuu woke up, he was leaning toward Touko on his left, his face buried in the nape of her neck.

When sleeping while sitting, Yuu had a habit of leaning to the right, usually borrowing Kanako's shoulder.

It was rare for him to be leaning toward Touko.

Actually, while Yuu was asleep, Touko had said, "Nee-san is always hogging him," and they had switched every 30 minutes.

"Sorry, Touko-chan. Was I heavy?"  
"Nnfuu... Yuu-sama's breath..."

Yuu still seemed half-asleep.

Normally, he used "-san," but only when getting intimate with the three of them, he called Touko "-chan." That made Touko happy.

Though petite, Touko was well-trained and had no problem with Yuu's weight.

Moreover, Yuu's breath directly on her skin was enough to arouse her.

In the dark car, Yuu couldn't quite see Touko's expression and thought he had inconvenienced her, so he apologized. But when he realized she wasn't inconvenienced at all but rather delighted, he pulled Touko closer by the shoulder and patted her head.

"Nnfu fu. Yuu-samaa..."  
"Ahaha... Um, where are we now?"

The other three protection officers looked enviously at Touko happily rubbing her cheek against Yuu's chest, but Miyo, who was in the passenger seat navigating, answered Yuu's question.

"We're currently driving through Kashiwazaki City. It seems the next instructions are on a note at a convenience store on the outskirts of the city."

While Yuu was asleep, they had checked the note at Shiozawa Ishiuchi Service Area. They took the Hokuriku Expressway toward Toyama at Nagaoka Junction. They had gotten off at Kashiwazaki IC and were driving northeast on National Route 116.

They had already left the urban area of Kashiwazaki, and the surroundings were pitch black. Unmarked police cars should have been following at a distance. There was no worry of losing them, but it would be obvious they were bringing the police along.

The destination was a convenience store on the border between Kashiwazaki City and the neighboring town.

The vast parking lot had no cars parked.

Once again, they had someone check the note that was supposedly posted in an inconspicuous spot in the restroom, and they also bought food and drinks.

The time was 1:30 AM. Even with breaks, the expressway was empty at night, so they were making good time for the long distance.

This was the last set of instructions, and it was time to fortify themselves before plunging into enemy territory.

---

After leaving the convenience store, they immediately entered Kanba Town. Yuu didn't know that place name.

At some point, they were driving along a coastal road.

The Sea of Japan should have been on the left, but it was too dark to see anything.

In contrast, the right side was covered in pure white snow. As they went inland, the slope increased, and occasionally buildings came into view, but almost all lights were off.

After turning a curve, a large building suddenly appeared. It seemed to be right next to the coast.

A warehouse in a place like this?

Yuu had seen warehouses lined up at the wharves in Tokyo and Yokohama, but here there was only one prominent building standing alone. There seemed to be a few single-story buildings nearby, but they were hard to make out because of the snow cover.

"Is that..."  
"Yes, it seems to be the final destination."

The instruction note Miyo had brought included a map, and it clearly indicated that was the place they were heading to.

As they got closer, they could see something long and thin sticking out from the top of the building like a horn.

During the day, it would have been recognizable as a crane from afar.

But in the darkness of night, it looked like a monster's horn, making it even more eerie.

---

### Author's Afterword

I used real place names for part of the route, but the destination is a fictional place name.

By the way, I thought I had written about Yuu's hometown in the first chapter, but when I reread it, I hadn't. It must have been a setting in my head.

Belatedly, I added that he is from Gunma Prefecture in the character introduction.

The model is a town that was absorbed during the Heisei-era mergers, which I've used as a setting in my past works.

### Chapter Translation Notes
- Translated "警護官" as "protection officer" consistently with the Fixed Terms.
- Translated "妊婦" as "pregnant women" to maintain explicit terminology.
- Preserved Japanese honorifics (e.g., -san, -chan) as per style rules.
- Transliterated sound effects: "ニコっと" as "with a 'niko' sound", "がばっと" as "tightly", etc.
- Maintained original Japanese name order (e.g., Iruma Miyo, Oosato Yoriko).
- Translated internal monologues in italics: *(This is concerning.)* for example (though none in this chapter).
- For the fictional town "神羽町", translated as "Kanba Town" and added to Special Terms.
- Rendered dialogue with new paragraphs for each speaker, except when preceded by attribution.
- Translated the author's afterword to provide context about the setting.