## 324. The End of Obsession ⑤ ~Negotiations~

The building appeared about as spacious as a lengthened school gymnasium.  

Only the central area had lighting, leaving the depths shrouded in darkness. The ceiling seemed about three stories high with no partitions, creating an expansive space.  

Rusted steel beams crossed high above, and rusted rails lay on the floor. Numerous patch marks covered the walls, indicating severe dilapidation. It seemed questionable whether it was still in use.  

Mysterious junk lay scattered along the walls: paint-peeled drums, large cans, tires, pallets, and other wood and metal scraps. They appeared practically like garbage.  

Before entering, Kanako and others had speculated this might be a dock for repairing small vessels like fishing boats.  

The nearby road was a single lane, easily blockaded.  
Thus, they predicted the kidnappers planned to escape by sea.  

Lights offshore suggested patrol boats might already be waiting, possibly after contacting the Japan Coast Guard.  

But as Yuu entered, he saw no trace of any vessel. The massive steel door facing the sea remained shut.  

The entire building creaked annoyingly, likely from bearing the brunt of sea winds.  
Only the central area was clear, revealing a group clustered beyond.  

"Sayakaa!"  

They seemed to notice Yuu entering through the service door. Those sitting on pipe chairs and tires moments ago all stood up at once.  

Among them, one long-haired woman remained seated on a chair. Though her face was downcast and unseen, the swollen belly under her familiar white sweater confirmed her pregnancy.  

""Yuu-samaa!""  

Kanako and others hastily chased after Yuu as he dashed forward.  
Hearing Yuu's shout, the woman looked up - confirming she was Sayaka as expected.  

But a gag prevented her from speaking clearly, emitting only muffled moans. She was bound to the chair with her hands tied behind her back.  

"Stop right there! Don't move!"  

An exceptionally tall woman sharply commanded Yuu to halt. He stopped about 5 meters away because her handgun was aimed at Sayaka's occipital region.  

*Guh... Five of them? Three have guns. The others... hiding somewhere?*  

Numbers appeared even within visible range. Yuu knew Kanako and Touko possessed extraordinary combat abilities, and he felt confident against ordinary women. The temptation to charge overwhelmed him.  

According to Ryoko's testimony, five appeared during the abduction, but others likely assisted including drivers.  
Kate's absence suggested another base where she was confined.  

Moreover, besides the tall woman, two others ostentatiously held handguns.  
Weapons that could easily take lives with a trigger pull. That advantage was overwhelming.  

In Japan's peaceful society, protection officers aren't legally permitted to carry firearms except for special circumstances like overseas travel. They only carry expandable batons and non-lethal riot control weapons. With hostages taken by armed opponents, reckless action was impossible.  

Drafts made the interior nearly as cold as outside. An antique potbelly stove behind the group seemed barely adequate for warmth.  

Sayaka wore only a sweater after being abducted when exiting the car, leaving her chilled by the wind.  
Seeing his beloved restrained ignited furious rage within Yuu.  

But he couldn't yield to emotion and risk Yuu, Sayaka, or any protection officer dying.  
Remembering his mission, Yuu lowered his chin and muttered his observations softly. The police should receive them through his chest microphone.  

"You came, Yuu Hirose. I've been waiting."  
"You're Jane Grimwood?"  

The tall Caucasian woman with brown short hair stood imposingly at the center.  
Her wanted poster showed long blonde hair, but she'd apparently cut and dyed it while fleeing. Her face closely resembled Kate's.  

Silent, she'd be exceptionally beautiful. She looked nothing like a mother of a 16-year-old.  
Tall with a good figure and striking appearance - she could pass as a foreign film actress.  

But her all-black outfit - gleaming coat, slim pants, and boots - combined with her evil smile gave the impression of a villainous organization executive.  

The middle-aged women flanking Jane also matched remembered faces. Though wearing glasses or different hairstyles, Yuu recognized them from studying their wanted posters at the police station alongside Jane's.  

About Yuu's height and slender, Terada wore glasses with narrow eyes behind them. Her expression remained blank yet shrewd upon seeing Yuu.  
In contrast, Sawaguchi was short and plump with droopy eyes. She instantly beamed with joyful delight upon seeing Yuu, like an ardent fan spotting her favorite male idol.  

These two with utterly contrasting expressions seemed Jane's longtime associates.  
According to warrants, Jane was 34, Terada 39, and Sawaguchi 37.  

The two at the back wore caps pulled low, obscuring their eyes. But they whispered animatedly, apparently surprised by Yuu.  
Their dark gray uniforms with high collars and multiple buttons resembled old military garb minus rank insignia.  

"Yuu, come. Become mine, and I'll return the hostage."  

Jane jerked her chin toward Sayaka.  
Essentially a hostage exchange.  
To them, Yuu as a male was far more valuable than Sayaka.  

Sayaka desperately shook her head at Yuu.  
Only muffled sounds escaped her gag, but Yuu understood:  
*Don't come. Don't worry about me.*  
That was Sayaka's nature.  

Yuu wanted to rescue her immediately but couldn't simply obey Jane.  

"There should be another hostage. Where are you hiding her?"  
"Hah?"  

Jane responded with an exaggerated shrug.  
The phone call stipulated Yuu's arrival as the condition for Sayaka's release.  
Perhaps Jane hadn't expected Kate's mention here.  

But Yuu deliberately revisited the topic hoping for clues about Kate's whereabouts.  
Irritation flashed across Jane's face.  

"Hostage? Wrong. She's my daughter. I just brought home a runaway."  
"No. According to Kate, you severed ties. You continued abuse - no, domination through verbal and physical violence. She said you're no parent.  
Kate decided on a new home and school. Ignoring a 16-year-old's will and confining her isn't parental behavior. Don't misunderstand. Children aren't pets."  
"Guh..."  

To them, men were fragile beings who couldn't survive without female protection.  
They believed surrounding and threatening would instantly make him compliant.  

But Yuu before them stood too imposingly.  
Instead of obediently submitting to Jane's words, his eloquent rebuttal clearly flustered them.  

The back two spoke rapidly in some language. Jane irritably retorted in Japanese. Sawaguchi rephrased it differently.  
Hearing this exchange, Yuu realized they weren't speaking Japanese or recognizable English. It vaguely resembled Chinese. He brought his mouth near his chest and muttered softly.  

Jane turned to Yuu, not hiding her displeasure.  

"Was that girl doing so well? Already pregnant? Hmph. But she's not here. She's somewhere distant. If you want to meet her so badly, come with us."  

Was she misunderstanding? Burning with rivalry toward her daughter as a woman?  
Given the terrible relationship between reborn Kate and Jane, such suspicion might be inevitable.  

With Kate absent, the real battle began.  
Yuu glanced at Kanako and Touko flanking him and nodded.  
Despite the opponents' firearms, neither showed fear. They burned with protective duty toward Yuu.  

"Fine. If you release Sayaka, I'll come. How do we get to Kate's location?"  

Jane didn't answer, but relief briefly crossed her face.  
However, she changed expression seeing four protection officers flanking Yuu as he stepped forward.  

"Hey, wait! Only you come!"  
"Can't do that."  

A back-and-forth argument ensued.  
Jane grew visibly impatient at Yuu's noncompliance.  
She knew police accompanied Yuu here.  

Despite their hostage and gun advantage, police special forces might storm in if pushed.  
Jane, Terada, and Sawaguchi seemed intent on peacefully acquiring Yuu, but the back two clearly began fuming. Their gestures conveyed this clearly.  

Hearing arguments about passenger limits, Yuu suddenly looked up.  
Was the roof opening for a helicopter?  
When Yuu asked "How will we go? By boat? Helicopter?" again, no one answered.  

After mutual demands for compromise, only Kanako and Touko would accompany Yuu.  
Terada untied Sayaka from the chair and stood her up. Seeing her stagger, Yuu barely restrained himself from rushing to embrace her.  

As Yuu's group slowly advanced, they passed Sayaka supported by Terada.  
Still gagged and bound, Sayaka stared intently at Yuu.  
Her muffled words sounded like "Yuu-kun" or "I'm sorry."  

"It's okay. I'll definitely return, so don't worry. Get in the car and warm up. Sayaka. I love you."  

Hearing this, tears streamed profusely from Sayaka's eyes.  
Terada released her, and Miyo and Yoriko waiting behind Yuu took custody. Immediately, their hands worked to remove the gag and ropes.  

Meanwhile, Yuu approached within 2 meters of Jane.  
He noticed a 1.5m square plywood sheet laid between them.  
As Jane grinned, the two cap-wearing women slid the plywood aside, revealing a manhole-like opening.  

When Yuu peered down, Sayaka's voice called from behind. He turned.  

"Yu-Yuu-kunn!"  
"Sayaka, you're a strong girl. Wait for me with Riko and Emi."  
"Vuu..."  

"Enough touching farewells. Get down already."  

Likely Terada speaking.  
Yuu frowned at the interruption but nodded and approached the hole.  

"Going underground..."  
"Scared? Want a piggyback? Or should I carry you? Gufufu."  
"No, I can climb down myself."  

Sawaguchi had appeared behind him with a lewd grin.  
The hole's diameter barely fit a person, so Yuu assumed she joked. Piggybacking an adult seemed impossible regardless. Unnoticed by Yuu, Sawaguchi looked genuinely disappointed.  

One cap-wearing woman descended first with practiced movements from frequent use.  
Next, the agile Touko descended before Yuu.  
Kanako shone a penlight down, but the beam seemed pitifully weak in the deep darkness.  

"Yuu-sama, it's safe. Come."  
"Okay. Coming down now."  

Following Touko, Yuu grasped the metal ladder.  
The ladder, likely added later, wasn't rusted and felt surprisingly sturdy. Falling seemed unlikely, but the metal bars felt freezing to bare hands.  

Amid fears of how far he might fall if slipping, Touko's guiding voice below proved reassuring.  
To report and calm himself, Yuu spoke aloud while descending.  
But sudden anxiety struck.  

Old mobile phones had poor reception underground.  
He prayed the microphone and transmitter on him would function below.  

The ladder wasn't continuous, ending at a platform where the first woman and Touko waited.  
The cap-woman gestured downward with her thumb before descending further.  

Peering down revealed a narrower, round hole than before. It would be tight for larger people.  
A thick circular metal plate lay nearby - likely a cover.  
Touko descended next, so Yuu waited. Faint light now glowed below, slightly reassuring.  

The final descent passed quickly.  
The floor clanged metallically.  

"Kinda cramped."  

Kanako descended immediately, so Yuu moved aside. Kanako and Touko sandwiched Yuu front and back.  
The low, slanted ceiling made the 180cm+ Kanako hunch awkwardly to avoid hitting it.  

The passage around Yuu was too narrow for two people side-by-side.  
The ceiling and walls seemed dark-painted metal with pipes running along and mysterious boxes attached.  
The air felt damp and oddly smelly.  
It reminded Yuu of sewers from movies.  

Yuu noticed an open space diagonally across the passage. Light leaked from there.  
What room was it? Stretching to peek, Yuu saw a central pillar with a horizontal bar at hand-height. It resembled a utility pole but differed.  
The far wall glittered with blinking equipment.  

Several people stood near the pillar, crying out in surprise upon seeing Yuu - again not in Japanese.  
The cap-woman descending after Kanako blocked Yuu's view, shooing him away like a dog. Rude woman.  

"She says go to the back room. Wait there awhile."  

Urged by Sawaguchi who descended next, Yuu's group walked to the passage's end where they were ordered to open a door.  
The room was long but felt cramped from the low ceiling. Inside appeared completely empty.  
Its original purpose was unclear, but it wouldn't be strange as an improvised cell.  

Indeed, after confirming Yuu's group entered, Terada and Sawaguchi locked the iron door lacking even a peephole or vent.  
The dim orange emergency light above barely illuminated faces at a distance.  

"Let's sit."  

Yuu went to the farthest wall and sat directly on the floor.  
Kanako and Touko had been scanning for threats but apparently found none in the small room.  
They sat flanking Yuu protectively.  

Sitting made him notice vibrations rising from below.  
Though the metal floor felt cold, the interior was surprisingly warm.  

"This is... what? A ship, maybe?"  

He wondered if the underground dock hid a ship.  
The interior suggested a freighter more than a cruise ship or cruiser.  
But Kanako slightly shook her head. Shadows deepened her fine features in the gloom.  

"Yuu-sama, this might be... a submarine."  

The moment she spoke, the vibrations intensified slightly. Yuu felt slight G-forces press him against the wall.  
He sensed the vessel moving.  
Whether his transmitter still functioned was his sole concern.  

---

### Author's Afterword

I'm an amateur regarding radio waves, so as mentioned in the story, I only know that old mobile phones had poor reception underground.  

With advancements to 4G and 5G, it's probably fine now.  

But underwater?  

Reading war chronicles, WWII submarines needed to surface to transmit radio waves, making them targets for patrol planes.  

By around 1990, had technology overcome this?  

I'll proceed according to authorial convenience regarding such details.

### Chapter Translation Notes
- Translated "猿ぐつわ" as "gag" to match explicit terminology requirements
- Preserved Japanese honorifics (-sama for Yuu, -kun for male characters)
- Transliterated sound effects: "ぐっ" → "Guh", "ぐふふ" → "Gufufu", "むぐむぐ" → "muffled"
- Translated "オンボロ" as "dilapidation" to convey severe disrepair
- Used "protection officers" for 警護官 consistently with Fixed Reference
- Maintained Japanese name order: "Komatsu Sayaka" not "Sayaka Komatsu"
- Italicized internal monologues per style guidelines
- Translated technical terms literally: "G-forces" for "Gがかかって"