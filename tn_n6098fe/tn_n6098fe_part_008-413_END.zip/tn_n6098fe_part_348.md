## 326. The End of Obsession ⑦ ~Lifeblood~

### Author's Preface

While writing chapter 326, I suddenly realized:  
If I only write from Yuu's perspective, the background circumstances I envisioned in my mind wouldn't come across, making it confusing.  

Therefore, I decided to write the first half from Jane's perspective, covering events after Yuu was drugged.  

This contains violent scenes. Those sensitive to violence or blood should proceed with caution.

---

Click, click.  

Pulling the trigger only produced dry sounds with no recoil.  

*(Out of ammo!?)*  

The chill down my spine lasted but a moment. The woman charging toward me collapsed like a puppet with its strings cut.  

"Haaah..."  

A heavy sigh escaped. The dimly lit cove inside the cave had become a sea of blood, with numerous women lying prostrate on the ground.  

"Terada! Sawaguchi!"  

Coming to my senses, I called my comrades' names but received no response.  

Our submarine continued submerged, slowly navigating northeast through the Sea of Japan, arriving at Mugishima before dawn. This small island off Akita Prefecture once had a tiny settlement. After the last man died, the remaining women migrated to the mainland, leaving it deserted for about five years.  

The mainland side had a modest docking area, while the opposite side featured steep cliffs. Several sea-connected caves existed, one containing a cove deep enough to hide small vessels. The cave interior branched into a natural maze, with some passages connecting to the mountainside on the island's western edge.  

We'd targeted this island before it became deserted. Using a subsidiary real estate company, we bought the nearly worthless land under unrelated names and renovated ruined houses into hideouts. Here, we evaded authorities and conducted transactions with various continental organizations.  

We successfully transported the sedated Yuu to the mountainside hideout. So far, according to plan. All that remained was paying the pirates who retrieved our precious submarine their promised enormous reward.  

But then they started causing trouble.  

These pirates originated from the Manchuria Republic in northeast China - a nation founded by Qing dynasty descendants that experienced repeated coups before becoming a republic in name only. Either from remote fishing villages or naval deserters, they'd lived in a women-only world.  

I knew they'd gone wild-eyed seeing Yuu, and my bad premonition proved correct. Earlier, after locking Yuu in an empty warehouse, two young ones stole the key and sneaked in, only to be beaten back.  

*Give us fun. Let us have him. Give us his semen.* They made these demands incessantly. I only dealt with English-speaking officers, but Sawaguchi understood several continental languages. Hearing their selfish demands, she cursed vehemently.  

As compromise, I proposed lending Yuu to a few officers including the captain for limited time - only after we'd enjoyed him thoroughly, and only inside the hideout. But seeing a young man for the first time - or first in ages - they grew increasingly heated, making excessive demands. They vastly outnumbered us.  

The Jiaolong 6 was a diesel-powered coastal submarine purchased from Russia when Manchuria invaded the Liaodong Peninsula during one of the continental conflicts. Over 30 years old, it had been decommissioned and slated for scrapping before pirates bribed officers to acquire it. A rundown vessel barely maintained.  

Though designed for 30 crew, they operated it with about 20 by cutting corners - mainly because they lacked torpedoes and could only use mounted machine guns.  

With only five of us including hideout guards, they outnumbered us four to one. I'd heard people from that country become aggressive when sensing advantage. Even without understanding words, their demand for the man was clear.  

Pressured from below, the captain declared:  

"Half the promised reward is enough. In exchange, we'll welcome that man at our base. We'll return him here in a week."  

I was furious inside but kept it from showing. Who'd swallow such nonsense? They'd surely drug him after raping him as much as they wanted, then keep him forever under pretext of "his own wish."  

Since lower ranks joining would be unmanageable, I negotiated long with just the captain and officers. Dawn broke during talks. When we settled on half payment and just three days with Yuu, they all wore reluctant expressions but had relaxed smiles. Reducing days didn't mean they intended to return him. I knew that much.  

After agreement, they laughed around a bonfire - likely sharing lewd jokes about Yuu already. Turning away, I signaled Terada and Sawaguchi with my eyes.  

Reluctantly, I decided to execute the contingency plan prepared in case they became unmanageable. I absolutely wouldn't hand over Yuu - Sakuya's reincarnation - to anyone.  

Sawaguchi and I stayed while Terada went to fetch Yuu. After nearly an hour, Terada and another appeared flanking a man as cheers erupted.  

That wasn't Yuu. It was one of our hideout guards with similar build, hood pulled low to hide her face.  

As Terada's group passed me toward the captain, I signaled Sawaguchi. Nodding, she took a remote-like device from her pocket, extended its antenna, and pressed the switch.  

Seconds later when Terada's group was 5 meters from them, a heavy *thud* reverberated from the sea. Due to draft, the Jiaolong 6 was anchored offshore. We'd come ashore in two boats, so distance was considerable.  

Explosions sounded multiple times. The bombs we'd planted inside the submarine overnight detonated via radio control. Those on deck fell into water; those leaning from hatches fell inside. Submarines lack substantial armor. It couldn't withstand internal explosions.  

The Jiaolong 6, flooding in multiple places, sank instantly. Those inside wouldn't die immediately, but with only narrow hatches for escape in midwinter seas, they wouldn't survive unscathed. This should neutralize three-fourths of them.  

The captain and others turned and stared dumbfounded as their ship sank. A perfect opportunity. Drawing pistols, we fired almost simultaneously.  

Bullets pierced backs and chests, felling three, but one shot grazed a shoulder and another missed completely. The two later arrivals were college dropouts in their early 20s with little combat experience and poor firearm skills. Their inexperience showed now.  

Even at five against two, the advantageous situation suddenly reversed. Shots came from my flank. Sawaguchi, taking direct hits, fell atop me, pinning me down. My side burned with pain.  

Apparently the enemy hadn't been completely off guard. They'd hidden ambushers behind rocks without my knowledge. They likely hadn't expected their ship to be sunk.  

But the tide turned instantly. The three ahead - the one disguised as Yuu now hoodless - exchanged fire with no cover, falling one by one. Sawaguchi lay motionless. Though wounded, I could still move.  

Hiding behind rocks, I crawled laterally to flank the ambushers.  

Perhaps confident of victory, the four ambushers emerged from cover just as I fired consecutively from behind. I shot two in the back from closest range.  

The remaining two turned and fired immediately, but their shots missed as I took cover behind chest-high rocks. Though two against one, I held advantage. After shooting the third through the chest, the fourth charged. I calmly shifted position.  

As the fourth woman vaulted the rock with a war cry, my first shot shattered her left shoulder, making her reel back. Aiming at her heart for the second shot, I ran out of ammo.  

Seeing no movement in sight, I quickly crouched. Discarding the empty magazine, I reloaded with a spare from my pouch and returned to my original cover.  

Sawaguchi was already dead. That I hadn't suffered fatal wounds was pure luck - Sawaguchi had shielded me. An intellectual but closeted pervert, I'd recently learned she carried Yuu's magazine cutouts everywhere. Since yesterday she'd kept saying she wanted to see Yuu naked soon.  

I closed Sawaguchi's still-open eyelids.  

Moving toward where Terada's group fell, I glanced at the cove and saw several who escaped the submarine floating in water. At that distance, they posed no immediate threat. First I needed to check my comrades.  

As expected, the two later arrivals weren't breathing. Only Terada, bloodied from multiple gunshots, clung stubbornly to life. Spotting the ambush first and dropping prone must have helped. She fought longest among the three. My victory was thanks to Terada.  

"Jane... you're... alive?"  
"Yeah, thanks to you."  
"Heh... tough... bastard..."  

With a final smile, Terada expired. I'd lost a close friend of 16 years since coming to Japan.  

People often say I kill expressionlessly, but even I feel adrenaline surging during combat. But as excitement faded after battle, my side throbbed with pain. Touching it, my hand came away sticky with blood.  

I needed immediate treatment. Though sparsely populated, this island had no clinic, but the hideout had first-aid supplies. I desperately wanted to see Yuu... no, Sakuya. Seeing him would make him remember the past.  

Holding only that thought, I began walking toward the cave depths.  

◇ ◆ ◇ ◆ ◇ ◆  

"All obstacles are eliminated. Kufufu... Now, let's continue where we left off. Sakuya(···)"  
"Wh-what are you..."  

Contrary to expectation, only Jane entered. Calmly thinking, I might have handled her alone. The door lock was externally operated and now open. Not that Yuu intended to abandon Kate and flee.  

Yuu wanted to ask many things but couldn't form words. Jane looked abnormal. Her black coat's upper half was dyed crimson as if splattered with blood. Radiating dangerous energy fresh from life-or-death combat, her face was pale. Her eyes were fixed - Yuu felt paralyzed under their sharp gaze.  

Though reborn into this dangerous world, this was Yuu's first time feeling terror from a woman's gaze.  

Moreover, Yuu wondered strangely - hadn't Jane just called him "Sakuya"? Sakuya meant Toyoda Sakuya - Yuu's deceased father in this world. Why mention him now? While Yuu hesitated, Jane began stripping coat, jacket, and pants without pause.  

The unheated room should have been freezing. Exposing skin should cause shivering, yet Jane stripped unhesitatingly. When she stood before Yuu in black underwear, he exclaimed involuntarily.  

"Hey, you're injured!?"  

Perhaps an athlete? In underwear, Jane showed broad shoulders, developed chest and leg muscles, a taut body without excess fat - no trace of a mother. Her abdomen showed muscle definition but was tightly bandaged. Blood seeped near her left flank.  

"What? Just a scratch. I took strong painkillers - no problem. Actually I feel great! Hahahaha!"  

The haphazard bandaging suggested no medical treatment. Even amateur Yuu could tell from the bleeding - this was no scratch but a recent deep wound. Yet Jane seemed completely unfazed - rather, elated. Yuu recalled hearing about narcotics used as medicine in unregulated times. These "painkillers" must be illegal drugs.  

What was so funny? Jane cackled while unhooking her bra and removing her panties. So high she didn't even feel the skin-piercing cold? Like drunks stripping naked even in winter, perhaps.  

Considering her mid-30s age, sagging would be normal, but Jane's breasts formed perfect hemispheres pointing forward assertively. Not huge but palm-filling size. Nipples hardened visibly from Yuu's position in the cold air. Her lower abdomen had minimal grooming - golden pubic hair matching her head spread widely. Moist around the groin - perhaps arousal while stripping.  

Overall an athlete's well-proportioned body. Undeniably alluring despite her wickedness. But as beautiful flowers have thorns, Jane's seemed venomous.  

"What about Kanako-san and Touko-san?"  

Yuu barely managed to ask. He'd guessed they left Kanako and Touko behind after drugging Yuu. The blood splattered on Jane's coat suggested her "eliminated obstacles" remark was ominous.  

Hearing Yuu, Jane suddenly furrowed her willow-leaf eyebrows.  

"I don't want to hear about other women now!  
Hey, Sakuya. I left my country just to see you again.  
Look only at me now! Terada and Sawaguchi died for me!  
Trust them? They'd take you to the continent - you'd never see family again!  
I won't mistreat you. If you give me plenty of love, I might consider letting you meet them.  
Kukuku. No interruptions here - plenty of time to nurture love."  

Jane's words seemed disjointed to Yuu. But she said Terada and Sawaguchi died. He imagined infighting. Were Kanako and Touko involved? Safe? That was his only concern.  

"More importantly... won't Sakuya undress? Fufu... or want me to undress you?"  
"Eh, no"  

Smirking, Jane approached Yuu with outstretched hands. Panting roughly, her blue eyes shone feverishly - like a beast before prey.  

Originally intending compliance to rescue hostages - no maidenly chastity to protect - Yuu wanted Kanako and Touko's safety. But Jane seemed mentally unstable, unlikely to answer. Kanako and Touko weren't women to die easily. For now, pray for their safety and satisfy Jane.  

Yuu resolved himself. Standing, he draped his blanket over Kate. Stepping toward Jane, he unbuckled his pants.  

"I'll undress myself. Look all you want."  
"Kufu. That's more like it. Catherine? No, Dominique? Whatever! I'll show you who's the ultimate victor claiming the prize! Ah-hahaha!"  

Yuu didn't recognize the woman's name. What did she mean? Jane glanced sideways at Kate but didn't truly see her. Though eyes shone vividly, they seemed mad.  

---

### Author's Afterword

As noted in "Worldview & Terminology," I'll supplement here.  

After the Qing dynasty's fall, China remained fragmented for long before consolidating into four nations about half a century ago.  

This is the second nation mentioned after the Republic of China (Nanjing National Government) in the southeast.  

Only the Republic of China maintains friendly ties with Japan. Relations remain cold with the other three nations and Korean Peninsula states.  

With extremely poor relations over land borders, they avoid open war with Japan but experience political friction. Limited economic ties and people flows exist.  

These pirates mainly target civilian ships from hostile nations including Japan - essentially state-tolerated. If captured, their homeland disavows them - standard procedure.  

### Chapter Translation Notes
- Translated "命くれない" as "Lifeblood" to preserve the Japanese wordplay combining "life" (命) and "crimson" (紅)
- Preserved Japanese honorifics (-san) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "カチッ" → "Click")
- Used explicit anatomical terminology per style guidelines (e.g., "pubic hair", "semen")
- Maintained original dialogue formatting with new paragraphs for each speaker
- Translated "蛟龍6号" as "Jiaolong 6" using standard romanization
- Rendered sexual content without euphemisms as required