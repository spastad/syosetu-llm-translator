## 327. The End of Obsession ⑧ ~The Sun is a Sinner~

### Author's Preface

Finally, we enter the erotic part. It's been a long time coming...

---

Jane seemed unable to hold back any longer just as I finished unbuttoning my shirt and lowering my pants right in front of her. Suddenly, she hugged me, causing me to lose my footing and get pushed down. Even though it was onto a tatami mat, I nearly hit my head.

"Whoa! Mmmph!?"

Jane's arms wrapped tightly around the back of my head and waist. My lips were sealed as I found myself unable to move, as if pinned by a judo ground technique. She greedily devoured my lips with rough, snorting breaths. *Mufu, mufu*.

From my perspective, Jane has a daughter named Kate, and it seemed like she could buy men anytime, but the reality was unclear. At any rate, right now, she only appeared to be starved for men. Is this how a middle-aged virgin man would act when about to have his first experience with a high school girl?

*Chu-pu chu-pu*—continuous lip sounds echoed as Jane persistently pressed her lips against mine. Then, she stuck out her tongue. She licked all over my lips as if savoring them. When I opened my mouth and stuck out my tongue invitingly, Jane's face lit up with joy. It was as if she had achieved a deeper kiss with the one she longed for. When the tips of our tongues touched, she let out a "*Uvu*" sound. With our mouths half-open, our tongues touched each other—pushing, one on top, then the other. Making *pecho pecho* sounds, it was like dancing. Eventually, as if doing a cheek dance, she pressed her tongue tightly against mine and surged into my mouth.

"Mmph, nn, churu, ju-ruuuu... nero, re-ro, chu-puu... haa, haa, oihi... Sakuyaa... aah! More! Anmmph!"

I accepted the ever-eager Jane and actively entwined my tongue with hers. The pallor of Jane's cheeks from earlier now flushed crimson. As if determined not to let me escape, she lovingly stroked my head with her right hand wrapped around the back of my head. I also extended both hands around Jane's back. Naturally avoiding the bandaged part, my right hand rubbed her cold back to encourage blood flow, while my left hand headed toward her buttocks. Unlike her well-developed, hard back, her buttocks had the softness unique to women. I kneaded them *muni-muni*.

Embracing each other and exchanging deep kisses, Yuu and Jane became oblivious to the age difference or the hostility they held until last night. To an onlooker, they might have looked like a passionate couple. Jane pulled her mouth away, tongue still out, and stared at my face. A string of saliva extended from the tip of her tongue and settled into my mouth. Jane, having watched this with her eyes narrowed, smiled smugly with evident delight.

"Mufu. As expected, kissing Sakuya is exceptional. It feels like I'm melting from the core of my body."

Jane's right hand, which was pillowing my head, stroked my cheek. The touch felt like she was petting a beloved animal, a bit ticklish. Having had many opportunities with multiple girls, I enjoy being adored unilaterally, but now Jane is my only partner. I decided to indulge without holding back. My right hand moved from her back to her nape and then to the back of her head, where I pulled her toward me with a light force. This time, I would be the one to invade Jane's mouth.

"Nnpho!? Ooh, nn... vunmm... eraah... ap... nnn!"

I actively tangled my tongue with hers, moving it around inside her mouth so much that Jane's cheeks puffed out. Jane, with a look of joy, closed her eyes and pressed her lips. Drool dripped from her half-open mouth, wetting the area around my mouth. Jane forcibly pushed her left hand, which had been around my waist, under my T-shirt and touched my skin directly. As she felt the touch of a man's skin, Jane grew increasingly excited. Simultaneously, she spread her legs and straddled my waist, moving her hips back and forth as if rubbing her lower abdomen against me. It seemed like she was simulating being connected. Since her private parts were already soaking wet, the wetness spread to my pants. The crotch of my pants, rubbed against, began to stain.

While exchanging deep kisses with the now completely naked Jane, my crotch also reacted. No matter how wicked the opponent, I couldn't resist instinct. Jane must have noticed that the part she was rubbing against had hardened through my pants. With her wet tongue still out, she grinned. Licking my wet mouth area like a dog, she whispered.

"Kukukuku, Excellent! Sakuya Junior seems motivated too. Mufu. I-I'm putting it in? Right now!"

Jane's hand reached for my pants. She really was acting like a virgin in her eagerness. By the way, my crotch was only half-erect.

"Don't rush so much. This time, I'll caress you."  
"Eh?"

While holding Jane, I rotated half a turn to the left. Now, in contrast to before, I was on top, covering her. I turned to the left to avoid putting pressure on Jane's injured left side. The ingrained habit of being gentle with women manifested even with Jane as my partner.

Jane, who had been straddling me and wanting to insert it immediately, seemed surprised by my move. Though I train my body, Jane has more experience. It was unclear who had the advantage due to age and build differences. Yet, Jane was easily pinned down by me. Perhaps I, who had rested sufficiently, won against Jane, who was injured and had pulled an all-nighter.

"Wait. Sakuya, what do you... nnpho!"

In this world, the custom of men caressing women's bodies isn't established. Foreplay is an act women perform to arouse men. Women become wet and ready for insertion just by seeing a man's indecent state or actually pinning him down and pressing lips and skin together—their sexual desire heightens easily. Truly a reversal world.

So it wasn't strange that Jane, realizing I was erect, thought of immediate insertion. However, for me, since a woman with an outstanding figure was clinging to me, I was driven by the desire to fully savor her body and make her moan.

I brushed Jane's disheveled hair aside with my fingers and ran my tongue along her neck. Given Jane's athletic body, she must have lived a disciplined life. Her skin felt youthful with few wrinkles for her age. It was white and smooth like bone china. Now, I could smell sweat and saltiness, but I didn't mind and licked upward. My left hand reached for her breast, covering it fully with my palm.

"Kuu... wh-what? That tickles... ahya... nn, nfuu... w-wait, there... ann! Eh, stop... nhii!"

As soon as my tongue invaded Jane's ear, I licked it all over *beron beron*. My left hand, coming from her head, extended to her other ear and touched it with delicate finger movements. My right hand cupped her breast from below, enjoying the softness of the breast flesh, while extending my middle finger to poke her erect nipple.

"Hmm? Is this a weak spot? You're making such cute sounds. I'll lick it more."

Perhaps, for her age, she hasn't had proper sexual experience. The moment my caresses began, Jane started moaning in a high-pitched voice I wouldn't have thought possible. If she resisted seriously, she could probably throw me off, but either her body wouldn't obey, or she was intoxicated by the pleasure from Yuu's—Jane seemed convinced I was Sakuya—caresses. Or both. Jane could only tremble and moan, surrendering to the caresses from my hands and tongue.

"Haa, haa, haa... as expected, Sakuya. The man I had my eye on... ooh! Wh-what's thiiis!?"

After licking her ear until it was drenched in saliva, my tongue descended from her neck to her chest. I traced her collarbone with the tip of my tongue and gave it light bites. There are individual differences, but ears, neck, and collarbone can be erogenous zones. From my experience, Jane might have a surprisingly sensitive constitution. So instead of squeezing her breasts hard, I moved my fingertips in swirling patterns as if caressing a young virgin. I teased around the nipple with the tip of my finger, softly tormenting and playing with it *kuri-kuri*. For the other breast, I used my tongue. *Chu, chu*—I teased around the mound, and for the nipple at the top, I lightly licked it with the tip of my tongue. I repeated teasing caresses without strong stimulation, edging her.

"Hyafu! Nn, nn, nnn! Wh-what... is this... aa, aa, Sakuya's tongue, fingers... m, my chest... my chesst... nnaa! It's getting damp... aah, it's hot! Fuu, fuu, fuu... aah! Sakuyaa!"

For Jane, this was her first experience of breast caresses. Being a big fan of breasts regardless of size, I meticulously adored both breasts without getting bored. Because Jane lifted her chin or shook her head as if refusing, her hair became wildly disheveled. Her translucent white skin turned pink in places and became slightly sweaty.

The nipples, continuously teased by my tongue, became like red, wet buds. The left nipple, played with by my fingers, was also stiff *kori-kori*. Glancing at Jane's heaving chest as she breathed roughly, I knew the development of her erogenous zones wasn't over. I lightly pinched her right nipple with two fingers. For the other, I opened my mouth wide and sucked on the entire nipple. The pinched nipple was pulled upward *kui-kui*, while the one in my mouth was rolled around with my tongue. Or I sucked *chuu-chuu* like a baby. I tormented the nipples so persistently it felt like milk might come out if I kept sucking.

Since her milk production was poor after childbirth and Jane herself didn't think to express milk, Kate was raised on formula. So Jane herself had almost no experience of having her nipples sucked. The nipple torment by Yuu was a bolt from the blue, shockingly impactful for Jane.

"Hyaa! Ah, ah, kuha! W-wait, Sak... ihii! Wha... vufuu! D-don't suck! Ann! I-I'm not a baby... vunn! No... no... ooaa! I-It's getting weeeird!"

Jane grabbed my shoulders painfully tight and arched her body *pin*. It seemed she came just from the breast caresses.

"Ah, ah, haa! Wai... niiii... such a plaaace... hoohin! Stop, aa... it's coming again! Ooh, ooh... niiiiiiin!"

I sat between Jane's widely spread legs. My middle finger went in and out of her vagina with a loud *jupo jupo* sound. While using my arm to hold down her thighs that tried to close, I played with her clitoris with the fingers of my left hand placed on her mons. Having squirted *pushu pushu*, not only the tatami but even my face got wet.

Jane, tormented by the fingering with both hands, shook her head as if refusing and dug her nails into the tatami, but seemed to have climaxed again. When I pulled out my middle finger, love juice dripped in strings. From between my fingers to my palm, everything was soaked.

"Did it feel good?"

There was no immediate reply. Jane hid her face with a hand covered by disheveled hair, only breathing heavily. Feeling mischievous, I brought my face close to her glistening, soaking wet crotch. A unique smell of sweat and pussy mixed together hit my nose, but I didn't mind and licked her enlarged clitoris.

"Kuhiiin! Wh-what are you doing!?"  
"What? Cunnilingus. Since you didn't answer, I thought I'd make you feel even better."  
"Sa-Sakuya... I-I've already... haan! Yaa! Any more and I'll... really go... crazy! Hyaa! I said don't do that! Hii... Noooooooo!"

Of course, her genitals, but now, due to Yuu's techniques, Jane's sensuality as a woman had rapidly blossomed, showing high sensitivity wherever stimulated. I reached out and kneaded her breasts, pinching both nipples alternately. Or slid down to her stomach, playing with her navel visible through the twisted bandages. Instead of inside her vagina, I used several fingers to spread her labia minora, making lewd *kucha kucha* sounds. I moved my tongue from her clitoris to her inner thighs. Then suddenly, I pinched her clitoris with my fingers and stroked it. After such caresses, Jane stretched her toes *pin*, trembled *bikun bikun*, and seemed to have come again.

Then, I took off my underwear myself. Of course, the one-eyed monster in my crotch was fully erect, rock-hard. Though my body had warmed up, I was still wearing my top. Jane, who had been made to come multiple times by me, seemed breathless, but her slightly open pussy, having been fingered, twitched as if craving something. The female hollow accepting the male symbol. Settling where it should be. It seemed she sensed the moment her wish would be fulfilled and showed an expression of joy.

Jane must have felt it when I pressed my hips and my hot, hard cock touched her sensitive spot. Flustered, Jane lifted her upper body slightly and looked toward her crotch. Even from her position, her eyes caught the cock protruding from her mons. Instantly, she opened her eyes in shock.

"Wh-wh-what is that?"  
"What? It's my dick. Isn't this what you wanted? I'm putting it in?"  
"Wait! It's different from John's... s-something like that going in..."  
"I don't care. I can't hold back anymore."

Jane, who had been so full of eagerness to push me down, why was she panicking now? John must be Kate's father. Even though American men's genitals are larger on average, Jane panicked as if she were a virgin, which I found amusing.

Even though Jane was alone, when I first faced her, I didn't feel I could handle her by force. There's a story called "The Sun and the North Wind." It's about the Sun and the North Wind competing to see who could make a traveler take off his coat. If force (North Wind) didn't work, then I had to subdue Jane with pleasure (Sun), even if it took time. That's why I took my time with the foreplay. So far, it's going well. Now comes the main event. With her legs spread, I pulled my hips back slightly to adjust the position, then thrust in deeply.

---

### Author's Afterword

### Chapter Translation Notes
- Translated "ちゅぷちゅぷ" as "chu-pu chu-pu" to transliterate kissing sounds
- Translated "じゅぽじゅぽ" as "jupo jupo" for wet penetration sounds
- Preserved Japanese honorifics (none used in this passage)
- Maintained original name order: Hirose Yuu, Jane Grimwood
- Translated explicit anatomical terms directly: "チンポ" → "dick", "クリトリス" → "clitoris"
- Rendered sexual acts without euphemisms: "クンニ" → "cunnilingus"
- Italicized internal monologues and sound effects per style guide
- Translated "太陽と北風" as "The Sun and the North Wind" (Aesop's fable reference)
- Used gender-neutral "they" when original Japanese subject was ambiguous