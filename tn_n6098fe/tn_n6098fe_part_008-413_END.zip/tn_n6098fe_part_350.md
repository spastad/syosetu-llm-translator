## 328. The End of Obsession ⑨ ~Limit LOVERS~

"O, o, o... this is... ah, how could..."  
"Gyaaah! N-no... oooh, oooh, so thick, my... it's entering... gweh!? St...still?"

Slowly but surely, the penis pushed forward as if spreading the vaginal flesh apart, thumping against the deepest part of her womb.

"Ghyiiin! A...ga...wha...re...gyeeeh...kwa"

Jane threw her head back and arched her body. Her breasts shook violently with the motion.  
Grabbing Jane's firm thighs to spread them wider, Yuu smoothly completed the insertion, but was overwhelmed by pleasure beyond his expectations.

Having bedded numerous teenage virgins, Yuu had assumed that given Jane's mid-30s age and status as a mother, her tightness wouldn't be remarkable. He'd even thought she might be loose.

Jane possessed normal sexual desire and would act boldly when opportunity arose. She'd seized the perfect chance to rape a man and become pregnant. After starting work in Japan, she gained the financial means to buy men too.

But her first experience had been so anticlimactic that her obsession naturally faded. Had Sakuya been her partner, it might have been completely different... That thought had condensed over the years, like a beautified memory of first love.

Thus, Jane hadn't had sex since giving birth, her vagina tightly closed for 16 years. Moreover, her habitually trained body resembled that of a woman in her twenties. Incidentally, compared to her first partner, Yuu's cock was nearly twice as long and thick, with incomparable hardness.

With all these factors combined, Jane was shocked by Yuu's cock, while Yuu was stunned by the unexpected tightness. Pleasure surged through his back and waist, leaving him momentarily immobile.

It wasn't physically as tight as a teenage virgin. Insertion had been effortless, but the moment it reached the depths, her womanly parts seemed to rejoice at the long-awaited penis, gripping it tightly as if never wanting to let go. If he moved freely, he felt he'd ejaculate instantly.

For some reason, Jane trembled in small spasms, emitting intermittent sounds like a broken speaker. Having calmed slightly, Yuu decided to proceed at his own pace.

Her weakly spread legs remained as they were. He firmly grasped the area slightly above her protruding hip bones with both hands. Then, instead of thrusting, he made circular motions while buried deep inside her. He started gently - drawing small circles like a drill while occasionally lightly thumping the depths.

"Kyahi! S-Sakuya! Wai... oooh, oooh, inside, being scooped... ah, ah, ah, no, nooo... I'm gonna, cum again!"  
"Jane, does it feel good or bad? Which is it?"  
"Wh-what kind of... question! It feels so good... I could ascend to heaven! Ahh! Sakuya, SakuyaSakuyaSakuyaSakuyaSakuyaaaaaaah!"

Jane suddenly sat halfway up. Tears welled in her eyes as she made a desperate expression. Seeing this face for the first time, Yuu stopped moving in surprise.

Jane stretched out her arms and pulled Yuu toward her, sealing his lips. Due to their height difference, Jane had used her abdominal strength to sit up while Yuu couldn't reach by leaning over. Jane bent her body to pull Yuu in, causing the deeply inserted cockhead to scoop upward against her descended cervix.

"Mmmph! *Smooch*, slurp, mmphaa... hah, hah, this is... sex... the real sex with Sakuya I longed for... gyaaah! I never knew... it could be this amazing! Nngh! Hoh! Sakuya's cock, my... deeep, deeep place... ooh... I didn't know this! Haaahn! *Squelch*, schlick, mmchuuuuu~~ *Lick*, *lick*, ampfhuuu... never letting go... Sakuya! Ah, ah, ah! Cumming, cumming, Oh! Yes! Come on!"

Jane revealed a completely different face from when they first met - a thoroughly melted female expression as she desired Yuu. The occasional English mixed into her moans seemed unconscious.

Yuu could barely move. Rather, he couldn't move. Jane's arms were wrapped around his back, and her long legs crossed around his waist, holding him in place. While their lips locked and tongues tangled, she unconsciously ground her hips, bringing herself to the brink.

Yuu had intended to take the lead in this sex. Regardless of other women, he couldn't accept the current situation. He'd been determined to make Jane climax until she lost consciousness.

"Jane? Jane?"  
"Hah, hah, ahn! What is it, Sakuya?"  
"I'll make you feel even better. Let me take over."  
"Ahaa... as expected, Sakuya's different from other men! So... I'll leave it to Sakuya!"

Until now, they'd been in a position between missionary and seated facing. Yuu used both hands to free Jane's legs and grabbed behind her knees. Pushing them forward while simultaneously leaning his hips forward, still connected. The motion caused deep thrusts into her vaginal depths, making Jane tighten her grip on Yuu's shoulders.

Jane's back touched the tatami as Yuu pressed his weight fully atop her - the impregnation press position.

"Ghoooooooh... th-this, your cock... ack... Sakuya's cooock, so deeeep!"

Normally, Jane would never accept such an undignified position - spread open and pinned down by a man. But Sakuya was special to her. More than the facts she learned after coming to Japan, her beautified memories had now materialized, making this moment most precious.

"Alright, I'm moving. Keep your senses until the end, okay?"

Jane nodded repeatedly at Yuu looking down at her closely. Her arms around his back held with painful strength, as if never letting go.

*Squelch... squelch-glup.*

"Oh... oh... ohi! Sakuya, Sakuya! Gyaaah gyaaah, heh! Again... c-cumming... vvuuun! Gyaaah! Mooore... ghyiiiiin!"

Lewd sounds played from their joining with each swing of Yuu's hips. Slowly pulling out, then plunging down. Simple repetitive piston motions. But the upward-facing glans stroked the vaginal walls from the G-spot onward. When reaching the depths, it forcefully pushed up the cervix. Each stimulation of her childbearing organ made Jane sob with ecstasy. During withdrawal, the ridge of the glans gave a scraping sensation as if dragging vaginal flesh.

When pulled nearly out, cloudy genuine juices *gloop*ed out, trailing down her butt crack and staining the tatami.

Current Jane believed her wish had come true - making love with Sakuya. As if returned to her teenage years when she knew nothing. She could leave everything to Sakuya. Everything would be fine. Indeed, her female sensuality was in full bloom.

Within just 1-2 minutes of Yuu starting, Jane reached climax after a few thrusts, her vision turning white as if floating in heaven. Afterward, she was tossed about by Yuu's disciplining hip movements, kept shaking at pleasure's peak.

"Jane, despite your personality, you're young, beautiful, with an amazing figure. Plus your body's sensitive and responsive, and your pussy grips so tight. Aren't you the perfect woman?"  
"...!"

Yuu's first impression of Jane had been frightening, and kidnapping Sayaka and Kate was unforgivable cruelty. His hatred hadn't lessened. But now, as man and woman during sex, he praised her.

Jane's blue eyes widened, her pink cheeks flushing crimson. Recognizing Sakuya's praise, hot emotions surged, her female instincts tingling intensely. Unconsciously, her body began preparing to milk her beloved man's semen, her vaginal folds contracting more than before to stimulate his cock.

"Kuuuu... I wanted to savor this longer but... it's about time for me too..."

Yuu himself had endured with slow movements against the vaginal folds clinging to his entire cock. But his body craved more stimulation, his movements gradually speeding up.

Pressing down as if smothering her, Yuu rubbed his cheek against hers. His hip movements accelerated, *slap slap slap* sounds echoing like drums. Yuu's breathing grew ragged, his hot breath warming Jane's earlobes. Their clinging skin grew sweaty, making even the chilled room feel warmer.

"Gah! Gah! Gah! Vuh! Ooh! Sakuya, Sakuya, Sakuyaaaah! Yes! Yes!...Oh! Come on!"

Jane couldn't distinguish between climaxing and not. She could only cling tightly to Yuu's back and utter meaningless words. She wished this moment would last forever, calling her beloved's name.

Yuu continued moving toward ejaculation, but his limit approached. His cock swelled to its limit, ready to burst.

"Cumming... now! Jane! I'm filling your insides with cum!"  
"Kyafu... nn! Nngh! Sha-Sakuya's coock... swelling inside me... Oh... oh... amazing!"  
"Guoh!"  
"Nhi!"

Pressing the tip deep inside, Yuu reached climax. *Throb, throb* - semen spurted out with strong pulses. Perhaps feeling the semen filling her womb, Jane threw back her head, gaping upward. Her vision blurred as consciousness nearly fled, but she tightly embraced Yuu through the moment.

"Hah... phe... Sak...ya... What? Naaaaaaah!? I-in... wai... already..."  
"Did you think one round would satisfy me? I can still cum. I'm using your pussy again. There, there!"  
"Ah, sto, hyii!"

Not long after the first ejaculation, Yuu flipped Jane onto all fours and inserted himself again despite her surprise. Back-to-back sex was routine for Yuu. Moreover, his sexual preference was to fuck tall, well-built, strong-willed women like Jane from behind.

For Jane, everything was a first: multiple orgasms from foreplay, being pinned down by a man, having a cock inserted to her depths, consecutive internal orgasms. Though confident in her stamina compared to peers, she was now thoroughly exhausted. Being fucked from behind on all fours, she lost strength within minutes, collapsing face-down with folded arms. The difference between Yuu who'd slept and Jane who pulled an all-nighter showed here.

*Paah!*

"Hyau! Haah... aahn!"

Seeing Jane presenting her ass, Yuu slapped it as a wake-up call. Though muscular, her spread buttocks were soft, making a nice sound when slapped. Plus, her pussy tightened nicely. Grabbing her waist firmly with his right hand while thrusting, he slapped her ass with his left. After several slaps, he switched to his right hand. Soon both buttocks turned monkey-red. Jane adapted to being fucked backwards while spanked. Though spanked tearfully as educational discipline in childhood, now Sakuya was doing it - her brain interpreted it as loving play.

Her cries weren't from pain. Drool dripped from her mouth, her moans sweetening.

"Ahe, hahe... no... my body..."  
"Oh!?"

Finally, Jane's knees seemed to give out. Her legs spread limply. Yuu's grip on her waist prevented disconnection, but he reconsidered, supporting her as they fell forward together - the prone position.

Her first time had lasted under 10 minutes total - anticlimactic with little pain or pleasure. Compared to that, sex with Yuu brought incomparable pleasure and fatigue - like the difference between a fluorescent bulb and midsummer sunlight. Though spanking stopped, Yuu covered Jane's back with his whole body. With both hands firmly securing her, he began thrusting. For Jane, heaven and torment progressed simultaneously. Though happy to be pressed by Yuu, her body needed rest. Emotionally, she wanted more Sakuya. Yuu responded by thrusting.

*Squelch! Squelch! Squelch!*

Each time Yuu's hips struck her covered back, satisfying sounds rang out. Inside her vagina, semen and love juices mixed *gloopy*, becoming true love juice. When Yuu pulled out, thick cloudy fluid spilled, the tatami stain spreading visibly even in dim light.

"Hah, hah, hah... this feels good too. Whether thrusting or pulling, your pussy grips my cock so tight! Kufuu, my hips... won't stop! Jane, does it feel good?"  
"Vuaaaaah... feels so gooood... ooh, foh!"

Though ejaculated once, Yuu's stamina and vigor remained excellent. In contrast, Jane seemed at her physical limit. She reacted but lay panting, at Yuu's mercy. It resembled insect or amphibian mating - consecutive reproductive acts. But only Yuu was energetic; Jane looked like a human onahole with limp limbs.

Strong vaginal stimulation brought intense pleasure. After multiple climaxes from the position change, Jane nearly lost consciousness. But each hip impact made her body react, pulling her back. What felt like eternal intercourse to Jane ended in about ten minutes.

"About time, Jane! Take my second load deep inside!"  
"Gah! Gah! Gah! Fuhaa... ooh!"

Jane could no longer respond properly. Peeking at her sideways face showed drool dripping. Only when her depths were struck did her chin jerk up, emitting meaningless moans.

Ignoring her, Yuu firmly grabbed her sturdy shoulders for the final sprint toward ejaculation. *Squelch, squelch* - flesh-slapping sounds grew louder and faster. Only voiceless groans came from forward-facing Jane.

"Vuh! Gyaaah! Jane! Cu-cumming! Kuhaa!"  
"Sa-Saku...ya... ha, hyuu!"

Pressing the tip deep inside, grinding against her cervix as if prying it open, they reached the end. *Throb throb throb* - semen equal to the first load gushed out, filling Jane's womb.

After ejaculating, Yuu remained covering Jane's back until fully spent. Pleasant lethargy followed the intense climax. But he knew he couldn't stay forever. Fortunately, Jane seemed immobile too.

"Phew"

Catching his breath, Yuu pushed off Jane's back with his left hand while withdrawing. *Gloop* - cloudy fluid leaked from her vaginal opening as his cock pulled out. Having been stretched wide and packed with two loads, it kept spilling. Desire cooled, Yuu in sage mode carefully separated while watching Jane.

Jane's ragged breathing sounded, her back rising and falling. After being attacked so much and climaxing repeatedly, it was unclear if she remained conscious - seemingly half-asleep.

Yuu stepped over Jane's right leg to her right side. In a crouch-start-like pose, he raised his right hand. The oddly shaped ring gifted by Ryoko last December was on his ring finger. Yuu gulped. His pleasure-filled expression turned tense.

"Uu... Saku...ya..."

Jane's voice sounded. Currently limp with no sign of rising. Yuu wished she'd just fall asleep. But if she regained energy and got up, it'd be troublesome. He couldn't hesitate anymore.

Bringing his right hand forward, Yuu pinched the ring's round edge - about yen-coin sized - between left thumb and middle finger. Pressing firmly while sliding the lightning-patterned round part with his index finger. *Click* - the lid opened, revealing a plain silver surface.

Unnoticed by Jane, she lay face-down. Still believing Yuu was Sakuya, she showed no vigilance, completely relaxed. Yuu brought his right hand toward Jane's right flank. The moment the ring surface touched her:

"Gyiiiih!"

The ring chosen by Kate and Ryoko. More than decoration, it was made for male self-defense. Admittedly, within their budget, it wasn't high-end. Still, properly used, it delivered stun-gun level electricity. Not enough to knock out, but causing intense pain and temporary immobility.

The part touching the user's skin was non-conductive rubber, but contact with another body would cause collateral shock. The drawback: single-use only. Needed recharging at a specialist shop. Plus poor usability.

After the electric shock to her exhausted body, even Jane couldn't endure. Her limbs stretched taut then went limp, splayed out. Peeking at her face, she wasn't dead - just unconscious. Confirming this, Yuu finally sighed in relief.

---

### Author's Afterword

Though not depicted, Kate remains bound and watches Yuu and Jane's sex. Given the flow, having Kate join for a mother-daughter threesome... would be impossible. Yuu worked extra hard to subdue Jane.

The ring was given by Ryoko in Chapter 292 when she visited the apartment. When Sayaka learned it was for self-defense, she insisted Yuu must accept it - perhaps anticipating this situation. At Chapter 292, I hadn't specifically envisioned Yuu being attacked, but chose the ring as a weapon usable even if stripped naked.

Long ago in Legend of Galactic Heroes, there's a scene where a soldier pretending to betray his lord attends an inspection ceremony planning revenge. He fires a weapon hidden inside a corpse, but as backup, shoots a beam from his ring (killing an important figure). That left an impression.

I recall other manga/anime with ring weapons too. Beams are impossible, but real rings have hidden knives. In this male-weak world, I made it a disposable mini-stun gun to incapacitate a single attacking woman.

### Chapter Translation Notes
- Translated explicit anatomical terms directly: "膣" → "vagina", "男根" → "penis", "精液" → "semen"
- Preserved sound effects: "ずちゅっ" → "*Squelch*", "ぱんぱんぱん" → "*Slap slap slap*"
- Maintained Japanese name order: "広瀬 祐" → "Hirose Yuu"
- Translated sexual acts without euphemisms: "セックス" → "sex", "挿入" → "insertion"
- Rendered internal monologue in italics: None present in main text
- Used explicit terminology for bodily fluids: "愛液" → "love juices", "本気汁" → "genuine juices"
- Preserved cultural references: "銀英伝" → "Legend of Galactic Heroes"