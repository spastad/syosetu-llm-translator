## 329. The End of Obsession ⑩ ~Longing to See You~

### Author's Preface

I noticed a review was posted on the same day I uploaded the previous chapter, but I forgot to write my thanks.

I express my gratitude here. Thank you very much!

Reading 349 chapters in one go? Amazing!

---

Jane had lost consciousness, and perhaps because the tension drained away when poking her elicited no reaction, Yuu lost his balance and nearly fell backward.

When he barely caught himself by putting his hands on the tatami, he remembered Kate was behind him.

Startled, Yuu turned around and met Kate's eyes.

Kate sat slumped before the closet door, wrapped in a blanket. She appeared almost unchanged from when Jane had arrived.

No—Kate was leaning slightly forward, her blue eyes wide open as she stared intently at Yuu.

He felt as if she was looking at his entire body, especially his lower half, but perhaps it was just his imagination.

As Yuu thought this, Kate immediately averted her gaze. She seemed to be mumbling something, but with the ball gag still in place, it was impossible to understand.

How long had it been since they were drugged? Where were they? Were Kanako and Touko safe? Were Jane's associates nearby? Countless things needed confirmation, but immediate options were limited. Priorities had to be set.

Steeling himself, Yuu reconsidered approaching Kate first.

He rummaged through the pockets of the clothes Jane had haphazardly discarded.

He found what appeared to be house keys, but that wasn't what he sought.

Searching the coat pocket, he found two thin, small keys fastened to a ring and smiled.

"I'll free you now. Then, sorry to ask, but could you help me? This time we'll restrain Jane."

Using the keys, he first removed the handcuffs from her wrists and ankles.

He hesitated momentarily about touching her hair, but since it was necessary to remove the gag, he casually reached behind her head and unfastened the belt-style ball gag.

For some reason, Kate's ears remained bright red as she immediately covered her mouth with her hand.

Yuu guessed she must have suffered from having the foreign object in her mouth for so long—she kept opening and closing her mouth while pressing her hand against it.

Next, she rubbed her formerly handcuffed wrists while looking up at Yuu.

"Th-thank... thank you."  
"You've been through a lot too, Kate. I want to ask many things, but we must hurry."

Yuu smiled at Kate, who thanked him in a voice so faint it seemed ready to vanish.

"...! Yeah... okay. Okay, but! At least put on your underwear!"

When Kate shouted with a bright red face, Yuu realized he'd been standing there with his penis dangling freely after sex, without even wearing underwear.

After properly dressing—except for the coat—Yuu worked with Kate to restrain Jane.

Using the handcuffs that had been on Kate, they fastened Jane's hands and feet.

Using the ball gag as-is felt wrong, so instead Yuu took a hand towel from the closet to use as a makeshift gag. They also wanted to avoid noise if she woke.

The bloodstain on her left flank seemed to have grown larger, but as amateurs they couldn't risk tampering improperly. They could only tightly wrap her with the least stained sheet from the closet.

They avoided dressing her, instead swaddling her in blankets and futon covers like a mummy, securing her tightly with torn sheet strips in two places. Finally, they could breathe easier.

Fortunately, Jane didn't regain consciousness during the restraint.

"Alright. Jane's handled. First, where are we?"  
"Probably a small island in the Sea of Japan. Maybe deserted now. Anyway, it's a solitary house built in the mountains."

According to Kate, after being abducted they were forced to switch cars at another service area.

At that point, Jane's group had taken Sayaka elsewhere, leaving Kate with two women in their twenties.

Kate could have overpowered them if she tried.

But they threatened that if she escaped or missed a check-in, they couldn't guarantee Sayaka's safety, leaving Kate no choice but to comply.

By then, Kate suspected Jane's target might be her, and she felt intense guilt over possibly dragging Sayaka into this.

After several hours of driving, just before sunset they boarded a fishing boat and arrived at the island. From the dock, they came here by light truck.

Though handcuffed, she wasn't blindfolded. However, they encountered no one along the way, so she couldn't call for help.

After arrival, she received a simple meal and was allowed bathroom breaks.

She spent time under the two women's watch on the first floor until late at night, when they took her upstairs and locked her in this room's closet.

Shivering from cold in the cramped, musty, dusty closet, Kate drifted in and out of sleep.

Sometime late at night or early morning, she heard voices and footsteps approaching—likely when Jane brought Yuu.

Restrained and confined, Kate was in terrible physical and mental condition, too frightened to draw attention and remaining perfectly still.

Eventually she fell asleep, and it remained quiet with no signs of anyone until morning.

Yuu briefly recounted his own experiences: negotiating with Jane, being taken aboard a submarine-like vessel with two protection officers, then being locked inside and drugged with what seemed like anesthetic gas.

When he mentioned Sayaka was likely safe with the protection officers, Kate showed visible relief.

While talking, Yuu noticed Kate shivering. He'd used the blanket he gave her earlier to wrap Jane.

The closet might have more, but after being confined there, Kate probably couldn't stand the dust and mildew anymore.

So Yuu picked up the coat he'd discarded after being stripped and draped it over Kate's shoulders as she sat on the tatami.

"Huh? What about you...?"  
"I warmed up exercising earlier, so I'm fine. You must be chilled."  
"Ugh... That considerate side of yours... hasn't changed. Thank you."  
"Don't mention... huh? What's wrong?"  
"Eh? That's strange. Why—"

Yuu was startled to see tears suddenly spill down Kate's cheeks. Kate herself seemed flustered by her own crying.

"Here, use this."

Yuu took a handkerchief from his pants pocket and handed it over. Without a word, Kate bowed her head slightly and pressed it to her eyes.

"How unusual. A man with a floral handkerchief. And it smells nice."  
"Ah, that's..."

Last December, Martina had told Yuu to deliver premium Western sweets to Sayaka as thanks for her constant help. Having been born and raised in Japan, Martina likely intended it as an end-of-year gift—she regularly exchanged letters and gifts with the Komatsu, Hanmura, and Ishikawa families.

In return, Sayaka and the other two sent handkerchief sets addressed to Martina and Elena. Yuu happened to be using one from that set.

"It's a woman's handkerchief. Fufufu."  
"I got it at home..."

Yuu didn't understand why Kate laughed that way but felt oddly embarrassed. At least her tears had stopped—a relief.

Surely Kate had been frightened, confined alone in this place. Normally he'd want to hug her, but Kate remained a friend with boundaries. Plus, her earlier "underwear" comment reminded him she was reborn in this world with the same chastity values as his original world.

He couldn't touch her casually like usual. Their first meeting remained a painful memory—when he groped her breasts during their motorcycle ride, she elbowed him.

Yet the joy of confirming her safety and wanting to comfort her moved Yuu's hands.

"...!"  
"Thank goodness... I'm so glad you're safe."  
"Yeah..."

Instead of the right hand holding the handkerchief to her eyes, Yuu clasped Kate's left hand with both of his.

Perhaps sensing his concern, Kate didn't pull away—instead she lowered her handkerchief-holding right hand and clasped back.

They gazed at each other from close range.

Yuu knew Kate's inner self was that of a fellow forty-something single woman.

But her appearance—blonde hair, blue eyes, lips pale from cold yet skin flawlessly fair like new snow—was that of a perfect beauty with an aura far beyond sixteen. Her initial cold demeanor had vanished, replaced by moist eyes gazing at Yuu.

No man could remain unmoved.

But even Yuu considered time and place, refusing to be swept away by desire.

"I'll check downstairs. Kate, wait here."

As Yuu smiled and tried to withdraw his hand, she gripped it tighter.

"Um..."  
"Don't go."  
"Huh?"  
"Ah! Th-that just now... wasn't! Forget it! It didn't happen!"

For a moment Yuu thought he misheard, but Kate had definitely said "don't go"—and now her face flushed crimson as she hid it with both hands.

Yuu found Kate's mannerisms adorable.

Though both were forty-something inside, they resembled bashful sixteen-year-olds. Just as Yuu thought this, a loud clatter came from downstairs.

Until now, there'd been no sounds or voices—he'd almost convinced himself they were alone. Or rather, he'd hoped they were.

But had guards been lying low? Or had Jane's associates returned? The latter seemed more likely.

Yuu and Kate exchanged serious looks.

"Something we can use as a weapon..."

Even with the main culprit Jane restrained, capture by her associates would undo everything. They stood on the brink of freedom.

Yuu went to Jane's piled clothes and searched. He found an automatic pistol in a belt holster—not a revolver.

It felt heavy in his hand.

"Th-that..."  
"Ever fired one?"  
"Of course not!"  
"Shh! Quiet!"  
"S-sorry."

Yuu had never fired one either and barely knew how to use it. The gunpowder smell when he drew it suggested Jane had recently used it.

He didn't know if it was loaded or how to check. But he recalled from movies that the hammer must be cocked before pulling the trigger.

"I've heard amateurs can't hit anything anyway. We'll only use it for intimidation."  
"Y-yeah. And if they're unarmed, we can handle it. I'll vent all my frustration from being locked up here."  
"That's the spirit."

Yuu smiled awkwardly at Kate, who clenched her fists. With Kanako and Touko's whereabouts unknown, they had to fight their way out. At least having Kate beside him was reassuring.

After the loud noise, silence returned. No footsteps approached the stairs—an eerie stillness.

The room held no proper weapons. But weapons could hinder if unfamiliar, and Kate insisted her combat skills could handle unarmed opponents.

Yuu grabbed the doorknob he'd closed earlier and looked back at Kate. She'd removed the coat he gave her for mobility and stood ready, fully motivated.

Yuu opened the door silently.

Beyond lay a dingy hallway with stained white walls and wooden floors—utterly ordinary.

Hiding his body, he peered around the corner. No sounds, no signs of movement.

He hoped the earlier noise was just a rat. Yuu stepped into the hallway—and the floorboard creaked, making him panic.

As Kate described, this was the second floor of a house. The hallway revealed three rooms—they'd been in the middle one.

Next, he'd check the stairs. Yuu signaled Kate, still inside, who nodded silently.

"Huh?!"

When Yuu turned right toward the stairs, he gasped speechlessly.

Because Kujira Touko stood suddenly before him.

"Yu... Yuu-shaaamaa"

Tears fell like dewdrops from her eyes.

Before he knew it, Kanako leaned over from the stairs, peering down. Tears welled in her eyes too, but she fiercely wiped them with her sleeve.

"Touko-chan, Kanako-san... Ah, thank goodness. You're safe."

It should have been a touching reunion. Yuu moved to hug them, but unexpectedly Touko dodged past him. Rather, she threw open the door behind him, checked inside, and shouted "Clear!"

Kanako instantly closed in beside Yuu, taking a protective stance behind him. By then Yuu understood their intent—Kanako was guarding him.

After confirming the adjacent rooms were empty and seeing Jane swaddled in futon in the room where Yuu and Kate had been, the two finally relaxed.

Simultaneously, Touko leaped into Yuu's arms, crying. This time Yuu reached out to Kanako, whose cheeks were wet with tears, and the three celebrated their safety.

---

### Author's Afterword

Next chapter will cover how Kanako and Touko reached the house where Yuu was held.

### Chapter Translation Notes
- Translated "貞操観念" as "chastity values" to maintain thematic consistency with the novel's title
- Rendered "チンチンブラブラ" as "penis dangling freely" for anatomical accuracy per style rules
- Preserved Japanese terms like "tatami" and "futon" as culturally specific items
- Translated "猿轡" as "makeshift gag" to convey improvised restraint method
- Kept honorifics (-chan, -san) and name order (Kujira Touko) per fixed rules
- Transliterated sound effects: "ガタっと" → "clatter", "ぽろぽろ" → "like dewdrops"
- Used explicit terminology for sexual references ("penis", "groped her breasts") as required