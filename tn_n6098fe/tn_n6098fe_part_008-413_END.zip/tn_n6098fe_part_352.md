## 330. The End of Obsession ⑪ ~Over Drive~

When Kanako and Touko awoke, they instantly noticed Yuu was gone and panicked intensely.

Even if the enemy possessed guns, even in a situation where they were overwhelmingly outnumbered, their protective instincts for Yuu were far from cowardly.

But they hadn't anticipated the enemy using gas as a sneak attack.

Amidst the irresistible drowsiness, they remembered being pressed close against Yuu until losing consciousness.

High-ranking protection officers like Kanako and Touko undergo special training to withstand carbon monoxide from fires or tear gas used in riot control. However, gas that induces gradual drowsiness isn't used in real operations, so they couldn't resist it.

Though unavoidable, they blamed themselves for Yuu being abducted while they slept.

But they couldn't afford to wallow in regret. First, they had to escape this situation. They banged on the door and shouted, but no one responded. Though voices could be heard from a distance, no one paid them any attention. Apparently, once they'd taken Yuu, his female guards were deemed unnecessary.

Even when the physically imposing Kanako body-slammed the door, it didn't budge. They searched every corner of the room but found no weak points to break through. As trained protection officers, they'd practiced escaping confined rooms. If this had been a wooden structure, they might have managed. But as confirmed when they were locked in, the walls, floor, and even ceiling were all welded or riveted steel. As Kanako initially suspected, this was likely a submarine storage or armory. For watertight integrity, there weren't even unnecessary air vents.

They were confident they could counterattack if someone entered for surveillance or interrogation. But being left unattended left them no options - completely trapped.

Just as heavy silence fell between them...

Doooooon!

A deep bass rumble resembling an explosion echoed, shaking the floor beneath them. Since they were near the stern, the explosion sounded dangerously close. Kanako and Touko instantly moved near the door and dropped prone.

Explosions seemed to have occurred at two locations - one very close and another slightly farther away. They heard the eerie sound of metal groaning and violent water currents. If Yuu had been there, he might have recalled tsunami footage from the major earthquake years ago.

Kanako and Touko stayed low for protection but raised their heads at a loud banging sound against the wall. The welded section of the wall they'd leaned against with Yuu had burst open, likely weakened by the first explosion's impact. Torrents of water came flooding in.

Now effectively wall-less, the rapidly flowing water quickly filled the room. As the water rose past Kanako's knees toward her waist while standing, they realized inaction would mean suffocation. But crisis meant opportunity - this influx meant another exit had opened. After exchanging glances and nodding, Kanako and Touko took deep breaths.

Just before the water reached chest level, they dove into the water toward where the wall had been.

---

"Haah... haah... haah... Where... is this place?"  
"Look, Neki (Kanako's code name). So many... dead."  
"What?!"

Battered by incoming currents yet fighting desperately, they swam through the stern breach. Dodging randomly moving debris underwater, they surfaced closer than expected - the pier looked nearer than a 25-meter pool. But swimming clothed in piercingly cold water made it feel many times farther.

By the time they reached the pier, the water was shallow enough for Kanako to barely touch bottom. Too exhausted to climb the pier pillars, they collapsed upon reaching shore.

Their clothes were torn in multiple places from debris during the escape, and blood seeped from their skin, but fortunately no deep wounds. The real problem was the cold. Their bodies felt frozen to the core as if locked naked in a freezer, teeth chattering uncontrollably, shivers unceasing. In this state, searching for Yuu was impossible.

Looking ahead, they saw what appeared to be a dimly lit cave. Touko, who'd followed closely behind Kanako, pointed forward. On a flat, open area, a group of people lay motionless. Blood pooled everywhere, with no signs of movement among the fallen. Touko's assessment of "so many dead" seemed accurate.

First, they checked for Yuu. Most wore matching military-style uniforms like those seen on the submarine - women who appeared Japanese but likely mainland Chinese based on their speech. Then Jane's two associates and two unfamiliar young women. Though Jane and Yuu were absent, a trail of blood droplets led deeper into the cave.

Touko didn't remember, but Kanako recalled hearing arguing voices before losing consciousness. This suggested infighting escalated to killing, and the survivor Jane likely took Yuu. Was the blood from Yuu getting caught in the crossfire? That possibility couldn't be dismissed.

Kanako and Touko desperately wanted to search for Yuu immediately. But in their current state, they'd collapse from exhaustion soon. That would help no one. Their first action was to revive the nearly extinguished campfire and warm their frozen bodies.

Submarine crew members seemed to have escaped after them, but many sank after losing body heat to the cold seawater while injured. Some reached the pier but lacked strength to climb. Kanako and Touko felt no obligation to help them nor any sympathy. Their sole purpose was preparing to find Yuu.

Soaked through, they couldn't wait for clothes to dry. Stripping to underwear, they took clothes from similarly built corpses. They also took useful items: portable rations, canteens, pistols with remaining ammo, and flashlights - all fruits of their military/special forces training. They'd do anything to achieve their goal.

After about an hour warming up, eating lightly, and recovering strength, Kanako and Touko pursued Jane - who'd likely taken Yuu - deeper into the cave.

The cave sloped upward with several branches. The blood trail disappeared, possibly due to止血 (wound treatment), forcing them to choose paths intuitively. After climbing considerable distance, they emerged in a mountain valley around mid-slope. Sparse trees gave way to snow-covered terrain.

Where to go next? Deep snow in unmaintained mountain paths. Impatience was forbidden now - wandering blindly in snowy mountains would be fatal. Kanako decided to reach a ridge with clearer visibility.

Pushing through chest-deep snow on pathless terrain was grueling. They slipped repeatedly in the snowpack, causing scary moments. They knew climbing snowy mountains without proper gear was suicidal. Yet they pressed on - driven by protection officer pride and their determination as women to find and rescue their beloved Yuu. Their strong feelings for Yuu seemed to give Kanako and Touko boundless energy.

On the ridge, winds strengthened but snow lessened. Carefully scanning slopes while avoiding slips, they searched for suspicious locations where Jane might have taken Yuu. Driven by restless anxiety, they searched along the ridge for over 30 minutes until Touko - with 20/20 vision in both eyes - called out.

By then, they'd realized this was a small oval-shaped island about 10km across. The sun's position through cloud breaks indicated morning. Northwest featured sheer cliffs, while southeast coastal areas had minimal flatland with what appeared to be a settlement and dock.

Kanako and Touko stood on the mountain range occupying most of the island. A winding road snaked down the southern slope to the base, with a solitary house midway. The steep triangular roof typical of snow country stood out - luckily, fallen snow revealed red coloring. No other buildings appeared until the base. About 1km straight-line distance. They headed there.

---

"Ahh, thank goodness. Truly wonderful. So glad you're safe... so happy to see you unharmed."  
"Ha, hah..."  
"Yu, Yuu-sha... ah, haaah"

Overwhelmed with relief, Yuu, Kanako, and Touko collapsed together. Yuu held Touko on his lap with his left arm while pulling Kanako close with his right around her shoulder. He rubbed his face against Touko's head and Kanako's ample chest as if confirming they were real, not illusions. Though their bodies carried scents of sweat, sea, and faint blood from their clothes, Yuu didn't mind at all. Having imagined worst-case scenarios, the warmth from their bodies was his greatest comfort.

Kanako and Touko also cried uncontrollably seeing Yuu safe while feeling such relief they nearly lost strength in their legs. But until confirming all upstairs rooms were empty and no threats remained, they couldn't relax. Finally catching their breath, they exchanged embraces with Yuu. That said, this remained enemy territory - they needed to contact outside or move immediately. Yet held tightly by Yuu, they couldn't move... no, they genuinely didn't want to.

"Umm... could we wrap this up soon?"  
"Ah, sorry."

Yuu released Kanako and Touko only after Kate - left alone - spoke up. Reuniting with Yuu and the passionate embrace had left Kanako and Touko physically and emotionally shaken, cheeks flushed with temporary excitement. Still, when turning toward Kate, they instantly regained their professional protection officer expressions - impressive indeed.

The loud noise downstairs earlier came from Kanako and Touko immediately after infiltrating. Observing the surroundings, they'd seen one parked kei truck but sensed no people. The front door was locked, so they broke a back window to enter. Though the breaking sound was small, the dark interior and exhaustion from hours of walking since resting in the cave caused even Kanako to trip on the cluttered floor. Touko's expression at that moment was terrifying, Kanako later admitted.

They checked on Jane confined in the closet but found her still tightly bound with no signs of waking. After locking the closet door for safety, all four moved to the first-floor living room to exchange information. Before entering, while checking the house perimeter, Kanako had seen the address on the mailbox - though no resident name was listed. It appeared to be Mugishima Island in Akita Prefecture.

They agreed to contact outside immediately. The submarine they arrived on had sunk. Though a fishing boat was moored at the dock, amateurs operating it in winter seas would be dangerous.

"The phone... isn't connected."

A telephone sat in the entryway corner, but when Kanako picked up the receiver, there was no dial tone. The modular jack at the cable end seemed plugged in. Either the external cable was cut or never connected.

"To prevent escapees from using it?"  
"But the two watching me seemed required to make regular contact."  
"Then that means..."

There was a settlement on the small coastal flatland below, but would they really go there just to phone? Unlikely. What other communication methods existed? While Yuu and Kate pondered in the entryway, Kanako and Touko searched other rooms.

"Found it! This."  
"What is... whoa!"

At Touko's voice, Yuu and Kate rushed over. The first floor had an old-fashioned layout: kitchen/dining area plus two large Japanese-style rooms. One room had a hanging screen (sudare) at the back - different from summer sun shades. Closer to the misu screens used to conceal nobility in period dramas.

Behind the screen Touko lifted pointed to a tokonoma alcove with shelves like those for audio equipment. On the middle shelf sat a black, horizontally long machine. The upper shelf held a microphone and headphones connected to it.

To Yuu, it resembled a serious stereo amplifier, but with more switches and knobs than expected.

"Amateur radio. They used this for contact."  
"That's it!"

Even in the mobile-phone-saturated 21st century, taxi/truck drivers used radios, as did ships. Though requiring special equipment, radios work in remote areas or at sea without cell towers. Since Jane's associates used submarines and fishing boats, this was their communication method.

"I see, a radio... Now if only we can operate it..."

Yuu looked at Kate, but she shook her head. Yuu had never used one either. But Touko proudly raised her hand.

"No problem. At the company, I took training for Third-Class Amateur Radio Operator license."  
"You took training?"  
"Don't you need a license to operate radios?"  
"Well, just talking might be okay..."

Regardless, Touko was the only one among them with radio operation training and experience. They had to rely on her.

Kanako and Touko opened their ever-present company notebooks. Emergency contacts should include radio call signs. Though soaked and hard to read, they managed to extract information from both notebooks and contacted their security company MALSOK.

After explaining the situation to MALSOK's operator, they arranged police contact. Within 10 minutes, Akita Prefectural Police contacted them, promising to dispatch a helicopter immediately.

With escape now secured, they finally relaxed.

---

### Author's Afterword

This concludes the "End of Obsession" arc.

Story-wise it continues, but since the next part deals with post-rescue events, the subtitle will change.

Some readers worried about Kanako and Touko's safety, but I never planned to kill off such major characters from the start. Though it was close.

I considered a scene where they warmed their frozen bodies in this house's bath, leading to a threesome with Kanako and Touko... and maybe Kate joining after watching. But realistically, leisurely baths in a captivity house are impossible - surviving enemies might return.

Even after reuniting, protection officers would prioritize getting Yuu to safety immediately. Thus, no erotic scenes.

### Chapter Translation Notes
- Translated "第三級アマチュア無線技士" as "Third-Class Amateur Radio Operator" per Japanese licensing system
- Transliterated sound effects: "ドオォォォォン" → "Doooooon!", "ガンガン" → "banging"
- Preserved code name "Neki" for Kitamura Kanako without translation
- Translated "簀巻き" as "tightly bound" (literally "wrapped in matting") for clarity
- Rendered "へとへと" as "exhausted" to convey physical depletion
- Maintained Japanese term "tokonoma" (床の間) as cultural artifact requires no explanation in context