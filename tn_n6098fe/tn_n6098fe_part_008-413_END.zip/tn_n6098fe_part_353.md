## 331. Return ① ~with~

Notification came, and within less than an hour, Akita Prefectural Police's helicopter arrived.

Since helicopters require a certain amount of space to land, the four of them—Yuu and the others—were immediately taken aboard at what might have once been a plaza used for events.

Even during daytime, they encountered no one, and the houses they saw showed no signs of life, confirming it had indeed become a deserted island.

From there, everything happened in a whirlwind.

They flew to Akita City where the prefectural police headquarters was located, arriving at the building's rooftop heliport. The police chief and other high-ranking officials stood lined up to welcome them, treating them like VIPs.

They were immediately informed they'd undergo physical examinations at the adjacent police hospital.

Unfortunately, the timing was bad—the only male doctor had just left his post, and his replacement hadn't arrived yet. Even if they requested assistance from hospitals with male doctors, they'd have to look outside the prefecture and wouldn't make it in time today.

Yuu replied that he didn't mind female doctors at all—*secretly, he was very welcoming of lady doctors*—and the nearly 60-year-old police chief seemed genuinely relieved.

Unfortunately, the doctors weren't young beauties but all veteran physicians and nurses. The examination results gave Yuu a clean bill of health.

Kate who was examined next also had no issues.

Kanako and Touko had wounds here and there but nothing beyond minor injuries.

The real problem was their physical exhaustion—enough to make an ordinary person collapse. They seemed fine until arriving at the heliport, but perhaps the tension drained away, as they couldn't stand anymore.

Yuu stopped the police officers who tried to help.

He carried the petite Touko princess-style to a waiting stretcher.

Carrying Kanako was impossible, so he supported her shoulder, practically half-carrying her as they walked. This was only natural for the two who had escaped a sinking submarine and trekked through snowy mountains to reach Yuu.

Police officers watched this scene in wide-eyed amazement.

After the examinations, the four ate together in one room and gave their statements.

Since they were victims, there was no need for separate questioning.

Kanako and Touko, who had been soaked in seawater during their ocean escape, had already bathed and changed clothes.

After eating and refreshing themselves, their complexions improved significantly.

The suits they usually wore had been discarded in the cave, and they were still in the clothes taken from their captors. Since everything except personal belongings were enemy possessions subject to confiscation, they had apparently borrowed clothes from the police.

Kanako wore what looked like a navy blue recruit suit, while Touko inexplicably wore a green tracksuit with white stripes.

With her petite frame, bobbed hair, and childlike face, Touko looked just like a student in the tracksuit.

"I said I wanted something comfortable that fit, and this was the only option. Don't laugh, Sis."  
"Pfft."

Kanako burst out laughing at the rural middle-schooler-like, unfashionable tracksuit look.

At times like this, it was Yuu's role to comfort her.

"Touko-chan looks cute in anything."  
"Mufu. I like how kind Yuu-sama is."

Touko was delighted when Yuu hugged her and patted her head, while Kanako ground her teeth going "Gununu."

Kate watched this scene with exasperation.

Time passed under strict security—even in the prefectural police headquarters building corridor, officers stood packed so tightly not even an ant could slip through.

By the time the initial questioning ended, the sun had set and darkness had fallen outside the thickly curtained windows.

"Next, we'll escort you to Hotel Grandole Akita in the city.  
There are people waiting there for Hirose-san.  
Though it's nearby, we'll provide strict security for the transfer, so please rest assured."  
"Understood. Thank you for everything."

The security chief herself—with a physique rivaling a pro wrestler—spoke politely to Yuu.

To the police, Yuu was no ordinary civilian. He was a nationally famous boy on par with top idols, and a crucial person who had fallen into the hands of a long-wanted criminal group yet returned unharmed. The Metropolitan Police Department had strongly requested utmost caution, so the VIP treatment was natural.

Yuu didn't overthink it. He simply felt awkward being treated so courteously by female police officers of all ages at the prefectural headquarters he was visiting for the first time.

He bowed deeply to the security chief, matching her deference.

Faced with this, the security chief looked surprised and began bowing repeatedly while sweating.

When a woman older and higher-ranked than his mother showed such humility, Yuu felt compelled to bow again.

This mutual bowing might have continued indefinitely if Kate hadn't lost patience and stopped Yuu.

"So many patrol cars... Um, if it's alright, could I ride in one?"  
""""Huh?""""

The distance from the prefectural police headquarters building in the city center to Hotel Grandole Akita at the mountain's edge was about 2.5km—walkable.

But the prefectural police had planned VIP treatment: three police motorcycles leading, with ten patrol cars forming a convoy.

Yuu was to ride in the chief's high-grade domestic sedan used for official duties.

But Yuu's eyes were fixed on the patrol cars.

Unless caught red-handed, suspects or key witnesses would only ride in them unwillingly. The other occasion was transporting crime victims.

Including his previous life, Yuu had never ridden in a patrol car. The only opportunity might have been during last summer's abduction incident, but Kanako and Touko had spearheaded the rescue, so he'd ridden in their usual car.

"Hey, Yuu! Don't cause trouble with selfish requests. They're already going out of their way!"  
"Eh... r-right. You're right. It'd be rude not to follow procedures..."

Kate jabbed his arm as if scolding a troublesome younger brother, making Yuu reconsider.

Both Yuu and Kate were originally ordinary people and couldn't shake their civilian sensibilities.

The police officers exchanged glances. They wanted to grant Yuu's wish—he showed courtesy and familiarity to everyone he met.

The problem was deciding which patrol car he should ride in.

Then Kanako came up with an idea.

"Keep the convoy formation, but have Yuu-sama disguise himself as a woman and ride in the back patrol car. We can say it's a security precaution—how about that?"  
"Ohh, as expected of Kanako-san!"  
"So crossdressing is fine..."

The disguise just needed to prevent him from being recognized as male from a distance.

They found a somewhat flashy blonde wig for disguise and put it on him—matching Kate's hair.

Since his leg hair might show, a skirt was out of the question. They borrowed only a woman's long coat for him to wear over his clothes.

"Th-th-then... let's depart."  
"Yes. Thank you."

Yuu's patrol car was the third from the back.

Kanako sat in the passenger seat after losing at rock-paper-scissors. Yuu sat in the middle of the back seat, sandwiched between Kate on his left and Touko on his right.

The driver was a beautiful officer around 30 with a sharp demeanor—originally from the traffic enforcement division—which delighted Yuu.

She seemed unaware that her dialect slipped out due to nervousness.

Though she appeared stiff from the tension of driving Yuu, she smoothly followed the lead vehicle once moving. Her driving skills were clearly solid.

Compared to the luxury sedans he usually rode in, the patrol car's comfort wasn't exceptional.

The main differences were the exterior's black-and-white two-tone body and roof-mounted emergency lights—the interior was like any ordinary car.

But with police motorcycles leading and ten patrol cars in procession, it felt exhilarating to advance without stopping at any traffic signals while all other vehicles halted.

The only disappointment was that night had fallen, preventing him from seeing the scenery of Akita City, which he was visiting for the first time.

As the road sloped upward into the foothills, they arrived at the hotel.

Only Yuu's patrol car pulled up to the entrance, where pre-positioned officers formed solid walls on both sides leading to the doors. The VIP treatment continued until the end.

The female officer who drove got out first and opened the right rear door.

Touko gave a slight bow and got out, then it was Yuu's turn. Kate got out by opening the opposite door herself.

"Thank you. That was great driving."  
"I-I'm honored."  
"Um... keep up the good work from now on."  
"Hyah!?"

Yuu took her hand, shook it, and looked straight into her face—she was slightly taller than him.

Somewhat resembling Wish's Aoi, she had sharp eyes and a dignified face that suited male attire. Her cheeks flushed bright red.

Yuu made it a habit to show equal courtesy to any woman who helped him, even briefly.

He thought he was just being polite, but in this world where many women had little exposure to men, it made a strong impression.

After parting with the driver, he shook hands with and thanked each officer including the chief and other executives.

This contrasted sharply with when a certain politician's son visited for tourism—he accepted VIP treatment as his due, barely looking at or speaking to anyone.

If Yuu ever returned to Akita Prefecture—next time as an ordinary tourist—they would welcome him wholeheartedly.

Actually, after the security chief left at the police hospital, Yuu had a conversation alone with Kate.

If people were waiting for him, family would surely be included.

Kate was hesitating about how to face them.

"Can I... really go too?"  
"What are you saying now?"  
"But even though we were practically estranged, the mastermind was my mother. That day, they targeted me while I was moving, and even Sayaka got involved..."  
"Kate!"  
"Wh-what?"

Though usually strong-willed, Kate had been blaming herself for endangering Yuu and Sayaka.

As Kate looked down to hide her tearful face, Yuu grabbed her hand.

"It's clear Jane and her associates set it up. It's not your fault. You're a victim too, right?"  
"E-even so, others won't see it that way. Especially people around Yuu—they'll just see me as a woman who brings disaster."

Unlike Yuu, Kate's rebirth had been on hard mode, making her more prone to negative thinking.

Yuu squeezed her hand firmly to reassure her.

"If anyone speaks ill of you, I won't allow it."  
"Wh-why go that far..."  
"Because you're Sayaka's friend. If she's close to you, I want to cherish you too."  
"Ah!"

A scene from over ten years ago flashed through Kate's mind.

It was the day she first met Yuu in her previous life. Yuu's ex-wife had become a new client. Back then, Yuu politely greeted her and never forgot to thank her whenever they met during pickups/drop-offs.

Back then, Keiko's surroundings were full of self-absorbed, pretentious men trying to impress—partly because Keiko was more dashing and handsome than ordinary men, making women fawn over her. Amidst this, Yuu's attitude felt refreshing, and she secretly developed a fondness for him.

"Besides... you're not just a friend, Kate. How should I say... a comrade? Or a special companion..."

Scratching his head with his free hand, Yuu spoke.

He still felt some distance and shyness toward Kate—a fellow reincarnate not originally from this world but from a chastity-norm world.

"Fufu. That's right. We're comrades. Sharing the same secret..."

Kate's gloomy expression changed as a faint smile surfaced.

She felt happy sharing a secret with Yuu, her cheeks naturally relaxing.

Yuu found himself captivated by her beautiful smiling face.

"What?"  
"Ah, nothing... it's just... Keiko-san was... dazzlingly wonderful. Totally not my type, but she's still beautiful now."  
"Eh... d-dummy! That's embarrassing! Stop it. At my age... I-I'll start feeling weird!"

Kate's words trailed off, and Yuu only caught "at my age."

"At your age? You're a fresh 16-year-old now. Since you've been given youth, let's stay positive."  
"Calling it 'fresh' is so middle-aged."  
"Hahaha."  
"But... thank you, Yuu."

When they first met, she hadn't believed he was reincarnated and was wary.

But now the distance between them had significantly narrowed.

Incidentally, even in her previous life as Keiko, she hadn't called a man by his first name since childhood—yet now she called him Yuu naturally without realizing it.

After this exchange, Kate accompanied them to the hotel.

The hotel entrance's automatic doors opened.

Under dazzling lights, lining the spacious entrance floor to welcome Yuu wasn't the entire staff...

"Yuu-chan!"  
""""Yuu!""""  
""""Yuu-kun!""""  
"Whoa!"

A group unable to wait rushed into the entryway, surrounding Yuu.

Yuu's mother Martina and sister Elena.

His fiancées Sayaka, Riko, and Emi.

And Toyoda Haruka—chief permanent director of the foundation and Sakuya's former wife—along with her daughter and Yuu's half-sister Satsuki.

---

### Author's Afterword

In the chastity reversal world, Yuu and Keiko (Kate) didn't start off well.

Knowing Yuu had adapted to the chastity reversal world and become popular and sexually active with women, closing the distance wouldn't be easy.

This incident created a sort of suspension bridge effect, making them seem much closer—but will it last...?

I might write a chapter from Kate's perspective someday.

Note: Akita Prefectural Police headquarters building, police hospital, etc., are set differently from their real-world counterparts.

### Chapter Translation Notes
- Translated "ピチピチ" as "fresh" to convey youthful vitality while maintaining colloquial tone
- Translated "ぐぬぬ" as "Gununu" for onomatopoeic frustration sound
- Preserved Japanese honorifics (-chan, -sama) per style guidelines
- Translated "貞操逆転世界" as "chastity reversal world" for consistency
- Used "Keiko" when referring to Kate's past identity per naming conventions
- Translated "吊り橋効果" as "suspension bridge effect" for psychological term accuracy