## 332. Return ② ~I Wanted to Talk~

Martina was the first to tightly hug Yuu and burst into tears.

Elena, crying angry tears directed at no one in particular, hugged him from behind.

Though beaten to the punch, Riko and Emi wore relieved expressions while tears streamed down uncontrollably at the sight of Yuu safe. Sayaka felt the same, but upon spotting Kate, she rushed over with unbelievable speed for a pregnant woman and hugged her, startling Kate.

Satsuki also joined the circle surrounding Yuu along with Riko and Emi. Naturally, she too was shedding tears.

Haruka remained relatively composed, but the moment she saw Yuu's unchanged appearance, she seemed genuinely relieved, pressing her fingertips to the corners of her eyes.

The only one looking uncomfortable was Ryoko, who had been called as a concerned party. Though she soon followed Sayaka's lead and ran over to Kate.

In this chaotic situation (to put it mildly), Yuu found his face pressed firmly against Martina's voluptuous chest. Even through the thick winter clothing, he simultaneously experienced joy and slight discomfort from the sensation of her ample breasts.

After getting some space, he busily thanked each person who came to greet him by name, expressing gratitude and offering comfort.

"Everyone, this isn't the place. Let's move to a room."

After a while, Haruka spoke up, finally bringing Martina and the others back to their senses.

"Hirose Yuu-sama, family, and friends, please follow me this way."

Led by the middle-aged manager with half-white tied-up hair—wearing a tuxedo since this was a hotel, not a ryokan—about ten employees bowed respectfully.

Guided by the manager, Yuu and the group finally moved from the entrance. Along the way, Haruka quietly approached Yuu to talk. She wore a kimono with gold and silver patterns on a black base today, giving off a dignified aura reminiscent of a yakuza wife.

"Yuu, you're going to Tokyo tomorrow, right?"  
"Yes. For police questioning at the Metropolitan Police Department."

Though he'd already given a statement to Akita Prefectural Police detectives, the formal questioning would be tomorrow. He'd been asked to come to the Metropolitan Police Department for detailed inquiries about the incident. Given the gravity of the situation, it wouldn't be simple even for the victim. Missing the first day of the new semester was now certain.

Yuu was inwardly surprised that Haruka knew this, but considering her extensive connections as chief standing director of the foundation, it wasn't unexpected.

"Then... at least rest well tonight. It's reserved just for us, so feel free to relax."

Even from the front, Hotel Grandole Akita gave an impression of elegance and luxury. That it was fully reserved seemed incredibly extravagant to Yuu.

Hotel Grandole Akita prided itself on being safe for male guests. Among the perpetrators, the mastermind was arrested, and accomplices on the island—including foreigners—were presumed dead. However, the possibility of survivors escaping the island or decoy operatives couldn't be ruled out. Though police investigations continued across prefectures, Yuu couldn't be targeted—any mishap was unacceptable.

Therefore, after emergency discussions between the foundation and national/prefectural authorities, they decided to reserve the entire hotel and let Yuu rest under strict security. Akita Prefectural Police also staked their prestige on protecting Yuu, with officers stationed around the hotel and on every floor.

Thus, they passed through the completely guest-free lobby, climbed one staircase, and were shown into a conference room by the manager. It had a spacious, calm interior that could be used for corporate board meetings.

Normally, the illuminated garden would be visible through the windows, but blinds were drawn and partitions blocked the view. Yuu sat in the far seat, with Kanako and Touko standing behind him like bodyguards. Miyo and Yoriko, who had accompanied Sayaka to a Niigata hospital for examination, also stood nearby.

As the group filled one side of the oval table centered around Yuu, Haruka spoke.

"Everyone rushed here urgently, and Yuu must be exhausted too. Now that we've seen Yuu safe and can relax, I'd like you all to bathe, eat, and rest. However, each person's information about this incident is fragmentary. With all the women close to Yuu gathered here, I'd like to share information. What do you think?"

Among women who were meeting for the first time, having someone like Haruka take charge was welcome. No one opposed her suggestion.

Only Kate and Ryoko looked uncomfortable, wondering if they should be there. Noticing this, Yuu immediately stood.

"Haruka-san, Satsuki-nee, Mom, Sis, Sayaka, Riko, Emi, and Ryoko—thank you for coming all this way. I'm sorry for worrying you, but as you can see, I'm fine."

As Yuu bowed his head, enthusiastic applause erupted. After it subsided, Yuu spoke again.

"There's one thing I want to say. About Kate here."

Everyone's attention focused on the blonde, blue-eyed Caucasian girl. Among them, only the three fiancées knew Kate through student council connections, excluding Ryoko. Satsuki knew of her through Yuu's consultations about school transfers and employment but was meeting her for the first time.

"As you know, she's the daughter of Jane, the mastermind. The media might have written various things."

For the media, perpetrators' families are easy targets—they can be criticized relentlessly with little backlash. Though some feel it's cruel to attack families unless they're accomplices, they're a minority. About Kate: famous delinquent in the neighborhood, leader of a biker gang terrorizing the city, Sayaka's lapdog in Saiei Academy student council, ordering seniors around arbitrarily—that sort of thing. Like mother, like daughter. Some weekly magazines distorted facts to make it seem Kate was at fault.

"Until age 15, she suffered daily abuse—severe violence and verbal abuse if she resisted even slightly, locked in storage without meals. Jane apparently raised Kate as an obedient pawn."  
"How awful!"  
"To do that to her own child... She doesn't deserve to be a parent!"

Both Haruka and Martina here had raised their children with abundant love. That made them angrier and more sympathetic toward Kate.

"It was last March. After various events, Kate woke up, talked back to Jane, and after repeated fights, left home. Because of August's incident, she transferred to a night school in Matsumoto as Satsuki-nee arranged. She worked while attending school. Why was she kidnapped? Maybe Jane wanted to control her again? When I woke up, she was restrained and stuffed in a closet. What I'm saying is—Kate is completely a victim. Plus, Kate and Ryoko are precious friends to Sayaka too. So I want you to accept them both."

After Yuu's lengthy speech, silence fell briefly.

"You suffered so much. To be treated like that by your only family..."

Martina murmured softly. The fact that Kate was also reborn like Yuu remained hidden. Normally, sympathy would naturally extend to a minor like Kate. Even if Kate had faults—hanging with delinquents, leading the Red Scorpions—it was understandable.

"Does anyone object to Kate and Ryoko being here?"

No one opposed Haruka's question. On the contrary, they competed to speak to Kate. Usually calm, Kate seemed overcome with emotion, responding with tears in her eyes.

Then information sharing began. Shortly after Sayaka left the building with two protection officers and got in a car, the audio bug and transmitter on Yuu's body stopped sending signals—likely when Yuu entered the submarine. Police special forces stormed the dock, but it was empty. Seawater in the basement suggested an escape by sea. Three patrol boats were circling offshore, but they'd slipped away underwater. No one anticipated a submarine. From dawn, Niigata Prefectural Police and Coast Guard helicopters searched but found no trace of Yuu. So when the security company contacted them the next day, it was unbelievable.

Kate explained from her abduction to being imprisoned in the mountain house on the island. What everyone wanted to know most was Yuu's condition. No man taken by a group of women returns unharmed after a night—Sakuya was the sole exception. Yuu summarized what he knew.

Everyone listened intently, especially to when Jane appeared alone and attacked Yuu. Hearing that Yuu made her climax repeatedly with his techniques and cock until she nearly lost consciousness, they nodded knowingly. They knew firsthand the ferocity of what seemed like a pet but was actually a beast. However, hearing that Jane—possibly due to drugs used as painkillers—mistook Yuu for Sakuya till the end left Haruka and Martina with mixed feelings.

"She must have... met Sakuya-san during his overseas travels..."  
"Yes. She must have fallen deeply for him. Maybe they parted incompletely, leaving lingering feelings."

Haruka especially had seen many such women. Some relationships became physical; others remained unrequited crushes. Regrets lingered when they'd grown somewhat close but it ended abruptly. If the person was alive, hope remained—but Sakuya died young. Jane not only felt base desires seeing Yuu's fame but might have wanted him as an outlet for her longing for Sakuya. Without her confession, the truth remained unknown. No sympathy could be given after her crimes, but a vague unease lingered.

"Mom."  
"Mommy."

Amid the somber mood, Haruka and Martina snapped back to reality when called by their daughters.

"Shouldn't we discuss tonight's plans soon?"  
"Right. First, let's bathe. This hotel has hot springs good for beauty, I hear. Since it's reserved anyway, shall we all go together?"  
""""Wow!""""  
"Lovely!" "Let's go!" "I'm excited for the hot springs with Yuu-kun!" "It's been a while since I bathed with Yuu too."

Everyone was drawn to the hot springs—especially hearing they were beautifying.

"Eh... Everyone?"

Only Kate couldn't follow, looking around blankly. To her, baths were gender-separated, but she'd heard something unbelievable. Sayaka didn't seem bothered, and Ryoko happily said, "Hot springs? It's been ages," making it hard to confirm.

Yuu smiled fondly at his excited mother and sisters, then stood and approached Sayaka, Kate, and Ryoko.

"Kate, you saw it firsthand, but the rings you two chose saved me. Thank you."  
"So restraining Jane means... that ring worked!"

Though not mentioned earlier, Ryoko understood that repeated climaxes followed by the electric shock had knocked Jane out. Though worried since the affordable ring was single-use, hearing it worked when it counted made it worthwhile.

Kate was still shocked from witnessing Yuu's intense sex up close—his impressive cock remained burned into her vision. She hadn't clearly seen the ring being used. Rather, remembering that moment made her blush. Despite her mature mind, her young body had gotten aroused. Trying to hide it from Yuu, she averted her face. Fortunately, Yuu didn't notice Kate's expression because Sayaka pulled his arm.

"Yuu-kun, sit here."  
"Ah, yes."

Pointed to an empty seat, Yuu obediently sat. Sayaka looked too serious—rather, tragically on the verge of tears. Last night, Yuu and Sayaka had only exchanged brief words during the hostage exchange before parting. After leaving with two protection officers, Sayaka met her urgently arrived family and stayed at a Kashiwazaki hospital for tests. Though Yuu heard by phone she was fine, she'd only arrived at the hotel an hour ago, so they hadn't talked directly.

"Yu...u-kun!"

Standing Sayaka hugged the seated Yuu, pressing his face against her chest. She must have bought and changed clothes here: a white turtleneck sweater layered under a maroon dress—a maternity dress with room around the belly. With the heating on indoors, she wore no outerwear, so along with her swelling belly, the soft, abundant sensation of her growing breasts transmitted to his face. Though Sayaka leaned back slightly, her large belly still pressed against Yuu's chest, giving warmth and comfort. But when Yuu looked up, Sayaka seemed ready to cry.

"Sayaka?"  
"I... not only troubled Ryoko with my reckless actions but put Yuu-kun and Kate in danger... I was agonizing over how to apologize, only to make you worry more... Ah, what a foolish woman I am!"  
"Sayaka!"  
"The culprits are to blame! Not you, Sayaka!"  
"That's right. You did nothing wrong. Don't blame yourself."  
"But because I insisted on driving despite my condition, Kate and Ryoko..."

Kate and Ryoko closed in from both sides. Clearly, no one blamed Sayaka for this incident. But being exceptionally responsible, she couldn't help blaming herself. If only she weren't pregnant. If the opponents hadn't had guns, three against five could have been repelled. She alone had been a burden. Guilt toward Yuu, Kate, and Ryoko lingered and wouldn't fade easily.

This was Yuu's moment. Standing, he stroked Sayaka's head like comforting a child. Sayaka's beautiful black hair with its angelic halo felt pleasant to touch—unchanged since their first union.

"Me, Kate, Sayaka, and the baby—all fine with no problems. The mastermind was caught. All's well that ends well. Isn't that enough?"  
"Yuu-kun..."  
"Ah! The baby just moved!"  
"Huh..."  
"Fu, fufu... Maybe they want to come out soon?"

Finally seeing Sayaka's expression soften, not just Yuu but Kate and Ryoko sighed in relief and hugged her arms. Sayaka and Kate had only met last November, and Ryoko was a childhood friend—or rather, a longtime companion—but they'd only recently reunited. Yet all three seemed like old friends. The incident must have forged solidarity.

Then Riko and Emi joined in, not to be outdone, speaking to Sayaka. They too had worried about her. Satsuki and Elena certainly prioritized Yuu most. But they didn't dislike Sayaka, now family-related, and accepted her as the primary wife. As Yuu said, they rejoiced seeing all three kidnapping victims safe. Haruka and Martina watched the younger girls chatting with warm smiles.

---

### Author's Afterword

As an aftermath, such conversations were necessary. Family, fiancées, the foundation, Kate and Ryoko involved in the incident. As the story enters its final stages, I enjoy scenes where characters from different backgrounds who've interacted with the protagonist meet for the first time. With nine people gathered, Haruka's role in steering the conversation was invaluable. Next is the bath scene.

2021/10/2 Addition for Sayaka's part: Added that her family rushed to meet her. As a kidnapping victim, her family not coming would be unnatural. However, only Sayaka as fiancée came to this hotel—her family stayed elsewhere (her sister wanted to see Yuu, but her mother forbade it).

### Chapter Translation Notes
- Translated "号泣" as "burst into tears" to convey intense emotion
- Preserved Japanese honorifics (-san, -kun) and name order (Hirose Yuu)
- Translated "おっぱい" as "breasts" following explicit terminology rule
- Translated "チンポ" as "cock" per explicit anatomical terms requirement
- Rendered sexual acts without euphemisms ("made her climax repeatedly")
- Used italics for internal monologue *(This is concerning.)*
- Transliterated sound effects ("ぺこり" as slight bow motion described)
- Maintained dialogue formatting rules with new paragraphs for each speaker