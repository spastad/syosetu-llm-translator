## 333. Naked Interaction ① ~Naked Angel~

Hotel Grandole Akita's large bath is located on the first floor. Since the hotel itself is on elevated ground and there are no obstructions in its position, it should normally offer a view of Akita city's nightscape.

Typically reserved for women only, men use either the bathrooms in their rooms or the separately provided family baths.

But with this exclusive reservation, there was no reason not to use it.

Since Yuu was going to use the large bath, the flustered hotel staff moved shuttle buses—forcibly clearing obstacles to create space despite it not being a parking area—and used construction sheets to block outside visibility.

"Ooh! It's huge!"  
"It feels clean and refreshing."  
"And the amenities are well-stocked too!"

Yuu had invited the four protection officers, but Kanako and Touko had already bathed at the hospital to wash off seawater, and all four declined, wanting to focus on protection duties.

Thus, Yuu and the women—ten people total—filed into the large bath.

There was only one entrance, with no gender-indicating noren curtains.

Given the hotel's scale and its design for large crowds, the interior was spacious.

Immediately upon entering, the left side featured a changing area that could accommodate about fifty people, with lockers containing baskets. Coin lockers were visible further back.

Looking right, there were back-to-back washing stations. These could accommodate up to ten people simultaneously. A health scale and baby bed were also provided.

An open space occupied the center with wooden benches and vending machines—the take-and-pay-later type—likely for post-bath relaxation.

The floor appeared wooden but slightly textured. The surface seemed treated to prevent slipping, making it safe even for pregnant women.

Being the first bath of the day, everything was generally dry, with no stray hairs or debris on the floor.

"Hey hey, save the sightseeing for later! Listen up~"

Yuu had been looking around excitedly like a child since entering.

Even Emi and the usually cool Riko followed him with sparkling eyes.

Satsuki called out to Yuu and the others.

Meanwhile, Kate was hesitating near the entrance but was being escorted by Sayaka and Ryoko from both sides.

"I asked the hotel to prepare yukata and underwear for everyone—they're already in the locker baskets. They'll wash any underwear we remove by tomorrow morning."

Cheers immediately erupted at her words.

Apparently, properly sized underwear for everyone had been prepared before Yuu's arrival.

Not everyone had planned to stay overnight, and some had resigned themselves to wearing the same underwear, so this consideration was appreciated.

"Do we put removed clothes in here?"  
"Huh?!"

Three large baskets sat before the lockers. Yuu asked Satsuki if they should put removed clothes there.

"Yuu-chan, wait!"  
"We'll take Yuu's clothes home."  
"But that'll add to luggage. Wouldn't washing them with everyone else's be better?"  
""""No no no!""""

Yuu's clothes—worn for nearly a full day—especially the T-shirt, underwear, and socks directly touching his skin. Only he didn't realize their preciousness, prompting vehement objections.

Leaving them out might have caused bloody battles among hotel staff.

Ultimately, Hirose family members Martina and Elena took responsibility for them.

Women typically take time to change, depending on clothing complexity.

By the time Yuu entered the changing area, about half were partially undressed.

Except for one person, no one attempted to hide—as if only women were present, some even comparing underwear.

When Yuu reached the middle locker row, he saw a basket labeled "Hirose Yuu-sama" containing neatly folded yukata and men's underwear. They'd even included a sports-bra-like chest garment, which Yuu had no intention of wearing.

Martina, being pregnant, took time, but Elena—likely because she wore casual clothes—quickly stripped to her underwear.

Elena offered to help him undress with a mischievous smile, but Yuu declined since he wasn't a child. Instead, he told her to help their mother.

In this row: Haruka, Satsuki, Martina, Elena, Yuu.

As Yuu unbuttoned his shirt and glanced back, he saw Sayaka, Riko, Emi, Ryoko, and Kate across the central lockers.

The shoulder-height lockers obscured their undress level, but Ryoko seemed first to become naked. She urged the hesitant Kate, who was slow to undress around Yuu.

"Yuu, no injuries while captured by those bad women?"  
"Huh? Want to check?"

Yuu responded to Satsuki—already in underwear—while removing his T-shirt.

Not just Satsuki and Elena, but Martina and Haruka too shone their eyes on Yuu's exposed torso.

"Yes yes! Let big sis examine you thoroughly!"  
"Let Mama see too too!"

At that voice, even Riko and Emi on the opposite side reacted.

Though they'd seen each other naked many times, Yuu's nudity still captivated them.

"O-o-oh..."  
"Hmm?"

Ryoko—already fully naked—rounded the lockers to see Yuu's nude form after so long. Yuu turned at the sound and their eyes met. She stood boldly like a Nio statue, not hiding her dense black pubic hair.

Ryoko looked near nosebleed-level excitement, but to Yuu, her physique was exceptional.

Toned and sturdy without bulkiness—a nice body rivaling pre-pregnancy Sayaka's, arousing to men. Her breasts swayed when she moved.

Scars on her shoulders and underarms were unfortunate, but her chest and hips were magnificent. Yuu's crotch nearly reacted.

"Ryoko's so lewd."  
"A-ah, sorry!"  
"Not that meaning. Show me more."  
"Huh?"  
"Hey hey, Yu-kun, look at my belly!"  
"Look at me too!"  
"W-wait, I'm taking off my panties now."

Only ten people including Yuu in the spacious changing area.

But Yuu's presence made it as lively as peak hours.

Women stopped moving to stare intently at Yuu's disrobing. Only Kate—seizing the distraction—furtively undressed, wrapped a towel, and tied up her long blonde hair.

"Ooh..."  
"Ufufu."  
"Yu-kun, sexy!"  
"Still have such a nice body."  
"Come on, everyone undress!"

By full nudity, Yuu's cock was semi-erect—surrounded by fully or partially naked women.

Ryoko noticed: one person furtively hiding.

"Hey hey, Leader, what're you doing? Come here!"  
"W-wait! Kyah!"

As Yuu turned, Kate—pulled by the arm—entered his view.

Her feet tangled, losing balance—the towel wrapped around her chest fluttered down.

""Ah!""

Her long blonde hair tied back, snow-white skin exposed from chest to toes.

Her toned body matched Ryoko's, but most eye-catching were her large swaying breasts.

Yuu recalled the night he first encountered the Red Scorpions.

When riding behind Kate—then calling herself Keiko—he'd impulsively groped her chest, noting impressive size. Slightly larger than Ryoko's beside her, her breasts thrust forward assertively.

Below well-defined abs, a golden delta matching her hair. Though seen obliquely, perky upturned buttocks. Long legs without excess fat.

Her mother Jane had model-surpassing beauty and proportions (inhuman personality aside), which Kate seemed to inherit faithfully.

Seeing such a form, Yuu couldn't not react.

Instantly, his cock stood fully erect, slapping his lower abdomen.

"Kyaaaaaaah!"

Realizing her exposed natural state before Yuu, Kate flushed crimson, covered chest and crotch, and retreated behind lockers.

In this world, women feel no shame being nude before men—men hide skin instead.

Thus Kate's behavior should seem eccentric, but no one noticed.

All were captivated by Yuu's manly erect cock.

"Ah, Yuu-kun..."  
"Ufufu, relieved it's still vigorous."  
"Aha, Yuu's cock... wonderful..."

Elena, Satsuki, Sayaka, Riko, even Emi gathered around Yuu, closely observing.

They didn't touch, but examined from all angles, heads bumping, checking for abnormalities.

"Heard rumors, but... Yuu, you inherited even that from Sayaka-san. Not just size—seed potency too. Right, Martina-san?"  
"Ah, haha... yes."

Haruka leaned toward Martina as she spoke.

Her gaze rested on Martina's large swollen belly.

No malice or jealousy—rather, she stroked it affectionately.

When Sayaka lived, Martina's "mom friend" relationship lasted under three years.

She'd rarely met Haruka directly, finding her intimidating as the wife managing multiple lovers, so she remained somewhat reserved.

"I still feel embarrassed. Not just loving Yuu-chan as a son, but feeling him as a man. And getting pregnant at this age..."  
"In this world, women bearing three children with their beloved man's seed are blessed. You had that fortune and charm. Treasure it."  
"Y-yes!"

Martina detected loneliness in Haruka's eyes.

Though one of Sayaka's four longest-wed wives, Haruka only bore Satsuki.

Perhaps early childbirth made her body less fertile.

But they weren't close enough to discuss past matters.

She cherished Yuu like her own and celebrated Martina's pregnancy. That sufficed.

"Alright! Let's enter! The bath awaits~"  
""""""Yes!""""""

Satsuki—naturally assuming leadership—called out, receiving energetic replies.

Satsuki herself had been closely examining Yuu's cock, sniffing its scent with a dazed expression, but remembered pregnant members shouldn't catch cold.

"Let's go. Mom, Sayaka."  
"Yuu-chan..."  
"Yu, Yuu-kun..."

Satsuki slid open the bath door.

Yuu led, holding Sayaka's right hand and Martina's left.

The entrance area was dry and non-slippery with no prior users.

Still, Yuu wanted to hold these two most precious hands.

Sensing this, Martina and Sayaka spoke little, happy yet considerate of others.

Both busty, their breasts touched Yuu's arms—a blissful softness.

This kept his crotch fully erect.

"Whoa, amazing."

The floor featured intricate marble patterns. Over ten washing stations lined each side wall.

Ahead lay an extra-wide bathtub—over 10 meters wide, larger than previous inns.

Stone pillars flanked the tub, integrated with fierce oni statues—two horns, wide-gaping mouths.

To be precise, not oni—namahage.

Majestic 2-meter-tall figures, faithfully recreated with sickles and straw garments.

Yuu didn't know details, but historically unmarried men played namahage. With fewer men, young women now perform it.

Their lines—"Any crybabies?" "Any naughty kids?"—and appearance seem scary, but they're visiting deities banishing misfortune.

Thus, households with only women especially welcomed them.

The dog loyally sitting at namahage's feet was likely an Akita dog. Water gushed from its mouth.

Glass windows should offer views, but now blocked by sheet-covered buses.

"Come, Yuu-chan, wash your hair first."  
"Yuu-kun, I'll wash your back."  
"Ah, okay."

Yuu was pulled toward right-side washing stations.

Martina and Sayaka seemed to have divided roles via eye contact.

Resisting was unwise here.

"I'll wash Yuu too!"  
""Me too!""  
"Oh my, nice. Include me~"

Before Yuu could sit, Elena, Riko, Emi, and Satsuki surrounded him.

Elena aside, pregnant women gathered inexplicably.

Haruka watched smilingly from a distance.

Kate deliberately headed to opposite washing stations while Yuu faced away.

Ryoko followed with a wry smile.

---

### Author's Afterword

With nine women, undressing and bath entry alone filled this chapter.

The fun naked interactions continue next chapter onward.

### Chapter Translation Notes
- Translated "裸天女" as "Naked Angel" interpreting "天女" (heavenly maiden) as angelic figure in context
- Preserved Japanese honorifics (-chan, -kun) and name order (Hirose Yuu)
- Translated explicit terms directly: "チンポ" → "cock", "陰毛" → "pubic hair"
- Transliterated sound effects: "おーっ" → "Ooh", "きゃっ" → "Kyah"
- Italicized internal monologues per original text (none present in this chapter)
- Maintained dialogue formatting rules: new paragraphs for each speaker
- Translated "なまはげ" as "namahage" (cultural term explained in-text)
- Translated "秋田犬" as "Akita dog" (real breed name)
- Rendered sexual descriptions without euphemisms per style guidelines
- Used gender-neutral "protection officers" for ambiguous references
- Preserved specialized terms: "Red Scorpions", "Nio statue" (仏像)
- Translated "精の強さ" as "seed potency" for biological context