## 334. Naked Interaction ② ~Touch It with Your Hands~

"Ufufu. It's been so long since I washed your head like this, Yuu-chan. I used to wash you often when you were little. How is it? Does it feel good, Yuu-chan?"  
"Nn... mmph"  

Martina's voice revealed she was in the best possible mood.  
Yuu's response was muffled.  

"Ahh, Yuu-kun's back is so broad and sturdy... Just being able to touch my beloved's back like this... makes me unbearably happy... mmph"  

Sayaka's voice came from behind, tinged with sensuality. This was the expression of a woman intoxicated with joy, one she only showed to a select few at school.  
Yuu had initially hesitated about letting pregnant women wash him. But both Martina and Sayaka, while smiling, refused to take no for an answer—as if caring for the safely returned Yuu was their duty.  

Yuu was currently sitting on a stool, leaning forward with his upper body bent.  
His arms were wrapped around Martina's back, his face buried in the valley between her melon-sized breasts.  

Martina was gently massaging shampoo into his hair while his face was enveloped in the soft, milky-scented flesh. Though Martina was biologically related to him, mentally she was younger. Yet Yuu couldn't help being moved by her deep maternal love. While Yuu held familial affection for Martina, he also felt sexual desire toward her charms. Amidst these complex feelings, he thought that perhaps a biological mother's breasts truly had a soothing effect on both mind and body.  

Sayaka tried washing Yuu's back from directly behind but her near-full-term belly got in the way. Instead, she stood beside him, working up a soapy lather with both hands before scrubbing with a towel. Yuu could feel her breasts—larger since pregnancy—pressing softly against him. Sayaka seemed already aroused by washing Yuu's back while pressed against him.  

It seemed decided that Martina and Sayaka would wash Yuu first, as Elena, Riko, Emi, and Satsuki had started washing their own hair. Yuu could hear shower sounds and cheerful chatter from both sides. Though initially hesitant, Yuu welcomed this naked interaction with his loved ones. He began to think that being washed by pregnant women might be a rare experience.  

"All done washing~"  
"Ahh... nn, thank you, Mom"  

After rinsing off the bathhouse-provided shampoo and conditioner, Martina used a towel to pat him dry. Yuu had been buried in her cleavage so long that shower water started seeping in, making it hard to breathe, so he finally pulled away. When he looked up, his eyes met Martina's. Though she was smiling, her light brown eyes wavered when she realized they were gazing at each other so closely. Her glance dropped downward and landed on Yuu's erect penis pointing toward her breasts. Martina's cheeks flushed as she swallowed hard, simultaneously seeing her son and feeling him as a man.  

Whether aware of this or not, Yuu covered Martina's lips while holding her shoulders. Their mouths pressed together firmly as he slipped his tongue inside. Martina accepted it naturally, their tongues tangling with wet, slurping sounds.  

"Nnhaa..."  
"Just as I thought, Mom's really good at washing hair. Felt amazing"  
"Ahhn, Yuu-chan!"  

After their tongues tangled fiercely, leaving strands of saliva, Yuu whispered. Hearing his words, Martina nearly exploded with joy. She hugged Yuu tightly and began raining kisses on him. Pleasing her son gave meaning to her life as a mother, while simultaneously stimulating her womanhood until her privates grew damp.  

"How... was it? It's harder to control the pressure than before, I wonder if I washed well... mmph"  

After Martina's kissing subsided, Yuu turned toward Sayaka who was fidgeting. They'd bathed together many times at the apartment, washing each other, but frequency decreased after her belly grew—she'd started washing with fellow pregnant women Riko and Emi. Perhaps that's why washing Yuu's back while pressed against him had aroused Sayaka more than expected. She felt she hadn't applied enough pressure. But Yuu wordlessly reached out with his right hand, covered her lips, and slowly savored their softness. His fingers skillfully traced from her cheek to jaw, then neck to nape. As Yuu's fingers moved as if confirming her silk-smooth skin, Sayaka released a sensual sigh. After all, a woman feels joy simply from being touched by her beloved man anywhere.  

"Having a beauty like Sayaka wash me so earnestly—that alone makes me happy. Thank you"  
"Ah, ahh, Yuu-kun!"  
"Nngh!"  

Sayaka's arms wrapped around Yuu's back as she kissed him fiercely, not caring if their teeth clashed. Then her tongue slipped in. Sayaka had been beside herself until Yuu returned, and feeling his direct touch brought her supreme joy. She fell for her gentle, wonderful fiancé all over again.  

"It's about our turn now~"  
"I want to wash Yuu-kun too!"  
"Changing shifts"  
"O-okay"  

As Yuu and Sayaka's deep kiss paused, Riko, Emi, and Satsuki called out. Elena had already pressed herself against Yuu's back without a word. The only non-pregnant one in the group, Elena still had her slender body. She rubbed her modest bust against Yuu's back and kissed his nape, already breathing heavily.  

Martina and Sayaka moved to wash their own hair while the four who'd finished washing theirs took over. All had tied up their long hair to keep it out of the way. Elena and Emi, with similar hair color and length, had twin buns like Chinese dolls—they'd apparently helped each other tie them matching. Riko had a center-parted ponytail showing her forehead. Satsuki, with her abundant hair, had a large ballerina-style topknot.  

Riko took Yuu's right leg and Emi his left as he sat on the stool. Elena handled his upper right side and Satsuki his left, all while pressing their bodies against him. Being washed by four pairs of soft skin heightened his mood.  

"Waha. Feels kinda like I became a king"  
"If Yuu wanted... you could have status like a king, you know~"  
"Nah, being student council president is enough for now. Normal's fine"  

Satsuki whispered in his ear while washing his left arm between her breasts. Though she'd gotten pregnant relatively later in this group, her naked body now clearly showed a pregnant belly.  

"My my, no boy suits 'normal' less than Yuu-kun"  
"Uun. But Yuu-kun's best point is not acting arrogant no matter how popular he is!"  
"I... don't care what happens as long as I can be by Yuu's side as his sister. As long as Yuu's here"  
"I agree with Elena-neesan! Me too~"  

Elena, who'd been washing his right arm as if with her breasts while hugging it, rubbed her cheek against Yuu's shoulder. Emi similarly kissed the hard muscles of his thigh.  

"Now now, wash properly"  
"That's right~. Once you finish washing your assigned parts... you know what to do?"  
"Y-yes" "Yes!"  

Both Elena and Emi responded and began meticulously washing Yuu's arms and legs. Everyone kept glancing at areas beyond their assigned parts. Naturally, the most attention went to his crotch.  

"Uwah! K-ku, that tickles!"  
"Just ticklish?"  

Riko and Emi's hands gradually moved from his feet toward his groin. Satsuki and Elena, having finished his arms, moved from shoulders to neck. All four had gentle, delicate touches—almost like caresses. Though they weren't directly stimulating erogenous zones, the slippery soapy state seemed to heighten sensitivity. His penis stood rigid, dripping precum. They all stole glances while competing to see who could pleasure Yuu most.  

"Hah... ah! Nkuh!"  
"Araan, what's wrong~, Yuu?"  
"Haa, haa, Yuu's nipples... they're all hard~"  

Satsuki and Elena brought their mouths to his ears while persistently washing his chest. Their hands pressed flat against his pecs, stroking around the edges.  

"Ri, Riko, there... hyah!"  
"Gotta wash here thoroughly too"  
"Nnffufu. Yuu-kun's belly too~"  

Riko and Emi's hands, having bypassed his groin, reached his abdomen. When Riko's nimble fingers swirled around his navel, Yuu couldn't help but cry out. Navels hurt if dug into too hard, which Riko understood. That's why Yuu felt ticklish yet strangely stimulated—similar to when his anus was played with.  

Emi's knuckles lightly brushed against his penis while washing his lower abdomen near the pubic hair, but didn't linger further. Being pressed against naked girls and touched everywhere kept him fully erect, but he felt he couldn't hold back much longer. He desperately wanted to ejaculate, but the crucial spot wasn't being properly touched. Yuu felt like he was being teased.  

Once Yuu's entire body except his groin was soapy, the four exchanged glances. Their gaze fell on the still-erect penis left untouched. Martina and Sayaka watched while washing themselves nearby. Haruka, who'd finished washing and only needed rinsing, also looked toward Yuu.  

"Hey, Kate and Ryoko, come over here?"  
"That's right. Come on"  

A clattering sound came from the opposite wall. Ryoko, with the shortest hair among the women, had already finished washing and only needed rinsing. She immediately responded to Riko and Satsuki's voices. Kate, with long hair, seemed still midway. She'd been facing the wall while Yuu had his hair washed, but when shifts changed, Yuu turned his back to the wall. He could see the two naked women washing themselves while seated at a distance.  

"That's right. Ryoko, Kate, come here too"  
"Okay, Leader! Let's go!"  
"Eh, w-wait!"  

At Yuu's invitation, Ryoko dashed over without waiting for Kate's reply. Though running in the bath was dangerous, she demonstrated her excellent physical ability at times like this. But about 3 meters away, she slipped and fell on her butt, sliding right between Yuu's spread legs—perfectly positioned between Riko and Emi. Seeing the energetically erect penis right before her eyes, her face instantly lit up.  

"Oho, Yuu's penis... haaaa... seeing it up close, it's amazing as ever"  
"Really, Ryoko... ah"  

Naturally, Kate couldn't stay alone. Yet she was still too shy to expose herself naked before Yuu. Compromising, she came over with generous amounts of soap covering her breasts and crotch. To Yuu, this state—more risque than a bikini—felt even more erotic. Without hair ties or scrunchies, she'd somehow tied her long blonde hair in a ponytail. As expected of a former beautician—deft with her hands. Kate followed Ryoko but stopped when she saw Yuu's naked body, especially the fully erect penis.  

The old Kate might have acted cool. After all, though she looked 16, inside she was an adult woman. She'd had sexual experience (albeit less than others) and wasn't a maiden who'd fuss over seeing a man's crotch.  

But now she blushed like a virgin her age, showing bashfulness. Her legs turned inward as she plopped down on the spot. Images of Yuu and Jane's intense intercourse flashed through her mind, heat gathering in her lower abdomen. Kate initially averted her eyes from his groin, but when the four finally reached out and touched it, making Yuu moan pitifully, she couldn't help but stare with intense interest.  

"Kyah! Ah! Hah!"  
"Onee-chan will clean Yuu's important place~"  
"Haa, haa, Yuu's... penis, penis... affun! Just stroking it..."  
"Ahaha, Yuu-kun's penis is twitching~. So cute!"  
"So hot and hard like this, dripping with lewd fluid... haa... wonderful"  

*Nuchu, kuchu, nuchu, jup, nuchuri.*  

Covered in soap, four hands touched every part from glans to coronal ridge, shaft, base, and testicles. The sticky wet sounds came from precum mixing with soap, but also from Elena rubbing her own crotch with one hand while diligently working. Yuu embraced Satsuki and Elena's shoulders on either side, surrendering to the pleasure. Seeing Yuu throw his head back and pant, Elena couldn't resist covering his lips and slipping her tongue in. Then Satsuki also kissed him demandingly, tangling tongues similarly.  

With four hands concentrated, washing alone should've finished quickly. But as if by agreement, they kept stimulating his penis while changing positions. After Satsuki, Emi leaned in while keeping her hands moving and shared a deep kiss. Then Riko stretched out her tongue and claimed Yuu's lips. Both Emi and Riko were thoroughly aroused, vigorously moving their hands while seeking Yuu.  

"Yuu-kun"  
"Your penis soon"  
""Want to ejaculate?""  
"Ah, ahh. I want... to ejaculate... yeah. Ryoko, Kate, if you want, stroke my penis too"  
"!"  
"Ahh, gladly!"  

Ryoko joyfully reached out her right hand and began stroking alongside Riko and Emi who were already lightly gripping the shaft. Truthfully, Kate also felt the urge to touch Yuu's skin. But her past-life ethics made her hesitate to initiate contact with a man who wasn't her lover.  

While Kate hesitated, Yuu approached climax. Elena teased the glans with three fingers. Emi and Ryoko rapidly stroked from coronal ridge to base with overlapping hands. Riko gently massaged both testicles. As for Satsuki, she'd slipped between Yuu's butt and the stool and was playing near his anus.  

"Hii... agh! Au au, Sa, Satsuki-nee, my butt... no... ah! Ah! I'm cumming... nnnn~~ ugh! Ejaculating!"  

Unable to resist the multiple hands urging ejaculation, Yuu arched his back and trembled violently. The moment his hips jerked, semen gushed forcefully from his urethra.  

*Dopyu! Dopyu! Dopyuu!*  

"Ahh!" "Anh!" "Kufu, so much" "A, amazing..."  

Whether because his erection had lasted so long, the volume was substantial. Even after the forceful spurting subsided, thick semen dripped onto the women's hands. Since they'd been pressed against him, milky fluid had splattered onto breasts and swollen bellies too. Riko, Emi, and Ryoko—who'd been holding Yuu's legs close—got some on their faces and naturally licked it off, swallowing with happy expressions. Elena and Satsuki also scooped semen off their chests and bellies as if it were precious, savoring it as they swallowed.  

Kate, facing front, was shielded by Ryoko and remained untouched. Feeling left out, Kate felt slightly disappointed. Confused by her own feelings, she shook her head vigorously.  

---

### Author's Afterword

This time it was roughly the expected development, but imagining over half of the nine women with noticeably swollen pregnant bellies is incredible, isn't it?

### Chapter Translation Notes
- Translated "裸のつきあい" as "Naked Interaction" to maintain consistency with previous chapter
- Preserved Japanese honorifics (-chan, -kun, -nee) per style rules
- Used explicit anatomical terms: "penis", "testicles", "ejaculate", "semen" as required
- Transliterated sound effects: "Ufufu" (うふふ), "Nuchu" (ぬちゅ), "Dopyu" (どぴゅ)
- Maintained original name order for Japanese characters (e.g., Hirose Yuu)
- Translated sexual acts literally: "stroking", "massaging", "ejaculating"
- Rendered internal monologue in italics: *(This is concerning.)*
- Kept dialogue structure: new paragraph per speaker, except when attribution precedes dialogue