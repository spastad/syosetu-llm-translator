## 337. Midnight Resolve ① ~You Overflow So Much It Hurts~

"Hmm... what?"

When Yuu awoke, his vision wasn't pitch black but dimly lit.  
Looking around, only faint light from small downlights along the walls pierced the darkness.  
He realized he was lying on his back in bed, sandwiched between soft sensations on both sides that left him nearly immobile.  
As he'd vaguely expected, glancing sideways revealed Martina pressed against his right side and Elena on his left.  

*(When I woke yesterday morning I was shivering from cold, but now it's almost too warm)*  

Feeling their body heat, Yuu smiled wryly to himself. But he wasn't unhappy about it.  
He remembered enjoying delicious food with his beloved women after leaving the large bath last night.  
But around the time he returned to his seat after chatting with everyone, he'd started yawning repeatedly.  
His full stomach must have brought on sudden drowsiness.  
His memory grew fuzzy after that, though he recalled saying "Thank you for the meal" before likely being helped to his room by Kanako and Touko. He had no memory of getting into bed himself, so he must have already been asleep.  

As he retraced his memories, Yuu became fully awake and simultaneously felt thirsty and needing to urinate. He decided to get up.  
The problem was extricating himself from Martina clinging to his right arm and Elena entwined around all four limbs.  
Carefully peeling them away without waking the sleeping pair, he finally sat up and got out of bed.  

It was a spacious bedroom.  
He could see someone sleeping in another bed further away.  
As his eyes adjusted to the dimness, he recognized Haruka and Satsuki sleeping together in the double bed.  

Walking across plush carpet thick enough to muffle footsteps, Yuu gently opened and closed the door as he left the bedroom.  
He entered a lavish room with a glittering chandelier - a suite extravagant enough to be featured on TV.  
The living/dining area and kitchen were larger than his home, complete with a large screen, stereo system, and even a bar counter.  
Even to his untrained eye, the casually arranged furniture looked expensive.  
Though he'd enjoyed some luxuries since being reborn in this world, Yuu's middle-class sensibilities made such opulence feel unfamiliar.  

"Oh?"  

To Yuu's right were the kitchen and dining area, where most lights were off.  
To the left was the brightly lit living room.  
There, facing each other on a black leather sofa, sat two women. Yuu smiled faintly but headed to the bathroom first since Kate and Ryoko appeared fast asleep.  

After using the toilet, Yuu went to the kitchen, poured himself water, and drank.  
Though just tap water, it tasted heavenly to his parched throat.  
Hydrated, he approached the sofa.  
A square glass container on the low table looked like Western liquor - whiskey or brandy. Two glasses held dregs of liquid with dried snack remnants.  
And the empty glass he'd seen earlier in the sink.  

Yuu guessed someone - probably Haruka - had invited Kate and Ryoko for drinks.  
Though Kate was underage (18), they'd likely overlooked formalities given the circumstances.  
Having just seen Haruka in the bedroom, she must have retired first.  

Ryoko slept on her back with loud "kukaa" snores.  
Her legs were spread, her yukata completely open. From Yuu's vantage point, her panties were just out of sight but her slender legs were visible up to her dangerously high thighs.  
Opposite her, Kate sat slumped, head nodding. She still held shelled pistachios in her right hand as if about to eat them.  
Just as Kate's head was about to loll sideways, Yuu swiftly slid into the left seat beside her.  

Yuu sinking into the sofa and Kate's head thumping onto his shoulder happened simultaneously. Her neatly tied hair had come slightly loose, its strands lightly tickling his neck.  

"Fwa... nyehh!?"  

Anyone would startle finding someone unexpectedly beside them.  
Kate looked ready to jump up in shock, but calmed immediately upon recognizing Yuu.  

"W-what? Don't scare me like that... Wait, was I asleep?"  
"Seems so. I just woke up needing the bathroom and water."  
"Hmm... Haruka-san said she was turning in first... Then Ryoko and I were talking... It's already 1 AM?"  

It matched Yuu's assumptions.  
The premium liquor befitting the suite seemed to have tempted them into refills despite planning just one drink.  
Kate's cheeks were slightly flushed but her speech remained clear - perhaps her racial heritage gave her alcohol tolerance despite being underage.  
Her disheveled hair and the glimpse of cleavage from her open collar made her look incredibly alluring.  

Noticing Yuu's gaze, Kate adjusted her collar.  
Feeling awkward, Yuu looked forward only to see Ryoko scratching her chest, her yukata now so disheveled it barely functioned as clothing, exposing her nearly naked form.  
She wore plain white bra and panties borrowed from the hotel, but her figure compensated for their simplicity.  
At this inopportune moment, Yuu glanced around nervously.  

"Use these."  

Seemingly reading his mind, Kate handed him two stacked hotel bath towels.  
Yuu draped them over Ryoko's chest and lower abdomen.  

"Can't eat anymooore~"  

Sitting side-by-side, Yuu and Kate chuckled at Ryoko's sleep-talk.  
With the late hour, Kate and Ryoko should retire to the bedroom. But Yuu had an agenda and spoke up in the relaxed atmosphere.  

"I've been wanting to talk... Is now okay?"  
"Yeah. Fine. Who knows when we'll get another chance like this."  

Kate answered immediately without hesitation. Perhaps she'd been thinking the same.  
Originally, Kate was to relocate to Matsumoto City in Nagano Prefecture, working while attending night school.  
After completing investigative interviews about the kidnapping, she'd likely resume those plans.  
Tonight might be their last calm conversation opportunity.  

"Want a drink?"  
"Nah, I'll pass."  

Kate mischievously gestured to the liquor, but Yuu declined.  
Unfazed, Kate began making a rocks glass with the remaining melting ice. Whether she'd always enjoyed alcohol or just liked how it tasted in her new body, Yuu couldn't tell.  
He went to the kitchen and boiled water in a kettle to brew single-serve drip coffee he'd found earlier.  

With drinks prepared, they began talking.  
Sitting side-by-side on the sofa, a fist's width separated them.  
Not touching directly, but close enough that slight movement would connect them.  
This distance perfectly reflected their current relationship - much closer than their first meeting, yet not lovers. Just opposite-sex friends sharing chastity values from their previous world. Yuu at least believed they should maintain boundaries.  

"First... about Jane. We did the right thing, right?"  
"What, bringing that up now?"  
"Eh? Well..."  

Jane had been airlifted separately to a police hospital for emergency surgery.  
The bleeding control had been insufficient - leaving her untreated would've been dangerous.  
With most perpetrators dead, police were anxiously awaiting the prime suspect's regained consciousness.  
Though not life-threatening, she remained under heavy guard in Akita Police Hospital's ICU.  

Despite suffering violent abuse, Yuu felt uneasy about having sex with his blood-related mother in this world before knocking her unconscious - right before Jane's eyes.  
This hesitation revealed Yuu's fundamentally kind nature.  

"You had no other choice then, right? And anyone could see she'd snapped mentally. Only you could've resolved that, Yuu."  
"Yeah."  

No ordinary man in this world could have done it.  
The optimal solution would've required Sakuya himself - whom Jane desperately wanted - but he died 16 years prior.  

"Unlike you, I never had an environment where I could see her as a parent..."  

Kate smiled sadly, looking down.  
With age comes appreciation for parents - Yuu deeply valued Martina's selfless love, regardless of his mental age.  

"B-but! I met good friends. That's one thing I was blessed with. Roaming nightlife spots with just girls. Going toe-to-toe with gangs picking fights... Felt like being a kid again. It was fun."  
"Haha... I get that."  

Their eyes went to Ryoko sprawled on the sofa.  
The supine Ryoko groaned "Uuun" and rolled over facing the sofa back. Though covered by towels, her well-shaped buttocks drew attention.  

"That was May, right? I acted recklessly... Thank god I met Red Scorpions members that day."  
"Seriously. Two months had passed, right? You knew young men couldn't safely walk outside here. You're an adult inside."  
"Really, my bad."  

When Kate lightly elbowed him, Yuu bowed his head. Back then, he'd been overly elated by his privileged new life.  
He recalled groping Kate's breasts on their way home and receiving a fierce elbow strike.  
Though he'd found her behavior odd, he never imagined she was also reincarnated.  

"Right. My marriage ended in divorce, but I'd wondered how Keiko-san was doing."  
"Huh!?"  

Yuu looked directly at Kate.  
Though he'd never visited salons, he'd admired Keiko - his ex-wife's favorite stylist - for her work ethic and personality.  
Post-divorce, he had no reason to visit a female-dominated salon anyway.  
After his first job, workplaces only involved women a generation older. Matchmaking attempts failed quickly.  
Keiko was the last attractive contemporary woman he'd met besides his ex-wife.  
Though not a romantic prospect (he'd been married and faithful), he'd genuinely admired her.  

"I'm not joking! Like I said before, I'm truly glad I met you - not my ex-wife - in this world."  

Having interacted with many women, Yuu had learned to express appreciation openly.  
Assuming unspoken understanding was difficult even for families.  

Kate was visibly flustered by Yuu's directness.  
Her hands fidgeted as she untied her blonde hair and looked down, using the cascading locks to hide her face.  
But Yuu could see her ears turning red.  

Though not touching, her hair was within reach.  
A pleasant fragrance wafted from the silky blonde strands.  
Outwardly calm, Yuu's heart raced as he fought the urge to touch her.  

"Me too."  
"Hm?"  
"I'm also... glad it was you."  
"Eh? What did you say?"  

Kate looked up, meeting Yuu's eyes.  
Her cheeks were flushed as if feverish.  

"I-I'm... happy... to have met Yuu again!"  
"Th-thank you."  

Impulsively, Yuu reached for Kate's hands.  
She flinched but didn't pull away.  
Instead, their fingers interlaced, clasping tightly like lovers.  
The feel of her soft hands made warmth surge in Yuu's chest.  

"U-um..."  
"Y-yes?"  
"Do you really have to go to Matsumoto?"  
"Uh..."  
"You have team friends here, got close with Sayaka... Once the case resolves, things should calm down..."  
"That's... but... but..."  
"Whoa!?"  

Kate suddenly pressed her forehead against Yuu's chest, making his heart race.  

---

### Author's Afterword

I don't know what romance between single forty-somethings feels like, but real-world complications seem tough.  
Though Yuu and Kate are mentally forty-somethings, their 16-year-old appearances make sweet moments acceptable.

### Chapter Translation Notes
- Translated "くかーっ" as "kukaa" for snoring sound effect
- Preserved Japanese honorifics (-san for Haruka)
- Translated "貞操観念" as "chastity values" to maintain thematic consistency
- Rendered "恋人繋ぎ" as "lovers' clasp" to convey intimate hand-holding
- Used explicit term "bra and panties" for ブラとパンティ
- Maintained original name order for Japanese characters (e.g., Hirose Yuu)
- Translated "浮かれていた" as "overly elated" to capture Yuu's past mindset