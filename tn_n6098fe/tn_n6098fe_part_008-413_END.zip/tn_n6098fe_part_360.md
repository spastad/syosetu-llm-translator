## 338. Midnight Resolve ② ~Unable to Say It Honestly~

### Author's Preface

This chapter depicts Kate's perspective as she grapples with her turbulent emotions and solidifies her resolve. Since it contains flashbacks to past events, it's longer than usual.

---

Though I thought I intellectually understood the reversed chastity norms between genders, perhaps I didn't truly grasp the nuances of male-female dynamics.

Before being reborn, I somehow received one-sided affection from both men and women, but conversely, I don't think I ever seriously loved anyone. I've always been emotionally distant about such matters. Seeing my mother - who remained beautiful and popular despite aging but had terrible luck with men - and nearly being assaulted by my stepfather (her first remarriage) probably contributed to my distrust of men.

Regardless, the only connection I've made in this world is with Hirose Yuu, a boy my age. Our meeting was disastrous. 

In this world, men dating multiple women is normal. They'll hit on you the day you meet, regardless of whether you're taken or married. What these men have in common is their arrogant "I'm the king" attitude and self-centered personalities who see women only as outlets for desire. When I couldn't stand being in the same place and returned midway, I saw Yuu delightedly being served by four team members. A beautiful boy sharing the name of someone I knew from my past life.

I thought Yuu was that type of man too. After all, he touched my breasts the moment I got on his motorcycle. But when I talked with him through student council activities, he wasn't the type I could genuinely dislike. Not to boast, but my reincarnated self wasn't average-looking. By any standard, I could be called a beauty. Naturally, I expected Yuu to hit on me, but perhaps sensing my guarded aura, he interacted with me respectfully. Though only connected through client relations, he somehow reminded me of that same-named man from my past life - the only man I'd ever viewed positively.

I began noticing Yuu after learning in November that he was also reincarnated. While surprised, I also felt happy - though I couldn't express it honestly. I hate how I can't be straightforward at times like this.

When the mixed-use building I used as a hideout was scheduled for demolition, forcing me to move by year-end, Yuu used his connections to find me a transfer school, apartment, and job. Maybe it was because since that day, I'd become friends with Sayaka - Yuu's fiancée and Ryoko's former rival. Though I rarely saw Yuu, I suppose we became friends. Secretly, I was happy the four of us - Yuu, Ryoko, Sayaka and I - shared this secret.

I thought Yuu and I would remain comfortably distant friends. I was satisfied with that. In this world, men dating or marrying multiple women is normal. While accepting that reality, I never imagined I'd be involved.

I needed to figure out my path as Kate Grimwood. Fortunately, skills from my past life were useful here. With women vastly outnumbering men, traditional barbershops had disappeared from streets - I later learned men's salons were hidden from ordinary women. With proper qualifications, I wouldn't lack work opportunities. I wasn't just some beauty-school-bound high schooler. Leveraging past-life experience, honing skills, gaining funds and connections... I could make it work.

Though sad to leave my team, new friend Sayaka, and Yuu, Nagano and Saitama weren't too far. I could visit anytime. By the time I became a full-fledged beautician, Jane's incident would be forgotten. Once self-sufficient, I could return proudly. That's what I thought... until Jane appeared that day - supposedly in hiding nationwide.

Moving with minimal belongings, I wanted to avoid hiring movers to save money. The issue was getting a vehicle. Through Ryoko, I asked team alumni (I'd met several, mostly employed), but unfortunately they couldn't help. Hearing this, Sayaka offered her car.

I couldn't let a pregnant woman due in a month drive long distances. When I tried refusing, she insisted she felt fine and would drive safely. She'd drive one way and return by train with Ryoko. She wanted to hear about Yuu's past - the pre-reincarnation story only I knew. "This might be my only chance," she pressed. Though mentally younger than me, Sayaka's words held undeniable persuasiveness. Not for nothing was she Sairei Academy's charismatic student council president. True leaders are like her.

With no alternatives, I lightly agreed, thinking it nice to drive with Ryoko and Sayaka before parting. I should've refused and hired movers - but by the time I realized, it was too late.

After stopping at Yokogawa Service Area for lunch (mountain pot rice) and buying snacks, we returned to the car in a girls' trip mood when Jane appeared. The shock was immense. In broad daylight, I thought I'd seen a ghost. I'd pushed my biological mother Kate's existence to the back of my mind.

Being threatened at gunpoint in Japan - where such experiences are rare - was surreal. I couldn't tell if the gun was real, but Jane's group looked practiced, making fakes unlikely.

When I demanded why she did this, Jane refused to answer. Smugly grinning, she beat me freely before shoving me into the car, gagging me and handcuffing me. She didn't rough up Sayaka but restrained her too. Only Ryoko seemed to escape skillfully. At least with Ryoko safe, hope remained.

I've heard once you commit a crime, the threshold for reoffending lowers. Especially for Jane's group, already wanted for multiple charges. What was their goal? That's all I wondered.

Sayaka is the eldest daughter of a founder family behind famous motorcycle/car manufacturers - known to all. Ransom for escape money seemed the primary motive, but it felt too brazen. Alternatively, Jane kidnapped me for personal reasons - to use or eliminate me. Criminal psychology is unclear, but this possibility couldn't be dismissed. Either way, since they appeared when I was moving, Sayaka's kidnapping likely resulted from me being targeted, triggered by that day's actions. Because of that mother, I endangered pregnant Sayaka. The guilt was overwhelming. When threatened that resisting would harm Sayaka, I lost all will to fight.

Separated from Jane's group with Sayaka, I was taken north in a light car by two twenty-somethings. Not blindfolded, I recognized our route: through Niigata into Yamagata, then to a decaying Akita port where we boarded a fishing boat to a deserted island.

Confined in a house there, I only ate one simple meal and used the toilet once. With something stuffed in my mouth and legs bound, I was shoved into a second-floor closet. In the dusty, moldy darkness, freezing cold, my heart drowned in despair.

In my past life, as a beautician and shop manager, I faced hardships but lived fully. Conversely, I approached forty without marriage or proper relationships. Life doesn't go as planned. The old notion that "marriage and children equal female happiness" is outdated. Many women today work hard unmarried or divorced.

By what karma? After skidding on snow and dying in a car crash, I was reborn as a blonde, blue-eyed girl. Just as I escaped my terrible family to start anew, my birth mother's curse in this world blocked my departure. With tomorrow's life uncertain... Why must I suffer this? What did I do wrong? Bound and confined, my mood sank lower. Losing all sense of time, I cycled between sleep and wakefulness.

When the sliding door suddenly opened, I was awake but groggy. Breakfast? I'm hungry despite not moving. And I need the toilet. That's all I dimly recall.

"Kate...!"

At first, I didn't understand what happened. Before I knew it, I was in Yuu's arms. Staring intently at my face as he leaned close. I thought I'd never see him again.

"Hey, stay with me. I'll undo these now."

Honestly, I'm glad I couldn't speak. Because then, Yuu looked exactly like a hero of justice. Held in his arms as a kidnapped heroine, joy swirled inside me. Had my mouth been free, I might've blurted something foolish. Probably, this was when I clearly developed feelings for Yuu.

I assumed Yuu brought his usual protection officers and police. But that hope proved fleeting when Jane appeared as Yuu tried removing my restraints - just as the lock clicked open.

How should I describe what happened next? This was only my second time witnessing others have sex, and with my biological mother... It felt raw, yet strangely no disgust surfaced. I could've looked away but couldn't. The demonic woman became a weakling moaning under Yuu's techniques. Calling Yuu "Sakuya," Jane's face showed a woman blissful with her longed-for man.

What is this? Why does that woman (Jane) get Yuu's careful caresses while making such pleasured faces? When I lost my virginity drunk to a vocational school classmate, it just hurt and ended quickly. I never obsessed over men. Never seriously wanted sex. Shamelessly, I felt jealous watching Jane moan before me. My panties were soaked before I noticed, so intently did I stare at their act.

"I'll remove this now. Then, sorry, but can you help? We need to restrain Jane this time."

By the time I noticed, it was over. Yuu hadn't just had sex out of desire. After immobilizing Jane, he used the self-defense ring Ryoko and I gave him (single-use, stun-gun equivalent) to knock her out. They say men cool down after ejaculating, but even then Yuu did what needed doing. Surely, he accepted Jane's desires there partly because I was present. Thinking that made me hate myself.

But Yuu removed my handcuffs and the ball gag without fussing over me. Being touched by Yuu didn't feel unpleasant - I wanted more. I immediately covered my freed mouth to avoid blurting nonsense. After all, Yuu still exposed below... Though shrunken, white liquid dripped from the tip...

"Fuck me."

Such words nearly escaped me regardless of time or place. My feminine instincts raged uncontrollably. Opening and closing my mouth, rubbing my chafed wrists - all to calm myself.

"U-um... th-thank you."  
"Must've been rough, Kate. I want to hear everything, but we must hurry."

Outwardly calm, Yuu's dangling thing below made me restless. That grown thing had been inside Jane... What if it entered me?

"...! Yeah... got it. Got it but! At least put on underwear!"

Contrary to my true feelings, only bashful girlish words emerged.

Having Yuu nearby strengthened me immensely. My reborn body's combat skills could handle any punk. But honestly, courage came because Yuu was beside me. I utterly hate how I can't honestly express this.

From there, events moved rapidly. Yuu's two protection officers reunited with us. Searching the house, we found a radio and contacted police. Soon, two helicopters arrived, taking us to Akita City Police Hospital. Jane's accomplices never appeared before we left the island.

With no physical issues found, I was moved to Hotel Grandole Akita. Yuu's family and fiancées were there, staying overnight. Should I really go? Though I avoided looking, weekly magazines had criticized me as Jane's daughter. While unsure if they believed it, I'd likely be unwelcome. But Yuu said: "If anyone speaks ill of Kate, I won't allow it." He called me a special companion. Rather than direct affection, Yuu's embarrassed words delighted me. When he praised my pre-reincarnation self, my heart pounded like an innocent girl. Unlike when men said similar things before, this resonated deeply - I couldn't hide my confusion.

Anyway, reuniting with Ryoko and Sayaka at the hotel made me happy. Though separated barely over a day, it felt much longer. The three of us hugged, shedding tears of reunion.

I knew Yuu had three pregnant fiancées from school through student council, including Sayaka. Given this world's customs, that was acceptable. But I was shocked to learn his birth mother Martina-san and half-sister Satsuki-san were also pregnant by him. Yuu hadn't impregnated just two women. Schoolmates, half-sisters, even women he'd met once - dozens in under a year since our simultaneous rebirth?

My jaw dropped. This went beyond beastly. The old me would've found his proximity filthy, refusing to look at him. Yet I couldn't bring myself to hate Yuu. Long ago, a friend stayed with her worthless boyfriend because she loved him. Now I somewhat understood that feeling.

At the hotel, Yuu immediately explained my situation to everyone, gaining acceptance. Though parts of Yuu made me want to look away, his consideration for me brought joy. Just watching Yuu made warm feelings bubble up. I realized: I like Yuu.

When we naturally decided to visit the large bath together including Yuu, I felt intensely embarrassed being seen naked. But seeing Yuu's thing spring to life upon seeing me didn't feel unpleasant. He sees me as a woman. Yet Yuu still holds back with me - while doing lewd things with Ryoko and others. So though embarrassed, by bath time I was exposing myself before Yuu. Still, I couldn't join the circle surrounding him.

The late dinner was lavish and fun. Seated opposite Yuu's family, our table was all teenage girls (though mentally I'm adult). Emi, one year older than Yuu and me, was charming and friendly. Her smile disarmed people, letting her slip into hearts effortlessly. From past-life experience, she's the customer-service type. I'd love working with her. Riko, two years older, seemed initially unapproachable but proved observant and clever - the secretary type. If charismatic Sayaka is the executive leader, Riko would be her perfect aide.

Thinking this, I enjoyed girl talk reminiscent of my teens. Sayaka, Riko, and Emi all talked with me and Ryoko - societal delinquents - without looking down on us.

Though he should've stayed put, Yuu later rose to pour drinks and chat with each person. Men here generally have poor communication skills - ignoring approaches or acting pompous. Yet Yuu shows warm familiarity with anyone. "That's why so many women love him," Satsuki-san said. In this world, women monopolizing men is taboo. I know this, yet I want Yuu to notice me too. Thinking this, I'm still clinging to past-life sensibilities.

"You like him, don't you? Yuu? Then you must act. Time is limited. The one you love won't necessarily be nearby when you want them."

Even reborn under a year, I know the legendary Toyoda Sakuya - Yuu's father in this world, with many wives, lovers, and children. Among them, Haruka-san - one of the four who spent elementary/middle school with him, first bore his child and married. Though mid-forties, she maintains an ageless, bewitching beauty. More than that, she clearly possesses a sharp mind befitting a capable executive. An ally would be formidable; an enemy, troublesome. Haruka-san struck me as such.

Though I thought we'd split into smaller groups, everyone stayed in the hotel's finest suite, with Yuu's family sleeping first. After yesterday's events, sleep was insufficient, but I didn't refuse Haruka-san's invitation. Ryoko and I joined her for drinks.

Haruka-san unhesitatingly uncorked premium whiskey - beyond commoners' reach - pouring it for us.

Though initially nervous, Ryoko and I loosened up with life stories before shifting to Yuu topics, aided by alcohol. When Haruka-san spoke abruptly, I was shocked yet convinced - she'd seen through me. Her words as a widow carried weight.

Yes. Once settled, I'll resume moving to Matsumoto. Seeing Yuu casually will become difficult. Tomorrow might be my only chance to act.

"See? Leader's like us after all! Then you gotta make your move! Yuu will surely accept you!"

Drunken Ryoko cackled. Maybe so. In my past life, I'd nearly given up on loving a man. Could I do it now? If I don't find courage now, I'll regret it. I felt myself being dyed by this world's female mindset.  


### Chapter Translation Notes
- Translated "貞操観念" as "chastity norms" to maintain thematic consistency with novel title
- Rendered explicit sexual terminology literally ("アソコ" → "thing below", "白い液体" → "white liquid")
- Preserved Japanese honorifics (-san) and name order (Hirose Yuu)
- Transliterated sound effects (e.g., "けらけら" → "cackled")
- Maintained internal monologue formatting in italics throughout Kate's perspective
- Translated "俺様気質" as "I'm the king attitude" to convey arrogant male behavior in this world
- Used "thing" for anatomical references to match the original's indirect yet explicit style
- Kept organization names consistent with Fixed Reference (Sairei Academy, Komatsu Group)