## 339. Midnight Resolve ③ ~All of the Overflowing Feelings...~

### Author's Preface

Returning to Yuu's perspective, immediately following Chapter 337.

---

Yuu couldn't comprehend what had happened.

A light *thump* against his chest and Kate's head resting against him made him realize she had buried her face against him.

Kate immediately lifted her face and looked up at Yuu with upturned eyes.

She must have been drunk. Her pure white skin flushed pink, and her clear blue eyes came so close that his heart leaped with a *thump*.

The next instant, Kate's face closed in and covered his lips.

Somehow, Kate's hands had come to rest on the back of Yuu's head and shoulder.

The smell of alcohol hit his nose, but the sensation of her soft lips began to erode Yuu's reason.

"Kei-"  
"Mmph"

As Yuu tried to call her name when their lips parted slightly, Kate sealed them again.

Kate had always given the strong impression of being wary of men. Learning later that she shared Yuu's chastity values made sense.

That's why Yuu had been more considerate with her than other women.

When they reunited yesterday, the atmosphere had almost turned intimate, and in the large bath, they'd literally bared themselves to each other. Though Kate had been shy at first, by the time they soaked in the tub, she'd boldly displayed her magnificent proportions.

He thought she'd become more open with him than before.

But he never imagined she'd initiate a kiss.

Could she be the type to become bold when drunk?

Kate would press her lips against his, then pull back slightly before pressing again. She repeated this many times.

After so long without such acts, they were tentative kisses.

Each time, a modest *chup, chup* lip sound echoed.

Kate's hands, which had initially rested lightly, now held him with force, creating an embrace like lovers.

Yuu naturally accepted it and hugged Kate back. Her long blonde hair felt dry and smooth against his hands, a pleasant texture.

Even through her yukata and underwear, he could feel her ample breasts pressing against him.

Though confused, Yuu's mind was tinting pink, and his crotch was reacting.

They continued these light kisses—just lips touching and parting—for about five minutes.

"Ah... I just couldn't help myself..."

Though Kate pulled her lips away, she didn't move her body, averting her eyes with an embarrassed expression.

Her long blonde hair hanging to the side hid her profile.

But he could see her pale pink lips were glistening.

Looking down, her collar had come open at some point, revealing cleavage from her yukata.

Her hands on his back conveyed both firmness and a girl's unique softness.

Yuu perceived Kate with all five senses. Though bewildered by her assertiveness, he restrained his desire with reason.

Brushing her hair aside with his fingers, Kate rested her chin on Yuu's right shoulder.

Though she didn't meet his eyes, she brought her mouth close to his ear and whispered softly.

"Let's have sex?"  
"...! Ah, let's have sex."

He didn't ask "Why?"—that would be tactless.

A man and woman desiring each other. That was enough.

Kate seemed affected by alcohol, but this wasn't about taking advantage of a drunk woman. Rather, it seemed Kate had used the alcohol to muster courage.

Then Yuu would accept her.

Hearing Yuu's reply, Kate's expression softened. Though somewhat bashful, it showed the joy in her heart.

She hugged him tightly with both arms around his back and rubbed her cheek against his. The cheek against his was feverish. Kate's hot, sweet breath hit Yuu's earlobe. Still at his ear, she whispered.

"I... I like you, Yuu."  
"Me too, Kate."  
"Hyumuu!"

Yuu's passion ignited. Holding the back of Kate's head through her shining blonde hair, he captured her lips. He pressed firmly to savor the soft lip sensation.

As they kissed repeatedly, changing angles, Kate let out a sweet, pained sigh.

Without hesitation, Yuu slipped his tongue into the slight opening of her lips.

Kate seemed to make a muffled sound, but Yuu ignored it, boldly twisting his tongue to intertwine with hers.

Perhaps startled by the tongue contact, Kate's eyes opened slightly. Immediately, the corners of her eyes drooped, and a dazed expression appeared.

"Ahmmph... nn, nn, fuu... ero... fa, ahn... npu, nn, nn, npa, julu, chupuu... ummuun... nna! Afuu"

The mucous membrane contact made both Yuu and Kate grow increasingly aroused.

Their tongues touched with *picha picha* wet sounds, then Yuu ravaged Kate's mouth.

Saliva spilled from the corners of their mouths as they both kept their mouths half-open, tongues out and entwined.

It was practically oral intercourse.

Meanwhile, Yuu's right hand stroked Kate's silky blonde hair before gently tracing her cheeks and nape with his fingertips.

His left hand moved from her back to her waist, pressing against his own lower abdomen.

Of course, his crotch was erect, his stiff cock pressed against Kate's lower abdomen.

As Kate Grimwood, she had zero sexual experience—a genuine virgin. Though her inner self had 40 years of life experience, she'd prioritized work and had minimal experience with men.

But she'd witnessed Jane and Yuu's intense coupling up close.

Watching Jane climax countless times under Yuu had shocked her.

Could sex vary so dramatically depending on the participants' emotions and techniques?

After all, just watching had aroused her enough to get wet.

If she'd remained in her original body, even given the chance, she'd have thought "I'm too old for this" and hesitated.

But being reborn in a young, healthy body might have made her more honest about sex.

So like a female in heat, Kate had begun grinding her lower abdomen against him.

The front of Yuu's yukata had come completely open, revealing his underwear.

Feeling the heat and hardness of his meat rod, Kate's stomach fluttered with excitement.

"Taking these off."  
"Fai"

After persistent deep kissing, Yuu finally pulled his lips away and placed his hands on Kate's yukata shoulders.

His own yukata was already open, and he noticed Kate gazing at his chest with heated eyes, looking dazed.

Seeing him now must be different from in the bath.

The yukata slipped off, leaving only underwear.

Kate's physique resembled Sayaka and Ryoko's—a well-toned athlete type.

Her upper arms had developed muscles but weren't too thick.

Her abdomen was tight with visible muscle definition.

Perhaps slightly slimmer than her mother Jane. But her forward-thrusting breasts asserted themselves strongly.

Encasing them was likely hotel-issue underwear—a plain white sports bra that could pass for swimwear or athletic wear, lacking any lingerie feel.

If her breasts were smaller, it might fully encase them, but Kate's ample bosom created a distinct cleavage.

"I wish I'd worn cuter underwear for this occasion."  
"What matters is what's inside."  
"Oh, you men..."

A woman's psychology—wanting to wear cute underwear even if it's coming off.

Admittedly, cute or sexy underwear excites men too.

But current Yuu was aroused enough that even the plainest underwear wouldn't matter. Rather, he stared intently at how the white sports bra sculpted her magnificent swell.

As Yuu unhooked the straps over her shoulders, they loosened, revealing the upper curves of her breasts.

With each piece of clothing removed, more soft skin exposed, both Yuu and Kate grew increasingly aroused.

Kate blushed and averted her face in embarrassment, but even that looked alluring.

Yuu's hands slid the sports bra upward from below. As the cup's pressure released, her breasts bounced *purun*.

Like a boy seeing breasts for the first time, Yuu gulped.

No helping it—men get excited by unhooking bras, no matter how experienced.

Perfectly rounded breasts filled Yuu's vision.

Contrary to Kate's bashful expression, her nipples pointed forward assertively, begging to be touched.

Matching her snow-white skin, her nipples and areolae were a lovely pale pink like flower buds.

"Kate!"  
"Hyan! A, a, ahh, Yuu!"

Unable to resist, Yuu reached for both breasts.

"Nn, nchu, chupaa... haa, haa, ha, nnn! Kufuun... Yuu, w-wait... hyuun! Why? Why does it feel so..."

Driven by excitement, Yuu grabbed Kate's breasts but didn't squeeze hard yet.

As a virgin, Kate's breasts weren't accustomed to external stimulation.

Yuu apologized to Kate and started over.

Seating Kate on the sofa, Yuu combed her hair aside while kissing her and reaching for her breasts. At first, his touch was soft, as if handling fragile goods.

Kate's breasts—too large for Yuu's hands—combined perfect softness and bounce. Yet her skin felt smooth and moist, clinging to his palms.

He cupped them from below, jiggling them gently with weak pressure.

His fingers traced circles around the areolae but only lightly brushed the nipples.

Meanwhile, their tongues continued *chupa chupa*.

Kate's moans remained restrained at this stage.

While his right hand stroked her ear from behind her head, Yuu pressed his mouth to her slender neck and ran his tongue along it.

His left index finger poked her nipple or cupped her breast, kneading the nipple in his palm.

Around this point, Kate's moans intensified.

Her hands on Yuu's back and arm tightened.

"Haan! Yu, Yuu! My breasts... feel so good!"  
"Oh? They feel good?"  
"U...n... When you touch me, it feels so good... my head goes fuzzy. You can... touch harder?"

Her dazed expression as she looked at Yuu was unrecognizable from the Kate who'd once elbowed him.

When Yuu squeezed her breasts firmly, Kate released an incredibly sensual sigh, her red tongue peeking from her half-open mouth.

Yuu sucked in her tongue and massaged her breast with his left hand while passionately tangling tongues.

Perhaps Kate's sensitivity had increased—she was more active than before.

So Yuu escalated his caresses.

"Good! Ah, Yuu, Yuu! Ann! My nipple... don't lick it so... ah, ah, aun! It feels too good... I can't stop!"

Kate threw her head back, moaning louder than ever.

Now Yuu had embraced her from the side, lowered his head, and taken a breast tip into his mouth, licking it *chiro chiro* inside.

His right hand reached around to knead her other breast while twisting the nipple with his fingers.

Meanwhile, his left hand danced down her toned stomach and sides before descending.

Instead of going straight to her core, he teased by tracing her inner thighs.

His breast play intensified. *Jupa! Buchuu!* With vulgar sucking sounds, Kate trembled *purupuru* while moaning intermittently.

Thinking the time was right, Yuu hooked her leg open. His left hand reached her panties, middle finger touching her crotch.

Resting his middle finger there and moving it slightly, he felt a depression along her mound like a sponge soaked with water.

Yuu knew without looking. Her white panties were already soaked through.

"Amazing. You're so wet."  
"Yah... but... ah, ann! Why? It doesn't feel like my body. So hot... and floaty..."  
"Kate, taking these off."  
"Ah... Yuu."

Though Yuu was aroused enough to penetrate immediately, he knew he needed one more step for Kate's virginity.

He removed her yukata—the sash tied but otherwise useless—and set it aside.

As he pulled off her last garment, sticky fluid stretched in threads from her vagina.

Meanwhile, they kept kissing like passionate lovers.

Soon, both were completely naked, embracing sideways.

With the heating on and feeling each other's warmth, they felt hot rather than cold. Both were sweating.

"Eh? Kyaa! Wait wait! What are you—"  
"What? I'm going down on you. But... Kate's pussy is beautiful too."

They'd just been hugging naked, but feeling Yuu's skin directly seemed to make Kate dazed and feverish.

However, while kissing, Yuu had shifted position to face her directly before crouching between her legs.

To Kate, her private parts were suddenly exposed to Yuu's intense scrutiny.

She tried to close her legs reflexively, but Yuu's careful caresses left her powerless. She felt Yuu gently spread her open with his fingers and covered her face with both hands.

"Idiot! Hyuu! St...stop... there... ah, ah, no... don't lick... haan!"

Unlike Jane's bushy mound, Kate's golden pubic hair was neatly trimmed in an inverted triangle.

Her labia minora were lightly pigmented—pinker than anyone's—and virginally closed.

Spreading them with his fingers revealed a glistening, wet salmon pink. The small vaginal opening twitched, almost seeming to await entry.

Aiming for the nearly odorless vagina, Yuu brought his face close and extended his tongue.

"Ngvuuuuuu! V... v... vkuu!"

Kate shuddered violently, nearly crying out before covering her mouth.

Yuu paid no heed, engrossed in licking the virgin pussy.

First, he licked all over the inner labia with *peron, beron* licks.

Just this made Kate feel unbearably good—her muffled moans reached him from above.

As he licked, more love juice overflowed, wetting around Yuu's mouth and dripping onto the sofa. Her limit was near.

"Ah! Yuu, w-wait... fukuun! Any more... and I'll... change... hyameee!"  
"It's fine? Just cum, okay?"

Yuu's tongue intensified its focus on her clitoris. Unable to keep her mouth covered, Kate gripped the sofa back with one hand and Yuu's hand kneading her breast with the other.

"I don't... know this! Hih... nn, ig'... ahh............"

Kate's words cut off as she stared blankly upward.

But her body reacted honestly—legs snapping straight as cloudy genuine juice *pyurut* splattered from her vagina, wetting Yuu's face.

This was the moment Keiko (Kate)—who'd lacked sexual desire even before rebirth—experienced her first climax.

### Chapter Translation Notes
- Translated "本気汁" as "genuine juice" to convey the intensity of Kate's orgasmic fluid
- Preserved Japanese sound effects with transliterations (e.g., "ちゅぷ" → "chup")
- Translated "おマンコ" as "pussy" per explicit terminology requirement
- Rendered sexual acts without euphemisms (e.g., "クンニ" → "oral sex")
- Maintained Japanese name order for all characters (e.g., "Hirose Yuu")
- Italicized internal monologues per style guidelines