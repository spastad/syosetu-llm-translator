## 340. Midnight Resolve ④ ~Glad I Fell for You~

"Did it feel good?"

"Hah, hah, hae? It felt like... like I wasn't in my own body anymore... floating like I was on clouds..."

Even with a forty-something mind, her body was that of a sensitive sixteen-year-old. Kate seemed to be in a trance-like state, overwhelmed by pleasure beyond her imagination.

Yuu sat up and kissed Kate while stroking her head from the front. Though it was a light kiss like one would give a child after kissing her many times that night, the flames of desire burned fiercely within Kate. She clearly realized: she wanted Yuu. Without worrying about their teeth clashing, Kate actively pressed her lips against his, tangling her tongue with his.

Kate wrapped both arms around Yuu, but her right hand slid downward. Moving from his firm buttocks to the front, she found his erect penis. With a timid touch, she confirmed its heat and hardness at the tip before slowly enclosing it in her palm and moving it up and down.

For Kate, it had been about twenty years since she last touched male genitalia. Though she noticed it was longer and thicker than what she remembered, she felt no aversion. She'd seen her teammates and Jane gladly accept it, and Kate herself desired Yuu's member. Even with her clumsy handling, Yuu's moans of pleasure seemed adorable to her.

"Hey?"

"Yeah?"

Without needing to say more, they wordlessly agreed to proceed while gazing at each other. Before that, Yuu glanced behind the sofa. He remembered the bath towel he'd draped over Ryoko earlier was piled nearby. Perhaps it had been prepared anticipating they might do this on the sofa.

When he went to get the towel, he glanced at Ryoko, but she remained turned away as before. No sleep-talking or breathing sounds could be heard - either she was fast asleep, or... Either way, he decided not to worry about it.

Under Kate's hips as she lay on the sofa was a towel folded double. Though she'd already soaked the sofa considerably from the cunnilingus, he laid it down anticipating hymenal blood this time.

Sitting between Kate's spread legs with her knees bent, Yuu leaned over her. Kate's face showed both expectation and tension. To Yuu, Keiko had been beautiful even before rebirth, so he'd assumed she had considerable male experience. But from their conversations, that didn't seem to be the case. If anything, her strong wariness toward men suggested she might dislike them.

"Be... be gentle, okay?"

"Of course."

"......"

"......"

"Pfft."

Just as he thought this resembled a scene from a romance manga where a couple first consummates their relationship, Kate suddenly burst out laughing.

"What's so funny?"

"Fufufu. I just never imagined I'd be saying lines like this."

"Hahaha. But I hear a girl's first time really hurts."

Having experienced virgins - definitely in the double digits - in this world, Yuu knew better. Over 90% had already broken their own hymens, so no hymenal blood flowed. Still, the pain of accepting a man's member for the first time seemed real. In that regard, Kate appeared to be a genuine virgin with an intact hymen.

Yuu gently stroked Kate's cheek. Bringing his face close, he kissed her and said:

"Okay, I'm going to insert it now. Relax your body."

"O-okay."

Though not as nervous as Kate, Yuu was tense too. As the owner of the salon his wife frequented. As leader of the Red Scorpions. As student council officer at Saiei Academy. Though they'd met directly only a few times, including before rebirth, they had a long history. He'd held faint affection for her, but until recently never imagined they'd have sex like this. Yet more than that, Yuu felt both mentally and physically ready.

Instead of inserting immediately, he rubbed his erect penis against her wet entrance. Immediately, her love juices coated it. After coating from glans to shaft with her fluids, Yuu pulled his hips back slightly and positioned the tip at her vaginal opening.

With a *npuu* sound, the glans slid in. Immediately upon entry, he felt resistance. Surely that was the hymen. Having come this far, Yuu didn't hesitate. Grabbing Kate's legs, he thrust his hips forward.

"Gyahk!"

"Sorry. Just bear with it a little."

"I-I know... ngh! Yuu's... too big!"

"S-sorry."

Her vulva stretched wide around the glans. Kate's virgin vagina was incredibly tight, making penetration difficult. Though most would panic, the experienced Yuu remained calm. If pushing didn't work, he tried pulling. He repeated small, short thrusts - in and out. Throughout, Kate kept her eyes closed, frowning as she endured the pain. Beads of sweat formed on her forehead.

At times like this, focusing on the insertion point only makes tension worse. Yuu leaned over Kate and used his left hand to scoop up her breast. He pinched both nipples and pulled them upward.

"Ahh! My nipples!"

"Kate."

"Y-Yuu... mmph."

*Chu, chu* - Yuu exchanged kisses with Kate. Kate's hands, which had been gripping the sofa, moved to Yuu's back, clinging tightly. All the while, Yuu kept making small hip movements, gradually feeling himself sink deeper. It felt like forcibly twisting into a narrow passage.

"*Chu, chu, chu*... Gwah! Yuu's... going in!"

"Ahh, Kate's inside... so tight... feels amazing... ohh!"

"Hii! Yuu! Ah... ga... u... so... ohh! That deep... ahhhh!"

"Kuh! Ha, I'm in!"

It took time, but Yuu's penis finally reached Kate's depths. That said, her vaginal walls tightly constricted his member, making movement nearly impossible. Thus, Yuu and Kate remained tightly embraced, bodies pressed together. For Yuu, even without moving, this state felt satisfying enough. Or rather, moving carelessly might make him ejaculate immediately, so he wanted to savor this penetration.

"Am I... too heavy?"

"Mmm... it's fine."

"What about the pain?"

"That... still lingers. Feels like being skewered?"

"Uh... sorry."

"Why apologize? I wanted this myself. No regrets. In fact, I'm truly glad my first time was with you."

"That's... such an honor."

Gazing at her closely, Yuu smiled. In this world, being male gave him advantages - if you were young, you'd be popular unless something extreme happened. But having Kate, who shared his chastity values, clearly express affection made him incredibly happy. His chest warmed intensely as he kissed her again. Kate gently stroked Yuu's head with one hand.

Kate's calm voice. Her smooth, clinging white skin. Her straight, silky-smooth, sweet-smelling golden long hair. With their genitals connected, he wanted more of Kate. He wanted to touch her more.

"Nghyuu! W-wait, don't move yet!"

"Huh? I'm not moving."

"But inside... it went *guun*... ah, ahhh!"

"Whoa! Hey... tight, too tight!"

Though Yuu hadn't moved his hips, his increased feelings for Kate made him exert strength in his lower body, thrusting deeper into her vaginal depths. As if in retaliation, her vaginal walls unconsciously contracted, squeezing painfully tight.

Was this a vaginal spasm? Would he get stuck inside? Yuu worried, but that wasn't it. The unexpected movement and size of the foreign object she'd just accepted seemed to have triggered an automatic reaction.

Though Yuu wanted to stay embraced like this, his male instincts stirred - he wanted to move quickly and ejaculate. Supporting his upper body like in a push-up, he prepared to thrust.

"Moving now."

"Ah, Yuu, wait!"

"What?"

"When you... come... please do it outside."

"Uh..."

"It's not that I don't want your baby, Yuu. But at least wait until after graduation, when I'm independent."

"Ah, I see."

Unlike other women in this world, Kate seemed averse to pregnancy while still a student. It wasn't that she didn't want to conceive Yuu's child. Yuu himself didn't want to impregnate her against her will. Though pregnancy wasn't impossible even with withdrawal, he could come outside. The rest depended on timing.

"Got it. I'll come outside."

"Thank you. Ahhn! You're... moving!"

"I'll go as slowly as I can, but tell me if it hurts."

"I'm... fine. Go ahead. Move how you like."

Yuu began moving his hips gradually, but once he started, he couldn't stop. Even slight movements sent exquisite sensations through the fine vaginal folds stimulating his penis. Whether thrusting or pulling, the friction sent paralyzing pleasure through Yuu's entire body.

"Hah, hah, hah... damn, Kate's inside... feels too good!"

"Th-that's... good... ahh! Moving so much... mmm!"

Kate still seemed more pained than pleasured, frowning with eyebrows in a ^ shape. Yet even that expression didn't diminish her beauty - if anything, it aroused him. Though he knew making a virgin climax was difficult, he wanted her to feel more pleasure. Yuu felt he might lose control, but resisted rushing, slowly thrusting to savor the vaginal sensations. Even now, thrusting met strong resistance as if pushing back. When he hit her depths, she squeezed tight. When pulling out, folds clung as if reluctant to part. Gradually, her vagina seemed to adapt - seeping love juices acted as lubricant, making movement easier.

"...! Nngh... ah, ahn!"

With ejaculation approaching fast, Yuu changed to circular motions while deeply inserted. He wanted to savor Kate's interior longer, thinking this would help him last. Kate, who'd been gripping Yuu's shoulders and arms tightly while enduring the pain, began changing. Her hands busily stroked Yuu's head and back as if caressing him.

"Kate?"

"Ngh... hah, ah... somehow... it's getting better... ah, ahh, that... Yuu's... good, feels good... ahn!"

"Glad to hear."

While supporting his upper body push-up style and moving his hips, Yuu saw Kate's expression shift from pain to pleasure and felt relief and excitement. Kate was an adult inside. Perhaps she was partly acting for Yuu's sake - half performance, half genuine feeling. But that was fine. From their joined parts came sticky, wet sounds matching Yuu's hip movements.

Her eyebrows and outer eyes lowered, cheeks flushed pink, mouth half-open as she panted. Saliva dripped from her lips from their many kisses. Her golden hair stuck sweatily to her forehead. Though far from her usual cool demeanor, she looked utterly alluring. Her hill-like breasts swayed irregularly - *tapum, tapum* - with Yuu's movements.

Yuu slipped his right hand under Kate's head like a pillow, while his left hand folded to cup and knead her swaying breasts. Then he thrust deep inside.

"Hyaun!"

"Ahh, I can't stop now."

"Yuu! Au au... no... too intense!"

"Kate... Kate... kuu! I'm already..."

With each powerful thrust, *pan, pan* sounds of flesh meeting flesh echoed through the room. Kate's arms around Yuu's back tightened as if she'd never let go.

Becoming one, the two desperately called each other's names while breathing heavily. Yuu intended to last longer, but his urge to ejaculate grew violently. Like a runaway train with no brakes, he nearly succumbed to the male instinct to ejaculate inside and impregnate her. But at the last moment, he remembered Kate's words and stopped.

"Kate."

"Yu... Yuu."

Yuu barely controlled his lust-driven body, slowing his movements to long, leisurely strokes. Then he kissed Kate. Even slowed down, being connected at both mouths intensified the pleasure.

"Ngh, fu, fu, hah... ahh, I can't!"

"Hah, hau! Yuu, it's okay. Don't hold back... come!"

"Ngh... uu... sorry, I'm coming!"

Moaning with lips nearly touching, Yuu made his final sprint. Timing it, he pulled out at the last moment, rubbing against Kate's soft lower abdomen as his penis trembled violently, spurting semen forcefully.

*Becha, becha, becha.*

It reached not just Kate's toned stomach but even her ample breasts.

"So much... this much..."

"Haa, haa... felt amazing. But I couldn't make you climax... whoa!"

"Hah, hah, hah... damn, I can't hold back anymore!"

Even while gazing at each other post-ejaculation - Kate wide-eyed at the semen volume, Yuu satisfied but regretting not making her climax internally, considering a rematch - someone suddenly embraced him from behind. When Yuu looked back, he saw Ryoko, now completely naked, having stripped at some point.  


### Chapter Translation Notes
- Translated "破瓜の血" as "hymenal blood" to maintain medical accuracy while being explicit
- Preserved sound effects: "ぬぷぅ" → "*npuu*", "ぱんぱん" → "*pan, pan*", "べちゃっ" → "*Becha*"
- Translated "ワレメ" as "vulva" for anatomical precision
- Used "love juices" for "愛液" to balance explicitness with literary flow
- Maintained Japanese name order: "Hirose Yuu" throughout
- Rendered internal thoughts in italics: "*(thought)*" format
- Kept honorific "-neé" for Saira as established in fixed references
- Translated "膣内" as "inside" in dialogue for natural flow, but as "vaginal walls/vaginal interior" in narration for accuracy