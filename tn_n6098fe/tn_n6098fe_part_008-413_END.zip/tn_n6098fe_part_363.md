## 341. Midnight Resolve ⑤ ~Just One Wish~

"I'll go wipe myself down, so keep Ryoko company. You can handle that, right Yuu?"  
"W-well, yeah. But Kate, you're still..."  
"It's fine. Don't worry about me."

After giving just a light peck of a kiss, Kate separated her body from his. The awkwardness in her lower body movements was likely due to the lingering foreign sensation after just losing her virginity. On the towel beneath them was only a small red stain - apparently there had been minimal bleeding. Virginity loss doesn't always involve bleeding, and the amount varies by person. But Kate's pained expression was clearly genuine. Though the bleeding was light, Kate's body surface was thickly coated with semen. She seemed to plan to wipe with tissues before washing off in the bathroom.

Yuu turned back toward Ryoko. She was kneeling formally on the sofa, head bowed while hugging herself. Though she'd suddenly clung to him earlier, she now seemed ashamed of having acted on lust without waiting for the afterglow of Kate's experience. *She really is a good-natured woman at heart*, Yuu thought.

"Ryoko."  
"Hah! Wh-what is it, Yuu?"

Yuu approached her head-on and took Ryoko's chin. She uncomfortably averted her eyes.

When they'd arrived at the hotel, Yuu had seen Ryoko without her old delinquent-style heavy makeup, wearing only natural light makeup instead. He'd learned she'd previously used garish eyeshadow and lip colors to compensate for her baby-faced features that undermined her delinquent authority. But after cutting her hair short on Kate's suggestion, she'd apparently learned new makeup techniques. Frankly, the new style suited her better. Though currently barefaced after bathing, her naturally defined double eyelids, small nose and mouth were well-balanced in her cute face. The gap with her brash speech made her seem like a girl who couldn't fully commit to being insolent.

Yuu stroked her hair - once long with red and brown streaks, now chopped into a short bob dyed near-black burnt brown. His other hand traced fingers from her chin along her cheek. The moment Yuu touched her, Ryoko's expression turned blissful as she narrowed her eyes like a cat purring.

"Ahh... aah... fuh, nnn!"

Yuu's fingers slid to her ears, crawling around the holes outward to her nape. Whether from the hot spring soak or not, her skin felt smooth and glossy as his fingers descended her neck. He caressed even her bony shoulders and collarbones with delicate touches. Everywhere Yuu's hands touched, Ryoko felt drunk with pleasure, letting out faint moans. Her erogenous zones were being rediscovered under Yuu's long-absent caresses. Ryoko herself was timidly gripping Yuu's shoulders. Yuu's right hand descended to her flank, tenderly stroking her scar.

"Nkyuuuuu... ah, haa... Yuu's fingers... feel so good..."  
"Fufu. You're sensitive, Ryoko."

Yuu's right hand moved sideways across her toned stomach, then cupped her breasts, jiggling them. Though Ryoko had a muscular build, her breasts were substantial - easily E-cup sized like Sayaka's pre-pregnancy breasts, their weight heavy in his palms.

"Haaahn... nn, nn, nnaah! Yuuuu!"

When Yuu flicked her nipples with his index finger, Ryoko cried out joyfully, gazing at him through half-lidded eyes. Not missing her signal, Yuu brought his face close and pressed their lips together with a smack. Opening his mouth, he thrust out his tongue, and they noisily tangled tongues in a passionate deep kiss.

Though Ryoko had met Yuu several times with Sayaka and Kate after her first experience, it had only been hugs or kisses at most. Faced with this perfect opportunity, her excitement was uncontrollable. For Yuu too, one ejaculation wasn't enough to satisfy his lust, and his fondness for Ryoko transformed into intense desire.

After intensely tasting each other's mouths and exchanging saliva until breathless, they separated. A string of saliva stretched between their still-protruding tongues. Ryoko already wore a dazed expression - the very picture of a female craving male flesh. Yuu smiled at her before whispering near her ear:

"How much did you hear?"  
"Hah! Ah, um..."  
"You were awake partway through, right?"  
"Uu... actually since you made Leader cum. I was surprised. S-sorry. Felt like I was eavesdropping."  
"Can't be helped. Kate was moaning that loudly after all."  
"Wh-whose fault is that?!"

Kate had apparently overheard as she emerged from the washroom. Yuu hadn't been certain - he'd been focused on Kate's virginity. But sensing fidgeting, he'd tested the waters and been right.

"Well, Kate was the horny one."  
"Enough! Look at you, Ryoko. You just came but you're already like this again?"  
"Whoa!"

Circling the sofa, Kate pressed flush against Yuu's back. Pushing her ample breasts against him, she slid both hands down from his stomach and firmly grasped his erect penis. Ryoko also made her desire to touch obvious, so Yuu consented. In exchange, Yuu made Ryoko spread her legs and moved his right hand from her breasts to her crotch.

"Ahhaa... Yuu's penis... so hard and hot..."  
"Ryoko's dripping wet too, aren't you?"  
"W-well yeah... aahn!"

Enjoying being sandwiched front and back with his penis handled, Yuu's right fingers touched Ryoko's vagina directly. She'd apparently been masturbating since watching Yuu and Kate, already so wet and loose that no foreplay was needed. Finding her vaginal opening with his middle finger, Yuu inserted it immediately. Thanks to the abundant wetness, his finger slid in squelchily without resistance. Ryoko's vaginal walls clenched tightly around the finger as if mistaking it for the long-awaited penis.

"Ah, ah, ah... Yuu's... finger... ahh, feels so good! So good! Oh, oh, there... vuun!"

With his finger fully inserted, Yuu rubbed her front wall with his fingertip and thrust in and out with lewd squelching sounds. Ryoko shook her head as if resisting, then dropped her head onto Yuu's shoulder as if unable to endure it. Her rough breaths hit Yuu's skin. She could no longer focus on the hand touching his penis. Yuu felt joy seeing Ryoko express pleasure with her whole body.

Meanwhile, Kate remained plastered to Yuu's back, thoroughly stroking his penis with both hands despite her inexperience. Precum dripped endlessly, making sticky sounds with each movement.

"Ryoko, want me inside you?"  
"Ahh, Yuu, Yuu's... penis... I want your penis. Can't hold back anymore... fingers feel good but I wanna cum on Yuu's penis!"

"Good girl for being honest. Then let's become one."

Using the sofa instead of a bed required considering positions. With Kate it had been missionary, somewhat awkward to move, but fortunately no vigorous thrusting was needed for her first time. This was Ryoko's second time - their first had been with her sitting on a chair in an M-leg spread.

"Ryoko, is it okay if I choose the position I like?"  
"Ah, ah, I'll... leave it all to Yuu."  
"Then..."

Among several options in Yuu's mind, he chose a position no man in this world would ever attempt.

"First time seeing this... do men like this position?"

Ryoko faced the sofa back with hands planted, presenting her well-shaped ass to Yuu. Yuu stood behind her, having moved the low table aside for mobility, preparing for doggy-style penetration. As Yuu stroked Ryoko's buttocks to adjust her leg spread, Kate asked with keen interest.

"Well, I like it. Especially with women like Ryoko who are tall with great figures."

Ryoko was slightly shorter than Yuu, around 170cm. In this world with minimal gender height difference, 170cm women were common, but by his previous life's standards, she was quite tall. Yuu particularly enjoyed doggy-style with such women.

"What position would you like next time, Kate?"  
"Huh? Um... not sure. I don't really know."

Though Kate (Keiko) was Yuu's age and beautiful enough to be popular, her sexual knowledge seemed shallow. Yuu himself didn't have enough experience to boast about - most knowledge and techniques came after rebirth. At least her lack of rejection toward him having sex with another woman was helpful.

While talking with Kate, Yuu pressed his hips against the ass before him, fitting his penis snugly into the butt crack. He slid slowly downward, rubbing the tip against her vaginal opening. Faced with a man's member after so long, Ryoko's vulva drooled with joy, wetting the glans.

"Ahhn! Yuu, don't tease me!"

Ryoko looked back at him with a seductive glance. Kate watched excitedly from beside them as Yuu and Ryoko prepared to connect. Yuu felt incredibly happy and aroused at having sex with two stunningly beautiful naked girls consecutively. Gripping Ryoko's waist firmly with his right hand, Yuu grabbed her firmly at the curve.

"Got it. Got it. I'll put it in now. Heeeere!"  
"Gah!?"

With a squelch, the glans was swallowed by her vaginal opening. Though the glans entered smoothly, it immediately met strong resistance from vaginal flesh blocking further entry. Understandable - it had been eight months since taking Ryoko's virginity, and she wasn't the type to accept other men. Yuu would be careful with virgins, but fired up for doggy-style, he decided to proceed without restraint.

"Inside's tight, Ryoko. But—"  
"Aguh! Yuu's penis... kuh... coming in..."

Yuu firmly gripped Ryoko's hips with both hands and thrust powerfully. He would make her remember the shape of his manhood by forcing through the passage once opened. Uncharacteristically forceful, Yuu continued thrusting until he struck deep inside.

"Hyau! O...oh... cock... came..."

Ryoko threw her head back and arched her body, seemingly overwhelmed, her words fragmenting. When Yuu thrust deep, such intense pleasure hit him that his lower body trembled. He instinctively hugged Ryoko tightly with both hands gripping her waist. Her vaginal tightness was nearly virginal. The folds squirmed around the male symbol entering after so long, tightly squeezing his penis.

"Haaah~~~ Ryoko, feels so good... irresistible..."  
"I-I feel... like I'm dreaming... ahh... Yuu's amazing..."

Yuu nuzzled his face against her back while embracing her. He wanted to feel Ryoko without moving immediately. For Ryoko too, the long interval made the reunion especially moving. Kate watched them from beside. Perhaps affected by their heat, she fidgeted restlessly with thighs pressed together.

"Hey, Yuu. Can I ask something?"  
"Ah... yeah, sure."

Kate's cheeks flushed as she asked timidly despite not being involved, looking adorable.

"Inside me and Ryoko... is it different? As a man, which is better?"  
"Huh?"  
"S-sorry! Forget it!"

Kate shook her head vigorously, her breasts swaying. Seeing this, Yuu raised his upper body slightly and stroked Kate's head with his right hand.

"Just as figures, builds, and ages differ, everyone has unique qualities."  
"R-right."  
"One thing I can say: every woman I've had sex with has been wonderful. Kate has Kate's merits, Ryoko has Ryoko's. You're both equally amazing women I'd want again given the chance."  
"Gah! Yuu, move!"

"Right. Ryoko. Since it's been so long, I'll go all out! Feel me plenty!"  
"Haa, haa, gah! Vuhii! Yuu's penis... inside me... coming deep! Hahi, hahi... so good... can't think anymore..."

Once the penis settled inside Ryoko, Yuu began thrusting. Though still slow strokes, when pulling nearly out, cloudy love juice overflowed from their joining point, dripping stickily down her inner thighs. Ryoko could only moan under Yuu's penis, their conversation inaudible. While embracing Ryoko with his left hand, Yuu combed through shy Kate's hair.

"I think I understand why everyone falls for you, not just because you're a man."

Muttering this, Kate got off the sofa and embraced Yuu from behind.

### Chapter Translation Notes
- Translated "処女を喪った" as "losing her virginity" to maintain explicit terminology
- Preserved sound effects: "ちゅっと" → "a light peck", "にゅぷっと" → "squelch"
- Translated "M字開脚" as "M-leg spread" for anatomical accuracy
- Rendered sexual anatomy terms directly: "膣" → "vagina", "チンポ" → "penis"
- Maintained original name usage: "祐" → "Yuu", "涼子" → "Ryoko", "ケイト" → "Kate"
- Italicized internal monologue: "祐ならできるんでしょ？" → *(You can handle Ryoko, right, Yuu?)*
- Used explicit terminology for sexual acts: "ディープキス" → "deep kiss", "挿入" → "penetration"