## 342. Midnight Resolve ⑥ ~Long Night~

### Author's Preface

Slightly longer than usual (approx. 8500 characters), but I deliberately kept it as one chapter without splitting despite the increased length.

---

  

"Ahhh! Uuuuuuuuuh! Kuhah! D-don't... ahhh! Can't take it anymore... c-cumming! Yu-Yuuuuuuu!"

"Ryoko, it's okay. Cum."

  

Ryoko seemed unable to hold out much longer despite less than three minutes of penetration. Clutching the sofa backrest with her legs spread and ass thrust out, her posture resembled a crouching frog. For Yuu with his upward-curving penis, this position allowed easier movement than all-fours. After thrusting to the deepest point, he guided Ryoko to climax with rapid, shallow piston strokes.

  

"Hyaa! You're too much! Ah, ah, ah! Feels so gooood, cumminggggggggggg!"

  

With continuous knocking against her cervix, Ryoko climaxed almost instantly. She momentarily arched her back while tightly gripping the sofa backrest, but collapsed face-first after the prolonged ecstasy. Yuu's assault continued, with copious love juices dripping from their joined area to form a puddle on the floor.

  

Yuu kept thrusting with his left hand gripping Ryoko's waist, but his upper body remained immobilized. Kate had clung to him midway. Though unexpected, Yuu welcomed this development - simultaneously pleasuring two naked beauties.

  

"Ryoko's moaning so blissfully... hehe, makes me a bit jealous."

"Kate? Mmph!"

  

Kate peered at their joined area while resting her head against Yuu's chest, then lifted her face to block his view. Her cheeks flushed pink, eyes half-lidded, lips glistening wet with a lustful expression unlike anything seen before - not that of a freshly deflowered teen, but a woman awakened to desire by Yuu.

  

Kate traced circles on Yuu's chest before pinching his nipple, while her left hand pulled his head closer for a deep kiss. She immediately offered her tongue, which Yuu eagerly accepted. Throughout, Yuu's hips kept moving.

  

With his view blocked, Yuu couldn't see Ryoko's back or ass. But the undulating folds around his thrusting penis delivered tremorous pleasure. Combined with Kate's full-body contact and tongue play, his excitement kept intensifying.

  

After making Ryoko climax once, Yuu switched to circular hip movements. He couldn't see Ryoko's face pressed against the sofa back - the fearsome delinquent's expression now transformed into shameless ecstasy.

  

Meanwhile, Yuu lowered his right hand to Kate's ass, inserting his middle finger into her vagina. It slid in easily, her inner walls tightening around it.

  

"Kyahn! Oh Yuu... pervert... mmph, slurp, lick, haaahn~"  
"Ah ah... Yuu's penis... grinding deep... can't... just came... hah, hah, haun!"

  

Kate's high-pitched coos mixed with Ryoko's husky moans. Wet sounds emanated from Kate's penetrated vagina and their joined genitals. When Yuu rhythmically increased his thrusts, Ryoko's ass produced satisfying slaps.

  

"Puhah! Kate, Ryoko... I'm unbearably happy!"

"Me too! Ah, ah, having sex with Yuu... always dreamed of this... ahih, hahih, feels too good, dying!"

"I can't believe I've become this lewd... mmph! Unbelievable... ah, there... your finger... ah, ahn! All your fault, Yuu!"

  

As Yuu's finger plunged deep, Kate nearly recoiled but clung tighter. Even after losing her virginity, the sensation of penetration felt unfamiliar. Her feminine instincts craved Yuu's virile manhood.

  

"Foh! Ugh... ah, ah, ahe... coming again... Yuu, Yuu! Ah... amazinggggg!"  
"Oh, me too... guh! Can't stop!"

  

While kissing Kate deeply and penetrating Ryoko from behind, Yuu's pleasure skyrocketed. His thrusts grew fiercer as they raced toward climax together. Ryoko's legs weakened, knees threatening to buckle.

  

Withdrawing near climax would ruin the momentum. Yuu shifted positions to standing doggy-style, planting Ryoko's feet on the floor. Though harder for her, Yuu preferred this angle.

  

"Fah... ahn! Ah... mph! Mmmph! Yuu, wait... ah, no... why... feels good..."

  

Kate moaned with Yuu's finger pistoning deep inside her, face buried in his shoulder. Sticky squelches continued as her juices dripped onto Yuu's legs. Her lower body trembled like a newborn fawn's.

  

With two women moaning lewdly, Yuu's arousal became uncontrollable. Though he paused briefly to adjust positions, his hips soon resumed frantic thrusting.

  

"Guh, oh... cumming, cumming! Ryoko!"

  

Pan pan pan! Yuu slammed his hips violently for the final sprint. At full speed with no stopping until ejaculation. Ryoko, still sensitive from her first climax, inevitably broke again.

  

"Aheh, haheh... no no... ahh—, ahh—, ahhh, ohhh......... guh, uuuuuuuuuuuuh!"  
"Now... ejaculating! Kuhah!"

  

As Yuu spoke, thick semen burst toward Ryoko's womb in powerful spurts. Comparable volume to Kate's. Might hit fertile days.

*(Come to think of it, I didn't ask if I could cum inside.)*

Amid overwhelming pleasure, Yuu vaguely regretted but it was too late. Unlike Kate, Ryoko wouldn't need permission. After climaxing while receiving the flood, Ryoko's arms gave out, upper body slumping forward.

  

Meanwhile, Yuu kept stimulating Kate's vagina. But Ryoko's collapsing posture threatened disconnection. Yuu repositioned: sitting sofa-center with Ryoko sideways performing fellatio, while Kate received manual stimulation.

  

"Haaah... must properly thank Yuu's penis. Guhuhuh"

  

Sitting sideways while hugging Yuu's waist, Ryoko eyed his still-hard penis with heart-shaped pupils. After kissing the glans, she licked along the urethra, cleaning residual semen. New stimulation prevented softening.

  

"Ahh... ahhhn! Yuu! Feels good, coming! Yes! Yes! Haaahn!"

  

As Kate leaned in, Yuu lifted her hips, suckling breasts while inserting two fingers. Kate cradled his head lovingly as she moaned. Her long blonde hair tangled wildly as she tossed her head, sweaty skin and constant moans radiating allure. Nearing climax, she undulated her hips like dancing.

  

Ryoko kept sucking after cleaning, determined to extract more semen. But Kate reached her limit first.

  

"Yu, Yuuuu... can't take it... ah, ah, ah, cumming! Ahn! Cumming!"  
"Kate. Just cum."

"Ahh... Yuu! Nnnn~~~~~~!"

  

Kate mashed her lips against Yuu's as she climaxed. Fluid sprayed from around his deeply inserted fingers, splattering Ryoko's face.

  

  

  

  

Though weakened post-orgasm, Kate clung to Yuu but stared wide-eyed at Ryoko's fellatio. She knew men typically needed recovery time after ejaculation, yet remembered Yuu pleasuring four Red Scorpions consecutively. His erect penis spoke for itself. Drawn by Ryoko's blissful expression, Kate bent down and extended her tongue too.

  

"Hafuu~ feels like heaven... ah"

  

After brief double fellatio enjoyment, Yuu noticed multiple gazes upon him.

  

"Yuu-chan..."  
""Yuu~?""  
""Yuu-kun!"" "Yuu-kun!"  
"My my. So energetic... youth truly..."

  

Martina and Sakuya approached from front. Elena already shedding yukata. Sayaka, Riko and Emi reached from behind. Haruka watched amusedly from distance. With Kate and Ryoko's loud moans, no one could sleep through it. Having witnessed the full threesome, the women were thoroughly aroused. Though fatigued, Yuu couldn't refuse seven females with ignited instincts, getting led back to the bedroom while Kate and Ryoko went to shower.

  

"Yuu-kun, you'll catch cold sweaty like this."

"Mh... th-thank... oh, mmph... npa... slurp"

  

Sitting spread-eagle on bed surrounded by seven women, Yuu received upper-body wiping from Sayaka, Riko, Emi and Sakuya with near-constant kissing. Martina and Elena straddled his legs while Haruka attended his lower body - all three meticulously wiping his still-erect penis from glans to testicles.

  

"Ahah~ Yuu's penis..."  
"Haa, haa... shameful at my age. Embarrassing but... ahh"  
"Nonsense. What woman wouldn't ache seeing this?"

  

Under room lights, the erect penis glistened, dripping precum despite wiping. Elena drooled like a dog, while even Martina and Haruka flushed pink, breathing heavily as they examined it up close. Though grotesque with bulging veins, its shape and color radiated virility, its unique scent stirring their instincts. Even Haruka, who'd kept distance outside baths, gaped slack-jawed.

  

"Hey, Yuu?"  
"Mh? Wh-what?"  
"May I?"

  

After deep-kissing Sakuya, Martina's question made Yuu turn. Her gaze shifted to Haruka. Martina had deliberately saved space for the first wife.

  

"Eh... Martina-san?"  
"Okay."

  

Reading the atmosphere, Yuu nodded. Gently pushed by Martina, Haruka looked incredulous. She'd intended to be satisfied just touching Yuu's legendary member, yet her lower body undeniably ached. Conflicted about still being womanly, she gazed at Yuu.

  

"H-Haruka-san..."  
"Yuu... really?"  
"I can't wait. Want to connect with you now."  
"O-okay."

  

After constant sucking and handling, Yuu desperately needed penetration and release. Haruka rationalized she'd relieve him quickly as she straddled his waist.

  

Yuu lay supine with Sayaka's lap pillow, flanked by Riko and Emi - surrounded by three swollen bellies. Sakuya licked his chest. Though dismounted, Martina and Elena still straddled his legs. Thus enveloped by women, Haruka began riding him.

  

"Fuh... kuaah! Ah, ah, ahhh... so haaard... nnooh!" 

  

Having served as Sakuya's business partner rather than lover late in life, Haruka hadn't had sex in twenty years. After his death, she'd devoted herself to managing the foundation. Though resolved to abandon sexuality, Yuu ignited her desires. Once accepting manhood, she couldn't stop.

  

Gripping Yuu's sides, she lowered her hips. Though not virginal, penetration took time after long disuse. Initial pain gave way as vaginal walls stretched around the thick shaft, pleasure signals intensifying.

  

"Mh, mh, mmph! This... feeling... to experience again... ohhh! Oh, deep... rea...ched... kuhii!"  
"H-Haruka-san... ahhh! Amazing!"

  

Haruka's words cut off as electricity surged through her. The ecstasy since Sakuya's era made her reveal a dazed expression never shown before.

  

Yuu too experienced incredible pleasure upon entry. Though not virginal tightness, the hot, viscous interior surpassed expectations.

  

  

  

Bachun! Bachun! Bachun!

  

"Hah, hah, hah... ahh, hips won't... stop! Ah, ah, feels so gooood... uun! Mph... wonderful, wonderful!"

  

With Sakuya smilingly making space, Haruka placed hands on Yuu's chest and rode frantically. Though initially awkward, her body remembered quickly. Expert hip movements coordinated with vaginal contractions to pleasure both. Yuu's limited view delighted at dignified Haruka's dishevelment - half-unbound black hair swaying over modest breasts.

  

Extending hands that had been on Riko and Emi, Haruka reflexively clasped them in lover's hold. Despite the age gap, they looked like passionate lovers. Her vaginal walls writhed to milk his semen, but Haruka reached limit first.

  

"Gah! Ahhh! Kuhuuu... can't... endure... yes! Yes! Yuu... ah, ah, cumming! Haaaaaaaaaaaaahn!"

  

Clutching Yuu's hand painfully tight, Haruka arched back in climax before collapsing on his chest.

  

"My my... got too heated after so long. Hehe"

  

Haruka lifted herself within a minute, glancing back at Martina. After bowing apologetically, she withdrew.

  

"Next is Martina-san"  
""Eh?""  
"A man like Yuu shouldn't be monopolized. Yuu, give love to as many women as possible? Even Jane-like love-starved women, you can satisfy them."

  

As Sakuya's first wife who managed multiple spouses, Haruka's words held weight. Besides Kate, Ryoko and Haruka, six remained - manageable for Yuu. Nodding, Yuu spread his arms.

  

"Come, Mom"  
"I'm heavy"  
"I'll support you"

  

Sitting up, Yuu pulled hesitant Martina close. Concerned for her pregnancy, they'd avoided vaginal penetration for over a month, sticking to oral. But after witnessing others, Martina was visibly aroused. Drawn magnetically, she straddled Yuu and aligned his penis without using hands.

  

"Haaah..."

  

Martina's face instantly slackened with sweet sighs. Yuu gripped her massive breasts while adjusting hip angles for easier entry.

  

"Nkuh! Hah, ah... ahhh! Yuu... going... in!"  
"Ahh! M-Mom!"

  

Leaning slightly forward to avoid belly strain, Martina sheathed him. Yuu clasped her hands in lover's hold. They began slow, synchronized movements.

  

Naturally, they established rotation: women riding Yuu by age, switching after climax. Waiting women constantly touched Yuu - kissing, breast-suckling, nipple-play. Yuu lasted until Martina climaxed after Haruka, but came during Sakuya's turn.

  

After a break, Yuu endured Elena, Sayaka and Riko, ejaculating a fourth time simultaneously with Emi's climax. Without withdrawing, he embraced Emi and fell asleep.

  

  

  

  

Next morning, Yuu awoke past 9 AM. Sakuya and Elena sat beside him in full makeup. All women had woken and dressed earlier but didn't rouse him, instead taking turns watching his sleeping face.

  

After hurriedly showering off sweat and bodily fluids, Yuu's growling stomach led them to the restaurant breakfast buffet.

  

After the meal, Yuu received farewells from all hotel staff before returning to Akita Airport under motorcycle and patrol car escort. Haruka, Kate and Ryoko accompanied his flight back while Martina's group took the train. After landing at Haneda Airport under tight security, they reached Tokyo Police Headquarters around noon for lengthy questioning.

  

There, Yuu learned: Jane survived despite critical injuries, regaining consciousness upon Tokyo arrival; 24 deaths and 2 comas (submarine crew) confirmed on Mugishima Island with no other survivors; 3 extremist members arrested in Tokyo area with others pursued.

  

Regardless, the incident was concluding for Yuu personally. He'd return to school one day late.

  

  

  

  

---

### Author's Afterword

Personally, pregnant women and 40s women are okay in 2D, but I'm iffy about real life... Pregnant partners risk abdominal complications. Though modern 40s women look younger and prettier than before.

  

Regardless, research shows sex during pregnancy isn't taboo except during severe morning sickness or final weeks. But considerations include low-impact positions, condom use, avoiding vaginal fingering, etc. Women's libido often decreases during pregnancy too, so oral sex seems more common. In this chastity reversal world, pregnant women would never lose desire around Yuu (lol).

  

The separate return routes (flight vs train) were because I read pregnant women should avoid flights. Though short domestic flights might be fine. Next intermission covers Jane's aftermath before concluding Chapter 9.  


### Chapter Translation Notes
- Translated explicit sexual terminology literally: "チンポ" → "penis", "膣" → "vagina", "精液" → "semen"
- Preserved Japanese honorifics: "-san" for adults, "-chan" for Elena
- Maintained original name order: "広瀬 祐" → "Hirose Yuu", "小松 清華" → "Komatsu Sayaka"
- Transliterated sound effects: "ぱんぱんぱん" → "pan pan pan", "ぬちゅっ" → "nuchu"
- Italicized internal monologues using asterisks
- Formatted new dialogue lines as separate paragraphs per attribution rules
- Translated anatomical/sexual terms precisely: "子宮口" → "cervix", "オーラルセックス" → "oral sex"
- Used explicit phrasing for sexual acts: "デュープキス" → "deep kiss", "腰を打ち付ける" → "slamming hips"
- Translated culturally specific term "恋人繋ぎ" as "lover's hold" with contextual explanation
- Handled simultaneous dialogue attribution with double quotes when multiple characters speak/react identically