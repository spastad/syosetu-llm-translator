## Interlude 13: One Year Later. A Certain Weekly Magazine Article

From Weekly Bunshu, January 13, 1992 issue

'Do our readers remember the simultaneous bombing attempts in Tokyo and the kidnapping incident in Gunma Prefecture that occurred one year ago?

It was early morning on Sunday, January 6, 1991.

Bomb threats were called in to facilities including the Tokyo Metropolitan Government Building, Saitama Prefectural Government Building, Gunma Prefectural Government Building, several terminal stations including Shinjuku Station, and the Toyoda Sakuya Memorial Foundation headquarters.

At Shinjuku Station, smoke and a strange odor caused a disturbance. A suspicious person crouching near the wall of the Toyoda Sakuya Memorial Foundation headquarters was challenged by a security guard and apprehended while attempting to flee.

※It was later revealed that the perpetrators were remnants of the far-left terrorist organization Rescue Women Military Council, which had been previously raided by authorities, resulting in numerous arrests. The bomb threats were a diversion to draw police attention away from the kidnapping incident.

In the parking lot of the Yokokawa Service Area on the Joshinetsu Expressway (downbound), which was crowded with holidaymakers, three teenage girls were threatened with a handgun and forcibly taken away.

The names of the three girls were Komatsu Sayaka (18), Mihara Ryoko (18), and Kate Grimwood (16). ※Titles omitted. Ages as of the time.

Some readers may have already guessed.

Sayaka is the legitimate granddaughter of Komatsu Reika (65), president of Komatsu Group, globally known as an automobile and motorcycle manufacturer.

And Kate is the eldest daughter of Jane Grimwood (then 34), who was wanted for fraud, embezzlement, tax evasion, various forgeries, and funding terrorism.

It was believed that Jane, the leader of the criminal group, kidnapped Sayaka for ransom to fund her escape overseas with her accomplices. Kate was thought to have approached Sayaka beforehand to facilitate the kidnapping.

※Later testimony revealed that Kate had a strained relationship with her mother and had run away from home, contradicting this theory.

Sayaka and Kate were forced into the assailants' minivan, but Mihara Ryoko alone managed to escape from the service area by taking advantage of the assailants' distraction.

She immediately contacted the Komatsu family. This allowed authorities to coordinate with police before the assailants made contact, contributing to the incident's swift resolution.

The vehicle carrying the two girls from Yokokawa Service Area exited at Usui-Karuizawa IC and immediately re-entered the Joshinetsu Expressway (upbound).

The assailants' vehicle entered Fujioka SA, where it rendezvoused with two accomplices waiting there. Kate was transferred to another vehicle.

The two vehicles headed toward Niigata on the Kanetsu Expressway. At Nagaoka Junction, the vehicle carrying Jane and Sayaka went upbound (toward Kashiwazaki), while the vehicle carrying Kate went downbound (toward Niigata and Yamagata).

Around 7 PM that day, the assailants contacted the apartment where Sayaka lived and demanded a ransom of 100 million yen.

Sayaka's grandmother and Komatsu Group president Reika was designated as the ransom deliverer, but in reality, a police officer of similar age and build disguised herself for the role.

The exchange location was an abandoned dock on the coast of Kanba Town, adjacent to Kashiwazaki City.

Shortly after 1 AM, the ransom and hostage exchange occurred inside the abandoned dock. After securing Sayaka, police special forces stormed in, but the assailants had vanished like smoke.

Not only were the surrounding roads sealed off, but even the sea was blockaded with the cooperation of the Japan Coast Guard.

Astonishingly, the criminal group escaped underwater via submarine.

Jane, who had previously engaged in extensive dealings with illegal organizations overseas, had reportedly hired pirates from the Manchuria Republic in northeastern China—the self-styled Yellow Sea Navy.

These pirates, tacitly permitted by the Republic, attacked cargo and passenger ships belonging to the Republic's potential enemy nations—including not only continental powers but also Japan.

The Yellow Sea Navy owned an old submarine decommissioned from the Republic's navy, and Jane is believed to have paid a large sum to have it deployed.

One might question why Jane, who had enough funds to hire pirates despite being long pursued by police, would carry out a kidnapping.

Perhaps she used most of her remaining funds to pay the pirates for her escape abroad, and resorted to kidnapping to secure living expenses for her refuge.

In any case, the Jane group seemed to have successfully escaped when they landed on Mugishima, a deserted island off Akita Prefecture.

Kate, who had been separated en route, was also confined in a hideout on Mugishima.

What did Jane plan to do next?

She intended to hide in Hokkaido temporarily, then infiltrate illegal organizations in mainland China. Alternatively, she might have boarded a Russian cargo ship to return to her home country, the United States...

As the police did not disclose this information, various speculations were reported at the time.

As it turned out, Jane and her group never left Mugishima.

Because the docked submarine exploded for unknown reasons, and a gunfight broke out among those in the inlet. Most died in what appeared to be mutual killings.

According to police reports, the main reason was believed to be a dispute over payment to the Yellow Sea Navy. Those involved in illegal activities only think about how to outwit others for profit, and conflict is unavoidable when interests clash.

Besides Jane, who fled early to the island hideout, there were reportedly survivors among the submarine crew. However, thrown into the midwinter sea, they undoubtedly perished one after another.

Kate, who noticed the absence of her captors, found a radio in the hideout and called for help.

When police helicopters rushed to the scene, Jane had lost consciousness from massive blood loss upon reaching the hideout.

After Jane recovered, police questioning revealed the full story of the incident, as reported at the time.

Then, a shocking fact emerged.

Born in Texas, USA, she came to Japan 17 years ago for study. While learning Japanese and engaging in various businesses, she was said to have acquired Japanese citizenship. Her real name was Jane Mason.

The Mason family, residing in Maine in the eastern United States, were local notables. Tracing their roots, they were British nobles and a prestigious family since the nation's founding. Generations produced high-ranking government and military officials, as well as corporate executives. Jane was of the main family line.

However, upon inquiry with the United States, it was revealed that Jane had been effectively disowned and driven from home at age 15.

She drifted to the Bronx in New York and apparently joined a gang.

After spending a little over a year there, for unknown reasons, she left the gang life.

Her subsequent deeds show she did not reform.

While crossing the United States westward, Jane committed a robbery in a town near the Texas-New Mexico border.

It is unclear whether the presence of a young man in the house she broke into was related.

Unfortunately, it was during a transition period for the hired bodyguards' contracts, and the replacement was delayed due to a major sandstorm.

Jane killed four family members who tried to protect the young man.

Police forensic analysis revealed she killed them without hesitation, with remarkable efficiency.

She then raped the eldest son, who had hidden in a second-floor bedroom. It is believed she conceived Kate at this time.

She stole the driver's license of the eldest daughter, who shared the same first name and age as one of the victims.

Thereafter, she went by the name Jane Grimwood.

After reaching the West Coast, she contacted an underground organization to obtain a fake passport and traveled to Japan.

About two weeks after Jane arrived in Japan, a major uproar occurred over the death of Toyoda Sakuya.

It is unclear whether Jane was caught up in or took advantage of the riots that broke out in Tokyo, but she was detained on suspicion of property damage and released after about a week. She apparently established a company with Terada Ichiko (died January 7, 1991, age 39), whom she met in detention.

(Part omitted)

The issue was Jane's treatment.

She still held American citizenship. However, even for Americans, crimes committed in Japan are tried under Japanese law.

The Manchuria Republic demanded the extradition of Jane, an atrocious criminal who had killed many of its people, along with two of its citizens.

The Japanese government forcibly deported only the two surviving pirates but refused to hand over Jane.

Strangely, Jane's trial proceeded with limited disclosure, completely barring the press. The defendant did not appeal, and the first-instance sentence of 25 years imprisonment was finalized.

Subsequently, she was indicted in the United States for past robberies, rapes, and murders. Combined with her sentence in Japan, she received a long-term sentence of 205 years.

※As the death penalty is abolished in the United States, serious offenders receive combined sentences that effectively amount to life imprisonment.

It seemed Jane's crimes would be forgotten over time, but another astonishing fact emerged.

It was revealed that Jane was pregnant.

※This was announced half a year after the incident, after her sentence in Japan was handed down and she was transferred to the United States.

As there was no record of Jane using artificial insemination, it was speculated that she either bought a man's services or committed rape.

The press persistently pursued this point, but police stated Jane maintained her silence until the end, leaving the truth in darkness.

Even more astonishingly, Jane gave birth to a boy in the obstetrics department of an American prison.

In most developed countries, when a prisoner's pregnancy is discovered, the child is placed in the prison nursery while the mother serves her sentence, and the term may be shortened. For short sentences, it may be converted to probation depending on the prisoner's behavior.

In Jane's case of a long-term prisoner, the child would go to a facility.

However, records so far show only girls. No cases of boys being born.

Moreover, reports that Jane herself would relinquish parental rights caused a flood of applicants, creating extreme chaos.

Though not disclosed in detail, Toyoda Haruka, representative director of Japan's Toyoda Sakuya Memorial Foundation, traveled to the United States. After discussions with the Toyoda Sakuya Affection Foundation (STDAF), a friendly organization in the United States, it was reported that STDAF took custody of the boy.

Why did Toyoda Haruka act?

Why did Jane decide to give her child to STDAF?

The process remains entirely unknown and sparked much speculation at the time.

(Part omitted)

After continuing coverage since immediately after the incident, our magazine has reached one conclusion.

A male was likely involved in the kidnapping incident one year ago.

As one piece of evidence, even an amateur could guess that there was a sperm provider for Jane to become pregnant.

Even if that male was paid or raped, it is puzzling that Jane maintained her silence and authorities did not pursue the matter rigorously.

If Jane had raped a male during the incident, her criminal punishment should have been heavier.

The trial was limited disclosure, but it is known that the verdict did not mention rape.

At least, it is stated that no male rape victims existed...

Another piece of evidence is that the day after the kidnapping, Kate was rescued and Jane was apprehended. Both were reportedly admitted to a police hospital in Akita City.

That night in Akita City, under heavy security, someone was escorted the short distance from the police hospital to Hotel Grandole Akita.

Such security measures indicate an exceptionally important person. Could it have been a male?

While investigating around the kidnapping victims Komatsu Sayaka and Kate Grimwood, a certain boy emerged. This person's whereabouts were unaccounted for from the evening of January 6 to January 8, and he was absent from school at the start of the new term.

We refrain from naming this person here.

This is partly because he is a minor, but also because we wish to publish only after obtaining definitive evidence.

We believe the facts will be revealed in our magazine before long.

We ask our readers to await further reports.'

◇ ◆ ◇ ◆ ◇ ◆

"Damn, this is bad, senpai! Even that demon editor-in-chief gave up, right?"

"What's that! You're curious too, aren't you? The partner who got that atrocious J, who received a three-digit prison sentence for the first time in ages, pregnant! I absolutely think it's Y-kun!"

Both my drunken self and my senpai were slurring our words quite a bit. Some unidentifiable dialect was slipping out too.

Though it was a completely private room in an izakaya, our minds were clear enough to avoid using proper names.

Senpai was the ace of the editorial department, having scored several scoops for Weekly Bunshu.

I was a rookie reporter who joined mid-career after quitting a black company. Under senpai, I had been doing background research on the incident involving Jane Grimwood—whose real name is Mason, though she is publicly known by her assumed surname.

I heard the first article caused a stir and significantly boosted sales.

However, as if to dampen the editorial department's excitement, the managing director came and ordered the discontinuation of the sequel.

Led by the editor-in-chief, who was dissatisfied, we confronted the managing director.

In reality, extreme caution must be taken when writing articles about males.

Especially in this case, exposing the explicit experiences of a boy who, though nationally known, is a minor.

Even I, a newcomer, understand the dangers involved.

When the managing director earnestly admonished us, the feverish editorial department fell silent.

The one who couldn't accept this was senpai, who was at the center of the investigation.

"To hell with the voluntary restraint agreements in the publishing industry! What kind of mass media are we if we don't convey the truth our readers want to know?"

Senpai ranted angrily, and I was dragged along for a despair-fueled drinking session. Apparently, senpai intended to continue the investigation even against company orders.

"Hey! Miss, another cold sake!"

"You're still drinking?"

"Tonight we drink to the end! Keep me company! They told us to lay low for a while, you know. If I give up now, I can't call myself a reporter! Understand?"

"Yesss~"

In the end, I was stuck with her until the last train.

I planned not to come in until noon the next day anyway, under the pretext of independent research.

Senpai had been persistently investigating in Saitama since the start of the week, but suddenly at the end of the month, a transfer order came.

The transfer was to the Chichijima branch office in the Ogasawara Islands. Though called a branch, its main work was observing volcanic activity, with only one resident staff member. Shipments to the mainland came only once a week. It was rumored to be exile in disguise.

Persuaded by the editor-in-chief, I disposed of all the materials senpai had entrusted to me and decided to forget about the incident.

My current job is tough, but not as unreasonable as my previous company, and the pay is decent.

It's not that I lost interest in that boy, but I couldn't bear to defy the company, lose my job, and have to search for work again.

---

### Author's Afterword

I thought it would be more objective to write in the format of a weekly magazine article one year after the incident, rather than immediately after.

Yuu is treated as not involved. Jane might have spoken about Yuu during interrogation, but it was erased from the records. A common occurrence, isn't it?

Then, who got Jane pregnant?

Thus, reporters who investigated around Sayaka and Kate's circles found Yuu suspicious, but pressure prevented it from becoming public. Common (recurrence).

Well, the long Chapter 9 has finally ended.

It spanned just over a week from New Year's Eve, covered in 39 episodes (excluding interludes).

In hindsight, I could have split it into two parts.

The next Chapter 10 will be set in February-March.

Since I intend to end the story one year after Yuu's reincarnation, this will likely be the final chapter.

It will mainly focus on romantic, harem-filled daily life without major incidents like Jane's.

There are several events like Sayaka and others giving birth and graduating, so it might be split.

I will take a little over a week off to thoroughly plot the chapter.

During that time, I will update the "Character Introduction."

Please continue to enjoy *Reborn in a Chastity Reversal World*.

2021/11/2

I added an explanation for the editorial department's decision to self-censor at the end.

Not only was there pressure, but there was also an agreement not to publish articles with the real names of underage males except in special cases.

Nevertheless, because the reporter was running wild, the company transferred her to avoid actual damage.

### Chapter Translation Notes
- Translated "週刊「文秋」" as "Weekly Bunshu" to preserve the magazine's name and indicate its periodical nature
- Translated "身代金" as "ransom" consistently throughout the article
- Preserved Japanese honorifics (e.g., "ねーちゃん" as "Miss") and name order (e.g., "Komatsu Sayaka")
- Translated explicit terms directly (e.g., "強姦" as "rape")
- Used established translations for fixed terms (e.g., "Rescue Women Military Council", "Manchuria Republic")
- Transliterated sound effects (e.g., "ヤバイ" as "Damn" in context)
- Maintained original paragraph structure for dialogue with new lines per speaker
- Translated "貞操逆転世界" as "Chastity Reversal World" per fixed novel title