## 343. New Life ① ~Birth~

### Author's Preface

Sorry to keep you waiting. This is the beginning of Chapter 10.

In Chapter 10, I plan to bring back several characters who haven't appeared in a long time.

However, the first part is Sayaka's childbirth. I had decided on this early in the previous chapter.

Also, I've updated "Character Introduction 1".

---

  

"Sa-Sayaka... i-is she okay? Has she already given birth!?"

"Not yet. It's her first child. It takes time. So please calm down."

"I'm sorry. I couldn't help but panic..."

"I understand how you feel. When Sayaka was born, I was quite flustered too."

"Oh, really? At that time, I was so focused on giving birth that I didn't have the energy to pay attention to you."

"Ahaha..."

  

The setting was the obstetrics and gynecology department of Saito City General Hospital.

Yuu himself had been hospitalized here before and visited almost monthly for sperm donation. Not only was he acquainted with many nurses, but some of them were even women he had impregnated.

  

Among the women Yuu had impregnated, Sayaka was the first to give birth.

The original due date was Sunday, February 10th, and she had been hospitalized since a week prior.

Today—Saturday the 9th—her labor pains began in the evening, and her water broke around 6 PM. She was initially taken to the labor room but was then moved to the delivery room when her cervix dilated.

Yuu, who had been at home, rushed to the hospital immediately after receiving the call.

  

Following Sayaka, Riko and Emi were also hospitalized in this hospital.

Since Yuu had visited them several times, he knew their rooms.

Running inside the hospital would cause a disturbance. Suppressing his impatience, Yuu made his way to the front of the delivery room.

His visibly anxious state prompted Sayaka's parents to soothe him, as seen above.

Only her mother Tomoka and father Hikaru were present today. Although her close sister Kiyoka was also worried and wanted to come, she was right before her high school entrance exams. It was decided that she would come with their grandparents once the baby was safely born.

  

From Tomoka, Yuu learned that it could take many hours from the start of labor until birth, especially for a first child. In some cases, it might even take all night.

For Yuu, this was the long-awaited birth of his child.

Although Sayaka's health had been good since her morning sickness subsided and she entered the stable period of pregnancy, his worry remained unchanged.

He wanted to be by Sayaka's side to support her during this time.

However, he had been told there was no custom of husbands being present in the delivery room during childbirth.

Therefore, all he could do was sit on the bench in the hallway and wait.

  

The delivery room door seemed thickly built. No sounds from inside could be heard.

It didn't seem like the baby's cry of "Waaah" would be heard upon birth, as often depicted in movies and dramas.

  

"It's painful that all we can do is wait."

"Well, that's just how it is."

"Don't panic unnecessarily; stay composed."

"Yes."

  

The couple must have been tense about their beloved daughter's childbirth too.

Still, they appeared calmer than Yuu.

Although their words were gentle, Hikaru's movements of his hands and feet were fidgety.

If anything, Tomoka seemed more composed.

Men tend to panic about childbirth, while women are more steadfast.

  

Taking a deep breath, Yuu settled deeply into the chair.

Beyond the door, Sayaka was striving to give birth to their child.

Even if he couldn't be present, he intended to wait as close as possible for however many hours it took.

  

However, the hospital staff were troubled.

Naturally, Yuu was nationally recognized by face and name, but even Hikaru, at just 40 years old, was eye-catching in a world where men were precious—regardless of being married or middle-aged. Though not exactly handsome, Hikaru's gentle and kind appearance was sufficiently attractive.

In fact, within less than 30 minutes of Yuu's arrival, pregnant women with large bellies and their accompanying family members repeatedly glanced at Yuu and Hikaru, only to be warned by nurses and security guards and moved away.

Yuu had four protection officers. Additionally, three protection officers hired by the Komatsu family for Hikaru were watching from a slight distance, and hospital security guards were stationed at key points, so security measures were in place.

Nevertheless, the ward housed an unspecified number of women—doctors, nurses, pregnant women, and their companions—so it couldn't be said to be completely safe.

  

At the hospital's earnest request, the three moved to a waiting room prepared for families of pregnant women.

It seemed to be a shared waiting room with four four-seater tables, but since Sayaka was the only one scheduled to give birth that day, no one else was using it.

There was also a bookshelf with a TV, newspapers, magazines, and paperbacks to use while waiting.

  

"To think Sayaka is finally having a child... I always thought this day would come someday..."

  

Sitting around the table, Hikaru murmured with deep emotion.

To Yuu, Hikaru was his father-in-law.

A wife's father could be a difficult person to deal with. His father-in-law from his previous marriage wasn't a bad person, but they were both poor conversationalists and never really warmed up to each other. When visiting his ex-wife's family, he often struggled to keep the conversation going without her mother present.

  

In that regard, Hikaru was mentally about the same age. Though they had only met occasionally, his pleasant personality made him easy to talk to.

In his previous life, Yuu might have become good friends with him.

  

"Meeting Yuu-kun in high school was a good opportunity for her."

"Indeed."

"It's a shame about her previous fiancé; it was unfortunate for both parties."

  

Yuu recalled that Sayaka had been engaged.

It hadn't even been a year since he fell in love with Sayaka at first sight, but he had completely forgotten about it until now.

The engagement had been proposed by the other party's mother, and Sayaka had tried dutifully to grow closer, but the man had been completely unenthusiastic.

In fact, his cold attitude had even made Yuu angry when he saw Sayaka feeling down.

Later, it became clear that the former fiancé had zero intention of marrying anyone, having found fulfillment in his hobbies.

Therefore, Yuu and Sayaka getting together and the engagement being called off due to the pregnancy was a happy outcome for both.

The warm attitude Hikaru and Tomoka showed toward Yuu was also related to Sayaka's private happiness.

  

For now, all they could do was wait and pray for a safe birth.

Since it seemed like a long haul, they had boxed lunches bought and ate dinner while talking.

It had been a while since Yuu and Sayaka's parents had met together. Both Yuu and Tomoka were busy, so having ample time like today was rare, and their conversation flourished.

  

"Eh... is that really true?"

"Yeah. It's hard to believe now, but it's true. She was quite a wild child."

  

Yuu was surprised to hear stories about Sayaka's childhood.

Regarding Sayaka's past, he had often heard about her middle school days centered around kendo club activities. Partly because Riko had attended the same middle school.

It was a public middle school with a few male students, but they were in a separate building and had no contact. They were distant presences, only occasionally seen at school events.

On the contrary, Riko had told him that Sayaka was very popular, receiving multiple confessions from girls and even having a fan club made by junior girls.

  

After reuniting with Ryoko, stories of their endless battles also became topics of conversation.

He hadn't heard much about her younger days.

He only knew from Sayaka herself that she had loved moving her body since early childhood, often visiting the family dojo.

That's why the wild episodes from before her early elementary school years—which even Sayaka herself probably didn't remember well—were particularly intriguing.

It was hard to imagine from the current Sayaka, who excelled in both academics and sports, but she had been completely uninterested in studying until around the middle of elementary school.

  

"Especially since she's the eldest daughter, right? As the heir to the Komatsu family, we were worried about her future."

"I wasn't too worried. She was still young, and I thought it was fine to let her grow freely. We just needed to watch over her gently so she wouldn't go astray."

  

In the Komatsu family, her grandmother Reika was the president of Komatsu Group, and Tomoka also worked in a responsible position from a young age. Mainly, Hikaru and Tomoka's father—Yoshioki—shared the childcare responsibilities.

Sayaka's great-grandmother had retired and lived in retirement until Sayaka was in elementary school, so it was imaginable that she was raised freely within the traditional extended family.

On the other hand, she had also received strict training from her great-aunt Ritsuka, the dojo master, which likely fostered her strong-willed personality.

  

"Sayaka changed after Kiyoka was born and had been around for a while."

"Was it her awareness as an older sister...?"

"Yeah. That was probably part of it."

  

According to the two, Kiyoka had exceptional comprehension and memory, showing brilliant intellect even before starting school, to the point of being called a prodigy. Conversely, she was physically weak, often running a fever and being bedridden, and was hopeless at sports.

  

Sayaka changed after Kiyoka entered elementary school and her reputation spread.

Rather than being jealous of her sister's outstanding intellect, Sayaka resolved not to be ashamed as her older sister and to achieve top grades—a testament to her virtue.

  

Originally, Sayaka had a good head on her shoulders too.

She was a typical kid leader who preferred gathering neighborhood children to play outside rather than study. Kind-hearted, helping the weak and crushing the strong, she naturally attracted children around her.

Her school grades were average until around fifth grade, then suddenly improved rapidly, and by graduation, she was among the top in her class—quite surprising.

  

Hearing these stories, Yuu thought again that Sayaka was too good for him.

In contrast, Yuu's inner self was ordinary, and even in his memories from before being reborn, he had no remarkable episodes besides being abnormally popular with women.

Therefore, he resolved inwardly to behave as a respectable man who wouldn't embarrass Sayaka as her partner.

  

They became engrossed in conversation for a while, but as the night deepened, the talk dwindled, leaving them to watch the TV that had been left on, or read newspapers and magazines.

The fact that the nurses hadn't said anything probably meant Sayaka was still working hard to give birth.

  

When the clock's short hand approached 12 from 11, with less than 30 minutes until the date changed, hurried footsteps echoed down the hallway, coming close to the waiting room.

Since the protection officers let the person through without stopping, it must have been a nurse.

She had probably been assisting with the delivery in the delivery room. Despite it being midwinter, the nurse had beads of sweat glistening on her forehead. Upon entering the waiting room, she firmly closed the door behind her.

Facing the three of them, she showed a brilliant smile and said:

  

"Komatsu-san, Hirose-san, the baby is born!"

"Oh!"

"And?"

"How is Sayaka?"

"Both mother and child are healthy with no problems!"

  

Yuu made a triumphant pose and shook hands with Hikaru and Tomoka.

The baby's gender wasn't disclosed here, likely out of caution in case others overheard.

  

Guided by the nurse, Yuu and the others entered the delivery room.

The postnatal procedures seemed to have just finished, as the smell of alcohol stung his nose.

Sayaka lay on her back on the bed, and naturally, her abdomen had returned to normal.

  

"Sayaka, you did well!"

"Sayaka, well done!"

"Ah... Yu-Yuu-kun"

"It's okay. Just rest."

  

In preparation for childbirth, Sayaka had cut her proud black hair, which had reached her waist, short.

Still, it remained long enough to reach the middle of her back, but today she had tied it up in a single bundle like Riko.

Childbirth could be called a woman's critical moment.

She looked utterly exhausted, as if she had given her all, with disheveled hair and a pale complexion.

But a sense of accomplishment was also visible.

Beside Sayaka lying on her back on the bed was a baby wrapped in a blanket, sleeping soundly. It was the fruit of their love.

Being newly born, it was smaller than imagined. Its face was wrinkled and reddish—truly a baby.

  

"I'm glad. Truly glad..."

"Yuu-kun?"

  

As Yuu approached Sayaka's bed, he couldn't contain his rising emotions.

Tears naturally streamed down his cheeks.

In Japan, the maternal mortality rate was quite low, less than 0.1%. He had heard beforehand that the risk was negligible, especially at the young age of 18.

Still, childbirth was a life-threatening ordeal. Seeing both mother and child safe, it was no wonder tears flowed.

  

"You... worked hard and gave birth for us. Thank you. Truly, thank you, Sayaka."

"Ah... It was tough... but I've become a mother..."

  

Hearing Yuu's words of gratitude, Sayaka seemed overcome with emotion, her words breaking off.

Yuu and Sayaka held each other's hands, tears of joy continuing to flow.

  

"So, what is the baby's gender?"

  

While Hikaru was tearfully watching Yuu and Sayaka holding hands and gazing at each other, Tomoka—the calmest of the three—asked the doctor and nurses who were watching over them.

After exchanging glances, the doctor answered Tomoka as their representative.

  

"It's a boy."  
"「「「Eh!?」」」"

  

Though not particularly loud, the doctor's answer reached Yuu's ears.

Sayaka, who had heard it a moment earlier, nodded at Yuu.

  

He had heard that the current birth ratio had widened beyond 1:30.

Even if 100 babies were born in this hospital annually, only about three would be boys.

This was one of them.

Later, he heard that the nurse who spotted the small protrusion between the newborn's legs was very surprised.

However, being a veteran nurse who had delivered boys before, she calmly performed the necessary procedures.

  

Even Yuu had thought a girl was more likely statistically.

Truthfully, as long as both mother and child were healthy, the gender didn't matter.

Therefore, he was calmer than Hikaru and Tomoka, who were speechless.

  

"To think our first child would be a boy..."

"Yeah. I was surprised too."

"Either way, it's my and Sayaka's first child. We'll raise him with care. Ahh, but he's so cute!"

"Fufu. Mine and Yuu-kun's child..."

  

The two gazed at the sleeping baby.

After this, Sayaka might experience afterpains—pain from the uterus rapidly contracting back to its original size—so she would be returned to her private room to rest.

The baby would be moved to the newborn nursery temporarily, but since it was a boy, it would go to a specially prepared private room.

Therefore, they couldn't stay with him indefinitely.

  

"Well, I'll come again tomorrow. Sayaka, take care."

"Ah, um, Yuu-kun?"

"What is it? Sayaka?"

"About the name... I think you've been thinking about it..."

  

Although the probability was low, Yuu had considered several candidates in case a boy was born.

He hadn't settled on one yet.

  

"Looking at his face, a name suddenly came to me."

"What is it?"

"How about 'Hajime' with the kanji for one (一)?"

"Hajime (一)..."

  

Yuu repeated the name in his head.

From now on, many children would be born from Yuu's seed.

This was his commemorative first child with Sayaka, the first woman he loved.

As the manga title suggested, it was fitting for the "first step."

  

"Hajime (一), that's nice. Let's go with that."

"Really? Even though you put thought into it too..."

"You're the one who thought of it, but I think it's a good name too. It's early, but let's decide it here."

"Th-thank you, Yuu-kun."

  

Thus, Yuu's first child in this world was named Hajime (一).

  

  

  

  

  

  

  

  

  

  

---

### Author's Afterword

Common kanji for the name "Hajime" include "一" (one), "肇" (beginning), and "元" (origin).

Among other naming references I've seen, "始" (beginning) and "初" (first) are straightforward. "朔" (first day of the month) also fits the meaning since it's used in "tsuitachi" (first day), so it's not incomprehensible (I considered using this one).

However, using "晴士人" (clear-sky samurai person), "魁" (leader), "統" (unite), "玄" (mysterious), or "業" (work) to read as "Hajime" seemed too far-fetched, I thought.

### Chapter Translation Notes
- Translated "悪阻" as "morning sickness" (the medical term for pregnancy nausea).
- Translated "後陣痛" as "afterpains" (the medical term for postpartum uterine contractions).
- Preserved Japanese honorifics (e.g., -kun, -san).
- Transliterated sound effects (e.g., "おぎゃあ" as "Waaah").
- The baby's name "一" is rendered as "Hajime" in the text, with the kanji explained in parentheses where relevant.
- The author's afterword about naming is translated with explanations of the kanji options.