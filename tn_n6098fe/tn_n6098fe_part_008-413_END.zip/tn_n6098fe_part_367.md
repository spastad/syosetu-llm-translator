## 344. New Life ② ~The Shape of Unshakable Happiness~

"To think Yuu-kun's first child would be a boy."  
"Hajime-kun! H-he's adorable!"  
"No matter who he resembles, he'll definitely become a fine man. I look forward to his future!"  
"If I have a girl, may I arrange their engagement?"  
"Mizuki-chan, that's too hasty!"  
"But once word spreads at school, many girls will think that way, so I should claim it now..."

Two days after Sayaka gave birth to Hajime, on Monday the 11th.  
After birth, he spent time in the temperature-controlled neonatal room undergoing necessary examinations and procedures.  
He arrived at Sayaka's private room around 6 PM the next day.  
Sayaka could finally hold him in her arms.  

That said, newborns spend about three days in transparent neonatal beds (infant warmers) to maintain body temperature.  
Sayaka herself was exhausted from childbirth, so both mother and child mostly slept.  

Yuu visited Sayaka again on Sunday, meeting her grandfather Yoshioki, grandmother Reika, and sister Kiyoka who offered congratulations.  
On Monday after school, he stopped by again to find Riko and Emi - both hospitalized at the same facility - along with Riko's friend Iida Aiko and Emi's friend Ogawa Mizuki (student council accountant) visiting to see the baby.  
Mizuki wore her uniform, but since third-years had voluntary attendance from February, Aiko came directly from home in casual clothes.  

Aiko's outfit consisted of a navy winter jacket over a white high-neck sweater, caramel-colored suede tight skirt, black tights, and boots matching her skirt - creating quite a mature atmosphere.  

All student council members wanted to visit, but considering it unwise to crowd immediately postpartum, only Mizuki came as representative this time. Others would visit later.  
Despite viewing through transparent casing, his cuteness made their eyes soften.  
Hajime mostly slept or showed little reaction when awake - newborns have minimal eyesight.  
Occasional facial muscle movements sometimes resembled smiles. Though coincidental, these seeming smiles evoked overwhelming affection.  

"How are you both feeling?"  
"My stomach feels quite tight, but I hear that's normal so no problem."  
"Same here~"  

When Yuu asked Riko and Emi, their smiling replies reassured him.  
However, both near-term women moved laboriously, needing support from Aiko and Mizuki respectively when coming to Sayaka's room.  
With due dates just two days away, Riko and Emi could deliver simultaneously or separately like Sayaka. As Yuu's important fiancées, he planned to witness their births alongside their parents.  

"Speaking of which, Sairei's entrance exams are this week. What about student council duties?"  
"Well..."  

Riko's question made Yuu and Mizuki exchange glances.  
Most private high schools focus on university placement and club achievements to attract students.  
With stable enrollment currently but future declines projected, promoting school appeal is crucial.  

Sairei Academy's co-ed status gives it high application rates. Though slightly disadvantaged by location, its emphasis on gender interaction and natural environment attracts growing applicants - exceeding 10:1 ratios since year six of co-education.  
The 1991 exams anticipate explosive growth with overwhelming inquiries since last year, requiring urgent administrative staffing increases.  
All because of Yuu.  

For the regular course (200 capacity), 10:1 ratio means 2,000 applicants.  
Since school facilities can't accommodate this, municipal venues host exams annually.  
Selection involves written exams followed by interviews at school.  
Co-ed schools face more cheating attempts, creating challenges.  

With staff shortages during exams, sister schools under Ayakuni Group provide support while first/second-years assist as guides under student council direction.  
But if council president Yuu took charge?  
Teenage girls unaccustomed to males might lose focus or cause concert-like disturbances trying to approach him.  
Moreover, all current council members are pregnant - from Emi (due soon) to Sawa and Nana (recently confirmed).  
As precaution, council members were excused from duties.  

"If you want to see Yuu-kun, you must pass the exams."  
"That sums it up."  

Riko and Sayaka nodded wryly.  
Yuu felt guilty hearing he'd caused school difficulties, though increased applications benefit operations.  

"What's this year's ratio?"  
"I believe it made national news as the highest nationwide, not just in the prefecture."  

Aiko picked up one of two newspapers in the room. While national papers covered it, Martina's workplace Saito News had detailed articles. Headlines read:  

'Sairei Academy High School Regular Course Entrance Exams Reach 98:1 Ratio - Unprecedented Historical High for Co-ed Schools'  

The single P.E. course class was already filled through last year's recommendation exams - which also saw surging applications leading to increased capacity.  
This month's exams have over 20,000 applicants for 210 regular course spots.  

"Due to unprecedented numbers, they conducted document screening this year. Applicants came nationwide, not just Kanto."  
"Wow..."  
"The Yuu-kun effect is tremendous."  
"Kiyoka studied desperately too. I hope she passes."  
"She'll be fine. It's Kiyoka-chan after all."  

Yuu often visited staff rooms during breaks for student council matters. Familiar with many staff - including several intimate partners - he chatted casually regardless of relationship, sometimes touching them since he liked suited working women.  
Though busy before exams, staff welcomed Yuu - an oasis for those without male contact - sharing school affairs within appropriate bounds.  

Document screening eliminated applicants below academic standards or with disciplinary records before written exams.  
Still requiring two exam days later this week due to venue capacity, Yuu's non-involvement made it feel distant.  
He primarily hoped Kiyoka (Sayaka's sister) would pass Sairei as her first choice.  
But Riko and Emi's imminent deliveries took priority over exams.  

On the 13th, news of Riko's labor pains reached school around early afternoon. Yuu left during sixth period without attending class.  
Meeting Riko's mother Mako and Emi's mother Asami, he waited in the lounge from the beginning.  

Admitted to the delivery room, Riko could start anytime with imminent water breaking and cervical dilation. About two hours later, Emi also went into labor.  
First births typically take time, likely lasting until late night. Being Yuu's second experience, he was prepared.  

"Haah... I'm worried. For myself it's one thing, but my daughter giving birth..."  
"Emi will be fine! She'll deliver a healthy baby!"  

To Yuu's eyes, both mothers resembled their daughters.  
Riko's mother Mako usually displayed businesslike calm but fidgeted restlessly today.  
Emi's freelance photographer mother Asami typically appeared active and energetic but now sat composed.  

After chatting and watching TV/magazines for hours past 10 PM, contrary to expectations, Emi delivered first.  
Riko followed nearly two hours later, just before midnight.  
Since their simultaneous pregnancy discovery at the same clinic, they coincidentally delivered girls on the same day.  

"Ahh, so cute. Truly adorable."  
"Yuu-kun, you've only said 'cute' since arriving."  
"But it's true!"  

The next evening after Riko and Emi's successful deliveries.  
Yuu first visited Sayaka's room, then accompanied her to see them.  
Most pregnant inpatients get private rooms, but Riko and Emi shared a double room.  
Their newborns lay in infant warmers between their beds, freshly brought from the nursery.  
Sayaka sat holding four-day-old Hajime.  

Riko, having labored ten hours, still recovered in bed - smiling with accomplishment despite few words.  
Emi, having smoother delivery, sat up participating in conversation.  
Their families had visited earlier and left.  
Only Yuu, Sayaka, Riko, Emi and their babies remained.  

"Have you decided names?"  
"I... combined 'yu' from bond, 'ri' from science, and 'ka' from fragrance for Yurika."  
"Mine is 'mi' from beautiful and 'yu' from bond - Miyu-chan!"  

Both chose from previously considered options.  
Yurika seemed a fusion of Yuu, Riko, and Sayaka's names (with modified kanji).  
Emi liked the sound "Miyu", combining her "mi" and Yuu's "yu".  
Coincidentally both used the character for "bond" (結), perhaps signifying their unbreakable connection through these children.  

"Yurika and Miyu - wonderful names."  
"Truly. Yurika, Miyu - it's Papa~"  

When Yuu approached and spoke, Yurika faintly opened sleepy eyes while Miyu looked curiously before yawning and closing hers.  
Newborn communication remained difficult.  

They took turns holding Hajime.  
First Yuu - carefully receiving him from Sayaka.  
Cradling his firstborn tenderly in both arms.  
Weighing just over 3000g.  
Though tiny, he felt surprisingly heavy - perhaps because it was his child.  
Hajime kept sleeping peacefully when transferred, reassuring Yuu.  
Gazing at his sleeping face, joy welled up again, keeping Yuu's cheeks relaxed.  
Wanting to hold him forever, he yielded to Riko and Emi who waited eagerly.  

"Anyway... women are amazing."  
"Eh?" (x3)  
"Men just ejaculate, but women receive it, nurture life inside for months, and endure hardship to give birth. You three fulfilled my wish for children - Sayaka, Riko, Emi. Truly, thank you for giving birth."  

After briefly letting Riko and Emi hold Hajime before returning him to Sayaka, Yuu bowed.  
He simply expressed gratitude for his pre-reincarnation wish coming true.  
But Sayaka, Riko and Emi flustered.  

"Y-Yuu-kun! I should thank you!"  
"Exactly. Raise your head."  
"Because of Yuu-kun, we could have babies!"  
"I see. So thanks to these children, we've all become happy."  

After Yuu's words while gazing at each baby, all three teared up nodding.  

"But the real challenge starts now."  
"Mm. We must raise them properly as Yuu-kun's children."  
"I'll balance school and childcare!"  

Riko murmured while watching her sleeping child, Sayaka agreed, and Emi declared self-encouragingly.  
While childbirth brings joy, challenges lie ahead.  
Third-years Sayaka and Riko have long breaks until graduation but will juggle university and childcare come April. Emi's unchanged environment might be easier.  

"Focus on recovery and childcare at your parents' homes for now. I'll visit on days off."  

Though all planned to return to the condo, persuaded by parents, they decided to spend at least one month at their childhood homes.  
Emi's home is nearby, but Sayaka and Riko's are farther.  
Still, parental support eases newborn care.  
Thus Yuu declared he'd visit them.  

---

### Author's Afterword

First, the celebratory story continues.  
As predicted in reader comments, next year's entrance exams became chaotic.  

For reference, Heisei Year 3 Saitama public high schools had ~40,000 applicants.  
Though eras differ, it's as if all Saitama's third-year girls flooded one school.  

I just realized I forgot about male applicants.  
(Previously they entered almost exam-free, but Yuu's effect will increase numbers.)  
I'll write later about how Yuu's junior year fared.  


### Chapter Translation Notes
- Translated "産気づいた" as "went into labor" for medical accuracy
- Preserved Japanese honorifics (-kun, -chan) throughout dialogue
- Translated "一(はじめ)" as "Hajime" with furigana in parentheses for first occurrence
- Used "bond" for "結" character in names Yurika and Miyu to convey meaning
- Translated "陣痛室" as "delivery room" instead of literal "labor pain room"
- Maintained original name order (e.g., Iida Aiko, Ogawa Mizuki)
- Translated "書類選考" as "document screening" for academic context
- Preserved institutional names per Fixed Terms (Sairei Academy, Ayakuni Group)