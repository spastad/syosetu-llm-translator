## 347. Younger Girls ③ ~Sweet Touch Love~

Yuu, Nana, Kiyoka, and Sumiko moved from the living room to the bedroom, but since it had been unoccupied for a while, the room was freezing cold.

So they huddled together like packed rice cakes to warm each other up.

Though the air conditioner had started working, Yuu's body temperature and mood were also rising from being pressed against the girls from three sides.

"Since we're warmed up now, will you undress me?"  
""Yes!""  
"Eh..."

Nana and Kiyoka responded energetically to Yuu's words. Only Sumiko seemed unable to keep up with the situation. Especially because she was taller and her face was closer, she remained dazed with a blank expression.

Only after Kiyoka tapped her shoulder did she snap back to reality. Nana, already eager to undress him, quickly unbuttoned his shirt and began removing it. While Yuu remained standing, Sumiko knelt down and managed to undo his pants belt.

"U-um... is this acceptable?"  
"Mm. Don't hold back."

Nana was already pulling off Yuu's T-shirt, blocking his view, when Sumiko addressed him in a trembling voice, so he readily agreed. Sumiko had undone his pants hook but didn't proceed further. Because Yuu's bare upper body was fully exposed in her field of vision.

"Hauu..."  
"Kya, Sumiko-san!?"  
"Eh?"

When Yuu looked down after removing his T-shirt, Sumiko was dripping nosebleed as she leaned backward, and Kiyoka hurriedly supported her back.

"Ah, ah? Me... hah!"  
"Are you okay?"  
"Hawawawa... such an inexcusable... I deeply apolo..."  
"It's fine. Don't push yourself."

Yuu sat on the bed with Sumiko's head on his lap. Her nosebleed had been completely wiped away. Though not particularly avoiding it, Sumiko had been busy with studies and student council work, remaining distant from sexual interests, so seeing a boy's bare skin proved too stimulating. Sumiko seemed deeply apologetic for ruining the mood, but Yuu, Nana, and Kiyoka weren't upset. Compared to women who came on aggressively driven by lust, Sumiko's innocence felt endearing.

Yuu continued gently stroking Sumiko's head resting on his lap. Though her nosebleed had stopped, her racing heartbeat showed no sign of calming—if anything, it intensified. Moreover, with Yuu stroking her head, her body felt light and floaty as if in heaven. Since meeting Yuu, she'd felt so giddy it was like she wasn't herself anymore. But it wasn't an unpleasant feeling. Then Sumiko suddenly realized—Yuu was still shirtless.

"Yuu-senpai. You'll catch a cold like this."  
"Then... maybe Sumiko should warm me up?"  
"Huh?"

Sumiko felt ready to do anything Yuu asked. But she didn't know how.

"Brother, I'll undress too."  
"Me too."

After Nana and Kiyoka spoke in succession, Sumiko understood they should get naked to warm each other. But just imagining that scene made her so excited she nearly got another nosebleed.

Ultimately, Yuu didn't let the girls undress completely. He hadn't had much interaction with junior high girls before. Thinking it a good opportunity, he wanted to play with them still in uniform.

"*Mchu, chu, chu... afu... n-mu, churu, repa... ann*"  
"Kissing feels good?"  
"It feels... good. Yu... Yu-senpai's kiss... so sweet... delicious."

"Good girl, Sumiko."

Sumiko clung to Yuu's right side as he sat on the bed, eagerly exchanging kisses. Her sailor uniform remained on with the hem lifted, and her white bra had only the hook undone with cups pushed up. From Yuu's perspective, moderately sized breasts that seemed like C or even D-cups were pressed against him, putting him in an excellent mood. Though initially timid, when Yuu firmly pulled her close and their skin touched, Sumiko seemed to throw caution to the wind. She wrapped both arms around him, engrossed in kissing Yuu.

Meanwhile, Nana who had clung to his left side and Kiyoka near his feet were trying to remove Yuu's pants. While kissing Sumiko, Yuu slightly lifted his hips. Their hands slowly pulled down his pants. Then his already erect penis stood proudly revealed.

"Wahaa"  
"Ufufu"

Both Nana and Kiyoka gazed at the penis with sparkling eyes. Nana was one thing, but for Kiyoka, this was her first time seeing a penis in a while. Hence from her privileged position, she brought her face close, sniffing deeply before melting into a dazed expression.

"First, let Kiyoka suck it. Nana, over here."  
""Yes.""

Yuu stroked Nana's head with his left hand before pulling her to his chest. Understanding Yuu's intention, Nana wrapped her right arm around his waist and clung to him, raining kisses on his chest. Then she took a nipple into her mouth and began licking it.

"I'm glad I met an accomplished girl like you, Sumiko. Plus your proportions are outstanding—I can't stop getting excited. Now show me your breasts properly."  
"Ah, ann! I'm also... excited... ah, ah, I... I never knew I could feel this much..."

After persistent deep kissing, Yuu ran his tongue from her slender neck to her collarbone. Next were her beautifully shaped breasts. Lifting the already slipping sailor uniform further, he brought his nose close to her cleavage, where the scent of fresh soft skin mingled with milky fragrance. He kissed downward from the upper breast until reaching the small pink protrusion at the tip, lightly licking it with his tongue.

"Eh... w-wait... nnn! Fa, there... haan!"  
"Haa~ Brother-in-law's penis... long time no see. Still so magnificent... nfu. I'll lick it thoroughly for you. Nn~~ *chu, chu, chu, chupaaa*"

Sumiko moaned in ecstasy from the unfamiliar pleasure, unaware of drool dripping from her mouth. Meanwhile, Kiyoka between Yuu's legs rubbed her cheek against the penis while greeting it, then began lovingly kissing and licking it. Since Nana's bra hook was undone, Yuu's left hand easily touched her breast inside the sailor uniform. As he kneaded her modest breast and lightly teased the nipple with his fingertips, it quickly hardened. Nana let out muffled moans as Yuu fondled her nipple, but soon lifted her face while still clinging to him.

"Bro... ther"

Nana kissed Yuu's cheek while he still had Sumiko's nipple in his mouth. Her expression was completely melted. After briefly releasing his mouth, Yuu kissed Nana and stroked her head with his left hand.

"Show me your breasts too, Nana."  
"Mm. Brother, lick my breasts."

Nana quickly took off her sailor uniform. She pushed up the camisole and bra cups she wore underneath, presenting her breasts to Yuu's face. She'd reported slight swelling since her pregnancy became apparent, but to Yuu they seemed unchanged—AA or A-cup at best. But small breasts were still breasts. Though only gentle hill-like swells, they had their own allure. Yuu sucked Nana's breast while kneading Sumiko's with his right hand. Or kneaded Nana's breast with his left while sucking Sumiko's. Yuu had Kiyoka perform fellatio while simultaneously savoring both girls' breasts. The three girls' plaintive moans blended into a trio as the intensity steadily rose.

"*Haam... nmu, nmu, npa! Ufu. Chup... nyerorerorero jururi... hafuu, your penis is delicious*"  
"Ooh... good. Feels... so good, Kiyoka. Even after so long, you've gotten quite skilled."  
"I practiced during our time apart."  
"Heh, you're diligent. Good girl."  
"Ehehe. Brother-in-law, praise me more, more♪"

In reality, Kiyoka had been reading erotic manga during study breaks and masturbating while licking a large dildo modeled after Yuu's penis. Though sometimes she got too absorbed, maintaining good grades proved Kiyoka's excellence. In this heavenly state with his face sandwiched between Nana and Sumiko's breasts, Yuu judged the timing was right.

"Then as your reward, Kiyoka goes first."  
"Eh... is that okay?"

Kiyoka looked at Yuu and Nana. She'd be happy if they prioritized her since they hadn't met in so long. But since Nana and Kiyoka had developed a somewhat competitive relationship, she was surprised Nana yielded so readily.

"Women pregnant with brother's seed try to yield their turn as much as possible."  
"Eeeh!"

Kiyoka was shocked by Nana's words as she happily stroked her belly. Sumiko, unfamiliar with such dynamics, simply congratulated her. Nana's pregnancy became known in December, and though she had morning sickness, fortunately it wasn't severe. Her appetite decreased and she couldn't tolerate oily foods. Her belly still wasn't noticeable clothed—only slightly swollen when undressed like now.

"Th-that's... congratulations...?"  
"Why the questioning tone?"  
"Well... I confess, I'm jealous. But if brother-in-law marries my sister, then I as his sister-in-law becoming his wife is the natural course. Therefore! I want to make a baby right now."

Yuu placed a hand on Kiyoka's head.

"I told you before. After you've eaten properly and exercised, when your body has grown more."

Kiyoka stood about 140cm tall—below even the average sixth-grader. Unlike Sumiko who was adult-sized despite being the same third-year, Yuu felt impregnating Kiyoka while she was still elementary-school sized posed risks, so he always pulled out.

"From my perspective, I envy Kiyoka-san's position immensely."  
"That's right. Even without blood ties, you're cherished as a sister-in-law."

Admonished by both, Kiyoka nodded and apologized, "Sorry for being selfish." Yuu felt grateful his sister-in-law was obedient enough to apologize. He wrapped both arms around her sides and pulled her close. Her body was exceptionally light—like holding a child.

A true indoor type who'd been sickly in childhood, often bedridden and immersed in books. When they first met, she seemed so thin and pale-skinned she might break if hugged tightly. Naturally, her chest was completely flat. But through Yuu's encouragement and family support, she'd started caring about her health, looking healthier each time they met. Along with her improved complexion, her breasts seemed to have swelled slightly too. Yuu gave Kiyoka a light kiss before pressing their lower bodies tightly together.

"Ah, touching... penis touching my pussy... kufuun"

Kiyoka reveled in the sensation of something hard pressing against her intimate area. Though he hadn't checked, Yuu could tell Kiyoka was thoroughly wet, so he decided to penetrate her as is.

"I'm putting it in."  
"Hyaa"

In a missionary position, Yuu lifted Kiyoka. Kiyoka spread her legs to align positions, leaving only natural connection.

"Guh... still so tight!"  
"Hyaa! Aah! Going in... nguu!"

Though they'd had sex multiple times since taking her virginity, penetration always took time. Naturally, given her small body, the receiving part was physically narrow. Kiyoka's own weight impaled her on the penis like a skewer, but it stopped halfway.

"Just a bit more."  
"Wait, brother-in-law. I'll go all the way."

Kiyoka felt sorry for always making Yuu struggle despite being thoroughly wet, so she intended to move her hips herself to insert it fully. Yuu slowly lay back while holding Kiyoka. Simultaneously, he instructed Nana and Sumiko to remove their panties while keeping skirts on.

"Ha, ha, it's in! Ahaa... as expected, brother-in-law's penis... so big... filling my belly completely."  
"You did well, Kiyoka. Good girl."

Kiyoka rejoiced as Yuu stroked her head, beads of sweat glistening on her forehead. Though she'd practiced with a dildo, a real blood-filled penis was incomparable. Though small-bodied, as a sexually curious third-year junior high student with above-average libido, reuniting with Yuu after so long gave Kiyoka deep satisfaction.

"Brother-in-law, does it feel good inside me?"  
"Of course it feels good. Your vagina squeezes my penis so tightly. I barely need to move."  
"Ufufu... I'm glad."  
"Then today, you move for me? Slowly, at your own pace."  
"Y-yes! I'll try."

Kiyoka placed both hands on Yuu's chest and began awkwardly rocking her hips. Watching Kiyoka pant before him, Yuu gave instructions to Nana and Sumiko. Both obeyed without question. He had Nana straddle his face facing Kiyoka. In student council settings, surrounding Yuu with multiple girls like this was commonplace, so she didn't hesitate. Rather, with a delighted expression, she hitched up her skirt and straddled Yuu's face, presenting her exposed crotch directly to him.

Sumiko lay on her back to Yuu's right with her hips touching, throwing both legs over his chest in a crossed position. Her skirt was already lifted. Yuu bent his right arm to reach toward Sumiko's lower abdomen, letting his fingers crawl toward her groin. Immediately, love juices clung to his fingertips. Though handling multiple partners, with only one penis he could only connect to one person. But using his mouth and hands, they could all feel good together. Nana's skirt blocked Yuu's vision completely. Yet the three distinct moans reached him like a trio.

---

### Author's Afterword

Regarding nosebleed treatment, I recalled old methods like tilting the head back or stuffing tissue, but apparently those are incorrect. The proper way is pinching the nose, facing downward, and cooling the forehead. In the story, no one had accurate knowledge and followed old habits, so I've left it as is.

### Chapter Translation Notes
- Translated "おしくらまんじゅう" as "packed rice cakes" to convey the huddling imagery
- Preserved Japanese honorifics (-san, -chan) and name order (Shiranui Sumiko)
- Translated explicit anatomical/sexual terms directly ("penis", "pussy", "fellatio")
- Transliterated sound effects (e.g., "chu" for ちゅ, "rep" for れぷ)
- Rendered internal monologues in italics without parentheses
- Kept specialized terms like "sailor uniform" (セーラー服) and "camisole" (キャミソール)
- Maintained original dialogue structure with new paragraphs for each speaker