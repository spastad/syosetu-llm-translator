## 348. Younger Girls ④ ~Serious, Enthusiastic, Enraptured~

"Ah... Ahhhhhh... Cock, Brother's cock, ahhh, deep inside, my belly full of cock, it's coming deep... Ahyan! Brother! Anh, anh! So good!"

"Hyaaaaaan! Brother, brooother! Ah... there... I'm weak thereeee... Anh! Anh! Yan... it feels... so gooddddd"

"Nn, nn, kufun... I'm... being touched there by Yuu-senpai! Ah, this feels... so good, it's my first time feeling this good!"

Three distinct moans echoed through the room.

Kiyoka rode him, rocking her hips back and forth. If observed up close, one could see Yuu's cock moving beneath her nearly fat-free, slender belly. Facing Kiyoka, Nana received cunnilingus from Yuu. Having a man's face pressed against her genitals - an act women coveted that only existed in fiction - made Nana climax intensely from early on.

Sumiko lay with her legs splayed, her clitoris being teased by Yuu's right fingers. Since she was a virgin, Yuu focused on soft stimulation centered around her clitoris. Having been thoroughly aroused since meeting Yuu, Sumiko was surprisingly soaking wet. Even with gentle touches, the fact that Yuu was touching her intimate parts made her feel more than expected.

Meanwhile, Yuu was busy. He'd intentionally kept Nana's skirt on while she straddled him, leaving his vision completely dark. Still, the pussy pressed against his mouth was dripping wet, so he extended his tongue to thoroughly savor every inch of the soft, warm labia minora. Yuu's face was already drenched in her juices, with droplets dripping down to his chin and neck.

His right hand explored Sumiko's genitals. First, he softly stroked her entire labia minora with his middle finger. Bending his first knuckle, he repeatedly traced along the center of her slit with his fingertip. When he touched the small protruding tip, he felt Sumiko shudder with a high-pitched moan.

Kiyoka's hip movements were frustratingly slow. So Yuu lightly thrust upward to match her rhythm. Kiyoka's moans intensified, losing their earlier composure.

"Hahi, hahi, ooh! Fuu, fuu, kufu... No more... Ah, ah, ah... I'm... cumming, cumming!"  
"Anh! The...re... Hyuun! Aaaaaahhhh... Brother, brotheeer! Me too!"

Though Yuu couldn't see, Kiyoka and Nana tightly embraced as they neared their limits. More than their rivalry, the situation of being brought to climax together by Yuu likely caused this. In such moments, Nana - experienced in group encounters with Yuu at the student council - acted as usual. Namely, she kissed Kiyoka passionately in her aroused state.

Kiyoka was surprised but didn't refuse. Rather, she closed her eyes at the pleasure of kissing Nana and hugged her tighter than before. Their tongues naturally met, making wet squelching sounds.

Unaware of this scene, Yuu rhythmically thrust upward while focusing his tongue on Nana's enlarged clitoris.

"Nmuu! Nii... hyan..."  
"Nah! Ahe... nii... hyan..."  
"I... I'm cumming!"

The two came simultaneously as if timing it. Though both knew the happiness of climaxing through Yuu, sharing it with a companion seemed to amplify their joy. After embracing and showing each other their blissful expressions at close range, Kiyoka and Nana locked eyes and exchanged another deep kiss in unison.

Even after making them climax, the act continued. Women's orgasms last longer than men's. After pausing briefly, Kiyoka slowly began moving her hips again. This was good for Yuu - after making Nana climax, he concentrated on stimulating Sumiko with his right hand while his own pleasure built from his cock enveloped in the tight vagina. He intended to ejaculate inside Nana since he'd decided earlier not to come inside Kiyoka, but he also wanted to savor Kiyoka's vaginal sensations as long as possible.

"Hah, ah, hahn! Feels good, Brother's cock feels so good inside... Kiyoka is happy... Nn, nfun... Brother must be feeling good too, right?"

Kiyoka's initially awkward movements had become completely smooth. With each rhythmic hip swing, sticky wet sounds from their joining reached Yuu's ears. Overflowing love juices served as lubricant, and Nana's body pressed against her provided perfect support. The old Kiyoka with little stamina would have collapsed after one climax, but she'd built enough endurance to continue. While good for her, this was unbearable for Yuu. The childlike tightness made him feel like his essence was being squeezed out.

"Guh... dangerous... Nana!"  
"Hyai, Brother!"

Yuu brushed aside the skirt with his left hand and called to Nana.

"I'll pull out and ejaculate inside your pussy."  
"Hai. Switching places."

Nana had been tilting her head back in ecstasy from Yuu's cunnilingus, but upon hearing this, she smiled broadly.

"Huh? Eh, yah!"

Nana pulled Kiyoka's body away using both hands under her arms. Though petite and not particularly strong, Nana excelled at exploiting openings. Kiyoka tumbled to Yuu's left side. Though they'd been embracing like real sisters moments ago, women could be merciless to each other.

"Aahn, Brother!"  
"Sorry, Kiyoka."

Yuu comforted the prone Kiyoka by stroking her head as she clung to him. Meanwhile, Nana quickly changed positions and straddled Yuu's hips where Kiyoka had been, attempting insertion.

"Ahhaa... Bro... brother, co... cock... nn... guh! Going in... this... feels so good! Hahi, hahi... Aaaaaaaaaaahhhhhh!"  
"Wooh..."

Nana sank her hips, swallowing Yuu's cock in one motion as she threw her head back with a long moan. She seemed to be having a sweet orgasm from the deep penetration. Though it seemed to enter smoothly, her inner walls immediately tightened strongly, making Yuu groan in pleasure. Though already pregnant, her folds squirmed greedily as if trying to milk every drop. After telling Nana to take it slow, Yuu called out to Sumiko who was watching blankly.

"Sumiko, straddle my face."  
"Huh?"

Sumiko looked confused. Though she'd seen Kiyoka and Nana straddling Yuu's face and groin, she hadn't imagined it would be her turn.

"I want to lick your pussy."  
"Eh, ah, that's... blasphemous!"

By normal standards, Sumiko's reaction was perfectly reasonable. Forcing a young man to perform oral sex was equivalent to face-fucking in Yuu's previous life. But here, Yuu genuinely wanted to taste the pussy of this talented student council president and junior high virgin.

Realizing Yuu was serious, Sumiko gulped and raised her hips. Normally she might have declined, but prolonged manual stimulation had intoxicated her with pleasure. Her desire to feel as good as Kiyoka and Nana overwhelmed her usually firm rationality.

"Weh, weh... On Yuu-senpai's face... kufufu... *cough*. Is... is this really okay?"  
"Yeah. Straddle my face and show me your pussy properly."  
"Hai... please look, Yuu-senpai."

Yuu whispered to Kiyoka to temporarily move aside. Sumiko knelt over his face. Kiyoka held up Sumiko's skirt at her waist while Sumiko spread her legs and used both hands to spread her labia wide open. The glistening salmon-pink interior and small vaginal opening were completely visible. Her pubic hair was thick - though sexually inexperienced, her breasts and hips were fully developed. Her body had matured completely.

"Hah, hah, hafuu... Yuu-senpai is... staring intently at my shameful place... hah, hah, hafuu..."  
"My, Sumiko-saan. Does it feel good having Brother look at your pussy?"  
"Hah, hah, haiiii... Being stared at... by my adored Yuu-senpai... ahh!"

Sumiko seemed to have an exhibitionist streak. Though Yuu merely looked up without touching, she writhed intensely, her legs trembling violently. Droplets of love juice fell onto Yuu's face. After licking them, Yuu spoke.

"Sumiko's pussy is completely visible inside. So beautiful. Getting this wet just from being watched. How lewd."  
"Hahi! Sorry for... being lewd. I... can't control how good it feels when Yuu-senpai watches me... hah, ah, hyun!"

When Sumiko shuddered, jets of fluid sprayed out. This wasn't inherent exhibitionism - exposing herself to her crush excited her.

"Lower your hips like that. I'll make you feel even better."  
"Haa, haa, Yu... Yuu-senpaaai..."

Keeping her labia spread, Sumiko gradually lowered her hips. Thanks to Nana's movements, Yuu's pleasure steadily increased. The brief pause had helped, but he couldn't last much longer. He wanted to make Sumiko climax before ejaculating.

"Hah, ah, nn... nah! Good... bro... ther! Aah! Aah! Brother, I love it... your cock feels so good!"  
"*slurp* *lick* chupaa... Hehe, with breasts like Sumiko's, I wonder if she'll produce good breast milk?"  
"Hya!? W... wait... ah, ah, anh! No... breasts, pussy... both... nooo... aah! Bo... both feel... so... strange... hyu... I've... never felt this good before!"

Nana didn't thrust wildly but moved slowly to savor Yuu's cock, making her hip movements skillful. She placed both hands on Sumiko's shoulders for stability, rocking back and forth with long strokes. When fully sheathed, she paused to grind against his tip. Kiyoka hugged Sumiko from behind and suckled her breasts like a baby. Stimulated in two places simultaneously, Sumiko couldn't endure it, arching her back dramatically as she moaned.

Thanks to Nana, Yuu steadily approached climax while fighting to focus on cunnilingus. He firmly held Sumiko's thighs whenever they threatened to buck. Occasionally, love juices splattered, wetting his face again, but he kept licking intently. The same female musk that filled the air when Nana climaxed suggested Sumiko was near her limit. Yuu too was approaching his breaking point.

"Puhah! Nana! I'm cumming!"  
"Hyai! Nyan, me toooo... I'm cumming, buh! Aaaaaaaaaaahhhhhhh!"

Nana switched to violent thrusting as if unleashing pent-up desire. Wet slapping sounds echoed through the room. Once this started, Yuu couldn't hold back. As Nana screamed through her orgasm, thick jets of semen shot toward her womb. Overwhelmed by intense pleasure, Yuu kept licking Sumiko's pussy, eventually sucking on her swollen clitoris.

"Kuuah! Ah... feh... wha... t's... this..."

Sumiko arched backward, staring blankly at the ceiling as her voice cut off. Her first climax in 15 years. Her mind went completely blank. Unable to form words, she could only gasp silently while her consciousness floated hazily.

---

### Author's Afterword

I posted a short story with salaryman fantasy content. Please read it if interested.

『Trapped in an Elevator Alone with a Young OL, I Couldn't Hold Back Anymore』  
https://novel18.syosetu.com/n5073hi/

### Chapter Translation Notes
- Translated "おチンポ" as "cock" following explicit terminology rules
- Preserved Japanese honorifics (-senpai, -sama) per style guidelines
- Translated "マンコ" as "pussy" using direct anatomical terminology
- Kept Japanese name order (e.g., Shiranui Sumiko) throughout
- Transliterated sound effects (e.g., "guchu guchu" for ぐちゅぐちゅ)
- Maintained explicit descriptions of sexual acts without euphemisms
- Used "Brother" for "お義兄様" to convey Kiyoka's relationship with Yuu
- Translated "ワレメ" as "slit" for anatomical accuracy