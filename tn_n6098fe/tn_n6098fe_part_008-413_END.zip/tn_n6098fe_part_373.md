## 350. Celebrations Continue ① ~Song of Joy~

### Author's Preface

This time I'm writing about the aftermath of several characters who appeared long ago.

Since it's been so long you might think "What kind of character was she again?", I've written the circumstances within the story.

For details, see the character introductions... Actually, I intended to write more about the women involved with Yuu but haven't done so yet.

---

1991 began with the tragedy of Sayaka and Kate being kidnapped, but as the proverb says "misfortune may prove a blessing in disguise", the Jane gang who had been fugitives with arrest warrants were all arrested (or died), and Yuu also bonded with Kate despite their previous distance.

However, after completing interrogations and preparations, Kate moved to Matsumoto City in Nagano Prefecture using a moving company.

In February, the women impregnated by Yuu began giving birth.

Yuu's first child was born to Sayaka. Moreover, it was a boy. Named Hajime by Sayaka.

Riko and Emi gave birth to girls named Yurika and Miyu respectively.

On Friday the 15th, Yuu received news that Misa from Saitama Prefectural Saio Comprehensive High School (2nd year) and Mari from Municipal Matsusaka High School (1st year) - members of the Red Scorpions team formerly led by Kate (currently inactive) - had given birth.

The two who were hospitalized at the same time gave birth at a small clinic on the outskirts of Saito City.

Being a small clinic with only obstetrics/gynecology, security couldn't be expected like at a general hospital.

But Yuu decided to go anyway since he hadn't seen the other members besides Kate and Ryoko for so long.

On Sunday the 17th, disguised with a long-haired wig, hat and sunglasses with cooperation from protection officers, Yuu visited Misa and Mari sharing a room, guided by Ryoko.

Ginko, who rushed over after hearing from Ryoko, also reunited with them after a long time.

Needless to say, the three were astonished when Yuu removed his sunglasses.

Misa gave birth to a boy, Mari to a girl.

It was the first boy born at that clinic in three years, and the midwife apparently panicked. The veteran director in her sixties seemed unflappable and calmly handled the situation. With only Misa and Mari present and only three staff members, the secret was kept.

Kate couldn't come having just moved, but Yuu had an emotional reunion with the Red Scorpions members and was allowed to hold both babies - his fourth and fifth children. Misa had apparently given birth about six hours earlier.

Asked to name them, Yuu agonized over it.

Should he combine his name with Misa and Mari's? Or give names with special meanings?

Names naturally came to Yuu as he gazed at the babies.

"Misa's child will be 'Shin'nosuke', Mari's 'Himawari'. I'll leave the kanji to you."

When asked about the name origins, Yuu smiled wryly and said "Intuition." He felt he could see the future - the boy growing into a rambunctious kid who'd run adults ragged, the girl becoming a boy-crazy girl who loved shiny things - but didn't voice that.

Only now did Yuu learn their surnames.

Ogi Ginko: Tall and slender, trademark straight long hair dyed reddish-brown and cross-shaped face mask.

Ehara Misa: Petite with fluffy brown permed hair, distinctive large round eyes. Her son was named Shin'nosuke (慎之介). Misa herself was scatterbrained, so she wished for a cautious, thoughtful child. Whether that wish comes true depends on Misa.

Ushijima Mari: About Ginko's height but sturdy build with large breasts, long black permed hair. Her daughter was named Himawari (向日葵). Cheerful, bright Mari who values friendship. She seemed pleased with the image of a sunflower blooming toward the sun, and that her own name was included.

Ginko had brought a camera, so Yuu joined the photos.

First, Misa and Mari holding their babies with Yuu - three people together.

Then two-shots with Ryoko and Ginko.

Finally, they asked the midwife to take a group photo.

"Thank you, Yuu. I'll treasure these photos as family heirlooms."

"Don't exaggerate."

"No no, I can't show these to anyone outside our group!"

"Precious candid photos of Yuu! I'll cherish them forever!"

Ginko would responsibly develop the film at a familiar photo shop. Extra prints for Yuu would be sent to his school.

Though Yuu promised eventual marriage to Sayaka, Riko and Emi, Misa and Mari didn't expect that level of relationship. They were simply satisfied bearing children with Yuu's seed - they'd thought they'd never have any connection with men otherwise.

For Yuu, photos were nothing special. If time allowed, he wanted to visit again using seeing the children as an excuse.

---

On the 21st, Yuu received news that Kawamata Akiko, formerly the Hirose family housekeeper, had given birth.

He occasionally exchanged letters with Kawamata Akiko and Chihiro mother-and-child who returned to their Aomori hometown last May.

He learned of Akiko's pregnancy just before summer vacation.

It was clearly from when Yuu visited her apartment after learning she quit being a housekeeper and they became intimate with Chihiro present.

A letter arrived from Chihiro: 'A baby girl was born. Very healthy. Born February 18th.' Chihiro was only in second grade, but Yuu smiled at her well-written letter using kanji.

Yuu wanted to see Akiko, Chihiro and the newborn, but northernmost Aomori was far. Last month Yuu stayed overnight in Akita City because he was kidnapped - he rarely traveled far. He couldn't ask Akiko to come either with a newborn and sickly elderly mother. Though not immediately, he hoped to visit when timing allowed or have Akiko and Chihiro visit.

More birth announcements arrived.

The next was from Kuroda Noriko, third-year at Saitama Eiko High School.

Last May, Yuu went to cheer at the prefectural kendo tournament.

When he entered the restroom, Noriko - who'd just lost her match - apparently entered the men's room by mistake in shock and suddenly dragged him into a stall.

While calming panicked Noriko, they ended up having sex.

After Yuu became student council president and gained nationwide fame through Weekly Fuji coverage, the school received countless interview and meeting requests - including police inquiries.

The police couldn't be ignored, so when notified by school staff, Yuu took the call directly. They asked if Noriko's pregnancy was definitely his.

Yuu confirmed having sex but couldn't honestly explain the circumstances. So he answered that he fell for Noriko when she helped him during the tournament and initiated it himself.

After that, contact ceased. Busy days made Yuu relegate Noriko to the back of his mind.

Then on the 22nd, right after arriving at school, Yuu got a call.

Noriko's mother called to say she'd given birth.

About a week early, but a healthy boy was born.

Yuu called back during lunch to congratulate Noriko. Hearing Yuu's voice after so long, Noriko cried from shock and emotion, her words fragmented.

According to Noriko, she'd devoted herself to kendo since childhood but lost to an opponent she underestimated during her crucial third-year tournament.

The shock was immense - her vision went dark and she didn't realize she'd entered the men's room.

When she tried to assault Yuu in despair, he gently led her and gave her female pleasure.

She repeatedly expressed gratitude for even receiving a child.

Originally planning to continue kendo in university or work, her passion completely cooled.

Instead, she'd devote herself to raising the child Yuu helped create.

Raising a boy would be tough, but her mother and grandmother would help.

Her skills plateauing since high school made her irritable, straining family relations, but pregnancy dramatically improved things.

She thanked Yuu, saying meeting him and getting pregnant changed everything for the better.

---

Sunday the 24th. As usual, Yuu trained in muscle building and self-defense with Kanako and Touko at the MALSOK training center until noon.

Surrounded by many female staff, he ate lunch in the cafeteria before leaving - but not straight home. He had afternoon plans.

At Saito City General Hospital.

Though he'd visited multiple times since February for Sayaka's deliveries, he came almost monthly for sperm donation, becoming acquainted with many doctors, nurses and security.

It was also where he first awoke after rebirth. With excellent staff and security, it became Yuu's regular hospital.

For the hospital, Yuu was VIP treatment for providing top-rank semen monthly, but more than that, his friendliness toward all women made him always welcome.

Working here meant possibly meeting Yuu - with luck becoming his donation attendant, even getting pregnant like some nurses! - so no one quit; job applicants increased instead. Among hospitals, it was untouched by staff shortages.

With only emergencies on Sundays, the main entrance was closed.

As usual, Yuu entered through the back employee parking to avoid public eyes, guided by the head maternity nurse and security through silent, deserted corridors to a hospital room.

He knocked but got no answer. Maybe she was sleeping.

Hesitating slightly, Yuu slid open the door and entered.

He realized upon seeing the bed - Takano Mio, the room's occupant, was asleep.

Beside her was a newborn bassinet, the baby sleeping soundly.

Mio was a new semi-qualified nurse who turned 21 last birthday - five years older than Yuu.

But with a hairstyle reminiscent of 80s idols and a baby face, she seemed unreliable and didn't look older.

Her tea-colored short bob when they first met now reached her shoulders, parted and tied behind her ears in pigtails.

Her bare-faced, innocent sleeping face could pass for a teenager.

However, Mio's defining feature was her disproportionately large breasts for her height - apparently G-cup.

Room temperature was kept high for the baby.

The blanket was pulled down to her stomach, wearing only a pink maternity dress with sleeves rolled up.

Even now, her ample mounds rose and fell gently with her breathing.

Approaching the bed, Yuu peered at the baby.

He'd heard Mio had a girl.

Though sparse, light brown hair grew in curly.

Newborns' hair is soft, but this child probably took after Mio.

Her cheeks were soft and pudgy - truly angelic.

Yuu looked back at Mio.

Lying supine, Mio turned toward the baby and reached out.

Perhaps dreaming.

Bending down, Yuu took her hand, brought his face close, and gently kissed her.

"...Huh?"

As their lips parted, Mio opened her eyes, staring wide-eyed at Yuu.

"Good morning."

"Eh-heh. It's Yuu-sama."

"Whoa!?"

Mio smiled dazedly, zombie-like stretched both arms out, pulled Yuu close, and pressed her lips to his.

Not just that - she slipped her tongue in.

*She's aggressive right after meeting after so long,* Yuu thought wryly but reciprocated.

As their tongues met and Yuu gently stroked her head, Mio released sweet sighs of delight.

Their bodies weren't touching, but her breasts pressed softly against him.

Wanting to confirm the sensation, Yuu touched with his left hand.

His palm felt incredible softness, making his heart leap.

She didn't seem to wear a sturdy bra supporting her large breasts.

Seeing thin straps, she probably wore a camisole inside.

Carefully continuing gentle squeezes without strong pressure.

"Mmmchu, churuu... pah, ahaa... umyu, nyero, chupureroo... afuun... Yuu... sa... ma... ah? Eh? Eeeeeeeeeeeeeeeehhhhhhhhhhh!!!"

"What happened!?"

Mio's shriek brought the head nurse and security rushing in.

Yuu quickly pulled away, scratching his head.

"Sorry. I kissed her to wake her and she got startled."

The head nurse and security accepted this explanation. They'd kept Yuu's visit secret, so Mio's surprise was understandable.

Mio herself seemed half-asleep, mistaking Yuu for a dream.

After they left, calmed Mio sat up facing Yuu.

"Geez, you surprised me. I never thought you'd really come."

"Sorry. Since you were asleep, I thought a kiss might wake you."

"Ah... it's fine. I'm... happy."

"It has been a while."

Mio was Yuu's attendant during his first sperm donation at the hospital on April 1 last year. That began their connection.

Meeting again in the hospital restroom the next month, Yuu took Mio to a VIP room - but caught by her senior Kajio Shiho, leading to a threesome.

After that, he requested both as his donation attendants monthly.

But complaints from other nurses made it rotational.

Though no longer attendants, both became pregnant and shared joy with Yuu.

Yuu tried meeting Mio and Shiho during donations, but sometimes missed them when off-duty.

Last month Yuu couldn't come due to circumstances, so this was their first meeting in about three months.

"She'll grow into a cute girl like you, Mio."

"Cu-cute? Geez, uhehehe"

Overjoyed, Mio made a strange laugh as she handed the baby over. Yuu carefully held it.

The sleeping baby stirred in his arms but didn't fuss - a relief.

"Already named?"

"Raimu. From a dream."

"Raimu... unique name. You chose it?"

"Eh, um... yes."

Mio's eyes darted about suspiciously.

When Yuu kept staring, she resignedly confessed the naming origin.

On maternity leave near term, Mio had free time.

Always somewhat an anime/manga otaku (leaning erotic), but too busy for hobbies, she now voraciously consumed media.

She became obsessed with a manga about a high school girl transported to a parallel world with 1:1 gender ratio.

The heroine's name was Raimu.

In her original world, Raimu had no luck with boys, but in this normal world except the ratio, she acted proactively, enjoying her youth.

Readers projected themselves onto Raimu, enjoying romance with multiple boys.

From Yuu's perspective, she sounded like an ultra-carnivorous bitch - but gender-reversed, maybe that's normal.

"Anyway, Raimu, thank you for being born."

When Yuu spoke to the sleeping baby, Raimu slightly opened her eyes at his voice but remained dazed.

Maybe she couldn't recognize Yuu yet.

Still holding Raimu, Yuu sat beside Mio as he handed her back.

Against Mio's large chest, comfortable, Raimu immediately closed her eyes to sleep.

Watching this, both Yuu and Mio felt warmth, smiling.

"Mio."

"Yes?"

Yuu put an arm around her shoulder, peering at Mio's face.

Mio looked back blankly.

"Thank you truly for bearing Raimu. I love you, Mio."  
"Eh? Ah... mmph"

Kissed by Yuu, Mio widened her eyes in surprise but closed them with a melting expression at the lip contact.

Though happy being pregnant with Yuu's child, the past nine months had physical and mental hardships.

Safely delivering a girl lifted the burden but left her exhausted, sleeping constantly.

Yuu's words and kiss made joy surge through her again.

Tears streamed down Mio's cheeks as they kissed slowly.

---

### Author's Afterword

I intended to include the child with the other nurse Shiho, but it got too long so continued next chapter.

### Chapter Translation Notes
- Translated "禍転じて福と成す" as "misfortune may prove a blessing in disguise" to preserve proverb meaning
- Translated "男児/女児" as "boy/girl" maintaining biological precision per style rules
- Preserved Japanese honorifics (-sama for Yuu) and name order (Last Name First Name)
- Translated explicit terms directly: "セックス" as "sex", "乳房" as "breasts", etc.
- Transliterated sound effects: "がばっと" → "grabbing", "むにむに" → "soft pressing"
- Maintained manga title translation consistency with previous chapters
- Italicized internal monologue *(She's aggressive...)* per style rules