## 351. Celebrations Continue ② ~Lord Yuu, Please!~

Since Shiho gave birth to a boy, she was admitted to a different floor than usual in the obstetrics department. 

It was a special room - one of only two available in the general hospital's maternity ward. Yuu noticed it was the same room where Sayaka had been hospitalized before.

Learning from his experience with Mio, Yuu had a nurse notify Shiho in advance, so she was awake and waiting for him. Not only that - she was standing to greet him rather than staying in bed, which flustered Yuu.

The old Yuu wouldn't have understood, but childbirth is considered a life-threatening act involving tremendous pain and physical exhaustion. As Yuu grew more aware of what it meant to have his own children, he'd studied and come to understand this. Normally, one can't move around freely immediately after giving birth.

"S-sorry about this..."  
"You shouldn't push yourself. You need to rest now."

Yuu carried Shiho and sat her on the bed. Despite her tall, slender frame, Shiho felt surprisingly light - so delicate it seemed she might break if he applied any pressure. In the adjacent newborn bed, a baby slept peacefully.

"It's a boy?"  
"Ah... yes. I never imagined I'd give birth to a boy... I was shocked..."  
"You worked hard to deliver him. Thank you."

Yuu extended his left hand to stroke Shiho's head at nearly his own eye level. Her once-short bob now covered her ears and nape. As Yuu offered his congratulations while stroking her hair, Shiho's lips curved into a heartfelt smile.

"I've only received happiness from Lord Yuu since meeting you, without being able to repay you at all."  
"Don't say that. Meeting Shiho-san at this hospital is what made me happy."  
"Lord Yuu..."

Yuu recalled that when he first awoke in his reincarnated body, Shiho was the first woman he'd encountered. He'd immediately thought her beautiful. Her devoted nursing made him feel the term "angel in white" was created for her.

Of course, this was before he understood the chastity-reversed world, when his teenage body and middle-aged consciousness didn't align. Shiho maintained a reserved attitude, keeping a nurse-patient distance. But they'd secretly held mutual affection. That's why they'd passionately reunited later.

Yuu could only meet Mio and Shiho during monthly sperm donations. Both had apparently gotten pregnant during their second simultaneous encounter. When donation duties later rotated, some months passed without seeing Shiho. Though he'd congratulated her upon learning of her pregnancy, Yuu's busy schedule as student council president prevented frequent visits, leaving him remorseful.

In this world, most men marry to be supported by women, but it's not obligatory. For women, just having sex with ejaculation inside is blessing enough. Men bear no obligations even if their ejaculation results in pregnancy. While Yuu had no need to feel guilty, he genuinely wanted to celebrate and care for Shiho after her safe delivery.

As Yuu caressed Shiho's cheek with his right hand, he suddenly kissed her and pulled her close. Whether from the heating or nervousness, her lips felt slightly dry. Yuu pressed his lips repeatedly against hers as if to moisten them. Shiho lightly rested her hands on Yuu's back, but whether from emotional excitement at their long-awaited kiss or something else, her grip suddenly tightened. As they changed angles and kissed repeatedly, sweet sighs escaped Shiho's lips.

After about five minutes of kissing, Yuu and Shiho sat shoulder-to-shoulder gazing at the baby. With only about two days since birth, individual features weren't distinct yet. Still, while Mio's Raimu felt charming, Shiho's boy somehow seemed dignified - perhaps parental bias.

"Have you decided on a name?"  
"Actually... I wanted your opinion too..."

Shiho glanced toward her pillow. Several books were stacked against the headboard - large thin parenting magazines and smaller thick dictionaries. Shiho retrieved a memo tucked in a magazine and showed Yuu. Among various listed kanji, her slender finger pointed at "諒" (likely read as "Ryō"). But surrounding characters also caught his eye:

真 (Makoto), 誠 (Makoto), 慎 (Shin), 真実 (Shinjitsu), 真人 (Masato), 真誠 (Shinsei), 真琴 (Makoto)

Yuu guessed Shiho favored "Makoto." She'd probably hesitated about using "諒" for "Makoto" despite knowing it's typically read "Ryō," hence consulting him.

"Could it be... Makoto?"  
Shiho's face instantly brightened. Correct. She promptly opened a bookmarked dictionary page. "諒" has on'yomi reading "Ryō" and kun'yomi readings "Makoto" or "Satoru," meaning: "① Truth. Without falsehood. '忠諒' (Chūryō - loyalty and sincerity) ② To sympathize. Also, to clarify. To comprehend."

"Makoto... yes. It has good meaning - I think it's a wonderful name."  
"Really!? I'm so glad!"

Had this been pure phonetic borrowing, Yuu would've objected. But since the reading was dictionary-approved, it was fine. Consultations often mean the answer already exists within. He felt approving the name Shiho - who'd be closest to the child - had chosen was best.

As they settled the name, the baby in bed began fussing.  
"Wh-what should I do?"  
"Let me hold him. What's wrong, Makoto?"

Though not yet registered, Shiho picked up the baby she'd named Makoto. But he didn't stop crying when held. Naturally, he couldn't speak meaningfully or move purposefully, leaving them clueless about his needs.

"Maybe milk? Um... Lord Yuu, a favor?"  
"Of course. What can I do?"

Yuu anticipated Shiho intended to breastfeed and proactively offered help. Shiho wore a white gown. She exposed her breast by slipping it off her left shoulder where the baby's head rested. Unlike Mio, slender Shiho had modest breasts - small enough to cup in a palm. But they seemed slightly larger than Yuu remembered, likely due to pregnancy/childbirth preparing for breastfeeding - the mystery of the female body.

The baby was indeed hungry. When Shiho positioned him against her breast, he immediately latched on. Even without sight, he knew by smell or instinct.

"Nn... kuh... sorry. It's not coming well yet..."

Though the baby seemed to suck vigorously, he apparently got little milk. Remembering Shiho's earlier request, Yuu retrieved a bottle from a nearby warmer. He handed her the small bottle containing about 1/3 white liquid warmed to body temperature. Shiho detached the baby from her nipple and offered the bottle's nipple instead. He immediately began gulping.

"Breast milk doesn't come right after birth."  
"Eh? Really?"  
"But I've heard it starts coming when the baby sucks."

Exclusive breastfeeding is ideal. But newborns don't always latch well initially, and milk production varies. During Sayaka's pregnancy too, Yuu continuously learned surprising facts about childbirth and childcare.

In his previous life, Yuu never had children despite marriage, but he increasingly recalled a colleague excitedly sharing first-time fatherhood experiences. Watching Shiho feed the baby, she'd fully transformed into a mother. Women naturally develop maternal awareness after carrying a child for nine months and giving birth. As a man, Yuu only now felt paternal awareness and affection well up seeing his newborn.

***

After baby Makoto (tentative name) fell asleep contentedly, Yuu bid Shiho farewell and left the room. Surrounded by protection officers and hospital security, he reflected.

For Yuu, Sayaka, Riko, and Emi were fiancées who'd definitely become family through marriage soon. In this world, married men live with multiple wives when circumstances allow, or practice "tsumadoikon" marriage like the Heian period - husbands visiting wives' homes. Yuu would likely live with Sayaka, Riko, Emi, and their children as rehearsed.

But Misa, Mari, Akiko, Noriko, plus Mio and Shiho would raise Yuu's children as single mothers. Since women run society here, childbirth/childcare support is standard. With single mothers outnumbering two-parent families, those with steady jobs face no hardships. Schools/workplaces above certain sizes must have nurseries - offering more security than Yuu's previous world.

By late February, nine of Yuu's children had been born. More would arrive starting next month. Though mothers could raise them alone (with family support), Yuu worried about the newborns. He wished to visit frequently, but with only one body and many commitments, he realized this was when to request support from the Toyoda Sakuya Memorial Foundation. Just as this thought came, he arrived at the maternity ward nurses' station as requested.

"Guh!"

The nurses' station - where department nurses stay - typically has a central counter in general hospitals for visitors/inpatients. Aside from white uniforms, it resembles a government office reception. Though the hospital had many staff, each station had under ten nurses.

But when Yuu visited, white-uniformed nurses alone seemed to number over thirty - a full class. Yuu noticed several young girls in light blue nurse uniforms gazing at him with sparkling eyes. Beyond them in hallways, pregnant women with large bellies and female visitors of various ages formed lines - totaling 50-60 women. Protection officers flanked Yuu, but the women showed no approach intention - just intense stares.

"Hirose Yuu-sama. We've been waiting for you."

A middle-aged woman at the nurses' forefront addressed Yuu - the maternity head nurse who'd cared for Sayaka during hospitalization.

"Um... what is this?"  
"Apologies for the disturbance."

The head nurse bowed and dispersed the onlookers with a glance. Nurses parted down the middle, creating a path for Yuu guided by the head nurse. Along the way, Yuu noticed not just maternity nurses but the surgical head nurse and veteran nurses who'd cared for him during hospitalization - likely representatives from each department.

Yuu entered a small room behind the station. Calendars from pharmaceutical companies, whiteboards with schedules, vaccination/infection notices, nursing union bulletins, medical posters, and printouts covered the walls - organized but distinctly office-like. Pipe chairs lined a long table, with a black-suited woman seated farthest right. Yuu recognized the silver-rimmed-glasses-wearing, thin, nearly-60 woman with streaked hair in a bun - the hospital administrator, second-in-command. She'd formally thanked Yuu after his semen test results when he donated three consecutive months.

"Quickly, Hirose-sama, this way."

Though not pushed, Yuu felt subtle pressure from the nurses and took the leftmost seat. The administrator opposite seemed tense, staring down. Yuu worried he'd caused trouble.

As department heads sat and the door closed, the administrator spoke gravely:  
"Normally we only accept voluntary offers from men themselves - never coercion..."

The administrator faced Yuu with apologetic expression and furrowed brows. Yuu remained confused. Suddenly, she bowed deeply enough to hit the desk.

"We humbly beg you! Hirose-sama!"  
"Y-yes?"  
"Please, please... could you... accept sperm donation at our hospital!?"  
"""Please, Hirose-sama!"""

Dumbfounded as hospital staff - women easily twice his age - bowed, Yuu actually felt relieved realizing it was a donation request.

"Ah... I see. Of course."  
"Apologies for the presumptuous... eh?"

Men above certain age must donate sperm annually. Typically done through masturbation into a container in a private room, Yuu had requested nurse assistance after learning it was permitted. Nurse-assisted handjobs became win-win events - Yuu and nurses both enjoyed them. Yuu's Special A Class semen even earned monthly payments exceeding high school part-time wages. His regular donations boosted hospital reputation and nurse morale.

But January's kidnapping and police interrogations prevented his visit. The administrator feared Yuu was dissatisfied or had switched hospitals. However, since Yuu visited his hospitalized fiancées and nurse employees Mio/Shiho, they decided to ask directly.

"Come to think of it, I couldn't come last month. My apologies."  
"No, no! Please raise your head!"

As Yuu bowed, the administrator looked flustered. Though appearing a specialist, her weary expression made Yuu sympathetic.

"Shall we do it now then?"  
"Eh... is that alright?"  
"Of course. With the nurses' assistance."  
"""Yes! Leave it to us!"""

When Yuu smiled while scanning the head nurses, they all nodded with joyful expressions.

***

### Author's Afterword

Among all professions, getting handjobs from nurses in white is great, isn't it?  
Thus, next comes the long-awaited sperm donation chapter.

### Chapter Translation Notes
- Translated "祐様" as "Lord Yuu" to convey the respectful address
- Translated "献精" as "sperm donation" consistently with Fixed Reference Notes
- Preserved Japanese honorifics (e.g., Shiho-san, Sayaka-san)
- Transliterated sound effects (e.g., "gulp gulp" for "ごくごく")
- Used explicit terms for sexual acts (e.g., "handjob" for "手コキ")
- Maintained original name order for Japanese characters (e.g., Kajio Shiho)
- Translated "特Aクラス" as "Special A Class" per Fixed Reference