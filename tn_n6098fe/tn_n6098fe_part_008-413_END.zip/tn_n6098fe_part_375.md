## 352. Ejaculation Viewing Session ① ~Monochrome Venus~

### Author's Preface

In the hospital, the women who appeared by name and interacted with Yuu were Mio and Shiho, and Ro Chie (appeared in chapter 172), who was once his attending doctor?

This time, I came up with two new sperm donation attendants on short notice.

---

Yuu had been using the VIP room on the top floor of the hospital for sperm donation, but it was a distance from the obstetrics ward nurse station.

Yuu suggested that he didn't need to go that far and could use an available private room in the obstetrics ward instead.

If Yuu moved around with guards, security, and nurses in tow, it would draw attention. The hospital also found it more convenient to have it nearby, so they gratefully agreed.

While waiting for the sperm donation container and the two nurses in charge who had been selected last month to arrive, Yuu chatted with the large group of nurses surrounding him.

"If you'd like, would you all like to watch?"  
""""Huh...?""""

The head nurse and the other nurses couldn't believe their ears at Yuu's words.

In the general hospital, those with excellent work attitudes and performance could be assigned to the VIP room for men.

However, the inpatients were mostly elderly, and even the younger ones tended to be selfish, making it hard on the nurses.

Still, it was one of the few opportunities to interact with men.

In March last year, the situation changed completely with Yuu's hospitalization.

Yuu was gentlemanly and friendly to everyone—doctors, nurses, and office staff—and chatted with them casually.

He didn't get angry at nurses who made mistakes in front of him; instead, he worried and offered a helping hand. Such a young man was rare.

Moreover, once they became acquainted, he would touch them while talking. It was only natural that the nurses he interacted with became smitten.

Even after Yuu became nationally famous as the student council president in Weekly Fuji, his attitude didn't change, and it remained the same whether the person was a novice or a veteran.

After his discharge, Yuu visited every month for sperm donation, and two nurses selected by lottery would assist him in ejaculating.

Of course, he didn't engage in actual intercourse as he had with Mio and Shiho, but he would hug them, let them rest their head on his lap... in other words, spend about an hour flirting like lovers.

For the nurses in charge, it was truly blissful time.

Although the details of the sperm donation were never to be leaked externally, they had secretly become legendary among the nurses in the hospital.

"I-Is it really okay?"  
"Yeah. I don't mind at all. It's not like it'll shrink from being watched."

*(No, no, no...)* Some nurses retorted in their minds but didn't say it out loud.

The nurses in the obstetrics ward hadn't been lucky in the lottery and hadn't been selected for sperm donation duty until now. Just being allowed to be present was fortunate enough.

For Yuu, it was a small service, considering that the women he impregnated at this hospital's obstetrics ward would be taken care of next month and beyond. Plus, it had a lot to do with Yuu simply liking nurses. He got excited at the thought of ejaculating while being watched by a large group of nurses.

Thus, not only the 10 people from the obstetrics ward—including the on-duty female doctor who heard about it and joined—but also 3 nursing students who happened to be there for training were noticed by Yuu, making a total of 13 spectators.

The location was a room in the obstetrics ward for newborn boys and their mothers, conveniently located opposite Shiho's room.

Out of consideration for the surroundings, the head nurse instructed everyone to keep their voices down.

"Sorry to keep you wa... uh, what is this...?"

The two nurses in charge who brought the sperm donation container were speechless as soon as they entered the room.

The private rooms in the obstetrics ward were spacious to prevent pregnant women with large bellies from feeling cramped and to accommodate newborn beds. It would be about 18 tatami mats if it were a Japanese-style room.

Even so, with 14 people including Yuu, there wasn't much space to spare.

Yuu himself was sitting on the edge of the bed near the middle.

Three older nurses, including the head nurse, sat on chairs placed in an easy-to-see position facing Yuu—one at each end of the bed. The others lined up against the wall and by the window, facing Yuu. The nursing students were near the entrance, the farthest away.

As per medical professionals' custom, no one wore perfume, and their hair was either short or simply tied up.

Even so, due to the high population density, the room was filled with the fragrance of women.

"Today, we have a lot of spectators. Come over here."

Yuu, who remained calm even when surrounded by a large group of women, called out to them, and the two nurses in charge immediately showed expressions of joy. They hurried over to Yuu and lined up in front of him.

"I am Fujita Kasumi from the surgery department, in charge of today's sperm donation. Nice to meet you."  
"Um... I'm Nguyen Dieu Mai from pediatrics. Please call me Mai. Nice to meet you."

The two approached Yuu and greeted him in the middle.

Kasumi was a little shorter than Yuu. She had a voluptuous body clearly visible even through her white coat. Her hair was short, just covering her ears, with soft waves. Her downturned eyes and beauty mark near her mouth gave her a mature, sensual aura.

She was also familiar with Yuu and had spoken with him several times before.

She was 31, married, and a mother of one. Yuu had the impression that she resembled his half-sister Satsuki. In other words, she was a woman who exuded a maternal aura that made men want to depend on her.

In contrast to Kasumi, who was calm and spoke gently to Yuu, the other was clearly nervous and spoke quickly.

Mai was a 23-year-old nursing trainee from Vietnam who had come to Japan to work. Originally, her training was supposed to last two years, but due to her excellent work and her strong desire to stay, she was still working this year, her third.

Although her intonation was slightly off, she had no problem conversing in Japanese.

She was petite, under 160 cm, and slim. Her forehead was exposed, and her black hair was tied up in a small bun at the back of her neck.

Vietnamese names consist of surname, middle name, and given name. Since it's in the Chinese character cultural sphere, it can be written in kanji, and her name tag on her chest had both kanji and katakana.

Apart from her slightly dark skin, she was no different from a Japanese person. With her double eyelids, small face, and baby face, she looked younger and cuter than her age.

She didn't seem to have met Yuu before, but she couldn't hide her joy at seeing him up close. While fidgeting, she stared at him with sparkling black eyes.

"Kasumi-san, Mai-san. Nice to meet you."  
""Yes!""

The two replied energetically and immediately got to work.

It had been six months since Yuu's sperm donation became a rotating duty. There was a manual, and it seemed that each time, the previous attendants passed on how to do it.

While Mai turned on the container's power and checked its operation, Kasumi knelt facing Yuu.

"Hirose-sama, excuse me. I'll take off your pants."

Yuu nodded and stood up from the bed.

Kasumi, being experienced with men, remained calm. She might have been nervous inside, but she wore a gentle smile.

Today, he was wearing slim-fit cotton pants that didn't require a belt.

Kasumi's hands undid the button and zipper and pulled them down, revealing striped trunks and toned legs.

At this point, the watching nurses' eyes were glued to him. Just as Yuu was fascinated by women's beautiful legs, the nurses were also captivated by the rare sight of a young man's legs, becoming excited.

Even Mai stopped her hands for a moment.

The pants weren't off yet. Kasumi neatly folded the pants, and Yuu thanked her as he sat back on the bed.

By then, Mai was also ready.

Now, the ritual of Yuu's solo sperm donation, assisted by two nurses, would begin.

"Hirose-sama, is it alright?"  
"Yeah. Also, thinking about what we're about to do, I'd like you to call me by my name."  
"...! Yu... Yuu-sama?"  
"Yes. Kasumi-san. Come here."  
"Ah, um..."  
"Mai-san."  
"Mai is fine. Yuu-sama."  
"Yeah. Mai, come here quickly."

Yuu called out to them as casually as if inviting girlfriends, and Kasumi, who reacted first, showed her joy and scooted over to sit on Yuu's left side.

As Kasumi pressed her body against him, Yuu met her eyes and smiled, and she immediately looked dazed, as if she had already fallen for him.

After all, she had been overjoyed to be selected for sperm donation duty by luck, but a month had passed without Yuu visiting the hospital.

Considering how busy Yuu was, she had feared she might never see him again.

Then came this sudden summons for a meeting.

Unable to contain her excitement, she had walked quickly down the hallway where running wasn't allowed.

Kasumi had once been in charge of the VIP room for men and had been taken as a wife by a patient 15 years her senior. She even had a child. She loved her husband, but that was that, and this was this. It wasn't a world where one was bound to one man.

Even if Yuu was about half her age, that's just how women were—they couldn't help but be attracted.

Yuu turned to the remaining one and extended his right hand.

Mai had been frozen, staring at Yuu's hand, but she timidly reached out.

Her small, girlish hand was placed on his, and Yuu's hand gripped it and gently pulled her closer.

In an instant, Mai plopped down, and Yuu wrapped his arms around both their waists and pulled them close.

In contrast to Kasumi, whose large breasts were clearly pressing against him, Mai's body lacked curves, and her chest's swell wasn't noticeable through her white coat.

Still, feeling the soft touch and pleasant smell through the white coat, Yuu's excitement rose.

"I'm happy to have beauties like Kasumi-san and Mai assisting me."  
"Hehe. I'm the one who's happiest to be chosen for Yuu-sama..."  
"Eh, ah, um... Me? Beautiful? Am I beautiful?"  
"Kasumi-san is a sexy beauty, and Mai is more on the cute side, I'd say."

Kasumi rested her head on his shoulder.

Mai, praised as cute by Yuu, blushed and flustered. She had no experience being praised by a man, so she was bewildered, but she couldn't help feeling happy.

She might have put her hand on her chest because her heart was racing.

Yuu, finding the contrast between the two pleasing, smiled and said:

"Well then, let's have the beautiful nurses make my sperm lively."

In a different time and place, this would be denounced as sexual harassment, but now Kasumi and Mai were there for that very purpose.

Naturally, both their gazes turned to Yuu's crotch.

Pressed against from both sides, it was already half-erect.

"Th-then... I'll take them off."

Kasumi, who had gradually become excited while clinging to Yuu, asked in a slightly hoarse voice.

Yuu nodded in consent, and Kasumi exchanged a nod with Mai.

Both their hands went to the sides of the trunks, and they slowly lowered the last piece hiding his crotch.

Yuu could tell that all the watching nurses were leaning forward, their gazes hot.

From the 20-year-old nursing students to the nearly 50-year-old head nurse, 14 nurses surrounded him.

Even though he hadn't been touched directly yet, his crotch began to react as if Yuu's excitement had transferred to it.

As the elastic part of the trunks passed, his cock sprang up energetically.

"Ohh..."  
"Ahh!"  
"No way!?"  
"Th-this is..."  
"Amazing... Just seeing it makes me..."

Instantly, exclamations of admiration rose.

There were a few women like Kasumi who had experience with men, and even without experience, they had seen male genitals in AVs, porn, and nursing training—using video or mannequins, not the real thing.

However, none of the nurses present had seen Yuu's cock before, and they were astonished and moved by its length and thickness, which were on a different level from ordinary men.

"Kasumi-san."  
"Huh!? Nn... Nngh... Fmm..."

Paying no mind to the reactions around them, Yuu turned his face to Kasumi on his left and immediately stole her lips.

Kasumi's eyes widened in surprise, but she accepted the situation immediately.

Her eyes curved with joy, and she clung to Yuu with both hands.

Yuu's excitement rose as her voluptuous body pressed against him.

He changed the angle of his face several times, making lip sounds as they kissed.

At the sudden kissing scene, the watching nurses gasped and let out heated sighs.

Yuu's left hand, which had been around her waist, slowly stroked her back and buttocks in a gentle curve.

Of course, Kasumi also took this opportunity to roam her hands over Yuu's hard flesh without restraint.

"Touch it."  
"Yes."

After kissing for about three minutes, Yuu instructed, and Kasumi nodded with a melted expression and reached out.

As Kasumi's warm hand began stroking the shaft, Yuu turned the other way.

"Mai."  
"đúng... Ah, yes!"

What sounded like "don" or "dom" to Yuu's ears was probably Mai's reply in her native language. She hurriedly corrected herself.

When Yuu's hand touched Mai's arm from behind, she seemed to understand his intention and extended her hand to his crotch, her trembling fingertips touching the glans.

At that moment, Yuu covered her lips as she closed her eyes.

"Don't be so stiff."  
"B-because... I'm nervous..."  
"Well, I see."

Mai had secretly admired Yuu, gossiping about him with her fellow nurses at the general hospital, so it was unreasonable to expect her not to be nervous when her crush was so close.

But as Yuu's hand continued to gently stroke her back and he gave her light kisses—chuu, chuu—her heart melted like snow in the sunlight.

"Mai, you can touch a little more boldly. Use your palm too."  
"I-Is that so? Ah, it twitched!"  
"Because your hand feels good."

"Is this okay?"  
"Yeah, that's it. Kasumi-san, you're good at this. Ah, it feels good."  
"Hehe. I'm glad. But Yuu-sama's cock is truly magnificent..."

At first, she seemed flustered by the size difference, but Kasumi's touch gradually became skillful.

In contrast, Mai was awkward in both strength and technique. It couldn't be helped since it was her first time touching a male organ. She managed with Yuu's advice.

Anyway, as the two soft hands continued to caress him evenly from the glans to the testicles, pre-cum began to drip, making a sticky, squelching sound.

As Yuu felt pleasure, Kasumi and Mai became happier and more enthusiastic in stroking his cock.

The nurses watching couldn't remain calm either. They breathed heavily, haa haa, and rubbed their thighs together, fidgeting.

"It's about time."  
"Fah... Yes... Nngh, haan..."

While being hand-jobbed and kissing Kasumi and Mai alternately, Yuu realized he was nearing ejaculation.

Yuu's left hand went down to Kasumi's buttocks, kneading her plump ass.

His right hand went around her back to her side and touched Mai's chest. Even through the white coat, it felt like small breasts, but Mai's modest moans as Yuu touched her chest were adorable.

Upon Yuu's signal, Mai reluctantly left him and reached for the sperm donation device.

She picked up the rubber cap at the end of a hose that resembled a vacuum cleaner hose.

By then, Kasumi had bent over and brought her face close to his cock.

Her hand lightly gripped the shaft and stroked it gently from the base.

"Um... Yuu-sama, may I lick it?"  
"Yeah. Suck it. Please."

At Yuu's reply, Kasumi grinned and turned to Mai.

"You go first," she said softly, and Mai bowed in thanks.

Mai brought her nose close to the glans and sniffed, snn snn. The unique smell acted like an aphrodisiac, and Mai's small mouth opened slackly.

Hurriedly swallowing her saliva, Mai stuck out her tongue and licked the transparent fluid dripping from the urethral opening.

"It's salty, a strange taste. But somehow, I think I could get addicted."  
"Hehe. Let me lick it too."  
"Nn... Okay..."

Mai, who had been licking like a small animal lapping water, noticed Kasumi's words and moved slightly away from the glans.

"It's okay. Suck as much as you like until I ejaculate. Nngh! I-It's okay. Kasumi-san!"  
"Ahmoo, ohhhigyesu..."

After kissing the glans, Kasumi opened her mouth wide and swallowed the entire glans.

Then, she licked around inside her mouth.

Mai lowered her head a little and ran her tongue along the shaft.

Yuu reached out to stroke both of them within reach, as if thanking them for diligently sucking his cock.

"Ah, ah, ahh... That's good. Kasumi-san, Mai... There, it feels good... Haa, haa, I'm about to..."

It must have been about five minutes since the double fellatio began.

Mai, though clumsy, licked enthusiastically.

Kasumi, with her experience, focused on the good spots for men, from the glans to the frenulum.

With the two of them, Yuu was approaching his limit.

Mai firmly placed the rubber cap she was holding in one hand. The rubber material enveloped the glans to prevent any leakage.

Kasumi used her hands and mouth to caress the testicles.

Mai stroked from the coronal ridge to the base while timing it.

Both looked up at Yuu with upward glances, their caresses urging him to ejaculate.

Although it was part of the job, their service to Yuu was filled with affection.

"Ah, kwaa! I-I'm... about to... cum! Nngh, Kasumi...san! Mai! Ahh! I'm ejaculating!"  
"Ahh, Yuu-sama!"  
"Ahaa... Yuu...samaaa..."

The two, seeing Yuu about to cum from their caresses, were filled with deep sensuality and satisfaction, their bodies trembling.

But they tried to do what they had to do.

Mai pressed the switch, and with a noisy motor sound like a vacuum cleaner, suction started.

"Uho!"

Yuu felt a strong pulling sensation around his crotch. It was a different kind of strong stimulation from fellatio.

As soon as he ejaculated, his semen was sucked out in an instant with a kyupon sound.

### Chapter Translation Notes
- Translated "射精見学会" as "Ejaculation Viewing Session" to convey the event's nature
- Translated "モノクローム・ヴィーナス" as "Monochrome Venus" to preserve the artistic reference
- Preserved Japanese honorifics (-san, -sama) as per style rules
- Translated explicit sexual terms directly (e.g., "チンポ" as "cock", "フェラ" as "fellatio")
- Transliterated sound effects (e.g., "ちゅぱちゅぱ" as "chupa chupa", "きゅぽん" as "kyupon")
- Maintained Japanese name order for Japanese names (e.g., "Fujita Kasumi")
- For Vietnamese name "Nguyen Dieu Mai", used original spelling and provided katakana reading
- Translated internal monologues in italics (e.g., "*(No, no, no...)*")
- New dialogue lines start on new paragraphs as per rules