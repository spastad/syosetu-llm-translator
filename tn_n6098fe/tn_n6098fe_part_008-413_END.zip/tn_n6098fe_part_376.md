## 353. Ejaculation Viewing Session ② ~I Want to Be the Nurse of Your Dreams~

"Aah! It's still coming out. What a waste!"

While Mai was checking the state of the suctioned semen, Kasumi noticed semen leaking slightly from the uncovered penis and cried out. She stuck out her tongue greedily as if not wanting to waste a single drop of sweet nectar.

"Aah... feels so good..."

Kasumi was skilled at cleanup fellatio too. She sucked with chu-chu sounds, trying to drain every last drop of semen. As Yuu floated in post-ejaculation bliss, Mai finished her cleanup and joined in, thoroughly licking every corner.

Yuu kept gazing at the ceiling while leaving it to the two women, but suddenly became aware of his surroundings. The head nurse sitting in a chair, the nurses against the walls and at both ends of the bed, the nursing students near the entrance - all were staring at Yuu without exception. Leaning forward as close as possible without disturbing the trio, they all shared looks of envy. Surveying them, Yuu spoke.

"I'd like you all to touch me too, if that's alright."

He trusted this hospital's staff and knew he'd continue relying on them. Yuu was simply expressing his natural philanthropic spirit, but his words shocked everyone.

"Eh... e-even someone like me, Hirose-sama? Is it really alright?"

The head nurse spoke hesitantly with an expression of disbelief, yet hope visibly seeped through. Though embarrassed at her age, she found herself drawn to Yuu.

"Yes. Starting with the head nurse, I want to interact with everyone here. I want to kiss you. I want you to touch my penis. I truly mean it."

Current Yuu rarely experienced post-ejaculation clarity like a sage. Frequent encounters with multiple partners and growing accustomed to the chastity reversal world had made him greedy. Age differences didn't matter - being surrounded by white-uniformed nurses only fueled his excitement. Yuu was also a uniform fetishist.

While the obstetrics nurses conferred, Kasumi and Mai prepared to leave after completing their duties. They didn't want to part from Yuu but feared earning resentment by staying longer. Sensing their departure, Yuu stood up.

"Kasumi-san, Mai. Thank you for today."  
"No, I should be thanking you for this precious experience."  
"Thank you, Yuu-sama! I'll never forget today!"

After exchanging hugs with Yuu, the two left the room with moist eyes but smiling faces. By then, the obstetrics nurses seemed to have reached an agreement.

As Yuu sat on the edge of the bed, the two highest-ranking women - the head nurse and a doctor - approached. Apparently, they would take turns in pairs. Both were late 40s - equivalent to or older than Yuu's mother and completely outside his usual range - but Yuu remained amiable.

"Come on, please."  
"E-excuse me."  
"Haa, haa... aaaa, the admired, H-Hirose-kun... so close... uhyu... I'm more nervous than during surgery..."

The head nurse remained relatively composed, perhaps due to several conversations with Yuu since Sayaka's hospitalization. Though unmarried, Yuu recalled her happily mentioning a high school daughter aspiring to be a nurse. In contrast, the doctor had never directly spoken with Yuu despite seeing him. Skilled but shy-looking and appearing younger than her age, she was the type who'd devoted herself to work after losing in the marriage competition despite her doctor status.

The head nurse eagerly sat to Yuu's left, while the doctor stood haa-haa-ing before him, unable to take the final step. The tall, sturdy head nurse had sharp features and spoke clearly - the capable type. The doctor was short and plump with a quiet, fast mumble that was hard to understand, though her excitement was clear. Her white coat hung open, revealing a pink blouse that emphasized her large breasts as she clasped her hands.

"Doctor."  
"Fah!?"

Yuu embraced the head nurse's shoulder with his left hand while reaching with his right to pull the doctor closer. He smelled their clean medical scents mixed with alcohol. The head nurse leaned in shyly, but the doctor trembled like a live fish on a cutting board upon contact.

"Ha, ha, fuhyiiii! Thank you! Thank you!"  
"Uh, did the doctor break?"  
"Haha... it can't be helped."

Though Yuu's first impression of the doctor was timid rather than quiet, she now seemed transformed. Unlike the experienced head nurse, this 46-year-old doctor had no male contact and was completely overwhelmed. In this world too, high-earning doctors had status in the marriage market, but not all could marry - only those blessed with looks, personality, and luck. Losers like her devoted themselves to work. Yuu kissed them both without hesitation, leaving them with lust-filled expressions.

"Hey, touch me."

At Yuu's invitation, they nodded eagerly, placing one hand on his back while timidly reaching for his crotch with the other. Yuu didn't hold back either, groping their breasts and buttocks over their uniforms. Though middle-aged, they were still women. Stimulated by Yuu's techniques, they moaned with pleasure.

Two at a time took turns sandwiching Yuu, touching each other and exchanging kisses. Each pair had exactly 5 minutes timed by stopwatch brought by waiting nurses.

"Aah... touching a real penis, and Hirose-sama's penis at that... I'm so happy... and it's so magnificent."  
"Ufufu. Such a cute face but such a fierce penis. Haa... wonderful. How is it? Does it feel good?"  
"Ah, ah! There... oh! I-It feels... good... hau!"

The five pairs of women actively used their precious 5 minutes. They showered Yuu's face and exposed skin with kisses beyond his lips. While one hand jerked him off, they groped every reachable part of his body, thoroughly enjoying the young male physique. When an aroused Yuu unbuttoned half his shirt, they buried their noses in his collar to savor his masculine scent.

Though nearly overwhelmed by pleasure, Yuu endured. Having already ejaculated once and lacking partners as skilled as Kasumi helped. Still, being serviced by rotating white-uniformed nurses felt wonderfully comfortable. He remained erect for nearly 30 minutes, precum continuously dripping.

Finally, the nursing students' turn arrived. Nursing schools - vocational schools admitting high school graduates - offered courses for licensed practical nurses (2 years) or registered nurses (3 years), with practical training emphasized from year one. Three students from Saito Municipal Nursing School were interning in obstetrics. Unlike the standard white one-piece dresses of regular nurses, their light blue uniforms were easily distinguishable.

Having interned in general female wards, they'd had no contact with Yuu. Though occasionally seen, they'd never spoken, having signed pledges not to initiate contact with males or disclose male patient information. Thus, today's ejaculation viewing felt like a bolt from the blue. They'd watched Yuu's intimate moments with senior nurses more intently than school lessons. Seeing their usually strict instructors acting so differently around Yuu was shocking yet understandable. When their long-awaited turn came, the three before Yuu already had flushed faces and fidgeting thighs - clearly aroused.

"Maybe this is our first meeting? Tell me your names."

Though still erect, Yuu's cheerful voice made the three place hands on their chests to calm racing hearts before exchanging glances. After a pause, the middle one spoke - probably slightly taller than Yuu with short hair, the most mature-looking of the three, a beautiful woman with sharp eyes and dignified features.

"I-I'm Hayakawa Taene. Second year at Saito Municipal Nursing School."

The other two followed immediately. To Yuu's left was Takada Kozue, to his right Uchima Madoka. Both had hair tied in compact buns not reaching their backs. Both were shorter than Taene, with Kozue taller than Madoka (about 155cm). Their height difference made them look like a podium. While Taene and Madoka were slender with barely noticeable breasts, Kozue's chest protruded assertively. Kozue seemed easygoing, Madoka baby-faced but strong-willed.

"I'm nearing my limit. I want all three of you to make me ejaculate."

Their reactions showed surprise, joy, and slight confusion. All three came from Saito or neighboring cities' girls' schools with little male interaction. But they couldn't hesitate before this golden opportunity. Following Taene's decisive nod, all three approached Yuu. Yet Taene found it strange how Yuu, the youngest, seemed the most mature.

Kozue and Madoka sat hesitantly on either side of Yuu. Taene was guided between his spread legs. Tall Taene felt looking down would be rude, so she bent at the waist. Then the wet, erect penis before her captivated her gaze, leaving her mouth agape. Yuu spoke to her.

"Taene... what a beautifully resonant name."  
"Th-that's... friends say it's hard to say and doesn't suit my looks..."  
"No, I think it fits you perfectly."  
"Huh?"

Yuu's only regret was that none of the nurses or students wore nurse caps he could stroke. Removing them felt wrong - nurses needed their caps. So while complimenting Taene's name, he leaned forward, lifting her chin. When their eyes met, he kissed her.

"Mufuu... nn!?"

Realizing their lips touched, Taene widened her eyes in surprise before understanding she was kissing Yuu, her eyes moistening with joy. As they kissed repeatedly with chu, chu sounds, Yuu's hands groped Taene's slender body. Gradually, sweet breaths escaped her lips.

"Hah, hah, hah, kissing... my first time... feels so good... head feels fuzzy..."

After two minutes, when their lips parted, Taene panted like a dog with a thoroughly melted expression. Smiling at her, Yuu guided her slender hand to his crotch.

"Touch me."

As Taene nodded and began touching his penis tentatively, Yuu's hands went around Kozue and Madoka's waists.

"Kozue and Madoka have such lovely names too. Come on, Kozue first."  
"Ah... yes."

Though all three were four years older than Yuu, being fellow students created familiarity. Yuu naturally used their given names, which they readily accepted - rather, being called and embraced by Yuu filled them with joy.

"Nn, nn, mufuu... ah... ann!"  
"Chu, chupaa... hafu... nn... hau!"

After encouraging Kozue and Madoka to touch his penis with one hand each, Yuu groped their bodies while kissing them. He kneaded Kozue's plump breasts through her uniform - unexpectedly thick fabric but softness still palpable. When Madoka shifted, he slipped a hand under her butt to stroke her small bottom. Feeling along her cleft through two layers of cloth, he detected dampness.

After being touched continuously by five pairs of doctors and nurses, Yuu was extremely aroused. Though keeping his voice controlled, he desperately wanted to push someone down and ejaculate through clothed sex with a nurse. But starting intercourse might shatter the thirteen women's barely maintained composure. Still, surrounded by so many angels in white, Yuu felt he could indulge a little more. Perhaps that feeling escaped his lips.

"I want to see your pussies."  
"""Eh?"""

The three students, who'd been touching his penis like interacting with a rare animal, looked at Yuu in surprise.

---

### Author's Afterword

I think nursing students are rare creatures you won't encounter unless hospitalized at a training hospital.

I once dated a nursing student long ago. She complained about many things: the difficulty of learning during training, bullying from nurses, sexual harassment from male patients... Remembering those days made me want to give nursing students here a good experience.  


### Chapter Translation Notes
- Translated "師長" as "head nurse" to accurately reflect the senior nursing position
- Translated "お掃除フェラ" as "cleanup fellatio" to explicitly describe the sexual act
- Preserved Japanese honorifics (-san for Kasumi, -sama for Yuu)
- Translated "おマンコ" as "pussies" using explicit terminology per style guidelines
- Maintained original name order (Hayakawa Taene) for Japanese characters
- Transliterated sound effects (e.g., "chu-chu" for ちゅーちゅー, "haa haa" for はぁはぁ)
- Translated "ナースキャップ" as "nurse caps" to maintain medical context
- Used "obstetrics nurses" for 産婦人科の看護師 to specify department
- Translated "看護学校" as "nursing school" for accuracy
- Rendered sexual descriptions explicitly (e.g., "groped her small bottom")