## 354. Ejaculation Viewing Session ③ ~White Gradation~

"Isn't it unfair that I'm the only one stripped naked showing my penis?"

"U-um, yes..."

"So everyone should strip too and show me your pussies."

"Is it okay to show you?"

"I absolutely want to see."

"If that's the case..."

The common sense was that no man would want to see female genitalia. They likely never anticipated a man actively requesting to see. Though Taene didn't seem fully convinced by Yuu's reasoning, she didn't hesitate. Rather, the thought of Yuu looking at her made her want to show him. Her panties were soaked through, so taking them off might actually feel refreshing. Plus, the room was heated and packed with 14 people generating intense body heat. So without a hint of shyness, Taene placed her hands on her buttons to strip completely.

"Ah, wait! Could you do it as I say?"

Taene, who'd been ready to quickly strip and expose herself before Yuu, tilted her head but seemed willing to comply with his request.

Standing directly before Yuu, close enough to touch if he reached out, Taene grasped the hem of her dress with both hands and smoothly lifted it up. Her slender figure had an attractive shape with long legs. About half the nurses wore white stockings, mostly the older ones. All three nursing students were bare-legged.

Without teasing, the hem rose past her knees, revealing her thighs—slender but with pleasing fullness. Soon the pure white lace-trimmed panties appeared before Yuu's eyes. At this proximity, he could immediately see: soaked through from the crotch upward, dark pubic hair showed through. And from squatting and standing, the crotch fabric dug in lewdly.

Seeing Yuu lean forward, eyes glued to her indecently wet panties, Taene felt both surprise and excitement inside. If she deliberately showed her underwear to a young man outside, she might get arrested as a pervert. Though not an exhibitionist, the thought of showing Yuu her genitals made her lower abdomen tingle uncontrollably.

Holding up her skirt with one hand, Taene used the other to slide her panties down. First came her pubic hair—a neatly trimmed inverted triangle. Further down, the hair grew damp. Past the thigh crease, as the crotch separated, Yuu saw transparent fluid stretching in threads from her vagina.

"Ooh... so incredibly erotic. I'm excited."  
"R-really? Nngh... somehow that makes me happy. Please look more."  
"Ah, Taene's pussy is beautiful."  
"Ahhaa..."

Spreading her legs with panties pulled down, Taene used her fingers to spread her labia wide. Yuu lowered his head to peer closely. Feeling Yuu's intense gaze, Taene shuddered with pleasure down her spine, and love juice dripped thickly.

"Me too."  
"Please look at me."

Yuu noticed his arms being pulled from both sides. Unnoticed, Kozue and Madoka had also removed their panties. Kozue wore sky blue panties matching her dress, Madoka white with floral patterns—both quickly discarded. With skirts hitched up, their faces flushed but expectant as they gazed at him. Seeing their pleading expressions, Yuu happily nodded.

"Then I'd like to see even better."

Yuu instructed Kozue and Madoka to turn toward him and sit straddling him. Meaning, they spread their legs over him. Kozue had thick, dark, bushy pubic hair covering her lower abdomen. In contrast, Madoka's was sparse enough to see her pale skin. Both were equally wet down there though. Spreading their legs wide gave a clear view of their glistening intimate parts. All three including Taene were likely virgins—their parts were clean salmon pink with small, tightly closed vaginal openings.

"Mhm. Kozue and Madoka have beautiful pussies too. I'll touch you?"  
"Y-yes... ah, aahn!"  
"Ooh! A man touching me... ah! I-it feels good... haah!"

Yuu's hands reached toward Kozue and Madoka's spread thighs, lightly touching. Starting with soft touches around their vaginal openings, but just small finger movements produced squelching sounds. Being fingered by Yuu, Kozue and Madoka let out cute moans while rubbing their faces against his shoulders.

"Jerk my cock. Let's touch each other."

When Yuu whispered this, both nodded and reached for the penis they'd released. This time Kozue lightly gripped the base while Madoka stroked the glans up and down. Yuu lightly played with both their pussies using his fingertips while facing forward.

"Um, could you let me touch too?"  
"Hmm, what should I do?"

Begged by Taene, Yuu hesitated. Truthfully, he wanted to fondle Taene too after she showed him. But with only two hands, handling three people while seated was impossible. Then he realized—since he was sitting on a bed, he could just lie down.

Yuu lay back on the bed while still seated on the edge. Though a single bed for pregnant women, it had extra width. So even lying sideways, his head barely touched. He positioned Kozue and Madoka to present their buttocks on his left and right—Kozue's large buttocks within reach on his left, Madoka's small bottom on his right, both still facing his crotch.

"Th-this is... straddling a man, putting my butt in his face... shouldn't... but..."

Though Taene seemed reluctant, her underlying excitement was visible. Pressing her wet pussy against a man's face was a female-dominant scenario only seen in fiction. Urged forward, Taene straddled Yuu but hesitated.

"It's fine. Come on. Let me lick your pussy. In return, could you suck my cock?"  
"Y-yes... ahh..."

Yuu's hands, which had been stroking Kozue and Madoka's buttocks, reached up to grab Taene's thighs. Finally resigning herself—or deciding to entrust herself to Yuu—her well-shaped buttocks descended. He could feel her legs trembling slightly as if holding in pee. As her legs spread wider, droplets fell on Yuu's neck and chest—not urine but love juice. As she drew closer, the musky female scent hit Yuu's nose. Though not yet touched, Taene's virgin vagina twitched impatiently.

Meanwhile, Kozue and Madoka weren't just touching his penis but already tasting it with their tongues. Feeling Yuu's breath on her genitals alone made Taene writhe with excitement as she joined them.

"Chu, chuuuu... chopo! Ahh, magnificent, cock, cock, urehioihi... aahn mujuru"  
"Lero, lero, lero chupaa... nmu, nmu... kufuu... ah, ann!"  
"Hau! W-wait please, hyai! Don't lick so... ah, ah, ahh! Must touch the cock... kuun! S-something's coming!"

While the three swarmed Yuu's cock, moaning while thoroughly caressing from tip to balls, Yuu became engrossed in cunnilingus. By the time Yuu's lips made contact, Taene's slit was already drenched and slippery. When he licked with his tongue, love juice overflowed like a spring. But the moment Yuu started licking, Taene jerked her hips up in surprise at the unfamiliar stimulation. So Yuu firmly grabbed her buttocks and pulled her close. Taene seemed to resign herself—or became distracted by the cock below—and now lay passive under Yuu's ministrations. The cunnilingus made it hard to focus on the cock.

With Taene immobilized, Yuu twisted his tongue deep into her vagina while extending his hands to Kozue and Madoka's buttocks. After savoring the smooth skin clinging to his palms, he lowered his fingertips. Soon reaching their thoroughly soaked labia, he turned his palms upward and used his middle fingers to spread them apart. Reaching the tips, he found small bumps and rubbed them with his fingertips.

"Hyau! St... st-top... feeling it... nnn! Nhyuu... ihii..."  
"Nfu... i-iin! Ah, ah, feels so good... uun... yaraa, first time feeling this strongly..."

As if repaying the three for their devoted service, Yuu continued passionately fondling them with tongue and hands. For them, this was their first time seeing male genitalia—and Yuu's cock was far more impressive than imagined. Just touching it, smelling it up close, and making direct contact with lips and tongue made their brains melt. Simultaneously being stimulated in their most sensitive spots by Yuu, pleasure several times more intense than self-stimulation raced through all three. Though Yuu couldn't see, Kozue and Madoka wore ecstatic expressions as they sucked, moaned muffledly, and writhed their hips.

*(Shit... dangerous, I'm gonna cum first)*

Since this was their first direct contact with male genitalia, their knowledge came mostly from AVs—they had no real technique. Still, three against one put the man at a disadvantage. With all three touching and sucking frantically, ejaculation was inevitable. Especially with Taene in a sixty-nine position, taking the glans into her mouth while licking all over, Yuu's urge to ejaculate surged rapidly. Yet his tongue and hands kept moving mechanically.

"Fua! Aaah, aaaah! I'm... cumming!"  
"Nmo... ooh! Cumming! Nn!"

Unable to hold back, Taene released the glans with a *chupon* sound just as semen spurted out.

""Wawaah!?""

Kozue and Madoka, who'd had their mouths on his balls and shaft, cried out in surprise. The spurting semen hit Taene's face directly and spilled onto Kozue and Madoka's faces and hands.

"Ahh... so much came out... amazing."  
"Lick... this is... se-men... baby-making stuff..."

Seeing a live ejaculation, Kozue and Madoka began licking the semen off their faces and hands in a daze. Only Taene kept moaning—Yuu continued cunnilingus. Taking advantage of Kozue and Madoka cleaning him with their mouths, Yuu teased her enlarged clitoris with broad tongue strokes. Each flick of Yuu's tongue made Taene's buttocks jump, but Yuu held them firmly.

"Hia! Ah, ah, ah, no more... haan! This... this... ahi! Can't take it... cumming, cumming cumming cuuung! Aaaaaaaaahhhhhhhhhhh—!"  
"Ngoooh!"

As Taene neared orgasm, she arched her upper body backward, simultaneously pressing her buttocks down hard. The pressure on his face made his tongue leave her clitoris, but instead his lips pressed against her vaginal opening as he inserted his tongue. Trembling, Taene let out a long moan as she climaxed. Her squirting drenched Yuu's entire face and even made him choke as it entered his mouth.

"Puhah... haa, haa, that felt... good..."

Tilting his head back, Yuu took a deep breath. Taene slumped forward limply but soon joined Kozue and Madoka swarming Yuu's cock. Seeing how happy they were, Yuu thought maybe he could request more participating nurses for future sperm donations. Just then—

"Hey, you three! That's enough!"  
"Haa, haa, I want..."  
"I want to suck Hirose-sama's cock too!"

Hearing voices unusually close, Yuu looked around to find the nurses surrounding him and the trio. Over half had removed their white coats or hitched up their skirts, with some even stripping their panties to expose their lower halves. The bed had been creaking—four nurses were already on the bed near Yuu's upper body. The three who'd been feverishly sucking his cock now seemed to regain their senses under the nurses' glare.

In such situations, favoring one side is unwise. After Yuu simply said "Thank you" to the three apologetically bowing their heads, they smiled in relief, expressed gratitude, and quickly moved away from Yuu.

Women in male-related professions, especially doctors and nurses at general hospitals, tend to be more rational than average women. But seeing Yuu interact with the three nursing students had nearly shattered their rationality. Many were halfway out of their white coats, apparently having masturbated. Their eyes glinted fiercely as they panted heavily. Even the head nurse, the calmest, was no exception. The only reason they didn't pounce on Yuu was perhaps residual rationality or mutual restraint due to their numbers.

Surrounded by 10 female doctors and nurses ranging from early 20s to late 40s, all behaving like female beasts eyeing prey, Yuu showed no fear. Instead, he smiled while looking around. Seeing this, the head nurse and several others felt pangs of guilt. But they were speechless at Yuu's next action—he quickly removed his shirt and T-shirt underneath, then flopped onto the bed.

"Fine. Do as you all like. Just don't fight—play nice."

Cheers erupted instantly as everyone pressed closer.

""""Aahn! Hirose-samaaa!""""  
"Skin! A man's bare skin!"  
"I want to kiss Hirose-sama again!"  
"Hirose-sama's nipples!"  
"Hirose-kun! Let me lick your asshole!"

Ten women in disheveled white coats swarmed the naked Yuu all at once. The bed creaked under their momentum. Though hoping they'd spare his butt, Yuu let them do as they pleased.

Hospitals might have doctors and nurses surrounding a supine patient in operating rooms, but this scene was utterly different. Divided roughly between upper and lower body, women immediately pressed lips against Yuu's upper body—neck, chest. One nurse even lifted his arm to smell his armpit. Though his vision was blocked, Yuu groped toward someone's crotch. Three women already swarmed his cock, while two others straddled his legs and began knee masturbation.

Though he'd ejaculated twice today and been enthusiastically sucked by the three students, the thing between his legs had already revived. Being fondled all over by this crowd of female doctors and nurses, Yuu immersed himself in supreme bliss. Ultimately, after ejaculating twice more, the head nurse came to her senses and declared the session over.

### Chapter Translation Notes
- Translated "おマンコ" as "pussies" to maintain explicit terminology while preserving colloquial tone
- Transliterated sound effects: "ぐちょぐちょ" → "soaked through", "ちゅぽん" → "*chupon*", "ぶしゅ" → "spurted"
- Preserved Japanese honorifics ("広瀬様" → "Hirose-sama")
- Used given names (Taene, Kozue, Madoka) as in original Japanese text per translation rules
- Translated internal monologues with italics: *(Shit... dangerous, I'm gonna cum first)*
- Maintained explicit anatomical terms: "penis", "vagina", "clitoris", "semen"
- Rendered sexual acts without euphemisms: "cunnilingus", "ejaculation", "fingering"