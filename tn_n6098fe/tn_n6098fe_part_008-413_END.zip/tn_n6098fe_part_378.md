## 355. Escaping the Unlucky Constitution ① ~I Want to Be Happy~

### Author's Preface

This time, the point of view changes between the first half and the second half.

---

  

"So, I went to the gynecologist... and I'm pregnant."

"Oh! Congratulations!"

"Thank you."

  

Monday, February 18th. Yuu had come to the office during lunch break after being told there was a phone call for him.

The caller was Fujiki Hiromi. 26 years old, married, no children. She was an employee of the Toyoda Sakuya Memorial Foundation and had been Yuu's point of contact since he became involved with the foundation.

Yuu found the capable and beautiful Hiromi likable, and they had slept together before. The last time was at the beginning of December.

It would be normal to assume the child was her husband's, but it seemed her husband had difficulty conceiving, and he had only one child with his three wives, including Hiromi. This was Hiromi's first child, and there was a possibility it was Yuu's. Or rather, Hiromi was convinced it was Yuu's child.

However, neither mentioned whose child it was.

  

"Hiromi-san, are you feeling unwell?"

"Actually... my morning sickness is worse than I expected."

"That's tough. Right now, your health is the most important thing. Don't push yourself."

"Y-yes! That's too kind of you."

  

Hiromi usually spoke smoothly and articulately, but today Yuu sensed from her voice that she didn't seem well.

Morning sickness varied from person to person. Yuu had observed this from the women around him.

Some became sensitive to certain smells or lost their appetite, which was manageable, but others suffered from headaches, fevers, nausea, and became bedridden.

Especially since Sayaka's morning sickness was severe during her first pregnancy, Yuu felt women had it tough.

That's why Yuu was concerned about Hiromi.

Men who showed such consideration were rare, so Hiromi was moved even over the phone.

  

"Sorry. Let me get to the main point."

"Okay."

  

The main point was a request from the Ministry of Health, Labour and Welfare for Yuu to have child-making sex with his blood relatives.

They were particularly interested in Yuu among Sakuya's surviving sons, and the sessions would also serve as research on how much he could influence the male birth rate.

Since this directly affected future population issues, the risks to fetuses born from close relatives were deliberately ignored.

  

Until last year, Yuu had been having child-making sex with his half-sisters about once every month or two, impregnating several of them.

Even for one-night stands, the pregnancy rate exceeded 50%, demonstrating the exceptional quality of Yuu's sperm.

Since the beginning of the year, he had attended the foundation's New Year's party and been with his half-sisters, but due to various circumstances, there had been no arrangements since then.

On the other hand, nine of Yuu's children had been born in February. With four of them being boys, the foundation wanted to arrange a session with a half-sister by adjusting the schedule.

  

"I'm sorry for the short notice, but would tomorrow night be alright?"

"Tomorrow!? That's sudden."

  

It was probably related to menstrual cycles. There were plenty of candidates who wanted to be with Yuu, but they were limited by location and timing.

It seemed they wanted to arrange it as soon as possible, and tomorrow was the right timing for a particular half-sister.

Yuu thought about his upcoming schedule.

He had plans to visit Sayaka, Riko, and Emi's families over the weekend, but there were no urgent plans for weekday evenings.

  

"It's fine."

"Then I'll make the arrangements right away!"

  

Hiromi's voice was lively over the phone.

She must have been instructed from above. Yuu intended to accommodate her requests as much as possible since she had taken good care of him. Yuu was also looking forward to meeting whoever it was. They say "strike while the iron is hot."

He jotted down the time, place, and other details on a memo.

  

After hanging up, Yuu glanced to his left.

It was the inside of the office counter facing the entrance, where a young office worker always sat.

Today, it was Gonda Sakiko. 21 years old. With sharp eyes, she gave a tough impression as a former delinquent.

But contrary to her appearance, she was very serious about her work.

Last June, Yuu had obtained special permission to use the Special Male-Female Interaction Room.

Sakiko had guided him then.

She was tall and slender. Not only did she have a stunning figure, but Yuu also learned she had a straightforward personality without duplicity, and they had become physically intimate.

Since then, being the youngest office worker and close in age, she was arguably the closest to him.

  

During the call, the swaying of her long, straight brown hair had been in the corner of his vision.

She must have been curious about Yuu's call.

However, she now seemed to be looking down and writing something. Her long hair hung down, hiding her profile.

Yuu slowly slid his wheeled office chair to the left.

  

"Saki!"

"Hyaa! Wh-what are you...?"

"Sorry for interrupting your work. I just wanted to be spoiled by Saki."

  

Yuu wrapped his left arm around her slender waist, rested his head on Sakiko's shoulder, and pressed close.

Being a boy, especially Yuu, he could get away with this. He knew it would be welcomed.

Indeed, Sakiko was surprised, but the moment Yuu clung to her, her mouth relaxed.

Visitors to the school office were usually more frequent in the morning, and right now, there was no one around.

Office workers could leave their seats during lunch break, but Sakiko wouldn't leave when Yuu was there. She wanted to stay by his side a little longer, taking advantage of the opportunity.

Sakiko had always been called "Saki" among her friends.

Yuu was the only man who called her "Saki." He was special to her.

  

"Mmm... Saki smells nice."

"Th-that's... nfufu..."

  

Yuu buried his face in her long hair, and his right hand played with the ends.

Unlike in high school, since starting work, she had been dyeing and caring for her hair at a salon, resulting in an even, bright brown. It could be called a vivid amber.

The floral scent was probably from her conditioner.

  

"Nnn... I guess I have no choice since it's during work."

  

Even as she said that, Sakiko looked delighted to be hugged by Yuu. She might have felt like an older sister spoiling her younger brother.

With his chin on Sakiko's shoulder, Yuu lowered his right hand to her lap.

It was cold, so she had a blanket over her legs.

He lifted it and touched her thigh. The slightly rough texture was from her stockings.

  

"Ha... fuu... nn..."

  

With Yuu clinging to her and his face so close she could feel his breath, Sakiko's cheeks flushed, and a faint sigh escaped her lips.

As Yuu tilted his head closer, he suddenly glanced down.

On the desk, he saw the paper Sakiko had been writing on.

The white paper had drawings of animals and flowers—fancy designs like those drawn by elementary or middle school students.

Below them were honest feelings written: 'Yuu-kun, your profile is cool,' 'I want to hear your voice more,' 'I like Yuu-kun.'

  

"Ah... ahh! Don't look!"

  

She must have realized he saw it. Sakiko hurriedly turned the paper over.

  

"Saki, you're so cute."

"Eh?"

  

While his hand on her thigh slipped inside her tight skirt, Yuu brought his mouth close to Sakiko's reddened ear and whispered.

  

"Saki is beautiful, her long hair is lovely, and she has long legs and a stunning figure—I'm captivated. I like Saki too, who's always so kind to me."

"Fah! Hauuuuuuu... th-that's... no... I-I'm gonna... I'm gonna cum!"

  

As Yuu's right hand, which had been stroking her inner thigh, reached her groin, and his fingertips touched her sensitive spot through her pantyhose, Sakiko trembled slightly as if holding back her urine.

Just as Yuu thought about kissing her and tried to peek at Sakiko's face, a voice came from behind.

  

"Sorry to interrupt, but lunch break is over."

"Ah!"

  

When Sakiko's supervisor in the office called out, the two hurriedly separated.

  

  

  

  

◇ ◆ ◇ ◆ ◇ ◆

  

  

  

  

My name is Gokaichi Mina, 25 years old, single.

I work for H.F.E (Houfu Entertainment), a subsidiary of Houfu, one of Japan's leading toy manufacturers, mainly handling event planning and sales promotion—just an ordinary office worker... or not.

Because since I was little, I've had extreme swings of good and bad luck.

  

My first stroke of luck was being born with my mother's beauty.

I mean, my mom is almost 50 but looks like she's in her 30s—so young and pretty. I was proud during school open houses.

  

My mom isn't married, but I was told I was born from a relationship with a man, not artificial insemination.

My biological father apparently passed away when I was in elementary school, but my mom still loves him deeply. Though she runs a small restaurant and has had a few flirtations with customers, she never dated or married anyone.

But for a long time, she wouldn't tell me who he was.

It was only about two years ago that she finally told me.

I was so shocked, it felt like the world turned upside down.

I finally understood why my mom remained devoted to him even after his death.

However, she told me not to tell anyone outside the family that he was my father, so I've kept that secret.

  

Since childhood, I've been called cheerful, carefree, and a bit airheaded.

Put another way: thoughtless, restless, clumsy, and unable to read the air. That's the kind of evaluation I got.

Financially, I've never struggled, and my life has been ordinary and reasonably smooth, but my misfortunes were mostly due to my personality.

For example, my mom has mysterious connections and used them to introduce me to young men several times.

But it always ended in rejection. Somehow, my behavior seemed to irritate them. Men are so difficult!

  

Also, while I'm blessed with friends, I occasionally get into trouble with weird people.

My friends tease me that I have an aura that attracts oddballs, but it's no joke.

  

Last summer, the biggest stroke of luck and misfortune in my life came simultaneously.

Once again, through my mom's connections, I was going to be introduced to a man.

His name was a secret until we met, but when I heard his age, I was shocked.

He was a 16-year-old high school boy! Is that okay? Since it's consensual, it's not a crime, right?

If it were 45 and 36, it wouldn't feel so strange.

But a 9-year gap between a teenager and someone in their 20s is huge. I couldn't believe it, so I double-checked with my mom, and it was true. I was over the moon.

I mean, a fresh young boy... Just imagining it made me drool.

What kind of boy would he be? The cool, handsome type? Or the fragile type you want to protect?

My head was filled with thoughts of him every day.

So, when I accidentally let it slip while drinking with a friend from junior college, it couldn't be helped, right?

But it turned out to be a mistake.

  

On my way home. I was walking in high spirits with alcohol in my system when I noticed someone following me.

Even when I walked faster, they followed!

Scared, I started running, and they chased me, shouting. Multiple women.

At the time, I didn't know why they were chasing me. As I tried to cut through a park to reach the road, I was hit by a taxi.

The women who chased me apparently stole my bag and ran off.

In the end, I broke my leg and was hospitalized, and the introduction fell through.

It took time to sort things out since my wallet and ID were in the stolen bag. For a while, I felt rock bottom.

  

Even though I went from heaven to hell, I still had to live.

Maybe my strength is that I don't drag out my depression and bounce back quickly.

If I keep living, something good will happen eventually.

  

  

  

  

......... Something good really did happen!

After some failures, I worked hard—was this a reward from God?

Around the latter half of February, after the New Year, I got a second chance to meet the boy I missed before!

My name from the previous entry was still valid. My mom asked about my menstrual cycle, and the timing was perfect.

I was glad I heard the news at home. I danced around wildly in joy, and my mom was exasperated.

I mean, a 16-year-old boy willing to meet a woman 9 years older... It must be that Hirose Yuu-kun.

Ever since I read about him in a weekly magazine, everyone at work has been talking about him—Japan's most famous boy.

Slender and cool, dignified, with a wonderful smile.

I was ecstatic to meet Yuu-kun.

This time, I won't tell anyone. I absolutely won't let this chance slip away. I vowed it.

  

However, I have one worry right now.

I'm being stalked.

  

At my company, our main job is to plan and promote events to boost sales of toys sold by our parent manufacturer.

For example, we often help at department stores or shopping malls in the Tokyo area, and even at special venues hosting anime or tokusatsu shows.

Usually, staff stay behind the scenes, but if asked, I'll work as a salesperson or guide.

Even though I'm not good at thinking hard, I try to do whatever I can.

Of course, most customers are children, and for some reason, I'm said to be good with kids.

Is it because our mental ages are close? Mind your own business!

  

Among the customers, there are parents who enjoy themselves with their children, but there are also otaku who love children's shows even as adults.

Both the kids clutching their pocket money and hesitantly buying character goods under 1000 yen and the adults who buy in bulk are important customers.

Otaku come in all types—some normal, some not—but I treated them all with a smile.

Among them, one otaku—a woman about my age who gave a creepy, ghost-like impression when I first saw her—I tried to deal with her patiently, maintaining a professional smile even though she mumbled in a hard-to-hear voice...

  

Somehow, instead of just liking me, she became obsessed.

I mean, she shows up wherever I go for work.

My work is mainly in the Tokyo area, but I sometimes travel to other regions.

You wouldn't expect someone to follow a mere staff member, right? Not even actors or voice actors in the shows.

But she was there when I worked at a resort facility in Fukushima Prefecture and when I went on a business trip to a department store in Nagoya. When I was at a sale, she would come close and stare—it was scary.

  

If she were just an enthusiastic customer, it would have been fine, but when lining up to buy goods, she deliberately handed me a letter.

Ten pages of stationery filled with her feelings for me...

In a world with few men, same-sex love is normal. I get that.

But I want to fall in love with a man! I'm troubled by a woman's passionate feelings.

  

On top of repeatedly giving me letters and presents, she started calling my company by name.

When I stopped taking her calls, she started sending FAXes daily with messages like: 'I want to see Mina, hear her voice, hold her hand, touch her hair, hug her, kiss her, see her naked. Mina is my wife, so we must make children together. I've loved you since a past life. I'll never give up.'

Her delusions were escalating, and she was so persistent it was terrifying, but since she hadn't directly harmed me, I couldn't consult the police.

When I asked around, people said she was fixated, so I should keep my distance and handle it quietly. She'll give up eventually.

  

This has been going on for about three months, and it's really getting to me.

So far, she doesn't know my home address or phone number...

But she's probably watching the company. I vary my leaving time and take detours home, so I'm exhausted every day.

  

Since February, I've been assigned fewer jobs at visible storefronts or event venues and more to warehouse work or vendor-related tasks. It's tough because it's different from before, and I feel pathetic for being slow, but it can't be helped.

Seeing her less has made me feel a bit better. The FAX attacks continue, though.

If I keep my distance, will she give up?

If not, I'm really in trouble.

  

After all, a once-in-a-lifetime stroke of luck has come. I don't want to miss it.

The day before, I stayed at a business hotel instead of going home.

From there, I would go to the meeting place.

  

  

  

  

  

  

  

  

---

### Author's Afterword

Saki in the first half appeared in Chapter 105 and became intimate with Yuu in Chapter 109. It's been a while since her appearance.

I wanted to write about workplace flirting, along with Hiromi's pregnancy.

The second half is about the woman from "(Interlude 5) The Misfortune of a Careless Woman."

In my work, unfortunate women become happy after meeting Yuu, but I had forgotten about her, arguably the most unfortunate character, and she finally gets her moment.

I hadn't even set a name for her, so I came up with one in a hurry.

Gokaichi (五ケ市) is a rare surname, but I had a friend with it in school. It's found in Hokkaido, Saitama, and Tokyo.

### Chapter Translation Notes
- Translated "悪阻" as "morning sickness" as it is the standard medical term for pregnancy-related nausea.
- Translated "事務室" as "office" in the context of the school administrative office.
- Preserved honorifics: "-san" for Hiromi and Sakiko.
- Transliterated sound effects: "ひょわぁ！" as "Hyaa!" and "んふぅ" as "nfufu".
- Translated "OL" as "office worker" to convey the meaning in English.
- Translated "オタク" as "otaku" as it is a widely recognized term.
- Translated "FAX" as "FAX" since it is a standard term, but explained the content in full.
- Translated "粗忽な女" as "careless woman" in the afterword, matching the interlude title.
- Maintained the original Japanese name order for all characters (e.g., Fujiki Hiromi, Gonda Sakiko, Gokaichi Mina).
- Used explicit terms for sexual content as per the style guide (e.g., "child-making sex", "sperm", "physically intimate").
- Italicized internal monologues (e.g., *This is concerning.*).
- For Mina's monologue, maintained first-person perspective and casual tone to reflect her character.