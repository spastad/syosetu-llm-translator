## 358. Escaping the Unlucky Constitution ④ ~Completely Naked~

### Author's Preface

Happy New Year.

Please continue supporting *Reborn in a Chastity Reversal World* this year.

  

I've added Shiranui Sumiko (不知火 珠美子) and Gokaichi Mina (五ケ市 美奈) to the character introductions, along with their first appearance chapters.

  

---

  

"Fwanmu, churlu, chu, chu, chupaa... mfhuu... aa-n, nero, lero, lero, npah... afu, kimohiii... kimohii yoou... Yuufun, mo, moree"

  

Naked and embracing, Yuu and Mina confirmed the sensation and heat of each other's skin with their entire bodies.  
Pressing their body surfaces together, their hands stroked from backs to buttocks. They warmed unconnected parts to prevent chilling.  
Moreover, with repeated kissing, their arousal naturally escalated to deep kissing.  
As their tongues actively intertwined, wet *picha picha* sounds combined with mucosal sensations to heighten excitement.  
After a long kiss, they separated with tongues still out, a string of saliva connecting their mouths.

  

Yuu and Mina gazed closely at each other. Mina's face was already that of a lust-drenched female.  
Midway, Yuu learned this was her first kiss. Between gasps, she confessed she never knew kissing could be this stimulating and heart-warming.

  

"Haa, haa... Yu, Yuu-kun?"  
"What is it, Mina-neé?"

  

Panting heavily, Mina lowered her gaze to Yuu's still-erect penis, licking back drool about to drip.  
Then she stared at Yuu with heated eyes.  
Mina's naturally large, round eyes seemed even larger now. Her dark brown irises were perfectly circular, like a cat's dilated pupils in darkness.  
Or perhaps like a female beast before prey.

  

"Hey, let's do it? I-I can't hold back!"  
"Huh?"  
"It's a bit early, but it's okay, right? Huh? Huh?"  
"Ooh!?"

  

Yuu was in a half-squat with hips raised, so when Mina pushed, he easily landed on his buttocks.  
Mina spread her legs and straddled him as if for face-to-face intercourse.  
But perhaps due to inexperience as a virgin, penetration didn't happen smoothly.  
Still, Mina pressed her lower abdomen against the erect penis.  
The soaking wetness wasn't just from the shower.

  

"I want to! I want to have sex! Lose my virginity to Yuu-kun! Huh, huh? You don't have to ejaculate yet. Just the tip, just partway. Stab through my virgin pussy with that hard, hot cock! Okay? Let me put it in! Pleeease!"

  

*Like some teenage virgin*, Yuu mentally retorted.  
Partly because Yuu had barged in naked, but Mina's aroused momentum threatened to sweep him along.  
Yuu was excited too and almost surrendered, but stopped himself at the last moment.  
For Mina, this was a long-awaited conception sex after six months of setbacks. Letting it start passively felt wrong.  
At the very least, Yuu should lead and make this an unforgettable night for her. He was used to handling women pushing for sex from experience with his sister Elena.

  

First, Yuu removed his right hand from her back to create space, extending his left to Mina's buttocks.  
Though many women were stronger than Yuu in this world, Mina appeared as fragile as she looked. She couldn't match his strength.

  

"Kyann!"

  

Grabbing her butt firmly made Mina lift her chin.  
Yuu brought his mouth to her ear.

  

"First we need to wash up. We were interrupted, right?"  
"U, uu... yes... but..."  
"Relax. I won't run or hide. You see how excited I am by your nakedness, right?"  
"Ah... now that you mention it... Yuu-kun's cock is totally different from what I saw in AV... nnn! Thinking about this magnificent cock entering me, I..."  
"Not just size. My semen's strong too. I can cum multiple times."  
"Really...?"  
"Truly. Tonight I'll fill you with semen until you're satisfied."  
"Ah, ah... haa-n!"

  

The fingers on her buttocks reached her vagina, playing with the entrance.  
Perhaps because it was soaking wet, his fingertip slipped in easily but tightened around the second knuckle.  
Her hymen seemed absent.

  

"So leave tonight to me."  
"Hah, hah... o-okay! Yuu... kun! I'll... leave it to youuu... ah... fingers... a boy's... fingers... good... good! Nnn~~~~~~n!"

  

Though Yuu intended to take brief control, Mina seemed to enjoy his fingers more than her own. Clinging tightly to Yuu, she appeared to have a light orgasm.

  

  

  

  

Since she'd already washed her upper body, Yuu sat Mina on the tub edge to wash her feet.  
Mina had heard high-end brothels offered body-washing services by men.  
But would they have handsome young men like Yuu?  
To Yuu, washing each other was natural when bathing together, but Mina showed visible gratitude.  
Glad she hadn't rushed into penetration, she extended her legs.  
Sitting sideways on a stool, Yuu lifted her right leg.  
He massaged-washed from thigh to groin with soapy hands.  
Her thighs had firm muscles beneath plump flesh.

  

"Mina-neé has beautiful legs. Play any sports?"  
"Nn... track... in middle school."  
"I see. They look soft but feel toned here."  
"I, I still... jog. With mom... nnn! T-together... afu"

  

Partly for work stamina, but continuing exercise stemmed from her mother's teaching that bodies should stay young.  
Yuu meticulously washed downward from thigh to knee to calf as if handling treasure.  
For Mina, each touch seemed to transform into pleasure.  
Though gripping the tub edge, moans escaped. Her well-shaped breasts jiggled as her upper body moved.  
Her pubic hair was neatly trimmed in an inverted triangle. With legs slightly parted, her private parts were teasingly visible.

  

Yuu glanced at Mina's alluring figure - excellent proportions, soap patches hiding key areas provocatively.  
Even focusing on washing, her sweet moans filled his ears.  
Though tempted by his own words, he suppressed desire to continue.

  

"Hyaa! Ah, hahyu! I-it tickles... ahi... whyyy... ann!"

  

Yuu cradled her lower leg on his lap, washing each toe with massaging motions.  
He knew sensitivity-increasing pressure points existed from ankle to sole.  
Though initially ticklish, rubbing brought pleasure - perhaps enhanced by this world's highly sexual women.  
By the time he finished washing her right foot, Mina looked dazed.

  

"Now I'll wash your other foot."  
"Ah... kay"

  

Mina nodded absently, surrendering her left foot.  
Then Yuu had an idea.

  

"Having your feet washed feels good, right? Then use your free hand to masturbate."  
"Ah... okay"

  

Perhaps overwhelmed by the novel sensation, Mina nodded obediently.  
Masturbating before a man would normally be called perverted.  
But since Yuu suggested it, she unhesitatingly reached between her legs.  
She climaxed while Yuu meticulously washed from thigh to toes.

  

  

  

  

"Now, how about washing my body?"  
"Wehehe... I'll wash... Yuu-kun's... bo-dy!"

  

Mina's eyes glittered as she approached, mouth open enough to drool.  
Normally a youthful-looking beauty, now she appeared as a desire-exposed desperate woman.  
But facing a rare chance to touch a young man, perhaps it was inevitable.

  

Yuu smiled wryly facing Mina.  
Kneeling, Mina soaped her hands while devouring Yuu with her eyes.

  

"Okay. I leave it to you."  
"Ehe. Ehehehe"

  

Overflowing joy kept Mina's mouth slack as she reached behind Yuu's ears.  
Her unskilled hands began washing timidly.

  

"You can press harder."  
"U, un... hey hey, Yuu-kun?"  
"Yeah?"  
"C-can I kiss you?"  
"Sure. But keep washing."  
"Un! Then now"

  

Perhaps initiating felt embarrassing.  
Blushing belatedly, Mina brought her lips close for a light kiss while diligently washing Yuu's neck.  
Her hands moved from shoulders to chest as they kissed.

  

"Ah... Yuu-kun's chest is hard. So wonderful."  
"Mina-neé has perfect proportions too. Can I touch your breasts?"  
"Un, touch them all you want!"

  

With Mina slightly taller, her swaying breasts caught Yuu's eye.  
Not huge, but perfectly sized to fill his palms.  
Yuu spread his elbows so Mina could wash easily while he gently cupped and squeezed.  
Mina washed Yuu's chest in circular motions as their lips met again.

  

"Chu, chu, chuu... afu... nn, nn! Having my breasts touched by Yuu-kun, touching Yuu-kun's chest... ann! So happy, feels good"  
"Ah, I feel good too. I could fondle Mina-neé's breasts forever."  
"Ah... Yuu-kun likes breasts?"  
"Yeah, love them. Like this?"  
"Yan! Nipples... sensitive..."

  

More mutual caressing than washing now.  
Yuu enjoyed this intimate contact more than purely sexual acts.  
As moans escaped both, Mina's hands descended to his abdomen.

  

"Whoa. Save that for later."  
"Ehh..."  
"Hands and feet first. Okay, Mina-neé?"

  

Mina regretfully eyed the erect penis but obeyed, reaching for his arm.  
Yuu placed his arm vertically between her breasts instead.  
Enjoying contact while washing was fun.  
Understanding, Mina smiled and began washing while hugging his arm.

  

Next, Mina straddled Yuu's legs facing away to wash them.  
The position felt unexpectedly good against her crotch, and with Yuu fondling her breasts from behind, Mina moaned intermittently.  
Her washing motions grew weak.  
By the time she finished both legs, she leaned back panting.  
Yuu whispered over her shoulder.

  

"Now, time to wash my di—""Leave it to me!"

  

Before Yuu finished, Mina answered immediately while grinding her buttocks.

  

"Ufufu, Mr. Penis, Mr. Penis, why are you so hard and big~♪ To please girls, of course~♪"

  

After rinsing cooled bodies and floor with hot water, they sat facing each other against the tub.  
Mina leaned her head on Yuu's shoulder and began washing from penis tip to testicles.  
Humming a twisted children's song cheerfully.

  

"How is it~? First time washing a penis, but I'm doing well, right?"  
"U... un. Good. Very good... ah, feels nice"  
"Ufu, glad~. Mr. Penis feels good~? Must clean here too"  
"Kya! T-there... hau!"

  

Mina's finger accidentally brushed his anus while massaging his scrotum.  
Though unintentional, it hit Yuu's weak spot.  
Pleased by his reaction, Mina smiled slyly and continued. One hand jerked his shaft while her fingertip teased his anus.

  

The slippery soap already heightened pleasure, but simultaneous penis and anal stimulation was overwhelming.  
Yuu's upper body shuddered, hips nearly bucking.  
He meant to endure while washing but reached his limit.

  

"Can't hold back anymore"  
"Heh?"  
"I'm putting it in"

  

Scooping bathwater to rinse his groin, Yuu lifted Mina into straddling position for face-to-face penetration.  
Exactly what Mina desired.  
She clung to him with soapy hands on his back.  
Their tightly pressed bodies shared heat, intensifying arousal.  
As they gazed, their lips met.  
Yuu lifted Mina's plump buttocks for penetration.

---

### Author's Afterword

I enjoyed writing their bath flirtation so much, I didn't reach penetration.

### Chapter Translation Notes
- Translated "ちゅるっ" as "churlu" for wet kissing sounds
- Preserved "-neé" honorific for Mina as established
- Translated "おチンポさん" as "Mr. Penis" to maintain playful tone
- Used explicit terms "penis", "vagina", "scrotum" per style rules
- Kept Japanese song rhythm in Mina's humming
- Italicized internal monologue *(Like some teenage virgin)*