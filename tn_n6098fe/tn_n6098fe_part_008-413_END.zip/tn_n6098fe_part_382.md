## 359. Escaping the Unlucky Constitution ⑤ ~Rather a Serenade~

"Ha, ha, haheee... amazing... your penis... is deep inside me, all the way to the back..."

"Ah... I thought I'd cum already, Mina-nee's vagina feels incredibly good."

"Ehe, ehehe... really? I'm happy. Haaaaaa... I'm connected with Yuu-kun. It's like a dream."

Though the vibrator had broken her hymen, penetrating Mina's vagina was still difficult since she was a virgin. In the face-to-face position, Yuu thought Mina's own weight would allow smooth entry, but it stopped midway. After taking time, Yuu finally inserted fully but stayed still while embracing her, fearing movement would make him ejaculate. 

What concerned him most was defloration pain. Mina only winced during insertion, fortunately with no lasting pain.

"This isn't a dream. See?"  
"Kyahn! W-wait... ah, ah, what's... this... such... waaah!"

As Yuu slowly thrust upward while embracing her, Mina's moans echoed in the shower. Her vagina hadn't fully accommodated his penis yet - too tight for much movement - which actually suited him now.

"Look down. See how we're connected?"  
"A, ah, I see... it... ahhn! We're connected..."

When they slightly separated their upper bodies to look down, though they couldn't see the genitals directly, their lower abdomens were pressed together. Pubic hair tangled in sweat and vaginal fluids looked obscenely wet.

"Mina-nee, how is it? Feeling good now?"  
"Yahn, I've been feeling good... for a while now! Yuu-kun's... penis... going deep... nnah! Aah! Aah! Thrusting... haahn! Completely different from... a vibrator... having sex with Yuu-kun is... so amazing..."

At a slow "zun zun" pace, the penis reliably hit her vaginal depths. Mina's well-shaped breasts shook, her nipples rubbing against Yuu's chest seeming pleasurable. Surprisingly quick to adapt for a virgin, she moaned dramatically with each thrust.

Though Yuu had been erect since bursting into the bath, the prolonged foreplay made the pleasure of penetrating a virgin vagina overwhelming. Even without fast movement, the vaginal tightness and friction intensified his urge to ejaculate. He knew he wouldn't last long but felt no rush - he intended to creampie her repeatedly tonight.

"Sorry, Mina-nee... I'm close."  
"Hah hah, hah... ahn! It's okay..."

"M-Mina-nee?"  
"Chu-"  
"Mmph"

As Yuu spoke, Mina sealed his lips with a wet kiss. Having been panting open-mouthed, she now aggressively shoved her tongue in. Yuu actively tangled tongues with her equally forceful kiss.

"Foh... mm... churu, chupa... afuu... waa, uun! Yuu-fuun... amazing... ahn! Nchu... reroreroo"  
"Mph... ugh, ah, ah, Mina, neeeee"

Despite just losing her virginity, Mina seemed thoroughly aroused. While pleased, Yuu felt he'd reach his limit before her orgasm. With both mouths connected, he intensified his thrusts. *Tan tan tan* flesh impacts mixed with *zuchu zuchu* sticky sounds from their junction as Mina's moans heightened.

"Nguu... I-I'm cumming!"  
"Ngaah! Aah! Aah! Wai... stop... amazing... kuryu! A, a, ahii!"  
"Ugh... kwaah!"  
"Yu, Yuu-k... ahh... ahe... niiiiiiiiiiiiih!"

Yuu ejaculated with an overwhelming release that felt like his lower body was being taken away. Being his first orgasm, the ejaculation lasted long - he surely flooded Mina's womb with substantial semen. Mina clung tightly until feeling the hot spurts inside, then threw her head back gazing at the ceiling. Yuu sensed she'd orgasmed from receiving his semen.

***

"Mina-nee? Mina-nee, hey... Mii-na!"  
"Kyafun!"

Post-orgasm Mina remained motionless against Yuu's shoulder - immobilized by climax aftermath. When Yuu flexed his lower body, his still-hard penis inside her released residual semen with a *pyuru* sound.

"Really, Yuu-kun!"  
"Did it feel good?"

Mina beamed at his question.  
"Of course! When I came at the end, my mind went completely white... never felt that before."  
"Good, you came from my penis."  
"Kufu~ Yuu-kun, you're too wonderful, anmou, I love love you!"

Mina showered him with *chu chu* kisses. Even after dozens of women, Yuu felt supreme joy when virgins delighted in him and fell deeper in love. He noticed her tied-up hair had partially come undone, the cold ends touching his shoulder. While their connected bodies burned hot, their backs cooled rapidly - risking colds.

"Mina-nee, should we soak in the bath?"  
"Aahn. Reluctant but... you want to separate?"  
"No, not that. How about entering together like this?"

Yuu meant entering the tub still connected. Though it wouldn't increase pregnancy chances, Mina happily agreed, not wanting separation. Her small frame helped as Yuu lifted her while connected, sitting on the tub edge before slowly entering in "ekiben position."

"Ufuh, so happy..."  
"Ah, entering together like this is warm and comfortable..."

Mina clung dreamily, nuzzling Yuu's neck and shoulder. His penis remained hard despite ejaculation - her freshly deflowered vagina felt irresistible. Without thrusting, they simply enjoyed the intimate connection.

Suddenly Mina lifted her face and captured Yuu's lips. He reciprocated while holding her. Kissing repeatedly with changing angles, their tongues tangled as *chapun chapun* water splashes mixed with *picha picha* saliva sounds.

"Nnfuu... the pleasure keeps going... my head feels woozy..."  
"Um, could you be getting lightheaded?"  
"Fuhee...?"

Mina's face had turned apple-red beyond pink. Bathing post-sex while continuously kissing and excited likely caused this. After about 15 minutes soaking, Yuu decided to exit.

They had to separate when leaving the bath. On the washing area, when Yuu pulled out, sticky semen *dorori* dripped out.

"Aahn, it came out..."  
"Right now, my sperm are swimming toward your egg around here, aren't they?"  
"Right! Ufufu. Do your best, sperm-chan! Reach my egg and fertilize it to get me pregnant!"

Though pregnancy rarely happens from one session, Yuu had impregnated women before. Since Mina was likely in her fertile period, he resolved to creampie her repeatedly.

After drying off, they wrapped in bath towels. While waiting for Mina to dry her long hair, Yuu drank from the fridge - thirsty from the long bath and anticipating more activity. Mina clung constantly except when blow-drying - like an affectionate puppy.

"Hey hey, let me suck your penis. I want to remember Yuu-kun's penis well."  
"Hmm... if that's what you want."

After discarding towels and kissing naked in bed, Yuu agreed to his cute half-sister's request. Though ready for penetration, he wanted to fulfill her wish.

Kneeling beside Yuu lying spread-eagle, Mina bowed toward his erect penis. She brought her face close, *sniff sniffing* the base. Though freshly washed, precum had dripped from their cuddling - which she seemed to smell.

"Fu, fuhe... already hard again after ejaculating. Ahaa, good boy, penis. Okay then"

Eyes drooping lewdly, Mina lifted his penis with her right hand on balls and left on shaft. She opened wide enough to swallow it, *pak* taking the base into her mouth.

"Muuuuu... really biiig"  
"Ah... Mina-nee, you're unexpectedly skilled."  
"Mufu. I practiced hard."  
"I-I see, ooh..."

After licking from root to glans, Mina suctioned the head. Not deepthroating, she used lips and tongue simultaneously while right hand gently massaged balls and left hand stroked the shaft.

Yuu watched sideways through half-closed eyes. He enjoyed seeing her push aside dangling hair while sucking - a favorite gesture.

"Mufuu, delicious, Yuu-fun penis, delicious... amu, juru, juruchupaa... love your penis... want more licking"  
"Ugh... kuu..."

More than service, Mina worshipped his penis with desperate desire - like a virgin man performing cunnilingus with stored knowledge. Rubbing her cheek against it and kissing repeatedly, she resembled a cat intoxicated by catnip. The pleasure built dangerously.

"Mina-nee, soon..."  
"Nn-mu, amu... jupa, juru"  
"Fuhe?"

When Yuu touched her shoulder, Mina finally noticed.  
"Time to enter you."  
"Eh? Oh... right. Sorry."

Seemingly the type to lose awareness when engrossed, she remembered penetration was the goal. Apologizing with saliva-glistened lips, she bowed.

"It's fine. I almost came - it felt that good. But I want to cum inside you this time."  
"Ah... was I making you feel good? I got too carried away..."

Yuu found her belated concern amusing and hugged her gently.  
"Now I'll make Mina-nee feel good. Probably in ways you don't know."

Saying this, Yuu pushed Mina down.

---

### Author's Afterword

The "Escaping the Unlucky Constitution" (Mina) arc has one more chapter. Next is the last.

### Chapter Translation Notes
- Translated "チンポ" as "penis" per explicit terminology requirement
- Preserved "-nee" honorific in "Mina-nee"
- Transliterated sound effects: "ぐちょぐちょ" → "gucho gucho", "ぴゅる" → "pyuru"
- Translated "膣内" as "vagina" with contextual clarification ("inside her vagina")
- Maintained Japanese name order: "Gokaichi Mina" remains as is
- Rendered internal thoughts in italics: e.g., "*(This isn't a dream.)*"
- Translated sexual acts without euphemisms: "中出し" → "creampie"