## 360. Escaping the Unlucky Constitution ⑥ ~Don't Give Up on Your Dream~

"Aah, aah, ahhi! Iiinn! Uwaa... so intense... aah! Amazing, so amazing! I'm... gonna cum! Yuu-kunn!"

"Good. Cum without holding back, cum! There!"

On the bed. Yuu knelt behind Mina-neé who was on all fours, thrusting rhythmically while firmly gripping her large peach-shaped buttocks with both hands.

Since he had already taken her virginity and Mina-neé's pussy was in a welcoming state, he pounded vigorously from the start.

Truly beast-like intense sex.

With each thrust of Yuu's hips, bachun, bachun! The sound echoed as his lower abdomen slapped against her buttocks.

Love juices overflowed with each insertion and removal of Yuu's thick cock, trickling down her thighs and soaking the sheets.

Even for Mina-neé who had consumed above-average adult content, this position was unfamiliar.

Though once penetrated by a cock, it didn't matter.

Mina-neé's freshly deflowered vagina was unilaterally assaulted and developed.

This was because Mina-neé herself had unconditionally surrendered to Yuu's cock, delighting in being dominated.

Each time Yuu slammed his hips, Mina-neé's breasts shook violently, burun, burun!

As she gripped the sheets tightly, her long hair wildly disheveled whenever she lifted her chin or shook her head.

Yuu leaned forward, pushing his cock deep into her vaginal depths while reaching out to grab a breast with his right hand.

As if triggered by this, Mina-neé's body jerked violently.

"Ahhyeeeeee... I'm cummiing... uunnh! Fuhi... cumming, I'm cumming aaah..."

Having reached climax in less than five minutes of doggy style, Mina-neé dropped her head down.

But Yuu paid no mind, continuing to thrust while kneading her breasts.

"Heh... wait... I'm cumming, still cumming... au au"

Despite being mid-orgasm, the relentless assault left Mina-neé unable to support herself with her arms, elbows buckling.

Her posture resembled a yoga position with raised hips.

Seizing the opportunity, Yuu supported Mina-neé's lower abdomen with his left hand while adding his weight.

After telling Mina-neé to lie face down, he covered her back - the prone bone position.

"Mina-neé, am I too heavy?"

"Ufuu... not... heavy at all. Feeling Yuu-kun's warmth makes me happyyyy... ah, ah, again... moving"

"We're just getting started"

"Hyaa! A, ahi, no... I'll cum againnnnn!"

Planning to make Mina-neé climax repeatedly tonight, Yuu smiled as he combed her wildly disheveled hair spread across her back, whispering over her shoulder.

"We'll keep going. Be prepared"

"Haan! Already... can't even think straight anymore"

"That's fine. I intend to make Mina-neé feel so good she loses herself. There!"

Yuu thrust his hips at shorter intervals than before - not just simple pistoning, but deep drilling motions that made her buttocks deform.

Mina-neé hugged a pillow face-down, only emitting intermittent meaningless moans.

After 5-6 minutes, until Yuu poured his seed deep inside her, she experienced two more climaxes.

***

Yuu rested on Mina-neé's back for a while after ejaculating, savoring the afterglow.

But concerned about burdening her, when Yuu got up, Mina-neé remained face-down without moving.

Though slightly worried, the truth was she couldn't move even if she wanted to.

After pulling out his cock, Yuu rolled Mina-neé onto her back and wiped the semen leaking from her vagina.

Taking a break, Yuu fetched cold drinks from the fridge, but Mina-neé still lay sprawled.

It was past midnight. She must have been exhausted.

When Yuu sat on the bed edge and called out, Mina-neé rolled over and rested her head on his lap.

As Yuu stroked the cheeks and hair of Mina-neé who faced his now-calm cock, she narrowed her eyes with a blissful expression - almost like a cat about to purr.

"Come on Mina-neé, wake up and hydrate"  
"Unyu~n"

Mina-neé began nuzzling her cheek against the softened cock.

If she kept that up, it would harden again and he'd want to continue.

Yuu didn't mind, but wanted her to hydrate to prevent dehydration.

"I'll feed you mouth-to-mouth"  
"Haaai"

Slipping his left arm under her armpit to lift her, Mina-neé leaned against Yuu and opened her mouth.

Yuu took a sip of Pocari Sweat-like canned drink and fed it to her mouth-to-mouth. This repeated three times.

"Ahh, I'm so happy... I wish this time could last forever"

Mina-neé murmured while rubbing her cheek against Yuu's shoulder.

Being able to touch a young man's body without reservation.

Having sweet words whispered while being kissed relentlessly.

His hands caressing her entire body felt tremulously pleasurable.

Normal men would finish quickly, but with Yuu it was unbelievably intense - maintaining connection heightened pleasure toward climax.

The ecstasy while connected to Yuu was leagues beyond masturbation, making it hard to maintain consciousness.

Completely different from any male-female intercourse she'd known - truly felt like divine skill.

Rather than recovering from past misfortunes, it felt like 100-fold luck had returned. For her, tonight was undoubtedly the best night of her life.

Two rounds of sex exhausted even the relatively sturdy Mina-neé. Left alone, she might have departed to dreamland.

But falling asleep felt wasteful.

She wanted to cling to Yuu like this, feeling his body warmth.

"Mina-neé?"  
"What?"

When Mina-neé looked up, Yuu gazed back with tender eyes and called her name.

That alone wrapped Mina-neé's heart in happiness.

"It's not over yet"

"Huh..."

Yuu took Mina-neé's hand and guided it to his crotch.

His cock, once calmed, was already half-erect just from their naked bodies touching and fondling each other's heads, chests, and thighs.

"Shall we continue? Or are you too tired, Mina-neé?"

"Fa... unbelievable"  
"Don't want to?"

Staring down at the cock hardening with each touch, Mina-neé wore an astonished expression.

When Yuu declared in the bathroom earlier, she doubted it. During the second round, she was too excited to think.

In Mina-neé's knowledge, one ejaculation per night was normal. Young boys might manage two with breaks. She'd never heard of any man doing more.

Responding to Yuu's call, Mina-neé hugged him tightly as if declaring her answer.

"I want to! I want more with Yuu-kun!"  
"Fufu. That's more like it. What position this time?"  
"What... I know! Since Yuu-kun worked hard before, let me move this time"

Though nine years older, Mina-neé's sexual experience differed like a baby learning to walk versus an adult.

Yuu nodded with a teacher-like smile watching his pupil.

"Like this?"  
"Yeah. But don't insert it yet"  
"Huh?"  
"After sandwiching the cock between your thighs, slowly rub back and forth"  
"U, un"

Mounted on Yuu's hips as he lay supine, Mina-neé seemed ready to insert immediately, but Yuu stopped her.

Following Yuu's words, she sandwiched his erect cock shaft along her lower abdomen with her vulva - so-called sumata.

Hands on Yuu's chest, she gradually rocked her hips back and forth.

"Haa, haa, haa... nn, nku... good, this too... feels good. The hardness... rubbing... feels like my pussy and your cock are kissing chu chu"

After several back-and-forth motions, love juices overflowed, making zuchu, zuchu sounds. The genital contact area seemed slicker now.

With a dazed face, Mina-neé slowly leaned her upper body forward to kiss Yuu.

"Hey? Still can't insert?"  
"Not yet. Keep going a bit longer"  
"Aaan!"

Yuu gripped Mina-neé's buttocks with both hands, moving them in sync with her motions.

Her nipple tips poking his chest felt pleasant with each movement.

As Mina-neé panted with tongue out approaching his face, Yuu met her with his own tongue.

"Umufuu... chupa chupa, lero lero... fann! Good... your cock feels so good... can't, can't stop ooh"

Mina-neé's hip speed increased, the wet sounds turning into sticky nuchu, nuchu.

Mouth half-open, Mina-neé leaked sweet moans by Yuu's ear while mindlessly rocking her hips.

"When you feel close and can't hold back, you can insert it"  
"A, aii... i, i, iin!"

Strength filled Mina-neé's hands clasped behind Yuu's head.

As pleasure intensified toward her limit, her movements grew larger.

She rubbed from glans to base, gunyugunyu, occasionally hitting the tip against her vaginal entrance.

"A, ahi"  
"Ooh!"

When Mina-neé pulled back after rubbing to the tip, the glans plunged zuburi into her vaginal opening.

"Hah... hai... kufuuuun! Fi, oh..."

If she pulled back like before, the thick meat rod would sink zubuzubu into her vagina.

Speechless, Mina-neé panted heavily with tongue hanging dog-like. Drool dripped from her open mouth onto Yuu's cheek.

"I, i, ihhya... taa..."

The moment the cock reached deep inside, Mina-neé climaxed and collapsed patari onto Yuu's chest.

"Felt good?"  
"Ufuun... so, so good. Everything went bright white before my eyes"  
"But I'm still going. Come on, try harder"  
"Hyann!"

Yuu thrust his hips upward.

True to her word, Mina-neé lifted her upper body slightly, hugged Yuu's head while kissing, and began wriggling her hips.

Perhaps the sumata served as practice. Smooth movements for someone who just lost her virginity.

"Faa! O, oh cock-shan, cock-shan, I love you... nku... my pussy's delighted! Uwa... a, again... gonna cum ooh!"

Since insertion, rather than ups and downs, she seemed constantly near peak pleasure.

"Did my cock teach Mina-neé's pussy to get addicted to cumming?"

Mina-neé could only pant incoherently, nodding repeatedly.

Her long hair fell wildly fasafasa onto Yuu's face.

Combing her hair, Yuu watched Mina-neé desperately rock her hips toward climax.

Screaming, Mina-neé collapsed again, unable to move immediately. After a while, Yuu lifted her upper body while holding her.

Once sitting and hugging while exchanging kisses, Yuu pushed her down and mounted her.

Yuu too was near his limit but endured until Mina-neé came first.

Now supine, Mina-neé seemed absent-minded, but when Yuu reached out, she tightly grasped his hands - a lovers' handhold.

Thus Yuu began thrusting his hips to make his third creampie inside Mina-neé.

***

Somehow he must have fallen asleep.

Yuu awoke hugging Mina-neé sideways, face buried in her chest.

Feeling urinary urgency and hunger, Yuu checked the digital clock on the headboard - past 8 AM.

After kissing Mina-neé's cheek as she mumbled adorably in her sleep, he slowly got up and used the toilet.

30 minutes later, room service breakfast arrived.

Though still bleary-eyed, Mina-neé seemed to wake up instantly upon seeing freshly baked bread.

They faced each other at the table like during dinner.

Both wore provided white gowns, but their eyes wandered to each other's exposed chests while eating.

After heartily eating and downing a glass of milk, Yuu spoke to Mina-neé still eating.

"Suddenly, but will Mina-neé continue her current job?"  
"Omu!? Nn... gokun. Uh, job?"

Mina-neé tilted her head after washing down remaining croissant with orange juice.

Immersed in happiness facing Yuu at breakfast, she'd forgotten her situation.

Last night she was attacked by a stalker in the restroom.

Had this been a man attacked, it would be a serious crime even without completion.

But with both perpetrator and victim female, it was ambiguous. Without serious injury, she might get suspended sentence if no prior record.

Harsh reality for stalking victims.

"Don't know what'll happen to the perpetrator, but they say stalkers don't give up easily. Isn't it dangerous continuing the same job?"  
"A, aah! D-don't say that..."

Awakened to reality, Mina-neé clearly panicked - likely recalling yesterday's terror.

In his past life, Yuu knew several murder and assault cases by stalkers.

Luckily he encountered it with protection officers last night.

He wanted to avoid worst-case scenarios where Mina-neé lost her life or got injured.

Though only seeing the perpetrator briefly, he doubted easy reform based on Mina-neé's account.

Moving or changing jobs was one solution, but normally difficult.

"Hey"  
"What?"  
"Shall I ask the foundation who arranged this meeting?"  
"Eh... really?"

Yuu was just a... though too famous, high school student.

But no ordinary high schooler.

"If I ask, they might arrange a job transfer. You have nursery qualifications too"  
"Yeah... that'd help. But why go so far for someone you just met?"

Meeting Yuu and spending the night together.

Mina-neé felt she'd received more than enough happiness.

Beyond that, having him care about her future felt unbelievable.

"Well, though we never met, Mina-neé is my sister. More importantly, tonight might have gotten you pregnant with my child, right? Can't recklessly expose you to danger"  
"Ah..."

Mina-neé gently touched her abdomen.

Last night she received massive creampies three times.

Not determined by quantity, but at 25, losing virginity might bring pregnancy.

"Can't guarantee, but I'll ask"  
"Ah, thank you. For everything... truly thank you. Since yesterday... Yuu-kun is my lifelong benefactor"

Tears welling, Mina-neé bowed her head.

"No no, outcome's uncertain. More importantly, this delicious bread - eat more"  
"U, un"  
"After eating..."

After checking the clock, Yuu grinned.

Though school awaited, he decided to skip morning classes.

"Shall we bathe together?"

Mina-neé had no option to refuse.

This time bathing together, they washed each other while flirting, but ultimately united in face-to-face seated position.

Yuu made Mina-neé climax several times before creampieing her.

***

The next day, the 28th, Mina-neé reported the incident at work and requested transfer.

But since nothing serious happened, the company didn't understand. Reluctantly, Mina-neé moved from Saitama to Chiba.

March passed uneventfully. During discussions with the foundation contacted by Yuu, she considered career change but timing was bad, entering April.

When Golden Week came, increased events forced Mina-neé back to promotion work. But at one event venue, the stalker reappeared.

Having received suspended sentence, he'd lain low but began stalking Mina-neé again.

Panicked, Mina-neé realized she was pregnant.

She couldn't risk harming the precious life she'd conceived, so quit immediately.

Though part-time, she began studying to restart as nursery worker while working at foundation's Osaka branch.

Two years after meeting Yuu. While raising a young child, Mina-neé achieved her dream of becoming nursery worker.

At a special daycare gathering Yuu's children.

***

### Author's Afterword

Mina exits here.

For a character conceived suddenly, I grew attached while writing.

I'd like to write a side story (epilogue) after the main story concludes - something like Mina's childcare struggles. Not confirmed, just an idea.  


### Chapter Translation Notes
- Translated "素股" as "sumata" (thigh sex) preserving the Japanese term as culturally specific sexual act
- Rendered explicit anatomical terms directly ("pussy," "cock," "creampie")
- Preserved honorific "-neé" for Mina throughout
- Transliterated sound effects: "bachun" (slapping), "burun" (breast shaking), "zuchu" (wet sounds)
- Translated "おマンコ" as "pussy" and "チンポ" as "cock" per explicit terminology rule
- Maintained Japanese name order "Gokaichi Mina" as established in Fixed Characters
- Italicized internal monologue *(This is concerning.)* per style rules
- Translated "Toyoda Sakuya Memorial Foundation" consistently with Fixed Terms reference
- Formatted simultaneous dialogue with double quotes ""..."" when characters speak/react together