## 361. What We Can Do Now ~For the Children Yet to Be Born~

"This month alone, 9 children. And 4 of them are boys! When I heard it, I thought it was a lie, and even now I can hardly believe it... but it's true, isn't it?"  

"Yeah. I couldn't hold all of them at once, but I held each one in my arms. Babies are so cute, aren't they?"  

"My... Yū, you're so young yet you love children?"  

"Well, they're born into this world carrying my blood. Of course they're precious. How's your stomach condition, Satsuki-nee?"  

"I've entered the stable period, perfect! I've given birth once before, so no problems~"  

After checking out of the hotel at 10 AM, Yuu headed straight to school.  

There was a student council gathering after school, and after returning home, he immediately cooked dinner and ate with his family.  

Now relaxing in his room, he called the foundation headquarters and was talking on the phone with his half-sister Satsuki.  

First, the topic was the children Yuu had fathered.  

Since Sayaka, Riko, and Emi safely gave birth, reports had been periodically made to the foundation.  

Not only was the number of 9 children in one month remarkable, but including 4 boys was earth-shattering enough to shake the foundation. Though Toyoda Haruka, the representative director, immediately tightened discipline.  

This fact would be conveyed to the cooperating government and Ministry of Health, Labour and Welfare, but not disclosed to the media.  

The foundation already received numerous inquiries targeting Yuu.  

Interviews from magazines and TV, appearance requests for video media. Modeling and image character requests from various companies and public institutions. Even local governments nationwide expressing welcome - these increased after word spread in January about Yuu staying at a hotel in Akita City. From ordinary people to celebrities wanting to meet Yuu, and so on.  

Initially, Sairei Academy also handled inquiries, but unable to cope, the foundation took over entirely.  

However, while Yuu is a high school student, they basically reject requests. The rare exception was the CM collaboration with Wish - though Yuu's identity wasn't revealed.  

After Yuu got involved with the foundation, Satsuki and Fujiki Hiromi became the contact persons, but hearing it was too much for just two people, staffing was greatly increased and a dedicated team for Yuu was formed.  

Satsuki served as its leader, but she too was pregnant with Yuu's child.  

Her belly was already quite large, and if all went well, she should give birth in May.  

"Speaking of which, Satsuki-nee has a daughter, right? Umm, she's in middle school now?"  

"That's right... When she was little, she'd follow me everywhere saying 'Mama, Mama', but now she's at that cheeky age and hardly talks to me. Mama is sad."  

"But she must be a beauty like Satsuki-nee. I'd like to meet her once."  

"Oh my, actually... my daughter has been asking me to let her meet you."  

"Then!"  

"It's hard to mix public and private so openly. Maybe at a foundation event or when this child is born."  

"Got it. I'll look forward to it."  

Among Sakuya's children, Satsuki was the oldest and first to get pregnant, having her child at 15 or 16.  

Listening to Satsuki's drawn-out sensual voice, Yuu imagined the fantasy of a mother-daughter threesome with the beautiful pair, but then remembered the main topic.  

"I wanted to confirm - do the women who gave birth to my children become foundation members?"  

"Of course."  

"Without exception, whether married or not, if they bear a child?"  

"Yes. You intend to acknowledge paternity, right?"  

"Naturally."  

"Then it's fine."  

Originally, to avoid chaos after Sakuya's death, wives, lovers, and children collectively evacuated to a hot spring resort facility in Hakone, and a mutual aid group started for future cooperation - the predecessor of the Toyoda Sakuya Memorial Foundation.  

After establishment, many women claiming relations with Sakuya or raising Sakuya's children came forward, making authenticity verification difficult.  

Police adopted DNA analysis for criminal identification from the late 1980s. Even in 1991, it hadn't reached general parent-child testing availability.  

Within Japan was one thing, but cases kept occurring where those who went overseas were later confirmed through Sakuya's handwritten letters or testimony.  

Starting with under 100 members - initially called the Sakuya-kai - now with Sakuya's children having their own children, the scale grew, taking the form of a foundation.  

Women who had relations with Sakuya occupying key positions in various organizations also helped enable cooperation with government and companies.  

Foundation funds originated from Sakuya's estate, but wealthy women donating to repay Sakuya was also significant.  

Anyway, when a direct male descendant like Yuu fathers a child, the woman and child automatically become members. Membership increases yearly.  

Becoming a member doesn't incur obligations like fees, but connections form as part of Toyoda Sakuya's clan.  

Supporting isolated mothers and children so they don't fall into hardship is also the foundation's role.  

Even in cases like Kuroda Noriko who became pregnant and gave birth after a single encounter with Yuu, confirming they could connect through the foundation was meaningful.  

Relieved by Satsuki's answer, Yuu changed the subject.  

"Does the foundation manage childcare facilities?"  

"Childcare facilities... wait a moment."  

Satsuki fell silent at Yuu's question.  

After a while, she asked someone nearby.  

About 5 minutes later, paper rustling could be heard. Probably checking related materials.  

"We don't directly manage any, but we invest in one school corporation running a nursery school in Tokyo."  

"Just one?"  

"Yes. The foundation focuses most on co-ed high schools for education."  

"I see."  

During his lifetime, Sakuya actively promoted mutual understanding between genders and gender interaction in education.  

So the foundation operates based on Sakuya's will.  

However, no matter how large the scale, they couldn't influence all educational stages. Mainly focusing on co-ed high schools like Sairei Academy.  

According to Satsuki, when they were young, they lived like a large family in an old but big mansion without attending childcare facilities. Especially considering the danger of sending boys out, Sakuya's women took turns caring for them.  

But as children increased, space became tight, so Sakuya gathered sponsors and collaborators to establish a small nursery.  

That became the predecessor of the school corporation the foundation invested in.  

"Saitama... preferably Saito City - I thought about asking to build a new nursery there."  

"Hmm... Essentially, you want to gather your children, right? Especially with many boys."  

"Exactly."  

Satsuki seemed to immediately grasp Yuu's idea.  

Many women who bore Yuu's children were students. More would likely come at Sairei Academy.  

As students living with families, they could expect support, which was reassuring.  

But there were cases like Mio and Shiho working as nurses, and women starting jobs would emerge.  

Sairei Academy had infant care rooms, and universities/companies had childcare facilities - parenting support was incomparable to Yuu's previous world.  

Still, seeing Martina, Yuu knew mothers with boys struggled in this world.  

He thought it would be good to have accessible childcare facilities where they could entrust children with peace of mind.  

As a father of many children, Yuu wanted to help however he could.  

"Well... Personally, I'd like to help you, Yuu."  

"Whoa! As expected of my favorite big sister! You understand."  

"Geez..."  

When Yuu spoke in an excited voice, Satsuki on the other end seemed embarrassed.  

That said, immediate decisions were impossible.  

Being an organization, it required board approval.  

Yuu understood that much.  

For today, just gaining Satsuki's understanding was enough.  

But Yuu got carried away.  

"Speaking of childcare facilities..."  

Even Yuu, who had no children, knew things.  

Common knowledge about childcare changes significantly in 20-30 years.  

Like eating habits or allergies.  

By the time newborns grew up, former common sense could become nonsense.  

But Yuu wasn't an experienced parent nor had professional knowledge. Only secondhand knowledge.  

So he proposed that if building new facilities, they should reflect the latest childcare knowledge, not bound by old ways.  

"Eh... why does Yuu even know such things?"  

"Well, that's because I studied various things to become a father."  

"Even so, it's rare for ordinary boys to care so much about their born children."  

Yuu hadn't made specific proposals, but boys mentioning childcare facility policies were unheard of. Satsuki's suspicion was natural.  

"Even if just once, I cherish every woman I've been with. Especially those who bore my children. Of course that includes you, Satsuki-nee. More than a blood-related sister, you've become indispensable to me."  

"My... oh, that... th-thank you... I'm happy."  

Usually showing sisterly composure, Satsuki seemed genuinely moved by such direct words.  

"At this age, I'm happy to carry Yuu's child. Probably a girl, but maybe a boy? Either way, I'm looking forward to it~"  

"Then, take it easy with work and deliver a healthy baby."  

"I know!"  

Satisfied with Satsuki's answer about cooperating with experts for childcare facilities, Yuu ended the call, considerate of her pregnancy.  

He realized they'd talked for about an hour.  

Right after hanging up, the door knocked.  

When Yuu responded, his sister Elena opened the door.  

"Yuu, the bath is free."  

"Got it. I'll go soon."  

Yuu tried to leave the room holding the cordless phone, but Elena blocked his way.  

Fresh from the bath, her long hair wrapped in a towel. Perhaps feeling hot, she wore only a T-shirt - braless with visible nipples.  

Elena hugged Yuu head-on, rubbing her body against him.  

As if trying to smear her post-bath scent on Yuu.  

"Sorry to Mom, but I'm looking forward to tomorrow night♪"  

"Honestly..."  

This month Elena took entrance exams for prestigious Tokyo universities, and results arrived this Monday - she passed her desired university.  

Despite a nearly six-month gap, Elena - a severe brother-complex - channeled her focus into studying, rapidly improving from fall to winter.  

Not Tokyo University level, but she passed a top-tier university.  

As celebration, tomorrow night would lift the ban on baby-making sex.  

Elena seemed unable to contain her excitement.  

"Well then, I'll sleep with Mom tonight. Good night, sis."  

"Ufufu. Good night, Yuu."  

Hugging, Yuu and Elena kissed.  

Exchanging a passionate kiss beyond mere greeting, Elena reluctantly returned to her room.  

After bathing and preparing for bed, Yuu headed to Martina's bedroom.  

Entering, she wore a maternity one-piece pajama, checking belongings with a list.  

"Mom, aren't you already prepared?"  

"Oh, Yuu-chan. It's been so long... I'm worried about forgetting things."  

Martina took leave after handing over work in February.  

Her due date was mid-March, but she often complained of painful abdominal tightening.  

Though youthful-looking, Martina was late 30s - advanced maternal age.  

Consulting their familiar Saito General Hospital OB-GYN, they decided on early hospitalization. Tomorrow.  

"Let's check again tomorrow morning before leaving, but for tonight, sleep. Your body is precious."  

"Hmm... I suppose. Since Yuu-chan is here."  

When Yuu approached and embraced her shoulders, Martina nodded as if shaking off hesitation.  

Indeed, her belly seemed larger than any pregnant woman Yuu had seen. Walking seemed difficult. Though Yuu and Elena were considerate at home, hospitalization felt safer.  

Supporting Martina, Yuu got into bed.  

They promised to sleep together tonight before hospitalization.  

Lying face-to-face, where voluptuous breasts would've touched before, now her belly pressed against him.  

"Ufufu. Yuu-chan!"  

"Mom."  

Yuu brought his face closer for a goodnight kiss.  

His hand stroked her tied-up hair without disturbing it, easing Martina's expression.  

Following habit, he massaged her breasts, then caressed the swollen belly. Thinking of the life growing inside - his child yet sibling by relation - filled him with emotion.  

"Right. I wanted to say something before sleeping."  

"What is it?"  

Yuu slightly shifted position, burying his face in Martina's breasts. Staring into her eyes felt embarrassing.  

"Thank you for giving birth to me. I'm glad to be your child."  

"Ah... I..."  

Martina's voice caught.  

Tears welling, Martina embraced her beloved son's head, gently stroking it.  

"I'm the one... truly happy to have met Yuu-chan."  

Suddenly losing her husband, Martina cherished Elena and Yuu above all. Their strained relationship once pained her heart.  

But before she knew it, Yuu accepted Elena's excessive love. Rather, Yuu treated Elena with magnanimity befitting an elder.  

Moreover, to Martina, he showed not just filial love but adult male affection. She felt as if her husband had been reborn.  

"I'll work hard to deliver this child. Looking forward to our family growing."  

"Yeah. I'm looking forward to it too. But your health comes first."  

"Thank you."  

Fortunately, all women impregnated by Yuu had safe deliveries.  

But he knew miscarriage risks always existed.  

He trusted Saito General Hospital's OB-GYN staff, but Martina had age-related concerns. Though he heard abdominal tightening near term was common, as a non-childbearing male, he worried.  

He sincerely prayed nothing would go wrong, and delivery would end safely.  

---

### Author's Afterword

I posted a short story I wrote during the New Year holidays.  

'Trapped in an Elevator with a Beautiful Older Woman, I Couldn't Hold Back'  
https://novel18.syosetu.com/n8210hk/  

It could be called a companion piece to the short story 'Trapped in an Elevator with a Young OL, I Couldn't Hold Back' posted in November, reversing the age gap between the man and woman.  

It features a high school boy who loves older women getting trapped in an elevator with his ideal older woman.  

If interested, please give it a read.

### Chapter Translation Notes
- Translated "沙月姉" as "Satsuki-nee" preserving the honorific and sibling relationship
- Rendered "ユウちゃん" as "Yuu-chan" maintaining the affectionate diminutive
- Translated "ブラコン" as "brother-complex" for cultural accuracy
- Used "OB-GYN" for "産婦人科" as standard medical terminology
- Preserved foundation/organization names per Fixed Reference (e.g., Toyoda Sakuya Memorial Foundation)
- Translated anatomical terms directly ("breasts", "belly", "nipples")
- Maintained Japanese name order throughout (e.g., Kuroda Noriko)
- Italicized internal thoughts like *Even Yuu, who had no children...*
- Formatted dialogue with new paragraphs per speaker