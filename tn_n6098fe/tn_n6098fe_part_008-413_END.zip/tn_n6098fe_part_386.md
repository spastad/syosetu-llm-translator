## 363. Reward for My Sister ② ~promise~

"Kwaa!"

While caressing Yuu's face adoringly, Elena seemed to have targeted his nipples. She kneaded one with her fingers while enthusiastically sucking the other, making wet slurping sounds with her tongue.

Men are weak to nipple stimulation too.

Yuu had been pretending to sleep while letting Elena do as she pleased, but he couldn't hold back a moan.

"Ahhn, Yuu? You're awake?"  
"Hey, Elena-nee? This is..."  
"Sorry for waking you. I only meant to sleep beside you, but being close to you made me want you."  
"Elena-nee, we can't. We're siblings."  
"I know. But I can't control these feelings. I can only think about you... I love you, love you, love you, love you, love you, I love you so much! I want to make a baby with you!"

Their conversation was poor acting on both sides. Elena's true feelings were leaking out completely.

"...Honestly. I'm amazed at how perverted you are, Elena-nee."  
"Sorryyy~"  
"It's fine."  
"Huh!?"  
"Only I can accept my perverted, nymphomaniac sister."

Though harsh, it was the truth. Elena only had eyes for Yuu and showed no interest in other men - she was that severely brother-complexed. Seeing Yuu accept her despite his exasperation moved Elena to tears. This was the ideal development she'd dreamed of for years.

"Yuu... Aha... I'll love you forever... More than yesterday... I'll devote my whole life to youuuu!"

Though thinking *Her love is intense*, Yuu spread his arms. Naturally, Elena threw herself into them. While holding Yuu's head and rubbing cheeks, Elena licked him before kissing him with teary eyes. Yuu also wrapped his arms around Elena's back, returning the passionate kiss.

Immediately, Elena's tongue invaded his mouth, exploring everywhere from behind his gums to the back of his throat. Yuu actively moved his tongue too, tangling together as if their tongues were mating.

"Muhhaaaaa... Amchu, lero, lero, lerroooonfuu... I love you, love Yuuu... nmuwaa... nyerooo... chupuu... Haun, my brain feels like it's melting..."

While deep kissing, Elena straddling Yuu's hips began rocking her lower body. Yuu could feel dampness around his testicles where she was rubbing.

"Hey, Elena-nee?"  
"Whaa ni?"

After their tongues danced in each other's mouths, they opened their mouths and pressed their tongues together. Yuu swallowed Elena's drool before speaking while half-muffled by his sister. Elena answered without separating.

"Npfuu... wha iz i (what is it)?"  
"Ah~"

After pursing his lips to suck on Elena's invading tongue, Yuu asked. He could tell Elena wasn't naked, but she wasn't wearing winter pajamas either - just thin negligee in midwinter? Though Elena couldn't answer, she seemed to understand when Yuu moved his fingertips to check the fabric.

"Nn... Since we're here, want to see?"  
"Yeah. I want to see."  
"Ehehe. Okay."

Sitting up, Elena reached behind Yuu's pillow. The headboard had a small light and digital clock. When she turned on the light, yellow light illuminated the bed. Elena slowly sat up, swept her long hair back, and straightened her posture so Yuu could see clearly.

She wore a pink babydoll. Thin straps on both shoulders left shoulders and chest boldly exposed. Though lace covered the breast area, the center was sheer. Unfortunately, Elena wasn't full enough to create cleavage, but her erect nipples were visible. Floral patterns adorned her abdomen with skin showing in places - erotic.

Yuu was seeing it for the first time; she must have bought it for tonight.

"How is it?"  
"Ho... Very sexy. And cute too. It suits you well, Elena-nee."  
"Ufufu. Thank you. Hey, look at this too."

Elena knelt and lifted herself. The babydoll's hem was short, barely covering her buttocks. From Yuu's position, black lace panties naturally came into view. Though hard to see in the dim light, they weren't ordinary underwear. When Elena placed both hands on her hips and pulled the fabric sideways with her fingertips, a vertical hole opened in the crotch - crotchless panties allowing penetration while worn.

In the faint light, Elena's modest bust was offset by her slender, appealing figure. Her long tea-colored hair inherited from their father spread over her fair skin. Though they say you tire of beauty in three days, Elena was no ordinary beauty - her appearance could fairly be compared to Venus, goddess of beauty. It was understandable why junior girls admired her.

Though Yuu saw her daily, seeing half-naked Elena aroused him intensely. He sat up abruptly and embraced her.

"Elena-nee!"  
"Aahn! Yuuuu!"

Yuu rubbed his face against Elena's chest while frantically caressing her slender body through the babydoll. Delighted by Yuu's excited reaction, Elena hugged him back tightly. Feeling the modest yet soft breasts against his face, Yuu massured her buttocks with his right hand, gradually moving downward. Without lifting the hem, he reached the crotch area. Finding the slit, he touched her vulva - already soaking wet with love juice coating his fingers.

"An! No more... Now it's my turn to make you feel good."  
"Haha. I couldn't help it..."

Patting his head soothingly, Elena pushed Yuu onto his back. Holding his head with her left hand, she pressed her lips against his and thrust her tongue. Her right hand stroked from chest to abdomen over his pajamas until her fingertips touched his bulging crotch. When Elena's finger poked it, it was rock-hard.

"Aha."

Elena pulled away, her mouth forming a crescent moon shape, corners wet with drool.

"Can I suck your cock?"  
"Sure. Suck as much as you want."

With Yuu's permission, Elena happily gave a final "buchu" kiss. Contrary to expectations, she didn't immediately bury her face in his crotch. She only rubbed it over his pants while running her tongue down from chin to neck to chest. Elena's head disappeared under the covers as she pulled down Yuu's pants and underwear together.

"Ukyuu! The smell of cock..."

A muffled voice came from under the covers. Yuu smiled wryly imagining Elena's expression - the goddess-like beauty now looking lewd. But she didn't start licking immediately. What occasionally touched his cock seemed to be Elena's nose or cheeks. She was probably sniffing closely and rubbing her cheeks against it while caressing Yuu's abdomen, hips, and thighs.

Like an animal sniffing something new, Elena savored the scent from tip to balls before kissing the glans. Yuu couldn't see under the covers, but he felt the tip enveloped in soft wetness.

"Ah~ mmph!"  
"Whoa!"

His body almost jumped. Elena had suddenly deep-throated him to her limit. Yuu felt engulfed in lukewarm wetness. Elena had intended to take time licking, but her body grew restless and she went straight for deep throating.

Zuchuu, juppo, jurururuuu~

Making vulgar sounds mixing precum and saliva, she gave serious fellatio from the start, her head bobbing up and down visibly to Yuu. Without the covers, he might have seen her distorted face. Though Akiko the housekeeper had done this before, Elena had eagerly followed Yuu's order to do the same after getting Akiko fired. Her technique was now comparable to Akiko's after half a year.

"Kuu! I-It feels good, Elena-nee!"

Elena didn't respond, engrossed in fellatio. She pursed her lips to suck while pulling back until just the glans remained, licking it with her tongue. Then she swallowed it again, the tip hitting her throat. Repeated like this, it was unbearable - tingling pleasure made his lower body twitch.

But Elena didn't continue monotonously. Now she lightly gripped with her right hand, jerking while focusing oral attacks on the glans, licking sloppily. Her left hand gently massaged both balls alternately.

"Ah, ahh... That's... dangerous too... Feels so good..."  
"Mufuun... Yuu's... cock... delicious. I wanna... suck forever~"  
"But"  
"Nn"

Though she seemed absorbed, this was just foreplay. The night's main event was filling Elena's vagina - they'd agreed.

"Yuu... I want your cock. Want it inside my pussy. Can I?"

Elena lifted her head, only her face visible through the gap, asking in clipped phrases. Her expression showed desperate desire despite not being stimulated much.

"Sure, Elena-nee. Tonight I planned to fill your insides with my semen."  
"Kki!"

Wordless joy. Slithering over, Elena clung to Yuu. She seemed intent on penetration while still dressed, her right hand already guiding his cock.

"Put it in! Put it in now! Yuu's cock and my pussy... become one! Connect! Fuck me hard... Cum inside me, pyu, pyu, make a baby! Ufu. Ufufufufufufufu"  
"Ah, yes. Baby-making sex for Elena-nee's wish. Oh... ooh"  
"Nnfuu... Cock... Inside big sister... Going in... nnnnnnnnnnnnnnnnnnnnnnnnn~! Vun! Ah.........!"

Elena guided his cock to her vaginal opening and lowered her hips to swallow it, but seemed to orgasm immediately upon full insertion. Though not ejaculated inside yet, Yuu could imagine from her reaction.

"What's this, Elena-nee? You came fast as always. Hold out until I ejaculate."

Having been conditioned by previous experiences to orgasm from Yuu's cock, Elena was like Pavlov's dog. She'd orgasmed countless times during sex with Yuu, often losing consciousness midway.

"I-I'll try. Because tonight you'll cum inside me. Next time... I'll make you cum first."  
"Okay. I'm counting on it."

True to her word, Elena tightened her lower body, making her vagina contract further. Honestly, Elena's vagina gave Yuu supreme pleasure - a masterclass pussy he never tired of. Blood relations might affect sexual compatibility.

Elena began rocking her hips back and forth like doing push-ups. Her long hair dangling to Yuu's chest swayed gently. Yuu placed his left hand on Elena's buttocks while lifting her falling hair with his right hand and smoothing it down her back to see her face better.

"Elena-nee's pussy feels amazing."  
"Hah, hah, hah... Ann! Me too... My head feels like it's melting... Yuu's... cock... Inside me... my pussy, my pussy is... rejoicing everywhere... Ah... haa... I'm... c-c-cumming! Nnnnnnnnnnnnnnnnnnnnnnn~! Ahee... Love you, love you love you! Nfuu, sex with Yuu... happiness... I can't live without this... Aahn! My hips... won't stop!"

Her hip movements started slow, as if savoring. As sticky wet sounds from genital friction increased, Elena's hips sped up. Her jaw trembled, and after orgasming, she buried her face in Yuu's neck. Her long hair spread over Yuu's face, so he combed it aside while patting her head. Elena kept rocking her hips relentlessly, making "bachun, bachun" sounds as her buttocks slapped, while panting sweet moans in Yuu's ear.

"Haa, haa... Uggh! Hey... nee... Aahn! I feel like sister's pussy is milking me dry."

Yuu usually timed withdrawal to avoid internal ejaculation, but tonight required no restraint. The prospect of creampie made restraint impossible. Though the spice of incestuous taboo existed initially, now the male instinct to impregnate spurred him on. Yuu wrapped both hands around Elena's slender waist - the sign he'd ejaculate inside as promised.

"I'm about to..."  
"Aaii! Yu... u... nn, nn, Cum... inside me... fill me uuuuuuuuuuuuuup!"

Elena also hugged Yuu's head, grinding her hips violently. Countless vaginal folds contracted repeatedly, writhing to milk semen from his member - as if obeying her wish to conceive Yuu's child. Unable to hold back, Yuu thrust upward.

"Elena-nee! I'm... ejaculating!"  
"Nnaa! Oh, oh, i-it's... so strong! Th-this is..."

Whether orgasming or not, Elena received Yuu's semen while riding pleasure's peak. Thick semen gushed into her womb in pulses.  
"Hot"  
Elena felt this before nearly losing consciousness.

---

### Author's Afterword

The subtitle uses a hit song by an artist who dominated the 90s and was nicknamed "Winter Queen." The heavy love lyrics fit Elena's feelings perfectly?

Sometimes subtitles come easily, other times not, but Elena's came quickly - like "Anata Dake Mitsumeteru" in Chapter 56.

### Chapter Translation Notes
- Translated "ベビードール" as "babydoll" for the lingerie style
- Preserved Japanese honorifics (-nee) for sibling address
- Translated explicit anatomical/sexual terms directly (e.g., "膣内" → "vagina", "精液" → "semen")
- Transliterated sound effects (e.g., "くぁっ" → "Kwaa!", "ずちゅっ" → "Zuchuu")
- Maintained original name order (Hirose Yuu, Hirose Elena)
- Italicized internal thoughts (e.g., *Her love is intense*)
- Translated song reference in afterword while preserving cultural context