## 364. Reward for My Sister ③ ~A Wonderful Morning~

"Yuu, your penis has gotten big, hasn't it?"  
"U... hey, Sis"

Yuu was dreaming.

He lay on his back in his childhood bedroom's bed. His sister lay beside him, and he realized she was giving him a handjob after pulling down his pajama pants and underwear. But it wasn't Elena.

This was his sister from before his rebirth - coincidentally also three years older like Elena.

Unlike Yuu's ordinary looks, his sister was beautiful with sharp features. She was academically gifted too, having passed exams for the top prefectural girls' high school and later a national university. Though capable of entering prestigious Tokyo private universities, she chose a local national university due to financial constraints.

Though beautiful, she had no romantic relationships during her teens. Partly due to disinterest, and partly because growing up in a single-mother household made her emotionally reserved with little facial expression - unlike most popular girls who expressed emotions openly. Even as an adult when she finally met a good man and seemed headed for marriage, they broke up due to his infidelity. After this betrayal, she focused solely on work. Unlike Yuu who married once, she remained unmarried.

Though close as children, they naturally grew distant during adolescence, exchanging only daily pleasantries... 

In the dream, his sister wore her signature hairstyle - black hair tied in a single ponytail reaching her back - and expressionlessly jerked his penis while watching his reactions with obsidian-like eyes. Her skilled fingers never neglected the glans. Though his real sister would never do this, Yuu moaned in pleasure while thinking she resembled someone...

Suddenly her face transformed into former housekeeper Akiko. Some housekeepers in households with boys would occasionally help them ejaculate to prevent excessive buildup - but only trustworthy ones who kept secrets. Akiko was one such woman. Though similarly expressionless, Yuu later learned she hid intense passion within. Her eyes held tenderness when looking at Yuu.

*(Come to think of Akiko-san... she should've had her baby by now)*

As he recalled recently receiving a letter from her daughter Chihiro, Yuu's consciousness rapidly awakened. Feeling warmth along with the morning chill, his vision focused to reveal Elena staring at him.

Memories of last night returned. After ejaculating once in cowgirl position, Yuu sat up holding Elena and continued without pulling out for round two in missionary. Elena climaxed repeatedly from his thrusts until exhausted when he came. Though Yuu had energy to spare, they fell asleep embracing since school awaited.

"Ahhn. Yuu's so cute. Watching your sleeping face, seeing you wake up while jerking your morning wood - this was my dream!"

Though embarrassed, Yuu understood wanting to watch someone sleep and wake. That handjob came included was quintessential Elena. Smiling at Yuu, Elena looked divine like a goddess. Her light brown hair (inherited from their father) glittered golden in morning light. Her unpainted lips showed natural pink. Though she'd refused pajamas last night claiming Yuu's warmth sufficed, her baby doll lingerie exposed pale skin to her chest - radiating untouchable beauty. Her glowing skin and healthy complexion likely resulted from Yuu's abundant creampie.

"Hey, Sis... kuh!"  
"Yuu, does it feel good?"  
"Yeah. I-it feels so good... haah... ah!"  
"Kufufu. Just seeing your aroused face makes me happy... my heart's pounding! Tell me when you're close. I'll drink every drop of your morning semen!"

Morning wood handjobs strangely made him less resistant. After a light kiss, Elena slipped under the covers toward his crotch. What began as gentle stroking gradually sped up while she licked pre-cum. Within three minutes, Yuu reached climax and released into Elena's mouth. Needless to say, she swallowed every drop without spilling.

Since Saturdays had half-day classes, Yuu began preparing as usual. Elena secretly wished he'd skip school for nonstop intimacy, but Yuu was student council president with nine children (and more coming) - a busy life filled with schoolgirls. Moreover, he'd promised to visit Emi's family that afternoon to see their newborn and check on Emi's health. Meeting her family besides her mother was non-negotiable.

Having been told beforehand, Elena obediently prepared to see him off. But she noticed Yuu finished unusually early. Since guards drove him to school at fixed times, leaving early served no purpose.

Ignoring Elena's suspicion, Yuu walked to the entrance and turned around. Putting down his bag, he spread his arms. Recognizing the pre-departure hug and kiss ritual, Elena joyfully clung to him.

"Sis"  
"Yuu!"

They kissed passionately, changing angles repeatedly - less a goodbye than lovers reluctant to part.

"Ahh... uunn..."  
"Sis, you're already wet"  
"Th-that's... *smooch*... chuupreloo"

Elena wore only a white sweater and panties, proudly displaying slender legs. So when Yuu's right hand slid down, it immediately touched her private parts through the panties. Though freshly changed, Elena had already moistened them. While their tongues intertwined, Yuu rubbed her crotch.

"Sis, face the wall standing up"  
"Nnge?"  
"We've got 15 minutes. I'll insert you now?"

Understanding his intent, Elena nodded in surprise while bracing against the wall. Yuu gripped her protruding hips and pulled her panties down to mid-thigh. Since Elena was taller, she widened her stance beyond shoulder-width to align their hips. Meanwhile, Yuu unbuckled his belt and lowered his pants and underwear.

He'd always wanted to try standing doggy style before leaving. His erection swelled and curved upward as he pressed it against Elena's exposed butt crack.

"Short on time, so I'll go full power from the start"  
"Ahh, yes! Come on, come on~"  
"Here goes!"  
"Kyauun!"

Despite her wetness, entering without foreplay made even his experienced sister's vagina tight. Yuu thrust forcefully anyway, plunging deep in one motion.

"AAAAAAAHN!"  
"Sis, too loud!"  
"B-but... u... mmg"

Elena covered her mouth while Yuu gripped her buttocks and thrust powerfully from the start - almost rape-like sex. Yet Elena clearly enjoyed it, evidenced by love juices gushing down her thighs.

"Nn, nn, mufu! Vuuun! Ha, so rough... love it... more, more, Yuuuu!"  
"Ahh, Sis... your pussy feels amazing!"

Pan, pan, pan - each thrust echoed through the entrance hall as Yuu's lower abdomen slapped Elena's buttocks. No thoughts of making her come first or savoring her vagina - Yuu pistoned solely to ejaculate before his ride arrived. Yet Elena writhed ecstatically. Her long brown hair whipped with each deep thrust, occasionally freeing moans when her hand slipped from her mouth.

Had he not ejaculated upon waking, he might've finished sooner. Elena's vagina offered supreme pleasure - he needed to come quickly yet wanted to savor her longer. After 7-8 minutes of furious thrusting, Yuu felt climax approaching. He began shallow, rapid thrusts at maximum depth.

"Hyaah! Ann! Ann! Yuu, so... so good! Ahe... shorerameeeee"

As Elena's moans intensified, Yuu worried they might be heard outside. Pressing against her back, he covered her mouth with one hand while wrapping his other arm around her slender frame to hold her still for the final sprint.

"Nnaa, muu... nn, nnnn! Nfoh!"  
"I'm coming, Sis! I'll fill you up inside!"

Elena nodded repeatedly against Yuu's hand.

"Ohh... ooh... cumming!... kuha!"  
"Oh, oh, muo! Nfuuuuuuuuuun!"

Likely climaxing simultaneously with Yuu's ejaculation, Elena threw her head back gazing at the ceiling with ecstatic expression as semen flooded her womb.

Checking the clock, Yuu had three minutes until departure. An idea struck him. After pulling out, he redressed Elena's panties. When her legs gave out and she collapsed, he ordered cleanup fellatio. As she licked residual semen, the doorbell rang.

***

After morning classes, Yuu headed to Emi's family home as planned. Located in former Higashimatsusaka City's outskirts, the Ishikawa residence wasn't far from school. He'd met Emi's mother Asami during engagement formalities and at Emi's delivery, later greeting her grandmother too. Though Emi mentioned being quarter-British, her grandmother appeared younger than expected - a refined lady in her mid-60s with flaxen (gold-tinged light brown) hair and blue eyes. But upon seeing Yuu, she became talkative, eagerly asking how he and Emi met.

Emi's mother and grandmother had unusually achieved love marriages with men in this world, similar to the Komatsu family. Aggressive yet likable personalities seemed an Ishikawa female trait. Today marked Yuu's first meeting with Emi's father and grandfather. Though nervous, his worries proved unfounded - both gentle men sincerely blessed their daughter's/granddaughter's engagement and child with Yuu. With lunchtime approaching, the family shared an extravagant meal centered around newborn Miyu, enjoying warm fellowship.

***

Returning home around 5 PM after the pleasant visit, Yuu realized cooking duties fell to him. Elena couldn't cook or even manage basic housework - their mother Martina handled that but was hospitalized. Though housekeepers came weekdays, weekends required Yuu to feed Elena. He'd stopped at a supermarket earlier to have guards buy ingredients. The silver lining: Elena happily ate anything he cooked.

"I'm home"  
"Yuu, welcome back~. I've been waiting"

Hearing Yuu, Elena rushed over wearing an unexpected outfit - his own stencil-collar coat indoors over what appeared to be just a white shirt.

"Sis, what are you doing?"

Ignoring his question, Elena smirked while unbuttoning the coat.

"Hey, look look~"  
"Huh?"

After undoing the three buttons, only a white shirt remained underneath - likely also Yuu's. Faint red lines showed through the fabric, resembling...

"No way"  
"Ta-da!"

Opening the shirt revealed Elena's pale skin bound from thighs to crotch with red rope. Though her limbs remained free, it resembled a tortoise shell bondage.

"How did you even...?"  
"The ropes are elastic - I can put this on myself!"

Elena proudly puffed her modest chest - slightly emphasized by the ropes. Though wearing black panties, two ropes dug into her cleft. When had she bought such gear? As Yuu stared dumbfounded at his self-bound sister, an idea struck.

"That's not enough. Wait here"

Grinning, Yuu entered Elena's room without permission and retrieved his target. Kneeling before her, he held two of her favorite pink vibrators. Tugging the crotch rope confirmed its elasticity. When he pulled aside her panties, her slit was already soaked - perhaps she'd masturbated in this outfit. Yuu inserted one egg-shaped vibrator into her vagina.

"Hyahn! Ah, ah, it's going in..."

He inserted the second vibrator above the panties, positioning it near her clitoris and securing it with rope.

"Ahi... Yu, Yuuuu..."

He let the connected remotes dangle from her panty elastic. Far from resisting, Elena wriggled expectantly. Yuu activated both switches simultaneously to meet her hopes.

"Hyahhhhaaaaahn!"  
"Sis, punishment for using my things without permission. You'll stay like that for a while"  
"Yah... ahhn! Nooo, I can't stand..."

Elena collapsed dramatically - clearly capable of standing but seeking attention. Kind Yuu decided to give her what she craved. He lowered his pants and underwear.

"Sis, time for your welcome-home blowjob"  
"Uun... Yuu's... penis..."

With glazed eyes, Elena clung to Yuu's lower body and began licking his penis with her broad tongue.

### Chapter Translation Notes
- Translated "おチンポ" as "penis" per explicit terminology rule
- Preserved Japanese honorifics (-san for Akiko)
- Transliterated sound effects (e.g., "pan pan pan" for ぱんぱんぱん)
- Translated "ベビードール" as "baby doll lingerie" for accuracy
- Rendered sexual acts without euphemisms ("fellatio", "intercourse", etc.)
- Maintained original name order (e.g., "Ishikawa Asami")
- Italicized internal monologue *(This is concerning.)*
- Translated "亀甲縛り" as "tortoise shell bondage" for cultural specificity