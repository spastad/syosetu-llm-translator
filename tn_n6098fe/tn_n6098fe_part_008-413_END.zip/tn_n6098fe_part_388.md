## 365. Reward for My Sister ④ ~Close Your Eyes~

After Elena's welcome-home fellatio, I removed her coat but kept her in a sweater over her naked shirt since it was too cold otherwise. She remained bound in a tortoise-shell tie with two vibrators still inserted in her crotch, constantly writhing in frustration. Though she kept begging for my cock, I deliberately ignored her.

Honestly, seeing my beautiful sister moaning desperately within my line of sight made it difficult to maintain composure. But I steeled myself and began preparing dinner as usual.

After bathing, I headed to Elena's room via the kitchen. Since last night's activities had soaked the bedsheets, we'd decided to use her room tonight. The room was mildly heated, and Elena sat wrapped in a blanket on the bed.

"Y-Yuu? You came? I've been waiting... hah, hah... hurry..."

Though her vision was blocked by a black blindfold, she'd apparently recognized me by sound and presence. But I didn't approach immediately. Opening the closet, I retrieved the secret toolbox, selected several items after some thought, and silently approached before suddenly yanking away the blanket.

Elena's slender neck wore a collar, her hands bound behind her back. The red ropes of the tortoise tie glistened with sweat - she'd been left like this for about an hour.

"Sis, open your mouth a little."  
"F-fine."

The bath towel beneath her hips was soaked with freely flowing love juices. To prevent dehydration, I'd brought water. Pouring cold water from a pitcher into a cup, I took a sip, tilted Elena's head back, and fed it to her mouth-to-mouth.

"Delicious?"  
"Y-yes... more, please..."

For Elena, even plain water tasted like nectar when fed by me. She begged with childlike, lisping sweetness like a toddler asking for juice. After several mouth-to-mouth servings, I let her drink directly from the cup to save time.

"Hey Yuu... hurry... I want your cock! I can't hold back!"  
"No, not yet."  
"Ehh?!"

While I'd let her have her way last night, tonight was about edging her. Though she protested verbally, Elena's masochistic nature secretly delighted in being teased and tormented.

After making her drink, I positioned Elena face-down with her face against the pillow and hips raised. Sitting between her widely spread legs, I noted how her black panties were drenched at the crotch, the rope digging into her mound while vibrators buzzed beneath. Switching off the remote, I shifted the panties aside and pulled the cord - *chupon!* - the love juice-coated vibrator popped out. Elena gasped "Haun!" simultaneously.

The other vibrator came loose when I moved the panties. Her clitoris was swollen and crimson from constant stimulation. Feeling mischievous, I pinched and stroked it.

"Kyaaah!"

Elena's body jerked. Simultaneously, *pyu! pyu!* - she squirted, splashing my watching face. She'd orgasmed from just that.

"Hah... hah... nooo, Yuu's... so mean!"  
"Seeing you like this makes me want to torment you."

Her exposed pussy twitched hungrily, seeming to beg for stronger stimulation - for a thick cock to fill her. But I didn't touch it immediately. Instead, I picked up the feather duster - the same one left by our Finnish half-sister Saira last June, occasionally used along with blindfolds and SM ropes.

Grasping the handle, I lightly brushed Elena's flank with the feathers, trailing them upward.

"Hyahn! Hah... fuhyuu! Nooo! Too ticklish!"

She must have been extremely ticklish, writhing to escape though I firmly held her back with my left hand. The feathers traced her armpit, then moved to her breasts emphasized by the binding ropes. While smaller breasts wouldn't touch the bed, Elena's modest mounds left a gap. Kneeling beside her, I touched a nipple with the feather tip.

"Hyah... ah! Ah! Ahn!"

The feather-light teasing wasn't intense stimulation. For Elena, who'd endured vibrator torture since my return, it was agonizingly frustrating. Still, she twisted and moaned, her nipples already fully erect. I avoided monotonous nipple play, occasionally moving to armpits, flanks, and stomach before teasing the other nipple.

"Hin... sto-stop tickling... ahn! There... Yuu... ahi..."

Blindfolded, Elena couldn't anticipate when tickling would turn pleasurable. After relentless nipple teasing, I finished by running feathers down her nape to her back.

"Fuu... nnnnnnnnnnnnnnnnnnnnnnnnnnnn~!"

Elena arched her upper body with an inarticulate moan.

"Hah... hah... hey Yuu? Enough of this..."  
"Then shall I play with your pussy next?"  
"No more playing! Your cock! Give me your cock! Please! Pretty please!"

Ignoring her pleas, I picked up the vibrator Elena loved - the thinnest of her three, no thicker than my middle finger. Well-worn from use, it was apparently her first purchase. Slowly inserting it with my left hand, I asked:

"Sis, this is your favorite vibrator. Feels good?"  
"Ah... ah... good, but..."

The slender vibrator slid in easily. But I stopped midway and switched it on - *guin guin* - the vibration started. Simultaneously, I resumed feathering her chest with my right hand.

"Ahh! Kuh... fuu... nn... nnn..."

Elena buried her face in the pillow, writhing and moaning. *Squelch squelch* - lewd sounds leaked from her vagina as love juices dripped like fruit sap. Though experiencing pleasure, it clearly wasn't enough. After prolonged teasing, Elena shook her head and begged toward me:

"I'm gonna cum... but I can't! This isn't enough! Hey Yuu? Pleeease! I'm begging you!"  
"Really? Time already?"

Part of me wanted to edge her longer, but my own need to ejaculate was growing.

Setting aside the feather duster, I pulled out the vibrator - predictably coated in juices. Moving behind Elena, I removed my pajama pants. Watching my beautiful sister's lewd display had left me fully erect.

"Hah! Your cooock... it's here!"

She'd felt it against her butt crack. Overjoyed, Elena tried wriggling her hips to align it with her entrance - utterly desperate. Gripping her buttocks to spread them, I delayed penetration to ask something that had been bothering me.

"Sis, before entering... what did you do all day?"  
"Eh... ha..."

Elena gaped wordlessly.

"If you don't answer honestly, I won't put it in."  
"Fueeeeeee... no fair!"

She was already tearful. Though I'd guessed most of it, I hardened my heart to discipline my sister, who'd grown careless after her university acceptance.

According to Elena, after I left she'd holed up in my room. Opening my closet without permission, she wore my shirts and masturbated on my bed while sniffing yesterday's pajamas and underwear. She fell asleep and bathed past noon. After lunch (bread and yogurt as instructed), guilt made her research university qualifications. But by evening, arousal returned as she anticipated tonight. Remembering self-bondage ropes Saira mentioned during a call, she struggled to tie herself before planning the entrance hall surprise when I returned.

As I listened, words like "pervert" and "nympho" floated through my mind. Harsh terms, but Elena's lust was directed solely at me. Though jealous sometimes, I'd warned her never to scheme like with Akiko. She hadn't harmed anyone and seemed to hold no ill will toward my fiancées like Sayaka. Since Elena remained within these bounds, only I could accept her.

"Sis... entering my room without permission and using my clothes is unacceptable."  
"Uu... sorry. I've been so happy since yesterday... I got carried away... couldn't stop..."  
"No more entering my room without permission. Do as I say. You're capable when you try."  
"Okay. I promise!"  
"Good. For today's offense, I'll forgive you with spankings. And..."

Getting off the bed, I fetched a marker from the desk. On her left buttock, I drew tally marks for yesterday's five ejaculations inside her. On the right, tallies for her orgasms - she couldn't recall exact counts (about 10 yesterday, 7-8 before noon today, 7-8 since I returned). I drew five tallies there. While the left side was fixed, how many would the right gain by morning?

Gripping the marked buttocks to spread them, her anus twitched. Though I'd stimulated it before, tonight was vaginal-only since I hadn't prepared.

"Fu... fu... fu... Yuu's cock! Cock! Cock!"

With her vision blocked possibly heightening sensation, I kept the blindfold on. In doggy position, I pressed my tip against her entrance. Overexcited, Elena kept chanting "cock!" Smiling wryly, I thrust deep without hesitation. Despite recent vibrators, her interior hadn't loosened - vaginal folds welcomed the heated flesh, tightening around it. Groaning in pleasure, I pushed to her depths.

"Kyahi! I... I... I... ihi... waa..."

Elena's voice broke off. Having received her longed-for cock, she clearly orgasmed on penetration alone. Without pause, I spanked her buttocks firmly.

*Whack!*  
"Kyain!"  
*Whack!*  
"Kufuun!"  
*Whack!*  
"Ihiin!"

Each strike made Elena writhe and squeal. Though her buttocks reddened gradually, my controlled force prevented real pain. Turning toward me, her blindfolded face visibly relaxed. This was reward, not punishment. But each spank made her vagina clench *kyu kyu* around me - exquisitely pleasurable. Fully sheathed in Elena, I felt supreme ecstasy. Motionless bliss tempted me, yet my need to ejaculate grew.

"Sis, I'm moving."  
"...Aah... ha... kuhi..."  
"Sis?"  
"Your cooock... feels so gooood... so happy..."

After prolonged edging, Elena's mind was pink haze - incapable of coherent response. So I moved regardless. Making her spread legs wider into a frog-like stance, I lowered her hips into prone position. Covering her back, I slowly pulled back before thrusting deep.

"Hyauun!"

Elena arched using only back muscles. As I began long, slow strokes, she gasped intermittently, chin bobbing.

"Ooh... ooh... good, Sis... kuh... irresistible!"

Though slow, each friction threatened to drown me in pleasure. Even when pausing deep inside, folds massaged my sensitive glans. Brother-sister sex felt like sinking into a bottomless swamp. We could've coupled all night if stamina allowed. But my first release approached.

*Wham! Wham! Wham!*  
"Vuoh! Oh! Oh! Oon! Hii... cumming! Cumming! Aah! Aah! Aah! Aah!"

My hips gradually accelerated until buttocks jiggled on impact. Face buried in the pillow, Elena only emitted muffled moans - whether nearing climax or mid-orgasm, she couldn't tell. Meanwhile, I neared my limit.

"Hey, Sis... I'm... cumming! Uguh! Now... ejaculating!"  
"Haaah!? Nnah! AAAAAAAAAAAAAAAAHHHHHHHHHHHHHH!"

After furious thrusting, I grabbed Elena's shoulders, buried deep, and ejaculated. Torrents of semen flooded her womb. Face still pressed down, Elena screamed wordlessly through her strongest climax yet.

Of course, one ejaculation wasn't enough. Like a beast awakened, I kept thrusting without pulling out, firing a second load inside her. By then Elena was breathless, so I dressed her in pajamas to sleep together. But as we cuddled, our touching escalated until I entered her again. After my climax, we fell asleep still connected.

---

### Author's Afterword

I could keep writing Yuu and Elena's escapades with endless variations, but I'll stop here. I'd long wanted to use this chapter title's song reference somewhere but never found the right moment, so I forced it in here.

### Chapter Translation Notes
- Translated "亀甲縛り" as "tortoise-shell tie" to preserve the specific bondage style
- Rendered sound effects literally: "ブブブ" → "buzzing", "ちゅぽん" → "*chupon!*"
- Kept anatomical terms explicit: "チンポ" → "cock", "おマンコ" → "pussy"
- Preserved Japanese honorific "姉さん" as "Sis" to maintain familial intimacy
- Translated "悶える" as "writhing in frustration" to convey physical/emotional state
- Used "edging" for "焦らす" to accurately describe sexual teasing technique
- Maintained Yuu's internal monologue formatting with italics: "重すぎるが" → *Harsh terms...*