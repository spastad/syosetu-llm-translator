## 366. At the Komatsu Residence ~A Lively Family~

### Author's Preface

I recently learned that a "like" feature has been added for each chapter. 

Since the default setting was not to accept them, I changed it to allow likes. 

While they don't affect points directly, receiving praise boosts motivation for us authors. 

Even if writing comments feels burdensome, a "like" only takes one click. I'd be delighted if you could "like" chapters you enjoyed.

---

"Fufufu. How adorable. I cherished Riko when she was born, but knowing this is Riko's child... Yurika is simply the cutest in the world."

"My dear, Sayaka's Hajime is the world's most adorable baby! Look - he's inherited all the best traits from Yuu-kun and Sayaka!"

"No no. Yurika, born from Yuu-kun and Riko's love, is definitely number one!"

"No, Hajime is!"

"Grandmother..."

"Grandma, please stop, it's embarrassing..."

The ones holding the babies and arguing were Reika, Sayaka's grandmother, and Kako, Riko's grandmother. Both in their sixties, blessed with great-grandchildren. Reika served as president of Komatsu Group, while Kako had handed over shop management to her eldest daughter Mako (Riko's mother) but remained active as a community leader in the local shopping district. Neither showed their age.

However, the infants they held were their beloved grandchildren's newborns - naturally precious to them.

---

In southern Saitama Prefecture, adjacent to Tokyo, stood the Komatsu residence in Wakou City. Yuu visited Sayaka's family home on Sunday afternoon after his fiancées returned to their parents' homes following hospital discharge. Earlier that day, he'd trained at MALSOK security company's training center as usual.

The spacious Japanese-style room contained not only Sayaka and Kiyoka sisters, but also grandparents Reika and Yoshioki, parents Tomoka and Hikaru, and Sayaka's great-aunt Ritsuka (also a dojo master). The Hanmura family, close friends of the Komatsus, had rushed over upon hearing of Yuu's visit. Though mother Mako couldn't attend due to work, grandmother Kako brought Riko and Sayori - Riko's cousin and current student council member.

"How are Sayaka and Riko feeling? You both look well."  
"We're being pampered hand and foot here."  
"It's lonely not seeing Yuu-kun daily, but coming home was the right choice."  
"Your health comes first now. Come to think of it, your faces look rounder?"  
"Eh!? R-really?"  
"Now that you mention it, we've just been eating and sleeping..."  
"Just joking. Both of you are as beautiful as ever."  
"Oh Yuu-kun, you..."  
"Idiot..."

Yuu knew from research that postpartum women suffered physical damage comparable to car accidents. Though Sayaka and Riko had clearly been exhausted right after delivery, three weeks later their complexions had improved and mobility returned. Despite their youth, entrusting their recovery and childcare to their parents had been the correct decision.

Around the long table, Sayaka and Riko flanked Yuu while their grandmothers competed over the babies. Sayori sat beside Riko, Kiyoka next to Sayaka - who smiled meaningfully when her eyes met Yuu's. Shortly after the homecoming, Yuu had visited their apartment with half-sister Nana to send belongings, where Kiyoka arrived with former Saibo Academy student council president Sumiko. The four shared an intimate moment.

In his previous world, men cheating during their wives' homecoming births risked divorce. But this was a chastity reversal world where men took multiple partners. Following Komatsu tradition, Yuu would eventually marry Kiyoka too. He'd informed Sayaka openly, needing no secrecy.

"How's Sayori's morning sickness?"  
"...Still not great."  
"Sayori might have it worse than most."  
"It's a path all must walk. Endure it for now."

Though layered clothing hid physical changes, Sayori was entering her third month of pregnancy. Her appetite had waned this past month, making her slender frame appear even thinner. Yuu felt concerned yet powerless. Sayaka, who'd suffered severe morning sickness, gazed distantly and murmured.

Yuu felt nothing but gratitude toward them - enduring months of nausea and restrictions while nurturing life, finally suffering birth pangs to deliver. Overflowing with affection, Yuu stroked Sayaka's head with his right hand. She happily leaned into him, shaking her black hair shortened for childbirth. When Riko also leaned in, Yuu stroked her head with his left hand. Today her usually tied-up hair flowed down her back. The slightly wavy black hair now reached mid-back, same as Sayaka's current length.

"Our grandchildren get along so well."  
"More might be coming?"  
"I want a boy next! Normally that'd require incredible luck, but Yuu-kun surely can."  
"Then we'll take a girl."

Without noticing, the great-grandchild competition ended as Reika and Kako smiled at Yuu sandwiched between the girls. Though the babies had been the focus earlier, attention had shifted to Yuu with Sayaka and Riko.

"How strange. Despite how much I suffered from morning sickness, seeing Hajime makes me want another child with Yuu-kun."  
"Same here. If Yuu-kun agrees... perhaps when university life settles down?"

Sayaka and Riko both stared at Yuu. They understood how blessed they were to bear their beloved man's children. Yet humans might be greedy creatures - they yearned for deeper bonds with Yuu. He resolved to grant their wish. With family support and no financial worries, more children were welcome. Already father to nine with more expected, Yuu believed more children were better if manageable.

"Of course! Sayaka, Riko, let's keep making babies!"  
"Y-Yuu-kun!"

For that moment, they might have been lost in their own world. But Yuu soon remembered their surroundings - enveloped by Sayaka and Riko's families. Though he blushed, the grandmothers looked impressed.

"Truly, our son-in-law is splendid!"  
"No, my son-in-law is best!"  
"Mother, Mrs. Hanmura, you're both talking about the same person."

At Tomoka's remark, Reika and Kako exchanged glances and burst out laughing.

"Ohohoho! So we were."  
"Yes. Nothing matters more than our grandchildren finding happiness with a good husband."

"I want Yuu-kun's child when big sister has her next baby!"  
"B-but I'm having Yuu-kun's baby this year first..."

As Kiyoka and Sayori pressed against Yuu's back, he took their hands knowingly.

"Kiyoka, grow up steadily. Childbirth is hard work as you see with your sister - physical preparation matters!"  
"Yes, Brother-in-law!"  
"I look forward to Sayori's baby. It's tough with morning sickness now, but take care of yourself."  
"I-I know."

Kiyoka answered energetically under Yuu's affectionate gaze. Sayori replied shyly but smiling.

Conversation continued centered on the babies and Yuu. Observing the three generations - Reika, Tomoka, Sayaka - Yuu pondered. Komatsu, a top Japanese motorcycle/automaker, was founded by Sayaka's great-grandmother Hanako. Eldest daughter Reika succeeded as president, expanding Komatsu globally through exceptional management. Tomoka, now a department head and future president candidate, was seen as steady - likely refocusing on Komatsu's technical roots rather than reckless expansion.

Sayaka would study business at university before joining Komatsu. Riko aimed to hone engineering skills for the same goal. Both dreamed of supporting Komatsu together. Would Hajime join too? If a daughter came from Sayaka, she could inherit while Hajime pursued his passions. Unlike his previous world, women faced no career restrictions here - they could become politicians, soldiers, fighters, or adventurers if desired. Whatever their gender, Yuu wanted his children to pursue their chosen paths.

"What is it, Yuu-kun?"  
Sayaka inquired as Yuu fell silent staring at the babies. Turning to her, Yuu smiled and took her hand.

"Just thinking about Hajime and Yurika's future. Not just them and Miyu - many more of my children will come. I must strive to give them wonderful futures."  
"Yuu-kun, are you really only 16?"  
"But as a first-year male student council president handling duties splendidly, it's no surprise he thinks ahead."  
"No no, as president I don't compare to Sayaka. Everyone helps me - especially Sayori. She's remarkably capable for a first-year."  
"Th-that's not true..."

When Yuu glanced at Sayori, she blushed slightly and averted her eyes. Though acting reserved, she was genuinely pleased.

"What do you aim to achieve, Yuu-kun?"  
Ritsuka, who'd been quietly observing, addressed Yuu. Dressed in white *keikogi* and *hakama* after morning training, she watched him intently. After brief thought, Yuu met her gaze squarely.

"I haven't thought concretely yet, but after high school I want to continue my father's work."  
"Eeeh!?"  
"Even if it means walking a thorny path?"  
"Yes, I'm prepared. I believe it's my destiny in this life."

Ritsuka crossed her arms and nodded several times.

"Sayaka!"  
"Yes! Great-aunt!"  
"You chose well."  
"Naturally. Yuu-kun is the man I wish to spend my life with."

Ritsuka laughed heartily at Sayaka's immediate response. Yuu felt relieved earning approval from the samurai-like elder. Originally as a high school freshman, he'd never seriously considered his future - most teenagers didn't. But circumstances differed completely now. After nearly a year reborn, he contemplated his destiny.

Then Tomoka clapped her hands.

"Speaking of which, wedding preparations are progressing smoothly."  
"Sorry for burdening you while busy."  
"It's fine. Though surprising at first, it's wonderful to celebrate with many."

The wedding for Yuu, Sayaka, Riko, and Emi was scheduled for late March - legal at age 16 in this world. With Martina hospitalized early, Tomoka led preparations with the fiancées' mothers. The venue chosen after discussion was Sairei Academy - where they'd met and nurtured love. The unprecedented request shocked the school until Tomoka's presentation convinced them: making this a model case would provide future promotional opportunities. Approval from the board chairman and principal ensured smooth progress. All former students and staff could attend this non-religious public ceremony, guaranteeing large attendance.

Yuu expected no changes post-marriage. With separate surnames standard, they'd follow convention. Though 16-year-old Yuu already met society's minimum wife quota, more would surely join over time - likely including Kiyoka and Sayori present today.

Yuu wouldn't hide his marriage but avoided publicity. To prevent media leaks from frequent school visitors, only Weekly Fuji and Saito News would receive announcements.

---

Yuu had another destination that day. Around 5 PM, he prepared to leave.

"You should stay over since you're here!"  
"Yes! I want more time with Brother-in-law!"

Everyone tried to stop him - especially Yoshioki and Hikaru wanting man-to-man talk, and Kiyoka clinging to him. But Yuu had an appointment he couldn't miss.

"Don't trouble Yuu-kun with selfishness."  
"Exactly. He'll visit again next week."

Sayaka and Riko mediated. Reluctantly, Kiyoka released Yuu, who soothed her with a head pat. When Yuu turned to Sayaka, she leaned in and whispered:

"Tell them I sent my regards."  
"Understood. I'll definitely convey it."

Only Sayaka and Riko knew Yuu's destination: the dormitory housing Rinne Mitsuse, who'd left home against family wishes.

---

### Author's Afterword

I mentioned separate surnames are standard, though some couples share one. Sakuya Toyoda's first wives like Haruka took the Toyoda surname. I've considered the backstory and hope to write about it someday.

### Chapter Translation Notes
- Translated "里帰り" as "homecoming" to convey post-birth family return tradition
- Rendered "上げ膳据え膳" as "pampered treatment" to express privileged care
- Preserved Japanese honorifics (-san, -chan) and name order per style rules
- Translated "曾孫" as "great-grandchildren" with contextual explanation
- Maintained explicit terminology for reproductive content ("making babies")
- Italicized internal monologues like *(How strange...)* per formatting rules
- Transliterated sound effects ("Fufufu", "Ohohoho")
- Used gender-neutral "they" for Amir as specified in translation rules
- Translated "男同士の会話" as "man-to-man talk" to retain cultural nuance
- Kept specialized terms like "keikogi/hakama" with contextual clarity