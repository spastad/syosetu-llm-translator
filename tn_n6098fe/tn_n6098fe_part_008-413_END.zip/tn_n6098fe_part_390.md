## 367. After the Mistress Contract ~Tears -Made in tears-~

### Author's Preface

The previous chapter received 89 "likes"! Thank you!

By the way, it seems only the author can see this number in the editing interface.

---

Since last September, after the Dankyo Party's affiliates and subordinate organizations were exposed for criminal involvement, public sentiment shifted dramatically.

Political parties and left-leaning civic groups like the Dankyo Party had opposed the government and ruling party's policies - which essentially continued male protection under the guise of inheriting Toyoda Sakuya's movement for mutual understanding and interaction between genders. They advocated for complete female supremacy and strict male control.

Their dark dealings were exposed by media - including deliberate leaks from authorities - impacting Saiei Academy.

Saiei Academy had received substantial donations from sponsors linked to these groups, with admission quotas for members' children as reciprocation. After the scandal, donations ceased, and the principal along with some faculty were expelled.

Further arrests among former student council members led to suspensions and expulsions. Former council president Mitsuse Rinne hadn't directly committed crimes but bore responsibility for leading the council, receiving a 2-3 month suspension. Her avoidance of expulsion was likely due to her family's influence as owners of Nikko Industries.

New student council president Mikageishi Mayo informed Yuu about this. Rinne accepted the punishment, but her mother and grandmother refused, causing conflict. Amidst this, a power struggle erupted within Nikko Industries between the Mitsuse faction and rivals. Before resolution, Rinne submitted her withdrawal from Saiei Academy and left her family.

Rinne had employed two male servants - one at home, one at the student council office - following family pressure to "have at least one or two lovers as the Mitsuse heiress." She showed little interest, using them only for chores. Before leaving home, she dismissed both, but Amir - her student council attendant - unexpectedly asked to stay with her. Though strict, Rinne had never touched Amir (a refugee's son) and paid above student wages, earning his loyalty. Unable to take him, she gave him generous severance and promised future reemployment.

---

After leaving the Komatsu residence, Yuu's car entered Tokyo, approaching Shakujii Park in Nerima Ward. A wide campus straddling the road housed a university and high school with European-style brick buildings resembling a European streetscape.

Rinne transferred to St. Anastasia University Affiliated High School, a mission school with full dormitory. St. Anastasia University was founded by a Catholic-affiliated religious group to train clergy. Its affiliated high school accepts troubled students for rehabilitation, making transfers easy but enforcing strict discipline. Though not Christian, Rinne reportedly sought this harsh environment for reflection.

Yuu exited the car at the high school parking lot. Since the school was male-prohibited - with Yuu being the only male who'd willingly visit - he crossdressed beforehand. His long black wig had bangs covering his eyes behind non-prescription glasses. To avoid looking gloomy, Sayaka and others playfully applied makeup. He wore a black suit matching Kanako's, with a coat and scarf hiding his Adam's apple. Walking carefully and speaking minimally would prevent detection, they advised.

But bringing multiple guards would raise suspicion, so only Kanako accompanied Yuu while Touko followed at a distance like a spy.

No one passed by as they walked from the parking lot. Though buildings appeared aged, they were impeccably clean. The campus felt solemn rather than vibrant, befitting its strict reputation.

"Kitamura from the Toyoda Sakuya Memorial Foundation."  
"Hirose."

At reception, Yuu and Kanako gave their business cards to a nun-like middle-aged woman. Posing as scholarship officials with Yuu using his sister's name, they'd scheduled an appointment. The woman glanced at the cards, eyed them briefly, but showed no suspicion.

"She's at evening service now. Please wait in the dormitory meeting room."

A young nun offered to guide them. Her head was fully covered by a white wimple and black veil, a gold cross gleaming at her chest. Having never seen a real nun up close, Yuu stared curiously. The loose-fitting habit contrasted sharply with erotic game/manga depictions.

Entering the dorm, they proceeded down the first-floor hallway. The talkative young nun explained various details. Yuu only nodded to avoid speaking, leaving Kanako to respond. Student rooms occupied floors 2-4, while floor 1 had a cafeteria, recreation room (with the dorm's only TV), and meeting rooms for external visitors. Students couldn't leave campus without permission, nor meet outsiders unapproved. Daily morning/evening services - worship and chores - restricted personal life regardless of weekday. Research indicated an oppressively strict environment.

Yuu and Kanako entered a meeting room: 8-tatami size with only an aged wooden table and four hard chairs. A single vase by the window and small European landscape painting offered minimal decoration.

After 15 idle minutes, black-habited students approached outside. Unlike their guide, they wore no head coverings. Remarkably silent for a girls' group, they walked quietly - possibly a rule. All had short or tied-back black hair, fitting the strict-school image.

Despite the crowd, footsteps were quiet, though muted chatter began inside the dorm. After 5-6 more minutes, a knock came.

"Come in."  
"Excuse me."

Yuu was surprised by Rinne's entrance - her appearance had completely changed, and she no longer used formal "desu wa" speech.

Her once eye-catching copper-beige hair was now nearly black (perhaps dyed or naturally reddish). Previously distinctive drill-curled waves were now tied simply at the nape, shorter than before. She wore no makeup - Yuu remembered her bare face from their hotel encounter. Though naturally youthful, she'd worn severe eye makeup as council president to avoid being underestimated. Yuu preferred her cute bare face.

"May I ask who... oh?"  
Rinne looked at Yuu but didn't recognize him. She remembered Kanako from their hotel encounter.

"I'll keep watch outside," Kanako said, leaving to give them privacy. Rinne hesitated, unsure whether to sit with this unfamiliar "woman."

Yuu approached. Rinne showed wariness but seemed more confused than alarmed. Passing her, Yuu moved behind her, anticipating her reaction when revealed.

"Yuu. Hirose Yuu."  
"Eh? Yu... mo-ga-?"

He covered her mouth as he identified himself. Rinne stared back in disbelief.

"I'm crossdressing - men are banned here. Stay quiet or we're in trouble. Understood?"  
Rinne nodded vigorously. Yuu removed his hand, guided her to a chair by the shoulders, then sat and removed his glasses, sweeping aside his bangs.

Hearing his voice left Rinne half-doubting, but seeing his eyes made her gasp. Covering her mouth, her eyes welled and cheeks flushed. Yuu smiled and patted his lap.

"Come here."  
"Eh... ah..."  
"Don't want to sit?"

Rinne shook her head wildly. "Excuse me," she said formally, then sat sideways on Yuu's lap, legs together.

"Rinne."  
"Yu-Yuu-sama! I've missed you so much!"

She twisted around and clung to him. Even through her thick habit, her voluptuous body felt soft. Rinne sobbed uncontrollably, gripping him tightly.

*Huff, huff, suu-haa, suu-haa... It's definitely Yuu-sama's scent. Kuhuu... I can't stand it!*

Her formal speech vanished as she grew excited. After nearly half a year of abstinence, her reaction was understandable. Yuu gently stroked her head and back.

After savoring Yuu's scent, Rinne looked up. "I'm truly shocked. Yuu-sama looks unexpectedly good in women's clothing."  
"Sayaka and others went all out to make it convincing."  
"Ah... Sayaka-san."

They gazed at each other. At their first meeting, Rinne wore heavy makeup and a shortened uniform skirt. Now barefaced in a full habit while Yuu wore makeup felt ironic.

"I came to tell you something important."  
"Wh-what is it...?"

Rinne stiffened, dropping her gaze as if expecting bad news.

Previously, Yuu had trained Rinne at a hotel, making her his mistress. Through experiencing the joy of Yuu's affection, she shed her family's rigid teachings and softened, reconciling with Sayaka through a threesome. In this world, mistresses weren't stigmatized - the line between wife and mistress was blurred, with mistresses bearing children openly. Wealthy women often took young lovers if unable to conceive with husbands.

Rinne assumed their relationship relied on her Nikko Industries heiress status.

Yuu poked her nose. "Kyan!" she cried cutely, covering it.  
"What nonsense. Your family doesn't matter. This is between us. You're still my woman. Aren't you?"  
"Ha..."

Tears welled in Rinne's eyes. "Waaah!" she cried, clinging again. Yuu stroked her head, whispering in her ear.

"I'll definitely impregnate you after graduation. Bear my child."

Few phrases pleased women more in this world. Yuu had ejaculated inside Rinne over five times - enough to count on both hands - but she hadn't conceived. Perhaps she had low fertility. Still, Yuu intended to impregnate her.

"Uu, uu... I-I thought... *hic*... you'd discarded me... uuOOOOOH!"

Had Yuu come to end things, he wouldn't have put her on his lap. But months apart during family turmoil and school transfers had made Rinne anxious. The haughty young lady was gone - Rinne cried like a child, face wet with tears and snot.

"Here, wipe." Yuu offered his handkerchief.  
"I-I've made it dirty... I'll wash and return it."  
"Keep it."  
"Feh!? I-I'll hold you to that!"

She brightened instantly at keeping Yuu's used handkerchief.

"Rinne."

Yuu lifted her chin. He kissed her lightly. When they parted, red lipstick stained Rinne's lips.

"My lipstick got on you this time."  
"Fufu, indeed. Ahn!"  
"What's this outfit?"

Yuu's left hand groped her chest through the thick habit. He wanted to undress her but found no buttons or zippers. The black scapular habit had open sides but covered her from head to ankle with an inner tunic, revealing almost no skin.

"I want more kisses, but you have no makeup to fix this... I know!"

Yuu lifted Rinne by her back and knees. Though startled, her expression quickly turned blissful. Holding her was strenuous since Rinne was only slightly shorter, but Yuu's training allowed it briefly. Carrying her princess-style, he set her in his chair, then stood facing the door and removed his coat.

As Yuu unbuttoned his jacket and unbuckled his pants, Rinne understood. Her expression filled with anticipation.

"Let's have my cock greet you properly after so long."  
"Y-yes!"

Eagerly, Rinne pulled down Yuu's slacks and underwear together. Already semi-erect from feeling her bottom earlier, his cock emerged. Rinne touched it reverently.

"Kuhu. Long time no see, Yuu-sama's cock. Ah, already rising... haa! So energetic! Growing harder by the moment!"

Her close inspection and gentle massage made his cock respond - blood rushed in, making it stand erect. Rinne stroked it while nuzzling her cheek against it, sighing contentedly.

"Aha."  
"Play with it as you like."  
"Leave it to me."

Rinne looked up with the expression of a bitch before a treat, mouth slack and nearly drooling. She explored every inch with her beautiful fingers before growing bolder. Her right hand stroked slowly from glans to base while her left massaged his balls. When precum appeared, Rinne pursed her lips to kiss it away, diligently licking every drop. Her reaction to his cock seemed stronger than to seeing his face. Yuu smiled wryly but petted her head.

As a corporate heiress and council president, Rinne could have had multiple boys. But for two years, she'd only kept elementary-aged servants without sex, resigned to never satisfying women sexually. After Yuu raped her, she learned female pleasure. Her body now craved Yuu, and abstinence left her starved.

"Whoa! Good. Feels great when you suck me."  
"Mufu."

Rinne smiled up at him with the glans in her mouth. Yuu noticed her white thighs exposed - she'd expertly hiked her habit and was fingering herself. Perhaps dorm life restricted masturbation. She deserved this pleasure.

"Nmm, nmo... ofu... afuun... Your cock is so... nn... magnificent. So hard and hot. Huff... just sucking it makes me... nn, nn, nnnn!"

Her face - once unthinkably lewd - now licked his entire cock with her tongue. After coating it in saliva, she deepthroated him, sucking hard. Her right hand stroked perfectly while her left finger-fucked herself. Squelching sounds came from her panties.

"Ah, I'm close. You'll swallow it all, right?"

Rinne smiled around his cock - she wouldn't let go even if refused. Instead, she prodded his urethra with her tongue, urging ejaculation. Yuu cupped her face and thrust his hips - performing irrumatio (face-fucking), which only Elena and Rinne enjoyed.

*Gluck, gluck* sounds echoed. Muffled moans escaped Rinne. She sped up her left hand while wrapping her right arm around Yuu's waist.

"Ooh, ooh, Rinne's mouth pussy... good! I'm... cumming... ejaculating!"  
"Ofu... nmo, o', o'... iu... nnnnn~~~~~~n!"

Yuu pulled back slightly and released into her mouth. Rinne came as hot semen flooded her mouth, her fingers still pumping furiously. Though the volume threatened to overflow, she swallowed every drop despite climaxing violently.

After thorough cleaning with her mouth, Rinne reluctantly released him.

"Rinne, that felt amazing. Thank you."  
"No... I'm the one who received Yuu-sama's essence. This will sustain me."  
"R-right."  
"Yes! Once more... Yuu-sama, I adore you. Though unworthy, I beg your continued favor."  
"Mitsuse Rinne will remain Hirose Yuu's mistress forever. I'll visit again after graduation."

Yuu stroked her head. Rinne smiled radiantly.

---

### Author's Afterword

I'd half-forgotten about Mitsuse Rinne (みつせ りんね) amid other writing priorities, but she played important roles in Chapters 5-6. Realizing her story needed closure, I wrote this.

She's changed considerably since her debut.

2022/2/8  
Added follow-up about Amir, the boy who served as Rinne's personal attendant in the Saiei Academy student council room.

### Chapter Translation Notes
- Translated "愛人契約" as "mistress contract" to maintain explicit terminology
- Preserved "-sama" honorific and Japanese name order (Mitsuse Rinne)
- Translated sexual acts explicitly: "フェラチオ" as "fellatio", "イラマチオ" as "irrumatio"
- Transliterated sound effects: "ぐぽっ" as "gluck", "ごくごく" as "gulp"
- Maintained cultural terms: "シスター" as "nun", "修道服" as "habit"
- Used "cock" for "チンポ" per explicit terminology rule
- Formatted internal monologues in *italics* (e.g., Rinne's thoughts)
- Preserved business terminology: "名刺" as "business cards"