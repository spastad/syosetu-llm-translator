## 368. Making Memories ① ~Premonition of Farewell~

### Author's Preface

Do you remember Amir, the boy who served as Rinne's attendant in the Saiei Academy student council? (Refer to 150. At Saiei Academy ③)

When writing about Rinne's aftermath in the previous chapter, I hesitated whether to include Amir but ultimately didn't mention him. I've decided to include him now. I've added this after initially writing that Rinne left home.

The story flow remains unchanged.

---

March is a season of farewells.

Schools hold graduation ceremonies, and corporations implement annual personnel transfers as part of their routine.

At Sairei Academy High School, Yuu becoming student council president gained nationwide attention, causing a surge in applicants.

Consequently, both male and female enrollments will increase starting next academic year.

With nearly one additional class for both genders, urgent staff increases were approved.

Unlike public schools with regular transfers, private school transfers are limited. Still, some must leave due to circumstances.

Requests to Yuu, the student council president, continue incessantly despite passing their peak.

With only one Yuu and official student council duties, most requests are declined. Among these, Yuu personally chose to accept one: showing appreciation to faculty and staff leaving Sairei Academy at March's end.

Yuu, who loves working women, had grown close to office workers and female faculty members. He wanted to bid farewell.

One transfer is mathematics teacher for male classes, Dei Kazuko (33, single). She has a 6-year-old daughter conceived through artificial insemination.

Last year's student council scandal at Saiei Academy revealed deep connections between some teachers and the student council, including favors and benefits. Four were fired, three received pay cuts. While the vice principal acted as interim principal, new graduates and transfers from sister schools will fill vacancies next term.

Though Sairei Academy shouldn't have transfers, Kazuko was selected due to her poorly concealed lust toward male students (unpopular except with Yuu). Her replacement has already been recruited from another private high.

The other is office worker Watanabe Kazuyo (30, single with 7-year-old daughter). Her transfer is due to family circumstances.

Her mother runs an inn in Saito Station's rapidly developing downtown area since the private railway station opened. Since last autumn, women visiting Saito City for Yuu dramatically increased.

While hotels, inns, and restaurants prosper, overcrowding caused staff shortages. New establishments are planned but can't immediately expand capacity. Kazuyo's mother's inn is no exception, so she wants Kazuyo to manage operations while training as successor.

Truthfully, neither Kazuko nor Kazuyo want to leave Sairei Academy where Yuu attends. But since they're not moving far from Yuu's residence/school, they accepted after persuasion.

Though transfers take effect March 31, notices came early due to handover procedures. Both requested time with Yuu before spring break.

"Are you sure it's here?"  
"Yes. We received direct contact from Hirose-kun himself."

On March 8 after school, Kazuko and Kazuyo wait in Building 3's third-floor Classroom 3-1.

Third-years have had voluntary attendance since February with no regular classes. Unlike other schools, no students need remedial lessons or make-up exams. Normally, only couples meeting safely on campus or sports students mentoring underclassmen would be present.

But this year, many third-year girls loiter near the student council room and throughout campus hoping to encounter Yuu. Rumors spread that Yuu happened to walk around after school, got approached by three third-years, and went to the Special Male-Female Interaction Room for sex. Incidentally, the rumor is true.

Regardless, the third-floor corridor with senior classrooms is deserted and silent except for Kazuko and Kazuyo. Neither are extroverted, but sharing similar circumstances as single mothers created common ground. While waiting for Yuu, they chatted mostly about their daughters.

"Dei-sensei, you're not moving, right? That's good. No need for your daughter to transfer schools."  
"True, but my commute gets longer. I worry about leaving her alone more."  
"Well, elementary schoolers have to rely on after-school care."

Kazuko sighed softly. She lives in an apartment with her daughter. Worried about her young child being alone long hours.

Kazuyo will live in her mother's inn annex with three generations including an aunt. Though expecting busy work, eliminating commuting is a plus.

However, Kazuyo felt slightly exasperated seeing Kazuko's outfit. When did she change? The bright red designer suit with shoulder pads was trendy years ago. Despite winter, the purple innerwear fails to cover her cleavage, emphasizing her deep valley. The tight skirt is extremely short, exposing plump thighs. Usually tied in a messy bun, her wavy black hair now falls to her chest in a shag cut. Gold earrings glint, makeup is perfect, though perfume seems restrained for school.

Unlike petite Kazuyo, the flashy suit doesn't look bad on sturdy-framed Kazuko. But Kazuyo thought it oddly youthful for a 33-year-old. While ordinary men would avoid this, she clearly expects Yuu to like it.

Meanwhile, Kazuyo wears her usual drab dark gray work suit with knee-length tight skirt and thick black tights for warmth. Hair in a tight bun with silver-rimmed glasses - the epitome of a plain office worker.

Not particularly beautiful, both share plain looks. Kazuyo regretted not dressing nicer or applying more makeup for Yuu.

Still, Kazuyo doesn't know how to appeal to young men. Though hired at Sairei Academy, she's lived a manless life. Until Yuu. Young office worker Gonda Sakiko said Yuu likes women in suits, but Kazuyo doubted it. After all, Yuu shows warmth to every woman on campus. Surely he prefers young, lively students over thirty-somethings like her.

Yet Yuu always greets her with a smile when visiting the office. Once, they nearly collided at the entrance, and he caught her in his arms. She couldn't suppress her thrill when wrapped in Yuu's arms, whispered "Sorry" in her ear. She's replayed that moment countless times...

"Sorry I'm late!"

Over an hour passed since last class ended. Though days lengthen in March, sunset already streams into the classroom. Twilight time.

While Kazuyo and Kazuko chatted nonstop, they turned toward the entrance upon hearing a familiar voice.

Yuu leaned against the door facing them, breathing heavily.

The setting sun through the window illuminated him perfectly.

Like a spotlight.

Kazuyo and Kazuko almost mistook him for a descending angel.

Yuu encountered over ten third-year girls while heading from the student council room to the building. Being seniors at his school, and given his personality, he couldn't ignore or reject girls showing affection.

Like - no, more than - an idol surrounded by fervent fans, he charmed them, hugging each one. The group swelled to nearly thirty. Realizing he'd taken too long, he sprinted up to the third floor.

"Hirose-kunnn!!"

Their daze lasted only a moment.

Kazuko dashed forward first.

Though backlit, Yuu recognized the large-framed woman with jiggling large breasts as his math teacher who'd looked after him for a year.

After shutting the door behind him, Yuu caught the approaching Kazuko.

"Sensei, you look super sexy and stylish today!"  
"R-really?"  
"Yeah! Kazuko-sensei has great proportions - sexy, revealing clothes suit you perfectly. It's getting me excited. Oh, you're wearing earrings today too. Beautiful!"  
"Wahh..."

Yuu lacks fashion confidence but knows to compliment women who dress up. Embracing Kazuko's voluptuous body, he whispered in her ear. Excited by her breasts against his chest, his right hand slid down to firmly grasp her large buttocks.

Kazuko already wore the face of a fallen woman. Though fortunate to be chosen for the co-ed school's male classes, her hidden lust showed in her eyes, making her unpopular with male students despite lacking romantic experience.

But Yuu was the exception. In late June when Kazuko wore lighter clothing, Yuu got aroused and took her to the Special Male-Female Interaction Room for her first time. Though that was their only full intercourse, math-struggling Yuu visited the math prep room several times for tutoring. When alone, he'd cling and act spoiled.

Once, she even titfucked him and swallowed his cum - an unforgettable memory for Kazuko. She loves Yuu beyond teacher-student boundaries, especially since he calls her by name.

Her thighs rubbed together during their long-awaited embrace because she was already wet.

Yuu patted Kazuko's head lightly before pulling away. She gazed at him wistfully. Watching them, you couldn't tell who was the adult.

"Kazuyo-san"  
"Hyah, yes!"

As Kazuyo stood dumbfounded, Yuu approached. Kazuko secretly closed in behind him, but Kazuyo only saw Yuu.

Compared to Kazuko who'd slept with him, Yuu acted more reserved with Kazuyo.

Yuu extended his right hand like inviting her to dance. Hesitant but envious of their earlier embrace, Kazuyo mustered courage to take it.

Before she knew it, her petite body fit snugly in Yuu's arms.

"I wanted to get closer to you, Kazuyo-san. I'm sad you're transferring."  
"Ah, ah, um... that..."  
"So today, in our limited time, I want us to get really close."  
"H-hai"

Crushed against his firm chest, unable to move, Kazuyo's heart swirled with joy. Flushed and speechless, she couldn't meet his eyes. Replying to Yuu's whispers took all her effort.

---

The deserted classroom felt chilly, but office worker Kazuyo had arranged for heaters by the window to warm it. As sunset neared the horizon, three desks and chairs faced the window. Candles flickered on the desks alongside shortcakes, snacks, and under-1%-alcohol champagne - a modest farewell party evoking off-season Christmas.

Though they could've used the Special Male-Female Interaction Room (campus love hotel), Yuu wanted intimate time with women in a nighttime classroom, having enjoyed himself with third-year sports seniors during the cultural festival. His middle-aged soul desired fun with single-mother teacher and office worker.

For Kazuko and Kazuyo, anywhere was fine if Yuu was there.

Sandwiched between them, Yuu sat with Kazuko pressed close on his right, Kazuyo on his left. Yuu poured champagne into their plastic cups; they each poured half into his.

"Now... to Kazuko-sensei and Kazuyo-san's future... cheers!"  
""Cheers!""

They chatted while eating and drinking. As a father of nine, Yuu focused on their parenting futures.

Kazuyo's daughter Miwa - whom Yuu met at the cultural festival - had pigtails and big eyes, seeming promising. She fearlessly spoke to Yuu, making Kazuyo fluster.

When asking about Kazuko's daughter, he learned her name was Suzune (starting second grade in April). Kazuko showed a wallet photo - likely at an amusement park. Wearing a white dress with flower patterns and peace sign, she had long black hair and a chubby build, seeming gentle. She resembled Goto Mashiro from Class 1-5.

"Suzune-chan is so cute!"  
"R-really? She's gentle and thoughtful - truly adorable, unlike her parent."

Kazuko smiled with naked parental pride. Hearing them, Yuu saw both valued their daughters despite full-time jobs. As a child-lover, this impressed him.

Stopping mid-bite, Yuu wrapped his arms around both women's waists. Kazuko showed open delight, Kazuyo shyly gazed at him. Looking between them, Yuu said:

"Wouldn't it be great if their little sister... or brother... was conceived here?"

---

### Author's Afterword

Math teacher Dei Kazuko reappears for the first time since Chapter 105.

Those shoulder-padded suits popular in the 80s... I still wonder why women wore them too, not just men.

### Chapter Translation Notes
- Translated "むっつりスケベ" as "hidden lust" to convey repressed sexual desire while maintaining nuance
- Rendered "精飲" as "swallowed his cum" following explicit terminology rules
- Preserved "センセ" as "Sensei" as an honorific while adapting to English context
- Translated "ときめき" as "thrill" to capture emotional excitement in the context
- Used "titfucked" for "乳房でチンポを挟んでしごき" per explicit terminology requirements
- Kept "Special Male-Female Interaction Room" as established term from Fixed Reference
- Transliterated sound effects like "わはぁ" as "Wahh" and "ひゃ" as "Hyah"