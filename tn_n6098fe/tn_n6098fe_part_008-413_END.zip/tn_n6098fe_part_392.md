## 369. Making Memories ② ~Tonight for Sure~

"Hirose-kun!"

The one who not only hugged Yuu the moment she heard his words but also planted a *bucchu* kiss on his cheek was Kazuko.

Even without looking, Yuu could imagine a splendid kiss mark had formed on his cheek, but he only gave a wry smile.

*(In his previous life, he had heard a theory that women become more sexually active in their 30s. Though it had no scientific basis, perhaps there was a tendency to become obsessed with men due to anxiety about age. From Yuu's experience, women in this world were sexually voracious at any age. Among them, Kazuko was either bad at hiding it or had become overly excited from being in charge of a boys' class for the first time, resulting in a vicious cycle of sending rude glances and being disliked.)*

However, Yuu alone accepted Kazuko without disliking her. When he went to the math preparation room to study and they were alone, Yuu would cling to her, making Kazuko happy. Thanks to that, Kazuko became fixated only on Yuu and was able to suppress her ulterior motives in front of other boys. But her initial impression was so bad that her image never improved.

At any rate, Yuu turned to Kazuko with a smile and pressed his lips against hers. They kissed as if savoring the sensation of each other's lips while changing angles, then simultaneously extended their tongues and intertwined them.

"*Chupa, juru, muchuuuu... uhi, Hirose-kun (hiyoshekyun) kishuu... kimohiii... my head is melting... nmu, nma, lero, leroo, chupaa... unchu! Haah, haah, more!*"

Even while kissing, Kazuko's hands were busily groping Yuu's chest and back. Kazuko had become like a predator devouring the essence of a young man, but Yuu was not losing either. He brought his hands from her back to the front and grabbed the large breasts protruding from the gap in her jacket, kneading them.

The intense oral sex—more like devouring each other's mouths than kissing—lasted several minutes. When Yuu pulled away, several strands of saliva connected their tongues and mouths. Yuu's hand had forcibly pulled down the neckline of her innerwear. It seemed to double as a bra, and his fingers reached directly to her breasts through the cup gap. While kneading the large breast with his right hand, Yuu turned to Kazuyo.

Kazuyo had been watching Yuu and Kazuko's intense kiss with stunned eyes, but when she noticed Yuu looking at her, she blushed.

"Kazuyo-san, shall we kiss?"  
"H-Hirose-kun..."

Kazuyo, who had no immunity to men, only opened and closed her mouth without being able to continue. Seeing Yuu's wet lips, her heart pounded so loudly it was noisy. Yuu, considerate of Kazuyo, gave her a light kiss where their lips barely touched.

"Could you take off your glasses?"  
"Ah, yes."

If he tried to kiss her like he did with Kazuko, the glasses might get in the way. Kazuyo removed her silver-rimmed glasses and put them in her jacket pocket. Without her glasses, Kazuyo's eyes were double-lidded but wide with long eyelashes. She might not be called a beauty, but her features weren't bad. Though he heard she was 30, her skin looked youthful enough to pass for her 20s. With a quiet, unobtrusive personality, she might be the type who could transform with care and makeup.

"Kazuyo-san, you're cute."  
"Eh? Me?"

Without letting her continue, Yuu kissed her. At first, Yuu had been somewhat reserved with the inexperienced Kazuyo. However, he was quite aroused from the deep kiss with Kazuko. Seeing Kazuyo without glasses unexpectedly cute, he couldn't suppress his lust. From behind, Kazuko rubbed her voluptuous body against him while running her tongue over his ear.

Yuu wrapped his left arm around Kazuyo and pressed his lips against hers, then inserted his tongue. In truth, Kazuyo herself was sufficiently excited, though she couldn't clearly express it. She not only gladly accepted Yuu but clung tightly with both hands. With Yuu's tongue, now without reservation, ravaging her mouth, Kazuyo let out sweet moans and melted.

"Shall we take off our clothes?"

After thoroughly enjoying oral pleasure with Kazuyo, Yuu spoke to the two, his lips glistening with saliva. Kazuyo seemed unable to process Yuu's words, staring blankly. Kazuko, on the other hand, had already taken off her jacket before Yuu finished speaking.

Even though the heating had started working, they wouldn't go completely naked. No, for Yuu, partial clothing was what felt erotic. Kazuko, who had taken off her jacket and skirt and let her innerwear's chest slip out, was the closest to naked. Kazuyo also took off her dark gray suit jacket and pants and the sweater underneath. She wore a white blouse with buttons undone to the middle and black tights—an arousing outfit for Yuu.

"I knew Kazuko-sensei had a dynamite body, but Kazuyo-san, you have a great figure too."  
"Eh, really?"

He knew that Kazuko, who had been in the volleyball club in high school and had been an advisor before coming to Sairei Academy, had well-developed shoulder muscles and was a self-proclaimed F-cup. Her hips were large, but her stomach was tight, giving her an excellent proportion. She had complained that the fat around her waist wouldn't come off after giving birth, but considering her age of 33, she maintained it well.

When undressed, Kazuyo wasn't far behind. He could imagine from her suit that her chest was large, and upon asking, she said she was an E-cup. Her hips and thighs were plump and firm. As a mother, she had a little fat on her stomach, but that plumpness seemed like it would feel good to hold. Of course, the two also had their eyes shining at Yuu's figure, now only in his shirt and pants, drooling as if they couldn't help it.

"Ahh, Hirose-kun! I love you, love you, I love you so much!"  
"M-me too... I've always admired you, Hirose-kun... ooh!"  
"Aha, thank you. I like you too, Kazuko-sensei and Kazuyo-san."

Yuu's "like" was the "like (LOVE)" he felt for many women he favored, but the two's "like" might be closer to "passionate love" or "adoration" for the one and only Yuu. The intensity of their feelings was different. Moreover, not only Kazuko but even Kazuyo had their switches flipped from the deep kiss earlier. Like two female dogs playing, they rubbed their bodies against him and competed to kiss him. While Kazuko devoured Yuu's mouth, Kazuyo also stuck out her tongue. Rather than taking turns, it was as if both were intertwining their tongues simultaneously.

The buttons on the front of Yuu's shirt were all undone, and his inner T-shirt was rolled up, while the two women's hands busily groped his chest, stomach, and back. Yuu, too, was kneading the two women's exposed breasts to his heart's content. Their large breasts were so soft that he wanted to knead them forever. As he kneaded with his palms, including the nipples, both Kazuko and Kazuyo moaned sweetly and writhed. Yet, their mouths and hands didn't rest.

"*Chu, chu, lerochu! Ann! My boobs, knead them more... being kneaded by Hirose-kun feels so good...*"  
"*Haah, haah, the feel of Hirose-kun's skin, his smell, I could get addicted... ah, ah, I can't believe my breasts feel this... aahn! Hirose-kuuun!*"  
"Whoa... it's dangerous, so shall we sit on the floor?"

Yuu was sitting on a chair in the middle, sandwiched tightly, but the momentum of the two aroused women was too strong. Especially Kazuko, being large-framed, her hips and legs bumped against the desk, and they might tip over from the chair.

So Yuu got off the chair, but he made a request to the two: to take off their panties while sitting. Without hesitation, Kazuko and Kazuyo quickly took them off in front of Yuu and spread their legs.

Kazuko wore red, translucent lace panties. While taking them off, her love juice stretched in a string with a *nicha* sound. Kazuyo took off her black tights. Tights and stockings were hard for men to distinguish, but generally, tights were thicker for warmth. Impatient, Kazuyo took off her black tights and white panties at the same time.

Kazuyo had a typical inverted triangle of black pubic hair. On the other hand, Kazuko's pubic hair was among the thickest Yuu had seen, bushy. He had heard that hairy people, both men and women, had strong sexual desires—something about high testosterone. He didn't know how true that was, but it was certain that Kazuko was quite lewd. That's what Yuu thought from what he'd seen so far. The pubic hair of both was soaked in the lower half due to the copious secretion of love juice. But Kazuko had only been with one man (Yuu) before. Kazuyo also seemed to have no male experience, as the inside of her naturally spread labia was a vivid salmon pink—unusually clean for her age.

"Kazuko-sensei and Kazuyo-san, you're both so beautiful and erotic!"

Yuu extended his hands to the two women's vaginas. Since they were facing each other, Kazuko was now on the left and Kazuyo on the right. The moment he touched the inside of their labia, love juice immediately clung to Yuu's fingertips, making *kuchu kuchu* wet sounds with every movement.

"Aahn! Hirose-kun! More, touch sensei's pussy! Good! Hirose-kun's fingers, aaah!"  
"Nnfuu... Hirose-kun is... touching my... ah, ah, I'm thrilled, kufu, nnn!"

While fingering both vaginas simultaneously, Yuu took one of Kazuko's trembling breasts into his mouth. When he rolled her large nipple with his tongue or sucked on it, Kazuko's moans grew louder. With just a little stimulation, a squirt of fluid jumped from Kazuko's vagina. She seemed to be genuinely aroused, reaching climax soon after starting the fingering.

Without hesitation, he inserted his middle finger into Kazuko's already penetrated vagina. For Kazuyo, he focused on soft touches around her clitoris. Kazuyo, bewildered by the pleasure she was experiencing for the first time, grabbed Yuu's shoulders and cried out in delight. Just as Yuu was about to move to Kazuyo's breasts, Kazuko suddenly grabbed his head and pressed it against her breasts.

"Ooh! Fooh! Already... Hirose-kun's finger and cock feel too good! Ahe... i... I'm cumming, cumming, I'm cumming! Ah... faaaaaaaaah!"

The middle finger inserted in Kazuko's vagina was tightly squeezed, and her hips shook violently.

"Pffu... Sensei, did you already cum?"  
"Ehe, ehehehe... It's been so long since Hirose-kun played with my pussy... my body was overjoyed."

Not premature ejaculation, but rather a weak pussy. But Yuu was happy that she felt it so much. He actually found the fully unleashed desire of the female teacher preferable. He had Kazuko, who had just cum, go behind him and take off his pants. She immediately hugged him from behind, kissing the nape of his neck while reaching her hands forward to touch his powerfully erect cock.

Meanwhile, Yuu continued fingering Kazuyo in a kneeling position. He took her soft breast into his mouth and tormented it persistently, using both hands to play with her clitoris and vagina. Yuu was seriously trying to make Kazuyo cum. Just receiving the caresses of the admired Yuu was enough; it was only a matter of time before Kazuyo reached her climax.

"Haah, aaah! H-Hiroshhekuu... ahi! I-I'm... this is unbelievably good... ah, ah, ah, I'm cumming! I'm cumming! Haun! I'm cumming! Aaaaaaaaaaah!"

At that moment, Kazuyo clung tightly to Yuu. The pleasure and euphoria, incomparable to masturbation, blew away her reason. Contrary to her quiet appearance, she let out a scream.

"Hey, hey, Hirose-kun, ha, hurry, let's do it? Your cock, your cock, your cock! This... hard and hot, magnificent cock..."

While Kazuyo lay sprawled with a dazed expression after her climax, the fully prepared Kazuko clung to Yuu from behind, fiddling with his cock with both hands. Her mind was filled only with the desire to have that hot, hard meat rod inserted into her vagina. She wished from the bottom of her heart to be creampied, to have his seed fill her womb, and to finally get pregnant with Yuu's child. Yuu understood her feelings, but he had already decided on the first one for tonight.

"Sensei, sorry. Tonight, I plan to take Kazuyo-san's virginity first. Instead, could you suck it to make it easier to insert?"  
"Eh, eh..."

Though Kazuko seemed to have left her reason behind and was full of desire, she apparently didn't go so far as to force her way to be first against Yuu's wishes. Yuu wasn't a man who finished with one ejaculation. Remembering that when they had sex in the Special Male-Female Interaction Room, he had creampied her three times, she reluctantly agreed. Rather, she drooled like a dog at the thought of being able to suck Yuu's cock.

"Haah, haah... I-I can't believe it. Hirose-kun is my first..."

Lying on her back on three desks pushed together was Kazuyo. Her tied-up black hair had come loose and spread out. The front of her blouse was open, her bra unhooked, exposing her breasts, and her legs spread with Yuu between them. It was a situation he had wanted to try in a classroom. He never thought he'd do it with Kazuyo, who was neither a student nor a teacher but an office worker.

Leaning over from Kazuyo's side, with her face buried in Yuu's crotch, was Kazuko. Holding Yuu's waist firmly with one hand, she licked from the tip to the base. Kazuko's expression, with her red tongue out licking the pre-cum that overflowed, was pure happiness. She seemed to be coating his entire cock with her saliva mixed in her mouth.

"Ah, Kazuko-sensei, that feels amazing. But I want to cum inside Kazuyo-san. Sorry."

When Yuu gently stroked her head and spoke, Kazuko reluctantly pulled her mouth away. A string of saliva stretched from her extended tongue, so she gave the glans one last *chu* kiss and backed off. However, she didn't wait idly; she went behind Yuu and hugged him. Not wanting to waste a moment, she wanted to touch Yuu. Yuu didn't push her away and, while being clung to, moved his hips closer to Kazuyo's entrance, grabbing her thighs with both hands.

"Well then, Kazuyo-san, I'm going to insert it."

Kazuyo, with a mix of tension and expectation on her face, nodded repeatedly.

---

### Author's Afterword

Doing it in a night classroom, which you normally wouldn't enter, has a nice sense of the extraordinary, doesn't it?

### Chapter Translation Notes
- Translated "口性交" as "oral sex" in the context of intense mouth-to-mouth kissing, as per explicit terminology requirement. Note: This term in Japanese refers to passionate kissing involving the mouth and tongue, not fellatio.
- Preserved honorifics: "-kun", "-sensei", and "-san" as per the original.
- Transliterated sound effects (e.g., *bucchu*, *chupa*, *nicha*, *kuchu kuchu*).
- Used explicit terms for body parts and sexual acts: "pussy", "cock", "fingering", "cum", etc.
- Translated "おマンコ" as "pussy" and "チンポ" as "cock" consistently.
- Maintained the original Japanese name order: "Hirose Yuu", "Dei Kazuko", "Watanabe Kazuyo".
- For the term "雑魚マンコ" (zako manko), translated as "weak pussy" to convey the meaning of being quick to orgasm.
- The internal monologue section (marked by parentheses in the original) is rendered in italics and enclosed in `*( ... )*`.
- New dialogue lines start on new paragraphs, except when preceded by an attribution (e.g., `祐が優しく頭を撫でて言葉をかければ` -> `When Yuu gently stroked her head and spoke,` followed by the dialogue on the same line).