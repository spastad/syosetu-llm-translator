## 370. Making Memories ③ ~Amidst Limitless Desire~

"O-o-oh... what incredible... K-Kazuyo-san's vagina... amazing tightness... feels too good!"

"Haa, haa, haa... D-does it feel good? My pussy..."

"Ah, it's the best, Kazuyo-san."

There was no lie in Yuu's words. With his cock fully inserted, he leaned over Kazuyo and kissed her. At 30 years old, receiving the cock of her adored Yuu for the first time overwhelmed Kazuyo with emotion, and she hugged him tightly with both hands. Kazuko remained clinging to his back as before. Yuu was sandwiched between female bodies.

Surprisingly, Kazuyo's vaginal opening accepted Yuu smoothly despite being her first time. But it immediately began squeezing him tightly. Kazuyo had given birth through artificial insemination - a baby's head larger than a penis had passed through her birth canal. After seven years, it had naturally recovered. Thus, while fitting Yuu's cock perfectly, she still maintained virgin-like tightness. Even without moving, she provided Yuu with supreme pleasure.

"I'll move slowly now."  
"Ha, haaaiiii... nkuh... Hirose-kun's... big one... aahh!"

After pausing to savor her vagina, Yuu pulled his lips away and began moving slowly while gazing at Kazuyo. In reality, he could only make small, grinding movements, which was fortunate given the unstable desk surface. Grabbing Kazuyo's shoulders and hips firmly, he slowly pulled his hips back, stopping when the glans caught, then thrusting deep into the narrow vagina as if carving through it. Vaginal folds entangled his cock with each thrust. Holding Kazuyo's body while moving with slow, deep strokes felt just right now.

"A-a-a-afuu! H-Hirose-kuu... nnnh!"  
"Oh fuu... K-Kazuyo-san! Your pussy feels great!"

Kazuyo's vagina, receiving a man for the first time at 30 despite being a mother, provided unexpectedly intense pleasure to Yuu. Kazuyo herself seemed to be climaxing from the start without experiencing defloration pain. They moaned each other's names while losing themselves in sensation.

"Nmuah... lero leroo... Hirose-kun's skin tastes delicious..."  
"Kuaah!"  
"Ahyun! Your cock! D-deep! So deeeep!"

Kazuko pressed her large breasts against Yuu's back while playing with his nipples and licking from his nape to his back. Yuu thrust deep into Kazuyo's vaginal depths and buried his face in soft breasts. Kazuyo reflexively threw her head back - a chain reaction of pleasure.

Yuu held Kazuyo's head with his right hand while kneading her breast with his left, gradually speeding up his hip movements. As Yuu moved, sticky "jupu jupu" sounds came from their joining area. Their mixed love juices dripped enough to form puddles on the floor. Not just Yuu in his sandwiched state, but sweat glistened on Kazuyo's forehead and chest too.

"Haa, haa, kuh! K-Kazuyo-san"  
"Vun! H-Hirose-kuun..."

Though 14 years apart in actual age, Yuu and Kazuyo gazed at each other like passionate lovers, calling each other's names before kissing. Not just that - they eagerly entwined tongues. With each small thrust, dull "pashin pashin" sounds echoed.

"Nnaa... I'm gonna cum soon..."  
"Au... nh, haa! Cum... cum inside me... fill me up!"  
"Gladly. I'll ejaculate plenty and impregnate you, Kazuyo-san! Oouh! Tightening again!"

As if sensing Yuu's approaching climax, Kazuyo's body squeezed his glans with a milking motion. Yuu couldn't withstand this. He gave a final sprint, thrusting deep enough to grind against her cervix before climaxing. Burying his face in Kazuyo's chest, Yuu surrendered to immense pleasure. Thick semen pumped powerfully inside.

"Hahyu! Shugoo... oo, kuu... inside... so full... ahhaaaaaaaah!"

Filled with massive semen, Kazuyo let out an unprecedented moan of pleasure. Simultaneously, she was flooded with euphoria and fulfillment - not violent but a floating ecstasy.

"Hirose-kun! Now it's my turn! Let's make babies, Sensei! Okay? Okay? Can I ride you? Hurry, put that cock inside me!"  
"O-okay, okay, I get it."

As Yuu pulled his cock from Kazuyo's vagina, Kazuko dragged him away while clinging to his back, pulling him near the teacher's desk. Despite their similar builds, her horny strength was formidable.

Yuu turned halfway and hugged the eager Kazuko, covering her mouth. When he extended his tongue, Kazuko passionately tangled tongues. Pressing their bodies tightly together, Yuu lowered his right hand and firmly grabbed her large butt, moving his hips in small motions. Though not genital-connected, it resembled pseudo-sex. Kazuko's face melted completely.

"Sensei, didn't I say before? Just pushing your desires one-sidedly is no different from rape."  
"Uu... r-right. Sorry."

After continuing the deep kiss awhile, Yuu gently admonished her when slightly pulling back. Even Kazuko looked chastised - their age difference became unclear.

"It's fine. I'm definitely excited too. You can tell, right?"  
"Y-yes! Even after cumming once, Hirose-kun's huge thick cock! Still hard against me!"  
"I'll properly insert it into Sensei's pussy this time. I'll make you cum over and over with a creampie."  
"Fu, fuhi. Hirose-kun! I love you!"

While stroking Kazuko's head as she rubbed against his lower abdomen, Yuu asked:

"Then, let's try your desired scenario first, Kazuko-sensei. How do you want it?"  
"Eh... Really!? Then..."

Eyes shining, Kazuko gulped audibly and licked her lips.

"Haa, haa... H-Hirose-kun! O-okay, I'll... t-take your cock now."  
"Okay, Sensei. No need to rush."

Yuu stood on the teacher's platform leaning against the blackboard, pressed by Kazuko. Her fantasy was classroom sex with a male student - specifically standing on the platform where she usually taught. Yuu understood when imagining the reversed situation and agreed.

Kazuko seemed taller until removing clothes, but without heels their heights matched. To ease insertion, Yuu slightly lowered his hips. Facing him with ragged breath, Kazuko lowered her gaze. However, her oversized breasts blocked the view, so she guided his cock with her left hand. Feeling the rod's heat in her palm, Kazuko sighed emotionally, standing on tiptoes with slightly spread legs.

"Guuh..."  
"Nnaah! Haa... it's going in... hah, fuh, hohe... oo, your big cooock! So biiig!"

Though appearing smooth initially, reaching full depth took time since it had been awhile. Kazuko came instantly with a "pyu pyu" squirt as they fully connected. Recoiling backward, Yuu hurriedly caught her.

While Yuu often did standing sex from behind, he rarely experienced face-to-face. Hugging made movement difficult. Since Kazuko seemed immobilized by post-insertion climax, Yuu leaned against the blackboard while holding her.

"Sensei, okay?"  
"Ah, thank you. Aah, Hirose-kun's too kind, I'm crying. I'm fine now. I'll move well so Hirose-kun feels good too."  
"Okay. I'll leave it to you."

Yuu leaned against the blackboard while slightly lowering his hips. This allowed Kazuko to move without tiptoeing.

"Nhaa, ah, uun! A-amazing... my pussy, Hirose-kun's thick cock... oh fuu... d-deep, penetrated deep! Feels great! So happy... overflowing happiness... haan! The best!"

Pressing her voluptuous upper body against him while hugging Yuu's head, Kazuko moaned while managing to move her hips. Perhaps because constant deep penetration from his weight kept her filled post-climax, Kazuko seemed out of her mind.

Objectively, it appeared like a lustful female teacher assaulting a male student. Actually, Yuu supported her hips with both hands for inexperienced Kazuko.

"Foh! Ooh... no... akuun! S-sorry... senseii... I'm cummming agaaain!"  
"It's fine. Sensei, come on, cum as much as you want."  
"Ahee!"

When Yuu ground his hips, Kazuko reflexively threw her head back and moaned. Fulfilling her Yuu fantasy left her pussy defenseless. Another massive squirt splattered juice across the platform and desk.

After climaxing twice quickly, Kazuko went limp, prompting a position change. Switching places, Yuu pressed her against the blackboard, lifting one leg with his right arm - the "Carp Climbing Waterfall" position from 48 techniques. Slightly angled but hip-aligned, this suited Yuu better. Unfamiliar with the position, he avoided roughness. Thrust deep inside, Yuu ground his hips circularly. Grabbing the prominently swaying breasts with his left hand, he kneaded while whispering.

"Sensei, more coming. Feel incredible lots more for unforgettable sex."  
"Hyaa, Hirose-kun, sex... lifetime memory... okay! Oo, oo, amazing! Uterus grinding feels so gooood... oo, oho, hitting! Aaauu!"

Moaning with head thrown back, Kazuko's head bumped the blackboard, but she seemed beyond caring. As Yuu grew accustomed, he switched to piston motions - starting small then increasing stroke depth. Each hip thrust produced dull "bachun buchun" sounds, with serious juices scattering from their union.

Though seemingly overwhelmed, Kazuko's vaginal tightness remained good from training. Perhaps her genitals remembered a cock inserted over half a year ago. Inner folds reacted, wriggling to milk semen. Thus Yuu's ejaculation urge gradually built.

"Aaeee... ooh! Ooh! Can't... cumming aaahn! H-Hirose-kun!"  
"Sensei, I'll breed you like this!"  
"Aaii! Hirose-kun's... healthy seeeemen, give me looots!"

Hearing this, Yuu accelerated his thrusts. As farewell before next month's transfer, he intended a generous creampie. Continuously tossed on pleasure's peak, Kazuko couldn't respond coherently. Holding her voluptuous body firmly, Yuu gave final sprinting thrusts.

"Ooh! I'm cumming! Sensei, ejaculating!"  
"Pyaa! Your cock, taking it! Ooh, ooh, ahi... no more... iiih... kuu"

Around Kazuko's umpteenth climax since insertion, Yuu reached his limit. For a second round, massive semen erupted. Perhaps feeling the abundant deposit inside, Kazuko hugged Yuu with a satisfied expression, sweat beads glistening on her forehead.

"Fuuh. A bit tired, maybe?"

Despite his young body, supporting one leg during standing sex was taxing. Yuu sat on a nearby chair. Kazuyo immediately approached. Having gotten off the desk unnoticed, she'd been sitting on the floor masturbating while watching Yuu and Kazuko's sex. Crawling over like a dog as Yuu sat, she begged.

"Hirose-kun, u-um... may I lick your cock?"

Naturally, Yuu consented. Beaming joyfully, Kazuyo clung to Yuu's waist and voraciously sucked his still-wet cock.

"H-Hirose-kun... let teacher lick too?"

Kazuko, who should've been sitting exhausted on the platform, had somehow approached and begged similarly.

"Then suck nicely together, you two."

Yuu extended both hands to stroke Kazuyo and Kazuko's heads. With expressions like trained bitches, they pressed voluptuous breasts against Yuu's legs and began fellatio.

Kazuko had some blowjob experience, but Kazuyo was a novice. Neither was skilled. Yet enthusiasm surpassed technique - they seemed to compete pleasuring Yuu. Large tongues licked thoroughly from base to glans, front and back. When Kazuko deep-throated the glans, Kazuyo sucked testicles. Instantly Yuu's cock became coated in their drool, mixing with precum into sticky "necho necho" wet sounds.

"Aah... feels amazing."  
"Juzozo... gokun. Hirose-kun's cock juice... delicious."  
"Puhah... ufun... your cock's so magnificent... haa, haa, just licking makes me aroused."

Delighted by their melted expressions and enthusiastic sucking, Yuu enjoyed the double teacher-staff blowjob. Having ejaculated twice gave some leeway, so he planned to savor this awhile. Gently stroking their heads, an idea struck.

"Kazuko-sensei, Kazuyo-san, may I ask a favor?"  
"Nmo?"  
"Ai?"

Switching roles - Kazuko now sucking testicles while Kazuyo kept lips on the tip - they looked at Yuu.

"I-is this okay?"  
"Aha... pressing breasts together feels kinda weird."  
"Ooh, this is a masterpiece. Keep sucking the tip together like this."

He had them kneel on either side sandwiching his cock with breasts - the dream double paizuri. Kazuko: F-cup. Kazuyo: E-cup. Though large breasts hid it completely from the sides, length left the glans exposed. Faces close, they extended tongues to lick the cock tip when urged.

"Kuu... this is unbearable!"

Both breasts felt exceptionally soft and comfortable, but more. Pressing tightly enough to hide nipples provided firm pressure. Moreover, two tongues crawled over the exposed glans. Unconcerned about touching tongues, both licked obsessively. Their saliva and precum dripped into the breast valley and tiny cock gap. Each squirm produced lewd "nucha nucha" sounds - perfect spice. With supreme visuals and sensation, Yuu soon lost composure.

"Aa, aa, dangerous..."  
"Lero lero lero roo..."  
"Chu, chupaa... feels good?"  
"Great! Feels amazing... aah, gonna cum."  
"Cum cum, Hirose-kun, give me looots!"

Sensing his nearing climax, they tightened armpits for stronger breast pressure while subtly moving back-and-forth, each sucking half the glans while stimulating with tongues. Yuu couldn't withstand this. Though planning to stop midway, resistance proved impossible.

"Ug... ejaculating!"  
"*Both* Nn!?"

Since the urethra wasn't fully blocked, semen shot out with a "bushu" sound. Startled, Kazuko and Kazuyo faced each other as cum splattered their faces white. Feeling its warmth and unique scent, both wore ecstatic smiles.

After resting, Yuu's libido and stamina remained unstoppable. Seeing Yuu declare "Now, let's continue," Kazuko and Kazuyo showed shock and joy. When Yuu requested them facing desks with raised hips, they moved instantly. Sandwiching his cock between two plump buttocks, he inserted middle fingers into their dripping vaginas. Declaring he'd penetrate whoever came first from fingering, surprisingly Kazuyo climaxed before Kazuko - apparently near orgasm from masturbating during fellatio. Keeping his promise, Yuu penetrated Kazuyo for a dozen thrusts before switching to Kazuko. Alternating between vaginas, he eventually creampied both Kazuyo and Kazuko for the second time each.

---

### Author's Afterword

I considered splitting this content-wise into two chapters but ultimately combined it into one. As a result, it feels slightly rushed.

### Chapter Translation Notes
- Translated sexual terminology explicitly: "膣内" → "vagina", "チンポ" → "cock", "おマンコ" → "pussy"
- Preserved Japanese honorifics: "和世さん" → "Kazuyo-san", "賀寿子センセ" → "Kazuko-sensei"
- Transliterated sound effects: "じゅぷ" → "jupu", "ぱしん" → "pashin", "ぬちゃぬちゃ" → "nucha nucha"
- Maintained Japanese name order: "広瀬祐" → "Hirose Yuu"
- Translated "人工授精" as "artificial insemination" per academic precision requirement
- Rendered sexual acts without euphemisms: "中出し" → "creampie", "種付け" → "breeding"
- Formatted internal vocalizations in italics: "（ち、近い！）" → *example format shown though none present*
- New dialogue lines as separate paragraphs except when attribution precedes dialogue