## 371. Pre-Graduation Special Screening ① ~Ambush~

The time rewinds to Monday of that week.

After school, Yuu was in the nurse's office after being called by health teacher Kendo Maho.

Though Yuu interacts openly with female teachers and even has physical relationships with them, his connection with Maho is particularly deep due to their collaboration on special health education classes and sex education video production.

"A preview screening of that video?"  
"Y-yes. Today about that... ah!"

Apparently wanting to discuss something confidential, Maho leaned in close as soon as they sat facing each other. Feeling mischievous, Yuu kissed her pink-rouged lips. Then he lifted the surprised Maho and sat her on his lap. Despite being petite with a childlike face under 150cm tall, she had large breasts. Even through her thick beige sweater worn beneath the white coat, their fullness was evident. This cute nurse looked unbelievable for someone nearly 30, and was one of Yuu's favorite staff members at Sairei Academy. Yuu wrapped both arms around Maho's back while burying his face in her chest.

Though Maho seemed pleased by his affectionate behavior, she had important business today and broached the subject while stroking Yuu's head. The matter concerned the specially planned sex education video Yuu had starred in during early January. A pilot version had been completed by late February. Yuu didn't know typical video production timelines, but completing it in under two months seemed remarkably fast - likely due to CAN Planning's skilled staff. In reality, the editors frequently became aroused while working, making the process challenging.

"So, this preview screening?"  
"W-well... for the current... third-years... ahhn! N-nipples... I can feel it!"  
"Ah, sorry. Guess we can't talk properly like this."

While keeping Maho secured with his right arm, Yuu had been massaging her chest with his left hand. At first it was over her sweater, but he gradually became engrossed and slipped his hand inside. Despite her large breasts, sensitivity wasn't reduced - when he slipped fingers beneath her bra to play with her nipples, Maho clung to Yuu while letting out adorable moans. However, since conversation couldn't continue this way, he withdrew his hand.

Though secretly disappointed to lose Yuu's touch, Maho quickly resumed talking.

"A preview for third-years before graduation?"  
"Yes. If Hirose-kun agrees."

Originally, the video was planned for limited release during special health education classes for Sairei Academy's second and third-years next academic year. Depending on reception, they considered expanding to other co-ed schools and Ayakuni Group sister schools. Maho suggested a one-time screening for the graduating third-years. The current third-years had an excellent reputation - not just for academic achievements and club activities, but also due to strong impressions from council president Sayaka. As a graduation gift, Maho thought showing them the video starring school idol Yuu would be meaningful.

Consulting Yuu first acknowledged his importance as lead actor beyond being a student. If Yuu approved, persuading the principal and rights-holding foundation would be easier. In his previous world, screening sexy videos of female talent students in class would cause major scandals. In this world, men typically dislike being filmed during sex. Yuu was practically alone in thinking "being seen doesn't diminish anything." Men who disliked nudity or sexual exposure wouldn't appear in such videos anyway. Though he felt slightly embarrassed that his fiancées Sayaka and Riko also appeared.

"I'm fine with it. If it'll make the third-years happy."  
"Really? Wonderful! I knew you'd say that, Hirose-kun!"

Relieved and delighted, Maho hugged him tightly. Her large, soft breasts pressed against Yuu's chest. Though the nurse's office smelled of disinfectant, Maho's clean, pleasant fragrance filled Yuu's nostrils now. Her hair had grown longer since their impromptu video scene in January, the curled ends now reaching her back. Stroking Maho's brown hair, Yuu brought his mouth to her ear.

"Is that all for today, sensei?"  
"U-uh huh. I guess. Are you... leaving already?"  
"Would it be okay if I left? For you, Maho-sensei?"

Yuu responded to her question with another, feeling slightly mischievous. Blushing, Maho stammered her reply.

"I-if Hirose-kun wants... I'd like you to stay a little longer. I'd be... happy if you stayed."

Yuu was busy after school with student council duties and more. Perhaps feeling guilty for monopolizing him, Maho confessed her true feelings while looking up at him. Yuu couldn't help finding her adorable.

"Sure. I want to stay with Maho-sensei too. And since we're here..."  
"Hyaah!? H-Hirose-kun!?"

Yuu swiftly extended his left hand to support Maho's hips as he stood up. He lifted her petite frame effortlessly.

"Let's continue on that bed over there."  
"...Okay."

Whether for original purposes or sexual ones, Yuu had never used the nurse's office bed before. He wanted Maho to be his first.

***

By personally contacting his half-sister Satsuki at the foundation rather than delegating, arrangements proceeded smoothly. Fortunately, CAN Planning had delivered the pilot version to the foundation right at March's start. Thus, an emergency screening for third-years was scheduled for March 9th, just before graduation.

Since it was Saturday, Yuu had half-day classes. The venue was the audiovisual room in the Friendship Hall, with screenings starting at 9am. The pilot version included scenes normally cut, making it about 80 minutes long. By the time Yuu finished class, four classes would have completed viewing. Yuu felt restless wondering how the third-years would react - especially Sayaka and Riko - and couldn't concentrate in class.

After class ended, Yuu immediately left the male building.

"He's here!"  
""""Hirose-kun!""""  
"Whoa!?"

School rules forbade girls from entering the male building without permission. Normally, they waited behind the rope barrier at the entrance. The number fluctuated, but girls waiting for Yuu had increased since he became council president. Today, 50-60 third-year girls ambushed him, erupting in shrill cheers when he exited - startling him. Their gazes held unusual intensity.

Trusting Sairei Academy's proper ladies and familiar seniors, Yuu didn't avoid them. He approached confidently since Sayaka stood at the crowd's center.

"Yuu-kun..."  
"Um... you watched it?"

Sayaka nodded. Apparently, morning screenings were split between male classes and female classes 1-3. Riko's absence suggested classes 4-5 (science track) were currently viewing. They'd only been told it was a specially made sex education video - details withheld. When Yuu appeared on screen, chaos erupted. But when explicit scenes began, silence fell. Everyone seemed affected by Yuu and Yuki's passionate, unscripted sex - countless girls slipped hands under skirts. Even this world's typically low-libido boys reportedly got excited. Afterwards, everyone grew restless.

Pairs already close - like Yuu's friend Ichijo Koki with girlfriends Hayase Mika and Ishima Mariko (1 boy × 2 girls pattern) - headed straight for the Special Male-Female Interaction Room. When that filled, some took taxis to Saito City hotels. The effect was dramatic. But among girls seriously infatuated with Yuu - those who came to school during free attendance just to see him - Sayaka gathered them to wait outside the building. This included girls like Iida Aiko who'd previously been intimate with Yuu.

"After watching that, seeing the real Hirose-kun... makes me so excited!"  
"Haaaaah... I want Hirose-kun to love me like that!"  
"It was incredible..."

Third-year girls encircled Yuu and Sayaka. Sayaka brought her mouth to Yuu's ear.

"Could you... come to the apartment today?"

Though visiting her family home weekly, they hadn't had sex recently. Watching that video had aroused her. Yuu pondered briefly before whispering back.

"Better not go to the apartment."  
"...! I-I see... sudden requests might conflict with your plans..."  
"Actually, I want to invite you to my place."  
"Huh?"

Momentarily deflated, Sayaka looked stunned, doubting her ears.

"You haven't seen Elena-nee recently either. Thought you might like to meet."

Though frozen by the unexpected invitation, Sayaka had no reason to refuse - she wanted to jump at the chance. They agreed to meet at the student council room after the afternoon screening, including Riko. Claiming he had somewhere to go, Yuu ended their private talk. Then he greeted each waiting third-year girl personally, exchanging pleasantries before heading to the administration building.

Encountering several staff members and sports club underclasswomen heading to afternoon practice along the way, Yuu merely waved when called. He passed through the first-floor corridor of the administration building, heading north to the Friendship Hall. This was the same audiovisual room where he'd stripped for second-years during special health class, letting them touch him until ejaculation.

Yuu climbed to the second floor and checked the hallway. Fortunately, no one was there. He quickly crossed the hallway and slipped into the preparation room next to where the sex education video played. Audio leaked through the wall - apparently during Yuu and Yuki's climax. Straining his ears, he heard moans and Yuu's strained voice. Feeling strange hearing his own sex sounds, he hid behind equipment to wait.

***

About 30-40 minutes passed. As the video ended, female students' commotion shook the adjacent room. Many called Yuu's name - Riko must be among them. Yuu suppressed the urge to go out. After a 10-minute break, the final class would enter.

Preparation rooms accompanied audiovisual/music/home economics rooms in the administration building. Yuu had sneaked in because it connected directly to the audiovisual room - specifically to the teacher's platform side. Hearing silence next door, Yuu slowly turned the doorknob.

"Haaaah... having footage of myself having sex broadcast feels weird... but it reminds me of that time..."

Kendo Maho operated the equipment as screening supervisor. Foundation staff had attended the first class but apparently left. Closing the door quietly, Maho didn't notice. It seemed careless - if someone with ill intent knew about the video's content and tried to steal it. But apparently no one at Sairei Academy harbored such intentions.

Confirming no students remained, Yuu stealthily approached Maho from behind. With lights dimmed for the next screening and hidden by equipment shadows, Maho didn't notice until he was close.

"Okay, last one next... mmph!"  
"Don't move! Just kidding."  
"...!?"

When Maho realized Yuu had covered her mouth and embraced her from behind, her eyes widened in shock. She seemed confused why Yuu was here.

"H-Hirose-kun?"  
"Sorry for startling you. Wanted to check things out."

Just then, the hallway grew noisy. The final class had arrived.

"Wh-what do we do?"  
"Well..."

Yuu looked back and saw a teacher's seat nearby.

"I'll hide here since my presence would cause commotion."  
"B-but..."

As Yuu hid under the desk, the audiovisual room door opened. The final class of female students streamed in.

---

### Author's Afterword

In chapters 313-319, I wrote about Yuu starring in an adult video... rather, a sex education video. Since we went that far, I wanted to depict students' raw reactions during the school screening. Though unfamiliar with video production, completing editing and a pilot version within about two months seems remarkably fast. Especially considering the editors were constantly aroused while working.

### Chapter Translation Notes
- Translated "まちぶせ" as "Ambush" to convey the surprise element of students waiting for Yuu
- Preserved Japanese honorifics (-kun, -sensei) and name order (e.g., Kendo Maho)
- Translated explicit sexual terminology directly (e.g., "nipples", "sex", "moans")
- Maintained original paragraph structure for dialogue sequences
- Transliterated sound effects (e.g., "Hyaah!", "Haaaah")
- Used italics for internal monologue *(feeling strange hearing...)*
- Translated culturally specific terms like "bloomers" and "family-style restaurant" with contextual equivalents
- Preserved specialized terms like "Special Male-Female Interaction Room" from Fixed Reference