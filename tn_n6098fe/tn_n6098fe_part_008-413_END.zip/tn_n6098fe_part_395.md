## 372. Pre-Graduation Special Screening ② ~Camouflage~

"Um, what we're about to screen is a groundbreaking sex education video newly produced for special health and physical education classes. Originally scheduled for use starting next academic year, but we wanted you all to see it too. Though it's a busy pre-graduation period, we've urgently arranged this opportunity."

"Teacher! Is it really erotic content?"

"Ah, hahaha. You'll have to watch to find out, but I think you can have high expectations."

"Hohou~"

"It won't... put us in a weird mood from being too erotic, right?"

"Of course not~"

I'd heard women are quite open when discussing sex among themselves, but apparently that applies even between teachers and students. Rather, because Maho handles health education and usually counsels students about body and sexual concerns in the nurse's office, the distance feels closer.

However, until now, teaching materials used in class had zero entertainment value and were rather stiff. While there was content showing nude males exposing their genitals or depicting sexual acts themselves, for those familiar with experience or adult content, it was utterly unsatisfying. Many students seemed skeptical whether this was worth gathering for right before graduation. Students from classes 1-5 who saw it first told nothing to the upcoming classes. Or rather, the fact that hardly any returned to their classrooms spoke volumes.

With high school life ending soon, opportunities to gather as a class are disappearing. That there were zero absences today seemed more due to wanting to gather as a class—and maybe luckily meeting Yuu—than the video screening.

Today's final screening was for General Course Class 6 and Physical Education Course—64 female students total. Unlike in classrooms, they sat clustered with friends, whispering in the dimly lit room. Maho had drawn thick black curtains over the windows, and except for the downlight illuminating the teacher's platform for equipment operation, all lights were off.

After pressing the remote's play button, Maho turned off the remaining lights. Pitch darkness fell, but the screen soon brightened. As it finally began, the previously audible chatter died down. Maho returned to the teacher's seat while suppressing her pounding heart. The gray office desk had ample width, providing plenty of hiding space underneath. Though invisible to students, from Maho's position, she could see Yuu crouching there.

Maho sat in the chair, feigning calm. She saw Yuu beckoning from below while maintaining a distance where their legs wouldn't touch. To avoid looking unnatural by being too far from the desk, Maho scooted her chair slightly forward. When both legs entered the space under the desk, Yuu grabbed them.

Today Maho wore a check-patterned vest and white blouse under her usual white coat, with a beige knee-length tight skirt and black tights. Yuu spread her legs apart, positioning his face where her panties were visible.

Maho's face flushed red, but since it was pitch dark, no one noticed. Though her heart raced at having Yuu between her legs, she thought she could endure leg touches without making noise. 

Just as Yuu spread Maho's legs and peered under her skirt, cheerful music signaled the video's start. Yuu hadn't seen the final version but had watched all parts he recorded.

The video depicted Hiroto and Yuki—modeled after Sairei Academy—meeting in April and developing mutual attraction. Though classes were gender-segregated, they gradually grew closer through school events, sometimes missing each other or meeting by chance during breaks or after school. Still images of changing seasons accompanied voiceovers of their feelings and conversations—only Yuu and Yuki's voices. While Yuu's lines sounded awkward, Yuki's acting was skillful.

Just as viewers began immersing in this sweet adolescent romance, murmurs arose as it progressed. More students grew suspicious about the familiar voice—some speculated it might be a special voice-only appearance.

The turning point in their school-bound friendship occurred during summer vacation. However, neither had the courage to go out together. In this era without cell phones, they occasionally talked on home phones, though Yuki sometimes used pay phones outside to avoid family complaints about long calls.

One day in late August, they agreed to work on homework together at the library. Hiroto became more enamored seeing Yuki dressed up fashionably, while Yuki felt lust seeing Hiroto in a T-shirt but suppressed it as they sat at a table. The scene showed both studying at the table—backs visible but heads cut off. Though mundane, gasps filled the classroom at seeing an actual young man instead of middle-aged actors.

"Nngh... fuu... hah... nn... nnngh"

Meanwhile, Yuu had buried his face under Maho's skirt. His left hand freely groped her thigh—the tights felt rough but the plump thigh flesh was soft. His right hand invaded her vest. With her leaning forward, her enormous breasts nearly rested on the desk. Yuu softly kneaded them with upward strokes. Though giving only light stimulation, Maho's muffled moans escaped. A distinct scent already emanated from her crotch near Yuu's nose—apparently aroused both by the video and Yuu's proximity. Fortunately, the loud video audio masked Maho's sounds, so Yuu decided to escalate.

The video progressed to fall semester after summer break. Through sports festivals and cultural festivals, Hiroto and Yuki spent more time together, their mutual feelings growing though neither confessed. After a campfire at the cultural festival wrap-up, Yuki finally confessed when they were alone. Hiroto had been approached by several girls—scenes showing Yuki's jealousy—and though knowing he'd eventually date/marry multiple women, he'd rejected all others wanting only Yuki now. Hiroto naturally said yes to her confession. By then, all watching students were engrossed, some cheering when Yuki succeeded.

Their relationship accelerated after becoming official: hand-holding, light hugs, first kisses. Initially discreet, they gradually stopped hiding at school. When caught embracing, they became a recognized couple within a month. Though only voiceovers against location photos, it was overwhelming—even Yuu felt embarrassed rewatching. For now, Yuu enjoyed the scent of Maho's vulva in the darkness.

Their first time on Christmas was skipped, jumping to a "one month later" explicit scene. After school on Saturday, they went straight to Yuki's room. Though awkward initially, the young couple became sex addicts through repetition.

'Hey, Hiroto... I want to do it... Sorry for being such a slut always wanting you. I can't stop thinking about you—just seeing you up close like this...'

As Yuki spoke, the first real bed scene began, eliciting today's loudest gasp. Though the camera only showed Yuu's back and side, these third-years familiar with Yuu immediately recognized him.

"Eeeeeh?!" "Huh... no way!?" "Wh-why?" "Hihihi, Hirose-kun!?" "Yuu-kun's there!" "No mistake, right?" "Our student council president!"

Chaos engulfed the audiovisual room. But order quickly returned as students focused on watching.

'I want... Yuki too'

Lip-smacking kisses and sweet whispers. Without looking, Yuu knew everyone was glued to the screen. A collective "Ooh!" erupted when Hiroto removed his clothes. By then, Yuu had grown unsatisfied with over-clothes contact and tried removing Maho's tights.

"N-no, Hirose-kun!"

Maho whispered downward in token resistance—but didn't seriously resist, letting Yuu undress her. As the naked Hiroto and Yuki began petting onscreen, drawing sighs of admiration and envy, Yuu beheld Maho's vulva directly.

"Nkgh... fuu... nmu..."

While Yuki's moans intensified onscreen, stifled sounds escaped Maho's hand-covered mouth. Going down on her would risk exposure, so Yuu kept to soft caresses. Instead, he untucked her blouse, unhooked her bra from behind, and directly kneaded her breasts.

Had the room been bright and quiet, they'd have been caught—but all students were fixated on the screen showing Hiroto and Yuki in 69 position. Many girls began putting hands under skirts to touch themselves; initially suppressed moans grew bolder. With perfect masturbation material unfolding, projecting themselves as receiving Yuu's touches or blowjobs brought unprecedented pleasure. No one paid attention to others—masking Maho's situation.

'Haaaaaah... vngh! I can't... take it! Ah! Ah! Ah! Ah... cumming again, Hiro...to... no, ahngh! Cumming uuuuuuuuuuuu!!!'

When Yuki climaxed, satisfied "Fuu" sounds were heard—some had already orgasmed from masturbation. But the main event followed. As Hiroto penetrated Yuki and thrust vigorously, classroom moans intensified. After all, this showed raw, mosaic-free sex more intense than typical AVs. Hiroto's rough breathing. Yuki's moans. *Pan pan pan* hip impacts. Relentless wet sounds from their joining.

It transcended acting—showing genuine lovemaking. Though virgins comprised over half, these were sexually curious high school girls. Witnessing such sex inevitably aroused them. Some even removed underwear or pulled it aside, spreading legs to masturbate openly.

"Nn-gh! Mufu... nn, nn, nna... ahn... good... hah... nnn!"

Yuu savored Maho's breast size and softness, kneading vigorously while being unusually reserved with cunnilingus. Avoiding her most sensitive clitoris, he slowly licked inside her labia, sucking overflowing juices. But as she neared orgasm, Maho grew impatient. She began kneading her own breasts, pinching and teasing nipples. Hearing 64 female moans filling the room, Yuu decided restraint was unnecessary.

'Yuki, I'll ejaculate lots... take it... get pregnant with my child... ahh! Yuki! I love you! Yuki!'

'Me too... hyauun! So good! Hi, Hiroto! Hiroto! Hirotoo! Oh.........'

Onscreen, Hiroto and Yuki entered their final stretch. Yuu now intended to make Maho climax. He inserted his free left middle finger into her vagina while extending his tongue to flick her clitoris teasingly.

"Khyii!"

Instantly Maho arched back. But all students were too engrossed in masturbation to notice. *Jupujupu nechonecho* wet sounds intensified everywhere.

As Hiroto ejaculated inside Yuki onscreen, voices crying "Cumming!" "I'm coming!" while calling Yuu's name filled the air—and Maho reached climax too.

"Hyoshek... nn! Ah! Ah! Ah... coming! Coming! Aaaaaaaaahhhhhh—!"

Amid the masturbation festival, Maho joined the students, crying out as she orgasmed.

---

### Author's Afterword

Writing parallel scenes—the video content on screen, the students' reactions, and Yuu hidden under the desk pleasuring Maho—proved quite challenging.

### Chapter Translation Notes
- Translated "カムフラージュ" as "Camouflage" to maintain military metaphor continuity from previous chapter "Ambush"
- Preserved Japanese honorifics (-kun, -sensei) per style guide
- Translated explicit sexual terminology directly (e.g., "クンニ" → "cunnilingus", "膣内" → "vagina")
- Transliterated sound effects (e.g., "ぱんぱん" → "pan pan", "じゅぷじゅぷ" → "jupujupu")
- Used single quotes for in-universe video dialogue to distinguish from narrative dialogue
- Maintained original name order (Hirose Yuu) for Japanese characters
- Italicized internal monologue *(This is concerning.)* per style guide