## 373. Pre-Graduation Special Screening ③ ~Love is a Commotion~

Just when it seemed to end with Hiroto and Yuki's sex scene, after a brief pause, a scene appeared showing another woman joining them on the same bed, gazing at each other.

A teacher character who had long been infatuated with her student confessed. When Hiroto accepted and began hugging and kissing her even with Yuki present, the watching students were utterly astonished.

In this world's AVs, high school boy-themed videos are extremely popular.

Of course, they can't use real high school students, so it's common for women crossdressing with double-ended dildos to play the roles. Even when real males are occasionally used, they're over 30 years old, creating an objectively awkward feeling that can't be helped.

Actresses often play standard roles like classmates, teachers, mothers, sisters, or engage in chikan play on trains/buses. Scenarios where they're cornered and assaulted in park toilets, abandoned houses, or factories by laborers/homeless people are also popular. Essentially, it's a gender-reversed version of beautiful girls being assaulted by dirty old men.

What's being shown on screen is a combination of a real high school boy and female teacher. Since they're people the students know well, the realism is undeniable.

Because of this, even students who had calmed down began getting aroused again.

When women become aroused, unlike men, the sensation is sustained.

Everyone seized the moment to continue masturbating.

Especially when seeing the teacher rubbing Hiroto's cock between her ample breasts, busty girls began fondling themselves as if they were doing the same.

"Ah, ah, ahhh! Kuu! H-Hiroshhee-kun! I'm... cumming again! Aaah... haaaaaaaaahn!"

Around the time Maho's teacher character on screen accepted Hiroto's cock and completed her emotional virginity loss, the real Maho reached climax and couldn't suppress her voice.

By now she'd even removed her vest and blouse, exposing her large breasts. Yuu emerged to suckle them while fingering her vagina.

*Sploosh sploosh* - her ejaculate splashed onto Yuu's knuckles and soaked his clothes, but he continued pleasuring her without concern.

The audiovisual room's seats are tiered higher toward the back, so had it been bright, Yuu would definitely have been visible. But everyone was too engrossed in the screen and masturbating to notice.

After all, during this mutual masturbation session, many were screaming Yuu's name while climaxing just like Maho.

However, not everyone remained oblivious. Sometimes the lighting made Maho's area brighter, occasionally revealing Yuu's head suckling her breasts. They never imagined such a thing was happening and simply didn't look carefully. But as Hiroto ejaculated in the video and the audio quieted, some students began feeling uneasy.

"Is someone... at the teacher's desk?"  
"N-no way..."

Yuu, with only his upper body emerging from under the desk, was intensely focused on simultaneously pleasuring Maho's breasts and pussy to multiple orgasms. Though unclear, students were starting to notice.

At first they thought it might be a hallucination, but one concerned student stood up and turned on the podium lights.

""""H-Hirose-kun!""""  
"Ah..."

On screen, the final scene showed Hiroto whispering sweet nothings between Yuki and the teacher in bed, but now nobody cared. Yuu had planned to stay hidden, but thought *if we're caught, so be it*. Part of him actually wanted to emerge upon hearing two classes of aroused girls.

He didn't know over half of Class 6, but he had deep connections with the PE course class including former basketball captain Shiina Chizuru - they'd been intimate after the Christmas party. Seeing no point in hiding, he decided to own the situation.

"Special treat for our final class! Maho-sensei and I will now demonstrate sex!"

"Oooh!" came the roar. Though confused, they celebrated their luck. "Maho-sensei, let's go."

The Friendship Hall's audiovisual room has an unusual layout. A pathway extends straight from the podium to the center, ending in a circular space large enough to lie down - resembling a fashion show or strip club stage.

Still riding her climax, Maho didn't understand what was happening but felt great being held by Yuu. With disheveled clothes, she was carried to the center.

"H-Hirose-kun..."  
"Yuu-kun!"  
"Ahh, still so dreamy!"  
"I came three times masturbating but I'm still horny!"  
"M-me too... this might be bad"  
"Everyone, come closer for a better view!"

Students who'd been standing since Yuu appeared clattered forward. Standing in the circular space, Yuu surveyed the 64 third-year girls forming a semicircle before him.

"Sensei, take off my bottoms"  
"Huh? O-okay!"

While every woman present had disheveled clothing, Yuu alone remained fully dressed. He started by having Maho remove his lower garments. Perhaps nervous, her movements seemed slightly awkward. Students watched impatiently as Yuu's lower body was gradually exposed.

"Wow!"  
"Still impressive as ever..."  
"I... want it..."  
"Huh?"  
"Wait, it's different than I imagined"

Reactions split when his vigorously erect cock appeared. The PE students hadn't seen it since Christmas, while most Class 6 students had never seen a real penis. Regardless of class, all eyes locked onto Yuu's virile member. Even for first-timers, this masculine phallus stabbed straight into female instincts. Many eyes glazed over, mouths practically drooling.

After undressing below, Yuu removed Maho's skirt, discarded her lowered tights, and stripped her panties. He sat cross-legged and guided her to sit against him. Given Maho's petite frame, he planned rear-entry penetration for optimal visibility. By now Maho was putty in his hands - shocked by his boldness but trusting he'd pleasure her more.

Viewed from certain angles, Maho resembled someone positioning over a toilet as she lowered her hips. When her butt reached his abdomen level, Yuu extended his hands to support the backs of her spread knees.

"Um?"  
"Stay like that. I'll insert now. Watch closely."

Their seated area was slightly higher than desks. Students leaned over the edge, packed tightly even behind them. With Maho's legs spread wide and supported, her vulva was fully exposed - *kupaa* open, revealing beautiful salmon-pink inner flesh already drenched from Yuu's earlier cunnilingus and fingering.

But all eyes focused on the thick, throbbing cock standing proudly. Though shocked by the video, the real cock's scent and rawness made their brains melt. Lower abdomens throbbed as countless hands returned to groins.

Despite Maho's size, the insertion point wasn't directly visible. Unfazed, Yuu first pressed his cock against her entrance like dry-humping, producing a *nuchu* sound.

While holding Maho, Yuu adjusted the glans position against her tiny vaginal opening. Some watching students gulped audibly at the sight of the thick cock meeting such a small entrance.

"Kuh!"  
"Aunn!"

Maho's already experienced vaginal opening widened to swallow the glans completely. As her supported body sank slightly, penetration advanced but stopped midway.

"Your pussy's still crazy tight, sensei. Does it hurt?"  
"I-I'm fiiine... really... p-please... I want... Yuu-kun's cock... all the way... to my deepest place! Nn... kufuu! I want Hirose-kun's cock... thrust deep inside!"

If any woman here was most aroused, it was Maho. She'd watched her deflowering scene three times today, and during the fourth viewing had been pleasured to multiple orgasms by Yuu without watching. Desire is limitless - recalling the filming, Maho's entire body and mind craved Yuu's cock. Though held from behind, she wriggled her hips impatiently.

"Okay. Then I'll go all out."  
"Yes! Give it... aaahn! I-It's... in... so big!"

Yuu pressed Maho down and thrust upward hard, *gatsun*! His cock forcibly widened her tight passage, *zuzuzu* pushing deep inside.

"Ooh... Maho-sensei's pussy... squeezing so tight... ahh, feels amazing"  
"Kufu... Hirose-kun's cock... inside me... faaaaaa... vun! So... happy..."

Maho's vaginal tightness barely differed from her deflowering. Though entry took time, her constantly stimulated, secretion-drenched hole now swallowed his cock completely. Students watching up close stared wide-eyed, mouths agape.

"Such a thick cock... went all in!"  
"I-Incredible"  
"Sensei looks so happy"  
"I'm jealous"

Words spilled out unconsciously. Their hands instinctively reached between legs. Many removed soaked panties, fingering themselves as if being penetrated by Yuu.

"Sensei, does it feel good?"  
"Ah, aahn! Of... course it feels good... ahn! Being pierced... deep by Hirose-kun's cock... I'm... so happy! Haaahn!"

Initially, the vaginal constriction was too tight for vigorous movement. Yuu supported Maho's legs with both hands, thrusting in small movements that made her ample breasts *tapuntapun* sway. At the junction, her spread vulva gaped open, their mixed juices overflowing to form puddles below with each thrust. Maho's moans intensified after her wish was fulfilled - no longer conscious of being before students.

Those who'd had sex with Yuu before. Those seeing a real penis for the first time. Regardless of experience, all craved Yuu's cock - a desire amplified by Maho's blissful expression.

"Ah, haa! D-Deeper... *ton ton*... hya! A-Amazing, amazing! I-I'm... cumming!"  
"Go ahead. My cute Maho-sensei, cum on my cock this time."

With Yuu's face near her ear, his handsome voice whispering sweetly became the trigger. Her mouth fell open in dazed expression. When he thrust hard, *zun*, her ejaculate *pyu* sprayed onto several students watching the junction head-on.

"I-I'm cumming! Vuaah! Aaaaaaaahhhhhhhhhhhn!"

Though only five minutes since insertion, Maho experienced climax surpassing her earlier oral/fingering orgasms, screaming louder. But Yuu's hips didn't stop - his thrusting pace gradually accelerated.

"Nyaa, w-wait... I'm cumming... can't... more..."  
"No way. Your pussy feels too good, I can't stop."  
"Hyaun! No, so rough... too much... I'm cumming... vu, ah, au!"  
"Maho-sensei, look at me."  
"H-Hiroshhee-kun"

While thrusting, Yuu twisted to kiss Maho as she turned back. Not just kissing - their tongues tangled with *picha picha* wet sounds. Watching such loving, passionate sex mirroring the video was unbearable. Many students frantically moved their hands, climaxing simultaneously with Maho while staring with heated eyes.

---

### Author's Afterword

Well, it was only a matter of time before he got caught.

If anything, the real trouble starts now.

### Chapter Translation Notes
- Translated "ワレメ" as "vulva" for anatomical accuracy per explicit terminology rule
- Translated "膣内" as "pussy" in dialogue but "vagina" in narration to reflect contextual nuance
- Preserved Japanese honorifics (-kun, -sensei) throughout
- Transliterated sound effects (e.g., "ぶしゅぷしゅ" → "sploosh sploosh")
- Maintained original name order (e.g., "Shiina Chizuru" not "Chizuru Shiina")
- Used explicit terms for sexual acts ("fellatio", "cunnilingus", "penetration") as required
- Formatted simultaneous dialogue with double quotes ""..."" for group reactions
- Italicized internal monologue *(if we're caught, so be it)*