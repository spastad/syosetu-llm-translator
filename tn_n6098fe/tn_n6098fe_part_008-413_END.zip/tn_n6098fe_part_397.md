## 374. Pre-Graduation Special Screening ④ ~Everyone's Sweet Voices~

### Author's Preface

Regarding the students in the audiovisual room, I previously wrote 60 people but it was actually 64 (36 from Class 6 and 28 from PE course). I've corrected this.

---

After finishing his ejaculation, Yuu slightly lifted Maho's body which he had been supporting with both hands.

His erect penis remained engorged as it withdrew. As if lamenting the separation from the vagina it had been sheathed in, it trailed a cloudy white thread from its tip.

"It felt really good, Maho-sensei."  
"Ah...hmm..."

Maho, who had climaxed multiple times, could barely respond coherently as she gasped for breath. But when Yuu brought his lips to her cheek, she turned her face to meet his and they kissed. Yuu laid Maho on the floor while still holding her, then turned around. Semen flowed out as it backflowed from her vaginal opening.

"Now then."

Yuu stood up and surveyed his surroundings.

Amidst the gazes of 64 third-year female students from Class 6 and the PE course, the thing between his legs remained vigorously erect. Everyone's eyes were glued to the erect cock. They swallowed saliva or licked their lips, their eyes gleaming like carnivorous beasts eyeing prey.

The atmosphere suggested that if anyone made the first move, everyone would swarm in like an avalanche. Whether due to lingering rationality or complex group psychology, they remained in place - but were clearly primed to explode. One wrong move would lead to disaster.

To seize the initiative, Yuu spoke first.

"Class representative for Class 6!"  
"...Yes!" "Haaai!"

One student who'd been staring intently at Yuu from the left front row, and another from the back, responded. Yuu continued.

"For PE course, Chizuru-senpai and Wakako-senpai!"  
""Yes!""  
"Could you come here?"

Two energetic voices responded from the right side. Yuu had specifically called two representatives from each class.

Shiina Chizuru, former basketball team captain from PE course, and Fujieda Wakako, former soccer team captain. Both had helped with school event security before. Chizuru especially had known Yuu since his enrollment and was among the first in PE course to have physical relations with him, along with Connie from basketball club. Given their standing among PE students, they were ideal choices.

The two happily mounted the platform. Half-naked with uniforms and underwear partially removed, their well-toned bodies showed they'd maintained training even after club retirement. Chizuru's magnificent large breasts swayed when she stood.

"Attendance number 24, Fukuyama Himiko!"  
"And number 20, Nishiguchi Narumi~"

The two class representatives from Class 6 presented contrasting appearances. The tall one was Himiko. Standing beside Wakako (175cm), she matched her height but differed completely - while Wakako had sun-tanned skin from soccer training, Himiko was slender and pale. Her long black hair reached her waist, with bangs pinned back by a bright red hairband revealing her forehead. Though beautiful with sharp, determined eyes, her intense gaze gave a slightly intimidating impression.

In contrast, Narumi was short and plump with chestnut-brown short bob hair. Her relaxed speech suggested a gentle personality. While Narumi remained fully dressed, Himiko swiftly stripped off both uniform and underwear, approaching Yuu completely naked.

"U, hi, hi, Hi-ro-se-kun... mmm!?"

Without panicking, Yuu intercepted Himiko by embracing and kissing her. Himiko's eyes widened in momentary surprise, but once realizing she was kissing Yuu, her face flushed crimson. She immediately wrapped both arms around Yuu's back.

"Aahn, me too~"  
""Yuu-kun!""

Narumi tried pushing Himiko aside while Chizuru and Wakako embraced Yuu from behind, nearly causing a pileup. That they didn't fall over was largely thanks to the PE students' strong cores - proof of their year protecting Yuu.

"Haha. One at a time."

After kissing all four in turn, Yuu said:

"Himiko-senpai, Narumi-senpai, could you suck my cock?"  
"Gladly!"  
"Haaai"

As Yuu stood, the two Class 6 students knelt and sandwiched his cock between them, extending their tongues. Though coated white with mixed fluids, it seemed like a feast to them.

"Whoa, what a magnificent thing~"  
"Truly erotic~ The real thing's different, isn't it?"

Himiko and Narumi each held one of Yuu's thighs while touching his testicles, licking from tip to shaft. Meanwhile, Chizuru and Wakako pressed close from either side. After having them remove his top, Yuu let them freely handle his upper body. They took turns requesting kisses while running hands and tongues over his torso.

"Nnhaa... How many times I dreamed of holding Yuu-kun like this again, kissing him..."  
"Aah, Yuu-kun's bare skin... kufuu"

Wakako murmured in a melting voice while kissing Yuu, her hands stroking his back and tweaking his nipple. Chizuko excitedly pressed her ample breasts against him while caressing his head and licking from shoulder to chest. Yuu enjoyed their toned yet feminine bodies, hands around their waists.

"Come to think of it, he already ejaculated once, right?"  
"Chuup, leroleroo... Huh? But it's still so lively."  
"Well, yes. Hirose-kun is special. After all, he has such a big, mighty cock... chu, chu, amm"

Unlike the PE students who'd experienced Yuu's stamina after the Christmas party, most Class 6 students found it puzzling yet accepted that Yuu was special as shown in the video. Himiko and Narumi mentioned it while sandwiched around his cock, but since it remained proudly erect, they continued licking it clean before kissing along its length.

"Uwa... a, i-it feels good..."

Since this was their first time seeing male genitalia, fellatio was naturally their first experience too. Yet their tongue work was skilled - likely from diligent practice to please men. With upper and lower body attended from both sides, Yuu felt heavenly despite seeming overwhelmed.

The others watched enviously but held onto hope they'd be called in turn. None wanted to force themselves on Yuu and risk his displeasure. Their three years of ladylike education helped maintain restraint.

Himiko gradually grew unhinged. Hailing from a family of shrine maidens in Chichibu, she was set to study Shinto at a Tokyo university. Though possessing leadership and academic excellence, she sometimes acted eccentrically.

"Mufu! This is none other than the manifested Konjinshin*! Truly honchi suijaku**! Incomparable to ordinary specimens, so enormous, hot, hard... haa, haa... My brain melts from the fragrant male scent... My womb throbs painfully!"

*(Konjinshin: Phallic deity in Japanese folklore)  
**(Honchi suijaku: Buddhist concept of deities manifesting as kami)

Himiko had been muttering since starting to suck, but nobody noticed. Narumi facing her ignored the ramblings as usual. Thus when Himiko grabbed the base of Yuu's cock and looked up, no one noticed her fixed gaze.

"Hi-Hirose-kun! I humbly beseech you! Grant me this Konjinshin's essence... in my womb!"  
"Whoa!?"

Himiko stood abruptly and pressed against Yuu, trying to impale herself. Both Chizuru (deep kissing Yuu) and Wakako (kissing his nape) were caught off guard. Narumi got pushed aside by Himiko's spread thighs.

"Ohoo! So biiig!"

Coincidentally, the position and angle aligned perfectly for insertion. Though startled, Yuu calmly held Himiko's slender body. Being a virgin, she couldn't take it all at once, stopping midway - but this agitated not just the three women but all surrounding students.

"Oooi!"  
"Cheating!"  
"Get off!"  
"Then I'll do it too!"

Amidst angry shouts and screams, Yuu remained calm. When modeling for second-years before, he'd only ejaculated a few times. But now, after watching the explicit video and live sex, everyone's excitement peaked. Handling two classes was excessive, but Yuu knew only personal sacrifice could control this.

As Chizuru and Wakako tried forcibly removing Himiko, Yuu shook his head to stop them. Instead, he firmly wrapped his arms around Himiko's slender waist and thrust.

"Kuhiiii! Oo... aha... i-it's in... haa, haa... Konjinshin pierces my body... Overjoyed... uu, so happyyyy!"

Like others, breaking her hymen made Himiko cry tears of joy. Students about to rush the platform froze. Though co-ed, most graduates remained inexperienced. While shocked and jealous of Himiko's opportunistic move, they understood her feelings.

Patting Himiko's head, Yuu addressed everyone over her shoulder:

"How many virgins are here?"  
"Here!" "Yes!" "Me!" "Me too!"

About 3/4 of Class 6's 36 raised hands. Though 9 were non-virgins (3 deflowered by Yuu), they noticed no PE students raised hands. Yuu's next words stunned them.

"I'll take all virgins here. Line up in order."

After a stunned moment, virgins exploded in cheers. Meanwhile, Yuu thrust shallowly to adjust inside Himiko. Fortunately, her emotional excitement outweighed the pain. Rather, she seemed to feel pleasure as her cervix was knocked, clinging tightly while panting.

""Yuu-kun...""  
"Ah, wait a sec"

Hearing Chizuru and Wakako, Yuu decided his course. Though he'd taken the virginity of all PE students he'd been with during Christmas, he couldn't neglect them now.

Yuu had Himiko sit on him. After kissing her, he told her to move herself. Nodding dazedly, she did. Then looking up at Chizuru and Wakako while lying back, Yuu said cheerfully:

"Non-virgin senpais, I'll pleasure you orally. You may straddle my face."

Hearing they could ride Yuu's face, Chizuru and Wakako smiled broadly rather than complain. Everyone felt moved by Yuu's magnanimity in accepting all. Thus cooperation prevailed over competition (though Class 6 vowed to punish Himiko later).

The remaining issue was excessive numbers. Even Yuu couldn't creampie everyone. After discussion, they decided: after Himiko and Narumi, virgins would ride in attendance order for 3 minutes each.

Himiko moved clumsily yet passionately. Chizuru straddled Yuu's face for serious cunnilingus while Yuu groped her large breasts.

"Aah, ah, inside me... Konjinshin... wildly thrashing... gimooo! This is ecstasy!"  
"Yu-Yuu-kun! Aah! So gooood... amazing! What... licking so much... I'm already..."

After 3 minutes, Narumi and waiting classmates mercilessly pulled Himiko off. Narumi mounted Yuu's hips. Meanwhile, Chizuru nearing climax was granted extra time - a reward for her conduct.

When Chizuru arched back in climax, PE students helped her down. Narumi inserted herself - also a virgin. Her tight vagina made Yuu moan with a wet face.

"Oo... Narumi-senpai's inside... so hot, squeezing... uu, dangerous"  
"Ahaa... So happy~ Yuu-kun took my first time... I'm so moved... I'll do my best"  
"Haa, haa... Yu... Yuu-kun, I'll straddle. My pussy... will you lick it?"  
"Sure. Wakako-senpai, come. I'll lick you thoroughly"

Though enjoying consecutive virgin vaginas, Yuu neared his limit. Still wanting to please Wakako, he simultaneously attacked her clitoris and vagina with fingers and tongue.

Each thrust against Narumi's large buttocks produced loud slaps. Despite her plump, gentle appearance, her virgin vagina squeezed tightly as she frantically rocked. Its fine folds seemed intent on milking every drop. Thus Yuu ejaculated right at the 3-minute mark.

"A... ahee, coming! Aah... so hot... so much..."  
"Hiaa! Yuu-kun sucking... aahn! Good! Good! I'm cummiiiiiiing!"

Yuu came while sucking Wakako's clitoris. Her engorged clitoris, thoroughly teased by her own fingers earlier, easily reached climax under his touch.

Satisfied after receiving ample semen and orgasming from cunnilingus, Narumi and Wakako left Yuu. Immediately, Class 6's #1 attendance student mounted his hips. From PE course, Ashina Karin (former track team) headed for his head.

While Himiko watched resentfully, Narumi pressed semen threatening to leak from her vagina and murmured:

"Haste makes waste, as they say~"  
"Grrr..."

Despite her soft appearance, Narumi proved a cunning woman.

Ultimately, Yuu penetrated all Class 6 virgins. After the third ejaculation, his cock temporarily wilted, but non-virgin volunteers revived it with enthusiastic fellatio. Including Narumi, seven students luckily received Yuu's semen.

Though the women did most moving during intercourse, servicing the riders proved more exhausting. All 28 PE students took turns, but Yuu only brought half to climax - his mouth tiring later.

Lying supine with two riders at a time, Yuu became drenched from head to toe - looking like he'd endured gang rape all night. Yet he felt fulfilled. Himiko and others brought towels from other classrooms, taking turns cleaning him. As they diligently wiped him like caring for an elderly patient, blood rushed to his seemingly spent cock, astonishing everyone. When Yuu staggered trying to stand, they hurriedly supported him.

At Yuu's request, Chizuru carried him piggyback to the student council room with all PE students - over 3 hours after the video ended. An impatient Sayaka and Riko were furious, but couldn't stay angry at Yuu's self-inflicted situation. With Yuu and all PE students bowing apologies, peace was restored.

---

### Author's Afterword

If genders were reversed, this would be about a bitchy angel underclassman helping graduating seniors avoid virgin graduation by taking their virginity while servicing non-virgins orally.

This will likely be Yuu's last time servicing double-digit numbers. The next few chapters will have no erotic content.

### Chapter Translation Notes
- Translated "金精神" as "Konjinshin" (phallic deity) with footnote explanation
- Translated "本地垂迹" as "honchi suijaku" (Buddhist concept of deities manifesting as kami)
- Preserved Japanese honorifics (-sensei, -senpai, -kun)
- Maintained original name order (e.g., Fukuyama Himiko)
- Transliterated sound effects (e.g., "chuup", "leroleroo")
- Used explicit anatomical terms (vagina, penis, clitoris) per style guidelines
- Translated sexual acts without euphemisms (e.g., "impaled herself", "creampie")
- Italicized internal thoughts (e.g., *This is ecstasy!*)
- New dialogue lines start new paragraphs except with attributions