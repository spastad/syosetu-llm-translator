## 375. Graduation Ceremony ~my graduation~

March 11th marked the graduation ceremony at Sairei Academy High School.

As the formal name "Graduation Certificate Awarding Ceremony" indicates, this event certifies students' completion of all high school educational requirements as they receive diplomas from the principal.

For students, this day represents leaving the school they spent three years in, parting with teachers and classmates, and in some cases concluding their student life. It's therefore a special day prone to sentimental emotions.

The ceremony began with the opening address in the gymnasium decorated with red and white banners, attended by current students, faculty, and guests. Yuu naturally participated as a current student, wearing his rarely worn gakuran uniform for this milestone occasion.

Yuu couldn't help but feel profound loneliness knowing that Komatsu Sayaka—who he fell for immediately after enrollment and who became his fiancée bearing his child—along with Hanmura Riko and Shiina Chizuru (former basketball captain who provided security at numerous events) and other PE course seniors would graduate today. Many third-year girls had also grown close to him since he became student council president.

Still, his duties as student council president made him more nervous than sentimental.

The graduates entered. While customs vary by school, at Sairei Academy all wore their final uniforms: girls in winter sailor uniforms of light and deep purple, boys in gakurans of matching colors, each with a "Congratulations on Graduation" ribbon pinned to their left chest. Applause greeted the third-years as they entered through open doors.

The graduating third-years appeared either radiant or nervous. Some girls already looked tearful, seemingly overcome with emotion.

After the graduates took their seats came the national anthem, accompanied by music teacher Shirayuki Saori. Dressed in a wine-red suit with half-up hair adorned by a white ribbon at her chest, Saori's piano performance lived up to her "Princess Teacher" nickname, appearing perfectly demure. Only Yuu knew her true nature as an extreme pervert.

Diploma distribution began with class 1, student number 1. This followed the same sequence Yuu experienced in his previous life's elementary, middle, and high school graduations. However, unlike those ceremonies, many graduates here shared deep connections with Yuu. Besides Sayaka and Riko, other girls might soon become pregnant with his child. Thus, Yuu intently watched each name and face to remember them all.

After diplomas were awarded to nearly 300 graduates came addresses from the principal, board chair, and guests, followed by congratulatory telegrams. Though necessary for such events, Yuu felt inwardly weary of the lengthy speeches but kept it hidden.

After all, his turn approached. He'd been informed beforehand that as student council president, he'd represent current students—unlike his previous life where he'd never held such a role. By now, he'd grown accustomed to public appearances. Hearing Sayaka would deliver the graduate response speech motivated him further.

"Next, the farewell address from current students. Student Council President, Hirose Yuu."  
"Yes!"

The moment Yuu stood to respond, all students' eyes focused on him. Regardless of grade or class, the girls' gazes seemed to glisten—faculty were no exception. If emotions in those stares became visible, Yuu's body would have been enveloped in a pinkish-red aura blending affection, admiration, and lust.

Feeling both shyness and embarrassment, Yuu straightened his back and walked forward. He bowed to guests, faculty, and the podium before ascending the steps. Surveying the gym from the microphone—about 90% female—Yuu felt exhilaration alongside tension at receiving women's passionate gazes.

A flash went off in Yuu's direction. Though parents were seated in the second-floor gallery where photography was prohibited, this was likely from specially permitted photographers from Weekly Fuji or Saito News hired for school materials. Yuu began speaking when the flashes subsided.

"As cherry buds begin to swell heralding spring's arrival, we congratulate all Sairei Academy graduates on this auspicious day. The entire student body offers heartfelt congratulations......"

Yuu had obtained the previous year's script when requested—three pages of 400-character manuscript paper. After multiple reviews, he felt almost no changes were needed. Realizing this was the same script Sayaka had delivered a year ago, now used to send off Sayaka herself, felt like a strange twist of fate.

Once he started reading, it ended surprisingly quickly. After placing the script down, Yuu faced the graduates and added unscripted words:

"I'm truly grateful to have enrolled at Sairei Academy and experienced high school life here. Beyond the excellent educational policies and facilities, meeting seniors has been my greatest treasure. I'll never forget this year spent with all of you graduating today. From my heart, I wish you happiness in your future paths."

These slightly bashful yet sincere words resonated deeply with every graduate.

"H-Hirose-kun... I love you!"  
"I'm so glad we attended the same school..."  
"Yuu-kun... I'll never forget you either. I've engraved you in my heart."

Unintended emotional outbursts and tears erupted among female students. Amid thunderous applause, Yuu bowed and descended the podium. Sayaka's name was announced for the graduate response speech earlier than scheduled—perhaps due to time constraints—as Yuu stepped down. Sayaka rose from her row.

*(Yuu-kun, that was wonderful)*  
*(Thank you. Do your best too, Sayaka)*

Though they exchanged no words during the ceremony, Yuu and Sayaka passed each other with smiling lip movements—perhaps a considerate gesture for the school's officially recognized best couple.

"The season when spring arrives in the Musashino hills. On this auspicious day, we graduates express heartfelt gratitude to the teachers and staff who arranged this ceremony......"

Sayaka's graduate response began. Unlike Yuu who referred to his script, Sayaka seemed to have memorized hers completely, keeping her gaze forward despite having the script at hand. Even accounting for her former student council presidency, Sayaka delivered her address with remarkable dignity.

Her neatly trimmed bangs along her eyebrows. Lustrous black straight hair reaching mid-back. Fair skin and doll-like symmetrical features. Slanted eyes with shining black pupils reflecting strong will. Her voice—neither strained nor loud—carried beautifully, a resonant tone that sank into the heart.

From his seat, Yuu looked up at Sayaka, feeling the same dignified beauty as when they first met. Had he been a real high schooler in his previous life, someone like Sayaka would've been an unattainable flower—someone he couldn't even approach. His rebirth into this chastity reversal world was indeed fortunate.

But Yuu himself had changed. He'd expressed his feelings without hesitation despite Sayaka having a fiancé, leading to their current relationship. Moreover, present-day Sayaka radiated not just beauty but nobility and spiritual strength—likely influenced by becoming Yuu's partner and a mother.

When the response ended, equally thunderous applause followed. After both speeches concluded, the ceremony neared its end. The traditional graduation song "Aogeba Tōtoshi" was sung, followed by the school anthem and closing address. Tearful graduates appeared regardless of gender during the songs.

The diploma ceremony was undoubtedly important, but what followed mattered too. Yuu recalled a custom from his previous world where junior girls requested second buttons from graduating boys they admired—something he'd never experienced.

Now the situation was completely different. The moment Yuu exited the gym, third-year female graduates swarmed toward him desperately. But student council officers waiting near the entrance swiftly formed a guard. After seeing off his first-year male classmates returning to their building, Yuu placated the surrounding graduates:

"I'll visit male seniors first, then go class by class. Please wait."

This typical Sairei Academy compliance made them withdraw obediently. Graduates gathered in front of the gym and courtyard rather than leaving immediately—a tradition where underclassmen also gathered seeking seniors. Groups chatted, exchanged contact information, and took photos. Here too, boys gave gakuran buttons to junior girls, while girls exchanged prepared mementos.

"Congratulations on graduating, Ichijo-senpai."  
"Thank you, Hirose-kun. Your farewell address moved me."

Third-year boys were surrounded by junior girls in front of the gym but made way when Yuu approached. First to greet him was Ichijo Koki—a senior who proactively supported Yuu, handsome in both appearance and character.

"Your post-graduation path is police school in Saitama Prefecture, right?"  
"Police work, huh..."  
"Yeah. I hadn't considered it until summer. Watching you work hard as a first-year made me want a career worthy of Mika and Mariko's efforts."

Koki's lovers—Hayase Mika had secured a Naval Academy spot (influenced by officer relatives), while singer Ichishima Mariko would perform the theme for an April anime, possibly her breakthrough year. Koki wanting a respectable job matching his lovers' efforts stemmed from Yuu's influence. Though male-targeted sexual crimes were rampant, few male police officers specialized in victim care. Mission-driven Koki would become an excellent officer.

When Yuu and Koki shook hands firmly, the surrounding female crowd erupted in cheers and heated sighs—some likely harboring improper fantasies about the school's top two handsome men pairing.

Previously, 60% of Sairei Academy male graduates pursued higher education, 20% employment, and 20% remained undecided—often becoming househusbands supported by working wives. But this year, more graduates chose education after setting life goals. Though unconfirmed, conversations with third-year males like Koki suggested Yuu's influence as student council president.

After shaking hands with all male graduates, Yuu headed toward female classes in the courtyard—starting with Sayaka's class 1.

"Yuu-kun!"  
"Sayaka!"

Yuu went straight to Sayaka and embraced her tightly despite the crowd. Sayaka blushed in surprise but soon calmed and hugged back. Accustomed to this, onlookers smiled warmly.

"Your response was wonderful. As expected of my wife."  
"Th-thank you. Yours was great too."  
"Okay, lovebirds! Mind if we interrupt?"

The class 1 homeroom teacher called to the embracing couple. Unnoticed by them, most class 1 members had gathered before the school building for a group photo with Yuu. Though graduation album photos were already taken, they wanted this commemorative shot. Yuu stood center with Sayaka seated before him, graduation committee members flanking them as Yuu held their waists for the photo.

"Thinking I'll never see Yuu-kun again... it's so sad..."

When one committee member burst into tears, Yuu gently stroked her head.

"You're graduating high school, but we might meet again. We'll always share the bond of being Sairei students. Don't cry."  
"Y-Yuu-kun!?"

As Yuu enveloped her petite frame in an embrace, class 1 students swarmed them with excited shouts.

"Everyone loves you so much, Yuu-kun."

Sayaka said when their eyes met—the composure of a legal wife. Ultimately, Yuu hugged everyone and exchanged words before moving to class 2, repeating the process with commemorative photos and farewell hugs.

By the time Yuu finished with all seven graduating classes including PE course, lunch break had begun, so he returned to the male school building.

Reflecting, a year had passed since his rebirth. This year brought countless encounters, incidents, and a child—a uniquely eventful year for any high schooler. What would the next year bring? Gazing at the greening schoolyard while watched by all graduates, Yuu let his thoughts wander.

---

### Author's Afterword

Graduation ceremonies often occur around March 10th. Initially I considered the 9th, but inserted the viewing event so moved it to the 11th after the weekend. (Though I mistakenly wrote 12th initially and corrected it). Coincidentally, this aligns closely with real-world timing. While this feels like a series finale, the story continues a bit longer.

### Chapter Translation Notes
- Translated "学ラン" as "gakuran" to preserve cultural specificity of Japanese school uniforms
- Maintained Japanese name order throughout (e.g., "Hirose Yuu")
- Preserved honorifics (e.g., "Ichijo-senpai")
- Translated song title "仰げば尊し" as "Aogeba Tōtoshi" with explanation in context
- Used italics for internal thoughts (e.g., *Yuu-kun, that was wonderful*)
- Transliterated sound effects (e.g., "わっ" as "excited shouts")
- Translated explicit terms directly (e.g., "スケベ" as "pervert")