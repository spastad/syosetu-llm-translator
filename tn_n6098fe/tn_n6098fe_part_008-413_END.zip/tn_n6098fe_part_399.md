## 376. Celebrations Continue ③ ~My Baby Grand~

In March, birth announcements began arriving again from women Hirose Yuu had impregnated. This was the second wave of the baby boom.

The news came via letter from Saira (mother is Finnish Susanna Yutilainen) living in Hokkaido, and from Yanai Miku working at the Japan White Cross Society who had examined Yuu's semen. Both were Yuu's half-sisters, likely conceived during June when they had made children.

Saira gave birth to a girl named Leila. Judging from the enclosed photo, her hair was ash-blonde bordering on gray. Her eyes were bluish-gray with facial features and pale skin distinct from Japanese traits. Whether she resembled Saira more or involved atavism remained unclear with a newborn, but she'd undoubtedly grow into a beauty like Susanna and Saira.

Meanwhile, Miku gave birth to a boy. The handwriting was messy and content brief - clearly written in haste. No photo was enclosed. The name given was Kaoru. The custom of giving boys names that could be mistaken for girls' had existed since ancient times as a defensive measure to help boys avoid targeting. Though Yuu suspected Miku chose "Kaoru" due to her scent fetish rather than tradition.

***

The day after graduation ceremony on March 12, school-bound Yuu visited Saito City General Hospital. Hiyama Youko and Aki Kazumi from Class 5 - the first classmates Yuu befriended upon entering Sairei Academy - had been admitted to obstetrics last week. Though they became pregnant and hospitalized simultaneously, Youko delivered on the 9th and Kazumi on the 10th. Among first-years, Class 5 had many girls pregnant with Yuu's children since the start of school, and Youko seemed oddly pleased about being first.

Youko and Kazumi shared a room. Both had baby girls sleeping soundly in incubators when Yuu visited. Though still fatigued from childbirth, their faces lit up the moment they saw Yuu.

"Thank you for giving birth to such adorable babies. You both worked so hard."  
"Un. I did my best. It hurt and was exhausting. But seeing Yuu-kun visit heals me!"

Sitting on the bed edge, Yuu first embraced Youko who'd propped herself up. Her formerly bobbed hair was now a neat short cut. Though naturally slender, her face and arms looked even thinner - almost haggard. Even with youth and stamina at 16, childbirth remained a life-draining ordeal. Yuu stroked Youko as if touching something precious.

Seeing Kazumi's longing expression across the baby, Yuu moved to her bed for a similar embrace. Though Kazumi delivered a day later, she appeared healthier - possibly due to an easier birth. Still, having accomplished this great task, Yuu stroked Kazumi soothingly. Unlike Youko, Kazumi's hair had grown longer since they met. Her breasts and belly still seemed large, but Yuu kept silent about postpartum figures.

"Thank you too, Kazumi. I'm so happy you both delivered safely."  
"Yu... Yuu-kuuun..."

Overcome with emotion in Yuu's arms, Kazumi buried her face without speaking.

Yuu asked about the babies' names. Though unregistered, both mothers had decided. Youko's daughter was Hina.

"Youko is common, but I like my character. Is it too straightforward?"  
"Not at all. Hina has lovely reading and characters. Youko's daughter named Hina feels perfectly natural."  
"Ah... thank you. Hearing that from you reassures me."

Yuu recalled Hina ranked among popular 21st-century baby names. Overly unique names risked difficult readings or strange spellings - so-called "DQN names" or "sparkly names." Yuu preferred readable, safe names over forced uniqueness.

Unlike Youko's straightforward answer, Kazumi hesitated shyly. Clutching a notebook (presumably with names) face-down to her chest, she fidgeted.

"Tell me, Kazumi."  
"B-but..."  
"Come on."

As Kazumi shook her head reluctantly, Yuu tried taking the notebook. When she resisted, Yuu squeezed her breasts instead.

"Ah, ahn! Nooo..."

Kazumi's breasts had grown larger. Unlike bright, lively Youko, Kazumi always seemed unconfident and unable to refuse requests. Yet her figure aroused male desire - in a non-chastity reversal world, she might have attracted gropers. Yuu's hands remembered her size (around large C/small D cup) from fondling her in class.

As Yuu kneaded her braless, pajama-clad soft breasts, Kazumi released the notebook. Among listed girls' names, one circled was Ayumi.

"Ayumi?"  
"Ah... um... I wanted to use Yuu-kun's character... Is that no good?"  
"Of course it's fine!"

Kazumi seemed guilty about using Yuu's name without permission. Yuu understood wanting to pass a loved one's name to one's child - Riko and Emi's children also contained "yu." Yuu wasn't petty enough to mind. Seeing Yuu's approval, Kazumi showed genuine relief.

***

Two days later, Yuu visited the hospital obstetrics department again. With March nearly half over, he'd been coming every other day - partly to visit mother Martina, but also because women he'd impregnated kept being admitted. Yuu's frequent visits boosted staff morale. As "Hirose Yuu's favored hospital," its reputation spread and patient numbers surged. Though security costs increased, hospital finances rose steadily - Yuu was practically a lucky god. Already VIP-treated for semen donation, the pampering intensified embarrassingly. Still, Yuu appreciated guards preventing visitors from mobbing him.

Next to deliver after Kazumi was fellow Class 5 member Gotou Mashiro. Having borne a boy, she got a private room next to Martina's. The delivery was relatively short and smooth. Though told both were healthy, Mashiro panicked upon seeing Yuu.

"What should I do!? What do I do!? Yuu-kun!"  
"Calm down, Mashiro."

Yuu gently embraced the teary, flustered Mashiro. Though told it was an easy birth, perhaps she'd developed postpartum blues? At just 16, future childcare might overwhelm her. All Yuu could do was hold her until she calmed. Embracing plump, busty Mashiro (still the class's largest breasts) soothed yet aroused Yuu, but now wasn't the time. Stroking her now-back-length black hair, he spoke gently.

"It's okay, Mashiro. Tell me what worries you."  
"W-well... actually..."  
"What is it?"  
"I can't decide on a name..."  
"Huh..."

Though anticlimactic, Yuu swallowed his "that's all?" remark. For Mashiro, this was her first child with beloved Yuu, and she was post-delivery sensitive.

Still holding her, Yuu learned she'd assumed she'd have a girl and prepared names, but got a healthy boy instead - she hadn't checked the gender during pregnancy. Usually mothers named babies, but no good name came before Yuu's visit.

"Then shall I name him?"  
"Eh... You'll name him?"

Realizing he'd always left naming to others (only naming Misa and Mari himself), Yuu felt honored. But no ideas came immediately. Pulling back slightly, Yuu peered at the sleeping baby in the incubator.

When Yuu stared, the baby slightly opened its eyes but didn't make eye contact - unable to recognize Yuu visually yet. After a tiny yawn, it slept again. Smiling at its cuteness, Yuu looked back at Mashiro. Thrilled by Yuu's proximity, she smiled back - her droopy-eyed, gentle face was healing. Stroking her mochi-like cheek, Yuu said:

"How about 'Yuuma' from Yuu and Mashiro? Characters: gentle (優) and Mashiro's truth (真)."  
"Yuuma... wonderful! Such a lovely name! As expected of Yuu-kun!"  
"Ah, it's nothing special."

Though an offhand idea, it perfectly satisfied Mashiro. Yuu's sixth son was named Yuuma.

***

Maegashira Yuma went into labor simultaneously with Mashiro. But in her room, Yuma slept like the dead on an IV drip, so Yuu couldn't see the baby. The obstetrician who'd attended Yuu's recent semen donation explained instead. Recognizing Yuu, she briefly showed surprise and joy before resuming professionalism.

"Is Yuma... okay? The baby?"  
"Don't worry. Yuma-chan is just exhausted. The baby's in NICU now but shows no critical symptoms by my assessment."

Yuma had a difficult delivery. Despite being a first-year, her childlike face and 140cm height made her look elementary-school-aged in casual clothes. Yuu hadn't ignored pregnancy risks but couldn't exclude her - one of his earliest Class 5 friends. His desires had prevailed, so he regretted the troubled delivery.

Yuma bore a girl weighing just over 2000 grams - formerly called "premature," now "low birth weight infant." Further tests would clarify, but gestation period was normal with only low weight. Initial tests showed no congenital diseases. Though possibly small and weak-muscled in childhood, she'd likely normalize while growing. Relieved but cautious, Yuu said:

"Doctor, please take good care of Yuma and the baby."  
"Y-yes! Leave it to me. I'll do my best."

Blushing as Yuu clasped her hands, the doctor showed none of her prior clumsiness. Trusting her obstetric skills, Yuu kept holding and staring until nurses separated them so Yuu could visit Martina.

Sliding open the door and drawing curtains, Yuu found Martina reading a magazine against raised bedrest.

"Ahh, Yuu-chan!"  
"How are you feeling, Mom?"  
"Hmm... belly tightness as usual. I'm used to it now."

Yuu hugged Martina as usual, stroked her head, and lightly kissed her. Facing her first delivery since Yuu, Martina felt anxious. Since hospitalization, her parents (who'd avoided her for protecting young Yuu from relatives) and close colleagues had visited. But Yuu's visits delighted her most.

Her due date was just two days away. Her enormous belly made movement difficult - clearly justifying early hospitalization. But Martina seemed bored, reading magazines and books brought by Yuu and Elena besides hospital newspapers.

"You said on phone you had news..."  
"Yes, I had an echo test."

In Yuu's previous world, ultrasound during pregnancy was standard, with gender identifiable after six months. Here, gender remained undisclosed to avoid trouble if male. Ultrasounds only checked for abnormalities. Martina likely got scanned due to belly tightness complaints.

Beckoned closer, Yuu leaned in. With mischievous tone, Martina whispered in his ear:

"The baby... it's twins."

---

### Author's Afterword

While writing this work, I researched pregnancy/childbirth more. In Japan, low birth weight infant rates keep rising - from ~5% 40 years ago to 9.4% in 2019. Nearly 1 in 10 babies. Causes include increased twins/triplets from fertility treatments and medical advances saving extremely low birth weight infants. Twins/triplets occur in ~1% of births. Though common in fiction, I've never actually met multiples.

Many more of Yuu's children will come, but Martina's delivery concludes the main story's birth scenes. I definitely wanted to include hers.

2022/3/11

Correction: Previously wrote "X-ray" for fetal gender checks, but it's actually ultrasound (echo) images.

### Chapter Translation Notes
- Translated "出産ラッシュ" as "baby boom" to convey concentrated births
- Preserved Japanese name order (e.g., "Yanai Miku")
- Translated "匂いフェチ" as "scent fetish" for accuracy
- Rendered "マタニティブルー" as "postpartum blues" using clinical terminology
- Used "NICU" without translation as standard medical acronym
- Translated "ナーバス" as "sensitive" to convey emotional state
- Preserved honorific "-chan" for Yuma as per style rules
- Translated "ポンコツぶり" as "clumsiness" to match context