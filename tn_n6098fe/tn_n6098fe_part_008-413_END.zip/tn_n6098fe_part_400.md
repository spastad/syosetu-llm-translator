## 377. Celebrations Continue ④ ~Glad to Be Born~

Friday, March 15. Martina's due date.

Yuu had been restless since the night before, and Elena was also fidgeting.

Martina had been hospitalized early, and since it was just the two siblings at home, they had been having sex almost every night. However, the previous night, they refrained in case of an emergency call—though they did sleep together in the same bed.

First thing in the morning, Yuu called the hospital and was told that her condition was still stable, so he went to school as usual.

After school without incident, he skipped student council activities for the day and headed straight to the hospital.

As usual, Yuu headed to the waiting room surrounded by numerous security guards and nurses.

Although Martina was the only one scheduled to give birth that day, the security guards and nurses seemed visibly tense.

"Yuu!"

"Sis. You're already here. That's early."

Elena had already arrived at the hospital.

It seemed his sister was also worried about Martina.

She wasn't showing her usual lustful brother-complex self that she did at home, but was putting on a cool facade for the outside world.

"Have you seen Mom?"

"I saw her as soon as I arrived at the hospital. She seemed to be doing well."

"Just to be safe, I'll go see her too."

"Then I'll come with you."

Elena had arrived around 2 PM, and at that point, Martina hadn't gone into labor yet.

Just as Yuu and Elena were about to leave the waiting room together, one of the nurses in charge of Martina rushed in.

"Hirose-san! It seems your mother's water has broken!"

"Ah! I'll go right away!"

By the time Yuu and the others arrived, Martina was just leaving her room to move to the delivery room.

Healthy pregnant women can walk, but in Martina's case, they were moving her on a stretcher just in case.

"Mom!"

"Mommy!"

"Yuu-chan, Elena... It's okay. I'll give birth to a healthy baby."

Yuu must have looked extremely tense.

Holding his hand, Martina answered firmly.

Sweat was already beading on her forehead. She might have been in pain from the contractions starting.

But Martina bravely smiled and answered.

"Yeah. I understand. If it's Mom, I'm sure it'll be fine."

"Do your best!"

Yuu also bowed to the accompanying nurses.

The nurses, while showing their tension, didn't panic at all. They had professional expressions.

Yuu and Elena watched as the stretcher, which had been stopped briefly, started moving again.

They returned to the waiting room, but Yuu and Elena couldn't settle down.

Even with the TV on or a magazine in hand, they couldn't take in the content.

That said, the birth wouldn't be over immediately.

Kanako, who had been standing guard like a sentry at the entrance, called out to them, and they decided to have dinner first.

After finishing the boxed meals they had bought, they felt a little calmer.

Yuu and Elena sat side by side in chairs. Holding hands, Elena rested her head on Yuu's shoulder.

The TV screen, left on, showed a variety program featuring only female celebrities, followed by a drama set in a school, but at least Yuu was distracted and his expression didn't change. Elena seemed the same.

"Mom is amazing, isn't she?"

Elena muttered.

"I've been saying I want to have Yuu's baby for a long time, but having a baby is really tough. They say it's ten months, right? Growing the baby in your belly for a long time, with morning sickness and difficulty moving. And when it's time to give birth, they say it's incredibly painful."

"What's wrong, Sis? Are you getting cold feet thinking about being pregnant yourself?"

"Th-that's not it! That's... it's just that Mom went through all that to have me and Yuu, and she practically raised us alone, didn't she? And now she's having twins? Mom is truly amazing!"

"Yeah. I completely agree with that opinion."

Yuu reached out with his free hand to pat Elena's pouting head, and she smiled softly.

Compared to the previous world, pregnant women are blessed economically and environmentally.

As a result, women who give birth and raise children alone are the majority.

There are men who cooperate with their wives, or who work hard as stay-at-home husbands doing housework and childcare, but there are also many men who just ejaculate and then don't care.

Even in the 21st century that Yuu knew, where gender equality was advocated, many women worked while raising children.

One reason for that was that only the mother could breastfeed, and they were more responsive to night crying, among other reasons, so childcare tended to be the mother's job—that can't be denied.

"But still, I guess I'm a little anxious. What if Mom..."

"Let's believe in Mom who's doing her best right now."

"Yeah. You're right."

Even in modern times with advanced medicine, nothing is absolute.

Once you start thinking about bad things, it never ends.

Yuu thought that for now, they could only believe in and wait for Martina, who was doing her best to give birth to twins who would be like their younger siblings.

  

  

  

The night grew late.

Even though Martina had given birth to two children before, twins apparently take time. According to the nurse, twins are often born at the same time, but sometimes there can be a time gap.

Feeling drowsy, Yuu fell asleep on Elena's lap.

When Yuu woke up later, Elena was also nodding off.

It was almost midnight.

He noticed the sound of hurried footsteps.

In the deserted hospital hallway, vigilance had slackened.

The protection officers were taking turns eating and resting.

At that time, Miyo and Yoriko were on watch, but since it was the attending nurse who came, they let her through.

"Hirose-san!"

"What's wrong?"

Yuu and Elena were already standing.

The nurse closed the door behind her so that it wouldn't be heard outside.

Concerned, Yuu approached her. Fortunately, her expression wasn't dark.

Sweat beaded on her forehead, but she seemed to have the satisfaction of a job well done.

"They're born... healthy twin babies. A boy and a girl."

"Whoa! We... did it! Thank you!"

"Hyah!?"

In his joy, Yuu hugged the nurse in front of him.

Her slender, petite body was not only squeezed by Yuu but lifted off the ground.

From behind Yuu, Elena, also showing joy, clung tightly.

The nurse, in a panic from the simultaneous shock and joy, was only released after the protection officers, hearing the commotion, called out to Yuu.

That night, Martina was exhausted, and the hospital was busy because it had been a while since twins were born.

So Yuu and Elena just said goodbye to Martina and went home. The newborn babies had been moved to a specially prepared nursery. For just a short time, Yuu and Elena were able to see the babies sleeping through the window.

That night, perhaps because they were excited, Yuu and Elena took a bath together and had intense sex in the bathroom and washroom. When they moved to the bed and Yuu came inside her for the third time, Elena fainted.

  

  

  

The next evening, Yuu and Elena went to visit Martina.

"Wow~, they really are twins."

"They're even posing the same way."

"So cute!"

After a labor that took about six hours from when her water broke, the twin babies were being cared for in the nursery, so Martina seemed to have rested well overnight.

Yuu had been worried, but Martina's complexion looked better than expected.

Martina's parents had visited around noon, but the twins had only just arrived in the room, so they shared the joy of the first meeting with Martina.

Newborns have red, wrinkled faces and look more like monkeys than humans.

Also, since they can't hold their heads up, they can only lie on their backs.

Twins can be either identical or fraternal depending on the fertilized egg.

Martina gave birth to fraternal twins. Compared to identical twins, they tend to look different, but for now, they looked exactly alike, even synchronizing their poses.

"Mom, you really did great."

"I'm so glad both Mom and the babies are safe. I'm truly relieved."

"Yuu was uncharacteristically flustered."

"Sis... Speaking of which, you were surprisingly calm."

"Fufufu. Women are steady in times like this."

In front of the twin babies, the three of them laughed together. Yuu thought to himself how wonderful it was that they could laugh together now that they were healthy. Martina and Elena must have felt the same.

The Hirose family had grown to five.

If Elena got pregnant, it would grow even more.

The joy of having a loved one become pregnant and give birth, and the family growing, was irreplaceable.

"By the way, Mom, have you decided on names?"

"Names... Hmm. What should I do?"

Martina apparently hadn't had time to think about names.

"I had a few candidates for the girl's name. But the boy's is difficult. Yuu-chan and Elena, help me think."

Martina's policy had been consistent since she first got pregnant.

Easy to say, and understandable for both Japanese and Westerners.

Looking at the notes she had written since becoming pregnant, there were names like Aina, Erika, and Runa.

They could use kanji or leave them in katakana.

"Aina and Erika sound similar to Sis's name."

"I think Aina is cute."

Martina couldn't decide, and Elena seemed to favor Aina.

To Yuu, Aina was the heroine of an OAV he saw when he was young. Erika reminded him of an actress.

As Yuu watched the sleeping twins, an idea suddenly came to him.

"Hey, since they're twins, I'd like to give them names that are related."

"Oh, Yuu-chan, that's a nice idea!"

"So, what should we do?"

"We'll think about that now."

He muttered this and that while thinking, but suitable names for twins didn't come to mind immediately.

Yuu looked at the notes Martina had written again.

"Runa has an image of the moon, right?"

"Originally, wasn't it derived from the moon goddess?"

"Then, how about naming the girl Runa after the moon, and the boy after the sun?"

"I see... What would be good?"

"Hmm. Since it's Runa, how about something after a sun god?"

The obstetrics department had materials like kanji dictionaries and encyclopedias for naming.

As far as they could tell from looking them up, sun worship exists worldwide and there are many sun gods, but there were no suitable names for a Japanese boy. Names like Apollo, Amaterasu, or Indra would be problematic.

"Then, how about Taiyou (sun)?"

"Hmm, Taiyou, Asahi, Yuuhi...? Doesn't really click."

An image of the sun shining brightly came to Yuu's mind.

"Hare... hareru, Haru."

"Haru!?"

"Haru and Runa... The names connect, that's nice!"

With Yuu's muttered words as a trigger, the boy was named Haru (晴) and the girl Runa (ルナ).

  

  

  

While looking at Haru and Runa's sleeping faces and chatting, nearly two hours had passed.

It was already getting dark outside.

Even though Martina looked well, it was better to let her rest since she had just given birth.

When Yuu said he was leaving, Martina looked sad.

Yuu hugged her gently without putting too much weight on her, and Elena hugged her from the other side.

"I'll come again."

"Mom, rest well."

"Okay. I need to recover my strength quickly. I want to go home soon."

Normally, she would be discharged in 3-4 days if there were no problems, but the hospital said it would be better to stay for a week just in case.

Recovering strength after childbirth is important.

In modern times, it's unthinkable, but in the past, many women died due to poor postpartum recovery.

In Martina's case, because of her age, they were taking a longer time before discharge.

After the farewell hug, Yuu moved his face closer because he had something to tell her.

"This Sunday, I'm going to visit Dad's grave."

"Sakuya-san's..."

"Yeah. I was invited by Haruka-san before."

Sakuya had a private cemetery specially built in Tokyo.

Even now, on Sakuya's death anniversary and birthday, many people gather, but even on other days, women from all over Japan and the world visit constantly.

For Yuu, now that a year had passed since his rebirth, and as he thought about his own future, Haruka's invitation was timely.

"Come to think of it... I haven't been in a while. No, I've completely stopped going."

"Then, once Haru and Runa can hold their heads up, let's all go together."

"Yeah! I want to go after so long!"

It seemed that when Yuu and Elena were still children and got along well, the three of them had visited.

It was a past that Yuu could hardly remember now, but Elena remembered.

Besides preparing to welcome the twins at home, Yuu had various plans including the grave visit.

Anyway, busy days were still ahead for Yuu.

  

  

  

  

  

  

---

### Author's Afterword

So, next chapter, we go to visit Sakuya's grave.

I read online (I don't know if it's true) that there was a man (Japanese) named Apollo.

Also, while researching sun gods, I thought Sol (Roman mythology) might work, but parents who thought the same named their children Soru (空輝) or Soru (塑琉)... and it had a bad reputation, so I gave up.

Other sun-related name candidates were You (陽), Kou (晃), Akira (旭), Wataru (亘), and I agonized over them until just before posting.

Haru (晴) is already used by Haruka, and with so many characters, the kanji are bound to overlap, but I decided not to worry about it.

### Chapter Translation Notes
- Translated "破水" as "water broke" (medical term)
- Translated "陣痛" as "contractions"
- Translated "十月十日" as "ten months" (common Japanese expression for pregnancy duration)
- Translated "悪阻" as "morning sickness"
- Translated "船を漕いでいた" as "nodding off" (idiom for dozing)
- Translated "産後の肥立ち" as "postpartum recovery"
- Preserved honorifics: "-chan" for Yuu and Elena, "-san" for others
- Used "Mom" for "ママ" and "Mommy" for "ママ" in Elena's dialogue to reflect the character's affection
- Translated "色情魔ブラコン" as "lustful brother-complex" to convey the original nuance
- Translated "OAV" as "OAV" (Original Animation Video) without expansion to preserve the term's familiarity
- Translated "一卵性双生児" as "identical twins" and "二卵性双生児" as "fraternal twins"
- Kept the names "Haru" and "Runa" in romaji with furigana in parentheses for the first occurrence in the narrative
- Used "Sakuya" for "咲弥" as established in Fixed Character Names
- Translated "命日" as "death anniversary"
- Rendered internal thoughts in italics: *(This is concerning.)* → *(This is concerning.)*
- New dialogue lines: Each speaker's dialogue starts on a new paragraph unless preceded by an attribution (e.g., "Yuu turned to Elena." followed by dialogue on same line)
- Sound effects: Transliterated "バタバタ" as "hurried" (contextual) and "ぴたっと" as "tightly"