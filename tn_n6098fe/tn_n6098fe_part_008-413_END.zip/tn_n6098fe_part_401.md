## 378. Grave Visit ① ~Time Stranger~

### Author's Preface

The big earthquake surprised me and delayed my posting.

Is everyone safe?

---

On the early afternoon of Sunday, March 17, a car carrying Yuu was heading toward Tokyo.

Their destination was the cemetery where his biological father Toyoda Sakuya was buried. Sakuya, who had received a state funeral-level ceremony, was enshrined in a private cemetery.

In modern Japan, Sakuya was likely the only private individual to own a personal cemetery rather than sharing a communal burial ground.

That's how significant the impact of his death had been.

The invitation today came from Toyoda Haruka, standing director of the Toyoda Sakuya Memorial Foundation.

They planned to meet Haruka at the site.

Even on the curve-filled Metropolitan Expressway where Yuu wouldn't want to drive, Oosato Yoriko—both protection officer and driver—handled the car smoothly.

As the car entered surface streets, Yuu gazed out the window, inwardly surprised at how different the Minato ward waterfront looked compared to his memories of previous visits.

In this reclaimed land area, development had progressed year by year in the 21st century.

He remembered increased transportation options and towering high-rises and condominiums.

But in this 1991, development hadn't advanced that far.

The Tokyo Monorail to Haneda Airport existed, but the Rinkai Line wasn't operational yet.

Areas that would later be called Shinagawa Seaside and Oi Wharf showed construction activity, but the scenery remained bleak.

The destination was apparently near Oi Wharf Park.

From articles Yuu had read, it was explained as an area Sakuya had emotional ties to from his childhood, though details weren't specified.

Most materials about Sakuya started from his late teens or at earliest middle school years, with extremely few touching on his upbringing. Yuu recalled this was because of a childhood tragedy—the accident that triggered Sakuya's reincarnation.

Wanting to hear details about this from Haruka was another reason Yuu accepted the invitation.

The parking lot was as spacious as a highway service area, large enough for multiple buses with an adjacent bus stop, but being a weekday, it was mostly empty.

Only a few cars were parked near the entrance. A group of foreigners with colorful hair and outfits were just leaving.

It seemed to be one of Tokyo's minor tourist spots.

The car carrying Yuu parked at a distance from the entrance.

When hearing "cemetery," one imagines vast grounds divided like a grid with countless graves.

But only Sakuya was buried here. Yuu had heard the foundation managed the site.

The white domed building gave no religious impression.

If anything, it resembled a public cultural center or library.

Kanako exited the car first and opened Yuu's door just as several uniformed security guards jogged over.

Haruka must have notified them. Surrounded by guards, Yuu was guided not to the public entrance but through a staff-only door into the compound.

Walking down a long corridor without encountering anyone, Yuu took an elevator down to the basement and was led to a room.

The plate read "Director's Office."

Beyond the door was a wide desk and reception set resembling a school principal's office.

As expected, Haruka in a black kimono sat at the desk chair, but an unfamiliar woman occupied the black leather sofa.

The woman wore a black fur coat and sunglasses, with only her bangs visible under a white headscarf. Yuu recalled that wrapping style being hugely popular long before his birth, back in the Showa era.

Her age was indeterminate, but her face shape, well-defined nose bridge, and sensual lips suggested a beauty about ten years older than Yuu.

The moment Yuu entered, she stood smoothly.

Her swollen belly revealed she was pregnant. Her bearing indicated she was no ordinary person.

Though not particularly tall, she radiated a captivating aura.

Seeing Yuu, she smiled and parted lips painted with vivid red rouge, speaking in a sultry voice.

"Yuu, long time no see."

Simultaneously, she removed her sunglasses.

"T-Takako-san!"  
"I wanted to see you."

Actress Tsutsui Takako—whom Yuu had met and become intimate with at Hesperis, the foundation's hot spring resort facility in Hakone. Mother of current student council officer Nana.

Yuu called her name while moving to embrace her.

Though careful not to press against her belly, it was more than a light touch.

"You've grown quite big. When's your due date?"  
"About another month. Fufu. Never thought I'd be giving birth at this age."

Takako laughed mischievously.

Neither specified whose child it was. Both knew it was conceived during their passionate encounter at Hesperis.

"Is Nana behaving well?"  
"Ah, she's an incredible sister—way too good for me. You've heard, right? That she's pregnant."  
"I heard. Getting both mother and daughter pregnant... even Sakuya-san never did that. Oh, Yuu."  
"Well, both you and Nana are irresistibly attractive."  
"My, catching an old woman like me. With all your options, Yuu."  
"Ahem."

Reuniting after so long, emotions ran high as Yuu and Takako held each other and gazed into each other's eyes. Judging this would get nowhere, someone cleared their throat.

Both apologized for ignoring the room's owner.

But Haruka remained displeased.

Though standing, she stayed aloof and avoided eye contact. As Yuu hesitated, Takako lightly patted his back.

Reading Takako's expression, Yuu approached Haruka.

"Haruka-san"  
"......"  
"I wanted to see you."  
"!"

Though decades older and previously able to maintain composure seeing Yuu with women as the foundation's representative, Haruka was different now. Perhaps because of their January encounter at an Akita hotel. Haruka seemed to have regained her feminine passions.

Yuu hugged Haruka like a lover, thanking her for her constant support.

This completely restored Haruka's mood.

Yuu helped serve tea before sitting opposite Haruka and Takako on the sofa.

"Now then, today I invited Yuu to visit Sakuya-san's grave... but earlier, Yuu mentioned wanting to know more about Sakuya-san."  
"Yes."  
"I thought this was a good opportunity, so I invited Takako-san too."

During a recent call with Satsuki about the futures of children already born or soon to be born—including Yuu's wish to know more about his father Sakuya—the request reached Haruka via Satsuki.

The reason: Sakuya, like Yuu, came from another world.

Only the First 4—Sakuya's first four wives—knew about his reincarnation.

Plus Takako, called his last mistress. Yuu learned this from Takako, which likely explained her invitation.

Another reason for inviting Takako: As a famous actress pregnant without naming the father, she drew media attention. Meeting Yuu—also well-known—would be extremely difficult otherwise, so Haruka created this opportunity.

Incidentally, the basement director's office had anti-wiretapping measures, no windows for peeping, and guards at the entrance preventing intruders.

As Yuu and Takako straightened up, Haruka began speaking.

"I remember clearly when I met Sakuya-san. I was eleven then."  
""Eleven!?""  
"Come to think of it, very few should know this. I'll tell you now—myself, Natsumi, Akiho, Fuyuno, and Koyuki one year younger too."

"All women using the Toyoda surname now lived in an orphanage near here. Sakuya-san suddenly appeared there. With his long hair and cute face, we didn't think he was male at first. Fufufu. Anyway, we abandoned children all took the Toyoda surname when marrying."

Both Yuu and Takako widened their eyes in shock at this casually revealed truth. Few knew about Haruka and the others' childhoods, just as with Sakuya.

Takako voiced the first question.

"Um, foundation materials mentioned Sakuya-san suffered a childhood car accident losing his entire family. Then he was supposedly adopted by some household..."  
"That's the official explanation."  
"Official?"

This matched what Yuu heard from Takako.

Like Yuu, the original Sakuya boy of this world was in a car accident with his family.

Sakuya alone survived but was severely injured. While unconscious, the consciousness from another world's Sakuya entered his body. That was Yuu's understanding.

Losing his family all at once with no relatives, going to an orphanage made sense—but he was a precious male child. No matter how feminine he looked, police and medical institutions couldn't miss that. If identified as male, countless families would want him.

Though unconfirmed in existing records, it was speculated he was adopted by an affluent, even politically powerful family.

"Let me correct what I told Takako-san before. Strictly speaking, Sakuya-san didn't reincarnate—he appeared before us rejuvenated."

Yuu and Takako were speechless.

If Haruka's words were true, Sakuya—after dying—rejuvenated and crossed worldlines as an eleven-year-old.

An outrageous tale, but Yuu himself experienced reincarnation.

He couldn't dismiss Sakuya's experience as nonsense. Rather, he thought this might be another pattern.

"So the Sakuya-san who appeared before you was... Sakuya-san's..."  
"His consciousness was 31 years old when he died, we learned later."  
"So same as me then."  
"Incidentally, there really was a same-named boy who lost his family in that accident. Even after recovering, he couldn't cope and was protected by national medical institutions. Sadly, he eventually took his own life due to mental illness. Later, documents were altered to make it seem that boy was Sakuya-san."

They could only be stunned by how casually this secret was revealed.

Haruka smiled faintly like a mischievous child caught misbehaving.

"When Sakuya-san was discovered to be male at the facility, it caused an uproar. But somehow he stayed instead of leaving. We were children then, so we fought a lot. But eventually, we all came to love him. I'll always be grateful to the director."

Suddenly appearing in this world, Sakuya had no family register and couldn't even attend school.

Since the orphanage had children abandoned without birth registration, the director apparently pulled strings to cover for him. She seemed like a harmless old woman but had connections.

Later, they linked him to the original same-named Sakuya.

Suddenly, Yuu recalled something.

"I believe Father died at..."  
"Age 31."  
"And the age when he died before rejuvenating was..."  
"Th... 31."

Haruka's eyes widened, then her expression turned grave as she pondered.

"Living Sakuya-san had many puzzling aspects... well, we loved him including those. Anyway, he often said he wouldn't live long. Then, right after his 30th birthday celebration I think? He wrote a voluminous notebook—more than a will. He must have been certain death was near."

Both Yuu and Takako were speechless.

Rather, something bothered Yuu, but he stayed silent listening.

"Even at the facility, women harassing and assaulting him was daily life. No matter what danger he faced, he annoyingly stayed calm."

"That he died in such trouble was unbelievable... Anyway, after his death, we acted according to his testament notebook."

After Sakuya's death, Haruka and the four wives organized the funeral and evacuated all wives, mistresses, and children to a Hakone hot spring facility—later renovated into Hesperis resort—showing calm leadership.

Naturally, this owed to Haruka's responsibility and magnanimity, but Sakuya's testament instructions were crucial.

Moreover, Sakuya meticulously recorded women he'd been intimate with during travels abroad.

This later helped recognize mistresses and children.

"Rereading it recently, I found an entry about meeting a gang woman named Jane in New York months before his death. I suspect this was Jane Grimwood who kidnapped Yuu."  
"As I thought..."

Yuu learned from reports that Jane Grimwood—prime culprit and one of few survivors of January's kidnapping—would undergo full interrogation and punishment in America.

Though seemingly reformed during questioning, her crimes clearly stemmed from encountering Sakuya as a teen.

Now they had corroboration.

"There's just one thing we disobeyed the testament about—or had to."

Haruka smiled modestly.

It concerned Sakuya's funeral and subsequent treatment.

He wanted to leave assets to his wives and children, wishing for a simple burial without lavish ceremonies or tomb.

But society wouldn't accept that.

As it stands, annual memorials and birthday celebrations occur at Sakuya's enshrined facility, with constant visitors domestic and foreign.

As the mood turned somber, Yuu murmured offhandedly.

"Maybe I can only live until the age I first died too?"

At this remark, both Haruka and Takako stared at Yuu in shock.

---

### Author's Afterword

Yuu revealing his reincarnation to Takako while learning Sakuya also transmigrated happened in Chapter 191.

The truth about Sakuya meeting Haruka and others at the orphanage—and why they kept the Toyoda surname (taking Sakuya's name rather than their abandoning parents')—was planned long ago.

I considered writing it in a post-main-story side story but revealed it here instead.

### Chapter Translation Notes
- Translated "ファースト4" as "First 4" per established terminology
- Rendered "遺言ノート" as "testament notebook" to preserve literal meaning
- Kept "ヘスペリス" as "Hesperis" per Fixed Reference terms
- Maintained Japanese name order (Toyoda Haruka) and honorifics (-san)
- Translated "我慢できないくらい魅力的" as "irresistibly attractive" to convey intensity
- Preserved temporal references (Showa era, 1991) without localization
- Italicized internal reactions like *"So same as me then"* for monologue