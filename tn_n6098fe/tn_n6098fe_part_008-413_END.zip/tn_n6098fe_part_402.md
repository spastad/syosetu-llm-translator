## 379. Grave Visit ② ~Let's Go Avant-Garde~

### Author's Preface

Since the previous chapter was dialogue-based, some factual relationships might have been unclear, so I'll provide supplemental explanation.

Yuu: Died in accident at age 40 → Possessed body of same-name boy (15) in Chastity Reversal World who suffered life-threatening injuries after being attacked by female group on way home from junior high graduation.

Sakuya: Died at age 31 → Possessed body of same-name boy (11) in Chastity Reversal World who suffered life-threatening injuries in traffic accident (as heard from Takako in Chapter 191).

**[Truth]** Sakuya: Died at age 31 → Reincarnated in Chastity Reversal World becoming 11 years younger (mind age 31). Died 20 years later at age 31.

Following Sakuya's example, might Yuu also only live until his previous life's death age (40)?

---

Yuu's muttering triggered a heavy atmosphere.  
Takako was the one who tried to break through it.

"It was just coincidence with Sakuya-san, right? It's hard to imagine Yuu dying the same way."  
"Th-that's right. With men's average lifespan now over 70, unless he's terribly unlucky with accidents or incidents..."

Both Takako and Haruka leaned forward trying to deny Yuu's idea, but Yuu slowly shook his head.

"I can't imagine when I'll die either. Probably, Father felt the same until midway through. But in his special circumstance of receiving a second life, I think he might have had some premonition when death approached. That's why he left his notebook."

When Yuu responded, both women fell silent.  
They wanted to deny it. By common sense, it should be absurd.  
But whether Sakuya or Yuu, they appeared in this world in extraordinary ways, making denial impossible.  
Yuu grasped both their hands resting on the table and smiled reassuringly.

"Let's treat it as just a hypothesis. Dying at 40 would be too early. But I already died once at 40 and restarted from 15, so even if I died at 40 again, I'd have lived 65 years total with the bonus."

Yuu reflected on his past.  
Had he survived the accident that day, what life would he have led?  
Remarriage would have been extremely unlikely, leading to a lonely life ending in solitary death.  
Being reborn in this world was essentially bonus lifetime granted by the gods.  
Even if death comes earlier than average, he wants to live without regrets.

"Besides, my current happiness is incomparable to my previous life. In just one year, I've gained fiancées and many children born. Wishes unfulfilled in my previous life came true. And I've met stunning beauties like Haruka-san and Takako-san, even having sex with them? No other man is this blessed."  
"My, my..."  
"Quite the smooth talker. That part resembles Sakuya-san exactly."  
"Bloodline, perhaps?"  
"Fufufu"

Both mature beauties smiled while holding Yuu's hands.  
Would what happened to Sakuya happen to Yuu? As mortals, they couldn't know no matter how much they pondered.  
They decided to shelve the matter for now.

During the calm moment, Yuu heard episodes about Sakuya's orphanage and school days from Haruka.  
Not only Yuu, but even Takako was hearing most for the first time.  
However, since men faced harsher conditions then, Sakuya apparently struggled.  
He was sometimes attacked by seniors or teachers unknown to Haruka, but always fought back.  
*Must've fucked them till they couldn't stand*, Yuu imagined, having been in similar situations.

During junior high, Sakuya was smart but didn't apply himself academically, maintaining average grades.  
Instead, he focused on understanding society's mechanisms and planning his future.  
Haruka often remembered him skipping class to stay in the library.  
He even visited government offices, universities, newspaper companies, and local assembly members' offices - interviewing adults under "social studies tours."  
Meaning he'd been considering entering society since then.

Orphanage friends served as his guard to prevent random attacks.  
They decided to share Sakuya's fate - not advancing to high school but working while having children.

When conversation lulled, they temporarily left to refill tea.  
Moistening his lips while enjoying the premium tea's aroma, Yuu broached something he'd been thinking.

"From Father's and my perspective, this extreme gender imbalance feels abnormal and concerning for the future. So Father probably felt he had to act quickly. Why was he granted a second life? Wasn't it to change this world?  
But he knew one person couldn't change it easily."  
"Yes. I believe so too. He once said: 'I'll become the foundation stone for changing this world.' That normalization would take generations."  
"Then I'm the only one who can inherit Father's will and pass it on."  
"Yuu..."

Haruka had likely been mentoring him for this purpose, Yuu realized.  
In hindsight, being invited to Hesperis last summer and meeting Takako and others was part of it.

"So after high school graduation, I'll—"  
"We'll prepare a proper position for Yuu in the foundation."

Before Yuu finished, Haruka declared it like a decided matter with a smile.  
Yuu originally thought working at the foundation might be best, so he didn't object. He wondered about the position briefly, but Takako eagerly circled the table and pressed against Yuu's side.

"Hey, Yuu?"  
"Hmm?"  
"Aren't you interested in showbiz?"

She'd removed her coat, revealing her figure through a thin sweater, paired with loose wide pants.  
Yuu felt her soft body while her elegant perfume tickled his nose.  
Takako brought her lips near Yuu's ear, whispering in a sexy voice like her young-man-seduction scenes in dramas. Yuu nearly got erect just from that.

"Sh-showbiz? I'm... not suited for it."

Compared to pre-reincarnation, he'd built tolerance for public appearances. But acting before cameras was different.  
His Wish CM co-starring had no face shots. Though lines were minimal, he caused many NGs.  
During the sex-ed video shoot, he managed by having sex naturally rather than acting.

"Oh my, why?"  
"I'm bad at acting."  
"You co-starred with Wish in a CM, didn't you? I'm jealous. I want to do it with Yuu too."

Takako's hand touched Yuu's face as they locked eyes.  
At close range, Yuu saw himself reflected in Takako's black pupils.  
Despite their parent-child age gap, her pouting face seemed adorable. Truly worthy of "femme fatale" title.

"Ju-just a CM might..."  
"Really? Promise! With Yuu, even without acting—"  
"Yuu is Sakuya-san's important successor. His main job is foundation work. I'll teach him everything hands-on."  
"He can do entertainment while at the foundation! I know! Let's invite Nana too. Of course I'd play Yuu's wife with Nana as our daughter."  
"Ah, ahaha"

Haruka had approached from the other side without notice, petting Yuu's head like a child.  
Takako was likely joking or wishful thinking - Yuu/Takako co-starring seemed unrealistic.  
But Takako had impressive nerve joking like that before Haruka. Her showbiz ups/downs weren't for nothing.  
Sandwiched between the two beauties bantering, an internal phone rang suddenly.

"Yes. Alright. Show them in."

From Haruka's response, someone was coming.  
Yuu looked at Takako, who kept smiling silently. She knew but wouldn't tell.  
Perhaps someone Yuu hadn't met.  
Meanwhile, Yuu stroked Takako's swollen belly.

About 10 minutes later.  
After hearing voices outside, the door burst open dramatically.

"Heyyyy... Waaah!"

Turning, Yuu first saw Kanako and Touko frowning in the hallway with facility guards.  
But more eye-catching was the girl in uniform pointing at Yuu with flashy manicured nails.  
Navy blazer completely unbuttoned. Checkered skirt abnormally short. White sweater pulled down to skirt-hem level. Legs neither too thick nor thin, stretching sleekly ending in loose white socks.  
Medium-long light brown hair reaching chest with silver streaks - straight but with spiral curls at ends.  
Makeup emphasized long lashes and wide eyes. Lips with whitish rouge. Though skin wasn't tanned, "kogyaru" flashed in Yuu's mind.

"Th-the real Yuu-kun! OMG OMG super OMG! Sooooooo handsome! Yaaahn! I've wanted to meet you foreeeever!"  
"O-oh..."

Yuu was dumbfounded by her shrill, excited voice after that "greeting."

"Arisa."

Haruka's low voice called out.  
Not loud, but it cut off the girl - Arisa - stiffening her face.  
She turned robotically toward Haruka.

"Pyai! G-g-gra—"  
"Huh?"  
"S-sorry... Sorry! Haruka-san!"  
"Mhm. Redo your greeting."

Though smiling, Haruka's imposing tone made the girl bow and retreat, closing the door.  
After 3 minutes, knocking came.

"Yes. Come in."  
"Pardon me."

Re-entering, she'd properly buttoned her blazer.  
She smiled shyly at Yuu.  
He found her cute while sensing resemblance to someone.

"H-hi. I'm Toyoda Arisa. M-meeting Hirose Yuu-k... sama is super exciting - I mean, an honor! Ah! And my mo... mom is always indebted to you!"  
"Mom...?"

Yuu momentarily wondered if she was Haruka's daughter. Age-wise, they could be mother-daughter.  
But Haruka and Sakuya only had Satsuki.  
When Yuu compared them, Haruka smiled wryly.

"Satsuki's daughter."  
"Ah! That makes sense... But wait. Satsuki-nee's daughter is..."  
"Arisa-chan, you'll be in 9th grade next term, right?"  
"Y-yes! Thaaat's right!"

Takako, also a foundation director, apparently knew her.

"Got it! Satsuki-nee's... I've wanted to meet you!"  
"Hyowa!"

Yuu approached without hesitation and hugged her tightly, startling Arisa. She froze rigid.  
To Yuu, as daughter of Satsuki - his close half-sister - she was his niece. He showed natural affection.  
Initially, she'd seemed mature enough for high school, likely over 160cm tall with near-adult body. But she was only in 8th grade.

"Eh... Me? Hugged by real Yuu-kun? Why? Why? Dream? Illusion? Hachu-mu thing?"  
"Not a dream, real Hirose Yuu. Nice to meet you, Arisa. You're as beautiful as Satsuki-nee - surprised me."  
"Ahh... Yeah... Seriously dangerous nya. Might die like this..."

When Arisa looked up at Yuu, their breath-mixing proximity made her eyes dart unfocused, face rapidly flushing crimson.  
As she staggered, Yuu held her tightly to prevent falling, but she didn't react.  
Though Yuu couldn't see, Arisa's mouth relaxed against his chest.

"Yuu, it might have been too stimulating for Arisa-chan."

Arisa attends private girls' junior high (not public) with lenient policies on hair/clothing if academics are maintained.  
Despite kogyaru appearance/speech, she's quite bright for her age.  
Moreover, elementary-aged Arisa attended foundation events with Satsuki, but entering puberty made her avoid parental outings.  
So it had been long since she interacted with boys.

Teen girls without boy immunity might go wild seeing Yuu directly, but Arisa becoming meek like a borrowed cat was cute. Or rather, her pureness beneath appearance was charming.  
Yuu sat Arisa on the sofa while holding her. She remained pliant as he stroked her head, eyes narrowing with melting smile.

"Ahhaa... Why? When Yuu-sama touches me, I go po-waaan..."  
"Arisa and I are family, right? No need for honorifics or formal speech."  
"Really!? Yuu-kun is such an understanding guy!"  
"Arisa. Remember: Familiarity breeds courtesy. Especially since Yuu is this world's most important male. Don't forget basic manners."  
"Hyai!"

Yuu recalled Satsuki saying her daughter (Arisa) was peak rebellious phase. But Haruka, as grandmother, seemed too intimidating to defy.  
Yuu somehow understood Arisa's feelings.

Satsuki, like Takako, is in her final month with due date next month.  
She's on leave but skipped today's grave visit due to health.  
Arisa, who'd long wanted to meet Yuu, came in her mother's place.

Seeing Arisa sit straight-backed answering, Haruka smiled satisfied and said to Yuu and Takako:

"Now that everyone's here, shall we go upstairs?"

---

### Author's Afterword

Toyoda Arisa is the junior high daughter mentioned in Satsuki's conversation (Chapter 361).  
I took this chance to introduce her.  
Gyaru appearance but pure-hearted girl. A delinquent who helps weak and crushes strong - good impression like a chivalrous guy.

### Chapter Translation Notes
- Translated "アバンギャルド" as "Avant-Garde" to preserve French loanword nuance
- Translated "魔性の女" as "femme fatale" for cultural equivalence
- Translated "借りてきた猫" as "borrowed cat" to retain Japanese idiom meaning temporary meekness
- Preserved Japanese honorifics (-san, -chan, -sama) and name order (Toyoda Arisa)
- Transliterated sound effects (e.g., "Pyai!" for ぴゃい, "Hyowa" for ひょわ)
- Translated "コギャル" as "kogyaru" to maintain subculture term
- Rendered sexual terms explicitly ("fucked them till they couldn't stand")