## 380. Grave Visit ③ ~THEME OF FATHER'S SON~

"Anywhere is fine, but make sure the grave has a view of the ocean."

Sakuya's will notebook reportedly contained that wish.

His final wish was granted, though the facility's scale had grown considerably larger than needed for an individual memorial. This reflected Sakuya's immense global influence.

During memorial and birthday ceremonies alone, hundreds would gather, requiring capacity for several hundred people. Spaces for dining and waiting were generously allocated, though mostly closed during regular times.

Taking the elevator from the basement to the third floor revealed a spacious hall. Led by security guards, Haruka and Takako walked ahead, followed by Yuu and Arisa. Protection officers guarded their flanks and rear.

Sakuya's photographs adorned the high walls on both sides, starting from his teens and progressing chronologically toward the back.

At the far end awaited large double doors. The gravesite lay beyond. Before them stood two tall women in black suits like gatekeepers. As the security guard approached, she exchanged words with the black-suited women.

"Oh, is that so? If it's ane-san... That's fine. Let's wait a little."

Haruka answered casually when consulted by the guard, making the black-suited woman bow apologetically. Apparently, someone Haruka knew was visiting the grave and wanted private time with the deceased.

Yuu stood slightly away from the door but gradually heard voices from inside.

"Ugh... Hic... Sa-Sakuya... I... I want to see you again... Sakuya... Just once... Come to me... Bwaaaaaaah!"

The voice called Sakuya's name between dramatic sobs. The two black-suited women pretended not to hear. Haruka and Takako nodded understandingly. Only Arisa looked startled but stayed silent reading the atmosphere.

About twenty minutes later, the door swung open forcefully.

A woman appeared wearing a black kimono embroidered with a rising dragon. Her jet-black hair was swept back in a tight updo, her narrow eyes sharp like a raptor's, radiating an intimidating aura. She resembled Haruka but with even greater presence - around 50 years old, the very image of a yakuza matriarch. Or rather, in this world where wives dominated organized crime, perhaps she was the actual yakuza boss herself?

Unbelievably, no one else emerged - meaning she must have been the one wailing inside moments ago... Her slightly swollen eyes confirmed it.

"Sorry to keep you waiting."  
"Not at all. We heard it was important private time for the wakagashira."

"Oh? Oh my! If it isn't Haru-chan!"  
"Long time no see, Shino ane-san."

The woman called Shino ane-san beamed, approaching Haruka and taking her hands. Clearly, they shared a close relationship. Her gaze turned to Yuu who tilted his head at the term "wakagashira" (young boss).

"Eh... No way, Saku... That can't be."  
"Shino ane-san, this is Hirose Yuu. My stepson."  
"Hoho. Of course I know."

"Yuu, this is Koyama Shino ane-san who looked after me when I was a clueless kid. Introduce yourself properly."

Yuu bowed deeply when introduced by Haruka. He sensed she'd weathered far more storms than he could imagine - her sheer presence commanded awe.

"Pleased to meet you. I'm Hirose Yuu. Honored to meet Haruka-san's benefactor."  
"Relax, no need for formalities. But let me see your face properly."  
"Yes."

Shino stood directly before Yuu, her hand reaching for his face. She stood about Haruka's height, slightly shorter than Yuu, now smiling gently. Yet her aura remained intimidating enough that Yuu had to steel himself. Shino touched his cheeks and patted his shoulders - not sexually, but like a mother reunited with her grown son.

"How strange. I know your face, yet earlier you looked just like young Sakuya."  
"You knew my father well?"

Yuu judged from the flow that hiding their blood relation was unnecessary. Shino grinned mischievously, glancing at Haruka.

"Of course! Haru-chan and I competed for Sakuya, sometimes sharing his love too."  
"Sh-Shino ane-san..."  
"Hoho. Anyway... Haru-chan?"  
"Yes?"  
"This boy is Sakuya's successor, isn't he?"  
"! Shino ane-san, actually—"  
"No need to say it. I felt it the moment I saw him. Yuu has the same... quality as Sakuya."

Shino peered into Yuu's face, her lips curling into a smile. Had she discerned his reincarnation at a glance? Or was it feminine intuition sensing something?

"Hohoho. Don't look so scared, I won't bite."

Shino laughed heartily and removed her hand from Yuu's shoulder.

"If you ever need help, I'll be there. Ask Haru-chan for details."  
"Yes. Thank you."

With a fluttery wave, Shino departed. Though Yuu had felt chilly earlier, his back was now damp with sweat.

After the group disappeared from view, Haruka explained. Shino was her senior at the orphanage and a notorious local gang leader. One night when she attacked Sakuya, he retaliated so fiercely she "melted" and became his lover. After junior high, she entered the yakuza world, secretly supporting Sakuya from the shadows. Now she served as wakagashira of Kounan-kai - the core organization of Kanhasshuu Shinoukai, a tekiya (street vendor)-based syndicate controlling the Kanto region.

Takako knew of her but met her for the first time today. Arisa seemed intimidated: "Haruka-san's ane-san... so intense." Though Yuu had never feared delinquents or radicals before, Shino was in a league of her own.

Despite the unexpected encounter, they refocused on the grave visit. Security would keep others out for about thirty minutes, allowing them private time.

Beyond the doors lay a serene space. A glass-domed ceiling bathed the area in soft sunlight. Stones and sand were meticulously arranged, flanked by perfectly pruned plants and ponds - evoking Kyoto's famous karesansui (dry landscape) gardens that seemed to purify the soul.

A stone-paved path led straight to a tall memorial stele. Beyond the glass windows lay Tokyo Bay with cargo ships coming and going.

"Not to sound inappropriate... but it's peaceful with a great view. I like it."  
"Really? I'm glad you think so, Yuu."

As Yuu looked around while speaking, Haruka smiled happily. The uneven stone path prompted Yuu to hold the heavily pregnant Takako's hand. Arisa followed solemnly without unnecessary chatter.

Approaching the stele serving as a gravestone, they saw "Toyoda Sakuya's Grave" carved prominently - without Buddhist posthumous names. When Yuu asked while walking, Haruka explained that during Sakuya's funeral, offers came from Shinto, Buddhist, Christian, Muslim, and other global faiths with Japanese branches. Accepting memorials from all resulted in a non-denominational format. The base featured inscriptions in Japanese, English, Russian, Chinese and more - testament to his international visitors.

Before the stele stood a flower stand with an A4-sized photo of a smiling Sakuya - likely late twenties. Fair-skinned with long brown hair and cool eyes, he'd have been irresistible to women even without the chastity reversal. Fresh flowers from morning visitors adorned the stand.

Yuu's group added their prepared bouquets one by one. The four - Yuu, Haruka, Takako, and Arisa - stood side by side in prayer.

Yuu closed his eyes, palms together, addressing his blood father whom he'd never met - a fellow reincarnate from what was likely the same original world, though through different means.

*(What karma brought me to this world a year ago? Never imagined men would be so scarce with reversed chastity norms. It's been tough but I'm living happily. Not sure if you guided me here, but thank you.  
But this world will decline without change. You knew that.  
So you sowed seeds to transform it. I intend to continue that. Don't know how much I can achieve before dying, but I'll strive for children born and unborn. Please watch over me warmly from the afterlife.)*

After praying longer than intended, Yuu opened his eyes feeling unburdened. He almost imagined Sakuya in the photo saying: "Live this life without regrets."

Grave visitors typically proceeded to the second-floor exhibit of Sakuya-related materials. But security concerns meant only replicas were displayed here - originals were at foundation HQ or annexes Yuu had seen. He saw no need to visit.

As the double doors opened, nearly ten middle-aged women in their 30s-40s waited. Sundays clearly drew more visitors. Takako had already donned sunglasses and scarf. But the women instantly spotted Yuu. Guarded by security and protection officers, they couldn't approach, merely passing by.

They returned via elevator to the basement. Back at the director's office where they'd left belongings, Haruka addressed everyone.

"Since we're here, shall we get dinner?"  
"Absolutely!"  
"Yes, yes!"

Yuu answered immediately while Arisa raised her hand energetically, making both chuckle. It wasn't yet 5 PM, and Yuu wasn't hungry, but a growing 14-year-old girl's appetite prevailed - especially with Yuu present. Though Arisa looked like a kogal, her well-behaved silence during the visit felt reward-worthy.

"Unfortunately, I'll pass this time. I have a magazine interview over dinner. Had I known Yuu was coming earlier, I wouldn't have scheduled it."

Takako had announced an entertainment hiatus during late pregnancy. But public and media interest remained high regarding her undisclosed pregnancy partner. After a 16-year gap since her first child, peers were particularly curious, leading to occasional interview requests.

"I'll see you again, Takako-san. We'll make it happen somehow."  
"Mmh, Yuu... I'm happy."

Yuu lifted Takako carefully to avoid stomach pressure. Removing her sunglasses, Takako gazed up at him with heated eyes. They kissed slowly, lost in their own world despite Haruka and Arisa's presence.

Given their high profiles, meeting was difficult. Promising to visit after the birth, Yuu saw her off.

"Yuu likes fish, right?"  
"Yes. Growing up inland made me love sushi and sashimi especially."  
"Then I'll take you to a special place."  
"Awesome!"  
"Yay! Love you, Haruka-san!"  
"Honestly, Arisa's so transparent."

Haruka smiled at the excited Arisa. Though not conventionally grandchild-aged and with adult proportions and crude speech, Haruka genuinely doted on her like a granddaughter. Yuu could feel it.

---

### Author's Afterword

This serves as the sole face-to-face moment with Sakuya - both blood father and reincarnation predecessor. I felt this scene was essential before concluding.

### Chapter Translation Notes
- Translated "姐さん" as "ane-san" preserving yakuza hierarchy terminology
- Transliterated crying sounds: "うぐっ" → "Ugh", "ひぐぅ" → "Hic", "びえぇぇぇぇぇぇぇん" → "Bwaaaaaaah"
- Translated "的屋(テキヤ)系暴力団" as "tekiya (street vendor)-based yakuza group" with cultural explanation
- Preserved Japanese architectural terms: "枯山水" → "karesansui (dry landscape)"
- Maintained original name order for Koyama Shino (小山 志乃)