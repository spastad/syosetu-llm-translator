## 381. Grave Visit ④ ~Second Love~

Haruka guided us to a restaurant located down a narrow alley branching off from the shopping street in front of Oimachi Station. She explained that Sakuya and she had frequented this familiar spot countless times since reaching adulthood.

At first glance, it appeared to be just an ordinary old private residence without any conspicuous signage. It seemed to be one of those hidden culinary gems known only to insiders.

We entered through an unassuming gate that one might easily pass by. After admiring the small but well-maintained garden, we slid open the entrance door to find an interior designed as a restaurant with counter seating and tables.

Since it was still early, there were no customers yet.

But in the kitchen, chefs in traditional cooking attire were busily working. When Haruka called out to them, they welcomed us with hearty voices.

Haruka confidently headed up the stairs, so Yuu and Arisa followed. The second floor featured a traditional Japanese-style tatami room with distinctive charm.

Kanako and the other protection officers would be dining downstairs.

  
"I know it's still early, but Arisa, what are your plans for high school?"  
"Umm... Our school has a combined middle-high program, so I thought I'd just go to the upper school like normal..."  
"But?"  
"I... kinda wanna try going to Sairei..."

  
We sat facing Haruka across a long rectangular table that could seat about ten people. It was obvious Arisa wanted to sit next to Yuu, so he smiled and gave permission.

While drinking tea before the food arrived, we chatted. When asked about her future plans, Arisa seemed hesitant. Seeing her fidget shyly while confessing this in front of Yuu himself felt adorable.

When Yuu glanced at Haruka, she said, "Why not let her do as she likes?" Given she attended a fairly prestigious private school, her academic abilities seemed sufficient.

  
"If you can persuade your mother, I think it'll be fine."  
"Mo... Mom, huh..."

  
Arisa rested her cheek on her hand with a complicated expression. Though Yuu himself didn't remember well, parent-child relationships during rebellious phases could be challenging. Still, he'd heard that children rebelling during puberty was proof they'd received ample parental love until then.

  
"It ultimately depends on you, Arisa. If you truly want to enter Sairei, study hard and convince Satsuki-neé. Apparently the competition ratio has gotten quite high this year."  
"R-really...?"  
"Also, I hear Sairei's interviews are pretty strict. Good luck."  
"Guh... I'm screwed then..."

  
Though her initial appearance as a kogal had been surprising, from what Yuu observed, Arisa had an extremely proper personality. As her uncle, Yuu would be happy if Arisa became his junior at school. But he couldn't show special favoritism just because she was family.

  
While listening to Haruka's stories about Sakuya's lifetime, the food seemed to be ready. An elderly-looking waiter with white hair but spry movements arrived. When he slid open the closet door, food ascended from below - it was a serving elevator.

Efficiently arranged on the table were sashimi, tempura, simmered dishes, grilled items, and tsukudani - all seafood-focused.  
"The ingredients come directly from Tsukiji Market. The conger eel tempura is especially exquisite," Haruka said with a smile.  
"We've been favored by customers since Lord Sakuya's time," the elderly waiter reminisced nostalgically.

  
"Whoa... looks delicious!"  
"Quite lavish."

  
Strangely, though he hadn't been hungry earlier, seeing the array of delicious dishes on the table made Yuu feel his appetite awaken. Not just Yuu - Arisa already looked ready to drool.

  
"Shall we begin?"
  
As Haruka smiled and glanced at Arisa, she was properly seated in seiza position with her hands together. She clearly didn't want to appear slovenly before Haruka.

  
""Itadakimasu!""
  
The astonishingly long conger eel tempura indeed featured crispy batter and piping hot, juicy flesh that was exquisite. All the sashimi was fresh and delicious, but especially the yellowtail and tuna with their rich marbling melted blissfully soft in the mouth. The simmered dishes and tsukudani were also deeply flavorful, perfect with rice.

  
One thing Yuu noticed about his 16-year-old body was its voracious appetite coupled with active metabolism. Unlike middle age, he could eat heartily without indigestion or weight gain. Of course, having sex almost daily meant he needed the calories to maintain stamina.

  
While eating enthusiastically, Yuu noticed something midway. Though Arisa was gobbling food at high speed saying "So good! So good!", Haruka hadn't ordered rice and was pouring herself hot sake. She mainly nibbled on tsukudani, grilled fish, and salted squid while leaving the main dishes to Yuu and Arisa.

  
"Haruka-san, you don't seem to be eating much?"  
"It's fine. As you age, your appetite diminishes."

  
Having experienced reduced tolerance for oily foods approaching 40 in his past life, Yuu understood.

  
"But please have a little more."  
"Don't say 'a little' - have as much as you want!"  
"Haruka-san! The tempura and sashimi are super delicious! I'm lucky to come today instead of Mom!"  
"If you eat too much, you'll get fat."  
"Then just burn the calories after eating?"  
"Oh? Will Yuu help me with that?"  
"Of course, gladly."

  
When Haruka gave him a shiver-inducing sidelong glance, Yuu smiled back. Neither had forgotten their intimate night at the Akita hotel this past January. To the current Yuu, the attractive widow Haruka was a viable partner. Only Arisa looked clueless about the conversation's meaning.

  
  

  
"Phew, that was incredibly delicious. Gochisousama deshita."  
"Then tell the staff later too."  
"Yes... By the way, Arisa?"  
"Nyaaah~ feels so good~"

  
Though Arisa had been eating voraciously earlier, she suddenly started swaying. Before Yuu knew it, she collapsed toward him, laying her head on his lap. Having gotten warm, she'd removed not just her jacket but even her sweater, and her short skirt was disheveled enough to reveal her panties - glossy satin in peppermint green.

When Yuu touched her cheek, it felt slightly feverish and flushed. Likely from alcohol. Two sake cups had appeared on the table at some point. It seemed unlikely Arisa helped herself, so Haruka must have poured for her when Yuu briefly excused himself to the restroom.

  
"Haruka-saaan? Arisa's still a middle schooler."  
"My my? Yuu's unexpectedly strict. Sakuya-sama was drinking since age 15."  
"I thought we should refrain until adulthood since she might still grow taller."

  
Yuu inherited Martina's traits physically, and if Sakuya could drink, alcohol might be tolerable. Still, he believed drinking should wait until adulthood - partly due to bad memories from his previous life.

  
"More importantly, Haruka-san, are you drunk?"  
"Oh my, I'm nooot. I'm just happy Yuu's keeping me company. Nfufu. Keeping Yuu all to my~self."

  
Though drunks varied, whether Martina or Haruka before him, their cheerfulness was welcome. Especially since it enhanced their allure, arousing him as a man. Yuu gently placed Arisa's head on the zabuton he'd been sitting on. When she mumbled in her sleep, he stroked her head. Worried she might get cold, he covered her with her sweater and his jacket.

Then he circled around the table and sat right beside Haruka, pressing close. Sharing the same seat made the alcohol smell unnoticeable.

  
"Yuu has peculiar tastes too. Even going for an older woman with such an age gap."  
"Can't help it when Haruka-san is so beautiful and captivating."  
"My my, you'll get me excited."  
"I'm already excited."

  
Saying this, Yuu embraced Haruka and kissed her. She immediately returned the embrace. The two held each other tightly, changing angles as they kissed repeatedly for a long time. Without either initiating, their tongues emerged and intertwined. As their tongues writhed, wet *picha picha* sounds leaked out.

Though their physical ages were a generation apart, their mental ages were close, and they were already acting like passionate lovers.

  
"Hahh"  
"Haruka-san"  
"Ahh, Yuu!"

  
The pre-reincarnation Yuu wouldn't have wanted sex with older women. But facing a truly attractive woman, age flew from his mind. The current Yuu simply wanted wild sex with Haruka - that alone filled his thoughts.

  
After ending the prolonged kiss and separating lips, strands of saliva stretched between their tongues. Haruka's cheeks flushed pink not just from intoxication as she caressed Yuu's head with a desiring look.

  
"Yuu made me remember I'm a woman. Now I only see you as a man to love. I haven't felt this way since Sakuya-sama."  
"What a coincidence. I'm lusting after the beautiful Haruka-san too."  
"Ahh, I want Yuu so badly. You'll take responsibility for making me feel this way."

  
Haruka stood and slid open the fusuma behind her. Inside, two futons were laid out. Likely Sakuya and Haruka had spent intimate time there after meals too.

  
Right after the January kidnapping incident at the Akita hotel, Yuu ended up in a threesome with Kate and Ryouko. In the heat of passion, he woke the sleeping women and took them one by one in the bedroom - Haruka first. That encounter awakened Haruka's sensuality that had lain dormant for 20 years.

Had she prepared this in anticipation of such a mood today? Either way, it suited Yuu who was equally aroused.

  
Haruka untied her obi while holding the open fusuma. She swiftly removed her black kimono and nagajuban, leaving only her white underrobe. Though seen in period dramas, seeing it up close with slight transparency was more erotic than full nudity. When Haruka released her pinned-up hair, beautiful black locks cascaded down her back.

  
At this point, words were unnecessary. Yuu stood and began undressing too. Down to just his underwear, Yuu smiled invitingly and followed Haruka into the adjacent room.

  
  

  
"Nnn! Kufuun... Yuu! Ahh! I'm feeling it. I can't believe it feels this good."  
"So erotic... so wonderful... Haruka-san."

  
On the futon, Yuu pinned Haruka down, engrossed in caressing her. Her underrobe ties were undone, revealing nearly all her white skin. Yuu's love bites bloomed like flowers across Haruka's neck and collarbone. His right hand treated her modest breasts like precious objects, kneading them. Continuous nipple stimulation from his fingertips had made them perkily erect.

Her lustrous long hair spread across the pillow, tangling and undulating whenever Haruka tossed her head in pleasure. Each time Yuu took in her alluring appearance, her sensual aura aroused him, making him exchange deep kisses repeatedly.

  
While rolling a nipple in his mouth with his tongue, Yuu's right hand slid from her breasts down her flat stomach, tracing the pubic hair. Haruka naturally spread her legs to accept Yuu's hand. When his fingertips touched her vulva, a *kuchu* sound emerged.

This wasn't just slight wetness from arousal. Her love juices clung thickly to his lightly placed fingertips - completely drenched.

  
"Haruka-san, you're already this wet."  
"Hau... Yuu, yours is hard and hot... touching me."

  
Yuu's underwear had long been removed, and his erect cock pressed against Haruka's thigh. When Yuu spread her labia *kupaa* with his index and ring fingers, his middle finger touched her vaginal opening and was *nyupu* swallowed in. Simultaneously, Haruka's supple fingers touched his cock.

  
"Nna... uunn! Amu... nn, nn... faaahh!"

  
After mashing their lips together, their tongues immediately intertwined while they caressed each other's genitals. Each time Yuu's middle finger thrust in and out of her vagina, love juices flowed thickly.

While moaning, Haruka defiantly used her fingertips to toy with his glans, lightly gripping and stroking his shaft. Unstoppable precum made sticky *nechi nechi* sounds.

  
"Ah, ah, ah... ai... good! Haa, haa, hey... Yuu?"

  
Haruka looked up at Yuu with feverish eyes. After so many deep kisses, her wet mouth clearly showed what she wanted.

  
"I want it now. Quickly... I want your hard one... to thrust deep into my pussy."  
"But I haven't made Haruka-san cum yet."

  
Though he had no intention of playing games now, he teased her slightly. Then Haruka clung to Yuu, wrapping her legs around him before suddenly rotating them.

Now on the other futon, Haruka straddled Yuu, already mounting him.

  
"Nfufu. You get impatient when you age. I can't wait anymore."  
"Ha, Haruka-san?"

  
Looking down at Yuu with a smile like a female beast capturing prey, Haruka moved her hips trying to insert him. Her long black hair fell over Yuu's face, darkening his vision. Then it covered his lips too. Though Yuu had been leading earlier, the tables had turned completely. But that was fine too.

  
"Nnnn!"  
"Uu... nmuu!"

  
Yuu and Haruka connected not just with their upper mouths but simultaneously with their lower mouths too.

  

---

### Author's Afterword

After reading the previous chapter, you probably thought the final chapter was near.

Not yet! It's not over yet! (Nocturne-style)

After a delicious meal, we also partake of a beautiful widow.

### Chapter Translation Notes
- Translated "隠れ家的な料理屋" as "hidden culinary gems" to convey exclusivity while maintaining the "hidden restaurant" concept
- Preserved Japanese culinary terms: "天ぷら" → "tempura", "煮付け" → "simmered dishes", "佃煮" → "tsukudani"
- Translated explicit sexual sounds literally: "ぴちゃぴちゃ" → "*picha picha*", "ぶちゅ" → "*pressed together*", "にゅぷ" → "*nyupu*"
- Maintained Japanese honorifics: "-san" for Haruka, "-neé" for Satsuki
- Translated anatomical terms directly: "おマンコ" → "pussy", "チンポ" → "cock"
- Rendered sexual acts without euphemisms: "思いきり突いて" → "thrust deep", "セックス" → "sex"
- Preserved cultural references: "正座" → "seiza position", "熱燗" → "hot sake"
- Transliterated sound effects: "むにゃむにゃ" → "mumbled", "くふぅん" → "*Kufuun*"