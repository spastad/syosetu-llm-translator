## 382. Grave Visit ⑤ ~BE TOGETHER~

"Nngh, hah, hah, haaaaaaah... Feels good... Yuu. My body... it's trembling with pleasure... Ah! Ah! Aaah! Yu-Yuu... are you feeling good too?"  
"Y-yeah, Haruka-san. Feels... amazing."  
"Good... that's good... *mwah*, *smack*..."

Haruka rode atop Yuu, swaying her hips.  
At first, her movements were slow, as if testing the sensation of the penis she hadn't taken in so long. But soon she grew accustomed, her motions smoothing until sticky, wet sounds of "guchu guchu" came from their joined area.  
Haruka leaned over, cradling Yuu's head as she passionately kissed from his cheeks to his neck - payback for earlier. Simultaneously, her hips maintained a rhythmic motion.  
Though her vagina lacked the tightness of a teenager's, it felt molten hot from arousal. With each hip movement, it clenched "gyu-gyu" tight around Yuu's penis, delivering intense pleasure.

Objectively, Yuu appeared to be the one being assaulted.  
He'd intended to take the lead but found himself controlled instead.  
Yet Yuu accepted and enjoyed this situation.  
Now skin-to-skin in their natural states, Yuu's hands roamed from Haruka's slender back to her plump buttocks.

"Nkgh! D-don't... I'm gonna... cum already..."  
"Cum as much as you want, Haruka-san."  
"Aahn! You're really... incredible... aaahn!"

Matching Haruka's movements, Yuu thrust upward.  
The sudden impact deep in her vaginal canal made Haruka throw her head back with a high-pitched moan. She clung desperately to Yuu, panting near his ear.

"Ah! Ah! Good... so good... kuhhhh... can't stop!"  
"Ngh!"

Haruka's hips accelerated as if shifting gears.  
"Bachun! Bachun!" The sound of buttocks slapping repeated.  
Yuu felt his penis being squeezed, involuntary groans escaping. But he resolved to hold back until Haruka climaxed.

"Hah! Hah! Hauuuh! A-aaah! Ngh! Cu-cumming... ngh... mmmmmmmn!"

Haruka's voice cut off as she reached orgasm while tightly embracing Yuu.

"Haah... haah... Women are... such creatures. Once ignited... we can't stop."

Haruka breathed raggedly with a self-mocking smile. Yuu smoothed her disheveled black hair back as he spoke.

"I'm the same. You excite me tremendously, Haruka-san. Last time we got interrupted, but tonight I'll see it through to the end."  
"Ah... kyah!"

Still connected, Yuu embraced Haruka and sat up. Though not lengthy, he switched positions considering she'd been moving continuously. Now in a face-to-face seated position, Yuu prepared to take initiative.

"Ah! Ah! Ah... yes... this position... I love it. Aah... feeling Yuu's body heat while... being penetrated deep inside... *mwah*"

Post-orgasm but still impaled deep by the hard penis within Yuu's embrace, Haruka wore an ecstatic expression. Yuu brushed aside the black hair obscuring her face and kissed her upturned lips. As their tongues entwined, he began slow thrusts.

"*Schlorp*... *rero*, *reroo*... Nngh! Nnngh! Nmo... hyau! Shu... go... oh! Oh! Deeep... hya, w-wait... nooo... cumming... Yuu! Yuu!"

"Tan! Tan! Tan!" The sounds of buttock impacts overlapped Haruka's moans. Her arms wrapped around Yuu's back, clinging hard enough to leave nail marks.

As the family leader and foundation director, Haruka had lived prioritizing work over romance. But Yuu had ignited her sensual fire, now blazing fiercely within. Impaled deep by the thick penis, she could only drown in pleasure with each thrust.

Even after Haruka's second climax, Yuu continued thrusting. As he debated finishing in this position or switching to missionary, Arisa entered his field of vision from the adjacent room. She sat on a cushion, staring intently at their intercourse - hand over mouth, eyes wide.

"Ah!"

When Yuu made eye contact, Arisa scrambled under the low table like a child who'd witnessed parental sex after a midnight bathroom trip. Yuu whispered to the still-panting Haruka.

"Arisa saw us."  
"Haah... haah... She woke up? Can't be helped."

Haruka seemed unbothered - unsurprising given their vigorous activity. For women in this world, sex with loved ones was precious and sacred, nothing shameful but rather prideful. Thus Yuu embraced it openly.

"Arisa, come here."  
"Hweh?"

Arisa peeked out from under the table - effectively hiding only her head - with a disbelieving expression. When Yuu nodded, she crawled over on all fours with surprising speed.

"Wah! Wah... real actual sex! First time seeing it! Um... Haruka-san, does it really feel that good?"  
"Yes... ah... so good I can't think at all! Oh! Sho... stop it! Haaan! Too sensitive! Yu-Yuu's... mean!"

Yuu paused when Arisa spoke but thrust mid-Haruka's reply. Haruka seemed vulnerable to deep penetration where the tip tapped her cervix. Unable to speak, she frantically clung to Yuu, hair disheveled, nearing climax again.

Seeing the usually stern Haruka transformed into a lustful woman seemed unbelievable to Arisa. She sat fidgeting at the futon's edge, cheeks flushed from Yuu's nudity and the sexual atmosphere. Her arousal was obvious - natural for a sex-curious middle schooler. Perhaps she'd been masturbating or planning to; half her blouse buttons were undone without the ribbon, fully revealing her mint-green bra matching her panties. Though only 14, her body was adult-like, with noticeable breasts resembling her mother Satsuki's. Yuu resolved to take Arisa too, but first focused on Haruka as his own limit approached.

"Haruka-san, I'm about to cum too."  
"Kufuu... hya, w-wait... ngh! No! I just came... haun!"

True to her favorite position, face-to-face seating worked powerfully on Haruka. She reached climax faster than during cowgirl earlier. Matching Yuu's rhythm, she slammed her hips down - perhaps unconsciously - making his endurance fail.

"Ngh... ooh... cumming! Cumming, Haruka-san!"  
"Good... good... me too... cu-cumming... Yuu! T-together... aah! Amazing! Ooh... aaahhhhhhh!"  
"Guh! Ejaculating!"

Embracing tightly with full penetration, Yuu came. His spasming penis pulsed "byuku byuku" as semen shot powerfully into Haruka's womb. Receiving the creampie at her peak, Haruka stared blankly upward. Her moans ceased, mouth agape for seconds before going limp.

Yuu caught her as she nearly collapsed backward.

"Faaaaaah... Yu-Yuu-kun?"  
"What is it, Arisa?"

After laying the half-conscious Haruka on a futon, Yuu sat facing Arisa. His erection remained fully hard. Seeing this, Arisa breathed raggedly, rubbing her thighs together like a virgin middle schooler who'd witnessed her admired aunt post-coitus - inevitably aroused.

Yuu stroked Arisa's meshed brown hair, fingers trailing from hair tips to ears to cheeks. His touch seemed to cast a lewd spell, drawing "hafuun" sighs with each caress.

Meanwhile, Yuu unbuttoned her blouse completely but didn't remove it, leaving her upper body exposed. Her half-cup bra contained impressive volume, creating cleavage. Her slender shoulders, arms, and flat stomach suggested she wasn't athletic.

Yuu pulled her close with his left arm around her back. His erect penis brushed her stomach, making her jolt as she stared intently at the flesh rod below.

Cupping Arisa's well-shaped chin, Yuu turned her face toward him. Her youthful skin glowed - plenty attractive without makeup at her age. Leaning close, he whispered.

"Arisa, shall we kiss?"  
"Feh!? Uuuu, me!? Really!?"

Yuu smiled wryly at her shrill voice - the mood was right, but Arisa seemed genuinely inexperienced.

"Arisa, you're cute."  
"Eh... mmph!?"

Before she answered, Yuu covered her mouth. He embraced her, savoring her soft lips in a deep kiss. Though initially wide-eyed, Arisa soon understood, closing her eyes and clinging tightly.

Her gyaru appearance and adult-level figure contrasted with her innocent 14-year-old self. Seeing her half-naked and aroused, Yuu couldn't help but desire her. Invading her mouth with his tongue, he pressed against hers. Arisa gasped and twitched but actively reciprocated.

"Haam... nngh! Hyum... churu... rero, rero, eroo... nhaa... juru"

Initially passive, Arisa soon actively tangled tongues and rubbed against him. Yuu's excitement soared. Reaching behind her, he unhooked her bra clasp, then groped her firm, perky buttocks like unripe fruit.

When their lips parted, a string of saliva connected them. Arisa looked utterly melted, heart symbols practically in her eyes.

"Haa! Haa! Haa! Dangerous! Never knew kissing... felt this good! I seriously... can't stop wanting sex!"  
"Ooh!?"

Arisa energetically pushed Yuu down, now looking down at him in fully aroused female mode. Unfazed, Yuu pulled aside her displaced bra and cupped her firm breasts from below - smaller than her mother Satsuki's but filling his palms.

"Arisa, I intend to too. Let's have sex."  
"Aaaaaah... Yu-Yuu-kun! Love you!"

Arisa desperately clung to Yuu. She forcibly kissed him while groping his face and chest wildly. For Arisa, this development on the day she met her idol Yuu felt unreal. Yet she seized this rare chance, kissing obsessively and savoring his skin.

After letting Arisa have her way briefly, Yuu grew bored of passivity. Rolling sideways face-to-face, he sucked her breasts while his right hand reached between her legs - her panty crotch already soaked.

"Hyan! Eh! Eh! Stop... unyun! Ahi! Wai..."  
"My my. Our little Arisa's grown so splendidly. Your breasts might be bigger than mine. Looks like you'll produce lots of milk."

Haruka had appeared behind Arisa, kneading the breast Yuu wasn't sucking.

"Arisa's a virgin, right? Leave the foreplay to me."  
"Indeed. The first time hurts, you know?"  
"Ah! Ah! Wait... aah! No! Two at once... yaan!"

Pinned supine with panties removed, Arisa received dual attention. Yuu licked from ears to neck while kneading her mountain-like breasts. Haruka targeted precisely - sucking nipples while fingers crept toward her vulva. A veteran from group play with Sakuya, Haruka knew every female pleasure point.

"Hyae! Ah! Ah! Ah! Ann! This... feels too good... didn't know! Can't stand! Cumming already!"

Under Yuu and Haruka's expert touch, Arisa's moans flowed nonstop. When Yuu's fingers obsessively teased her clitoris, "pushu pushu" squirts erupted. Unable to endure the pleasure, Arisa convulsed violently.

"Good girl. Cum now."  
"Hyai... cumming! Cumming! Feels too good, won't stop... aaah! Ah! Ah! Amazing! Cummmmmmmmmmmming!"

Triggered by Yuu's whisper, Arisa arched her back sharply as she climaxed.  


### Chapter Translation Notes
- Translated sexual terminology explicitly (e.g., "チンポ" as "penis", "膣" as "vagina", "射精" as "ejaculating")
- Preserved Japanese honorifics (-san) and name order (Toyoda Haruka)
- Transliterated sound effects (e.g., "guchu guchu", "bachun", "byuku byuku")
- Formatted internal monologues in italics (e.g., *mwah*, *smack*)
- Maintained original dialogue structure with new paragraphs for each speaker
- Translated anatomical terms directly ("clitoris", "vulva", "creampie")
- Rendered sexual acts without euphemisms ("impaled", "thrusting", "semen shot")
- Used contextual translation for culturally specific terms ("gyaru" retained with explanation in narrative)