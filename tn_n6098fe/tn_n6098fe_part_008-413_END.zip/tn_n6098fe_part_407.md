## 384. Before the Wedding ① ~ALIVE~

"I'm sorry for intruding during such a busy time."

"Not at all. We're indebted to you in many ways, Toyoda-sama."

"Oh, please drop the formalities? We're practically like step-family, aren't we?"

"Um... then, may I call you Haruka-san?"

"Yes. It would be awkward to call me 'mother-in-law' ahead of Martina-san, so that's fine. Sayaka-san."

One day, not long before the wedding, Toyoda Haruka visited Komatsu Sayaka, who was spending time at her parents' home while caring for her child.

Since it was a weekday, Sayaka's father Hikaru, grandfather Yoshioki, and great-aunt Ritsuka were home. After politely greeting them, Haruka requested to speak with Sayaka alone.

Sayaka and Haruka had met once before. During Yuu's kidnapping incident this past January, they were introduced at a hotel in Akita City after his rescue. Sayaka had met Satsuki, the foundation representative supporting Yuu, several times and thought her a beautiful woman with both charm and warmth. She was shocked to learn Haruka was Satsuki's mother.

After learning Yuu's biological father was the legendary Toyoda Sakuya, Sayaka had researched materials and knew Haruka's name and face as his first wife. Even after Sakuya's death, she united the family and established the foundation to protect and advance his legacy. While the foundation received support from the ruling party and major corporations partly due to Sakuya's lingering influence, much credit went to Haruka's leadership.

Sayaka recognized her as a leader comparable to her own grandmother Reika, but when they met naked in the hotel's large bath, she was struck by how Haruka remained beautiful with steely strength despite her age - someone she aspired to emulate. Facing such a figure now naturally heightened Sayaka's tension.

Haruka wore her usual black kimono with flashy gold and silver embroidery, looking impeccable. *If Yuu were here, he'd probably think she looks straight out of a yakuza wife movie.* To Sayaka, her great-aunt Ritsuka - if about 20 years younger - might have carried a similar aura.

Since Sayaka was at her parents' home, she was dressed casually but freshened up after asking Haruka to wait. She wore a white blouse under a black jacket with a matching black long flared skirt - an outfit elegant enough to serve as formal wear. Combined with her long, loose black hair, she radiated the aura of a refined young lady.

Noticing Sayaka's stiff nervousness, Haruka smiled. This wasn't her business-negotiation smile but the soft expression she reserved for loved ones - first Sakuya, now Yuu and Martina - which sufficiently eased Sayaka's tension.

"By the way, have you finished preparing your ceremony attire?"

As the atmosphere relaxed, Haruka began with an easy topic rather than getting straight to the point. Sayaka smiled back.

"We discussed it among the three of us and decided on dresses."  
"I see. Dresses would suit you well and add more splendor."  
"*giggle* True. I did dream of a shiromuku, but once I tried on the dress, I couldn't contain my excitement."

For weddings, the bride's attire is the highlight, making the choice crucial. When the three met, Emi immediately chose a dress. Riko leaned toward dresses despite being neutral initially, thinking they'd flatter her tall frame. Sayaka was genuinely torn - having seen photos of her grandmother and mother in shiromuku, she'd yearned for one since childhood. But since the venue was a school gymnasium rather than a shrine, she worried it might seem out of place. Thus, they settled on classic wedding dresses and completed fittings.

Though they'd discussed invitations and ceremony proceedings over the phone, the excitement over attire proved Sayaka was still a girl at heart. Their conversation about the wedding continued enthusiastically.

"Now then, shall we get to the main topic?"

After thoroughly enjoying topics ranging from the wedding to babies and Sayaka's upcoming April university enrollment, Haruka lightly broached the subject, prompting Sayaka to straighten her posture.

"Today I've come not as a foundation director but as Sakuya's wife to meet you, Sayaka-san, who will become Yuu's wife. Of course, I've obtained permission from his mother Martina-san."  
"Y-yes."  
"Don't be so stiff. Truthfully, I feel kinship because you'll be in a similar position to mine. To Yuu, you're not just one wife among many, correct?"  
"Ah... that is..."

Haruka must have already heard from Yuu about how he and Sayaka met. Sayaka vaguely sensed Haruka's meaning but looked down shyly. She soon lifted her face to meet Haruka's eyes.

"Can I... become someone like you, Haruka-san?"  
"I came because I believe you can."

Haruka smiled tenderly at Sayaka, whose expression held a hint of anxiety. As Yuu's first wife, Haruka represented a predecessor in the same role - meaning Sayaka would need to manage Yuu's growing number of wives and lovers. Without stating it explicitly, this understanding passed between them.

"Truthfully, I've heard about you from Reika-sama."  
"Eh... f-from Grandmother... what did she say?"  
"*giggle* Don't worry. Reika-sama praised you as an accomplished granddaughter. She insisted no one but Sayaka could support Yuu closest as his woman."

Sayaka's cheeks flushed. Grandparents doting on grandchildren is common. Her grandfather Yoshioki had spoiled her as the first grandchild. Grandmother Reika grew stricter as Sayaka matured - expectations for the Komatsu heir, she now understood. Though rarely shown openly, her grandfather mentioned how Reika would nod proudly, saying "As expected of Sayaka, my pride and joy," whenever she excelled academically or in club activities. When her high school engagement soured, Reika fretted visibly, then rejoiced like it was her own happiness when Sayaka became engaged to Yuu. Despite knowing she was loved, hearing it from others was still embarrassing.

"Do you know about the world before the Red Death Disease epidemic when men were plentiful?"

Seeing Sayaka blush, Haruka smiled and abruptly changed topics. As an honors student strong in humanities, especially history, Sayaka knew but simply nodded.

"Back then, marriage typically involved one man and one woman. Depending on status, men sometimes took multiple wives to preserve family lines."  
"In Japan until the Edo period, feudal lords had principal wives and concubines."  
"Do you know the original meaning of the proverb 'heroes favor women'?"

Sayaka tilted her head, trying to recall.

"I believe... in pre-modern times, it meant men hailed as heroes were vigorous in all matters, including being fond of women."  
"Now it's used when wealthy women who built fortunes want multiple men, but originally heroes were male."

Both women immediately thought of men who could be called heroes.

"In modern Japan, men taking three or more wives is customary - almost an obligation they accept. But some men actively seek relationships. Among them, Sakuya was exceptional, but Yuu seems poised to surpass him."  
"Yes. At school, Yuu-kun was incredibly popular, and he tried to respond as much as possible. Many more children will surely be born."

Jealousy no longer existed in Sayaka - only concern that Yuu might overexert himself.

"Historical Japan had the Ooku. Chinese dynasties had imperial harems. Islam had harems too. Though circumstances differ, Yuu is essentially creating something similar. It's fine now with only close women, but as numbers grow, problems may arise. Women might even fight, potentially harming Yuu."

Sayaka realized - the factional strife among Sakuya's wives that led to his death. Haruka meant: *Don't repeat our mistakes.*

"Like the principal wife's role as overseer in the Ooku system, correct?"

Haruka nodded as if to say *exactly.*

"Currently, the foundation knows of Yuu's children - only by his self-reporting. Judging by Sakuya's case, there might be more. Or rather, they'll likely become too numerous to track. Because it's Yuu."  
"Because it's Yuu-kun. *giggle*"

They laughed together brightly.

When married, the first wife typically manages the husband's schedule, determines bedroom rotations, and sometimes intervenes in relationships outside marriage. This happens especially with early male marriages where wives are older or marriages are arranged. Haruka kept track of Sakuya's relationships through communication but generally gave him freedom. Sayaka intended the same - knowing extraordinary men like Sakuya or Yuu couldn't be restrained. But she wouldn't neglect problems either - prevention was key. Unknown women becoming obsessed and taking extreme actions must be avoided.

"Regardless, let's share information about Yuu going forward."  
"Yes. Understood."  
"Living peacefully without issues would be best, but..."  
"Yes. Indeed. Now that we have children, I don't want Yuu-kun taking reckless risks like before."

Yuu had been kidnapped twice this past year, in summer and winter. Both incidents ended well, but receiving the news each time felt life-shortening. Thus, those protecting Yuu - like Haruka and Sayaka - united to eliminate dangers.

Haruka then shared anecdotes from Sakuya's lifetime, and they pledged future cooperation for Yuu's sake. Though the foundation and Komatsu Group previously had little connection, the Komatsu family would now deepen ties.

"My apologies for the late greeting. I'm Sayaka's mother, Tomoka."  
"Not at all. I'm the one who should apologize for dropping in unexpectedly. I'm Toyoda Haruka."  
"Toyoda-sama, we've caused you trouble with our daughter's wedding preparations among other matters."  
"Not at all. Today I had a thorough talk with Sayaka-san. I think she's a perfect match for Yuu - a credit to your family's upbringing."  
"Oh no, Sayaka was quite a tomboy. I worried she'd never find a good husband."  
"But she met Yuu. Truly a blessed match. *ohohoho*"  
"Absolutely. *ohohoho*"

Over an hour had passed since Sayaka and Haruka began talking. Informed of Haruka's visit, Tomoka left work early to rush home - Grandmother Reika couldn't skip an important meeting.

Though Haruka had greeted Tomoka by phone regarding the foundation hosting the wedding, this was their first face-to-face meeting. As their mother-to-mother conversation threatened to continue indefinitely, Sayaka's father Hikaru cleared his throat. In his arms was Hajime, swaddled in a blanket.

"My! How adorable!"

As Sayaka took her child from Hikaru, Haruka hurried over, peered at the baby's face, and exclaimed in admiration.

At birth, his face was red like a monkey's, but after over a month, it had filled out adorably. Though not yet holding his head up, his vision seemed to be developing. When awake, he sometimes looked around and kicked his limbs. While not speaking clearly, he'd begun moving his mouth to goo.

"Hajime might be developing quickly."

Sayaka said, smiling at Hajime squirming in her arms.

"Um... might I hold him?"  
"Of course. He doesn't fear strangers."

Haruka carefully took Hajime from Sayaka. Babies vary, but Hajime never fussed when held by trusted non-family members. Rather, he looked up with round eyes, seeming content. Haruka beamed involuntarily - babies are unconditionally lovable, especially Hajime, born to Yuu and Sayaka, whom Haruka loved like her own son.

"Sayaka-san."  
"Yes."  
"Someday... well, when Hajime grows up, I hope the world becomes safe enough for men to go out alone."  
"I truly hope so too."

No one knew how much would change in 10 or 20 years. Sakuya had literally risked his life to change society. Now Yuu would inherit that path - easily predicted as long and arduous. Both Sayaka and Haruka intended to support him however possible.

---

### Author's Afterword

Originally, the first half was to be Sayaka and Haruka's conversation, and Yuu was to appear in the latter half, but it took more words than expected, so it will be carried over to the next chapter.

### Chapter Translation Notes
- Translated "御台所" as "principal wife" to convey the historical role of chief wife/overseer in polygamous systems
- Translated "お転婆" as "tomboy" to preserve the nuance of an energetic, unconventional girl
- Preserved Japanese honorifics (-san, -sama) and name order (Toyoda Haruka)
- Translated "義理の親子" as "step-family" to convey the quasi-parental relationship
- Rendered "おほほほ" as "*ohohoho*" to transliterate the characteristic laugh of mature women
- Translated "相好を崩した" idiomatically as "beamed involuntarily" to convey spontaneous delight