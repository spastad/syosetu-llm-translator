## 385. Before the Wedding ② ~For the Sake of Being Loved by You~

### Author's Preface

I managed to update despite having a slight fever from my third COVID vaccination today.

There's an announcement in the afterword.

---

On the same day that Haruka visited the Komatsu household and spoke with Sayaka.

At Sairei Academy, the closing ceremony was held to mark the end of the first year.

After school ended in about three hours, the student council gathered.

That said, Ishikawa Emi from the second year had been frequently absent for childcare except during exam periods. Aramaki Yoshie (1st year) was hospitalized due to her impending childbirth.

Those who could gather that day were the accountant Ogawa Mizuki (2nd year), vice president Kawai Kiriko (2nd year), vice president Hanmura Sawa (1st year), and Tsutsui Nana—four people.

They were having an early lunch in the student council office.

"Mizuki and Kiriko, your bellies are really showing now. How are you feeling?"

"Perfect, Yuu-kun."

"Me too. Since entering the stable period, my appetite has increased."

First, Yuu stroked Kiriko and Mizuki's bellies with his left and right hands.

Both were thought to have gotten pregnant in October when they joined the student council, and are now six months along. The swelling of their bellies had become noticeable.

Not only Kiriko, who was originally athletic and relatively well-built, but even the petite Mizuki now had a hearty appetite.

Presumably, they needed to take in plenty of nutrition for the growth of the fetuses inside them.

Meanwhile, Sawa and Nana were at four months. It was hardly noticeable from over their uniforms.

"Brother, touch me," Nana said with a straight face, lifting not only her sailor uniform but also the hem of her innerwear, so Yuu stroked her bare skin as she wished.

Observing closely while touching, he could feel that her belly was slightly swollen.

Although Nana had the most childlike physique in the student council, she was surely nurturing life within her womb.

She had also expressed pride in carrying Yuu's child.

Nana's hobby was styling her long black hair in various ways—tying it up, braiding it, using ribbons and hairpins—almost daily. Today, she had an elaborate hairstyle with a half-up bun.

But since the beginning of this year, there were days when she simply let it down without doing anything or tied it up simply.

On those days, her complexion was usually poor, likely due to morning sickness leaving her with no energy.

Neither Sawa nor Nana complained of feeling unwell in front of Yuu. Perhaps it was the strength of women who had been granted their longed-for child.

Both had said they had only recently settled down.

"Nana, you're doing great too."

"Nfu..."

As Yuu stroked her belly and then her head, Nana narrowed her eyes happily.

"Hey. Me too."  
"Sure, sure."

Following Nana, Sawa also pressed close.

Sawa didn't usually cling to him on her own, but it was amusing how she would compete when she saw Yoshie and Nana of the same grade being affectionate with Yuu.

In the end, Yuu had Sawa and Nana kneel with their hems lifted, touching their bellies and pressing his ear against them.

After finishing lunch with the usual conversation and physical contact, they sat in a circle again.

From Yuu's left: Nana, Kiriko, Mizuki, Sawa.

Today, Yuu had called the meeting because he wanted to gather before spring break started.

Yuu had something he wanted to discuss while checking on the four pregnant members.

"Next Monday is the wedding with Sayaka, Riko, and Emi, and I plan to submit the marriage registration immediately."

As Yuu spoke while looking around, all four nodded.

It would be the first school-wide wedding in history. All students enrolled until March were invited without exception, and the four student council members—excluding Emi, the bride, and Yoshie, who was hospitalized—were scheduled to help with the proceedings, so they naturally knew.

"At this age, I've decided on three wives, so I've fulfilled the minimum obligation as a man..."

Yuu paused there.

"Kiriko."  
"Yes."  
"Mizuki."  
"Hmm?"  
"Sawa."  
"Wh-what is it?"  
"Let's get engaged."  
""""Eh... eeeeeeeeeeeeeeh!?"""

The moment Yuu declared this to the three whose names he called, they let out a collective shriek.

"R-really? Me? With Yuu-kun?"  
"E-engaged!?"  
"C-could I become the same as Riko-nee...?"

Leaving the three frozen in surprise, Yuu continued.

"Of course, the same goes for Yoshie, who's hospitalized. And, Nana."  
"Yes. Brother."  
"Nana and I are siblings, so we can't get married."  
"Yes. But I—"  
"I know you love me as a man, Nana. I also cherish you dearly."  
"!"

Tears immediately overflowed from Nana's eyes, which usually showed little emotion.

Yuu stroked Nana's head as she sat to his left.

"It won't happen immediately, but let's live together in the future. Of course, with the child to be born too."  
"I'm happy."

Nana rested her head on Yuu's shoulder while still crying.

When the pregnancies were discovered, Yuu decided to get engaged to Sayaka and the others partly due to his previous life's common sense of taking responsibility, but also because the three were special.

Now, Yuu's children numbered nearly twenty, but he didn't intend to marry all of them except for his half-sisters and Martina.

In this world, it wasn't taboo for a man to have multiple wives while having physical relationships with other women and fathering children—in fact, it was encouraged. Acknowledgment was required, but no further responsibility was borne—though depending on the partner, they might request a wife or mistress contract. Of course, there was no risk of being sued for child support.

It was a world extremely convenient for men.

Since it was normal for men to have relationships with multiple women, the difference between marriage and other relationships had become ambiguous.

The main differences were that marriage meant registering as family. Living together and supporting and providing for the husband were about it.

For women, gaining the status of wife was socially and psychologically significant.

That's why wealthy families were passionate about securing a son-in-law and producing an heir.

Yuu was already happy enough to have acquired three wives at sixteen, but since he was reborn in this world, he had the desire to spend his time surrounded by beautiful women.

However, romance and marriage were separate matters.

His father, Sakuya, had twenty wives but couldn't suppress factional conflicts based on their regions of origin, which ultimately contributed to his death.

Moreover, Yuu had experienced divorce when he couldn't hold onto the heart of the wife he had truly loved.

After all, when unrelated people live together, compatibility is important. For example, differences in place of origin led to differences in clothing, food, and housing—and if countries differed, even religion and family values—requiring adjustment.

In that regard, for Yuu, who was student council president at Sairei Academy, the student council officers were the closest to him at school, with similar regions of origin and ages, and their appearances and personalities were impeccable.

He judged them as suitable partners to spend his life with.

However, he had no intention of moving out of his current apartment during high school. As he had spent half the week at Sayaka's apartment since the latter half of last year, he would likely continue visiting his wives.

Yuu had thought about moving after graduating high school and getting a job at the Toyoda Sakuya Memorial Foundation.

He hadn't decided whether to move to Tokyo or stay within Saitama Prefecture, but he thought it would be nice to rent a spacious residence where even a dozen people could live.

If Nana lived there, her mother, Takako, would have a legitimate reason to visit with the child.

Now, not only Nana but Mizuki had jumped into Yuu's arms. Moreover, Kiriko came around and hugged him from behind.

Sawa also pressed close to Yuu nonchalantly, so he stroked her long black hair.

"Um, I know it's late, but can I ask a question?"  
"What is it?"  
"I've been wondering for a while—are Yuu-kun and Nana-chan really siblings?"  
"I was wondering too. Yuu-kun, I heard you had an older sister, but..."  
"You're in the same grade, right? Aren't you cousins?"

At the questions from Kiriko, Mizuki, and Sawa, Yuu and Nana exchanged glances.

"I guess I hadn't mentioned it. Might as well tell you now."  
"Okay. I'll leave it to you, Brother."

Who Yuu's father was—only his fiancées Sayaka, Riko, and Emi knew at school.

Since transferring, Nana hadn't disclosed who her parents were, knowing it would cause trouble.

So Yuu revealed that he and Nana were half-siblings.

He also disclosed who their father was.

The three, entrusted with the secret, were dumbfounded as if pigeons had been shot with peashooters, then let out simultaneous cries of surprise, so Yuu hurriedly covered their mouths.

"No wonder... that explains it."  
"Somehow, it makes sense."  
"Yeah..."

When the three had recovered from the shock and seemed convinced, Yuu said in a calm tone:

"After the new term starts and things settle down a bit—around Golden Week, I think. Let's have a meeting with your parents too. At that time, I'll formally propose engagement."

Taking it as Yuu being serious and not joking since he mentioned calling their parents, Mizuki and the others couldn't hide their joy.

"By this time next year, we'll have the wedding with Mizuki, Kiriko, Sawa, and Yoshie."  
"Wow..."  
"Um, Yuu-kun?"  
"What is it, Kiriko?"  
"Th-th-this unworthy one... p-please take care of me."  
"Yes. Thank you for having me. I'll be in your care too, Kiriko."

Yuu turned around, brought his face close to Kiriko's, and kissed her.

Kiriko, who had been in the hard tennis club, left due to an injury in May of her second year. She was recommended as an executive committee member for the quiz championship and happened to have contact with Yuu.

That led to her joining the student council and even getting pregnant. Among second-year girls, she was considered a Cinderella girl for her luck, but she was a humble person by nature. She never tried to stand out and was a behind-the-scenes supporter.

That was also why Yuu liked Kiriko.

"Me! I, who made a mistake in the past and was foolish... I will dedicate my life to you, Yuu-kun, for accepting me!"  
"Mizuki..."

After kissing Kiriko, Yuu turned forward to find Mizuki approaching with teary eyes.

Her large breasts and belly pressed against him simultaneously.

The previous year, before Yuu enrolled, Mizuki had been appointed as student council accountant and, having fallen too hard for the then second-year male vice president, forcibly took him home and confined him.

Naturally, it ended in failure, and she received a suspension.

After the suspension period, when she was becoming truant, Yuu and Emi scouted her as accountant for the new student council.

Despite her suspension, Mizuki maintained top grades and was excellent as an accountant.

But due to her past, she had almost no friends. For Mizuki, Yuu and Emi were like benefactors.

Supporting Yuu as a wife alongside Emi was Mizuki's true wish.

Mizuki kissed Yuu while crying, immediately inserting her tongue.

Yuu also stroked her head while entwining his tongue.

"Nfu... chupa, nero, lero... mufuu, Yuu-fuun shuki, daishuki"  
"Brother! Now me."  
"A-ah, me too!"  
"Nn... okay, one at a time."

True to his word, Yuu began kissing the four while they clung to him from all sides.

Yuu's hands also took turns stroking heads and gently fondling breasts.

The girls actively kissed Yuu's nape, cheeks, and neck even when not kissing him.

While deep-kissing Sawa after Nana, even Kiriko couldn't wait and stuck out her tongue.

With multiple girls constantly overlapping lips and tongues, the sound of kissing never ceased.

"Amchu, chu, lero, juru... nfuun"  
"Ah, Mizuki, you're cute. Kiriko and Sawa are cute too. Of course, Nana is cute. I love you all."  
"Aahn! Yuu-kun, Yuu-kun!"  
"Brother, more!"

First Mizuki and Nana. Even Kiriko and Sawa now breathed hot breaths like aroused females, rubbing their bodies against Yuu.

In that state, even Yuu couldn't hold back. His hardened crotch pressed against Mizuki's lower abdomen as she sat on his lap.

Feeling it, Mizuki panted roughly like a dog, drooling as she rubbed her cheek against Yuu.

"Hey hey, Yuu-kun"  
"Nn?"

Yuu was simultaneously kissing Nana and Kiriko on the left with chupa chupa sounds, but he responded to Mizuki's call.

"Your cock is hard. Ufufu."  
"Ah, nice."  
"Me too, I want to touch!"

Kiriko and Nana's hands reached for Yuu's crotch.

Meanwhile, Sawa turned Yuu's face toward her. Sawa, her cheeks dyed pink, looked intoxicated as she devoured him.

Once aroused, Sawa's switch flipped, making her aggressive and turning her into a kissing fiend.

"Hey, Yuu-kun?"  
"What is it, Sawa?"  
"I... want to do more sexy things."  
"Oh? It's rare for Sawa to beg."

Sawa's face flushed crimson, but her eyes were clouded with lust.

"U... w-well, I'm a woman too. I have sexual desires..."  
"That's true. Well, shall we do it like this?"

When Yuu agreed, Kiriko, Mizuki, and Nana, who had heard the exchange, nodded simultaneously.

Since Yuu became student council president, he had been extremely busy. The student council officers had truly worked hard. What used to be two meetings a week became three, and before events, they sometimes met daily.

Even when student council work was busy, everyone was motivated because they could see Yuu.

To soothe them, Yuu regularly initiated physical contact and took one day off each week—Friday or Saturday—to spend in sexual bliss.

Since spring break started tomorrow, this was the last gathering of the month. That's why they were being proactive.

When Yuu put his hand on his shirt button, he was stopped.

The four wanted to undress him. Seeing their enthusiasm, Yuu smiled wryly and left it to them.

Once things had gone this far, he knew well that stopping the momentum was impossible.

---

### Author's Afterword

【 Announcement 】

"Reborn in a Chastity Reversal World" has been decided for a manga adaptation ‼

It will be serialized in COMIC VAMP. The author is Aikawa Tatsuki-sama.

Aikawa-sensei's works feature erotically cute girls, so expectations are high!

This is just the initial announcement stage, so I'll share more details like the serialization start date as they come.

I'm making timely announcements on Twitter, so please check it out if you like.

Wow... to have a professional artist draw it...

Like Yuu reborn, I'm overjoyed in this dream-like situation.

  

2022/4/16

Added dialogue around the middle where Yuu and Nana reveal they are half-siblings and who their father is.

By the way, Nana hasn't revealed that her mother is the famous actress Tsutsui Takako. She only calls Yuu "Brother" in front of him.

### Chapter Translation Notes
- Preserved Japanese honorifics (e.g., "祐君" as "Yuu-kun", "兄さん" as "Brother").
- Translated explicit sexual terms directly (e.g., "おチンポ" as "cock", "エッチなこと" as "sexy things").
- Transliterated sound effects (e.g., "んふ" as "nfu", "ちゅぱ" as "chupa", "じゅる" as "juru").
- Maintained Japanese name order (Last Name First Name) for all Japanese characters.
- Translated "異母兄妹" as "half-siblings".
- Used explicit terminology for sexual acts as per style guide.
- Italicized internal monologues (none in this chapter).
- New dialogue lines start on new paragraphs, except when preceded by attribution.
- Preserved simultaneous dialogue formatting with `""...""`.
- Explained culturally specific terms in notes (none required beyond translation notes).