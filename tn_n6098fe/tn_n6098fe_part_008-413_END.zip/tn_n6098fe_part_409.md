## 386. Before the Wedding ③ ~Overflowing Feelings~

By late March, spring had arrived and daytime temperatures were warm, but it was still too cold to go around naked.  

However, in the student council room, the heat emitted by the four women surrounding Yuu made the room warm enough to cause sweating.  

On the futon, Yuu lay on his back in a spread-eagle position while Mizuki, Kiriko, Sawa, and Nana crowded around him.  

First, Yuu had his clothes removed, then they took off their uniforms and underwear. Just by being naked and pressing their skin together, their excitement grew.  

"Nn, nnn~~~ chupaa... nnaa! Ufuu... Yuu-kun's penis, it's wonderful."  

"Lero lero hamu hamu... Yuu-kun's penis, as always, is splendid and sturdy... ann!"  

"Ah... Mizuki and Kiriko are both so good at it, it feels great. By the way, Nana and Sawa, your breasts have gotten bigger too."  

"Ah, ah, Nii...san... there, I'm sensitive there... funyun"  

"Chu, chu, churu... nnn! Afuu"  

Mizuki straddled Yuu's right leg, and Kiriko straddled his left leg, both diligently sucking his penis. Their two tongues licked thoroughly from the tip to the testicles, making it glisten with saliva.  

Mizuki and Kiriko each had one hand on his penis, while the other hand—Mizuki's right hand and Kiriko's left hand—were groping the breasts next to them and playing with the nipples.  

In other words, while they appeared to be cooperating in the fellatio, they were also trying to take the lead by stimulating each other.  

With the student council members continuing to gather naked around Yuu, they had grown accustomed to interactions between women.  

Nana and Sawa occupied Yuu's upper body, taking turns kissing him and running their tongues over his chest.  

Yuu's hands reached for both their breasts. Though originally a flat-chested pair, Yuu confirmed they had swelled slightly from pregnancy.  

The moment he began playing with their nipples using his fingertips, they hardened into stiff peaks. They moaned with cute voices without breaking their kisses with Yuu.  

While being pleasured by Yuu, Sawa enthusiastically sucked on his nipple.  

Nana, who had been passionately entwining her tongue with his, jerked her chin up when two fingers pinched her nipple but buried her face in Yuu's neck while trembling and sucking.  

Like beetles and stag beetles swarming around tree sap, they continued to devour Yuu.  

The one who couldn't hold back amid the four-way stimulation was Yuu himself.  

Mizuki and Kiriko noticed this first.  

"Yuu-kun, transparent fluid won't stop dripping from the tip. Are you going to ejaculate like this?"  

"Haa, haa, I... want the penis..."  

Yuu, who had been kissing Nana and Sawa alternately, lifted his face slightly.  

"I... would prefer penetration if possible. Is that okay?"  

"As long as we're not too rough."  

"It's fine since we're in the stable period."  

Early pregnancy was one thing, but now that their bellies had grown larger, even Yuu had to be cautious. Though he was fine with oral sex, the women remained proactive except during severe morning sickness or the final month of pregnancy.  

As student council members, they held the closest position to Yuu at Sairei Academy. If they couldn't have sex here, they didn't know when their next chance would come. Yuu accepted their wishes and decided to penetrate all of them, starting with the two second-years.  

"Mizuki-senpai, just licking it makes so much lewd fluid come out."  

"Kiriko-senpai, here? Or does this spot feel better? Say it properly with words!"  

"Hyaun! D-don't... st-stop... th-there... oh, oh, aaaaaah!"  

"Ahh... kuh... d-don't tease me... my clitoris, my clitoris feels so goooood!"  

Mizuki and Kiriko were on all fours using blankets and pillows as cushions to avoid straining their bodies.  

Nana and Sawa had their faces close to their buttocks, licking and fingering their clitorises and vaginas—Nana attending to Mizuki, Sawa to Kiriko.  

Yuu knelt between Nana and Sawa, stroking their small buttocks.  

Before meeting Yuu, Nana and Sawa had been virgins with no sexual experience. But after joining the student council, they gained experience through group play centered around Yuu and learned sexual techniques.  

Nana had excellent observational skills, and Sawa enjoyed pleasuring other women like her cousin Riko. They attacked their seniors without mercy, bringing Mizuki and Kiriko to the brink of orgasm.  

"Hiii! No more... st-stop... Nana-hyan... ah, ah, aaaaah! I'm cummiiiiing!"  

"Ufufu... Mizuki-senpai came, so cute."  

"Impressive, Nana."  

"Nn... ufuun"  

When Yuu's left hand reached Nana's privates, they were soaking wet. While attacking Mizuki, she had gotten aroused too.  

Sawa seemed engrossed in teasing and pleasuring Kiriko without any intention of competing from the start.  

"Then I'll start with Mizuki."  

"Haa, haa, Yuu-kuun... hurry... come..."  

Mizuki shook her perfectly round, peach-like buttocks to entice Yuu.  

As Yuu approached from behind, Nana touched his erect penis with her fingers, smearing Mizuki's love juices as lubricant.  

Nana guided the tip to Mizuki's vaginal entrance while keeping her hand on the shaft, inserting it into the opening.  

"Haan! I-It's in... ah, haaun"  

"Mizuki, I'll move slowly."  

"Y-yes... oh, oh, it's so hard... amazing as alwaaays..."  

Mizuki's vagina, having just orgasmed, swallowed Yuu easily. But immediately after insertion, the folds tightly gripped and constricted him.  

The sensation felt so good that Yuu remained still for a while after fully sheathing himself inside.  

Once his penis settled in her vagina, Yuu gradually began moving his hips. However, with a fetus inside Mizuki's belly, he couldn't thrust deeply like before.  

He pulled out at a frustratingly slow pace, stopping just before the glans came out, then pushed back in while savoring the tightness of her vagina. He lightly tapped against her cervix. Even that felt sufficiently pleasurable.  

"Senpai, here, lick."  

"Un? Chumu, eroo"  

Nana snuggled up beside Mizuki's left side and brought her wet fingertips—coated in a mix of love juices and pre-cum—to her mouth.  

Without hesitation, Mizuki stuck out her tongue and licked it clean while moaning, making wet sounds.  

Since Sawa was engrossed in pleasuring Kiriko, Yuu inserted his left fingers into Nana's vagina while thrusting.  

With Yuu being the only man, penetration was limited to one person at a time. Even with fingers and mouths, there were limits. So the girls pleasured each other too—making sure no one was left out and everyone felt good had become the student council's custom.  

"Hya... ahn, aaan! The penis feels so goood! I'm cumming, I'm cummiiing... aah! Kuh!"  

Yuu leaned forward without putting weight on Mizuki, rhythmically moving his hips.  

His left hand fingered Nana's vagina while his right held Mizuki's waist, performing light, brisk thrusts. Still, Mizuki approached climax.  

The short-statured pair of Nana and Mizuki kissed repeatedly like lovers in love, but Mizuki finally reached her limit.  

After watching Mizuki collapse with a long moan, Yuu pulled out his penis and shifted right.  

"Hah, hah, hah... I want to cum. I want to cuuuum..."  

"Kiriko-senpai, I've been edging her right before climax."  

"Haha, thanks Sawa. Kiriko, I'm going in."  

"Hyai! The penis! I want to cum with Yuu-kun's penis!"  

Kiriko spread her vulva open with her hands and begged for Yuu's penis. Love juices gushed from her vaginal opening like a geyser.  

When Yuu pressed his hips against her, Sawa—now kneeling—grasped the wet penis, smeared it with juices, and guided it to Kiriko's vaginal entrance.  

Then Sawa clung to Yuu for a passionate kiss.  

When Yuu's right hand moved from Sawa's buttocks to her pussy, it was also soaking wet.  

He hadn't ejaculated inside Mizuki yet, but Yuu himself was highly aroused.  

While deeply kissing Sawa, he pushed into Kiriko.  

"Hyaunn! Oh, oh... amazing... aah... feeeeeee! Ick... aaaaah!"  

The moment Yuu's penis reached her deepest point, Kiriko arched back sharply and climaxed.  

Being teased intensely by Sawa then receiving the longed-for penis seemed to be the finishing blow.  

"Chu, chu, chururi, afuu... I want it too... soon..."  

"Sawa, you're unusually proactive today."  

"B-because... ahn! We haven't done it lately."  

Even after making Kiriko cum, Yuu kept his penis inside and slowly moved his hips.  

While kissing Sawa who had her arms wrapped around him, he fingered her vagina.  

Since forming the current student council, they had managed to gather like this for group sex once or twice a week despite busy schedules until December. But after New Year's, the frequency decreased.  

Between Yuu's own busy circumstances and their pregnancies causing morning sickness, opportunities became scarce.  

They occasionally had sex individually, but it might have been a while since they gathered with four or more. That's why each was being so proactive.  

As Yuu thought this, someone hugged him from the opposite side of Sawa. He knew it was Nana without looking.  

"Big Brother. My turn now."  

"Eh? It's my turn!"  

""Muuuuuu!"  

"Wait. I'm about to cum soon."  

Yuu was telling them not to fight seriously, so neither was truly arguing. But their desire to unite with Yuu quickly was genuine.  

Sensing this, Yuu increased his thrusting speed.  

Yuu ejaculated simultaneously with Kiriko's climax about 2-3 minutes later.  

"Now, please take care of me."  

"I won't lose to Sawa."  

"Me neither."  

Sawa and Nana crouched on all fours near Yuu's crotch as he sat cross-legged, waiting with their faces close.  

They would now give him a double fellatio while masturbating.  

Yuu decided he would penetrate whoever came first.  

Kiriko, lying behind them, would judge.  

Mizuki hugged Yuu from behind, pressing her large breasts against his back.  

"Now, start!"  

"Anmu"  

"Muchu"  

At Yuu's signal, both immediately reached for their own crotches. Simultaneously, they opened their mouths slightly and gave passionate kisses to the erect penis from both sides. They soon brought out their tongues and sucked eagerly.  

Squelching sounds already came from both their pussies.  

Since both Nana and Sawa had been aroused while pleasuring Mizuki and Kiriko and were fingered by Yuu earlier, they were already soaking wet. They probably wouldn't take long to climax.  

"Nn, nn, un fu... churu, lero, lero, nnn! Ahaa... anmu"  

"Hah, hah, hamu... nmo, up... nn, nn... hafuu"  

"Ooh... you're both so good... feels amazing."  

Double fellatio by two beautiful girls the same age. While masturbating simultaneously, both had ecstatic expressions as they sucked the penis obsessively.  

Together, they licked up the shaft to the coronal ridge with their tongues, then took the glans into their mouths simultaneously.  

If he hadn't ejaculated earlier, Yuu might have come first. Now was a test of endurance until one of them climaxed.  

Yuu turned back to distract himself.  

"Mizuki, let me suck your breasts."  

"Sure~. Here here, suck all you want♪"  

"Wapuu"  

Mizuki circled around to the right and pressed her breasts against Yuu's face. Their softness pressed against his cheek.  

Originally, Mizuki had prominent breasts—F-cups on her petite frame. Pregnancy seemed to have made them fuller.  

Feeling bliss from the voluminous breasts, Yuu hugged Mizuki's waist and opened his mouth wide to suck her entire nipple. He used his tongue to suckle with chupa chupa sounds.  

"Aah! Yuu-kun, you really love breasts, huh... ufufu, such a perverted baby. Hyaun! Feels so good, so happy..."  

Nana and Sawa kept their moans subdued while masturbating and performing fellatio. Mizuki's cries of joy as her breasts were sucked were louder.  

Then the revived Kiriko joined in.  

"Nfuaaa! K-Kiriko-senpaaai!?"  

"W-wait! If you play with me now... st-stop!"  

"Nfufu. Payback for teasing me earlier."  

While Nana and Sawa had been fingering their own clitorises, Kiriko approached their buttocks and inserted fingers into both their vaginal openings.  

Nana and Sawa unintentionally pulled their mouths off the penis and writhed their lower bodies.  

But they immediately went back to sucking.  

They seemed to be competing not only to climax first but also to see who could pleasure Yuu more with their fellatio.  

"Nfuuuu... ahe, ifuu... ah, ah, amu"  

"Chup... nn, nnn! Nnn—!"  

"Oh, ofu..."  

"Ahn! Breasts, breasts feel so gooood!"  

Their moans overlapped and echoed through the room.  

Amid this, Sawa—discarding her usual cool demeanor—rubbed her cheek against the glans while trembling and came.  

About ten seconds later, Nana also climaxed while pressing her face into Yuu's crotch.  

---

### Author's Afterword

I think eroticism increases when girls get proactive with each other in one-man-multiple-women scenarios!

### Chapter Translation Notes
- Translated explicit anatomical terms directly (e.g., チンポ → "penis", おマンコ → "pussy", 睾丸 → "testicles")
- Preserved Japanese honorifics (-senpai, -hyan) and name order (e.g., Ogawa Mizuki)
- Transliterated sound effects (e.g., ちゅぱぁ → "chupaa", はむはむ → "hamu hamu")
- Rendered sexual acts without euphemisms (e.g., フェラ → "fellatio", 挿入 → "penetration")
- Maintained original dialogue structure with new paragraphs for each speaker
- Translated 夏那ひゃん as "Nana-hyan" to preserve unique honorific variation