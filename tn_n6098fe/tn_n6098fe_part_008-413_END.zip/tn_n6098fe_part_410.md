## 387. Before the Wedding ④ ~for you…~

### Author's Preface

Added dialogue around the middle of Chapter 385 where Yuu reveals to current student council members that he and Nana are half-siblings and discloses their father's identity. Though quite belated.

Note: Nana hasn't disclosed that her mother is famous actress Tsutsui Takako. She only calls Yuu "nii-san" (big brother) in his presence.

---

With only a slight time difference, Sawa came first, so Yuu, sitting up, pulled Sawa close.

"What position should we do? I'll do whatever you like, Sawa."  
"Umm..."

Sex with pregnant women requires more caution than usual. Avoiding abdominal pressure should be the top priority.

Among Sairei Academy girls, student council members have frequent encounters, and Yuu has tried various positions. But today, the missionary position with Yuu on top wasn't an option.

Since starting sex with Yuu, they've come to prefer face-to-face cowgirl position. However, it might be best to avoid that now as it strongly stimulates the uterus.

If choosing, it would be doggy style or sideways, or perhaps...

"W-wait, I'll ride on top, so lie down quickly! Come on, hurry!"  
"O-okay"

Sawa seemed eager to insert immediately in cowgirl position.

Gently pushed by Sawa's breasts, Yuu lay on his back again. This time, however, Mizuki was sitting with her butt down, providing a lap pillow with her aligned thighs. Half of Yuu's view was blocked by breasts.

Sawa was already straddling his hips. For the usually cool Sawa, this was an unusually lustful expression of a female in heat.

"*Haa... haa...* Yuu-kun's... cock... *ahn*... hard and hot... *kufuu*... good. This. This. I'm going to put this cock... inside my pussy now... *unn*... ah, ah, ah, it's going in... *haaan!*"

Feeling the cock at her sensitive spot, Sawa got so excited she kept repeating "cock" while leaning forward.

Shifting her hips, she inserted it herself.

Having swallowed the longed-for cock, Sawa made a melting face, collapsing onto him while squeezing his cheeks with both hands and showering him with kisses.

"*Nchu, chu, chu, chupaa... haa, haa...* love, love you... Yuu-kun, your cock... *ahn!* Inside me... Yuu-kun's haaard cock... *anmu, lero, lero, julu*"  
"*Guuuu...* S-Sawa's inside... so tight... ahh, feels good"

While inserting the cock deep inside, Sawa began rocking her hips in small movements while entwining tongues with Yuu.

Despite having sex many times since becoming student council members together, her pussy remained as tight as when she was a virgin.

Perhaps aroused by how Yuu was feeling, Sawa kept changing the angle of her face while passionately pressing her lips against his. Each time, her long black hair swayed, falling over Yuu's face, neck, and shoulders.

Yuu played with Sawa's hair with one hand while kneading Mizuki's ample breasts above him with the other.

"Let us join too"  
"Me too!"

"Sure. Nana, Kiriko"  
"*Yaan!*"

"Come on, come on. Sawa-chan, let's make you feel really good?"

Kiriko positioned herself behind Sawa, extending both hands to her breasts and the joining area.

Nana took Yuu's mouth instead of Sawa who had lifted her chin, inserting her tongue.

No matter who Yuu was penetrating, the student council members always entangled themselves to feel good together.

"*Kyan!* N-no, Kiriko... senpai..."  
"Come on, come on, since you're connected with Yuu-kun. Focus on moving, okay?"  
"*Hiiin!* Ah, *ahn!* I... I can't... already... I'm... I'm cumming!"

Being simultaneously stimulated on her nipples and clitoris by Kiriko behind her, Sawa couldn't concentrate on hip movements. Though she paused occasionally, climax was approaching.

Yuu couldn't bear to see Sawa in disarray.

Nana, who had regretfully yielded her turn to Sawa, instead gave a greedy, intense deep kiss. After making Yuu swallow saliva while wildly entwining tongues, she seemed to feel better and started sucking his nipples.

"Nii-san, does it feel good?"  
"*Nn... nmu*"

This time Mizuki hunched her back, dropping her voluptuous breasts onto Yuu's face, blocking his mouth. Instead of replying, Yuu stroked Nana's head while sucking on the breasts covering his vision.

Yuu was busy pleasuring multiple girls simultaneously.

"*Aaaaaaah!* No fair! I'm cumming... cumming! *Faa... heeeeeee...*"

Though not as intense as before pregnancy, Sawa desperately rocking her hips reached climax while Kiriko played with her nipples and clitoris.

Nana, watching this, grinned broadly.

"I came, so next is me"  
"Eh? W-wait"

Though Sawa was dissatisfied since less than 10 minutes had passed since insertion, Kiriko and Nana forcibly separated her.

"I've only ejaculated once, so I can still go on"  
"O-okay"

When Yuu sat up and said that while stroking Sawa's cheek and kissing her, she seemed to cheer up a bit.

Though partly due to her infatuation weakness, Sawa had become much more pliant since they first met.

Nana slipped between Yuu and Sawa, leaning her back against Yuu.

"Nii-san, I want that position we did before"  
"Before?"  
"I want you to hold me from behind"  
"Ah, that one. But I won't go rough today"  
"Un"

It was the rear-entry position he occasionally used with petite partners.

Like face-to-face cowgirl, it was popular among girls for the secure feeling of being enveloped by Yuu.

Like holding a little girl from behind to help her pee, Yuu lifted Nana's widely spread legs with both hands.

Nana gripped Yuu's hand with one hand while grabbing his shoulder from behind with the other.

"About here... see, Nana? Can you see the cock going in?"  
"U, un. Nii-san's big cock, hitting my pussy... ah, ah... *nkuu!* Going... in! Nii-san... nii-san... more... I want it deep enough to reach the baby's room!"

"Ah... *kuu...* N-Nana!"

Since Yuu was looking over Nana's shoulder, he couldn't see clearly, but when he placed his cock against her crotch like straddling, he felt the wet, warm female genitals.

Realizing Yuu's cock was touching her, Nana immediately rocked her hips to adjust position. Her small vaginal opening parted, swallowing the cock deeply.

Instantly, tingling pleasure ran down Yuu's spine - he almost ejaculated on the spot.

While penetrating Sawa, Yuu had managed to hold on, but Nana's equally tight constriction brought intense pleasure. He felt he wouldn't last long.

"Ah, ah, ah... nii-san, I love you..."  
"Me too"

When Nana turned just her face and looked up at Yuu with upturned eyes, her voice trembling, affection swelled in Yuu.

Holding Nana from behind with his cock deep inside her vagina, Yuu didn't move yet. No - if he moved, he might cum. Plus, strong stimulation to the fetus-containing uterus probably wasn't good.

To prolong the pleasure, Yuu remained still while exchanging passionate kisses with Nana. Releasing the hands holding her legs, he embraced Nana's body while enveloping her modest breasts.

"*Aahn!* So jealous! So jealous! Put it in me too!"

Mizuki pressed her breasts against his back while clinging from behind.

Meanwhile, Kiriko and Sawa had taken the opportunity to move away from Yuu, with Kiriko pinning Sawa down as they immersed themselves in their own lovey-dovey world.

Yuu decided not to disturb them for a while.

"Mizuki, come in front. Let's sandwich Nana between us"  
"*Unn!*"

Mizuki, who expected to be next after Nana, eagerly came before Yuu, sandwiching Nana between them.

When Nana, who had stopped kissing, rubbed her face against Yuu's neck, Mizuki approached from the front and pressed her lips against Nana's while sandwiched.

"You know, I'll say it as many times as needed. I can never thank you enough for saving me when I was shut away, Yuu-kun"  
"Exaggeration, Mizuki. At that time, Emi had asked me too"  
"Un. I'll forever be indebted to Emi, that's certain. But that's exactly why I'm happy to marry Yuu-kun together with Emi"  
"Mizuki"  
"Yuu-kuun... *chu*"  
"*Muu-*"

Though Mizuki and Nana were similar in height, when Mizuki lifted her hips to kiss, Nana's face got buried in the huge breasts.

"*Moo...* M-Mizuki sen... *nnaah, aahn!*"

Yuu hadn't forgotten about Nana at all.

Though not noticeably swollen, since she was pregnant, Yuu avoided her belly and hugged her breasts while slightly moving his hips.

"*Churu... lero, leroo... nnaa, Yuu-kuun... love you, anmu, julu, npa... afuun*"  
"*Nne...* ah, ah, *iin!* Nii-san... *n... haan!* Your cock, nii-san's cock grinding inside... feels so good..."

While exchanging wet, noisy deep kisses with Mizuki, Yuu played with Nana's small nipple with his right hand while moving his hips in small motions. Not thrusting upward, but making small circular "no" motions.

Nana, nearly buried in voluptuous breasts, lifted her chin and moaned. Saliva from Yuu and Mizuki dripped down into her mouth.

"*Kyan!* Ah, th-there, not now... *aaaaaah!* I... I'm... cumming! Cumming!"  
"Ooh... tightening! *Ku...* can't hold back anymore. I'm gonna cum like this!"

Yuu had been repeating deep kisses with Mizuki while making small hip movements, but gradually felt semen rising.

Though he'd had sex with Nana many times, her high-quality tight pussy was almost unchanged since the first time, not letting him last long.

The delicate folds inside seemed to wriggle, trying to squeeze out semen, bringing Yuu intense pleasure.

Mizuki, after thoroughly entwining tongues, seemed to change targets to Nana, sealing her moaning lips while reaching for the joining area. Apparently intending to stimulate her clitoris.

With Yuu's hand still playing with her nipple, Nana was attacked in three places simultaneously and couldn't withstand climax.

Yuu too was about to cum.

"Nana, let's cum together"  
"Love... nii-san, together... cumming... *haau!* No fair, cumming cumming!"

Yuu, who had been grinding his hips, changed to thrusting motions at this point. Though not pounding hard - just light knocking.

Nana, nearing climax, tightly gripped the hand Yuu was embracing her with.

Mizuki, who had been kissing Nana while playing with her clitoris, suddenly lowered her posture to all fours. Apparently planning to observe their joining area closely.

"*Gu...* ooh! Nana!"  
"Nii-san!"

Calling each other's names, Yuu and Nana climaxed simultaneously.

Feeling hot semen released inside her during climax, Nana seemed to lose consciousness, staring blankly into space.

Mizuki, who had brought her face close to their joining area at the moment they came, got splashed with fluids, but happily kissed the base of the cock.

Yuu and Nana were immersed in the afterglow of ejaculation, but Mizuki clung to him, demanding the next turn. Yuu smiled wryly and declared a break.

Yuu himself still had stamina, but a break was necessary. No matter how young and superior in energy and stamina, with four partners taking turns wanting him, there'd be no time to rest.

While Yuu rested, the four prepared tea snacks, so they brought out a low table to chat.

Their bodies cooled down as they relaxed, but no one put on clothes.

Including Yuu, they were all eager to continue.

Instead, they huddled together around Yuu, covered with sheets.

"April's coming soon, huh"  
"Another year passed already"  
"Feels like just yesterday I became student council president, but with all the busyness... the year flew by"  
"Me too"  
"Yeah"

Everyone nodded at Yuu's words.

He remembered hearing that time passes slowly when young, but quickly when older.

But looking back, it felt fast for everyone.

After all, too much happened this year. Not just Yuu - apparently all student council members felt it.

Except Emi and Yoshie, the other four met Yuu relatively late.

They had some hopes of meeting a wonderful boy upon entering school, but never imagined losing their virginity and getting pregnant.

"With the new school year, Mizuki and Kiriko will be third-years, and we'll be second-years"  
"And new students will enter"  
"Speaking of new students... most girls are aiming for Yuu-kun, right?"  
"That's true"  
"Seems there are more than usual"

The entrance exam for Sairei Academy High School, with its skyrocketing competition rate, was covered in detail not only by major newspapers but also Weekly Fuji and Saito News, so everyone knew.

Among the four, Kiriko, former tennis club member, knew many juniors and was well-informed.

Several juniors she was close with in middle school took the exam but all failed. This year's exam was that competitive.

"By the way, I heard Sayaka's sister Kiyoka, and Sumiko from Saiho Middle School passed"  
"President Komatsu's sister!?"  
"Right. So those two will really be our juniors"

In mid-February, Yuu and Nana went to Sayaka's apartment to help pack for the three fiancées returning home. Kiyoka and former Saiho Middle School student council president Shiranui Sumiko joined them. Since Sumiko was a virgin, it developed into a foursome.

Kiyoka and Sumiko, boasting top-tier academic ability in the prefecture plus good looks, were expected to pass, and Yuu received their passing notices earlier this month.

Nana, who had experienced competitive sex with Kiyoka as if in a sister rivalry, seemed deeply moved. Yuu thought they might become rivals - friends written as "competitors".

"Anyway, I'll keep changing Sairei while I'm student council president. I need your cooperation from April onward too"

Yuu's ideal was a coeducational school like in his previous world, where boys and girls learn in the same classrooms, exercise in the same grounds, and commute together.

He knew immediate realization was difficult due to gender ratios and safety.

Still, he wanted to make the school atmosphere closer to that.

"Since Yuu-kun invited me into student council, I'll cooperate with all my strength!"  
"I'll do anything for Yuu-kun... leave accounting to me!"  
"I'll do my best as vice president too"  
"I'll be used as nii-san wishes"

Kiriko, Mizuki, Sawa, and Nana all expressed agreement, making Yuu smile.

He believed Emi and Yoshie, though absent, would respond the same.

Yuu stretched both arms to embrace Kiriko and Sawa on either side.

Nana sat at Yuu's knees while Mizuki clung to his back like a piggyback monster.

"Then, let's continue... whoa, that's hasty"  
"I can't wait"  
"Unfair! Me too"  
"Nii-san, *chu-*"

Seeing Mizuki reach for his crotch from behind, Kiriko competitively touched his cock too.

The cock that had been feeling four soft skins swelled up, wrapped in their hands.

Nana looked up at Yuu and brought her lips close, but Sawa pressed her lips against his from the side.

Then as the five played around, it escalated, and the girls' moans grew louder.

---

### Author's Afterword

Thus concludes the friendly erotic chapter centered around Yuu and the student council.

Originally, Emi and Yoshie (currently hospitalized for childbirth) would join too, so Yuu is busy.

This is the last erotic chapter. The wedding ceremony begins next chapter.  


### Chapter Translation Notes
- Translated explicit anatomical terms directly: おチンポ → "cock", おマンコ → "pussy", 膣内 → "inside"
- Preserved Japanese honorifics: -kun, -san, -senpai, nii-san
- Transliterated sound effects: ちゅっ → *chu*, あんっ → *ahn*, ぐっ → *gu*
- Maintained original name order: Hanmura Sawa, Tsutsui Nana, etc.
- Rendered sexual acts without euphemisms: "ejaculated", "penetrated", "clitoris stimulation"
- Italicized internal monologues: *(Guhhh...)*, *(Haa... haa...)*
- Translated dialogue quotes with standard double quotes, maintaining paragraph breaks for each speaker
- Used explicit terminology for sexual content per fixed style guidelines