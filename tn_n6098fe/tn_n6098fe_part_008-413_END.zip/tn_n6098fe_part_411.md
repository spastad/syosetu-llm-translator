## 388. Wedding Ceremony ① ~Miracle Wedding March~

### Author's Preface

This two-part finale features Yuu and his partners' wedding ceremony.  
There's an announcement in the afterword.

---

Monday, March 25. An auspicious day. The wedding ceremony for Yuu and Sayaka, Riko, and Emi was held at Sairei Academy High School's gymnasium.

Though they'd completed their costume fittings recently, the three brides requiring extensive preparation time arrived at the venue early in the morning.  
Yuu left home at his usual school arrival time.

In his previous life, Yuu had held his wedding and reception when he was nearly thirty.  
He'd basically left everything to his wife and the wedding planner, passively following instructions. Above all, the spotlight belonged to the bride. While he'd savored the joy of marrying a woman he truly loved, his strongest memory was of the overwhelming stress.  
After his marriage collapsed within three years, it became a bitter memory.

Never in his wildest dreams did he imagine being reborn and marrying at just sixteen after barely a year. Moreover, marrying three beautiful girls simultaneously - something anyone in his previous world would envy - was only possible in this male-scarce world.  
Furthermore, in this world's wedding customs, the groom Yuu was considered the main attraction. He couldn't help feeling nervous.

"Ah, it's Hirose-kun!"  
""""Yuu-kun!""""  
"We're looking forward to today!"

Girls in athletic uniforms spotted Yuu as his car pulled up to the administration building entrance and waved enthusiastically.  
Contractors commissioned by the Toyoda Sakuya Memorial Foundation had been setting up the venue since yesterday, but third-year physical education students had also arrived early to help with decorations.  
The girls who spotted Yuu were from second and third-year PE courses. Though tense and quiet moments before, Yuu returned their greetings with an awkward smile upon seeing familiar faces.  
Escorted inside by protection officers, he was greeted by the entire office staff.

"Congratulations on this day"  
""""""Congratulations!""""""

"Th-thank you"

"We'll escort you to the waiting room immediately"  
"Nfufu. Yuu-kun, you seem nervous!"  
"Does it show that much?"

Greeted by Watanabe Kazuyo, Gonda Sakiko and other office staff, Yuu smiled shyly. As a frequent visitor to the office, all staff treated him like an idol. They intended to support his special day professionally while watching over him.

The wedding received full school support.  
The first floor of the administration building served as the waiting area.  
All faculty and students enrolled through March were invited, with nearly everyone attending except the few who'd already departed overseas or to rural areas.  
Students weren't expected to give monetary gifts. Faculty pooled resources for a collective gift.

The three brides seemed busy preparing in the spacious staff room, their handlers' flustered voices audible from the hallway.  
Yuu fought the temptation to peek inside, knowing it must be chaotic. He avoided causing displeasure before the ceremony even started.  
Seeing their radiant appearances for the first time during the ceremony would maximize the emotional impact.

Guided by Kazuyo and Sakiko, Yuu arrived at the reception room serving as the groom's waiting area.  
Inside waited two stylists assigned to him.  
The room's layout had been altered, with a full-length mirror installed at the rear. Beside it hung the white tuxedo Yuu would wear.

"We've been expecting you. We'll be handling your styling today, Hirose-sama"  
"Yes. Thank you for your assistance"

Two fashionable women in suits bowed in unison, and Yuu returned the gesture.  
Likely because they specialized in male clients, both women appeared to be in their thirties or older with calm demeanors.

"Please, this way"  
"Ufufu. Since Hirose-sama is today's star, we'll give it our all"  
"Haha... please go easy on me"

Numerous tools were arranged on the desk.  
They intended not just hairstyling but full makeup application.  
*This preparation will take time...* Yuu mentally prepared himself.

---

The ceremony was scheduled for 11:00 AM, with students gathering in large numbers after 10:00.  
Students weren't in formal wear - all girls wore uniforms while boys wore mostly suits despite having freedom of choice.  
Faculty wore suits or school-event appropriate attire.

The gymnasium interior had been completely transformed by professionals, astonishing entering students.  
Walls were covered with white-based wallpaper and curtains creating a pure impression.  
High on the back wall hung a large plaque reading: "Wedding Ceremony: Hirose, Komatsu, Hanmura, and Ishikawa Families".  
The stage featured a pure white sheet-covered platform with extravagant multicolored floral arrangements.  
Flowers adorned not just the platform but also the area before the stage.

Flowers were donated not just by faculty and the Toyoda Sakuya Memorial Foundation, but also by the Ayakuni Group, Saito City Mayor, Saito City General Hospital, Komatsu family dojo disciples, Sayaka and Riko's local shopping district, security company MALSOK through protection officer connections, and even conservative local politicians - demonstrating Yuu and Sayaka's extensive network.

Hearing about today's wedding, media outlets requested photography permits and even live broadcast rights.  
The academy wasn't entirely opposed, but Yuu flatly refused: "We're not celebrities".  
For Yuu, being celebrated by the school community was more than enough.  
Thus, only two specially permitted outlets - Weekly Fuji and Saito News - occupied second-floor seats with cameras. Special editions featuring Yuu's wedding would surely sell well.

Like during the school festival, a pathway extended from center stage, resembling a fashion show runway.  
As a non-religious civil ceremony, vows would be exchanged before all students and faculty.

Foundation staff handled planning and operations, but MC duties fell to current student council members Kiriko, Mizuki, Sawa, and Nana, currently testing microphones.  
Yoshie had just given birth and was excused from attending.

"Ah~ I'm getting nervous somehow"  
"It's Yuu-kun and the others' big day. Only natural"  

"Families and guests seem to have entered the waiting rooms"  
"Students are gathering too... it's finally happening..."

Checking the ceremony program stage-side, Kiriko and Sawa, Mizuki and Nana exchanged words.  
Kiriko, former athletics club member with strong projection, served as main MC. Nana, with acting experience and clear articulation, was sub-MC.  
Sawa and Mizuki would provide support as needed.  
Though foundation-hired venue staff were more experienced, Yuu and Sayaka specifically requested the student council members handle MC duties.

Determined to steer Sairei Academy toward his vision, Yuu planned to serve consecutive terms as student council president if circumstances allowed.  
Student council members would support him in this. He'd recently confessed his intention to make them life partners too.  
If all went well, next March would see Kiriko and four others as brides, with new council members serving as MCs.

As start time approached, students streamed into the venue. By 30 minutes before, a considerable crowd had gathered.  
Seated in class-assigned pipe chairs or chatting while admiring the transformed stage, they created quite a din.

At 20 minutes before, families from each household assembled in their stage-side seats.  
Everyone was dressed up, but Yuu's family drew particular attention.  
Martina wore deep green, Elena crimson dresses. Whispers of "As expected of Yuu's mother and sister" spread at their beauty.  
The twins Haru and Luna born to Martina would watch from their stroller.  
Representing Yuu's half-sisters, Satsuki attended despite her ninth-month pregnancy. Having watched over her beloved younger brother since their July meeting, she wouldn't miss his special day.

The Hanmura family included Riko's mother and grandmother. The Ishikawa family had Emi's mother and grandparents in the brides' family seats.  
The Komatsu family was numerous. Parents Hikaru and Tomoka, grandparents Yoshioki and Reika. Younger sister Kiyoka and great-aunt Ritsuka also attended.  
Traditionally holding Shinto-style weddings, the Komatsus wore coordinated Japanese attire. Reika and Ritsuka appeared accustomed, but Kiyoka in red-based white-and-pink patterned furisode seemed restless.  
Though busy with work, all three families' parents (and grandparents) were enthusiastically supporting their daughters' (granddaughters') wedding.  
Strollers in all three family sections held Hajime, Yurika, and Miyu to witness their parents' ceremony.

Guest seats lined the wall near the stage.  
Foundation representatives Toyoda Haruka and Fuyuno attended. Sairei Academy's principal and vice-principal. Ayakuni Group chairman. Saito City General Hospital director and chief administrator deeply connected to Yuu were specially invited.

---

Lights dimmed simultaneously at exactly 11:00 AM.  
The main entrance was already closed, and black curtains covered second-floor windows, creating near-total darkness.

"Thank you for waiting. The wedding ceremony for the Hirose, Komatsu, Hanmura, and Ishikawa families will now commence. Please direct your attention forward. First, the entrance of the bridal party!"

As Kiriko's slightly tense announcement concluded, spotlights illuminated the stage.  
A light classical piece evoking spring's arrival began playing.

"The groom Hirose Yuu-kun, brides Komatsu Sayaka-san, Hanmura Riko-san, and Ishikawa Emi-san! Everyone, please welcome them with applause!"

As applause erupted throughout the venue, four figures in pure white appeared from stage left. Simultaneous murmurs spread.  
Yuu in pristine white tuxedo carried Sayaka in wedding dress princess-style.  
Flanking them, Riko and Emi in matching wedding dresses clung to Yuu's arms.  
The four slowly advanced downstage. At center stage, Yuu set Sayaka down.

The bridal party entrance posed initial planning challenges.  
Standard weddings feature one bride and groom. Rare two-bride ceremonies have the groom escorted with one bride per arm.  
The veteran planner handling arrangements had no experience with three brides.  
Two brides could flank the groom, but positioning the third proved awkward whether placed before or behind.  
Placing two brides on one side seemed safest...

Then Yuu proposed carrying Sayaka.  
The challenge: Could he carry Sayaka, taller than average 18-year-old women, while walking?  
He'd carried her playfully before, but dropping and injuring her during the ceremony was unacceptable.  
With limited time before the event, Yuu trained intensively at MALSOK's training center under instructor supervision. Sayaka carefully reduced her weight through diet without compromising health.  
Their efforts succeeded - during the rehearsal two days prior, he carried her smoothly from stage left to center.

Sayaka's face flushed as she safely descended from Yuu's arms.  
Though embarrassed at being carried during their grand entrance, joy outweighed the shyness.

"Th-thank you. Yuu-kun. Was I heavy?"  
"No, not heavy at all. Only..."  
"Only?"  
"The dress fabric is slipperier than during rehearsal, so I panicked slightly"  
"Fufu. Really? You seemed perfectly steady"  
"Lucky~ I'm jealous you got carried by Yuu-kun~"  
"I could've carried each of you back and forth separately"  
"That might be a bit..."

Amidst the commotion over the unprecedented entrance, Yuu and the three whispered quietly.  
Under the spotlight, Yuu's white tuxedo shone brilliantly, drawing intense focus from every female attendee. Staring passionately at Yuu, many involuntarily murmured: "So handsome", "Falling for him again", "I love him".  

Though the brides' wedding dresses - every girl's dream - along with their stylist-enhanced beauty through makeup, hairstyling, hair ornaments, earrings, and necklaces drew admiration, the ceremony's true star remained Yuu.  
Couldn't Yuu take any number of wives? Many female students present wished they too could be loved as Yuu's wife. The ceremony commenced with such desires filling the air.

---

### Author's Afterword

As previously announced, the comic adaptation of *Reborn in a Chastity Reversal World* ("COMIC VAMP" by Aikawa Tatsuki) begins serialization on 4/25!!

To commemorate this, we've received and are sharing a color illustration.  
It features Martina and Elena flanking Yuu - based on Episode 5 (bath scene)!

You can view it on my activity reports or Twitter. Please take a look!

https://syosetu.com/userxblogmanage/view/blogkey/330099/  
https://twitter.com/ryoma35149721/status/1516788163125346310

### Chapter Translation Notes
- Translated "大安の日" as "auspicious day" to convey the cultural concept of favorable dates
- Preserved Japanese honorifics (-kun, -san) and name order (Hirose Yuu)
- Translated "花嫁3人" as "three brides" to maintain consistency with polyandrous setting
- Rendered "お姫様抱っこ" as "princess-style carry" to describe the specific carrying method
- Translated "振り袖姿" as "furisode" with explanation in context
- Used "stylists" for "スタイリスト" to convey professional preparation role
- Translated "人前式" as "civil ceremony" to denote non-religious wedding format
- Preserved organization names per Fixed Reference (MALSOK, Toyoda Sakuya Memorial Foundation)