## 389. Wedding Ceremony ② ~Diamonds~

"I, Hirose Yuu"  
"Komatsu Sayaka"  
"Hanmura Riko"  
"Ishikawa Emi"  
""""With all present as witnesses, pledge our marriage"""" 

Yuu, Sayaka, Riko, and Emi faced forward at the center of the stage and began reciting their vows. From the guest seats, foundation director Haruka and Ayakuni Group chairwoman Kodama Ayako approached as special witnesses. The four continued their pledge:

"From this day forward, in health and sickness"  
"In joy and sorrow"  
"In wealth and poverty"  
"We pledge to love and respect each other, support one another, and for as long as we live... no, even if we die and are reborn, I swear to love Sayaka, Riko, and Emi with all my heart."

Yuu had added words not in the rehearsal script, surprising all three. But when their eyes met, they understood his meaning and nodded.

""""We too""""  
"No matter what difficulties await us"  
"Will support Yuu-kun and build a bright, smiling household"  
"And live together"  
""""We swear!""""

"March 25, 1991. Groom: Hirose Yuu"  
"Bride: Komatsu Sayaka"  
"Bride: Hanmura Riko"  
"Bride: Ishikawa Emi"

As they finished their vows, thunderous cheers and applause erupted. Voices calling their names and blessing their marriage mixed in the air. Urged by Haruka and Ayako, the four holding hands proceeded down the aisle extending from the stage. Though the ceremony had just begun, the venue was already giving a standing ovation. Students at the front had apparently been given supplies in advance, setting off party poppers as Yuu passed. When they reached the end, the three brides surrounded Yuu and waved to the crowd with smiles.

The applause and cheers showed no sign of stopping, but quieted at the MC's voice. Special witness Ayako took the microphone.

"Now officially wedded. Hirose Yuu-kun, Komatsu Sayaka-san, Hanmura Riko-san, Ishikawa Emi-san. Congratulations on your marriage."

Applause erupted again, and the four bowed in gratitude.

"When I heard you wanted to hold your wedding at school, I was quite surprised. Sairei Academy is coeducational, so many couples have dated and married, but usually right after graduation or years later. However, as you all know, Hirose Yuu-kun stood out in a good way right after enrollment."

Laughter arose - friendly laughter. All three brides nodded emphatically while Yuu scratched his head. Come to think of it, Yuu had stood out during basketball club trials in early April, which led to his student council membership.

"When I heard Hirose-kun would become the first male student council president, I worried what might happen, but it was completely unfounded. Rather, Sairei Academy's students have cultivated mutual consideration and support, strengthening school unity. This foundation came from working alongside brides Komatsu-san, Hanmura-san, and Ishikawa-san in student council activities. Since you four cooperated in the student council, you'll surely build a wonderful household."

Enthusiastic applause followed. Sayaka's charismatic popularity as council president, and Riko and Emi who supported her well, inspired admiration but stronger still were wishes for their happiness.

"Honestly, we didn't know how a school wedding would turn out until we tried. But watching now, I feel it's become a magnificent ceremony. This also reflects everyone's daily attitudes. Hirose-kun, Komatsu-san, Hanmura-san, Ishikawa-san - may you continue to be happy!"

Ayako Kodama, who since youth had shown talent more as a manager than educator, founding six schools through junior high to junior college with solid management, concluded her smooth, almost salesperson-like congratulatory speech to overwhelming applause.

"Thank you, chairwoman. Next, let's have the exchange of rings and pledge kiss by the bride and groom!"

"Waaah!" Cheers erupted. Before such a crowd, even Yuu and Sayaka felt somewhat embarrassed, but this was an essential marriage ritual. From the MC seats, Mizuki and Sawa approached carefully holding four small boxes. Yuu took one.

The wedding rings were ones Yuu had selected beforehand at a Saito City jewelry store - platinum bands with modest diamond accents. Though typically provided by the bride's side, Yuu insisted on arranging this himself for his first wedding. He was enthusiastic about his rebirth's first marriage ceremony.

However, at 16 years old, he couldn't afford what's commonly called "three months' salary." But as a high schooler, Yuu received monthly sperm donation compensation plus savings Martina had accumulated. With little time for play and minimal material desires, he'd hardly touched it. Thus he had enough for rings equivalent to a company employee's monthly salary times the number needed.

But the jewelry store offered to provide them free if they could use Yuu's name for promotion. They anticipated significant customer attraction from advertising that the famously popular Yuu had purchased wedding rings there - more reliable than TV commercials. Yuu hesitated, feeling a man's pride prevented getting free rings for his beloved wives. After negotiation, he permitted name usage but paid half price, expecting future favors when his wives bought jewelry.

Taking the ring from its box, Yuu first faced Sayaka. In her daring off-shoulder all-lace wedding dress, her long black hair carefully combed and flowing down her back as usual with silky sheen, the silver tiara-crowned Sayaka looked nobly beautiful like a princess.

"Sayaka. I've been smitten with you since we met. Let me stay with you forever."  
"Yu... Yuu-kun..."

Sayaka covered her mouth at Yuu's simple but heartfelt words. After being trapped in an unwanted engagement and struggling in unrewarding days, she'd met Yuu. She couldn't have imagined such happiness a year ago.

"Now, give me your left hand."  
"Yes"

Sayaka's hands were relatively large for a woman with long fingers from middle school kendo. Yuu slid the ring onto her ring finger. As platinum light shone on Sayaka's finger, she let out a moved sob.

"Sayaka, don't cry yet."

Yuu took Sayaka's ring-adorned left hand while wrapping his arm around her waist. Sayaka embraced Yuu's back, and they gazed at each other.

"I think... I'm the happiest woman in the world."  
"I'm the happiest too, marrying such a wonderful Sayaka."

They shared their pledge kiss - not ceremonial, but a lingering kiss confirming each other's lips. "Kyaa!" came the shrill cheers.

"Riko seems cool on the surface but passionate inside."  
"Sniff... Ever since meeting Yuu-kun... I've been crazy about you... I'll never let go!"  
"Yeah. I won't let go either. Forever."

Riko, Sairei Academy's renowned talented beauty and cool beauty, normally composed and rarely emotional, now had reddened eyes. Tears threatened to spill from her narrow eyes. Though not truly homosexual, Riko had harbored more than friendship for Sayaka. But Yuu had captivated her woman's heart. Moreover, she'd gotten pregnant and married almost simultaneously with Sayaka and Emi. She couldn't wish for greater happiness.

Today Riko had her long black hair up, silver hair ornaments swaying - suiting her slender, mature-featured face. When they met in April, Riko had been a few centimeters taller, but nearly a year later Yuu had caught up. However, her high heels put her face higher than Yuu's. For today only without glasses, Yuu wiped tears from Riko's eyes with his finger. The tearful Riko managed a smile. They embraced and exchanged their pledge kiss.

"Yuu-kun"  
"Emi"

Yuu faced his third bride. Emi had slightly changed her usual twin-tail hairstyle - small buns on both sides with thin strands hanging down. In Yuu's memory, it resembled a shorter version of the pretty sailor soldier who punishes in the name of the moon.

"Ufufu. Having Yuu-kun's baby and a wedding. My dream came true."

While Sayaka and Riko were near tears, Emi shone with a sunny smile - truly at happiness's peak. Yuu had always been encouraged by Emi's bright smile.

"This isn't the goal. Our married life starts now."  
"Yeah! Let's keep going, Yuu-kun!"

Yuu embraced the smallest of the three, Emi, and kissed her. In return, all three placed a ring on Yuu's left ring finger. From Yuu's view: Sayaka front, Riko right, Emi left - they simultaneously hugged him and kissed him in succession. Officially, Sayaka was first wife, Riko second, Emi third. But Yuu loved all three equally as wives - this ritual symbolized that.

With the ceremony's main event complete, next came the group toast. Long tables for each class lined the walls and aisles, covered with white cloths. When entrances opened, physical education students brought in food/drink containers via dollies from trucks outside. Classmates received and arranged them on tables. Students included adults (18+) but had non-alcoholic drinks; only guests received beer. Food centered on light meals like sandwiches - simple compared to typical wedding fare. This accommodated the large crowd without fees and minimized outsiders for security.

While refreshments were prepared, the wedding party returned to their seats but soon greeted families. First, they approached the Hirose family. Amid congratulations, all four bowed.

"I thought you were still a child... but Yuu-chan looks so grown up now."  
"Facing such a huge crowd without flinching is so like Yuu."  
"Well, actually I was pretty nervous... but I put on a brave face for my brides."

Yuu smiled sheepishly at Martina and Satsuki's words. Having watched Yuu's wedding with complex feelings, Elena had been quiet, but now surrounded by the three brides. Since they'd been separate in waiting rooms, this was their first meeting. Sayaka and others praised Elena's beauty and expressed joy at becoming sisters-in-law, making the rarely flustered Elena blush. In-law relationships can be tricky regardless of cohabitation, especially in this brother-complex-filled world where wives and sisters-in-law easily clash. But Sayaka, Riko, and Emi understood social graces - though younger, they knew human relations better.

Martina's twins Haru and Luna mostly slept during the ceremony but were now awake. As the brides excitedly surrounded them saying "So cute!", the babies stared back curiously. Though under a month old, they sensed the unusual atmosphere. Their identical expressions and gestures showed their twin bond.

"Congratulations"  
"Congratulations!"  
"Thank you"

Next they visited the brides' families. Since Sayaka and others returned home for childbirth in February, Yuu had visited all three families weekly and was now completely familiar.

Typically, husbands rarely visit wives' parents. Especially with multiple wives or distance, visits become infrequent. But Yuu actively engaged with all three families - partly because he liked them. Regardless, all three families welcomed Yuu's visits and built good relationships. Thus they wholeheartedly celebrated their daughters' special day.

"Hajime~, it's Papa~"  
"Ah~, ah~"  
"Oh my, does he know it's Papa?"

Sayaka's Hajime couldn't speak meaningful words yet but waved hands and vocalized frequently. When Yuu brought his face close to the lifted Hajime, the baby touched his cheeks as if trying to communicate. Did he recognize his father despite weekly visits? Yuu's eyes softened with affection. Riko's Yurika and Emi's Miyu had also started vocalizing recently, but perhaps as the firstborn, Hajime seemed most expressive.

"Hajime takes after Sayaka - seems he'll be smart."  
"I think he'll have Yuu-kun's magnanimous character."  
"Oh? For intelligence, my Yurika wins!"  
"Charm matters most for girls. And Miyu's cuteness is unmatched!"

Mako (Riko's mother) and Asami (Emi's mother) joined Yuu and Sayaka's conversation. Though never competitive about daughters, grandchildren changed that. Having heard endless grandchild/ great-grandchild bragging, Yuu smiled wryly.

"Hajime, Yurika, and Miyu are all proud children born from my beloved wives. I adore all three. While I look forward to their growth, I'll be shocked when they leave the nest."  
"Yuu-kun, that's premature."  
"But I'm surprised Yuu-kun became such a doting father."  
"R-really?"

Yuu's words pleased not just Sayaka but Riko and Emi too, who hugged their children and leaned in. When children arrive, women strengthen their maternal identity. With multiple wives, while love for wives matters, how fathers treat children can create disparities. But Yuu never intended to rank his children.

The venue finally had toast preparations ready - distributing cups took time given the crowd.

"Everyone~, have you all received drinks?"

Nana, taking over MC duties from Kiriko, called out as people raised cups. Yuu's group received juice cups and returned to center stage. Holding babies prevented toasting, but Sayaka, Riko, and Emi wanted their children present, so their mothers held cups.

"Now for the toast, we ask Toyoda Sakuya Memorial Foundation director, Toyoda Haruka-sama!"

Haruka in black kimono bowed before the guest seats. Officially, Yuu wasn't revealed as Sakuya's son - at least until graduation. But such open support made some suspect a connection. They avoided prying further, fearing Yuu's displeasure.

"Congratulations on your marriage, Hirose Yuu-kun, Komatsu Sayaka-san, Hanmura Riko-san, Ishikawa Emi-san. A wedding with the whole school - truly wonderful. This celebration clearly brings joy to Sairei Academy High School too.  
To celebrate this marriage and the couple's future, allow me to propose the toast. Ready?  
Then... Kanpai!"

Following Haruka's lead, everyone chorused "Kanpai!" Congratulatory shouts rose for Yuu, Sayaka, Riko, and Emi, mixed with "I want to marry Yuu-kun too!" and "I want his baby!" For other boys, these might remain dreams. But with Yuu, opportunity might come - indeed, some first-to-third-years had already slept with him and gotten pregnant. With such hope, while some admired or envied Sayaka's group, none resented them - all celebrated sincerely.

Yuu looked around at congratulating staff and students, waving back. Then he gazed at Sayaka, Riko, and Emi smiling while holding babies.

"Like I said earlier, I'm truly blessed. Three times - no, more - happier than ordinary men."  
"Fufu, what's this, Yuu-kun?"  
"Well, marrying such beautiful, amazing girls and having children..."  
"We're happier to have Yuu-kun's children and this marriage."  
"And being blessed by so many people."

Yuu kissed Sayaka, Riko, and Emi again as they looked at him. He never imagined his rebirth's first-year conclusion would be marrying three brides. Beyond his three wives, children included his birth mother Martina, half-sisters not present, nurses from the general hospital, and women from other schools. Class 1-5 girls were also having his babies continuously. Like current student council members, many more were pregnant and would give birth. Watching everyone's blessings, Yuu felt truly grateful for being reborn in this world.

---

### Author's Afterword

Marriage isn't the goal but a new beginning, true. But as a happy ending, could there be a more splendid stage? Thus, I've concluded with the wedding ceremony of protagonist Yuu and the heroines from the beginning - Sayaka, Riko, and Emi. The next epilogue will complete the story.

...But apologies. I'll take a one-week break before posting. Instead, I plan to post a sibling-themed short story I'm currently writing. Of course, I've also started planning side stories (aftermath).

2022/4/25 Update  
The comic adaptation has begun serialization!  
URLs:  
Nico Nico Seiga: http://seiga.nicovideo.jp/comic/57884  
CW: https://comic-walker.com/contents/detail/KDCW_VP01203008010000_68

### Chapter Translation Notes
- Translated "ダイヤモンド" as "Diamonds" in the title to maintain symbolic meaning
- Preserved Japanese honorifics (-kun, -san, -sama) throughout
- Translated "誓いのキス" as "pledge kiss" to convey ceremonial significance
- Used explicit anatomical terms ("semen", "pregnant") per translation rules
- Maintained original name order (Hirose Yuu, Komatsu Sayaka, etc.)
- Transliterated sound effects: "キャー" → "Kyaa!", "わぁっ" → "Waaah!"
- Translated "杞憂" idiomatically as "unfounded" for natural flow
- Rendered sexual references directly ("sperm donation compensation")
- Kept culturally specific terms like "kanpai" with explanation in context
- Preserved corporate/organization names per Fixed Reference (Sairei Academy, Toyoda Sakuya Memorial Foundation)