## Epilogue ~Endless Dream~

### Author's Preface

I've added this to the previous afterword - the URLs for the comic adaptation are as follows:

Nico Nico Seiga: http://seiga.nicovideo.jp/comic/57884

Comic Walker: https://comic-walker.com/contents/detail/KDCW_VP01203008010000_68

Nico Nico seems to require user registration, but Comic Walker can be read for free without an account.

---

April 8, Monday.

The day of Sairei Academy High School's entrance ceremony.

A major characteristic of the 1991 academic year was the significant increase in the number of new first-year students.

The number of applicants wishing to enroll had reached unprecedented levels, and the entrance exam competition rate recorded the highest in the nation by far, regardless of whether the school was public or private.

The school had anticipated this due to the surge in inquiries since the previous year. They had planned to add one class each to the girls' and boys' general courses and had begun expanding and renovating the school building.

The incoming first-year students totaled 288 girls and 52 boys across the general and physical education courses. While the total number of students in a grade, including transfer students, had reached 300 in the past, this year's enrollment stood at 340 from April.

Incidentally, nationwide, there was an increasing trend of junior high school students aiming for coeducational schools.

There were many petitions submitted to the Ministry of Education and local boards of education requesting an increase in coeducational schools or the conversion of existing boys' and girls' schools to coeducational ones. Reports indicated that the authorities were considering these requests.

Not only the surge in applicants to Sairei Academy High School but also this trend might be attributed to the nationwide recognition of the situation at Sairei Academy, including Yuu.

Returning to Sairei Academy.

Naturally, the entrance ceremony attendees were the new first-year students and faculty. The current students—new second and third-years—would begin their school year with the opening ceremony the following day.

However, it was customary for the student council president to deliver a welcome speech at the entrance ceremony as the representative of the current students.

The new first-year students, clad in brand-new uniforms, especially the girls, were swelling with anticipation at the prospect of seeing student council president Hirose Yuu so soon after enrollment.

The ceremony proceeded solemnly: the entrance of the new students, the singing of the national anthem, the principal's address, greetings from guests, and the reading of congratulatory telegrams.

"Next, the welcome speech by the representative of the current students. Student Council President Hirose Yuu."

As the emcee announced, a wave of high-pitched cheers erupted.

Until then, the first-year students had been quiet, but their emotions burst forth, and they couldn't help but voice their excitement. Remembering they were in the middle of a solemn ceremony, they quickly covered their mouths with their hands or looked down in embarrassment—a charmingly innocent sight.

Called to the stage, Yuu walked out from the wings. Today, he was dressed in his school uniform, the gakuran.

Yuu had grown taller since entering high school. He was now quite tall for a 16-year-old boy.

Despite having an appetite that astonished his lunch companions, he maintained a slim, well-proportioned physique by never skipping his weekly training.

It wasn't just his physique.

Having become student council president, he had more opportunities to speak in front of large groups and with adults outside the school. Moreover, having overcome two kidnapping incidents, his features had gained a certain sharpness.

After a year filled with so many events, perhaps his appearance had finally begun to catch up a little with his mental age.

As Yuu made his dashing entrance and approached the microphone, not only the first-year students but also the female faculty members stared intently, not wanting to miss a single moment of his movements.

Feeling the intense gazes directed at him, Yuu was enveloped in a pleasant tension.

Had this been Yuu a year ago, he would have been too nervous to speak properly.

But now, he even found it pleasurable to be the center of attention for so many girls. It seemed that when the environment changed, so did the person.

Facing the microphone, Yuu looked out at the rows of first-year students.

Until just now, they had been listening seriously without idle chatter, but now everyone had lifted their faces, many beaming as they gazed at Yuu.

The ratio of boys to girls in the first-year was nearly 1:6, and compared to the seemingly reserved boys, the girls appeared noticeably lively.

Having passed the interview exam, they were all cute.

Since they had only recently been junior high school students, they generally seemed youthful, but some had a mature, sensual air about them.

One of them, the tall and conspicuous Shiranui Sumiko, met Yuu's eyes, and he smiled back.

"Haaah~~~"

"Ahh..."

"Hi, Hirose-senpai... wonderful..."

"I'm so glad I was able to enroll..."

Even before Yuu uttered a word, sighs of overwhelming emotion and whispered thoughts leaked out from many girls.

Whether they had originally aimed for a coeducational school or not, the majority had chosen Sairei Academy out of admiration for Yuu. Knowing the unprecedented competition rate, they had studied desperately for the entrance exams. Applicants near the borderline had clung to their desks with blood, sweat, and tears to secure their admission.

Unlike idols seen only on TV or from afar at concert venues, enrolling in Sairei Academy meant they could see him up close and hear his real voice.

With luck, they might even speak to him directly and become intimate, perhaps even entering a romantic relationship... their dreams swelled.

It wasn't just the fangirl mentality of adolescence. In life, the chance to interact with a man like Yuu was only possible during their school years. Many girls were already burning with determination to get close to him.

There was a slight stir, but when Yuu picked up the microphone and switched it on, the hall fell silent.

"To all new first-year students, congratulations on your enrollment."

Yuu felt relieved that he had managed to start speaking in a fairly calm voice, without his voice cracking, though not as composed as his predecessor Sayaka had been.

Confirming that the first-years were listening quietly, he continued.

"I imagine you all have dreams and hopes for the high school life that is about to begin. At the same time, you may feel anxious about the unfamiliar environment. To help make your school life meaningful, we, the second and third-year students, intend to support you with all our might.

Sairei Academy High School is packed with fulfilling events. I believe that whether you are a boy or a girl, you will be able to adapt to school life. To ensure that you feel glad to have enrolled in Sairei Academy, we, the student council, will............"

The content was a slightly revised version of the script Sayaka had used at last year's entrance ceremony.

Yuu inwardly congratulated himself for speaking smoothly, pausing appropriately without stumbling.

When Yuu finished speaking and bowed, thunderous applause erupted. The applause seemed more passionate than that for the principal and guests earlier.

"Next, the pledge by the new first-year students. Representative, Komatsu Kiyoka."

"Yes!"

Komatsu Kiyoka, seated in the front row, stood up with a spirited reply and walked forward.

Her long black hair, identical to her sister's, fluttered as she walked.

Normally, after Yuu exited, the principal would have taken the stage.

However, the teacher serving as emcee gestured for Yuu to remain where he was.

It seemed they intended to have the student representatives face each other.

Yuu had been curious about who would be chosen as the representative.

Since the selection was likely based on entrance exam results and report card grades, he had predicted that Shiranui Sumiko and Komatsu Kiyoka—both regular top scorers in the prefecture—would be strong candidates. Especially since Sumiko had even served as student council president at Saihou Junior High.

To Yuu, both were beautiful, talented girls with whom he had established relationships before their enrollment, but he was genuinely pleased that Kiyoka, whom he cherished like a real little sister, had been chosen.

Reflecting on it, Sayaka had been the graduate representative at March's graduation ceremony. Now, with the change in academic year, Kiyoka was the new first-year representative facing him. It seemed the Komatsu sisters shared a strange connection with him.

Walking up to the podium, visibly nervous, Kiyoka noticed Yuu still standing there. Her cheeks flushed red, but she bowed properly as per procedure and lifted her face.

Though she had grown taller since they first met, she still hadn't reached 150 cm.

Having been sickly as a child, she remained slender. Even through her sailor uniform, the swell of her chest was hardly noticeable. Among the first-years, her childishness stood out.

While her sister Sayaka was dignified and noble—like a large rose if compared to a flower—Kiyoka had a quiet beauty like a lily or a narcissus.

Her appearance alone gave her a fragile aura that made one want to protect her. In reality, she had a strong libido and a competitive streak.

Though she held her script, Kiyoka found herself unable to speak as she locked eyes with Yuu.

Despite having met and talked with Yuu many times before, facing him as a senior at the same school during the entrance ceremony might have overwhelmed her with emotion.

"Kiyoka, just talk to me like you usually do."

"Ye... yes."

When Yuu whispered softly, Kiyoka nodded with an unmistakably happy expression.

"With the arrival of warm spring, we 340 students have been able to attend the entrance ceremony as first-year students of Sairei Academy High School.

The cherry blossoms blooming in the schoolyard seem to welcome us.

Thank you for holding such a splendid entrance ceremony for us today............"

Time-wise, it was a speech of only about three minutes.

Kiyoka seemed to have memorized it. Though she held the script, she never glanced at it, speaking straight to Yuu until she finished.

After folding the script, Kiyoka parted her lips, which resembled cherry blossom buds.

"I... no, we... held a strong desire to enter Sairei Academy High School no matter what, and we overcame the rigorous entrance exams.

Now, facing our senior in the same place of learning, we savor the joy.

We wish to take pride as Sairei High students, improve ourselves, and lead a high school life without regrets. We humbly ask for your guidance."

The additional words, which seemed to have occurred to Kiyoka on the spot, felt as though they were directed straight at Yuu.

Yuu extended his right hand toward Kiyoka.

Startled by the offered hand, Kiyoka hastily extended her own right hand, and the two shook hands.

"We look forward to working with you too."

Yuu smiled at Kiyoka.

Given her small stature, Kiyoka's hand was tiny. Just being enveloped in Yuu's large palm warmed her heart, and she smiled back.

Afterward, the homeroom teachers for the first-year classes were announced.

The girls were divided into eight classes—Groups 1 to 7 for the general course, Group 8 for physical education.

For the first time since the school's founding, the boys were divided into two classes: Class A and Class B.

Kanbayashi-sensei, who had been Yuu's homeroom teacher in his first year, remained in charge of first-year boys as the homeroom teacher for Class A.

Tezuka-sensei, who had been the homeroom teacher for the girls' Class 5, also remained with the first-years, becoming the homeroom teacher for Class 7.

The first-year homeroom teachers were generally young, in their 20s to early 30s. Many were teachers Yuu knew, like Tezuka-sensei, but there were also new faces who had just been appointed this year.

As Yuu watched the teachers lined up on stage introducing themselves, he hoped to become close with the new teachers soon.

After the introduction of homeroom teachers and the singing of the school song, the closing remarks marked the end of the entrance ceremony.

Before the first-years exited, Yuu hurried out through a different entrance. He still had something to do.

After a short wait, the first-years began exiting in two columns, starting with Girls' Group 1 and Boys' Class A.

At the announcement, they stood up and turned around, murmuring in surprise.

Upperclassmen, both male and female, had formed an arch decorated with cherry blossoms leading to the main entrance.

This was an idea Yuu had proposed at the student council after learning of his role as student council president delivering the welcome speech.

Though the time was short, not only the student council members but also friends had been called to help prepare.

Given that it was Yuu's request, the girls of Sairei would never refuse, and they all readily agreed to cooperate.

Boys from Yuu's class also helped, so over 30 students—both male and female—formed the arch.

From the first-years' perspective, the side for the boys to pass through was lined with helpful second and third-year girls, while the side for the first-year girls was led by Yuu, with seven boys lined up.

"Congratulations!"  
"Co-congratulations."  
"Congratulations."

Not only Yuu at the front but also Higashino Rei, who had rushed over for the occasion, offered words of congratulations with slight embarrassment, and Yamada Masaya with a cool smile.

The petite girl at the head of the first-year line started walking but froze when greeted with smiles by Yuu and the others.

Her junior high school had been all-girls. Even in public schools, if there were boys, there was hardly any contact. Even if a girl was lucky enough to have a chance to approach a boy and mustered the courage to speak, being ignored was the best she could expect.

She had never experienced a scene where multiple boys greeted her cheerfully like this.

"Hey, you need to keep moving, or you'll cause a jam."  
"Ah, sorry!"

Having stopped, she had caused a congestion, so she hurriedly started walking again.

Unable to look directly at Yuu's dazzling smile, she tried to pass by with quick bows, but Yuu called out to her.

"Hehe. How cute. Let's get along from now on."  
"Hyaaah!"

Yuu had been charmed by the girl blushing right in front of him, and the words slipped out. But being spoken to directly sent her into raptures.

She stopped walking again, too captivated by Yuu, and ended up being pushed from behind.

Not only Yuu but also Rei, with his androgynous, protective charm, and Masaya, the cool bespectacled handsome guy—every first-year girl passing by under the gaze of these senior boys looked delighted.

The boys' line also passed under the cheerful gazes of beautiful senior girls, walking through with embarrassment.

In this world, young boys generally tended to avoid women, but perhaps because they had chosen a coeducational school, they didn't seem pointlessly afraid.

Maybe their innate personalities or their family and relative environments had given them some immunity.

Even after the shorter boys' line ended, they didn't rearrange into two columns.

Everyone knew that every girl wanted to pass by Yuu.

When Group 3 arrived after Groups 1 and 2, Kiyoka, at the front, approached.

"Brother-in-law!"  
"Kiyoka!"

Perhaps unconsciously, due to their in-law relationship, Kiyoka stepped slightly closer to Yuu. Beaming, she waved both hands playfully in front of her.

Yuu, drawn in, extended his right hand and high-fived Kiyoka.

Then, the girl next in line behind Kiyoka timidly extended her right hand, so Yuu high-fived her without hesitation.

Perhaps influenced by Yuu, the boys from his class had already started dating and had become closer to the girls.

So, when Kiyoka bowed slightly and extended her hand, Rei also high-fived her, albeit hesitantly.

Before they knew it, they were seeing off the first-years with high-fives.

Later in the girls' line, during Group 6, it was Sumiko's turn.

Up close to Yuu, Sumiko's eyes grew moist, her expression clearly moved.

"Welcome to Sairei Academy. I welcome you, Sumiko."  
"Yu... Yuu-senpai!"

Yuu and Sumiko exchanged a high-five with their right hands.

Touching Yuu's hand, Sumiko barely contained her explosive joy.

Yuu whispered softly, so only Sumiko could hear.

"I'll be waiting for you to join the student council."  
"I'll definitely come!"

For Sumiko, it was as if she had enrolled in Sairei Academy for Yuu.

Joining the student council and spending her high school life close to Yuu would fulfill her greatest wish.

If she could enter the student council led by Yuu, the dream of pregnancy and marriage during her school years would come true.

That rumor had already spread among the first-years.

Hence, interest in the student council was already unusually high among the first-years.

*(They're all cute, good kids.)*

After seeing off all the first-years, Yuu thought this while thanking the friends who had helped.

Sayaka and the other third-years had graduated, but now Yuu was a second-year, and new first-years had arrived.

No time makes the passage of a year feel as strongly as during student days.

Especially now, Yuu felt the joy of having juniors.

Over the year, how many first-years would he have sex with and impregnate?

A year ago, for Yuu, who had just been reborn, high school life felt too long ago, and he had often been bewildered.

But being invited to join the student council by Sayaka and the others had been a stroke of luck.

It seemed his second year of high school life would be even more fulfilling.

**[End]**

---

### Author's Afterword

With this, *Reborn in a Chastity Reversal World* comes to an end.

Originally, I came to love the chastity reversal genre and, after reading many works, thought I'd try writing one myself. I started this humble work with ideas like, "If it were me, I'd do it this way..."

When I began serialization in December 2018, I planned for about 100 to 150 chapters, thinking it would end in about a year to a year and a half. But immediately after starting, it was read by far more people than I imagined, and the points became incredible.

In the end, I decided to write until a full year had passed within the story, but with various added episodes and detours, it continued for over three years and four months. In the prologue, Yuu was at rock bottom as a middle-aged man; in the epilogue, he is in the midst of happiness, with a bright future ahead—that's how I ended it.

Above all, the fact that the serialization continued without stopping for so long was largely due to the many comments I received, which kept my motivation high. I am truly grateful.

Happily, I also received an offer for a comic adaptation, which began before the story ended. Seeing the characters from my novel drawn and readable as a manga warmed my heart.

Looking back at the entire work, there are various points of reflection. One is that for a long serialization, I could have reduced the episodes, sped up the development, and made it a story spanning several years.

I'll treat this as the end of the main story, but as I mentioned in my responses to comments, I plan to start an after-story spin-off. Since my stockpile is completely gone, it will be at least a week later. I hope to start during Golden Week.

I have several ideas, such as bringing back characters who disappeared in the latter half and having them reunite with Yuu. I'd be happy if you read that too.

Thank you so much for reading this far!

---

As a bonus, here's some promotion.

*'Trapped in an Elevator Alone with My Sister (15), We Couldn't Hold Back Anymore'*

https://novel18.syosetu.com/n4869hp/

I've uploaded the third short story in the "Trapped in an Elevator and Couldn't Hold Back" series. This time, it's about a brother and sister.

---

2022/5/16

*'Reborn in a Chastity Reversal World: After Story (After)'* has begun!

https://novel18.syosetu.com/n2950hq/

### Chapter Translation Notes
- Translated "貞操逆転世界" as "Chastity Reversal World" to match the fixed novel title
- Preserved Japanese honorifics (-sensei, -senpai) and name order (Last Name First Name)
- Transliterated sound effects: "わぁーっと" → "waaah", "シンと" → "fell silent"
- Translated "学ラン" as "gakuran" (Japanese male school uniform)
- Translated "セーラー服" as "sailor uniform" (Japanese female school uniform)
- Translated "ミーハー" as "fangirl" in context
- Translated "タッチ" as "high-fived" for physical greeting gesture
- Maintained explicit terminology where applicable (e.g., "sex", "impregnate")
- Italicized internal monologues per style guidelines
- Formatted dialogue with new paragraphs per speaker
- Preserved Japanese cultural terms like "Golden Week" without translation
- Translated "ブラウン管" as "TV" for natural reading
- Kept organization names like "Ministry of Education" as standard translations
- Maintained author's promotional content and links exactly as provided